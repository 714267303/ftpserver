# Admin pipeline v2

This is the execution contract for Admin conversion. It replaces all v1
manifest, normalization, approval-only and merged Hybrid instructions.
Old run artifacts remain historical evidence; regenerate their plans and MCP
evidence before execution. There is no v1 migration or unverified-flow bypass.

## Sequence and artifacts

1. Parse Excel → YAML, then structurally read `TestSteps` with Ruby safe YAML.
   Excel conversion keeps its assisted/deterministic options. There is no
   JSON→YAML token-fidelity rejection gate.
2. The model writes `admin-plan.json` with business operations and data selectors.
   It does not write Gherkin or executable locators in the plan.
3. The compiler binds current YAML data, resolves exact menus from PageExplore,
   compiles maintained operation adapters, checks Step_Index and page contracts.
   Invalid plans get at most one model correction before any browser launch.
4. MCP follows the compiled shared actions, observes their results, and performs
   rollback cleanup. MCP writes `exploration-report.json`, optional
   `admin-observations.json`, and structured observations in tool output.
5. The script verifies evidence and produces `admin-flow.json`,
   `admin-bindings.json`, `admin-evidence.json`, and `handoff-report.json`.
   Raw tool events are in `opencode-events.jsonl`; traces/screenshots in
   `playwright/`. A draft `admin-flow.json` before this stage is not executable.
6. The compiler renders `<case>.admin.feature`. Its full steps, order, tables,
   tags and scenario structure must equal the compiled contract before execution.
   Explicit `--repair` can rebuild a drifted Feature from verified evidence.
   Model repair works in an isolated workspace; a changed behavior is rejected
   before it replaces the Feature or runs. User `.rb` files remain read-only.
7. Only real successful execution with a matching Feature hash and all steps
   passed can promote the flow. Dry-run, missing evidence and skipped steps do
   not promote. Then generate independent non-Admin Features.

For a Hybrid case with one overnight boundary, output three Features:
`<case>.admin.feature`, `<case>-Day1.feature`, `<case>-Day2.feature` plus
`<case>.execution-flow.json`. Order is Admin → Day1 → external night batch
gate → Day2. Day1 saves its dump and Day2 loads it. Do not combine these into one
Feature or represent night batch with a short wait. Multiple overnight boundaries
are explicitly unsupported by the current lifecycle scheduler.

Execution-flow v2 records source, Feature, report and Admin contract hashes.
Resume checks completed-stage artifacts too. The operator acknowledges night
batch only after the flow has stopped at that gate. A partially executed failed
or interrupted stage cannot be silently repeated by resume; inspect and restore
its environment before starting a new flow.

## Plan contract

Read `flow_catalog/schema.json` and `examples/admin_plan.example.json`.
The example is structural guidance; include every actual source Admin step,
requested field change, effective-date choice, submission and expected check.
Never copy the example's data into another case.

Each action has a unique `id`, `operation`, named `session`, `phase`, `/UI/`
`page`, 1-based `source_steps`, `args`, and a bound `subject` for record actions.
Several routes may belong to one source step. Navigate in each session before
using that page. Open the same record before editing or submitting its detail.

| Operation | Required args | Resulting UAT operation |
|---|---|---|
| navigate | none | Exact PageExplore menu path |
| search | fields | Search in the corresponding Admin page |
| open_detail | column, fields | Double-click matching record |
| set_fields | fields | Set detail fields |
| effective_date | type; optional card | Indexed effective-type step with record card |
| submit | optional button (default Save) | Create pending countersign request; shared phase |
| commit | optional button (default Save) | Persistent non-countersign save; Feature phase only |
| confirm_message | message | Assert confirmation message |
| close_dialog | optional button (default Close) | Close confirmation window |
| approve | identifier, requester_session | Six-column `Approve if updated with :` table; Feature only |
| verify_table | fields | Check visible table record |
| verify_fields | fields | Check detail fields |
| wait | seconds (1..30) | Bounded runtime wait |

Detail operations accept a documented `detail` title. The default derives from
the page label. The compiler checks the maintained Step_Index; unknown adapters,
pages or fields fail before MCP. Extend `tools/admin_flow/operations.py` and its
tests for a new UI operation; do not invent Gherkin or modify user Ruby steps.
External runtime signatures retain source/version/hash provenance in
`external_step_signatures.json` and are incorporated into Step_Index.

Parameter selectors:

- `{"origin":"yaml","step":1,"field":"testdata","key":"SMP ID"}` selects
  one exact `SMP ID: value` line. For prose/table cells use `text` with an exact
  source span instead of `key`. Missing or ambiguous selectors fail.
- Assertions may select `field:"expected"`; these values cannot supply record
  identity or mutations. Explicit Test Data takes priority over prose aliases.
- `{"origin":"dataset","alias":"admin_gui_user1"}` is a runtime dataset
  alias. Session user/password values must use such aliases, never credentials.
- `{"origin":"observation"}` is for data absent from source. MCP discovers it
  through read-only UI and writes `{"parameter_name":"observed value"}` to
  `admin-observations.json`. All subsequent actions use that same value.

Record subjects and variable `fields` values use `{"param":"parameter_name"}`.
Actual business bindings are private run artifacts. Login secrets never belong
in plans, bindings, Features, observations or catalog metadata.

Use separate maker/checker browser contexts. MCP uses maker credentials from
`ODP_USERNAME/ODP_PASSWORD` and cleanup checker credentials from
`ODP_CHECKER_USERNAME/ODP_CHECKER_PASSWORD`; `SECRET_` aliases are supported.
Feature login uses dataset aliases. The operator must map those aliases to the
intended users in the runtime data files; alias presence alone does not prove
the same user, environment or permissions.

## Browser evidence

Run only `phase:"shared"` actions in order. Await each operation and assert its
actual visible result before emitting an event. Use stable locators through
Playwright MCP; ephemeral snapshot refs are observation handles only.

Each completed tool output contains `ODP_ADMIN_EVENT ` followed by one JSON
object. For example, after a real search and reading the resulting row:

```javascript
// observedRoute and row must be read from the live page/qaGrid.
// observedFields contains UI values, not an echo of the desired plan values.
if (observedRoute !== action.page) throw new Error('wrong page');
if (String(row.smpId) !== String(action.subject['SMP ID'])) throw new Error('wrong row');
console.log('ODP_ADMIN_EVENT ' + JSON.stringify({
  plan_sha256: flow.identity.plan, source_sha256: flow.identity.source,
  status: 'passed', action_id: action.id, operation: action.operation,
  session: action.session, route: observedRoute, subject: action.subject,
  observed: {fields: observedFields}
}));
```

Return/log the event in the MCP tool result, not in model prose or a file the
model wrote. Input code containing `click`, `Save` or `Reject` is not evidence.
Missing, failed, duplicate, out-of-order or foreign-source events fail validation.

Additional records use the same hashes/status/session/route/subject shape:

| operation | observed | Timing |
|---|---|---|
| session | authenticated:true, context_id: distinct local context label | Before this session's actions; no cookies/usernames |
| baseline | fields including identity and every edited active field, pending_request:false | Before first mutation |
| submit (action event) | request_status:"Pending", request_id: SHA-256 of UI request reference | After successful maker submission |
| effective_date (action event) | effective_type: selected type | After selecting effective type |
| reject / cancel | pending_request:false; reject includes same request_id as submit | After shared actions |
| restore | fields identical to baseline, pending_request:false | After cleanup |

Each shared action needs exactly one event with its `action_id`. Other events
omit that key. Baseline/cleanup/restore must refer to this run's changed record.
Hash the request reference read from the live UI with SHA-256 and log only the
64 lowercase hex characters, using the same hash during Reject. Raw UUIDs are
redacted by the transcript writer and cannot establish request identity.
Never reject an unrelated pre-existing request. With countersign, MCP submits
then checker Rejects; Feature submits then Approves. Without countersign, MCP
edits then Cancels and Feature later commits. Always attempt cleanup on an
intermediate failure; report failed if restored state cannot be proven.

Tool-output assertions provide auditable browser observations, not a mathematical
proof of natural-language intent or a defense against fabricated instrumentation.
The compiler checks source coverage, common omitted intents, identity continuity
and adapter validity; review plan/source mapping and screenshots when business
meaning is ambiguous. Approval and post-approval state are deliberately deferred
and only become tested by the real Admin Feature execution.

## Recovery and changes

`--admin-handoff-run RUN_DIR` consumes the existing YAML, v2 plan and durable
transcript. It does not rerun Excel conversion, MCP or an offline inference model.
Missing browser evidence requires fresh exploration after checking cleanup.
Never manufacture success counters or missing events during recovery.

Identity covers source, bindings, plan, adapters, YAML parser, page validator,
Step_Index, sitemap and relevant profiles. Changed inputs invalidate old compiled
flows. A mapping-only compiler fix may re-finalize the same v2 plan and transcript
if every new action/value still matches its evidence. Business plan/data changes
require fresh MCP validation. Catalog promotion is specific to that contract.

MCP has a total and idle deadline (`--admin-explore-timeout`, default 1800 s),
no automatic browser retry, and immediate redacted JSONL persistence. Keep the
last part of the time budget for cleanup. A forced process timeout cannot itself
restore website state. Model Feature repair defaults to 2 attempts (1..5); no
content change stops the retry loop.
