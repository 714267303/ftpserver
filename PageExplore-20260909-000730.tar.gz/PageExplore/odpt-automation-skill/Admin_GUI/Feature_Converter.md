# Admin Feature compiler

The supported pipeline is [Admin v2](Admin_Pipeline_V2.md). The model writes
`admin-plan.json`; scripts bind data and compile steps. MCP validates shared
actions and rollback. A verified compiled flow produces one standalone Admin
Feature. Binary/Day1/Day2 are separate outputs.

## Commands

Run from the tester project containing `PageExplore/`:

```bash
# Preflight the plan before browser use. This draft cannot execute.
python3 PageExplore/tools/admin_feature_converter.py \
  --plan outputs/admin/CASE/run/admin-plan.json \
  --yaml ai/TC/case.yaml --draft \
  --output-flow outputs/admin/CASE/run/admin-flow.json

# After MCP, compile and verify the real observations.
python3 PageExplore/tools/admin_feature_converter.py \
  --plan outputs/admin/CASE/run/admin-plan.json \
  --yaml ai/TC/case.yaml \
  --transcript outputs/admin/CASE/run/opencode-events.jsonl \
  --exploration-report outputs/admin/CASE/run/exploration-report.json \
  --output-flow outputs/admin/CASE/run/admin-flow.json

# Generate the standalone Feature from verified evidence.
python3 PageExplore/tools/admin_feature_converter.py \
  --flow outputs/admin/CASE/run/admin-flow.json \
  --output features/test_case/CASE/case.admin.feature \
  --report features/test_case/CASE/admin-compilation.json

# Exact behavior check before execution or repair promotion.
python3 PageExplore/tools/admin_feature_converter.py \
  --flow outputs/admin/CASE/run/admin-flow.json \
  --verify-feature features/test_case/CASE/case.admin.feature
```

Add `--observations path/to/admin-observations.json` when the plan contains UI
observation parameters. Step_Index and PageExplore default to this skill's
resources, with `--step-index` and `--page-explore-root` overrides.

The source, adapters, reference hashes and original transcript must still match.
Schema v1, arbitrary Gherkin manifests, `--base-feature`, `--standalone-admin`,
`--semantic-strict`, `--strict` and unverified-flow bypasses are unsupported.
Invalid data selectors, missing required operations and unknown page/step
mappings fail before MCP; they are not emitted as executable drafts.

See `examples/admin_plan.example.json` for the plan shape and
`flow_catalog/schema.json` for its JSON Schema. `flow.schema.json` describes the
script-generated result. Trace a generated step using `action_id`, `action_steps`,
source step indices, bindings and the matching event in `admin-evidence.json`.
