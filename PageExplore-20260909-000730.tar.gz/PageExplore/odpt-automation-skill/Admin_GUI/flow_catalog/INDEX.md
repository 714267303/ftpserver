# Admin GUI Reusable Flow Catalog

This index is generated from reviewed semantic manifests under
`Admin_GUI/flow_catalog/flows/`. Playwright traces and screenshots are
evidence pointers only; they are not copied into Features or this index.

Machine-readable index: [`INDEX.json`](INDEX.json)

## Coverage

| Metric | Count |
|---|---:|
| Flow files | 1 |
| Indexed flows | 0 |
| Verified | 0 |
| Observed | 0 |
| Inferred | 0 |
| Marked safe to reuse | 0 |
| Catalog errors | 0 |

Only `evidence_status=verified` and `reuse.safe_to_reuse=true` flows may
be selected automatically for a strict conversion. An `observed` flow
is a shortcut for exploration planning and must be replayed first.

## Flows

| Flow ID | Page | Channel | Evidence | Steps | Reuse | Manifest |
|---|---|---|---|---:|---|---|

## Add A Flow

1. Save the raw Playwright MCP trace/screenshots in an isolated run
   directory, for example `outputs/admin/<case>/run-001/`.
2. Copy the semantic UAT-step manifest into
   `Admin_GUI/flow_catalog/flows/<flow-id>.json` and keep dynamic
   values as dataset placeholders.
3. Record the page profile, redacted Grid observations, and evidence
   paths. Never add raw locator code, credentials, or UUIDs.
4. Replay from a clean state, then set `evidence_status` and
   `safe_to_reuse` to `verified`/`true` only after the feature passes.

```bash
python3 tools/build_admin_flow_catalog.py
python3 tools/build_admin_flow_catalog.py --check
```
