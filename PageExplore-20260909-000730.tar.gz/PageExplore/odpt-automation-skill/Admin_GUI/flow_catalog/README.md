# Admin flow catalog v2

The catalog indexes script-generated v2 contracts. Read
[Admin pipeline v2](../Admin_Pipeline_V2.md) before producing or using one.

- `schema.json`: model-authored business plan schema.
- `flow.schema.json`: compiled flow schema; do not hand-edit compiled steps.
- `flows/`: compiled contracts, including quarantined candidates.
- `INDEX.json` / `INDEX.md`: generated discovery indexes.

A case and plan may have several contract revisions. Catalog identity is
`flow_id + contract_sha256`. Old v1 files are retained as historical references
and counted as excluded; they cannot execute. No automatic migration exists.

A verified browser run starts with `safe_to_reuse:false`. Promotion requires
successful real standalone Admin execution, exact steps/tables, matching hashes,
all steps passed, and intact browser rollback evidence. Reuse checks the current
YAML and compiler/reference hashes again; the status flag alone is insufficient.

```bash
python3 tools/build_admin_flow_catalog.py
python3 tools/build_admin_flow_catalog.py --check
python3 tools/find_admin_flow.py 'SMP'
```

The index is a discovery aid. The compiler performs the authoritative execution
checks, including transcript verification. Raw run evidence stays under
`outputs/admin/<case>/run-*/` and is not bundled as reusable skills.
