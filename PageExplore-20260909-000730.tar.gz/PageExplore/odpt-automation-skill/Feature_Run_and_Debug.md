# Feature Run and Debug

Feature conversion and Feature execution are separate stages.  This keeps a
generated draft reviewable, lets a user edit a Feature before execution, and
allows the same runner to replay an existing Binary, Admin, or Hybrid Feature.

## Portable project layout

Copy this directory into the test checkout; it is not required to be installed
at a fixed repository path:

```
ProjectA/
  features/
  resource/
  PageExplore/
    tools/
    odpt-automation-skill/
    pageExplore/
    odp-docs/
```

Run the tool from `ProjectA` and pass the runtime checkout as `--run-workdir`:

```bash
ruby PageExplore/tools/batch_transform_tc.rb \
  --repair features/test_case/CASE/case.feature \
  --run-workdir . \
  --cucumber-command 'cucumber'
```

Bundled tools, skills, and the PageExplore knowledge base resolve relative to
the copied `PageExplore` directory. The old `/vncworkspace` checkout is never
used unless `ODP_LEGACY_REPO_ROOT` is explicitly set. Set `PAGEEXPLORE_ROOT`
only when the knowledge base is intentionally stored elsewhere.

The restored ODP Functional Specifications are indexed at
`PageExplore/odp-docs/INDEX.md` and `INDEX.json`. They provide business intent
and expected behavior; runtime Ruby step definitions and `Step_Index` remain
the authority for executable syntax. Override the index with `ODP_DOC_INDEX` or
`--odp-doc-index PATH` when a project keeps the documents elsewhere.

## Recommended runner

Use `tools/run_feature_debug.rb` for one Feature. It invokes the target
Cucumber command, captures a bounded combined output transcript, redacts it in
one pass, writes a JSON report, and returns the underlying exit status. The
normal run and diagnosis modes do not edit the Feature; only the explicit
`--repair` mode can do so.

```bash
# Run an existing Feature
ruby tools/run_feature_debug.rb path/to/case.feature \
  --workdir /path/to/uat-checkout \
  --cucumber-command 'bundle exec cucumber' \
  --report outputs/feature-runs/case.json \
  --log outputs/feature-runs/case.log

# Run and ask opencode to diagnose a failed run
ruby tools/run_feature_debug.rb path/to/case.feature \
  --workdir /path/to/uat-checkout \
  --cucumber-command 'bundle exec cucumber' \
  --diagnose \
  --report outputs/feature-runs/case.json
```

OpenCode defaults to the configured internal Ollama model
`ollama/AE&I/Qwen3.8-27B`. Select a model from
`opencode models` with `--model provider/model`, for example:

```bash
ruby tools/run_feature_debug.rb path/to/case.feature \
  --diagnose \
  --model 'ollama/AE&I/Qwen3.8-27B'
```

`OPENCODE_MODEL` is the equivalent environment setting. A custom command that
already contains `--model` or `-m` keeps that explicit command-level choice.
`opencode models` lists models resolved from configuration, but does not test
the provider endpoint. For the internal Ollama model, verify that the
configured `/v1/models` endpoint is reachable from the tester project before
running a repair. If the provider API key is supplied through an environment
variable rather than `opencode.jsonc`, add only that variable name to
`OPENCODE_ENV_ALLOWLIST`.

When Playwright MCP navigates to an internal ODP HTTPS endpoint with a
self-signed or otherwise untrusted certificate, the maintained PageExplore
installer defaults to browser-side certificate bypass
(`PLAYWRIGHT_MCP_IGNORE_HTTPS_ERRORS=1`) and adds
`--ignore-https-errors` to the generated `mcp.playwright.command`. Set the
switch to `0` to restore browser verification. If an existing ProjectA
`opencode.json(c)` was not created by the installer, merge the generated
template entry and restart OpenCode. This setting affects only the Playwright
browser context. Provider TLS must still use a trusted CA, and
`NODE_TLS_REJECT_UNAUTHORIZED=0` is not an acceptable substitute.
The runner's restricted OpenCode environment preserves this specific
non-sensitive variable and defaults it to `1`, so an exported `0` is also
honored during diagnosis and repair.

For a low-level Binary/FIX trace, add `--binary-debug`.  The runner then
passes `LOGLEVEL=DEBUG`, `WABI_FIX_DEBUG=1`, and `WABI_TIMING=1` to the Cucumber
process for that invocation only, and records the enabled variables in the
JSON report.  The converter and the Feature file are unchanged.

Diagnosis is read-only.  The prompt includes bounded Feature/output context
and summaries of `FIXODPMSG_Index.json`, `Error_Code_Index.json`,
`${PAGEEXPLORE_ROOT}/qaGrid/qaGridApi_Index.json`, the selected
`odp-docs/INDEX.json`, and `Step_Index.json`. Error-code lookup uses
`CATEGORY_ID:CODE`; a numeric code alone is not assumed to have one meaning.
The generated `.diagnosis.md` is written beside the report. Secrets, email
addresses, UUID-like values, JSON/Hash credentials, Authorization/Bearer
values, and password table cells are redacted after complete output capture,
so values split across output chunks cannot bypass the filter. Runner output
files are written with `0600` permissions by default.

To repair an existing Feature, opt in explicitly:

```bash
ruby tools/run_feature_debug.rb path/to/case.feature \
  --workdir /path/to/uat-checkout \
  --cucumber-command 'bundle exec cucumber' \
  --repair \
  --model 'ollama/AE&I/Qwen3.8-27B' \
  --repair-opencode-command 'opencode run --pure --thinking' \
  --repair-attempts 2 \
  --repair-experience-dir odpt-automation-skill/repair_experience/inbox
```

The runner executes the Feature first. If it fails, opencode may edit only the
specified Feature; shell commands, configuration changes, and edits to other
files are denied. The runner records before/after hashes and changed paths,
then reruns the Feature. A successful rerun stops the loop. `--repair-attempts
N` limits the number of repair/rerun cycles; the default `0` means continue
until the Feature passes, while runner errors or unauthorized changes stop
the process. Repair output is written to `.repair.md` beside the JSON report.
Each repair run that performs at least one repair attempt also writes a
redacted candidate record to `repair_experience/inbox/` (override with
`--repair-experience-dir`). Candidates are review material only; never promote
one directly to automatic guidance.

Before a repair execution, the runner checks project runtime references with
`--data-preflight auto`. A proven missing value file, literal placeholder, or
unresolved alias blocks both Cucumber and model repair. Alias presence is not
record existence: a configured `smp_id_ca1` still requires Cucumber or a real
Playwright replay to prove that the current ODP page can find its resolved
record. Use `--preflight-only` for this readiness report. Use
`--allow-unresolved-data` to collect one Cucumber failure without allowing the
model to edit around missing data; use `--data-preflight off` only for a
reviewed false positive.

The Cucumber summary is semantic evidence. In
`64 steps (1 failed, 57 skipped, 6 passed)`, the 57 skipped steps never ran.
If step seven is login, a printed SMP search later in the formatter output is
not evidence of an SMP lookup. The report records this under
`execution.cucumber_summary` and `execution.failure_classification`.

An observed `runtime_data_lookup`, `credential_or_session`, or
`environment_or_browser` failure stops repair as `blocked_runtime`; model edits
cannot establish missing external state. A `runtime_data_lookup` may continue
only when a verified/safe replay passes and acknowledges the hashes of the
current Feature and any forwarded bindings, thereby establishing an
authoritative Playwright/Cucumber divergence.

Promote a generalized lesson to `repair_experience/lessons/` only after a clean
replay, then set `status=verified` and `reuse.safe_to_reuse=true`.
When using the standalone runner, `--opencode-command` may supply the repair
command; `--repair-opencode-command` takes precedence when both are given.
`--repair` and `--diagnose` are mutually exclusive. The older
`--debug-feature` mode remains read-only.

Every repair attempt writes a redacted `.repair.md` transcript beside the JSON
report. A `rerun_N.log` is written only after the model command completes and
the runner is allowed to continue to Cucumber. For example,
`repair_permission_denied` means the transcript exists but no rerun log is
expected; the JSON report records `output_exists`, `rerun_attempted`, and the
stop reason explicitly. Copied tester projects do not need a `.git` directory:
the runner authorizes the single Feature under all path forms emitted by
OpenCode for that layout (canonical absolute, project-relative, and
root-relative without the leading slash), without widening the edit scope.

The default diagnosis command is `opencode run --pure --thinking`; it does not
auto-approve tool permissions. The diagnosis child receives an allowlisted
environment and does not inherit ODP credentials. Add an exceptional variable
name to `OPENCODE_ENV_ALLOWLIST` only when the reviewed local provider setup
requires it. Override the command only when the target environment
requires a reviewed custom agent or model configuration.
The default model is `ollama/AE&I/Qwen3.8-27B`; use `--model
provider/model` or `OPENCODE_MODEL` to select another model for diagnosis and
repair.
`FEATURE_MAX_OUTPUT_BYTES` bounds the captured Cucumber transcript (8 MiB by
default); truncation is recorded in the log/report rather than allowing
unbounded memory growth.

## Admin v2 contract repair

Use `--playwright-flow path/to/admin-flow.json` with the independent Admin
Feature. The runner invokes the same compiler for source/evidence verification
and full steps/tables/order comparison before Cucumber. `--repair` can rebuild
an inconsistent Feature from the validated plan. Changed model-repair behavior
is rejected before replacing the target and rerunning it. User Ruby files are
read-only; a custom-step code exception is reported without patching its `.rb`.

See [Admin pipeline v2](Admin_GUI/Admin_Pipeline_V2.md) for the plan and evidence
protocol. Approve is only exercised by Feature; MCP's Reject is cleanup evidence.
A v1 flow, stale source or missing transcript is not authoritative. Admin v2 does
not launch automatic live replay from this runner. Repair is bounded to 2
attempts by default (1..5 allowed); unchanged output stops without rerunning.

## Batch conversion modes

The historical three positional arguments of `tools/batch_transform_tc.rb`
remain unchanged.  Execution is opt-in:

```bash
# Convert only (the default)
ruby tools/batch_transform_tc.rb EXCEL_DIR YAML_DIR FEATURE_DIR

# Convert, then run each unambiguously generated Feature
ruby tools/batch_transform_tc.rb EXCEL_DIR YAML_DIR FEATURE_DIR \
  --run-generated \
  --binary-debug \
  --run-report-dir outputs/feature-runs \
  --run-workdir /path/to/uat-checkout \
  --cucumber-command 'bundle exec cucumber'

# Convert, run, and diagnose failed generated Features with opencode
ruby tools/batch_transform_tc.rb EXCEL_DIR YAML_DIR FEATURE_DIR \
  --debug-generated \
  --model 'ollama/AE&I/Qwen3.8-27B' \
  --binary-debug \
  --run-report-dir outputs/feature-runs

# Convert, then repair every generated Feature until it passes
ruby tools/batch_transform_tc.rb EXCEL_DIR YAML_DIR FEATURE_DIR \
  --repair-generated \
  --run-workdir /path/to/uat-checkout \
  --cucumber-command 'cucumber' \
  --repair-attempts 2
```

For generation, place the no-value `--repair` after the three positional
directories as shown. `--repair-generated` is an unambiguous equivalent that
can appear anywhere in the command. It is different from `--repair FEATURE`,
which repairs one existing file and skips conversion. `--repair-generated`
already runs and diagnoses failures, so do not combine it with
`--debug-generated`.

For Admin/Hybrid cases, `--repair-generated` executes the batch stages in
`2 -> 3 -> 1 -> 4 -> 5 -> 6 -> 7` order. Step 1 reuses a verified Admin flow
or starts OpenCode with the installed Playwright MCP server to validate the
missing Admin path. A maker/checker validation submits the maker request and
Rejects it as cleanup; a no-countersign form Cancels before save. MCP never
executes Approve. Required approval is deferred to the generated Feature.
Playwright MCP is headed by default; set
`DISPLAY=:99` for the maintained VNC image or pass
`--playwright-mcp-headless`. A new flow is promoted to `safe_to_reuse=true`
only after the final Feature report passes. Generation, execution, repair, or
report validation failure leaves it quarantined as `observed`.

For a Web batch, `--playwright-flow` accepts one file, a directory containing
`<case>.json`, or a path template containing `{case}` or `{feature}`. When
conversion already selected an Admin flow manifest, that manifest is used as
the comparison reference automatically. Replaying that flow before or between
Feature repair attempts still needs a project-owned
`--playwright-replay-command`; this is independent of the integrated Step 1
missing-flow exploration.

`--binary-debug` only has an effect when a Feature is run.  It can also be
enabled for batch invocations with `FEATURE_BINARY_DEBUG=1`.  Category hints
can be forwarded with repeated `--error-category` options or a comma-separated
`FEATURE_ERROR_CATEGORIES` value.

Runtime data and structural checks are also forwarded by the batch entry
point: `--preflight-only`, `--data-preflight MODE`,
`--allow-unresolved-data`, and repeated `--cucumber-arg ARG`. Never use tag
selection to skip prerequisite steps inside one Scenario. Split truly
independent validation into tagged Scenarios first, then pass, for example,
`--cucumber-arg=--tags --cucumber-arg=@data-independent`.

The batch entry point accepts the same `--model provider/model` option and
`OPENCODE_MODEL` environment override. It forwards that choice to the
standalone runner used for generated Feature diagnosis or repair. Use
`--odp-doc-index PATH` or `ODP_DOC_INDEX` when the ODP specifications are
mounted outside the bundled `odp-docs/` directory.

`ADMIN_FLOW_DIR` supplies compiled v2 contracts. Only verified/safe_to_reuse
flows with matching source/compiler/transcript identity can execute. Observed,
unverified or v1 files cannot bypass this check.

The batch process snapshots the target directory before each conversion and
will run only a newly created Feature for assisted model transforms. A changed
old matching Feature is treated as stale and is not executed. The local
deterministic Admin converter may use its explicit output path when it is the
selected converter. If execution was requested but no new Feature can be
identified, the case is reported as `skipped` and the batch exits non-zero.
Review-tagged drafts remain blocked unless
`--allow-review` is supplied after the conversion report has been resolved.
`--run-generated` and `--debug-generated` remain single-shot. Only the
explicit `--repair`/`--repair-generated` mode may rerun a generated Feature;
it uses the same audited loop as an existing-Feature repair and stops as soon
as Cucumber passes. This opt-in matters because replaying a test can repeat an
order or Admin mutation.

The batch command returns non-zero when Excel-to-YAML conversion, Feature
generation, requested Feature execution, or generated-file discovery fails.
Commands and child output are redacted before they are printed.

For each conversion, use `odp-docs/INDEX.md` to identify the Functional
Specification that describes the case's business transition. Load only the
relevant restored document sections; do not turn specification prose into
synthetic Gherkin steps.

Batch conversion uses `OPENCODE_CONVERSION_COMMAND` (or
`--opencode-command`) with the safe default `opencode run --pure --thinking`.
`--auto` and `--dangerously-skip-permissions` are rejected. Conversion receives
only a small environment allowlist; provider-specific credentials must be
named explicitly in `OPENCODE_ENV_ALLOWLIST` after review. Set
`OPENCODE_MAX_OUTPUT_BYTES` to change the 8 MiB conversion-output bound. For
batch failure diagnosis, use `OPENCODE_DEBUG_CMD` or
`--diagnose-opencode-command`; it is forwarded to the standalone runner and is
separate from the conversion command.

## Edit then debug an existing Feature

After manually correcting a generated Feature, invoke the same batch entry
point without Excel/YAML processing:

```bash
ruby tools/batch_transform_tc.rb \
  --debug-feature features/test_case/CASE/case.feature \
  --binary-debug \
  --run-report-dir outputs/feature-runs \
  --run-workdir /path/to/uat-checkout \
  --cucumber-command 'bundle exec cucumber'
```

Use `--run-feature PATH` when a model diagnosis is not needed.  `--debug-feature`
and `--run-feature` are mutually exclusive.  For a dry syntax check, pass
`--dry-run` to `tools/run_feature_debug.rb`, or pass `--dry-run` to the batch
command so it is forwarded to the runner.

To repair an existing Feature through the batch entry point, use `--repair`:

```bash
ruby tools/batch_transform_tc.rb \
  --repair features/test_case/CASE/case.feature \
  --run-workdir /path/to/uat-checkout \
  --cucumber-command 'bundle exec cucumber' \
  --repair-attempts 2
```

This runs the Feature, asks opencode to edit only that path after a failure,
and reruns until it passes. Set `--repair-attempts N` to impose a finite
limit. `--repair` is mutually exclusive with `--debug-feature` and
`--run-feature`.

User-defined/special steps are a hard repair boundary. If Cucumber reports a
code exception such as `NoMethodError`, `NameError`, or `ArgumentError` from a
Ruby frame below `features/customized_steps/` or `features/step_definitions/`,
the runner classifies it as `custom_step_implementation`, records
`repair.stop_reason=custom_step_implementation`, and does not invoke automatic
repair. It never edits a user `.rb` file and must not change the Feature merely
to bypass a broken custom implementation. Correct that Ruby step manually,
then rerun the unchanged Feature.

Batch-created YAML, Features, reports, and logs are kept in a private `0700`
directory tree. The runner rejects report/log/diagnosis paths that alias the
input Feature or each other, including existing symlinks and hard links, and
uses no-follow file creation for sidecars.

## Binary/FIX debugging boundary

The runner is intentionally a separate script rather than another prompt in
the converter:

* conversion produces a deterministic artifact and report;
* execution can be repeated after a human edits that artifact;
* read-only diagnosis is only requested for an actual failure and cannot
  silently alter the Feature; repair is a separate explicit opt-in;
* the same contract works for Binary-only, Admin-only, and Hybrid Features.

Keeping this runner separate also makes the manual-edit workflow explicit:
generate once, edit the `.feature`, then invoke `--run-feature`,
`--debug-feature`, or the explicit `--repair` mode against that exact path.
`--debug-feature` is read-only; `--repair` is the only mode that can patch the
requested Feature, and it records a hash/path audit before rerunning.
Even in repair mode, the model works in an isolated tree where every path
except the staged `.feature` is read-only; only that Feature can be promoted
back to the runtime checkout.

Refresh the indexes before a large run or after source changes:

```bash
python3 tools/build_fix_message_index.py --input ../etc/FIXODPMSG.xml --transport ../etc/FIXODP.xml
python3 tools/build_error_code_index.py
python3 tools/build_grid_api_index.py --pages pageExplore/pages
python3 tools/build_step_index.py
python3 tools/build_pages_index.py
```

The local snapshot may not contain the target UAT checkout's Selenium,
`mechanize`, WABI gems, or service endpoints.  A successful wrapper smoke test
only proves command/report plumbing; Cucumber execution must still be run in
the configured runtime checkout.
