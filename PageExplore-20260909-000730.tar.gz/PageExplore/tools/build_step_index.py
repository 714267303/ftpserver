#!/usr/bin/env python3
"""Build a machine-readable index of the project's executable Gherkin steps.

The UAT checkout contains a concatenated ``uat_step.txt`` snapshot while the
runtime source lives in the project's ``features/customized_steps`` directory
and in installed gems.  This tool indexes definitions without importing or
executing Ruby.  It is deliberately conservative: the snapshot is evidence;
the runtime source (when available) is the executable authority.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
from collections import Counter, defaultdict
from pathlib import Path
from typing import Iterable


MARKER_RE = re.compile(r"^<FILE:(?P<path>[^>]+)>")
# UAT Ruby uses both ``Given(/.../) do`` and ``Given /.../ do``.  Keep the
# alternatives explicit so a regex containing ``(.*)`` is not truncated at
# its first closing parenthesis.
STEP_PAREN_RE = re.compile(
    r"^\s*(?P<keyword>Given|When|Then|And)\s*\(\s*(?P<pattern>.+)\s*\)\s*do"
    r"(?:\s*\|(?P<args>[^|]*)\|)?\s*$"
)
STEP_SLASH_RE = re.compile(
    r"^\s*(?P<keyword>Given|When|Then|And)\s+"
    r"(?P<pattern>/(?:\\.|[^/])*/)\s*do"
    r"(?:\s*\|(?P<args>[^|]*)\|)?\s*$"
)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source_kind(path: str) -> str:
    name = Path(path).name.lower()
    if "admin_gui" in name:
        return "admin_gui"
    if "trading_gui" in name:
        return "trading_gui"
    if "binary" in name or "wabi" in name:
        return "binary_or_core"
    if "public" in name:
        return "shared_public"
    if "simulator" in name:
        return "simulator"
    return "other"


def iter_lines(path: Path) -> Iterable[tuple[str, int, str]]:
    """Yield (logical source, line number, line) from a source or snapshot."""

    current = path.as_posix()
    for line_number, line in enumerate(
        path.read_text(encoding="utf-8", errors="replace").splitlines(), 1
    ):
        marker = MARKER_RE.match(line)
        if marker:
            current = marker.group("path").strip()
            continue
        yield current, line_number, line


def extract(path: Path) -> list[dict[str, object]]:
    definitions: list[dict[str, object]] = []
    preceding: list[str] = []
    for logical_source, line_number, line in iter_lines(path):
        stripped = line.strip()
        if stripped.startswith("#"):
            # Keep only the compact author examples; full Ruby comments add
            # noise and can contain credentials or case-specific data.
            if re.match(r"^#\s*\*", stripped):
                preceding.append(stripped[1:].strip())
            elif stripped in {"#", ""}:
                pass
            else:
                preceding = preceding[-3:]
            continue

        match = STEP_PAREN_RE.match(line) or STEP_SLASH_RE.match(line)
        if not match:
            if stripped:
                preceding = []
            continue

        args = [item.strip() for item in (match.group("args") or "").split(",") if item.strip()]
        pattern = match.group("pattern").strip()
        # Parenthesized definitions already omit the regex delimiters.  Strip
        # delimiters from slash-form definitions so equivalent signatures
        # deduplicate across the snapshot and runtime source.
        if pattern.startswith("/") and pattern.endswith("/"):
            pattern = pattern[1:-1]
        definitions.append(
            {
                "id": f"{logical_source}:{line_number}",
                "source": logical_source,
                "source_kind": source_kind(logical_source),
                "line": line_number,
                "keyword": match.group("keyword"),
                "pattern": pattern,
                "argument_count": len(args),
                "arguments": args,
                "examples": preceding[-3:],
                "authority": "snapshot_observed" if path.name == "uat_step.txt" else "runtime_source",
            }
        )
        preceding = []
    return definitions


def deduplicate(definitions: list[dict[str, object]]) -> list[dict[str, object]]:
    """Deduplicate identical signatures while retaining all evidence refs."""

    grouped: dict[tuple[str, str, int], list[dict[str, object]]] = defaultdict(list)
    for definition in definitions:
        key = (
            str(definition["keyword"]),
            str(definition["pattern"]),
            int(definition["argument_count"]),
        )
        grouped[key].append(definition)

    result: list[dict[str, object]] = []
    for (keyword, pattern, argument_count), matches in sorted(grouped.items()):
        first = dict(matches[0])
        first["signature"] = f"{keyword}({pattern})|args={argument_count}"
        first["evidence"] = [
            {"source": item["source"], "line": item["line"], "authority": item["authority"]}
            for item in matches
        ]
        first["evidence_count"] = len(matches)
        authorities = {str(item["authority"]) for item in matches}
        source_kinds = {str(item["source_kind"]) for item in matches}
        # A signature present in the live checkout is authoritative even when
        # the snapshot happened to be parsed first.
        first["authority"] = (
            "runtime_source" if "runtime_source" in authorities else "snapshot_observed"
        )
        first["authorities"] = sorted(authorities)
        first["source_kinds"] = sorted(source_kinds)
        first.pop("id", None)
        result.append(first)
    return result


def discover_runtime_sources(root: Path | None) -> list[Path]:
    """Return Ruby step-source files from a target checkout, if present."""

    if root is None or not root.is_dir():
        return []
    return sorted(
        path
        for path in root.rglob("*.rb")
        if path.is_file() and not path.name.endswith(".gemspec")
    )


def discover_external_runtime(runtime_glob: str) -> dict[str, object]:
    """Describe installed wabi-web candidates without importing Ruby code."""

    matches = sorted(Path(path) for path in Path('/').glob(runtime_glob.lstrip('/')))
    # Path.glob above is intentionally bounded by the supplied absolute
    # prefix.  Ignore files and cap the scan so a malformed glob cannot walk a
    # whole filesystem.
    matches = [path for path in matches if path.is_dir()][:20]
    candidates: list[dict[str, object]] = []
    for path in matches:
        ruby_files = list(path.rglob('*.rb'))[:5000]
        raw_steps = 0
        for ruby_file in ruby_files:
            try:
                raw_steps += len(extract(ruby_file))
            except (OSError, UnicodeError):
                continue
        candidates.append(
            {
                "path": path.as_posix(),
                "ruby_files": len(ruby_files),
                "step_definitions": raw_steps,
            }
        )
    return {
        "glob": runtime_glob,
        "status": "found" if candidates else "not_found",
        "matches": candidates,
        "authority": "external_runtime",
    }


def render_markdown(payload: dict[str, object]) -> str:
    lines = [
        "# UAT Step Index",
        "",
        "This file combines the Ruby step snapshot with any available target",
        "checkout sources.  It is a routing index, not an implementation copy.",
        "Runtime source and installed gem versions remain the executable authority.",
        "",
        "## Provenance",
        "",
        f"- Schema: `{payload['schema_version']}`",
        f"- Snapshot SHA-256: `{payload['snapshot_sha256']}`",
        f"- Unique signatures: `{payload['stats']['unique_signatures']}`",
        f"- Raw definitions: `{payload['stats']['raw_definitions']}`",
        f"- Runtime-source definitions: `{payload['stats'].get('runtime_definitions', 0)}`",
        f"- Runtime-source files: `{payload['stats'].get('runtime_files', 0)}`",
        "- External runtime: `/usr/local/share/gems/gems/wabi-web-*/` (optional; resolve at execution time)",
        "",
        "## External Runtime Resolution",
        "",
    ]
    runtime_source = payload.get("runtime_source", {})
    if runtime_source:
        lines.extend(
            [
                "## Target Checkout Resolution",
                "",
                f"- Root: `{runtime_source.get('root', '')}`",
                f"- Status: `{runtime_source.get('status', 'unknown')}`",
                f"- Files: `{len(runtime_source.get('files', []))}`",
                "",
            ]
        )
    runtime = payload.get("runtime_resolution", {})
    if runtime:
        lines.extend(
            [
                f"- Status: `{runtime.get('status', 'unknown')}`",
                f"- Glob: `{runtime.get('glob', '')}`",
                f"- Candidates: `{len(runtime.get('matches', []))}`",
                "",
            ]
        )
    lines.extend(
        [
        "## Related Snapshots",
        "",
        "These files are intentionally not merged into the executable step list:",
        "",
        "| File | Role | Authority |",
        "|---|---|---|",
        "| `uat/uat_tool.txt` | Batch/split orchestration snapshot | evidence only; inspect the live tool before execution |",
        "| `uat/uat_admin_feature.txt` | Real Feature-flow corpus | evidence; route through `Feature_Flow_Index.md` |",
        "| `pageExplore/evidence/page_explore.txt` | Playwright exploration guidance | evidence; use maintained sitemap/Grid guide |",
        "",
        "## Authority and Loading",
        "",
        "| Library | Source | Authority | Load rule |",
        "|---|---|---|---|",
        "| Admin custom steps | logical files `admin_gui_steps.rb`, `admin_gui_ws_class_steps.rb` inside the snapshot | target-checkout runtime authority; snapshot observed here | load for Admin/Hybrid |",
        "| Trading custom steps | logical file `trading_gui_steps.rb` inside the snapshot | target-checkout runtime authority; snapshot observed here | load for Trading/Hybrid |",
        "| Shared custom steps | logical files `public_steps.rb`, `public_class.rb` inside the snapshot | target-checkout runtime authority; snapshot observed here | load for all GUI channels |",
        "| Binary custom/core steps | logical `binary_steps.rb` + WABI runtime | target-checkout/runtime authority | load for Binary/Hybrid |",
        "| Snapshot | `uat/uat_step.txt` | observed evidence | use to discover candidates; verify against runtime |",
        "| Target checkout | `features/customized_steps/**/*.rb` | executable when present | preferred local authority; pass `--runtime-root` for another checkout |",
        "| wabi-web | `/usr/local/share/gems/gems/wabi-web-*/` | external runtime | inspect installed version at run time; never guess API |",
        "",
        "## Signature Counts",
        "",
        "| Source kind | Definitions | Unique signatures |",
        "|---|---:|---:|",
        ]
    )
    for kind, counts in sorted(payload["stats"]["by_source_kind"].items()):
        lines.append(f"| `{kind}` | {counts['raw']} | {counts['unique']} |")

    lines.extend(
        [
            "",
            "## High-Value Admin Vocabulary",
            "",
            "These signatures are the preferred targets for the Admin converter.",
            "The complete machine-readable list is in `Step_Index.json`.",
            "",
            "| Intent | Signature fragment |",
            "|---|---|",
            '| login | `Login Trading Admin with:` |',
            '| navigation | `Select Trading Admin Left Menu "..."` |',
            '| search | `Search in Trading Admin "..." page with:` |',
            '| form | `Set Trading Admin "..." info as:` |',
            '| detail | `Double click table "..." column "..." with:` |',
            '| table assertion | `Check table "..." contains ...` |',
            '| sub-table add | `Add Table Item in "..." info popup page with:` |',
            '| sub-table update | `Modify Table Item in "..." info popup page with:` |',
            '| effective type | `Select effective type "..." in detail info page ...` |',
            '| countersign | `Click button "Approve|Reject" ...` |',
            '| WebSocket setup | `CONNECT WS with:` / `add new ... with user ...` |',
            "",
            "## Converter Policy",
            "",
            "1. Select the runtime channel (`admin`, `binary`, or `hybrid`) before loading steps.",
            "2. Match an emitted line to an exact signature in this index or the selected runtime library.",
            "3. Treat `snapshot_observed` and inferred mappings as draft-only; add `@REVIEW` until replayed.",
            "4. Do not emit raw JavaScript or a raw Playwright locator as a Feature step.",
            "5. Preserve unknown actions in a review report rather than silently dropping them.",
            "",
            "## Machine-Readable Source",
            "",
            "`Step_Index.json` contains every normalized signature, argument count, source line, and evidence reference.",
            "",
        ]
    )
    return "\n".join(lines)


def build(
    input_path: Path,
    runtime_glob: str = "/usr/local/share/gems/gems/wabi-web-*",
    runtime_root: Path | None = Path("features/customized_steps"),
) -> dict[str, object]:
    snapshot_definitions = extract(input_path)
    runtime_paths = discover_runtime_sources(runtime_root)
    runtime_definitions = [
        definition
        for path in runtime_paths
        for definition in extract(path)
    ]
    # Keep snapshot evidence even when a checkout is incomplete.  deduplicate
    # promotes matching signatures to runtime authority when source exists.
    external_path = Path(__file__).resolve().parent.parent / 'odpt-automation-skill/external_step_signatures.json'
    external_definitions = json.loads(external_path.read_text(encoding='utf-8'))['steps'] if external_path.is_file() else []
    definitions = snapshot_definitions + external_definitions + runtime_definitions
    unique = deduplicate(definitions)
    raw_by_kind = Counter(str(item["source_kind"]) for item in definitions)
    unique_by_kind = Counter(str(item["source_kind"]) for item in unique)
    by_kind = {
        kind: {"raw": raw_by_kind[kind], "unique": unique_by_kind[kind]}
        for kind in sorted(set(raw_by_kind) | set(unique_by_kind))
    }
    return {
        "schema_version": 1,
        "source_snapshot": input_path.as_posix(),
        "snapshot_sha256": sha256(input_path),
        "stats": {
            "raw_definitions": len(definitions),
            "snapshot_definitions": len(snapshot_definitions),
            "runtime_definitions": len(runtime_definitions),
            "runtime_files": len(runtime_paths),
            "unique_signatures": len(unique),
            "by_source_kind": by_kind,
        },
        "runtime_source": {
            "root": runtime_root.as_posix() if runtime_root else "",
            "status": "found" if runtime_paths else "not_found",
            "files": [path.as_posix() for path in runtime_paths],
            "authority": "runtime_source",
        },
        "external_libraries": [
            {
                "library_id": "wabi-web",
                "runtime": "ruby-cucumber-gui",
                "path_glob": "/usr/local/share/gems/gems/wabi-web-*",
                "authority": "external_runtime",
                "resolution": "inspect installed gem at execution time; unresolved is a visible warning",
            }
        ],
        "runtime_resolution": discover_external_runtime(runtime_glob),
        "related_artifacts": [
            {
                "path": "uat/uat_tool.txt",
                "role": "orchestration_snapshot",
                "authority": "observed evidence; not a step implementation",
            },
            {
                "path": "uat/uat_admin_feature.txt",
                "role": "feature_flow_corpus",
                "authority": "observed examples; use Feature_Flow_Index for routing",
            },
            {
                "path": "pageExplore/evidence/page_explore.txt",
                "role": "exploration_guidance_snapshot",
                "authority": "observed guidance; sitemap and Grid guide are maintained references",
            },
        ],
        "steps": unique,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", default="uat/uat_step.txt")
    parser.add_argument("--json-output", default="odpt-automation-skill/Step_Index.json")
    parser.add_argument("--markdown-output", default="odpt-automation-skill/Step_Index.md")
    parser.add_argument(
        "--runtime-glob",
        default="/usr/local/share/gems/gems/wabi-web-*",
        help="installed wabi-web glob to inspect (does not import or execute Ruby)",
    )
    parser.add_argument(
        "--runtime-root",
        default="features/customized_steps",
        help="target checkout Ruby step directory (use an absolute path for the internal checkout)",
    )
    parser.add_argument(
        "--no-runtime-source",
        action="store_true",
        help="index only the snapshot; useful for comparing historical evidence",
    )
    args = parser.parse_args()

    source = Path(args.input)
    if not source.is_file():
        parser.error(f"input does not exist: {source}")
    runtime_root = None if args.no_runtime_source else Path(args.runtime_root)
    payload = build(source, args.runtime_glob, runtime_root)
    json_path = Path(args.json_output)
    markdown_path = Path(args.markdown_output)
    json_path.parent.mkdir(parents=True, exist_ok=True)
    markdown_path.parent.mkdir(parents=True, exist_ok=True)
    json_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    markdown_path.write_text(render_markdown(payload), encoding="utf-8")
    print(f"JSON index written: {json_path}")
    print(f"Markdown index written: {markdown_path}")
    print(f"Raw definitions: {payload['stats']['raw_definitions']}")
    print(f"Unique signatures: {payload['stats']['unique_signatures']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
