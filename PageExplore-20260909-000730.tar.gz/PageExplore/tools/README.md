# Tools

The entry points are in this directory; implementation modules are grouped by
function. Admin v2 does not accept old flow or converter formats.

| Component | Responsibility |
|---|---|
| `batch_transform_tc.rb` | Batch CLI and options |
| `lib/case_source.rb` | One safe, structural YAML reader |
| `lib/batch_transform/` | Conversion, browser orchestration, Feature stages and execution flow |
| `admin_flow/source.py` | Data selectors and bindings |
| `admin_flow/operations.py` | Maintained business operation → UAT adapters |
| `admin_flow/compiler.py` | Plan validation, state continuity, hashes and deterministic generation |
| `admin_flow/evidence.py` | Completed MCP output, sessions, submission and cleanup verification |
| `admin_flow/runtime.py` | Step_Index matching and exact Feature comparison |
| `admin_feature_converter.py` | Compiler/evidence CLI |
| `admin_page_contract.py` | PageExplore routes, menus, fields and page contracts |
| `lib/admin_contract.rb` | Runner boundary to the same compiler |
| `lib/private_transcript.rb` | Incremental redacted evidence persistence |
| `run_feature_debug.rb` | Isolated execution/diagnosis and bounded Feature repair |
| `build_*.py` | Generated indexes |
| `split_tc_excel.rb` | Source workbook splitting |
| `summarize_opencode_events.rb` | Redacted event statistics |

Read [Admin pipeline v2](../odpt-automation-skill/Admin_GUI/Admin_Pipeline_V2.md)
for contracts and artifacts. `--admin-handoff-run RUN_DIR` finalizes the existing
v2 plan and browser evidence without rerunning Excel conversion or MCP.

Run local tests (no real model, website or orders):

```bash
python3 -m unittest discover -s tools -p 'test_*.py'
```
