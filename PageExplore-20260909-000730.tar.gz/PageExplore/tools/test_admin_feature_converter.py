"""Contract boundaries for v2 compilation, data and browser evidence."""
import copy
import json
import tempfile
import unittest
from pathlib import Path
from admin_test_support import fixture, compile_fixture, verified_fixture, evidence_events, transcript, INDEX, PAGES
from admin_flow.common import FlowError
from admin_flow.compiler import compile_plan, render, compare, recompile
from admin_flow.evidence import validate_evidence, verify_saved_evidence, browser_records
from admin_flow.source import read_case

class CompilerTest(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.root=Path(self.tmp.name)
        self.source,_,self.plan=fixture(self.root)
    def tearDown(self): self.tmp.cleanup()
    def compile(self): return compile_plan(self.plan,read_case(self.source),INDEX,PAGES)
    def test_complete_feature_correct_menu_approval_and_sessions(self):
        flow=self.compile(); text=render(flow)
        self.assertIn('"SMP>Maintain SMP ID"',text)
        self.assertEqual(1,text.count('* Approve if updated with :'))
        self.assertEqual(2,text.count('* Open browser'))
        self.assertNotIn('Reject',text)
        self.assertTrue(compare(flow,text)['aligned'])
    def test_yaml_key_order_and_changed_data(self):
        old=self.compile()
        self.source.write_text(self.source.read_text().replace('210010011','220020022'))
        self.assertIn('220020022',render(self.compile()))
        with self.assertRaisesRegex(FlowError,'changed'): recompile(old,INDEX,PAGES)
    def test_invalid_plan_boundaries(self):
        original=copy.deepcopy(self.plan)
        changes=[
            ('literal',lambda p:p['actions'][4]['args']['fields'].update({'Cancellation Method':'CP'})),
            ('alias',lambda p:p['parameters'].update(record={'origin':'yaml','step':1,'text':'TEST1'})),
            ('navigation',lambda p:p['actions'].pop(0)),
            ('detail',lambda p:p['actions'][4].update(subject={'SMP ID':{'param':'method'}})),
            ('approval_only',lambda p:p.update(actions=[p['actions'][8]])),
            ('postcheck',lambda p:p['actions'].pop()),
            ('checker',lambda p:p['sessions']['checker'].update(user={'param':'maker_user'})),
            ('version',lambda p:p.update(schema_version=1)),
            ('operation',lambda p:p['actions'][0].update(operation='raw_gherkin')),
        ]
        for name,change in changes:
            with self.subTest(name=name):
                self.plan=copy.deepcopy(original); change(self.plan)
                with self.assertRaises(FlowError): self.compile()
    def test_multiple_routes_in_one_source_step(self):
        action=copy.deepcopy(self.plan['actions'][0]); action.update(id='list',page='/UI/uiSmpIdListSearchTable')
        self.plan['actions'].insert(0,action)
        flow=self.compile(); self.assertEqual(2,len(flow['pages']))
        self.assertIn('Participant>Maintain SMP ID List',render(flow))
    def test_observation_binding(self):
        self.plan['parameters']['record']={'origin':'observation'}
        with self.assertRaises(FlowError): self.compile()
        flow=compile_plan(self.plan,read_case(self.source),INDEX,PAGES,{'record':'345678900'})
        self.assertIn('345678900',render(flow))
    def test_exact_feature_comparison(self):
        flow=self.compile(); text=render(flow)
        for changed in [text.replace('210010011','210010012'),text+'        * Clear Alert If Exist\n',
                        text+'        """\n        hidden data\n        """\n',
                        text.replace('Scenario:','Scenario Outline:'),text.replace('@FEATURE=AdminGUI','@FEATURE=AdminGUI @skip')]:
            with self.subTest(change=changed[-40:]): self.assertFalse(compare(flow,changed)['aligned'])
    def test_escaped_values_round_trip(self):
        flow=self.compile(); flow['steps'][6]['table'][1][0]='test|with\\slash'
        self.assertTrue(compare(flow,render(flow))['aligned'])
    def test_compiled_action_tampering(self):
        flow=self.compile(); flow['actions'][4]['args']['fields']['Cancellation Method']='CA'
        with self.assertRaisesRegex(FlowError,'edited'): recompile(flow,INDEX,PAGES)
    def test_read_only_flow_needs_no_checker_or_cleanup(self):
        self.source.write_text(self.source.read_text().replace('Maker update cancellation method, checker approve then verify.','Search and verify current record.'))
        verify=copy.deepcopy(self.plan['actions'][-1]); verify['phase']='shared'
        self.plan['actions']=self.plan['actions'][:2]+[verify]
        self.plan['cleanup']={'action':'none'}
        flow=self.compile()
        self.assertNotIn('Approve',render(flow)); self.assertEqual(1,render(flow).count('* Open browser'))
        events=[e for e in evidence_events(flow) if e['operation']=='session' and e['session']=='maker' or e.get('action_id')]
        report={'schema_version':2,'kind':'admin_exploration','case_id':flow['case_id'],'status':'passed'}
        self.assertTrue(validate_evidence(flow,transcript(self.root,events),report)['cleanup_completed'])
    def test_non_countersign_cancel_then_feature_commit(self):
        self.source.write_text(self.source.read_text().replace('Maker update cancellation method, checker approve then verify.','Update cancellation method, save and verify.'))
        commit=copy.deepcopy(self.plan['actions'][5]); commit.update(id='commit',operation='commit',phase='feature')
        verify=copy.deepcopy(self.plan['actions'][-1]); verify.update(operation='verify_fields')
        self.plan['actions']=self.plan['actions'][:5]+[commit,verify]
        self.plan['cleanup']={'action':'cancel','session':'maker'}
        flow=self.compile(); self.assertNotIn('Approve',render(flow))
        events=[e for e in evidence_events(flow) if not(e['operation']=='session' and e['session']=='checker')]
        for e in events:
            if e['operation']=='reject': e.update(operation='cancel',session='maker')
        report={'schema_version':2,'kind':'admin_exploration','case_id':flow['case_id'],'status':'passed'}
        self.assertTrue(validate_evidence(flow,transcript(self.root,events),report)['final_state_restored'])
    def test_expected_result_values_are_assertion_only(self):
        self.plan['parameters']['status']={'origin':'yaml','step':1,'field':'expected','text':'Active'}
        self.compile()
        self.plan['actions'][4]['args']['fields']['Status']={'param':'status'}
        with self.assertRaisesRegex(FlowError,'only for assertions'): self.compile()

class EvidenceTest(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.root=Path(self.tmp.name)
        self.flow=compile_fixture(self.root); self.events=evidence_events(self.flow)
        self.report={'schema_version':2,'kind':'admin_exploration','case_id':self.flow['case_id'],'status':'passed'}
    def tearDown(self): self.tmp.cleanup()
    def validate(self): return validate_evidence(self.flow,transcript(self.root,self.events),self.report)
    def test_successful_rollback(self): self.assertTrue(self.validate()['final_state_restored'])
    def test_input_and_failed_calls_are_not_evidence(self):
        for mode in ('input','failed'):
            with self.subTest(mode=mode):
                path=transcript(self.root,self.events)
                data=[json.loads(l) for l in path.read_text().splitlines()]
                for e in data:
                    s=e['part']['state']
                    if mode=='input': s['input']={'code':'if(false) '+s.pop('output')}
                    else: s['status']='error'
                path.write_text('\n'.join(json.dumps(e) for e in data))
                with self.assertRaises(FlowError): validate_evidence(self.flow,path,self.report)
    def test_missing_checker_session(self):
        self.events=[e for e in self.events if not(e['operation']=='session' and e['session']=='checker')]
        with self.assertRaisesRegex(FlowError,'authenticated'): self.validate()
    def test_wrong_cleanup_request(self):
        next(e for e in self.events if e['operation']=='reject')['observed']['request_id']='preexisting'
        with self.assertRaisesRegex(FlowError,'request created'): self.validate()
    def test_wrong_order(self):
        self.events[1],self.events[2]=self.events[2],self.events[1]
        with self.assertRaisesRegex(FlowError,'order'): self.validate()
    def test_approval_rejected(self):
        self.events[-2]['operation']='approve'
        with self.assertRaisesRegex(FlowError,'Approve'): self.validate()
    def test_incomplete_restore(self):
        self.events[-1]['observed']['fields']['Cancellation Method']='CP'
        with self.assertRaisesRegex(FlowError,'restored'): self.validate()
    def test_old_source(self):
        self.events[1]['source_sha256']='old'
        with self.assertRaisesRegex(FlowError,'different plan'): self.validate()
    def test_json_string_wrapped_tool_result(self):
        path=transcript(self.root,self.events)
        data=[json.loads(l) for l in path.read_text().splitlines()]
        for e in data:
            s=e['part']['state'];s['output']='### Result\n'+json.dumps(s['output'])+'\n### Ran code\n'
        path.write_text('\n'.join(json.dumps(e) for e in data))
        self.assertEqual(len(self.events),len(browser_records(path)))
    def test_saved_evidence_binds_transcript(self):
        flow,_=verified_fixture(self.root)
        Path(flow['evidence']['transcript']).write_text('{}\n')
        with self.assertRaisesRegex(FlowError,'changed'): verify_saved_evidence(flow)
    def test_tool_code_echo_is_not_browser_execution_evidence(self):
        path=transcript(self.root,self.events)
        data=[json.loads(l) for l in path.read_text().splitlines()]
        for e in data:
            state=e['part']['state']
            state['output']='### Result\nnull\n### Ran Playwright code\n```js\n'+state['output']+'\n```'
        path.write_text('\n'.join(json.dumps(e) for e in data))
        with self.assertRaisesRegex(FlowError,'no structured'):validate_evidence(self.flow,path,self.report)
    def test_plain_cli_warning_is_not_a_malformed_tool_event(self):
        path=transcript(self.root,self.events)
        path.write_text('WARNING optional CLI setting\n'+path.read_text())
        self.assertTrue(validate_evidence(self.flow,path,self.report)['final_state_restored'])
        path.write_text(path.read_text()+'{"part":')
        with self.assertRaisesRegex(FlowError,'malformed'):validate_evidence(self.flow,path,self.report)

if __name__=='__main__': unittest.main()
