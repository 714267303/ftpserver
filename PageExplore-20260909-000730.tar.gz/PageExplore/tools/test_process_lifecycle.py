"""Time limits, incremental capture and byte-boundary redaction."""
import json
import subprocess
import tempfile
import unittest
from pathlib import Path
from admin_flow.common import ROOT

class ProcessLifecycleTest(unittest.TestCase):
    def test_transcript_keeps_unicode_and_redacts_split_secrets(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'events.jsonl'
            script=r'''
require 'json'; require 'fileutils'
require ARGV.shift
require ARGV.shift
BATCH_REDACTION_VALUES = ['private-secret']
class Capture
 include BatchTransform::Core
 def write(path)
  writer=PrivateTranscript.new(path) { |line| redact_batch(line) }
  payload=JSON.generate({'message'=>'中文字段 private-secret'})+"\n"
  payload.b.bytes.each { |byte| writer.append(byte.chr) }
  # Complete lines must already be durable before close.
  raise 'not incremental' if File.size(path).zero?
  writer.close
 end
end
Capture.new.write(ARGV.shift)
'''
            run=subprocess.run(['ruby','-e',script,str(ROOT/'tools/lib/batch_transform/core.rb'),
                str(ROOT/'tools/lib/private_transcript.rb'),str(path)],text=True,capture_output=True,timeout=10)
            self.assertEqual(0,run.returncode,run.stderr)
            self.assertEqual('中文字段 <redacted>',json.loads(path.read_text())['message'])
            self.assertEqual(0o600,path.stat().st_mode & 0o777)
    def test_total_timeout_stops_a_chatty_process_without_retry(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); child=root/'child.rb'
            child.write_text('$stdout.sync=true\nloop { puts "{}"; sleep 0.03 }\n')
            script=r'''
require 'json'; require 'fileutils'; require 'shellwords'; require 'open3'
require ARGV.shift
BATCH_REDACTION_VALUES=[]
GREEN=RESET=CYAN=YELLOW=RED=''
VERBOSE_MODEL_OUTPUT=false
MAX_RETRIES=0
MAX_CAPTURE_BYTES=128
TIMEOUT_SECONDS=30
MODEL_PROGRESS_INTERVAL=15
class Runner
 include BatchTransform::Core
 def run(child,path)
  result=run_opencode('test',Shellwords.join(['ruby',child]), retry_on_hang:false,
    timeout_seconds:30,total_timeout_seconds:1,capture_path:path)
  puts JSON.generate(result.reject { |key,_| key==:output })
 end
end
Runner.new.run(ARGV.shift,ARGV.shift)
'''
            run=subprocess.run(['ruby','-e',script,str(ROOT/'tools/lib/batch_transform/core.rb'),str(child),str(root/'events')],
                text=True,capture_output=True,timeout=10)
            self.assertEqual(0,run.returncode,run.stderr)
            result=json.loads(run.stdout.splitlines()[-1])
            self.assertNotEqual(0,result['exit_code']); self.assertLess(result['elapsed'],6)
            self.assertNotIn('Attempt 2',run.stdout)

if __name__=='__main__':unittest.main()
