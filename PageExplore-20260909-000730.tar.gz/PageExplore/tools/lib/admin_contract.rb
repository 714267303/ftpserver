# frozen_string_literal: true

require 'json'
require 'open3'
require 'tempfile'

# Every Admin execution uses the same compiler that generated the Feature.
module AdminContract
  ROOT = File.expand_path('../..', __dir__)
  def self.check(flow_path, feature_path = nil, step_index: nil)
    args = [ENV.fetch('PYTHON', 'python3'), File.join(ROOT, 'tools/admin_feature_converter.py'),
            '--flow', File.expand_path(flow_path), '--require-evidence']
    args += ['--step-index', step_index] if step_index
    args += ['--page-explore-root', ENV['PAGEEXPLORE_ROOT']] if ENV['PAGEEXPLORE_ROOT']
    args += feature_path ? ['--verify-feature', File.expand_path(feature_path)] : ['--validate-only']
    stdout, stderr, status = Open3.capture3(*args)
    result = JSON.parse(stdout.lines.last.to_s) rescue {}
    result.merge('aligned' => status.success?, 'status' => status.success? ? 'aligned' : 'diverged',
                 'reason' => status.success? ? nil : (stderr.empty? ? stdout : stderr).strip)
  rescue StandardError => e
    {'aligned'=>false, 'status'=>'diverged', 'reason'=>e.message}
  end

  def self.compare(payload, text)
    Tempfile.create(['admin-contract-', '.json']) do |flow|
      flow.write(JSON.generate(payload)); flow.flush
      Tempfile.create(['admin-contract-', '.feature']) do |feature|
        feature.write(text); feature.flush
        check(flow.path, feature.path)
      end
    end
  end

  def self.render(flow_path, feature_path)
    args = [ENV.fetch('PYTHON', 'python3'), File.join(ROOT, 'tools/admin_feature_converter.py'),
            '--flow', File.expand_path(flow_path), '--output', File.expand_path(feature_path)]
    args += ['--page-explore-root', ENV['PAGEEXPLORE_ROOT']] if ENV['PAGEEXPLORE_ROOT']
    stdout, stderr, status = Open3.capture3(*args)
    raise stderr unless status.success?
    stdout
  end
end
