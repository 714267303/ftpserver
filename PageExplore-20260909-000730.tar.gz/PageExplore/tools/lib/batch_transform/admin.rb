# frozen_string_literal: true

module BatchTransform
  module Admin
    # ---------------------------------------------------------------------------
    # Admin exploration orchestration
    #
    # A conversion-only invocation must remain deterministic and side-effect free.
    # The explicit generation/repair path, however, can validate a missing Admin
    # setup through Playwright MCP. For a maker/checker workflow, browser
    # exploration submits the maker request, validates the countersign path, and
    # rejects that request as cleanup. The final approval remains a semantic step
    # deferred to the generated Feature. For a flow without countersign, MCP must
    # cancel before a persistent save. Python compiles a business plan before
    # browser execution and verifies tool-output evidence afterward. Ruby owns
    # orchestration, process permissions and promotion, never semantic inference.

    ADMIN_APPROVAL_REQUEST_PATTERN = /\b(?:approv(?:e(?:s|d|r)?|ing|al)|countersign)\b|maker[- ]checker/i

    ODP_MAKER_USERNAME_KEYS = %w[SECRET_ODP_USERNAME ODP_USERNAME].freeze
    ODP_MAKER_PASSWORD_KEYS = %w[SECRET_ODP_PASSWORD ODP_PASSWORD].freeze
    ODP_CHECKER_USERNAME_KEYS = %w[SECRET_ODP_CHECKER_USERNAME ODP_CHECKER_USERNAME].freeze
    ODP_CHECKER_PASSWORD_KEYS = %w[SECRET_ODP_CHECKER_PASSWORD ODP_CHECKER_PASSWORD].freeze
  end
end

require_relative "admin/configuration"
require_relative "admin/prompt"
require_relative "admin/contracts"
require_relative "admin/exploration"
