# frozen_string_literal: true

# Ordered hybrid execution-flow manifests, gates, and direct-run modes.

module BatchTransform
  module ExecutionFlow
    private

    EXECUTION_FLOW_SCHEMA_VERSION = 2

    def execution_identity(stage, feature_path)
      identity = {'feature_sha256'=>Digest::SHA256.file(feature_path).hexdigest}
      if stage['semantic_flow']
        flow = json_object_at(stage['semantic_flow'], 'Admin flow')
        identity['admin_contract_sha256'] = flow.fetch('contract_sha256')
      end
      identity
    end

    def bind_execution_report(record, stage, feature_path, validation: false)
      report = json_object_at(record['report'], 'stage execution report')
      raise 'stage report has a different Feature path or content' unless
        File.expand_path(report.dig('feature','path').to_s) == File.expand_path(feature_path) &&
        report.dig('feature','sha256') == Digest::SHA256.file(feature_path).hexdigest
      expected = validation ? %w[passed preflight_only] : ['passed']
      raise 'stage report does not prove success' unless expected.include?(report.dig('execution','status'))
      unless validation
        counts = report.dig('execution','cucumber_summary') || {}
        raise 'stage report has no completed steps' unless counts['total'].to_i.positive? && counts['total'] == counts['passed'] &&
          %w[failed skipped pending undefined].all? { |k| counts[k].to_i.zero? }
        raise 'dry-run is not execution' if Array(report.dig('execution','command')).include?('--dry-run')
      end
      record.merge!(execution_identity(stage, feature_path))
      record['report_sha256'] = Digest::SHA256.file(record['report']).hexdigest
    end

    def execution_flow_output_path(base_name)
      File.join(expanded_path(TARGET_DIR), "#{base_name}.execution-flow.json")
    end

    def execution_stage_state(status = 'pending')
      { 'status' => status }
    end

    def build_hybrid_execution_flow(yaml_path:, base_name:, admin_feature_path:, admin_flow_path:,
                                    non_admin_feature_paths:, lifecycle:, admin_run_result: nil,
                                    admin_run_summary: {}, admin_run_report_path: nil)
      case_id = primary_yaml_identifier(yaml_path)
      stages = [
        {
          'order' => 1,
          'id' => 'admin',
          'kind' => 'feature',
          'feature' => File.basename(admin_feature_path),
          'semantic_flow' => File.expand_path(admin_flow_path),
          'requires' => []
        }
      ]
      if lifecycle[:cross_day]
        stages.concat(
          [
            {
              'order' => 2,
              'id' => 'day1',
              'kind' => 'feature',
              'feature' => File.basename(non_admin_feature_paths.fetch(0)),
              'requires' => ['admin']
            },
            {
              'order' => 3,
              'id' => 'night_batch',
              'kind' => 'external_gate',
              'action' => 'advance_to_next_business_day',
              'completion_condition' => 'night batch completed and market status is OPEN',
              'acknowledgement_required' => true,
              'requires' => ['day1']
            },
            {
              'order' => 4,
              'id' => 'day2',
              'kind' => 'feature',
              'feature' => File.basename(non_admin_feature_paths.fetch(1)),
              'requires' => ['night_batch']
            }
          ]
        )
      else
        stages << {
          'order' => 2,
          'id' => 'continuation',
          'kind' => 'feature',
          'feature' => File.basename(non_admin_feature_paths.fetch(0)),
          'requires' => ['admin']
        }
      end

      actual_admin_passed = RUN_GENERATED && !FEATURE_DRY_RUN && !PREFLIGHT_ONLY &&
                            admin_run_result && admin_run_result[:exit_code].to_i.zero? &&
                            admin_run_summary['status'].to_s != 'preflight_only'
      validation_admin_passed = RUN_GENERATED && (FEATURE_DRY_RUN || PREFLIGHT_ONLY) &&
                                admin_run_result && admin_run_result[:exit_code].to_i.zero?
      execution_stages = stages.to_h { |stage| [stage['id'], execution_stage_state] }
      validation_stages = stages.to_h { |stage| [stage['id'], execution_stage_state('not_run')] }
      if actual_admin_passed
        execution_stages['admin'] = execution_stage_state('passed')
        execution_stages['admin']['report'] = File.expand_path(admin_run_report_path) if admin_run_report_path
      elsif validation_admin_passed
        validation_stages['admin'] = execution_stage_state('passed')
        validation_stages['admin']['report'] = File.expand_path(admin_run_report_path) if admin_run_report_path
      end

      payload = {
        'schema_version' => EXECUTION_FLOW_SCHEMA_VERSION,
        'flow_id' => "#{case_id}.execution.v2",
        'case_id' => case_id,
        'channel' => 'hybrid',
        'source_yaml' => File.expand_path(yaml_path),
        'source_sha256' => Digest::SHA256.file(yaml_path).hexdigest,
        'lifecycle' => lifecycle[:kind],
        'stages' => stages,
        'execution' => {
          'status' => 'pending',
          'waiting_for' => nil,
          'stages' => execution_stages
        },
        'validation' => {
          'status' => validation_admin_passed ? 'in_progress' : 'not_run',
          'stages' => validation_stages
        }
      }
      path = execution_flow_output_path(base_name)
      stages.select { |s| s['kind'] == 'feature' }.each do |stage|
        feature_path = File.expand_path(stage['feature'], File.dirname(path))
        stage.merge!(execution_identity(stage, feature_path))
      end
      if actual_admin_passed || validation_admin_passed
        record = (actual_admin_passed ? execution_stages : validation_stages)['admin']
        bind_execution_report(record, stages.first, admin_feature_path, validation: validation_admin_passed)
      end
      payload['definition_sha256'] = Digest::SHA256.hexdigest(JSON.generate(stages))
      write_json_atomic(path, payload)
      path
    end

    def load_execution_flow(path)
      absolute = File.expand_path(path)
      raise "execution flow does not exist: #{absolute}" unless File.file?(absolute) && !File.symlink?(absolute)

      payload = JSON.parse(File.read(absolute, encoding: 'UTF-8'))
      raise 'execution flow must contain a JSON object' unless payload.is_a?(Hash)
      unless payload['schema_version'] == EXECUTION_FLOW_SCHEMA_VERSION
        raise "unsupported execution-flow schema_version: #{payload['schema_version'].inspect}"
      end
      stages = payload['stages']
      raise 'execution flow stages must be a non-empty array' unless stages.is_a?(Array) && !stages.empty?
      raise 'execution-flow stage definitions changed' unless payload['definition_sha256'] == Digest::SHA256.hexdigest(JSON.generate(stages))
      raise 'execution-flow source YAML changed or is missing' unless File.file?(payload['source_yaml'].to_s) &&
        payload['source_sha256'] == Digest::SHA256.file(payload['source_yaml']).hexdigest

      ids = []
      stages.each_with_index do |stage, index|
        raise "execution flow stage #{index + 1} must be an object" unless stage.is_a?(Hash)
        expected_order = index + 1
        raise "execution flow stage order must be contiguous from 1" unless stage['order'] == expected_order
        id = stage['id'].to_s
        raise "execution flow stage #{expected_order} has an invalid id" unless id.match?(/\A[A-Za-z0-9][A-Za-z0-9_-]*\z/)
        raise "execution flow contains duplicate stage id #{id}" if ids.include?(id)
        kind = stage['kind'].to_s
        raise "execution flow stage #{id} has unsupported kind #{kind.inspect}" unless %w[feature external_gate].include?(kind)
        if kind == 'feature' && !stage['feature'].to_s.end_with?('.feature')
          raise "execution flow feature stage #{id} has no .feature path"
        end
        Array(stage['requires']).each do |dependency|
          raise "execution flow stage #{id} depends on a later or unknown stage #{dependency}" unless ids.include?(dependency.to_s)
        end
        ids << id
      end
      [absolute, payload]
    end

    def execution_flow_feature_path(flow_path, stage)
      root = File.dirname(flow_path)
      reference = stage['feature'].to_s
      candidate = File.expand_path(reference, root)
      unless path_within?(candidate, root)
        raise "execution flow feature escapes its directory: #{reference}"
      end
      unless File.file?(candidate) && !File.symlink?(candidate)
        raise "execution flow feature is missing or unsafe: #{candidate}"
      end
      candidate
    end

    def execution_flow_state(payload, validation: false)
      key = validation ? 'validation' : 'execution'
      payload[key] = {} unless payload[key].is_a?(Hash)
      payload[key]['stages'] = {} unless payload[key]['stages'].is_a?(Hash)
      payload['stages'].each do |stage|
        payload[key]['stages'][stage['id']] ||= execution_stage_state(validation ? 'not_run' : 'pending')
      end
      payload[key]
    end

    def execution_dependency_complete?(record, dependency_stage)
      return true if record.is_a?(Hash) && record['status'].to_s == 'not_required_for_validation'

      expected = dependency_stage['kind'] == 'external_gate' ? 'completed' : 'passed'
      record.is_a?(Hash) && record['status'].to_s == expected
    end

    def execute_feature_flow(flow_path, completed_gates: [], validation_only: false)
      absolute, payload = load_execution_flow(flow_path)
      stages = payload.fetch('stages')
      gate_ids = stages.select { |stage| stage['kind'] == 'external_gate' }.map { |stage| stage['id'] }
      unknown_gates = completed_gates - gate_ids
      raise "unknown execution-flow gate(s): #{unknown_gates.join(', ')}" unless unknown_gates.empty?

      state = execution_flow_state(payload, validation: validation_only)
      # Validate artifacts even for completed stages before deciding to skip them.
      stages.select { |s| s['kind'] == 'feature' }.each do |stage|
        feature_path = execution_flow_feature_path(absolute, stage)
        identity = execution_identity(stage, feature_path)
        raise "stage #{stage['id']} Feature or Admin contract changed" unless identity.all? { |k,v| stage[k] == v }
        if stage['semantic_flow']
          checked = validate_admin_feature_consistency(stage['semantic_flow'], feature_path)
          raise checked[:reason] unless checked[:ok]
        end
        record = state['stages'][stage['id']]
        if record['status'] == 'passed'
          raise 'completed stage has missing or changed execution evidence' unless
            identity.all? { |k,v| record[k] == v } && File.file?(record['report'].to_s) &&
            record['report_sha256'] == Digest::SHA256.file(record['report']).hexdigest
          bind_execution_report(record, stage, feature_path, validation: validation_only)
        elsif !validation_only && %w[running failed].include?(record['status'])
          raise "stage #{stage['id']} may have executed partially; inspect and restore environment before creating a new execution flow"
        end
      end
      unless validation_only
        premature_gates = completed_gates.reject do |gate_id|
          state.dig('stages', gate_id, 'status').to_s == 'waiting'
        end
        unless premature_gates.empty?
          raise "external gate can only be acknowledged after this flow has stopped at it: #{premature_gates.join(', ')}"
        end
      end
      state['status'] = 'in_progress'
      state['waiting_for'] = nil unless validation_only
      results = []
      summaries = []

      stages.each do |stage|
        id = stage['id']
        record = state['stages'][id]
        if validation_only
          if stage['kind'] == 'external_gate'
            record['status'] = 'not_required_for_validation'
            write_json_atomic(absolute, payload)
            next
          end
          next if record['status'] == 'passed'
        else
          completed_status = stage['kind'] == 'external_gate' ? 'completed' : 'passed'
          next if record['status'] == completed_status
        end

        dependencies = Array(stage['requires'])
        unresolved = dependencies.reject do |dependency|
          dependency_stage = stages.find { |candidate| candidate['id'] == dependency }
          dependency_record = state['stages'][dependency]
          execution_dependency_complete?(dependency_record, dependency_stage)
        end
        unless unresolved.empty?
          state['status'] = 'failed'
          record['status'] = 'blocked'
          record['reason'] = "unmet dependency: #{unresolved.join(', ')}"
          write_json_atomic(absolute, payload)
          return {
            status: 'failed', results: results, summaries: summaries,
            reason: record['reason'], flow_path: absolute
          }
        end

        if stage['kind'] == 'external_gate'
          if completed_gates.include?(id)
            record['status'] = 'completed'
            record['acknowledged_at'] = Time.now.utc.iso8601
            record['acknowledgement'] = 'operator_cli'
            write_json_atomic(absolute, payload)
            next
          end
          record['status'] = 'waiting'
          state['status'] = 'waiting_for_gate'
          state['waiting_for'] = id
          write_json_atomic(absolute, payload)
          return {
            status: 'waiting_for_gate', gate: id, results: results,
            summaries: summaries, flow_path: absolute
          }
        end

        feature_path = execution_flow_feature_path(absolute, stage)
        if id == 'admin' && stage['semantic_flow']
          consistency = validate_admin_feature_consistency(stage['semantic_flow'], feature_path)
          unless consistency[:ok]
            state['status'] = 'failed'
            record['status'] = 'failed'
            record['reason'] = consistency[:reason]
            write_json_atomic(absolute, payload)
            return {
              status: 'failed', results: results, summaries: summaries,
              reason: consistency[:reason], flow_path: absolute
            }
          end
        end
        report_dir = FEATURE_RUN_REPORT_DIR && !FEATURE_RUN_REPORT_DIR.to_s.strip.empty? ?
          File.expand_path(FEATURE_RUN_REPORT_DIR) : File.join(File.dirname(absolute), 'feature_run_reports')
        FileUtils.mkdir_p(report_dir)
        report_path = File.join(report_dir, "#{File.basename(absolute, '.execution-flow.json')}.#{id}.json")
        record['status'] = 'running'
        record['started_at'] = Time.now.utc.iso8601
        write_json_atomic(absolute, payload)
        pipeline = run_generated_feature_pipeline(
          "#{payload['case_id']}-#{id}",
          feature_path,
          report_path,
          admin_flow_path: id == 'admin' ? stage['semantic_flow'] : nil,
          admin_flow_created: false,
          phase: "Execution flow #{stage['order']}/#{stages.length} (#{id})"
        )
        result = pipeline[:final]
        summary = pipeline[:summary]
        results << result
        summaries << summary
        record['report'] = File.expand_path(report_path)
        record['exit_code'] = result[:exit_code].to_i
        if result[:exit_code].to_i.zero?
          # Repair may have changed a non-Admin Feature; bind the actual successful artifact.
          stage.merge!(execution_identity(stage, feature_path))
          payload['definition_sha256'] = Digest::SHA256.hexdigest(JSON.generate(stages))
          bind_execution_report(record, stage, feature_path, validation: validation_only)
          record['status'] = 'passed'
          write_json_atomic(absolute, payload)
          next
        end

        record['status'] = 'failed'
        record['reason'] = summary['message'].to_s unless summary['message'].to_s.empty?
        state['status'] = 'failed'
        write_json_atomic(absolute, payload)
        return {
          status: 'failed', results: results, summaries: summaries,
          last_result: result, last_summary: summary, flow_path: absolute
        }
      end

      state['status'] = validation_only ? 'passed' : 'passed'
      state['waiting_for'] = nil unless validation_only
      write_json_atomic(absolute, payload)
      {
        status: validation_only ? 'validation_passed' : 'passed',
        results: results,
        summaries: summaries,
        last_result: results.last,
        last_summary: summaries.last || {},
        flow_path: absolute
      }
    rescue StandardError => e
      {
        status: 'failed', results: [], summaries: [],
        reason: "execution flow failed: #{e.class}: #{e.message}",
        flow_path: File.expand_path(flow_path)
      }
    end

    def run_execution_flow_mode(path)
      validation_only = FEATURE_DRY_RUN || PREFLIGHT_ONLY
      info "Run execution flow: #{File.expand_path(path)}"
      outcome = execute_feature_flow(
        path,
        completed_gates: COMPLETED_EXECUTION_GATES,
        validation_only: validation_only
      )
      case outcome[:status]
      when 'passed', 'validation_passed'
        log "[OK] Execution flow #{outcome[:status] == 'validation_passed' ? 'validation passed' : 'completed'}"
        0
      when 'waiting_for_gate'
        warn "[WAIT] Execution flow is waiting for external gate #{outcome[:gate]}. Complete it, then resume with --run-execution-flow #{outcome[:flow_path]} --complete-gate #{outcome[:gate]}"
        3
      else
        error outcome[:reason] || 'Execution flow failed'
        1
      end
    end

    def run_existing_feature_mode(path, diagnose: false, repair: false)
      feature_path = File.expand_path(path)
      unless File.file?(feature_path)
        error "Feature file not found: #{feature_path}"
        return 2
      end
      info "OpenCode model: #{OPENCODE_MODEL}"
      report_dir = FEATURE_RUN_REPORT_DIR && !FEATURE_RUN_REPORT_DIR.to_s.strip.empty? ?
        File.expand_path(FEATURE_RUN_REPORT_DIR) : File.join(File.dirname(feature_path), 'run_reports')
      FileUtils.mkdir_p(report_dir)
      report_path = File.join(report_dir, "#{File.basename(feature_path, '.feature')}.json")
      result = run_feature_file(
        "#{repair ? 'Repair' : (diagnose ? 'Debug' : 'Run')} existing Feature: #{File.basename(feature_path)}",
        feature_path,
        report_path,
        diagnose: diagnose,
        repair: repair,
        playwright_flow: playwright_flow_for(feature_path)
      )
      result[:exit_code].to_i == 0 ? 0 : (result[:exit_code].to_i.positive? ? result[:exit_code].to_i : 1)
    end

    # Find all Excel files under the given folder (recursive)
    def find_excel_files(folder)
      results = []
      EXCEL_EXTENSIONS.each do |ext|
        results += Dir.glob("#{folder}/**/*#{ext}")
      end
      results.sort
    end
  end
end
