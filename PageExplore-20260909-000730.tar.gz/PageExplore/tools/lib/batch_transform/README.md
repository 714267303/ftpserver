# Batch modules

| Module | Responsibility |
|---|---|
| `core.rb` | Conversion commands, source routing, file selection, subprocess lifecycle |
| `admin/configuration.rb` | URL, dotenv and MCP configuration |
| `admin/prompt.rb` | v2 business plan and browser execution prompts |
| `admin/exploration.rb` | Plan compilation before MCP, evidence finalization and recovery |
| `admin/contracts.rb` | Compiler process boundary, quarantine and promotion |
| `feature_pipeline.rb` | Single execution/repair invocation and independent non-Admin generation |
| `execution_flow.rb` | v2 stage identities, resume validation and external gates |
| `pipeline.rb` | Per-case stage orchestration and summary |

Python `tools/admin_flow/` owns the Admin semantics. Ruby must not maintain a
second semantic matcher or manufacture browser evidence. Model repair can only
change a staged Feature, and execution requires the compiler contract first.
