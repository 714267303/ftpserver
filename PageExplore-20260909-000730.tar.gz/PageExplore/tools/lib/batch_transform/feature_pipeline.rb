# frozen_string_literal: true

# Standalone Admin and non-Admin Feature generation and execution helpers.

module BatchTransform
  module FeaturePipeline
    private

    # Resolve one explicit Playwright reference per Feature. A batch can use a
    # literal path, a directory containing <case>.json, or a {case}/{feature}
    # template. A reviewed Admin flow selected during conversion is the fallback.
    def playwright_flow_for(feature_path, fallback = nil)
      configured = PLAYWRIGHT_FLOW.to_s.strip
      return File.expand_path(fallback) if configured.empty? && !fallback.to_s.strip.empty?
      return nil if configured.empty?

      case_name = File.basename(feature_path.to_s, '.feature')
      resolved = configured.gsub('{case}', case_name).gsub('{feature}', File.basename(feature_path.to_s))
      expanded = File.expand_path(resolved)
      if File.directory?(expanded)
        candidates = [
          File.join(expanded, "#{case_name}.json"),
          File.join(expanded, "#{case_name}.admin-flow.json")
        ].select { |path| File.file?(path) }
        if candidates.length != 1
          warn "Expected one Playwright flow for #{case_name} under #{expanded}; found #{candidates.length}"
          return nil
        end
        return candidates.first
      end
      expanded
    end

    # Build and run the shared Feature execution/diagnosis wrapper.  The wrapper
    # owns Cucumber invocation and report format; this batch script only supplies
    # paths and orchestration options.
    def feature_runner_command(feature_path, report_path, diagnose: false, repair: false,
                               playwright_flow: nil, allow_unverified_playwright_flow: nil)
      runner = File.expand_path(FEATURE_RUNNER)
      args = [RbConfig.ruby, runner, File.expand_path(feature_path), '--report', File.expand_path(report_path)]
      args += ['--model', OPENCODE_MODEL] unless OPENCODE_MODEL.to_s.strip.empty?
      args += ['--odp-doc-index', ODP_DOC_INDEX] if ODP_DOC_INDEX && !ODP_DOC_INDEX.to_s.strip.empty?
      args += ['--diagnose'] if diagnose
      args += ['--opencode-command', OPENCODE_DEBUG_COMMAND] if diagnose && OPENCODE_DEBUG_COMMAND && !OPENCODE_DEBUG_COMMAND.strip.empty?
      args += ['--repair'] if repair
      args += ['--repair-attempts', REPAIR_ATTEMPTS.to_i.to_s] if repair
      args += ['--repair-opencode-command', OPENCODE_REPAIR_COMMAND] if repair && OPENCODE_REPAIR_COMMAND && !OPENCODE_REPAIR_COMMAND.strip.empty?
      args += ['--repair-experience-dir', REPAIR_EXPERIENCE_DIR] if repair && REPAIR_EXPERIENCE_DIR && !REPAIR_EXPERIENCE_DIR.strip.empty?
      args += ['--repair-experience-index', REPAIR_EXPERIENCE_INDEX] if repair && REPAIR_EXPERIENCE_INDEX && !REPAIR_EXPERIENCE_INDEX.strip.empty?
      args += ['--allow-review'] if ALLOW_REVIEW_FEATURES
      args += ['--cucumber-command', CUCUMBER_COMMAND] if CUCUMBER_COMMAND && !CUCUMBER_COMMAND.strip.empty?
      CUCUMBER_ARGS.each { |argument| args += ['--cucumber-arg', argument] }
      args += ['--workdir', File.expand_path(FEATURE_RUN_WORKDIR)] if FEATURE_RUN_WORKDIR && !FEATURE_RUN_WORKDIR.strip.empty?
      args += ['--timeout', FEATURE_TIMEOUT.to_i.to_s] if FEATURE_TIMEOUT && FEATURE_TIMEOUT.to_i.positive?
      resolved_playwright_flow = playwright_flow_for(feature_path, playwright_flow)
      args += ['--playwright-flow', resolved_playwright_flow] if resolved_playwright_flow
      if PLAYWRIGHT_REPLAY_COMMAND && !PLAYWRIGHT_REPLAY_COMMAND.to_s.strip.empty?
        args += ['--playwright-replay-command', PLAYWRIGHT_REPLAY_COMMAND]
      end
      args += ['--playwright-bindings', File.expand_path(PLAYWRIGHT_BINDINGS)] if PLAYWRIGHT_BINDINGS && !PLAYWRIGHT_BINDINGS.to_s.strip.empty?
      allow_unverified = if allow_unverified_playwright_flow.nil?
                           ALLOW_UNVERIFIED_PLAYWRIGHT_FLOW
                         else
                           allow_unverified_playwright_flow
                         end
      args << '--allow-unverified-playwright-flow' if allow_unverified
      args += ['--playwright-workdir', File.expand_path(PLAYWRIGHT_WORKDIR)] if PLAYWRIGHT_WORKDIR && !PLAYWRIGHT_WORKDIR.to_s.strip.empty?
      args += ['--playwright-replay-mode', PLAYWRIGHT_REPLAY_MODE] unless PLAYWRIGHT_REPLAY_MODE.to_s.strip.empty?
      args += ['--playwright-timeout', PLAYWRIGHT_TIMEOUT.to_i.to_s] if PLAYWRIGHT_TIMEOUT && PLAYWRIGHT_TIMEOUT.to_i.positive?
      args += ['--data-preflight', DATA_PREFLIGHT] unless DATA_PREFLIGHT.to_s.strip.empty?
      args << '--allow-unresolved-data' if ALLOW_UNRESOLVED_DATA
      args << '--preflight-only' if PREFLIGHT_ONLY
      args << '--binary-debug' if FEATURE_BINARY_DEBUG
      FEATURE_ERROR_CATEGORIES.each { |category| args += ['--error-category', category] }
      args << '--dry-run' if FEATURE_DRY_RUN
      Shellwords.join(args)
    end

    def run_feature_file(label, feature_path, report_path, diagnose: false, repair: false,
                         playwright_flow: nil, allow_unverified_playwright_flow: nil)
      unless File.file?(feature_path)
        warn "Cannot run missing Feature: #{feature_path}"
        return { exit_code: -1, elapsed: 0.0, elapsed_formatted: '0.0s', feature: feature_path }
      end
      cmd = feature_runner_command(
        feature_path,
        report_path,
        diagnose: diagnose,
        repair: repair,
        playwright_flow: playwright_flow,
        allow_unverified_playwright_flow: allow_unverified_playwright_flow
      )
      result = run_opencode(label, cmd, retry_on_hang: false)
      result.merge(feature: feature_path, report: report_path, diagnose: diagnose, repair: repair)
    end

    def feature_run_report_summary(result)
      report_path = result[:report]
      return {} unless report_path && File.file?(report_path)

      payload = JSON.parse(File.read(report_path, encoding: 'UTF-8'))
      execution = payload['execution'].is_a?(Hash) ? payload['execution'] : {}
      repair = payload['repair'].is_a?(Hash) ? payload['repair'] : {}
      preflight = payload['data_preflight'].is_a?(Hash) ? payload['data_preflight'] : {}
      classification = execution['failure_classification'].is_a?(Hash) ? execution['failure_classification'] : {}
      blockers = Array(preflight['blockers']).filter_map do |item|
        next unless item.is_a?(Hash)

        token = item['token'] || item['name']
        kind = item['kind']
        next if token.to_s.empty? && kind.to_s.empty?

        kind.to_s.empty? ? token.to_s : "#{kind}:#{token}"
      end.first(8)
      {
        'status' => execution['status'],
        'repair_status' => repair['status'],
        'repair_stop_reason' => repair['stop_reason'],
        'category' => classification['category'],
        'message' => classification['message'],
        'blockers' => blockers,
        'cucumber_summary' => execution['cucumber_summary']
      }
    rescue StandardError
      {}
    end

    def feature_failure_repairable?(summary)
      blocked_statuses = %w[blocked_data blocked_review]
      return false if blocked_statuses.include?(summary['status'].to_s)
      return false if summary['repair_status'].to_s == 'blocked_runtime'
      return false if summary['category'].to_s == 'runtime_data_unresolved'
      return false if summary['category'].to_s == 'custom_step_implementation'

      true
    end

    # Execute the generated Feature in two visible phases.  The old implementation
    # delegated the initial run and all repairs to one `--repair` invocation, which
    # made it impossible for the batch summary to prove that step 5 happened before
    # step 6.  Keeping the first run separate also prevents a repair model from
    # touching a Feature when the failure is a runtime-data or review gate.
    def run_generated_feature_pipeline(base_name, feature_path, report_path, admin_flow_path: nil,
                                       admin_flow_created: false, phase: nil)
      phase_prefix = phase.to_s.strip.empty? ? 'Step 5/7' : phase.to_s.strip
      info "#{phase_prefix}: Execute Feature with bounded in-process repair: #{File.basename(feature_path)}"
      result = run_feature_file(
        "Test Feature: #{File.basename(feature_path)}", feature_path, report_path,
        diagnose: DEBUG_GENERATED && !REPAIR_GENERATED, repair: REPAIR_GENERATED,
        playwright_flow: admin_flow_path, allow_unverified_playwright_flow: false)
      summary = feature_run_report_summary(result)
      if result[:exit_code].to_i.zero? && !FEATURE_DRY_RUN && !PREFLIGHT_ONLY
        begin
          stage = {'semantic_flow'=>admin_flow_path}.compact
          bind_execution_report({'report'=>File.expand_path(report_path)}, stage, feature_path)
        rescue StandardError => e
          result = result.merge(exit_code: 4)
          summary = summary.merge('status'=>'blocked_execution_evidence', 'message'=>e.message)
        end
      end
      { final: result, initial: result, repair: REPAIR_GENERATED ? result : nil,
        summary: summary, status: result[:exit_code].to_i.zero? ? 'passed' : 'failed' }
    rescue StandardError => e
      warn "Feature pipeline failed for #{base_name}: #{e.class}: #{e.message}"
      failed = { exit_code: 1, elapsed: 0.0, elapsed_formatted: '0.0s', report: report_path, feature: feature_path }
      { final: failed, initial: failed, repair: nil, summary: {}, status: 'failed' }
    end

    # Assisted opencode output paths are not known to the batch process. Prefer an
    # exact conventional basename, then accept one unambiguous matching Feature.
    def feature_inventory(root = TARGET_DIR)
      Dir.glob(File.join(root, '**', '*.feature')).each_with_object({}) do |path, result|
        begin
          result[File.expand_path(path)] = artifact_signature(path)
        rescue StandardError
          # A concurrently removed file is simply absent from the inventory.
        end
      end
    end

    def locate_generated_feature(base_name, known_path = nil, identifiers: [], before: {},
                                 allow_changed_existing: false, target_dir: TARGET_DIR)
      if known_path && File.file?(known_path)
        # A deterministic converter owns its explicit output path.  Assisted
        # model transforms must create a new Feature; a touched old file is never
        # an implicit execution target.
        return known_path if before.empty? || allow_changed_existing
        absolute = File.expand_path(known_path)
        begin
          previous = before[absolute]
          return known_path if previous.nil?
          return known_path if allow_changed_existing && previous != artifact_signature(known_path)
        rescue StandardError
          # Fall through to the new-candidate scan below.
        end
      end

      candidates = Dir.glob(File.join(target_dir, '**', '*.feature')).select { |path| File.file?(path) }
      # Assisted transforms can choose their own output name.  Never pick an old
      # matching Feature when execution was requested; require a new file or a
      # changed size/mtime since this case started.
      changed = candidates.select do |path|
        absolute = File.expand_path(path)
        begin
          previous = before[absolute]
          current = artifact_signature(path)
          previous.nil? || (allow_changed_existing && previous != current)
        rescue StandardError
          false
        end
      end
      candidates = changed unless before.empty?
      feature_ids = ([base_name] + Array(identifiers)).map(&:to_s).map(&:strip).reject(&:empty?).uniq
      exact_name_groups = [
        feature_ids.map { |identifier| "#{identifier}.feature" },
        feature_ids.flat_map do |identifier|
          [
            "#{identifier}.admin.feature",
            "#{identifier}.binary.feature",
            "#{identifier}.hybrid.feature"
          ]
        end,
        feature_ids.flat_map do |identifier|
          [
            "#{identifier}.Presetting.feature",
            "#{identifier}_Presetting.feature",
            "#{identifier}.presetting.feature",
            "#{identifier}_presetting.feature"
          ]
        end
      ]
      exact_name_groups.each do |exact_names|
        exact = candidates.select { |path| exact_names.include?(File.basename(path)) }
        return exact.first if exact.length == 1
        if exact.length > 1
          warn "Multiple generated Features match #{base_name}; skip automatic run: #{exact.join(', ')}"
          return nil
        end
      end

      fuzzy = candidates.select do |path|
        basename = File.basename(path).downcase
        feature_ids.any? { |identifier| basename.include?(identifier.downcase) }
      end
      if fuzzy.length == 1
        fuzzy.first
      elsif fuzzy.length > 1
        warn "Multiple generated Features match #{base_name}; skip automatic run: #{fuzzy.join(', ')}"
        nil
      end
    end

    def non_admin_feature_validation(path)
      return { ok: false, reason: 'non-Admin Feature is missing' } unless readable_artifact?(path)

      text = File.read(path, encoding: 'UTF-8')
      if text.each_line.any? { |line| line.match?(/^\s*@/) && line.match?(/(?:^|\s)@REVIEW\b/i) }
        return { ok: false, reason: 'non-Admin Feature contains @REVIEW and is not executable' }
      end
      if text.match?(/^\s*@FEATURE=AdminGUI\b/i) || text.match?(/^\s*@ADMIN_SETUP\b/i)
        return { ok: false, reason: 'non-Admin Feature contains Admin-only tags' }
      end
      if text.match?(/^\s*Feature:\s*.*Admin GUI/i)
        return { ok: false, reason: 'non-Admin Feature was generated with an Admin GUI identity' }
      end

      forbidden = /\A(?:Login Trading Admin with:|Save current browser to browser_admin|Switch browser to "?browser_admin|Select Trading Admin Left Menu |Search in Trading Admin |Set Trading Admin |Save Trading Admin |Check Trading Admin |Approve if updated with\s*:|Select effective type .* detail info page |Click button .* in Trading Admin|Check the confirm message .* in Trading Admin)/i
      offending = text.each_line.filter_map do |line|
        match = line.match(/^\s*(?:\*|Given|When|Then|And|But)\s+(.+?)\s*$/i)
        next unless match && match[1].match?(forbidden)

        match[1]
      end
      unless offending.empty?
        return {
          ok: false,
          reason: "non-Admin Feature contains Admin executable step(s): #{offending.first(3).join(', ')}"
        }
      end
      if text.match?(/\bLoad value from admin_gui_value\b/i)
        return { ok: false, reason: 'non-Admin Feature loads admin_gui_value' }
      end

      { ok: true }
    rescue StandardError => e
      { ok: false, reason: "cannot validate non-Admin Feature: #{e.class}: #{e.message}" }
    end

    def persist_feature_copy(source_path, destination)
      raise "refusing to overwrite symlink: #{destination}" if File.symlink?(destination)

      FileUtils.mkdir_p(File.dirname(destination))
      temporary = File.join(
        File.dirname(destination),
        ".#{File.basename(destination)}.tmp-#{Process.pid}-#{SecureRandom.hex(4)}"
      )
      begin
        File.open(temporary, File::WRONLY | File::CREAT | File::EXCL, 0o600) do |file|
          file.write(File.binread(source_path))
          file.flush
        end
        File.rename(temporary, destination)
      ensure
        File.delete(temporary) if File.exist?(temporary)
      end
      destination
    end

    def cross_day_feature_validation(paths, yaml_path)
      return { ok: false, reason: 'cross-day conversion must produce exactly Day1 and Day2 Features' } unless paths.length == 2

      day1, day2 = paths
      [day1, day2].each do |path|
        validation = non_admin_feature_validation(path)
        return validation unless validation[:ok]
      end

      dump_name = "#{primary_yaml_identifier(yaml_path)}-Day1"
      day1_text = File.read(day1, encoding: 'UTF-8')
      day2_text = File.read(day2, encoding: 'UTF-8')
      save_pattern = /^\s*\*\s+Save FIX dumpfile\s+#{Regexp.escape(dump_name)}\s*$/
      load_pattern = /^\s*\*\s+Load FIX dumpfile\s+#{Regexp.escape(dump_name)}\s*$/
      unless day1_text.match?(save_pattern)
        return { ok: false, reason: "Day1 Feature must end its lifecycle with `* Save FIX dumpfile #{dump_name}`" }
      end
      unless day2_text.match?(load_pattern)
        return { ok: false, reason: "Day2 Feature must load `* Load FIX dumpfile #{dump_name}`" }
      end

      executable_batch = (day1_text + "\n" + day2_text).each_line.find do |line|
        line.match?(/^\s*(?:\*|Given|When|Then|And|But)\s+.*#{CROSS_TRADING_DAY_MARKER}/i)
      end
      if executable_batch
        return {
          ok: false,
          reason: 'night batch must be an external execution-flow gate, not a generated Gherkin step'
        }
      end

      { ok: true }
    rescue StandardError => e
      { ok: false, reason: "cannot validate cross-day Features: #{e.class}: #{e.message}" }
    end

    def persist_non_admin_features(source_paths, base_name, lifecycle:)
      suffixes = lifecycle[:cross_day] ? ['-Day1.feature', '-Day2.feature'] : ['.feature']
      unless source_paths.length == suffixes.length
        raise "expected #{suffixes.length} non-Admin Feature artifact(s), found #{source_paths.length}"
      end

      source_paths.zip(suffixes).map do |source_path, suffix|
        destination = File.join(expanded_path(TARGET_DIR), "#{base_name}#{suffix}")
        persist_feature_copy(source_path, destination)
      end
    end

    def generated_non_admin_feature_paths(staging_root, base_name, lifecycle:)
      if lifecycle[:cross_day]
        paths = %w[Day1 Day2].map do |day|
          File.join(staging_root, "#{base_name}-#{day}.feature")
        end
        return paths if paths.all? { |path| File.file?(path) && !File.symlink?(path) }

        return []
      end

      path = locate_generated_feature(
        base_name,
        nil,
        identifiers: [],
        before: {},
        target_dir: staging_root
      )
      path ? [path] : []
    end

    def generate_hybrid_non_admin_features(yaml_path, base_name, lifecycle:)
      if lifecycle[:cross_day] && lifecycle[:batch_boundaries] != 1
        failure = "cross-day conversion currently requires exactly one batch boundary; found #{lifecycle[:batch_boundaries]}"
        return [[], { exit_code: 1, elapsed: 0.0, elapsed_formatted: '0.0s' }, failure, nil]
      end
      staging_root = File.join(
        expanded_path(TARGET_DIR),
        '.hybrid_binary_base',
        "#{safe_admin_slug(base_name)}-#{Time.now.utc.strftime('%Y%m%dT%H%M%SZ')}-#{Process.pid}-#{SecureRandom.hex(3)}"
      )
      FileUtils.mkdir_p(staging_root)
      FileUtils.chmod_R(0o700, staging_root)
      before = feature_inventory(staging_root)
      prompt = yaml_transform_prompt(
        yaml_path,
        channel_override: 'binary',
        target_dir: staging_root,
        exclude_admin: true,
        lifecycle: lifecycle,
        output_base_name: base_name
      )
      command = build_opencode_command(prompt)
      result = run_opencode(
        "Generate independent non-Admin Feature for Hybrid: #{base_name}",
        command,
        model_prompt: prompt,
        environment: conversion_permission_environment(
          read_roots: [File.dirname(yaml_path), AUTO_SKILL, STEP_INDEX, ODP_DOC_INDEX,
                       File.dirname(ODP_DOC_INDEX), PAGE_EXPLORE_ROOT, SCRIPT_ROOT],
          edit_roots: [staging_root]
        )
      )
      unless result[:exit_code].to_i.zero?
        return [[], result, "Binary base generation failed (exit #{result[:exit_code]})", staging_root]
      end
      paths = if lifecycle[:cross_day]
                generated_non_admin_feature_paths(staging_root, base_name, lifecycle: lifecycle)
              else
                path = locate_generated_feature(
                  base_name,
                  nil,
                  identifiers: yaml_identifiers(yaml_path),
                  before: before,
                  target_dir: staging_root
                )
                path ? [path] : []
              end
      if paths.empty?
        expected = lifecycle[:cross_day] ? "#{base_name}-Day1.feature and #{base_name}-Day2.feature" : 'one fresh non-Admin Feature'
        return [[], result, "no fresh Binary artifact set found for #{base_name}; expected #{expected}", staging_root]
      end
      paths.each do |path|
        failure = conversion_failure_reason(
          result,
          artifact_path: path,
          before_signature: before[File.expand_path(path)],
          require_fresh: true
        )
        return [[], result, failure, staging_root] if failure
      end

      validation = if lifecycle[:cross_day]
                     cross_day_feature_validation(paths, yaml_path)
                   else
                     non_admin_feature_validation(paths.first)
                   end
      return [[], result, validation[:reason], staging_root] unless validation[:ok]

      [paths, result, nil, staging_root]
    rescue StandardError => e
      [[], { exit_code: 1, elapsed: 0.0, elapsed_formatted: '0.0s' },
       "Binary base generation failed: #{e.class}: #{e.message}", nil]
    end
  end
end
