# frozen_string_literal: true

# Top-level per-case batch pipeline.

module BatchTransform
  module Pipeline
    private

    # --- Main Execution ---
    def main
      # Direct execution mode is intentionally available without Excel/YAML
      # arguments, so a user can run, diagnose, or explicitly repair one Feature.
      if REPAIR_FEATURE
        return run_existing_feature_mode(REPAIR_FEATURE, repair: true)
      end
      if DEBUG_FEATURE
        return run_existing_feature_mode(DEBUG_FEATURE, diagnose: true)
      end
      if RUN_FEATURE
        return run_existing_feature_mode(RUN_FEATURE, diagnose: false)
      end
      if RUN_EXECUTION_FLOW
        return run_execution_flow_mode(RUN_EXECUTION_FLOW)
      end

      if MAX_CAPTURE_BYTES <= 0
        error 'OPENCODE_MAX_OUTPUT_BYTES must be positive'
        return 2
      end
      begin
        build_opencode_command('validation prompt')
      rescue ArgumentError => e
        error e.message
        return 2
      end

      puts ""
      info "Batch Transform Excel -> YAML -> Target"
      info 'Flow: Excel->YAML -> classify -> Admin MCP/rollback -> standalone Admin Feature -> Admin validate/repair/promote -> independent non-Admin Feature/run'
      exploration_trigger = if ADMIN_EXPLORE_MODE == 'auto' && REPAIR_GENERATED
                              ' (enabled by --repair-generated)'
                            elsif ADMIN_EXPLORE_MODE == 'auto' &&
                                  (!ADMIN_EXPLORE_COMMAND.to_s.strip.empty? || !PLAYWRIGHT_MCP_COMMAND.to_s.strip.empty?)
                              ' (enabled by explicit MCP/exploration command)'
                            else
                              ''
                            end
      odp_url_details = configured_odp_url_details
      odp_url_source = odp_url_details[:source] ? " (source: #{odp_url_details[:source]})" : ''
      generated_run_description = if REPAIR_GENERATED
                                    'yes (repair until passed)'
                                  elsif DEBUG_GENERATED
                                    'yes (diagnose failures)'
                                  else
                                    RUN_GENERATED ? 'yes' : 'no'
                                  end
      if VERBOSE_MODEL_OUTPUT
        info "Excel folder: #{EXCEL_FOLDER}"
        info "Yaml folder:  #{YAML_FOLDER}"
        info "Target dir:   #{TARGET_DIR}"
        info "PageExplore root: #{PAGE_EXPLORE_ROOT}"
        info "OpenCode model: #{OPENCODE_MODEL}"
        info "ODP document index: #{ODP_DOC_INDEX}"
        info "Transform channel: #{TRANSFORM_CHANNEL}"
        info "Excel -> YAML mode: #{EXCEL_YAML_MODE}"
        info "YAML only: #{YAML_ONLY ? 'yes' : 'no'}"
        info "Admin flow dir: #{ADMIN_FLOW_DIR || '(not configured)'}"
        info "Admin converter mode: #{ADMIN_CONVERTER_MODE}"
        info "Admin MCP exploration: #{ADMIN_EXPLORE_MODE}#{exploration_trigger}"
        info "Admin handoff recovery run: #{ADMIN_HANDOFF_RUN || '(not requested)'}"
        info "Admin evidence root: #{expanded_path(ADMIN_EVIDENCE_ROOT)}"
        info "ODP browser URL: #{odp_url_details[:url] || '(not configured; required for Admin MCP)'}#{odp_url_source}"
        info "Playwright MCP secrets: #{playwright_mcp_secrets_path ? 'configured (path withheld)' : 'not configured'}"
        info "Playwright MCP browser: #{PLAYWRIGHT_MCP_HEADLESS ? 'headless' : 'headed'}"
        info "Run generated Features: #{generated_run_description}"
        info "Binary debug for Feature runs: #{FEATURE_BINARY_DEBUG ? 'yes' : 'no'}"
        info "Playwright replay: #{PLAYWRIGHT_REPLAY_COMMAND ? PLAYWRIGHT_REPLAY_MODE : 'not configured'}"
      else
        info "Input: #{EXCEL_FOLDER} -> #{YAML_FOLDER} -> #{TARGET_DIR}"
        info "Runtime: model=#{OPENCODE_MODEL}; Admin MCP=#{PLAYWRIGHT_MCP_HEADLESS ? 'headless' : 'headed'}; " \
             "ODP URL=#{odp_url_details[:url] ? 'configured' : 'not configured'}; credentials=#{playwright_mcp_secrets_path ? 'configured' : 'not configured'}"
      end
      puts ""

      # Validate excel folder
      unless File.directory?(EXCEL_FOLDER)
        error "Excel folder not found: #{EXCEL_FOLDER}"
        exit 1
      end

      # Ensure output directories exist
      FileUtils.mkdir_p(YAML_FOLDER)
      FileUtils.mkdir_p(TARGET_DIR)
      log "YAML directory ready: #{YAML_FOLDER}" if VERBOSE_MODEL_OUTPUT
      log "Target directory ready: #{TARGET_DIR}" if VERBOSE_MODEL_OUTPUT

      # Get all Excel files
      excel_files = find_excel_files(EXCEL_FOLDER)
      info "Found #{excel_files.length} Excel files in #{EXCEL_FOLDER}"

      if excel_files.empty?
        warn "No Excel files found. Exiting."
        exit 0
      end
      if !ADMIN_HANDOFF_RUN.to_s.strip.empty? && excel_files.length != 1
        error '--admin-handoff-run requires an input containing exactly one Excel case'
        return 2
      end

      # The per-file stage line identifies each case in compact mode. Print the
      # duplicate inventory only when detailed output was explicitly requested.
      if VERBOSE_MODEL_OUTPUT
        puts "\n  #{BOLD}Excel files to process:#{RESET}"
        puts "  #{'-' * 60}"
        excel_files.each_with_index do |filepath, idx|
          puts "  [#{format('%2d', idx + 1)}] #{File.basename(filepath)}"
        end
        puts "  #{'-' * 60}"
        puts ""
      end

      # Ensure access rights
      log "Setting access rights for opencode under #{YAML_FOLDER} and #{TARGET_DIR}..." if VERBOSE_MODEL_OUTPUT
      begin
        # Generated YAML/Features/reports can contain environment-specific test
        # data.  Keep the tree private to the invoking account.
        FileUtils.chmod_R(0o700, YAML_FOLDER)
        FileUtils.chmod_R(0o700, TARGET_DIR)
      rescue StandardError => e
        error "Could not make output directories private: #{e.message}"
        return 1
      end
      log "Access rights updated." if VERBOSE_MODEL_OUTPUT

      # --- Process each file sequentially: Excel -> YAML -> Transform ---
      puts "\n#{BOLD}#{'=' * 70}#{RESET}"
      puts "#{BOLD}  Processing #{excel_files.length} test case(s) (per-file pipeline)#{RESET}"
      puts "#{BOLD}#{'=' * 70}#{RESET}\n"

      all_results = []
      excel_success = 0
      excel_failed = 0
      yaml_success = 0
      yaml_failed = 0
      feature_run_success = 0
      feature_run_failed = 0
      feature_run_skipped = 0
      feature_run_waiting = 0
      flow_promotion_failed = 0
      pipeline_started_at = Process.clock_gettime(Process::CLOCK_MONOTONIC)

      excel_files.each_with_index do |excel_path, idx|
        base_name = File.basename(excel_path, '.*')
        yaml_path = File.join(YAML_FOLDER, "#{base_name}.yaml")

        # Stage 2: Excel -> YAML
        puts ""
        puts "#{BOLD}--- [#{idx + 1}/#{excel_files.length}] Step 2/7: Excel -> YAML ---#{RESET}"
        puts ""

        if !ADMIN_HANDOFF_RUN.to_s.strip.empty?
          unless readable_artifact?(yaml_path)
            reason = "Admin handoff recovery requires the existing YAML from the selected run: #{yaml_path}"
            excel_failed += 1
            warn "[FAIL] Failed  : #{File.basename(excel_path)} (#{reason}; Duration: 0.0s, exit: recovery)"
            all_results << {
              excel_file: File.basename(excel_path),
              yaml_file: "#{base_name}.yaml",
              excel_elapsed: 0.0,
              excel_elapsed_fmt: '0.0s',
              yaml_elapsed: 0,
              yaml_elapsed_fmt: '0.0s',
              excel_ok: false,
              yaml_ok: false,
              failure_reason: reason
            }
            puts ''
            next
          end
          info "Step 2/7: Reuse existing YAML for Admin handoff recovery: #{yaml_path}"
          log 'Excel parsing and Excel-to-YAML model conversion are skipped in handoff recovery mode.'
          e_result = { exit_code: 0, elapsed: 0.0, elapsed_formatted: '0.0s', output: '' }
          excel_failure_reason = nil
        else
          yaml_before_signature = artifact_signature(yaml_path)
          parsed_json_path, parse_failure_reason = parse_excel_to_artifact(excel_path, yaml_path)
          if parse_failure_reason
            excel_failed += 1
            warn "[FAIL] Failed  : #{File.basename(excel_path)} (#{parse_failure_reason}; Duration: 0.0s, exit: parser)"
            all_results << {
              excel_file: File.basename(excel_path),
              yaml_file: "#{base_name}.yaml",
              excel_elapsed: 0.0,
              excel_elapsed_fmt: '0.0s',
              yaml_elapsed: 0,
              yaml_elapsed_fmt: "0.0s",
              excel_ok: false,
              yaml_ok: false,
              failure_reason: parse_failure_reason
            }
            puts ""
            next
          end

          if EXCEL_YAML_MODE == 'deterministic'
            info "#{'=' * 70}"
            info "Excel -> YAML: #{File.basename(excel_path)} -> #{base_name}.yaml"
            info "#{'=' * 70}"
            log "Using deterministic parser output; model enrichment is skipped for this stage."
            e_result, deterministic_failure_reason = deterministic_excel_to_yaml(excel_path, yaml_path)
            if VERBOSE_MODEL_OUTPUT && !e_result[:output].to_s.strip.empty?
              puts redact_batch(e_result[:output])
            end
          else
            prompt = excel_to_yaml_prompt(excel_path, yaml_path, parsed_json_path: parsed_json_path)
            cmd = build_opencode_command(prompt)
            e_result = run_opencode(
              "Excel -> YAML: #{File.basename(excel_path)} -> #{base_name}.yaml",
              cmd,
              model_prompt: prompt,
              environment: conversion_permission_environment(
                read_roots: [File.dirname(parsed_json_path), EXCEL_YAML_SKILL, SCRIPT_ROOT,
                             ODP_DOC_INDEX, File.dirname(ODP_DOC_INDEX), PAGE_EXPLORE_ROOT],
                edit_roots: [YAML_FOLDER]
              )
            )
            deterministic_failure_reason = nil
          end

          excel_failure_reason = conversion_failure_reason(
            e_result,
            artifact_path: yaml_path,
            before_signature: yaml_before_signature,
            require_fresh: false
          ) || deterministic_failure_reason
        end
        if excel_failure_reason.nil?
          excel_success += 1
          log "[OK] Success: #{File.basename(excel_path)} -> #{base_name}.yaml (Duration: #{e_result[:elapsed_formatted]})"
        else
          excel_failed += 1
          warn "[FAIL] Failed  : #{File.basename(excel_path)} (#{excel_failure_reason}; Duration: #{e_result[:elapsed_formatted]}, exit: #{e_result[:exit_code]})"
          all_results << {
            excel_file: File.basename(excel_path),
            yaml_file: "#{base_name}.yaml",
            excel_elapsed: e_result[:elapsed],
            excel_elapsed_fmt: e_result[:elapsed_formatted],
            yaml_elapsed: 0,
            yaml_elapsed_fmt: "0.0s",
            excel_ok: false,
            yaml_ok: false,
            failure_reason: excel_failure_reason
          }
          puts ""
          next
        end

        if YAML_ONLY
          all_results << {
            excel_file: File.basename(excel_path),
            yaml_file: "#{base_name}.yaml",
            excel_elapsed: e_result[:elapsed],
            excel_elapsed_fmt: e_result[:elapsed_formatted],
            yaml_elapsed: 0,
            yaml_elapsed_fmt: 'SKIPPED',
            excel_ok: true,
            yaml_ok: nil,
            channel: 'not_transformed',
            failure_reason: nil
          }
          puts ""
          next
        end

        # Stage 3: inspect the generated routing metadata and classify the case.
        # Metadata-free legacy YAML retains the old behavior, but an explicit Admin
        # channel must never bypass Playwright evidence and fall through to a
        # generic model transform.
        execution_channels = yaml_execution_channels(yaml_path)
        lifecycle = yaml_lifecycle(yaml_path)
        invalid_execution_channels = execution_channels - YAML_EXECUTION_CHANNELS
        unless invalid_execution_channels.empty?
          error "Unsupported Execution Channel value(s) in #{base_name}.yaml: #{invalid_execution_channels.join(', ')}"
          yaml_failed += 1
          all_results << {
            excel_file: File.basename(excel_path),
            yaml_file: "#{base_name}.yaml",
            excel_elapsed: e_result[:elapsed],
            excel_elapsed_fmt: e_result[:elapsed_formatted],
            yaml_elapsed: 0,
            yaml_elapsed_fmt: '0.0s',
            excel_ok: true,
            yaml_ok: false,
            channel: 'invalid',
            execution_channels: execution_channels,
            admin_flow: nil,
            failure_reason: 'unsupported YAML Execution Channel metadata'
          }
          puts ''
          next
        end

        yaml_declared_channel = transform_channel_from_yaml(execution_channels)
        info "Step 3/7: Inspect and classify #{base_name} as #{yaml_declared_channel || TRANSFORM_CHANNEL}"
        if lifecycle[:cross_day]
          info "Step 3/7: Detected cross-trading-day lifecycle with #{lifecycle[:batch_boundaries]} external batch gate(s)."
        end
        admin_flow_created_this_run = false
        admin_exploration = nil
        detected_channel = nil
        required_admin_channel = if TRANSFORM_CHANNEL == 'auto'
                                   yaml_declared_channel
                                 else
          TRANSFORM_CHANNEL
        end
        if TRANSFORM_CHANNEL == 'binary' && %w[admin hybrid].include?(yaml_declared_channel)
          error "YAML declares #{yaml_declared_channel} but --channel binary was requested for #{base_name}; refusing to skip Admin GUI verification"
          yaml_failed += 1
          all_results << {
            excel_file: File.basename(excel_path),
            yaml_file: "#{base_name}.yaml",
            excel_elapsed: e_result[:elapsed],
            excel_elapsed_fmt: e_result[:elapsed_formatted],
            yaml_elapsed: 0,
            yaml_elapsed_fmt: '0.0s',
            excel_ok: true,
            yaml_ok: false,
            channel: yaml_declared_channel,
            execution_channels: execution_channels,
            admin_flow: nil,
            failure_reason: 'requested channel conflicts with YAML Execution Channel metadata'
          }
          puts ''
          next
        end

        # Do not scan the Admin catalog for Binary-only cases. Apart from avoiding
        # noisy "catalog not found" warnings, this makes the channel boundary
        # explicit: only an Admin/Hybrid case can consume browser evidence.
        admin_flow_path = if %w[admin hybrid].include?(required_admin_channel) &&
                             ADMIN_HANDOFF_RUN.to_s.strip.empty?
                            find_admin_flow(yaml_path)
                          end
        if admin_flow_path
          info "Step 1/7: Reuse verified Admin flow: #{File.basename(admin_flow_path)}"
        elsif !%w[admin hybrid].include?(required_admin_channel)
          info 'Step 1/7: Admin exploration not applicable to this Binary-only case.'
        end
        if %w[admin hybrid].include?(required_admin_channel) && admin_flow_path.nil?
          if admin_exploration_requested? || !ADMIN_HANDOFF_RUN.to_s.strip.empty?
            case_id = primary_yaml_identifier(yaml_path)
            if ADMIN_HANDOFF_RUN.to_s.strip.empty?
              browser_mode = PLAYWRIGHT_MCP_HEADLESS ? 'headless' : 'headed'
              info "Missing reusable Admin flow for #{base_name}; launching the #{browser_mode} Playwright MCP workflow."
              admin_exploration = run_admin_exploration(
                yaml_path: yaml_path,
                case_id: case_id,
                channel: required_admin_channel
              )
            else
              info "Step 1/7: Recover Admin manifest handoff from #{expanded_path(ADMIN_HANDOFF_RUN)}; Playwright MCP will not run."
              admin_exploration = recover_admin_exploration_handoff(
                yaml_path: yaml_path,
                case_id: case_id,
                channel: required_admin_channel,
                run_dir: ADMIN_HANDOFF_RUN
              )
            end
            if admin_exploration[:ok]
              admin_flow_path = admin_exploration[:flow_path]
              admin_flow_created_this_run = true
              detected_channel = manifest_channel(admin_flow_path)
              action = admin_exploration[:recovered_handoff] ? 'recovered' : 'captured'
              log "[OK] Step 1/7: Admin flow #{action}: #{admin_flow_path}"
            else
              error "Step 1/7 Admin exploration failed for #{base_name}: #{admin_exploration[:reason]}"
              yaml_failed += 1
              all_results << {
                excel_file: File.basename(excel_path),
                yaml_file: "#{base_name}.yaml",
                excel_elapsed: e_result[:elapsed],
                excel_elapsed_fmt: e_result[:elapsed_formatted],
                yaml_elapsed: 0,
                yaml_elapsed_fmt: '0.0s',
                excel_ok: true,
                yaml_ok: false,
                channel: required_admin_channel,
                execution_channels: execution_channels,
                admin_flow: nil,
                admin_exploration: admin_exploration,
                failure_stage: 'admin_exploration',
                failure_reason: admin_exploration[:reason]
              }
              puts ""
              next
            end
          else
            error "#{required_admin_channel} channel requires one matching reviewed Admin flow manifest for #{base_name}"
            warn 'Use --repair-generated (auto mode) or --admin-explore to validate the missing Admin path through Playwright MCP. Use --no-admin-explore to keep conversion-only behavior.'
            yaml_failed += 1
            all_results << {
              excel_file: File.basename(excel_path),
              yaml_file: "#{base_name}.yaml",
              excel_elapsed: e_result[:elapsed],
              excel_elapsed_fmt: e_result[:elapsed_formatted],
              yaml_elapsed: 0,
              yaml_elapsed_fmt: '0.0s',
              excel_ok: true,
              yaml_ok: false,
              channel: required_admin_channel,
              execution_channels: execution_channels,
              admin_flow: nil,
              failure_stage: 'admin_flow_required',
              failure_reason: 'reviewed Playwright Admin flow manifest is required'
            }
            puts ""
            next
          end
        end

        if admin_flow_path
          detected_channel ||= manifest_channel(admin_flow_path)
          if detected_channel.nil?
            quarantine_admin_flow(admin_flow_path, 'Admin flow manifest channel is invalid') if admin_flow_created_this_run
            yaml_failed += 1
            all_results << {
              excel_file: File.basename(excel_path),
              yaml_file: "#{base_name}.yaml",
              excel_elapsed: e_result[:elapsed],
              excel_elapsed_fmt: e_result[:elapsed_formatted],
              yaml_elapsed: 0,
              yaml_elapsed_fmt: "0.0s",
              excel_ok: true,
              yaml_ok: false,
              channel: TRANSFORM_CHANNEL,
              admin_flow: admin_flow_path
            }
            puts ""
            next
          end
          if yaml_declared_channel && %w[admin hybrid].include?(yaml_declared_channel) &&
             detected_channel != yaml_declared_channel
            error "Manifest channel #{detected_channel} does not match YAML Execution Channel routing #{yaml_declared_channel} for #{base_name}"
            quarantine_admin_flow(admin_flow_path, 'Admin flow channel conflicts with YAML Execution Channel metadata') if admin_flow_created_this_run
            yaml_failed += 1
            all_results << {
              excel_file: File.basename(excel_path),
              yaml_file: "#{base_name}.yaml",
              excel_elapsed: e_result[:elapsed],
              excel_elapsed_fmt: e_result[:elapsed_formatted],
              yaml_elapsed: 0,
              yaml_elapsed_fmt: '0.0s',
              excel_ok: true,
              yaml_ok: false,
              channel: yaml_declared_channel,
              execution_channels: execution_channels,
              admin_flow: admin_flow_path,
              failure_reason: 'Admin manifest channel conflicts with YAML Execution Channel metadata'
            }
            puts ''
            next
          end
          if TRANSFORM_CHANNEL != 'auto' && detected_channel != TRANSFORM_CHANNEL
            error "Manifest channel #{detected_channel} does not match requested #{TRANSFORM_CHANNEL} for #{base_name}"
            quarantine_admin_flow(admin_flow_path, 'Admin flow channel conflicts with requested transform channel') if admin_flow_created_this_run
            yaml_failed += 1
            all_results << {
              excel_file: File.basename(excel_path),
              yaml_file: "#{base_name}.yaml",
              excel_elapsed: e_result[:elapsed],
              excel_elapsed_fmt: e_result[:elapsed_formatted],
              yaml_elapsed: 0,
              yaml_elapsed_fmt: "0.0s",
              excel_ok: true,
              yaml_ok: false,
              channel: TRANSFORM_CHANNEL,
              admin_flow: admin_flow_path
            }
            puts ""
            next
          end
        end

        if admin_flow_path
          preflight_issues = reusable_admin_flow_case_issues(admin_flow_path, yaml_path)
          unless preflight_issues.empty?
            reason = "Admin flow correctness preflight failed: #{preflight_issues.join(', ')}"
            error "#{reason} for #{base_name}"
            quarantine_admin_flow(admin_flow_path, reason) if admin_flow_created_this_run
            yaml_failed += 1
            all_results << {
              excel_file: File.basename(excel_path),
              yaml_file: "#{base_name}.yaml",
              excel_elapsed: e_result[:elapsed],
              excel_elapsed_fmt: e_result[:elapsed_formatted],
              yaml_elapsed: 0,
              yaml_elapsed_fmt: '0.0s',
              excel_ok: true,
              yaml_ok: false,
              channel: detected_channel,
              execution_channels: execution_channels,
              admin_flow: admin_flow_path,
              failure_stage: 'admin_flow_preflight',
              failure_reason: reason
            }
            puts ''
            next
          end
          log '[OK] Admin flow correctness preflight: source coverage, PageExplore page contract, and Step_Index'
        end

        # Admin and non-Admin behavior are deliberately generated and validated as
        # separate artifacts.  The first executable target for an Admin/Hybrid
        # case is always the standalone Admin Feature rendered from the MCP flow.
        # A Hybrid continuation is generated only after that Admin artifact is
        # consistent (and, when execution was requested, has passed).  This keeps
        # Binary failures from driving edits to already-proven Admin behavior.
        puts ""
        puts "#{BOLD}--- [#{idx + 1}/#{excel_files.length}] Step 4/7: Generate independent Feature artifact(s) ---#{RESET}"
        puts ""

        feature_snapshot = feature_inventory
        generated_feature_path = nil
        admin_feature_path = nil
        non_admin_feature_path = nil
        non_admin_feature_paths = []
        execution_flow_path = nil
        execution_flow_outcome = nil
        admin_flow_finalized = false
        admin_promotion = nil
        conversion_results = []
        transform_failure_reason = nil
        pipeline_failure_stage = nil
        pipeline_failure_reason = nil
        admin_transform_ok = admin_flow_path.nil?
        non_admin_transform_ok = detected_channel != 'hybrid'
        admin_run_result = nil
        admin_run_summary = {}
        admin_initial_run_result = nil
        admin_repair_run_result = nil
        admin_alignment_run_result = nil
        non_admin_run_result = nil
        non_admin_run_summary = {}
        non_admin_initial_run_result = nil
        non_admin_repair_run_result = nil

        if admin_flow_path
          admin_feature_path = admin_output_path(base_name, admin_flow_path)
          admin_conversion_report = admin_report_path(base_name)
          admin_render = render_standalone_admin_feature(
            flow_path: admin_flow_path,
            feature_path: admin_feature_path,
            report_path: admin_conversion_report,
            label: "Admin manifest -> standalone Admin Feature: #{File.basename(admin_flow_path)}"
          )
          admin_y_result = admin_render[:result]
          conversion_results << admin_y_result
          admin_failure = admin_render[:reason]
          if admin_failure
            pipeline_failure_stage = 'admin_feature_generation'
            transform_failure_reason = "standalone Admin Feature generation failed: #{admin_failure}"
            warn "[FAIL] #{transform_failure_reason}"
          else
            admin_transform_ok = true
            generated_feature_path = admin_feature_path
            log "[OK] Standalone Admin Feature matches MCP semantic flow: #{File.basename(admin_feature_path)}"
          end

          if admin_transform_ok && RUN_GENERATED
            run_report_dir = FEATURE_RUN_REPORT_DIR && !FEATURE_RUN_REPORT_DIR.to_s.strip.empty? ?
              File.expand_path(FEATURE_RUN_REPORT_DIR) : File.join(TARGET_DIR, 'feature_run_reports')
            FileUtils.mkdir_p(run_report_dir)
            admin_run_report_path = File.join(run_report_dir, "#{base_name}.admin.json")
            admin_pipeline = run_generated_feature_pipeline(
              base_name,
              admin_feature_path,
              admin_run_report_path,
              admin_flow_path: admin_flow_path,
              admin_flow_created: admin_flow_created_this_run,
              phase: 'Step 5A/7 Admin validation'
            )
            admin_run_result = admin_pipeline[:final]
            admin_initial_run_result = admin_pipeline[:initial]
            admin_repair_run_result = admin_pipeline[:repair]
            admin_run_summary = admin_pipeline[:summary]

            final_consistency = validate_admin_feature_consistency(admin_flow_path, admin_feature_path)
            unless final_consistency[:ok]
              admin_run_result = admin_run_result.dup
              admin_run_result[:exit_code] = 4
              admin_run_summary = {
                'status' => 'blocked_behavior_mismatch',
                'category' => 'admin_mcp_behavior_mismatch',
                'message' => final_consistency[:reason],
                'blockers' => []
              }
              warn "[FAIL] Admin Feature changed away from the MCP semantic flow: #{final_consistency[:reason]}"
            end

            if admin_run_result[:exit_code].to_i.zero?
              log "[OK] Standalone Admin Feature passed: #{File.basename(admin_feature_path)}"
            else
              category = admin_run_summary['category'].to_s
              suffix = category.empty? ? '' : "; category: #{category}"
              pipeline_failure_stage = category == 'admin_mcp_behavior_mismatch' ?
                'admin_feature_consistency' : 'admin_feature_run'
              pipeline_failure_reason = "Standalone Admin Feature failed (exit: #{admin_run_result[:exit_code]}#{suffix})"
              warn "[FAIL] Standalone Admin Feature failed (exit: #{admin_run_result[:exit_code]}#{suffix})"
            end
          end

          if admin_flow_created_this_run && !admin_flow_finalized
            if !admin_transform_ok
              admin_promotion = quarantine_admin_flow(admin_flow_path, transform_failure_reason)
              warn '[WARN] Step 6/7: Admin flow kept quarantined (standalone Feature generation failed)'
              admin_flow_finalized = true
            elsif RUN_GENERATED
              admin_final_status = if admin_run_summary['status'] == 'preflight_only' || PREFLIGHT_ONLY
                                     'preflight_only'
                                   elsif FEATURE_DRY_RUN
                                     'dry_run'
                                   elsif admin_run_result && admin_run_result[:exit_code].to_i.zero?
                                     'passed'
                                   else
                                     'failed'
                                   end
              info "Step 6/7: Validate and promote Admin flow from standalone Admin Feature: #{File.basename(admin_flow_path)}"
              if admin_final_status == 'passed'
                admin_promotion = promote_admin_flow(
                  admin_flow_path,
                  feature_report_path: admin_run_report_path,
                  feature_path: admin_feature_path,
                  run_status: admin_final_status
                )
                if admin_promotion[:ok]
                  log '[OK] Step 6/7: Admin flow promoted from independent Admin validation'
                else
                  flow_promotion_failed += 1
                  unless admin_promotion[:quarantined]
                    quarantine = quarantine_admin_flow(admin_flow_path, admin_promotion[:reason])
                    admin_promotion[:quarantine] = quarantine
                    admin_promotion[:quarantined] = quarantine[:quarantined]
                  end
                  warn "[FAIL] Step 6/7: #{admin_promotion[:reason]}"
                end
              else
                admin_promotion = quarantine_admin_flow(admin_flow_path, "Standalone Admin Feature status=#{admin_final_status}")
                warn "[WARN] Step 6/7: Admin flow kept quarantined (#{admin_final_status})"
              end
              admin_flow_finalized = true
            else
              info 'Step 6/7: Standalone Admin Feature was generated but not executed; new flow remains unsafe to reuse.'
              admin_flow_finalized = true
            end
          elsif admin_flow_path && admin_transform_ok
            info 'Step 6/7: Existing reviewed Admin flow checked against its standalone Admin Feature.'
          end
        else
          # Binary-only cases retain the assisted YAML transform, but they never
          # consume or merge an Admin flow.
          prompt = yaml_transform_prompt(yaml_path)
          cmd = build_opencode_command(prompt)
          binary_y_result = run_opencode(
            "Transform YAML: #{base_name}.yaml -> #{TARGET_DIR}",
            cmd,
            model_prompt: prompt,
            environment: conversion_permission_environment(
              read_roots: [File.dirname(yaml_path), AUTO_SKILL, STEP_INDEX, ODP_DOC_INDEX,
                           File.dirname(ODP_DOC_INDEX),
                           PAGE_EXPLORE_ROOT, SCRIPT_ROOT,
                           admin_flow_path && File.dirname(admin_flow_path)],
              edit_roots: [TARGET_DIR]
            )
          )
          conversion_results << binary_y_result
          if binary_y_result[:exit_code].to_i.zero?
            generated_feature_path = locate_generated_feature(
              base_name,
              nil,
              identifiers: yaml_identifiers(yaml_path),
              before: feature_snapshot,
              allow_changed_existing: false
            )
          end
          transform_failure_reason = if binary_y_result[:exit_code].to_i.zero?
                                       if generated_feature_path.nil?
                                         "no fresh Feature artifact found for #{base_name}"
                                       else
                                         conversion_failure_reason(
                                           binary_y_result,
                                           artifact_path: generated_feature_path,
                                           before_signature: feature_snapshot[File.expand_path(generated_feature_path)],
                                           require_fresh: true
                                         )
                                       end
                                     else
                                       conversion_failure_reason(binary_y_result)
                                     end
          non_admin_transform_ok = transform_failure_reason.nil?
          pipeline_failure_stage = 'non_admin_generation' unless non_admin_transform_ok
        end

        admin_validation_succeeded = !RUN_GENERATED || (
          admin_run_result && admin_run_result[:exit_code].to_i.zero?
        )
        admin_execution_passed = !RUN_GENERATED || (
          admin_run_result && admin_run_result[:exit_code].to_i.zero? &&
          admin_run_summary['status'] != 'preflight_only' && !PREFLIGHT_ONLY && !FEATURE_DRY_RUN
        )

        if detected_channel == 'hybrid' && admin_transform_ok && admin_validation_succeeded
          puts ""
          info 'Step 7/7: Generate independent non-Admin lifecycle artifact(s) after Admin validation.'
          non_admin_sources = find_binary_bases(
            yaml_path,
            flow_path: admin_flow_path,
            lifecycle: lifecycle
          )
          non_admin_generation = nil
          non_admin_failure = nil
          unless non_admin_sources.empty?
            validation = if lifecycle[:cross_day]
                           cross_day_feature_validation(non_admin_sources, yaml_path)
                         else
                           non_admin_feature_validation(non_admin_sources.first)
                         end
            non_admin_failure = validation[:reason] unless validation[:ok]
            non_admin_generation = { exit_code: 0, elapsed: 0.0, elapsed_formatted: '0.0s' }
          else
            non_admin_sources, non_admin_generation, non_admin_failure, = generate_hybrid_non_admin_features(
              yaml_path,
              base_name,
              lifecycle: lifecycle
            )
          end
          conversion_results << non_admin_generation if non_admin_generation
          if non_admin_failure.nil? && !non_admin_sources.empty?
            begin
              non_admin_feature_paths = persist_non_admin_features(
                non_admin_sources,
                base_name,
                lifecycle: lifecycle
              )
              non_admin_feature_path = non_admin_feature_paths.first
              generated_feature_path = non_admin_feature_path
              if lifecycle[:cross_day]
                legacy_combined = File.join(expanded_path(TARGET_DIR), "#{base_name}.feature")
                if File.file?(legacy_combined)
                  warn "Legacy combined Feature remains on disk but is excluded from this execution flow: #{legacy_combined}"
                end
              end
              execution_flow_path = build_hybrid_execution_flow(
                yaml_path: yaml_path,
                base_name: base_name,
                admin_feature_path: admin_feature_path,
                admin_flow_path: admin_flow_path,
                non_admin_feature_paths: non_admin_feature_paths,
                lifecycle: lifecycle,
                admin_run_result: admin_run_result,
                admin_run_summary: admin_run_summary,
                admin_run_report_path: defined?(admin_run_report_path) ? admin_run_report_path : nil
              )
              non_admin_transform_ok = true
              names = non_admin_feature_paths.map { |path| File.basename(path) }.join(', ')
              log "[OK] Independent non-Admin Feature artifact(s) generated: #{names}"
              log "[OK] Ordered execution flow generated: #{File.basename(execution_flow_path)}"
            rescue StandardError => e
              non_admin_failure = "could not persist non-Admin execution artifacts: #{e.class}: #{e.message}"
            end
          end
          if non_admin_failure
            non_admin_transform_ok = false
            pipeline_failure_stage = 'non_admin_generation'
            pipeline_failure_reason = "non-Admin Feature generation failed: #{non_admin_failure}"
            transform_failure_reason ||= "non-Admin Feature generation failed: #{non_admin_failure}"
            warn "[FAIL] #{transform_failure_reason}"
          end
        elsif detected_channel == 'hybrid' && admin_transform_ok
          info 'Step 7/7: Non-Admin generation withheld until the standalone Admin Feature passes.'
          pipeline_failure_stage ||= 'admin_feature_run'
          pipeline_failure_reason ||= 'standalone Admin Feature validation did not pass'
          transform_failure_reason ||= pipeline_failure_reason
        end

        transform_ok = admin_transform_ok && non_admin_transform_ok

        # Run Binary-only and Hybrid non-Admin artifacts independently.  The Admin
        # flow is intentionally not supplied to this repair path: Browser/Admin
        # evidence must not justify edits to FIX, batch, clearing, or Trading GUI
        # behavior.
        non_admin_execution_allowed = detected_channel != 'hybrid' || admin_execution_passed ||
                                      PREFLIGHT_ONLY || FEATURE_DRY_RUN
        if RUN_GENERATED && non_admin_transform_ok && generated_feature_path &&
           (admin_flow_path.nil? || detected_channel == 'hybrid') &&
           non_admin_execution_allowed
          if detected_channel == 'hybrid' && execution_flow_path
            execution_flow_outcome = execute_feature_flow(
              execution_flow_path,
              completed_gates: [],
              validation_only: FEATURE_DRY_RUN || PREFLIGHT_ONLY
            )
            non_admin_run_result = execution_flow_outcome[:last_result] || execution_flow_outcome[:results].last
            non_admin_run_summary = execution_flow_outcome[:last_summary] || execution_flow_outcome[:summaries].last || {}
            case execution_flow_outcome[:status]
            when 'passed', 'validation_passed'
              if FEATURE_DRY_RUN || PREFLIGHT_ONLY
                log '[OK] Every Feature in the execution flow passed non-mutating validation.'
              else
                log '[OK] Independent non-Admin execution flow completed.'
              end
            when 'waiting_for_gate'
              gate = execution_flow_outcome[:gate]
              warn "[WAIT] Day1 passed; execution flow is waiting for external gate #{gate}."
              info "Resume after the gate with: ruby #{BATCH_TRANSFORM_ENTRYPOINT} --run-execution-flow #{execution_flow_path} --complete-gate #{gate}"
            else
              pipeline_failure_stage = 'non_admin_feature_run'
              pipeline_failure_reason = execution_flow_outcome[:reason] || 'Non-Admin execution flow failed'
              warn "[FAIL] #{pipeline_failure_reason}"
            end
          else
            feature_to_run = non_admin_feature_path || generated_feature_path
            unless feature_to_run == admin_feature_path
            run_report_dir = FEATURE_RUN_REPORT_DIR && !FEATURE_RUN_REPORT_DIR.to_s.strip.empty? ?
              File.expand_path(FEATURE_RUN_REPORT_DIR) : File.join(TARGET_DIR, 'feature_run_reports')
            FileUtils.mkdir_p(run_report_dir)
            run_report_path = File.join(run_report_dir, "#{base_name}.json")
            feature_pipeline = run_generated_feature_pipeline(
              base_name,
              feature_to_run,
              run_report_path,
              admin_flow_path: nil,
              admin_flow_created: false,
              phase: detected_channel == 'hybrid' ? 'Step 7/7 Non-Admin validation' : 'Step 5/7 Feature validation'
            )
            non_admin_run_result = feature_pipeline[:final]
            non_admin_initial_run_result = feature_pipeline[:initial]
            non_admin_repair_run_result = feature_pipeline[:repair]
            non_admin_run_summary = feature_pipeline[:summary]
            if non_admin_run_result[:exit_code].to_i.zero?
              if non_admin_run_summary['status'] == 'preflight_only'
                log "[OK] Data preflight: #{File.basename(feature_to_run)} (Cucumber not run)"
              else
                log "[OK] Independent #{detected_channel == 'hybrid' ? 'non-Admin ' : ''}Feature passed: #{File.basename(feature_to_run)}"
              end
            else
              pipeline_failure_stage = 'non_admin_feature_run'
              pipeline_failure_reason = "Non-Admin Feature failed (exit: #{non_admin_run_result[:exit_code]})"
              if non_admin_run_summary['status'] == 'blocked_data' ||
                 non_admin_run_summary['repair_status'] == 'blocked_data' ||
                 non_admin_run_summary['category'] == 'runtime_data_unresolved'
                blockers = Array(non_admin_run_summary['blockers'])
                blocker_text = blockers.empty? ? 'unresolved runtime data' : blockers.join(', ')
                warn "[BLOCKED] Non-Admin Feature run: #{File.basename(feature_to_run)} (#{blocker_text})"
              else
                category = non_admin_run_summary['category'].to_s
                suffix = category.empty? ? '' : "; category: #{category}"
                warn "[FAIL] Non-Admin Feature run: #{File.basename(feature_to_run)} (exit: #{non_admin_run_result[:exit_code]}#{suffix})"
              end
            end
            end
          end
        end

        if admin_flow_path.nil?
          info 'Step 6/7: Admin flow validation not applicable to this Binary-only case.'
        end

        conversion_elapsed = conversion_results.compact.sum { |result| result[:elapsed].to_f }
        y_result = {
          exit_code: transform_ok ? 0 : 1,
          elapsed: conversion_elapsed,
          elapsed_formatted: format_elapsed(conversion_elapsed)
        }
        if transform_ok
          yaml_success += 1
          log "[OK] Success: #{base_name}.yaml (Duration: #{y_result[:elapsed_formatted]})"
        else
          yaml_failed += 1
          warn "[FAIL] Failed: #{base_name}.yaml (#{transform_failure_reason}; Duration: #{y_result[:elapsed_formatted]})"
        end

        run_result = non_admin_run_result || admin_run_result
        run_summary = non_admin_run_result ? non_admin_run_summary : admin_run_summary
        initial_run_result = non_admin_initial_run_result || admin_initial_run_result
        repair_run_result = non_admin_repair_run_result || admin_repair_run_result
        feature_run_status = 'not_requested'
        if RUN_GENERATED
          required_results = []
          required_results << admin_run_result if admin_flow_path
          required_results << non_admin_run_result if admin_flow_path.nil? || detected_channel == 'hybrid'
          if execution_flow_outcome && execution_flow_outcome[:status] == 'waiting_for_gate'
            feature_run_status = 'waiting_for_gate'
            feature_run_waiting += 1
          elsif execution_flow_outcome && execution_flow_outcome[:status] == 'failed'
            feature_run_status = 'failed'
            feature_run_failed += 1
          elsif required_results.compact.any? { |result| !result[:exit_code].to_i.zero? }
            feature_run_status = 'failed'
            feature_run_failed += 1
          elsif [admin_run_summary, non_admin_run_summary].any? { |summary| summary['status'] == 'preflight_only' }
            feature_run_status = 'preflight_only'
            feature_run_success += 1
          elsif required_results.any?(&:nil?)
            feature_run_status = 'skipped'
            feature_run_skipped += 1
          else
            feature_run_status = 'passed'
            feature_run_success += 1
          end
        end

        all_results << {
          excel_file: File.basename(excel_path),
          yaml_file: "#{base_name}.yaml",
          excel_elapsed: e_result[:elapsed],
          excel_elapsed_fmt: e_result[:elapsed_formatted],
          yaml_elapsed: y_result[:elapsed],
          yaml_elapsed_fmt: y_result[:elapsed_formatted],
          excel_ok: true,
          yaml_ok: transform_ok,
          channel: admin_flow_path ? (detected_channel || TRANSFORM_CHANNEL) : 'binary',
          execution_channels: execution_channels,
          admin_flow: admin_flow_path,
          admin_flow_created: admin_flow_created_this_run,
          admin_exploration: admin_exploration,
          admin_promotion: admin_promotion,
          generated_feature: generated_feature_path,
          generated_features: ([admin_feature_path] + non_admin_feature_paths).compact,
          admin_feature: admin_feature_path,
          non_admin_feature: non_admin_feature_path,
          non_admin_features: non_admin_feature_paths,
          execution_flow: execution_flow_path,
          execution_flow_status: execution_flow_outcome && execution_flow_outcome[:status],
          admin_feature_run_status: admin_run_result && admin_run_summary['status'],
          non_admin_feature_run_status: non_admin_run_result && non_admin_run_summary['status'],
          feature_run_status: feature_run_status,
          feature_run_category: run_result && run_summary['category'],
          feature_run_blockers: run_result && run_summary['blockers'],
          feature_run_ok: feature_run_status == 'passed',
          feature_run_exit_code: run_result && run_result[:exit_code],
          feature_run_elapsed: run_result && run_result[:elapsed],
          feature_run_report: run_result && run_result[:report],
          feature_initial_run_report: initial_run_result && initial_run_result[:report],
          feature_repair_run_report: repair_run_result && repair_run_result[:report],
          admin_alignment_run_report: admin_alignment_run_result && admin_alignment_run_result[:report],
          failure_stage: pipeline_failure_stage,
          failure_reason: pipeline_failure_reason || transform_failure_reason
        }
        puts ""
      end

      # --- Final Summary ---
      total_excel = excel_success + excel_failed
      total_yaml = yaml_success + yaml_failed
      # Use wall-clock pipeline time so Admin exploration, Feature execution,
      # repair, catalog refresh, and deterministic parsing are not silently
      # omitted from the final total.
      grand_total_time = Process.clock_gettime(Process::CLOCK_MONOTONIC) - pipeline_started_at
      grand_formatted = format_elapsed(grand_total_time)
      avg_formatted = all_results.length > 0 ? format_elapsed(grand_total_time / all_results.length) : "0.0s"

      puts ""
      puts "#{BOLD}#{'=' * 70}#{RESET}"
      puts "#{BOLD}  All Done - Final Summary#{RESET}"
      puts "#{BOLD}#{'=' * 70}#{RESET}"
      puts ""
      puts "  #{BOLD}Per-Case Detail:#{RESET}"
      puts "  #{'-' * 60}"
      puts "  #{'#'.ljust(4)} #{'Test Case'.ljust(22)} #{'X->Y'.ljust(10)} #{'Y->T'.ljust(10)} #{'Status'}"
      puts "  #{'-' * 60}"

      all_results.each_with_index do |r, idx|
        x_str = r[:excel_ok] ? r[:excel_elapsed_fmt] : "FAILED"
        y_str = if r[:yaml_ok].nil?
                  'SKIPPED'
                else
                  r[:yaml_ok] ? r[:yaml_elapsed_fmt] : (r[:excel_ok] ? 'FAILED' : 'SKIPPED')
                end
        status = if r[:yaml_ok].nil?
                   r[:excel_ok] ? "#{GREEN}[YAML-OK]#{RESET}" : "#{RED}[EXCEL-FAIL]#{RESET}"
                 else
                   if !r[:excel_ok]
                     "#{RED}[EXCEL-FAIL]#{RESET}"
                   elsif r[:failure_stage] == 'admin_exploration'
                     "#{RED}[ADMIN-FAIL]#{RESET}"
                   elsif r[:failure_stage] == 'admin_flow_required'
                     "#{RED}[ADMIN-FLOW-FAIL]#{RESET}"
                   elsif r[:failure_stage] == 'admin_feature_consistency'
                     "#{RED}[ADMIN-MISMATCH]#{RESET}"
                   elsif r[:failure_stage] == 'admin_feature_generation'
                     "#{RED}[ADMIN-CONVERT-FAIL]#{RESET}"
                   elsif r[:failure_stage] == 'admin_feature_run'
                     "#{RED}[ADMIN-RUN-FAIL]#{RESET}"
                   elsif r[:failure_stage] == 'non_admin_generation'
                     "#{RED}[NONADMIN-FAIL]#{RESET}"
                   elsif !r[:yaml_ok]
                     "#{RED}[YAML-FAIL]#{RESET}"
                   elsif RUN_GENERATED && r[:feature_run_status] == 'failed'
                     category = r[:feature_run_category].to_s
                     if category == 'review_blocked'
                       "#{RED}[REVIEW-BLOCKED]#{RESET}"
                     elsif category == 'admin_mcp_behavior_mismatch'
                       "#{RED}[ADMIN-MISMATCH]#{RESET}"
                     else
                       "#{RED}[RUN-FAIL]#{RESET}"
                     end
                   elsif RUN_GENERATED && r[:feature_run_status] == 'skipped'
                     "#{YELLOW}[RUN-SKIPPED]#{RESET}"
                   elsif RUN_GENERATED && r[:feature_run_status] == 'waiting_for_gate'
                     "#{YELLOW}[WAIT-GATE]#{RESET}"
                   elsif RUN_GENERATED && r[:feature_run_status] == 'preflight_only'
                     "#{YELLOW}[PREFLIGHT]#{RESET}"
                   else
                     "#{GREEN}[OK]#{RESET}"
                   end
                 end
        name = r[:excel_file][0, 22]
        puts "  #{format('%2d', idx + 1)}. #{name.ljust(22)} #{x_str.ljust(10)} #{y_str.ljust(10)} #{status}"
      end

      puts "  #{'-' * 60}"
      puts ""
      puts "  Excel -> YAML:  #{GREEN}#{excel_success}#{RESET} succeeded, #{RED}#{excel_failed}#{RESET} failed"
      if YAML_ONLY
        puts "  YAML Transform: #{YELLOW}skipped (--yaml-only)#{RESET}"
      else
        puts "  YAML Transform: #{GREEN}#{yaml_success}#{RESET} succeeded, #{RED}#{yaml_failed}#{RESET} failed"
      end
      if RUN_GENERATED
        puts "  Feature Run:    #{GREEN}#{feature_run_success}#{RESET} passed, #{RED}#{feature_run_failed}#{RESET} failed, #{YELLOW}#{feature_run_skipped}#{RESET} skipped, #{YELLOW}#{feature_run_waiting}#{RESET} waiting"
      end
      puts "  #{'Total Time'.ljust(40)} #{grand_formatted}"
      puts "  #{'Avg Per Case'.ljust(40)} #{avg_formatted}"
      puts ""

      # Fix directory permissions
      info "Ensuring access rights for opencode under #{TARGET_DIR}..." if VERBOSE_MODEL_OUTPUT
      begin
        FileUtils.chmod_R(0o700, TARGET_DIR)
      rescue StandardError => e
        error "Could not make output directory private: #{e.message}"
        return 1
      end
      log "Access rights updated." if VERBOSE_MODEL_OUTPUT

      puts ""
      info "All done! Check #{TARGET_DIR} for results."
      # A conversion failure is fatal even when Feature execution was not
      # requested.  Otherwise a broken Excel/YAML pipeline can return success and
      # be mistaken for a valid generated artifact in CI.
      return 1 if excel_failed.positive? || (!YAML_ONLY && yaml_failed.positive?)
      return 1 if RUN_GENERATED && (feature_run_failed.positive? || feature_run_skipped.positive?)
      return 1 if flow_promotion_failed.positive?
      return 3 if RUN_GENERATED && feature_run_waiting.positive?
      0
    end
  end
end
