# frozen_string_literal: true

# Process boundary to the single v2 compiler. Ruby orchestrates; Python owns
# bindings, operation mappings, evidence and exact Feature contracts.
module BatchTransform
  module Admin
    module Contracts
      private

      def write_json_atomic(path, payload)
        raise "refusing to overwrite symlink: #{path}" if File.symlink?(path)
        FileUtils.mkdir_p(File.dirname(File.expand_path(path)))
        temporary = "#{path}.tmp-#{Process.pid}-#{SecureRandom.hex(4)}"
        begin
          File.write(temporary, JSON.pretty_generate(payload) + "\n", mode: 'w', perm: 0o600)
          File.rename(temporary, path)
        ensure
          File.delete(temporary) if File.exist?(temporary)
        end
      end

      def json_object_at(path, label)
        raise "#{label} missing or unsafe: #{path}" unless readable_artifact?(path)
        value = JSON.parse(File.read(path, encoding: 'UTF-8'))
        raise "#{label} must be an object" unless value.is_a?(Hash)
        value
      end

      def yaml_test_step_blocks(path)
        CaseSource.new(path).steps.map { |step| { index: step['index'], text: step['raw'].to_yaml } }
      end

      def yaml_admin_step_blocks(path)
        CaseSource.new(path).steps.select { |step| step['channel'] == 'admin_gui' }
                  .map { |step| { index: step['index'], text: step['raw'].to_yaml } }
      end

      def yaml_admin_step_text(path)
        CaseSource.new(path).steps.select { |s| s['channel'] == 'admin_gui' }
                  .flat_map { |s| [s['step'], s['testdata'], s['expected']] }.join("\n")
      end

      def compact_admin_transcript_error(value, max_chars: 900)
        redact_batch(value).to_s.gsub(/\e\[[0-9;]*[A-Za-z]/, '').gsub(/\s+/, ' ').strip[0, max_chars]
      end

      def admin_compile(*arguments)
        command = [PYTHON_BIN, ADMIN_CONVERTER, '--step-index', STEP_INDEX,
                   '--page-explore-root', PAGE_EXPLORE_ROOT, *arguments]
        stdout, stderr, status = Open3.capture3(opencode_environment, *command)
        { ok: status.success?, output: stdout, reason: compact_admin_transcript_error(stderr.empty? ? stdout : stderr),
          payload: (JSON.parse(stdout.lines.last.to_s) rescue {}) }
      end

      def reusable_admin_flow_case_issues(path, yaml_path)
        result = admin_compile('--flow', path, '--yaml', yaml_path, '--validate-only', '--require-evidence')
        result[:ok] ? [] : [result[:reason]]
      end

      def workspace_reference(path)
        absolute = File.expand_path(path)
        path_within?(absolute, Dir.pwd) ? absolute.delete_prefix("#{Dir.pwd}/") : absolute
      end

      def refresh_admin_flow_catalog
        flow_dir = File.expand_path(ADMIN_FLOW_DIR)
        root = File.basename(flow_dir) == 'flows' ? File.dirname(flow_dir) : flow_dir
        stdout, stderr, status = Open3.capture3(opencode_environment, PYTHON_BIN,
          File.join(SCRIPT_ROOT, 'tools/build_admin_flow_catalog.py'), '--catalog', root,
          '--flows-dir', flow_dir, '--output-json', File.join(root, 'INDEX.json'), '--output-md', File.join(root, 'INDEX.md'))
        { ok: status.success?, index: File.join(root, 'INDEX.json'), reason: compact_admin_transcript_error(stderr) }
      end

      def quarantine_admin_flow(path, reason)
        flow = json_object_at(path, 'Admin flow')
        flow['reuse']['safe_to_reuse'] = false
        flow['reuse']['failure'] = compact_admin_transcript_error(reason)
        write_json_atomic(path, flow)
        catalog = refresh_admin_flow_catalog
        { ok: catalog[:ok], quarantined: true, catalog: catalog }
      rescue StandardError => e
        { ok: false, quarantined: false, reason: e.message }
      end

      def promote_admin_flow(path, feature_report_path:, feature_path:, run_status:)
        raise 'only a passed execution may promote an Admin flow' unless run_status == 'passed'
        result = admin_compile('--flow', path, '--verify-feature', feature_path)
        raise result[:reason] unless result[:ok]
        flow = json_object_at(path, 'Admin flow')
        report = json_object_at(feature_report_path, 'Feature report')
        raise 'Feature execution did not pass' unless report.dig('execution', 'status') == 'passed'
        counts = report.dig('execution', 'cucumber_summary') || {}
        raise 'Feature report must prove all compiled steps passed' unless counts['total'].to_i == flow['background'].length + flow['steps'].length &&
          counts['passed'].to_i == counts['total'].to_i && %w[failed skipped pending undefined].all? { |k| counts[k].to_i.zero? }
        raise 'dry-run cannot promote a flow' if Array(report.dig('execution', 'command')).include?('--dry-run')
        raise 'Feature report path mismatch' unless File.expand_path(report.dig('feature', 'path').to_s) == File.expand_path(feature_path)
        actual = Digest::SHA256.file(feature_path).hexdigest
        raise 'Feature report hash missing or stale' unless report.dig('feature', 'sha256') == actual
        raise 'browser evidence is not verified' unless flow['evidence_status'] == 'verified' &&
                                                        flow.dig('evidence', 'contract_sha256') == flow['contract_sha256']
        flow['reuse'] = flow.fetch('reuse').merge('safe_to_reuse' => true,
          'feature_sha256' => actual, 'report_sha256' => Digest::SHA256.file(feature_report_path).hexdigest,
          'contract_sha256' => flow['contract_sha256'], 'promoted_at' => Time.now.utc.iso8601)
        write_json_atomic(path, flow)
        catalog = refresh_admin_flow_catalog
        unless catalog[:ok]
          quarantine_admin_flow(path, catalog[:reason])
          raise catalog[:reason]
        end
        { ok: true, path: path, catalog: catalog[:index] }
      rescue StandardError => e
        { ok: false, reason: e.message }
      end
    end
  end
end
