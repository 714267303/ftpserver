# frozen_string_literal: true

module BatchTransform
  module Admin
    module Prompt
      private

      def admin_plan_prompt(yaml_path:, plan_path:, issue: nil)
        example = {
          schema_version: 2, kind: 'admin_plan', flow_id: "admin.#{safe_admin_slug(primary_yaml_identifier(yaml_path)).downcase}.v2",
          case_id: primary_yaml_identifier(yaml_path), name: '<business purpose>', channel: transform_channel_from_yaml(yaml_execution_channels(yaml_path)),
          parameters: {
            record: { origin: 'yaml', step: 1, field: 'testdata', key: '<exact Test Data key>' },
            user: { origin: 'dataset', alias: 'admin_gui_user1' },
            password: { origin: 'dataset', alias: 'admin_gui_user1_password' }
          },
          sessions: { maker: { role: 'maker', browser: 'browser_admin_gui_user1', user: {param: 'user'}, password: {param: 'password'} } },
          actions: [
            {id: 'navigate', operation: 'navigate', session: 'maker', phase: 'shared', page: '/UI/<documented route>', source_steps: [1], args: {}},
            {id: 'search', operation: 'search', session: 'maker', phase: 'shared', page: '/UI/<documented route>', source_steps: [1],
             subject: {'<record field>' => {param: 'record'}}, args: {fields: {'<record field>' => {param: 'record'}}}}
          ],
          cleanup: {action: 'none'}, keywords: []
        }
        <<~TEXT
          Build a version 2 Admin business plan for '#{yaml_path}'. Write only '#{plan_path}'.
          Read '#{File.join(AUTO_SKILL, 'Admin_GUI', 'Admin_Pipeline_V2.md')}',
          '#{File.join(AUTO_SKILL, 'Admin_GUI', 'flow_catalog', 'schema.json')}',
          the relevant PageExplore sitemap/profile under '#{PAGE_EXPLORE_ROOT}',
          and the operation adapters '#{File.join(SCRIPT_ROOT, 'tools', 'admin_flow', 'operations.py')}'.
          Read Step_Index '#{STEP_INDEX}' only to confirm the adapter exists in the runtime.
          Use '#{ODP_DOC_INDEX}' for business meaning when required.
          Do not use a browser, shell, credentials, network, or write any .rb file.
          The plan contains business operations, not Gherkin text or locator code. Cover every
          admin_gui YAML step in order. Exclude Binary/Trading/clearing/batch steps.
          Use current Test Data as the only source for explicit business IDs/values. Define
          parameters with origin=yaml and key, or an exact text span for prose/table input.
          Assertions may select field=expected from the corresponding Expected Result;
          these parameters cannot supply record identity or mutation values.
          Every record identity and variable field value must use {"param":"name"}.
          When Test Data supplies no record, use origin=observation; MCP will discover it.
          Session users/passwords must reference origin=dataset aliases, never literal credentials.
          Fields, detail titles, effective type, and expected values must follow the source intent.
          Use multiple page routes when the case navigates between pages; each action owns its route.
          A maker change requires set_fields, optional effective_date, submit and Feature-only
          approve in a separate checker session, followed by requested verification. Shared actions
          are replayed by MCP. Approve and post-approval checks have phase=feature. Cleanup is
          reject with a checker session when submitting, cancel before save for forms without
          countersign, or none for a read-only case. Cleanup is never a Feature operation.
          For forms without countersign, use phase=feature commit for the persistent Save,
          and MCP cancels the edited form after validating the shared fields.
          This read-only search example demonstrates JSON structure; replace its actions and
          parameters with the complete current case, do not copy its limited business coverage:
          #{JSON.pretty_generate(example)}
          #{issue ? "Correct the existing plan using this deterministic diagnostic: #{issue}" : ''}
        TEXT
      end

      def admin_exploration_prompt(yaml_path:, case_id:, channel:, candidate_path:, report_path:, evidence_dir:, odp_url: nil,
                                   project_root: Dir.pwd, dotenv_path: nil)
        <<~TEXT
          Run the already-compiled Admin plan for '#{case_id}' from '#{candidate_path}'.
          The current YAML is '#{yaml_path}'. Read the plan, bindings, actions, identity and sessions
          in that file and '#{File.join(AUTO_SKILL, 'Admin_GUI', 'Admin_Pipeline_V2.md')}' first.
          Navigate only through configured Playwright MCP. Before navigation read
          '#{File.join(PAGE_EXPLORE_ROOT, 'sitemap.md')}', the relevant profile and
          '#{File.join(PAGE_EXPLORE_ROOT, 'GRID_OPERATION_GUIDE.md')}' when using a grid.
          Start at '#{odp_url}ESUI/eventServerLanding.html'. Read exactly '#{dotenv_path}' for
          ODP_USERNAME/ODP_PASSWORD and ODP_CHECKER_USERNAME/ODP_CHECKER_PASSWORD (SECRET_ aliases
          are supported). Use actual credentials privately in visible UI login fields. Key names
          are not substituted by --secrets. Use separate maker/checker sessions. Never expose
          credentials in reports, observations, console output, or plan/bindings.
          Use stable visible role/name/label or documented ID locators via browser_run_code_unsafe.
          Snapshot refs are not action targets. Observe after navigation or state-changing actions;
          related field fills in the same form may be batched before the next snapshot.
          Do not use shell, direct backend requests, window.fetch/XMLHttpRequest overrides or
          qaGrid mutation. Read-only qaGrid observations and documented UI interactions are allowed.
          Execute only phase=shared actions, in order, with the compiled bindings. Never Approve.
          If a parameter origin is observation, discover it through read-only UI, write the value
          to '#{File.join(evidence_dir, 'admin-observations.json')}', and use it consistently for
          subject and fields. Never replace an explicit YAML-sourced value. Record all shared
          actions and cleanup using ODP_ADMIN_EVENT in completed tool OUTPUT as documented.
          Evidence must contain the exact plan/source hashes from the compiled identity, action ID,
          operation, session, observed route from the browser, subject, and actual UI fields/state.
          Emit status=passed only after awaited UI actions and assertions complete; do not emit an
          observation merely because the script contains an action. No input-code keyword is proof.
          Capture baseline active fields before the first mutation of each record. Submit pending
          maker requests, locate them as checker, Reject/confirm, verify no pending request and
          restore baseline fields. For non-countersign forms Cancel before persistent Save.
          Record separate session observations with authenticated=true and distinct context_id
          labels (local browser labels, never cookies). Include request_id on Submit and Reject
          observations, using the SHA-256 of the same observed UI request reference (never
          print its raw UUID; redaction would destroy the identity). Baseline must show no pre-existing
          pending request and include the record identity and every edited active field.
          Cleanup is mandatory after an intermediate failure too. Reserve time for cleanup; if
          cleanup cannot be proven, report failed with cleanup_completed=false and the concrete stage.
          Do not edit the plan or compiled admin-flow.json. After evidence collection write
          '#{report_path}' with schema_version=2, kind=admin_exploration, case_id='#{case_id}',
          status=passed or failed and first_failure {stage,reason} for a failure. The runner validates
          evidence and writes admin-flow.json and admin-evidence.json itself. Do not calculate or
          fabricate report success counters. Raw artifacts must stay in '#{evidence_dir}'.
        TEXT
      end

      def build_admin_exploration_command(prompt)
        configured = ADMIN_EXPLORE_COMMAND.to_s.strip
        configured = 'opencode run --thinking --format json' if configured.empty?
        tokens = Shellwords.split(configured)
        raise ArgumentError, 'Admin exploration command is empty' if tokens.empty?
        forbidden = tokens.select do |token|
          token.to_s.match?(/\A--(?:pure|auto|dangerously-skip-permissions)(?:=|\z)/)
        end
        unless forbidden.empty?
          raise ArgumentError, "Admin exploration command cannot use #{forbidden.join(', ')}"
        end
        tokens = append_opencode_model(tokens)
        replaced = false
        tokens = tokens.map do |token|
          if token.include?('{prompt}')
            replaced = true
            token.gsub('{prompt}', prompt)
          else
            token
          end
        end
        tokens << prompt unless replaced
        Shellwords.join(tokens)
      end

      def admin_exploration_environment(read_roots:, edit_roots:, evidence_dir:)
        project_root = expanded_path(Dir.pwd)
        dotenv_path = playwright_mcp_secrets_path
        environment = conversion_permission_environment(
          read_roots: [project_root, dotenv_path, *Array(read_roots)],
          edit_roots: edit_roots
        )
        config = JSON.parse(environment.fetch('OPENCODE_CONFIG_CONTENT'))
        permission = config.fetch('permission')
        # Admin exploration is the one model stage allowed to inspect runtime
        # configuration, including ProjectA/.env. The model reads the selected file
        # before login and uses its ODP credentials only as browser fill values. The
        # external-directory policy still limits access to the runtime project and
        # the explicitly configured dotenv path; edit permissions remain scoped to
        # this run's evidence directory.
        permission['read'] = {
          '*' => 'allow',
          '.git/**' => 'deny'
        }
        # OpenCode names local MCP tools after their server/tool pair.  Keep a
        # wildcard for both the current `playwright_*` names and future capabilities,
        # while bash/execute remain denied by the base permission overlay.
        permission['playwright_*'] = 'allow'
        permission['mcp.playwright.*'] = 'allow'
        permission['mcp'] = 'allow'
        # Snapshot refs are tied to one transient accessibility-tree generation and
        # proved unreliable across React renders. Keep snapshots for observation,
        # explicitly allow raw Playwright locators, and make stale-ref actions
        # impossible in the Admin model environment.
        permission['playwright_browser_run_code_unsafe'] = 'allow'
        %w[click type fill_form select_option hover drag].each do |action|
          permission["playwright_browser_#{action}"] = 'deny'
          permission["mcp.playwright.browser_#{action}"] = 'deny'
        end

        configured_output_dir = PLAYWRIGHT_MCP_OUTPUT_DIR.to_s.strip
        output_dir = if configured_output_dir.empty?
                       File.join(evidence_dir, 'playwright')
                     else
                       # Treat the configured value as a base, then isolate every
                       # case/run below it.  A shared MCP output directory otherwise
                       # lets traces from two cases be mistaken for one another.
                       File.join(expanded_path(configured_output_dir), safe_admin_slug(File.basename(evidence_dir)))
                     end
        output_dir = expanded_path(output_dir)
        FileUtils.mkdir_p(output_dir)
        FileUtils.chmod_R(0o700, output_dir)

        server_command = playwright_mcp_server_command(output_dir)
        if server_command
          config['mcp'] = {
            'playwright' => {
              'type' => 'local',
              'command' => Shellwords.split(server_command),
              'cwd' => Dir.pwd,
              'enabled' => true,
              'timeout' => 120_000
            }
          }
        elsif (existing = existing_playwright_mcp_entry)
          # Reuse an installed project MCP entry when its CLI path is not one of the
          # conventional offline locations.  Normalize the headless switch here so
          # --playwright-mcp-headed works even with the installer's historical
          # `--headless` template.
          config['mcp'] = {'playwright' => normalize_existing_playwright_entry(existing[1], output_dir)}
        end
        environment['OPENCODE_CONFIG_CONTENT'] = JSON.generate(config)

        project_config = opencode_config_path_for(Dir.pwd)
        environment['OPENCODE_CONFIG'] = project_config if project_config
        # This is deliberately the only ODP value exposed through the model process
        # environment. It is navigation configuration, not a credential; login
        # values are read from the selected dotenv file with the model file tool and
        # are also registered with the transcript/terminal redactor by the caller.
        odp_url = configured_odp_url
        environment['ODP_URL'] = odp_url if odp_url
        unless PLAYWRIGHT_MCP_HEADLESS
          display = headed_display
          environment['DISPLAY'] = display if display
        end
        environment['PLAYWRIGHT_MCP_IGNORE_HTTPS_ERRORS'] = ENV.fetch(
          'PLAYWRIGHT_MCP_IGNORE_HTTPS_ERRORS', '1'
        )
        environment
      rescue JSON::ParserError => e
        raise "cannot construct OpenCode exploration permissions: #{e.message}"
      end
    end
  end
end
