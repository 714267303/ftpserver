# frozen_string_literal: true

module BatchTransform
  module Admin
    module Exploration
      private

      def create_admin_plan(yaml_path, plan_path, run_dir)
        issue = nil
        2.times do |attempt|
          prompt = admin_plan_prompt(yaml_path: yaml_path, plan_path: plan_path, issue: issue)
          tokens = Shellwords.split(ADMIN_PLAN_COMMAND.to_s.empty? ? OPENCODE_CONVERSION_COMMAND : ADMIN_PLAN_COMMAND)
          tokens = append_opencode_model(tokens)
          tokens << prompt
          environment = conversion_permission_environment(
            read_roots: [File.dirname(yaml_path), AUTO_SKILL, STEP_INDEX, ODP_DOC_INDEX, PAGE_EXPLORE_ROOT,
                         File.join(SCRIPT_ROOT, 'tools/admin_flow')], edit_roots: [plan_path])
          environment.merge!('ADMIN_PLAN_PATH' => plan_path, 'ADMIN_PLAN_YAML' => File.expand_path(yaml_path))
          result = run_opencode("Admin plan #{attempt + 1}/2", Shellwords.join(tokens), retry_on_hang: false,
            environment: environment, timeout_seconds: 300, total_timeout_seconds: 600,
            capture_path: File.join(run_dir, "plan-events-#{attempt + 1}.jsonl"), model_prompt: prompt)
          raise 'Admin plan generation failed' unless result[:exit_code].to_i.zero? && readable_artifact?(plan_path)
          compiled = admin_compile('--plan', plan_path, '--yaml', File.expand_path(yaml_path), '--draft',
            '--output-flow', File.join(run_dir, 'admin-flow.json'))
          return if compiled[:ok]
          issue = compiled[:reason]
          warn "Admin plan needs correction before browser execution: #{issue}"
        end
        raise "Admin plan validation failed before MCP: #{issue}"
      end

      def run_admin_exploration(yaml_path:, case_id:, channel:)
        error = admin_mcp_preflight_error
        raise error if error
        custom = !ADMIN_EXPLORE_COMMAND.to_s.empty?
        raise 'headed Playwright MCP requires DISPLAY' if !custom && !PLAYWRIGHT_MCP_HEADLESS && headed_display.nil?
        odp_url = configured_odp_url
        raise odp_url_configuration_error unless odp_url || custom
        unless custom
          missing = playwright_mcp_missing_login_secret_keys(require_checker: yaml_requests_final_approval?(yaml_path))
          raise "Missing login keys: #{missing.join(', ')}" unless missing.empty?
        end
        run_dir = File.join(File.expand_path(ADMIN_EVIDENCE_ROOT), safe_admin_slug(case_id),
          "run-#{Time.now.utc.strftime('%Y%m%dT%H%M%SZ')}-#{Process.pid}-#{SecureRandom.hex(3)}")
        FileUtils.mkdir_p(run_dir)
        File.chmod(0o700, run_dir)
        plan_path = File.join(run_dir, 'admin-plan.json')
        create_admin_plan(yaml_path, plan_path, run_dir)
        plan = json_object_at(plan_path, 'Admin plan')
        raise 'plan channel differs from the case classification' unless plan['channel'] == channel
        candidate_path = File.join(run_dir, 'admin-flow.json')
        report_path = File.join(run_dir, 'exploration-report.json')
        write_json_atomic(report_path, {'schema_version'=>2, 'kind'=>'admin_exploration', 'status'=>'running',
          'case_id'=>case_id, 'source_yaml_sha256'=>CaseSource.new(yaml_path).sha256})
        environment = admin_exploration_environment(
          read_roots: [run_dir, File.dirname(yaml_path), AUTO_SKILL, STEP_INDEX, ODP_DOC_INDEX, PAGE_EXPLORE_ROOT],
          edit_roots: [report_path, File.join(run_dir, 'admin-observations.json'), File.join(run_dir, 'playwright')],
          evidence_dir: run_dir)
        environment.merge!(
          'ADMIN_EXPLORATION_CASE_ID'=>case_id, 'ADMIN_EXPLORATION_CHANNEL'=>channel,
          'ADMIN_EXPLORATION_YAML'=>File.expand_path(yaml_path), 'ADMIN_EXPLORATION_FLOW_PATH'=>candidate_path,
          'ADMIN_EXPLORATION_PLAN_PATH'=>plan_path, 'ADMIN_EXPLORATION_REPORT_PATH'=>report_path,
          'ADMIN_EXPLORATION_EVIDENCE_DIR'=>run_dir, 'ADMIN_EXPLORATION_ODP_URL'=>odp_url.to_s)
        prompt = admin_exploration_prompt(yaml_path: File.expand_path(yaml_path), case_id: case_id, channel: channel,
          candidate_path: candidate_path, report_path: report_path, evidence_dir: run_dir,
          odp_url: odp_url, dotenv_path: playwright_mcp_secrets_path)
        result = run_opencode("Playwright MCP Admin exploration: #{case_id}", build_admin_exploration_command(prompt),
          retry_on_hang: false, environment: environment, timeout_seconds: ADMIN_EXPLORE_TIMEOUT,
          total_timeout_seconds: ADMIN_EXPLORE_TIMEOUT, capture_path: File.join(run_dir, 'opencode-events.jsonl'),
          model_prompt: prompt, sensitive_values: playwright_mcp_login_secret_values)
        raise "Admin MCP exited #{result[:exit_code]}; inspect rollback status before rerunning" unless result[:exit_code].to_i.zero?
        finalize_admin_plan(yaml_path, case_id, channel, run_dir).merge(result: result)
      rescue StandardError => e
        admin_failed_run(defined?(run_dir) ? run_dir : nil, e.message)
      end

      def finalize_admin_plan(yaml_path, case_id, channel, run_dir)
        plan_path = File.join(run_dir, 'admin-plan.json')
        report_path = File.join(run_dir, 'exploration-report.json')
        report = json_object_at(report_path, 'Admin exploration report')
        raise 'MCP did not complete: ' + report.fetch('first_failure', {}).to_s unless report['status'] == 'passed'
        raise 'MCP report must be schema_version=2' unless report['schema_version'] == 2
        raise 'MCP report case mismatch' unless report['case_id'] == case_id
        source_sha = CaseSource.new(yaml_path).sha256
        recorded_sha = report['source_yaml_sha256']
        raise 'YAML changed since this browser run' if recorded_sha && recorded_sha != source_sha
        plan = json_object_at(plan_path, 'Admin plan')
        raise 'plan channel mismatch' unless plan['channel'] == channel
        # Evidence is bound to the source and plan hashes in every completed browser event.
        # Neither a failed report nor missing evidence can be converted into success here.
        output = File.join(run_dir, 'admin-flow.json')
        args = ['--plan', plan_path, '--yaml', File.expand_path(yaml_path), '--output-flow', output,
                '--transcript', File.join(run_dir, 'opencode-events.jsonl'), '--exploration-report', report_path]
        observations = File.join(run_dir, 'admin-observations.json')
        args += ['--observations', observations] if readable_artifact?(observations)
        result = admin_compile(*args)
        raise result[:reason] unless result[:ok]
        flow = json_object_at(output, 'Compiled Admin flow')
        write_json_atomic(File.join(run_dir, 'admin-evidence.json'), flow['evidence'])
        destination = File.join(File.expand_path(ADMIN_FLOW_DIR), "#{flow['flow_id']}.#{flow['contract_sha256'][0, 16]}.json")
        write_json_atomic(destination, flow)
        write_json_atomic(File.join(run_dir, 'handoff-report.json'),
          {'schema_version'=>2, 'status'=>'passed', 'source_yaml_sha256'=>source_sha,
           'contract_sha256'=>flow['contract_sha256'], 'flow_path'=>destination})
        catalog = refresh_admin_flow_catalog
        raise catalog[:reason] unless catalog[:ok]
        {ok: true, flow_path: destination, run_dir: run_dir, report: report_path,
         transcript: File.join(run_dir, 'opencode-events.jsonl'), manifest: flow}
      end

      def recover_admin_exploration_handoff(yaml_path:, case_id:, channel:, run_dir:)
        finalize_admin_plan(yaml_path, case_id, channel, File.expand_path(run_dir)).merge(recovered_handoff: true)
      rescue StandardError => e
        admin_failed_run(File.expand_path(run_dir), e.message)
      end

      def admin_failed_run(run_dir, reason)
        if run_dir && File.directory?(run_dir)
          write_json_atomic(File.join(run_dir, 'handoff-report.json'),
            {'schema_version'=>2, 'status'=>'failed', 'reason'=>compact_admin_transcript_error(reason), 'browser_rerun'=>false})
        end
        {ok: false, reason: compact_admin_transcript_error(reason), run_dir: run_dir, browser_rerun: false}
      end
    end
  end
end
