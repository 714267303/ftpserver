# frozen_string_literal: true

# Admin YAML classification, dotenv discovery, and Playwright MCP configuration.

module BatchTransform
  module Admin
    module Configuration
      private

      def yaml_requests_final_approval?(yaml_path)
        yaml_admin_step_text(yaml_path).match?(ADMIN_APPROVAL_REQUEST_PATTERN)
      end

      def expanded_path(path)
        File.expand_path(path.to_s)
      end

      def path_within?(path, root)
        child = expanded_path(path)
        parent = expanded_path(root)
        child == parent || child.start_with?("#{parent}#{File::SEPARATOR}")
      end

      def safe_admin_slug(value)
        slug = value.to_s.encode('UTF-8', invalid: :replace, undef: :replace, replace: '_')
        slug = slug.gsub(/[^A-Za-z0-9_.-]+/, '_').sub(/\A\.+/, '')
        slug = 'case' if slug.empty?
        slug[0, 120]
      end

      def primary_yaml_identifier(yaml_path)
        identifiers = yaml_identifiers(yaml_path)
        preferred = identifiers.find { |item| item.match?(/\A(?:ODP|TC)[A-Za-z0-9_.:-]*\z/i) }
        return preferred unless preferred.to_s.empty?

        fallback = identifiers.find { |item| item.match?(/\A[A-Za-z0-9][A-Za-z0-9_.:-]*\z/) }
        fallback || safe_admin_slug(File.basename(yaml_path, '.yaml'))
      end

      def command_executable(name)
        value = name.to_s.strip
        return nil if value.empty?
        return value if File.file?(value) && File.executable?(value)

        ENV.fetch('PATH', '').split(File::PATH_SEPARATOR).each do |directory|
          candidate = File.join(directory, value)
          return candidate if File.file?(candidate) && File.executable?(candidate)
        end
        nil
      end

      def first_executable(candidates)
        Array(candidates).compact.map(&:to_s).find do |candidate|
          File.file?(candidate) && File.executable?(candidate)
        end
      end

      def first_readable_file(candidates)
        Array(candidates).compact.map(&:to_s).find do |candidate|
          File.file?(candidate) && File.readable?(candidate) && !File.symlink?(candidate)
        end
      end

      def dotenv_candidate_paths
        configured = PLAYWRIGHT_MCP_SECRETS.to_s.strip
        candidates = []
        candidates << expanded_path(configured) unless configured.empty?
        %w[ODP_ENV_FILE DOTENV_FILE].each do |name|
          value = ENV[name].to_s.strip
          candidates << expanded_path(value) unless value.empty?
        end
        candidates << File.join(Dir.pwd, '.env')
        if defined?(FEATURE_RUN_WORKDIR) && FEATURE_RUN_WORKDIR && !FEATURE_RUN_WORKDIR.to_s.strip.empty?
          candidates << File.join(expanded_path(FEATURE_RUN_WORKDIR), '.env')
        end
        runtime_root = ENV['UAT_RUNTIME_ROOT'].to_s.strip
        candidates << File.join(expanded_path(runtime_root), '.env') unless runtime_root.empty?
        # In a tester delivery the script lives at ProjectA/PageExplore/tools while
        # credentials live at ProjectA/.env. This path must work regardless of the
        # directory from which the batch command was launched.
        candidates << File.join(File.dirname(SCRIPT_ROOT), '.env')
        candidates << File.join(SCRIPT_ROOT, '.env')
        candidates.uniq
      end

      def dotenv_candidates
        dotenv_candidate_paths.select do |path|
          File.file?(path) && File.readable?(path) && !File.symlink?(path)
        end
      end

      def dotenv_scalar(path, key)
        return nil unless path && File.file?(path) && !File.symlink?(path)

        pattern = /\A\s*(?:export\s+)?#{Regexp.escape(key)}\s*=\s*(.*?)\s*\z/
        File.foreach(path, encoding: 'UTF-8') do |line|
          line = line.delete_prefix("\uFEFF")
          match = line.match(pattern)
          next unless match

          value = match[1].to_s.strip
          if value.start_with?("'")
            closing = value.rindex("'")
            tail = closing ? value[(closing + 1)..].to_s.strip : nil
            return nil unless closing && closing.positive? && (tail.empty? || tail.start_with?('#'))

            return value[1...closing]
          end
          if value.start_with?('"')
            closing = value.rindex('"')
            tail = closing ? value[(closing + 1)..].to_s.strip : nil
            return nil unless closing && closing.positive? && (tail.empty? || tail.start_with?('#'))

            # ODP_URL is intentionally a scalar.  Decode only the two escapes that
            # can occur in a URL and reject the rest rather than evaluating dotenv
            # expressions or interpolating another (possibly secret) variable.
            return value[1...closing].gsub('\\"', '"').gsub('\\\\', '\\')
          end

          # A dotenv comment starts at an unquoted ` #`.  Keep URL fragments intact.
          return value.split(/\s+#/, 2).first.to_s.strip
        end
        nil
      rescue StandardError
        nil
      end

      # Determine whether a dotenv file declares a key without ever loading its
      # value.  The value must stay inside the trusted parent/MCP boundary; only the
      # key name is used to select the placeholder passed to the browser tool.
      def dotenv_key?(path, key)
        return false unless path && File.file?(path) && !File.symlink?(path)

        pattern = /\A\s*(?:export\s+)?#{Regexp.escape(key)}\s*=/
        File.foreach(path, encoding: 'UTF-8') do |line|
          line = line.delete_prefix("\uFEFF")
          return true if line.match?(pattern)
        end
        false
      rescue StandardError
        false
      end

      def dotenv_credential_present?(path, keys)
        Array(keys).any? do |key|
          value = dotenv_scalar(path, key).to_s.strip
          !value.empty? && !value.match?(/\A(?:<[^>]+>|\$\{[^}]+\})\z/)
        end
      end

      def normalize_odp_url(value)
        text = value.to_s.strip
        return nil if text.empty? || text.match?(/[\x00-\x1F\x7F]/) || text.include?('${')

        # Operators often carry the ODP endpoint as a host/IP in older runtime
        # files (for example `10.161.65.56` or `odp.internal:8443`).  The browser
        # application is HTTPS by default, so accept that shorthand while keeping
        # the canonical URL form for the prompt and MCP environment.
        unless text.match?(%r{\A[A-Za-z][A-Za-z0-9+.-]*://})
          text = text.start_with?('//') ? "https:#{text}" : "https://#{text}"
        end
        uri = URI.parse(text)
        return nil unless %w[http https].include?(uri.scheme.to_s.downcase) && !uri.host.to_s.empty?
        return nil if uri.userinfo

        # People commonly paste the browser's landing-page URL into `.env`.  It is
        # safe to normalize the two observed landing-page spellings only when the
        # query is exactly the non-sensitive login-mode switch; arbitrary queries
        # and fragments remain invalid so tokens cannot be propagated accidentally.
        landing_path = %r{\A/ESUI/eventServerLanding(?:\.html|_html)?\z}
        if uri.query || uri.fragment
          return nil unless uri.query == 'login_mode=both' && uri.fragment.nil? && uri.path.match?(landing_path)

          uri.path = '/'
          uri.query = nil
        elsif uri.path.match?(landing_path)
          uri.path = '/'
        end

        return nil if uri.path.to_s.match?(%r{(?:^|/)\.\.(?:/|$)})

        uri.path = '/' if uri.path.to_s.empty?
        normalized = uri.to_s
        normalized = "#{normalized}/" unless normalized.end_with?('/')
        normalized
      rescue URI::InvalidURIError, ArgumentError
        nil
      end

      def configured_odp_url_details
        explicit = ODP_URL_OVERRIDE.to_s.strip
        unless explicit.empty?
          normalized = normalize_odp_url(explicit)
          return {
            url: normalized,
            source: '--odp-url',
            problems: normalized ? [] : ['--odp-url is invalid (expected an absolute http:// or https:// URL)'],
            checked_paths: []
          }
        end

        problems = []
        inherited = ENV['ODP_URL'].to_s.strip
        unless inherited.empty?
          normalized = normalize_odp_url(inherited)
          return { url: normalized, source: 'process environment', problems: [], checked_paths: [] } if normalized

          problems << 'process ODP_URL is invalid or still contains a placeholder; ignored'
        end

        checked_paths = dotenv_candidate_paths.map do |path|
          status = if File.symlink?(path)
                     'rejected symlink'
                   elsif !File.exist?(path)
                     'not found'
                   elsif !File.file?(path)
                     'not a regular file'
                   elsif !File.readable?(path)
                     'not readable'
                   elsif !dotenv_key?(path, 'ODP_URL')
                     'ODP_URL key missing'
                   else
                     raw_value = dotenv_scalar(path, 'ODP_URL')
                     normalized = normalize_odp_url(raw_value)
                     return {
                       url: normalized,
                       source: "dotenv #{path}",
                       problems: problems,
                       checked_paths: [[path, 'valid']]
                     } if normalized
                     'ODP_URL value invalid (use https://host/ or host[:port])'
                   end
          [path, status]
        end

        {
          url: nil,
          source: nil,
          problems: problems,
          checked_paths: checked_paths
        }
      end

      def configured_odp_url
        configured_odp_url_details[:url]
      end

      def odp_url_configuration_error
        details = configured_odp_url_details
        return nil if details[:url]

        parts = Array(details[:problems])
        checked = Array(details[:checked_paths]).map { |path, status| "#{path} (#{status})" }
        parts << "checked dotenv paths: #{checked.join(', ')}" unless checked.empty?
        "ODP_URL is not configured or is invalid; #{parts.join('; ')}. " \
          'Set ODP_URL to https://host/ (or host[:port]), pass --odp-url URL, or pass --playwright-mcp-secrets /absolute/path/.env.'
      end

      def playwright_mcp_secrets_path
        configured = PLAYWRIGHT_MCP_SECRETS.to_s.strip
        unless configured.empty?
          path = expanded_path(configured)
          return path if File.file?(path) && File.readable?(path) && !File.symlink?(path)
          warn "Configured Playwright MCP secrets file does not exist: #{path}"
          return nil
        end

        candidates = dotenv_candidates
        candidates.find do |path|
          dotenv_credential_present?(path, ODP_MAKER_USERNAME_KEYS) &&
            dotenv_credential_present?(path, ODP_MAKER_PASSWORD_KEYS)
        end || candidates.first
      end

      def playwright_mcp_missing_login_secret_keys(require_checker: false)
        path = playwright_mcp_secrets_path
        missing = []
        unless dotenv_credential_present?(path, ODP_MAKER_USERNAME_KEYS)
          missing << 'ODP_USERNAME (or SECRET_ODP_USERNAME)'
        end
        unless dotenv_credential_present?(path, ODP_MAKER_PASSWORD_KEYS)
          missing << 'ODP_PASSWORD (or SECRET_ODP_PASSWORD)'
        end
        if require_checker
          unless dotenv_credential_present?(path, ODP_CHECKER_USERNAME_KEYS)
            missing << 'ODP_CHECKER_USERNAME (or SECRET_ODP_CHECKER_USERNAME)'
          end
          unless dotenv_credential_present?(path, ODP_CHECKER_PASSWORD_KEYS)
            missing << 'ODP_CHECKER_PASSWORD (or SECRET_ODP_CHECKER_PASSWORD)'
          end
        end
        missing
      end

      def playwright_mcp_login_secret_values
        path = playwright_mcp_secrets_path
        return [] unless path

        (ODP_MAKER_USERNAME_KEYS + ODP_MAKER_PASSWORD_KEYS +
          ODP_CHECKER_USERNAME_KEYS + ODP_CHECKER_PASSWORD_KEYS)
          .filter_map { |key| dotenv_scalar(path, key) }
          .map(&:to_s)
          .reject(&:empty?)
          .uniq
      end

      def command_includes_option?(command, option)
        tokens = command.is_a?(Array) ? command.map(&:to_s) : Shellwords.split(command.to_s)
        tokens.any? { |token| token == option || token.start_with?("#{option}=") }
      rescue ArgumentError
        false
      end

      def replace_command_option(tokens, option, value)
        result = []
        index = 0
        while index < tokens.length
          token = tokens[index].to_s
          if token == option
            index += 2
            next
          end
          if token.start_with?("#{option}=")
            index += 1
            next
          end
          result << token
          index += 1
        end
        result += [option, value.to_s]
        result
      end

      def existing_playwright_entry_has_secrets?
        existing = existing_playwright_mcp_entry
        return false unless existing

        command_includes_option?(existing[1]['command'], '--secrets')
      end

      def playwright_mcp_credentials_configured?
        return true if playwright_mcp_secrets_path
        return true if command_includes_option?(PLAYWRIGHT_MCP_COMMAND, '--secrets')
        return true if PLAYWRIGHT_MCP_COMMAND.to_s.include?('{secrets}')
        return true if existing_playwright_entry_has_secrets?

        false
      end

      def playwright_mcp_cli_path
        explicit = PLAYWRIGHT_MCP_CLI.to_s.strip
        unless explicit.empty?
          path = expanded_path(explicit)
          return path if File.file?(path) && File.readable?(path) && !File.symlink?(path)

          warn "Configured Playwright MCP CLI is not a readable file: #{path}"
          return nil
        end

        # Node executes cli.js directly, so the package does not need the Unix
        # executable bit.  Some offline tar extractors preserve 0644 for JS files.
        first_readable_file([
          '/opt/playwright-mcp/current/node_modules/@playwright/mcp/cli.js',
          '/usr/local/lib/playwright-mcp/node_modules/@playwright/mcp/cli.js',
          File.join(Dir.pwd, 'node_modules', '@playwright', 'mcp', 'cli.js'),
          File.join(SCRIPT_ROOT, 'node_modules', '@playwright', 'mcp', 'cli.js')
        ])
      end

      def playwright_mcp_node_path
        explicit = PLAYWRIGHT_MCP_NODE.to_s.strip
        unless explicit.empty?
          path = expanded_path(explicit)
          return path if File.file?(path) && File.executable?(path)

          warn "Configured Playwright MCP Node is not executable: #{path}"
          return nil
        end

        first_executable([
          '/opt/playwright-mcp/runtime/node',
          '/usr/local/bin/node',
          command_executable('node')
        ])
      end

      def playwright_mcp_browser_path
        explicit = PLAYWRIGHT_MCP_BROWSER.to_s.strip
        unless explicit.empty?
          path = expanded_path(explicit)
          return path if File.file?(path) && File.executable?(path)

          warn "Configured Playwright browser is not executable: #{path}"
          return nil
        end

        discovered = Dir.glob('/opt/ms-playwright/**/chrome') +
                     Dir.glob('/opt/ms-playwright/**/chrome-linux/chrome') +
                     Dir.glob('/opt/playwright-mcp/**/chrome')
        first_executable(discovered.sort.reverse + [
          '/usr/bin/google-chrome',
          '/usr/bin/chromium',
          '/usr/bin/chromium-browser'
        ])
      end

      def headed_display
        configured = ENV['DISPLAY'].to_s.strip
        return configured unless configured.empty?

        # The maintained VNC image starts Xvfb on :99.  Do not start or mutate an
        # X server here; merely inherit the conventional display when its socket is
        # already present.
        return ':99' if File.exist?('/tmp/.X11-unix/X99')

        nil
      end

      def playwright_mcp_server_command(output_dir)
        explicit = PLAYWRIGHT_MCP_COMMAND.to_s.strip
        if !explicit.empty?
          tokens = Shellwords.split(explicit)
          raise ArgumentError, 'Playwright MCP command is empty' if tokens.empty?
          if explicit.include?('{secrets}') && playwright_mcp_secrets_path.nil?
            raise ArgumentError, 'Playwright MCP command contains {secrets}, but no readable dotenv secrets file was found'
          end
          substitutions = {
            '{output_dir}' => expanded_path(output_dir),
            '{secrets}' => playwright_mcp_secrets_path.to_s,
            '{headless}' => (PLAYWRIGHT_MCP_HEADLESS ? '--headless' : '')
          }
          tokens = tokens.flat_map do |token|
            replaced = substitutions.reduce(token) { |text, (key, value)| text.gsub(key, value) }
            replaced.empty? ? [] : [replaced]
          end
          secrets = playwright_mcp_secrets_path
          # An explicit/current dotenv selection must win over a stale --secrets
          # embedded in a reusable MCP command. Keeping the old option is the common
          # reason a newly populated ProjectA/.env appears to be ignored.
          tokens = replace_command_option(tokens, '--secrets', secrets) if secrets
          return Shellwords.join(tokens)
        end

        cli = playwright_mcp_cli_path
        return nil unless cli

        node = playwright_mcp_node_path
        return nil unless node
        tokens = [node, cli]
        browser = playwright_mcp_browser_path
        tokens += ['--executable-path', browser] if browser
        # Playwright MCP is headed by default.  Deliberately add --headless only
        # when the operator asks for it; this is what makes VNC inspection possible.
        tokens << '--headless' if PLAYWRIGHT_MCP_HEADLESS
        tokens += ['--isolated', '--output-dir', expanded_path(output_dir)]
        tokens << '--ignore-https-errors' unless ENV.fetch('PLAYWRIGHT_MCP_IGNORE_HTTPS_ERRORS', '1') == '0'
        secrets = playwright_mcp_secrets_path
        tokens += ['--secrets', secrets] if secrets
        tokens << '--no-sandbox' if Process.uid.zero?
        Shellwords.join(tokens)
      rescue ArgumentError
        raise
      rescue StandardError => e
        warn "Cannot construct Playwright MCP command: #{e.message}"
        nil
      end

      def opencode_config_path_for(workdir = Dir.pwd)
        configured = ENV['OPENCODE_CONFIG'].to_s.strip
        return expanded_path(configured) if !configured.empty? && File.file?(expanded_path(configured))

        current = expanded_path(workdir)
        loop do
          %w[opencode.jsonc opencode.json].each do |name|
            path = File.join(current, name)
            return path if File.file?(path)
          end
          parent = File.dirname(current)
          break if parent == current

          current = parent
        end
        nil
      end

      def jsonc_object(path)
        text = File.read(path, encoding: 'UTF-8')
        # OpenCode configs in the wild are often JSONC.  This intentionally handles
        # only comments/trailing commas; it is not used for arbitrary source files.
        stripped = String.new
        index = 0
        in_string = false
        escaped = false
        while index < text.length
          character = text[index]
          if in_string
            stripped << character
            if escaped
              escaped = false
            elsif character == '\\'
              escaped = true
            elsif character == '"'
              in_string = false
            end
            index += 1
            next
          end
          if character == '"'
            in_string = true
            stripped << character
            index += 1
          elsif character == '/' && text[index + 1] == '/'
            index += 2
            index += 1 while index < text.length && text[index] !~ /[\r\n]/
          elsif character == '/' && text[index + 1] == '*'
            index += 2
            index += 1 while index + 1 < text.length && !(text[index] == '*' && text[index + 1] == '/')
            index += 2 if index + 1 < text.length
          else
            stripped << character
            index += 1
          end
        end
        text = stripped
        text = text.gsub(/,\s*([}\]])/, '\\1')
        value = JSON.parse(text)
        value.is_a?(Hash) ? value : nil
      rescue StandardError
        nil
      end

      def playwright_mcp_config_candidates
        candidates = []
        configured = ENV['OPENCODE_CONFIG'].to_s.strip
        candidates << expanded_path(configured) unless configured.empty?
        current = expanded_path(Dir.pwd)
        loop do
          candidates.concat([File.join(current, 'opencode.jsonc'), File.join(current, 'opencode.json')])
          parent = File.dirname(current)
          break if parent == current

          current = parent
        end
        xdg = ENV['XDG_CONFIG_HOME'].to_s.strip
        xdg = File.join(Dir.home, '.config') if xdg.empty?
        candidates.concat([
          File.join(xdg, 'opencode', 'opencode.jsonc'),
          File.join(xdg, 'opencode', 'opencode.json')
        ])
        candidates.uniq.select { |path| File.file?(path) && !File.symlink?(path) }
      end

      def existing_playwright_mcp_entry
        playwright_mcp_config_candidates.each do |path|
          config = jsonc_object(path)
          entry = config && config.dig('mcp', 'playwright')
          return [path, entry] if entry.is_a?(Hash)
        end
        nil
      end

      def normalize_existing_playwright_entry(entry, output_dir)
        result = JSON.parse(JSON.generate(entry))
        command = result['command']
        command = [command] if command.is_a?(String)
        return result unless command.is_a?(Array) && !command.empty?

        command = command.map(&:to_s)
        if PLAYWRIGHT_MCP_HEADLESS
          command << '--headless' unless command.include?('--headless')
        else
          command = command.reject { |token| token == '--headless' }
        end
        unless command.include?('--output-dir')
          command += ['--output-dir', expanded_path(output_dir)]
        end
        secrets = playwright_mcp_secrets_path
        command = replace_command_option(command, '--secrets', secrets) if secrets
        result['command'] = command
        result['cwd'] ||= Dir.pwd
        result['enabled'] = true unless result.key?('enabled')
        result
      end

      def admin_mcp_preflight_error
        return nil unless ADMIN_EXPLORE_COMMAND.to_s.strip.empty? && PLAYWRIGHT_MCP_COMMAND.to_s.strip.empty?
        if playwright_mcp_cli_path
          return nil if playwright_mcp_node_path

          return 'Playwright MCP CLI was found, but no executable Node runtime is available; ' \
                 'set --playwright-mcp-node or install the offline runtime.'
        end
        return nil if existing_playwright_mcp_entry

        'Playwright MCP is not configured. Install the offline package or pass --playwright-mcp-command; ' \
          'for a headed VNC run ensure DISPLAY is set and omit --headless.'
      end

      def admin_exploration_requested?
        return false if ADMIN_EXPLORE_MODE == 'off'
        return true if ADMIN_EXPLORE_MODE == 'always'

        # Supplying an exploration command is an explicit request to perform the
        # missing-flow stage.  This keeps wrapper scripts concise while retaining
        # the side-effect-free default when no browser command was configured.
        return true unless ADMIN_EXPLORE_COMMAND.to_s.strip.empty? &&
                          PLAYWRIGHT_MCP_COMMAND.to_s.strip.empty?

        # `auto` is intentionally tied to --repair-generated.  A plain --run-
        # generated command should never change an Admin record merely because its
        # catalog entry is missing.
        REPAIR_GENERATED
      end
    end
  end
end
