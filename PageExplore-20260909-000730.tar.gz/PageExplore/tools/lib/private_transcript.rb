# frozen_string_literal: true

# Persist complete, redacted event lines while the model is running. A secret
# split across pipe chunks is still redacted before a single byte is written.
class PrivateTranscript
  MAX_LINE = 64 * 1024 * 1024
  def initialize(path, &redactor)
    raise 'transcript path is a symlink' if File.symlink?(path)
    FileUtils.mkdir_p(File.dirname(File.expand_path(path)))
    @file = File.open(path, 'w', 0o600)
    @file.chmod(0o600)
    @buffer = ''.b
    @redactor = redactor
    @discarding = false
  end

  def append(chunk)
    @buffer << chunk.b
    while (index = @buffer.index("\n"))
      line = @buffer.slice!(0, index + 1)
      @file.write(@redactor.call(line)) unless @discarding
      @discarding = false
      @file.flush
    end
    if @buffer.bytesize > MAX_LINE
      @file.write("[invalid evidence: event exceeds line limit]\n") unless @discarding
      @file.flush
      @buffer.clear
      @discarding = true
    end
  end

  def close
    @file.write(@redactor.call(@buffer)) unless @discarding || @buffer.empty?
    @file.flush
    @file.close
  end
end
