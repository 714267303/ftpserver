# frozen_string_literal: true

require 'yaml'
require 'json'
require 'digest'
require 'date'

# One structural parser for every pipeline consumer. Never instantiate YAML objects.
class CaseSource
  CHANNELS = %w[admin_gui trading_gui binary_proxy clearing batch manual_or_unspecified].freeze
  FIELDS = {
    'step' => 'Test Script (Step-by-Step) - Step',
    'testdata' => 'Test Script (Step-by-Step) - Test Data',
    'expected' => 'Test Script (Step-by-Step) - Expected Result'
  }.freeze
  attr_reader :path, :payload, :steps, :sha256

  def initialize(path)
    @path = File.expand_path(path)
    text = File.read(@path, encoding: 'UTF-8')
    @sha256 = Digest::SHA256.hexdigest(text)
    @payload = YAML.safe_load(text, permitted_classes: [Date, Time], aliases: false)
    raise 'case YAML must contain TestSteps' unless @payload.is_a?(Hash) && @payload['TestSteps'].is_a?(Array)
    @steps = @payload['TestSteps'].each_with_index.map do |item, index|
      raise "TestSteps[#{index}] must be an object" unless item.is_a?(Hash)
      channel = (item['Execution Channel'] || item['execution_channel'] || 'manual_or_unspecified').to_s.downcase
      raise "unsupported Execution Channel in step #{index + 1}" unless CHANNELS.include?(channel)
      values = FIELDS.to_h { |key, field| [key, item[field].to_s] }
      values.merge('index' => index + 1, 'channel' => channel,
                   'profile' => item['PageExplore Profile'].to_s, 'raw' => item)
    end
  end

  def to_h
    { 'path' => path, 'sha256' => sha256,
      'case_id' => (payload['Key'] || payload.dig('TestSteps', 0, 'Key')).to_s,
      'steps' => steps }
  end
end

if $PROGRAM_NAME == __FILE__
  begin
    puts JSON.generate(CaseSource.new(ARGV.fetch(0)).to_h)
  rescue StandardError => e
    warn "Invalid case YAML: #{e.message}"
    exit 2
  end
end
