"""Local batch orchestration integration; all child commands are test doubles."""
import json
import os
import subprocess
import tempfile
import unittest
from pathlib import Path
from admin_test_support import fixture, evidence_events, transcript, INDEX, PAGES
from admin_flow.common import ROOT
from admin_flow.compiler import compile_plan
from admin_flow.source import read_case
from admin_flow.evidence import validate_evidence

BATCH=ROOT/'tools/batch_transform_tc.rb'

class BatchPipelineTest(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.root=Path(self.tmp.name)
        for name in ('excel','yaml','target','flows','binary','excel_skill'): (self.root/name).mkdir()
        self.base='ODP-T2194_case'
        (self.root/'excel'/f'{self.base}.xlsx').write_bytes(b'mock')
        source,_,self.plan=fixture(self.root)
        self.source=source
        self.plan['channel']='hybrid'
        self.source.write_text(self.source.read_text()+'''- Execution Channel: binary_proxy
  Test Script (Step-by-Step) - Step: Send Day1 order
- Execution Channel: batch
  Test Script (Step-by-Step) - Step: After night batch advance to next business day and wait for market OPEN
- Execution Channel: binary_proxy
  Test Script (Step-by-Step) - Step: Send Day2 order
''')
        parser=self.root/'excel_skill/parse_excel.py'
        parser.write_text('import pathlib,json,sys\nprint(json.dumps([{"key":"ODP-T2194"}]) if "--all" in sys.argv else pathlib.Path('+repr(str(source))+').read_text())\n')
        yaml_path=self.root/'yaml'/f'{self.base}.yaml'
        # print() in parser contributes one final newline.
        yaml_path.write_text(self.source.read_text()+'\n')
        flow=compile_plan(self.plan,read_case(yaml_path),INDEX,PAGES)
        trace=transcript(self.root,evidence_events(flow))
        evidence=validate_evidence(flow,trace,{'schema_version':2,'kind':'admin_exploration','case_id':'ODP-T2194','status':'passed'})
        flow.update(evidence_status='verified',evidence={**evidence,'transcript':str(trace)},
                    reuse={'safe_to_reuse':True,'contract_sha256':flow['contract_sha256']})
        self.flow_path=self.root/'flows/ODP-T2194.json'; self.flow_path.write_text(json.dumps(flow))
        self.run_log=self.root/'runs.jsonl'
        self.runner=self.root/'fake_runner.rb'
        self.runner.write_text(r'''require 'json'
require 'digest'
require 'fileutils'
f=ARGV[0]; r=ARGV[ARGV.index('--report')+1]
text=File.read(f); n=text.lines.count { |l| l.match?(/^\s*\* /) }
failed=ENV['TEST_ADMIN_FAIL']=='1' && f.end_with?('.admin.feature')
File.open(ENV.fetch('TEST_RUN_LOG'),'a') { |o| o.puts(JSON.generate({'feature'=>f})) }
FileUtils.mkdir_p(File.dirname(r))
File.write(r,JSON.generate({'feature'=>{'path'=>File.expand_path(f),'sha256'=>Digest::SHA256.file(f).hexdigest},
 'execution'=>{'status'=>failed ? 'failed' : 'passed','command'=>['fake-cucumber'],
 'cucumber_summary'=>{'total'=>n,'passed'=>failed ? 0 : n,'failed'=>failed ? n : 0}}}))
exit(failed ? 1 : 0)
''')
        for day,step in [('Day1','Save'),('Day2','Load')]:
            (self.root/'binary'/f'ODP-T2194-{day}.feature').write_text(f'@FEATURE=Binary\nFeature: {day}\nScenario: {day}\n  * {step} FIX dumpfile ODP-T2194-Day1\n')
        self.env=os.environ.copy(); self.env.update(EXCEL_YAML_SKILL=str(self.root/'excel_skill'),
            AUTO_SKILL=str(ROOT/'odpt-automation-skill'),PAGEEXPLORE_ROOT=str(PAGES),TEST_RUN_LOG=str(self.run_log),NO_COLOR='1')
    def tearDown(self): self.tmp.cleanup()
    def run_batch(self,*extra):
        return subprocess.run(['ruby',str(BATCH),str(self.root/'excel'),str(self.root/'yaml'),str(self.root/'target'),
          '--excel-yaml-mode','deterministic','--run-generated','--no-admin-explore','--admin-flow-dir',str(self.root/'flows'),
          '--binary-base-dir',str(self.root/'binary'),'--feature-runner',str(self.runner),*extra],cwd=ROOT,env=self.env,
          text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=45)
    def events(self): return [json.loads(l) for l in self.run_log.read_text().splitlines()] if self.run_log.exists() else []
    @property
    def execution(self): return self.root/'target'/f'{self.base}.execution-flow.json'
    def resume(self):
        return subprocess.run(['ruby',str(BATCH),'--run-execution-flow',str(self.execution),'--complete-gate','night_batch',
          '--feature-runner',str(self.runner)],cwd=ROOT,env=self.env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=45)
    def test_admin_then_day1_gate_then_day2(self):
        run=self.run_batch(); self.assertEqual(3,run.returncode,run.stdout)
        flow=json.loads(self.execution.read_text())
        self.assertEqual(2,flow['schema_version'])
        self.assertEqual(['admin','day1','night_batch','day2'],[s['id'] for s in flow['stages']])
        self.assertEqual(2,len(self.events()))
        self.assertEqual('waiting_for_gate',flow['execution']['status'])
        self.assertFalse((self.root/'target'/f'{self.base}.feature').exists())
        resumed=self.resume(); self.assertEqual(0,resumed.returncode,resumed.stdout)
        self.assertEqual(3,len(self.events()))
        self.assertTrue(self.events()[-1]['feature'].endswith('-Day2.feature'))
    def test_admin_failure_stops_binary(self):
        self.env['TEST_ADMIN_FAIL']='1'; run=self.run_batch()
        self.assertNotEqual(0,run.returncode,run.stdout)
        self.assertEqual(1,len(self.events()),run.stdout)
        self.assertFalse(self.execution.exists())
    def test_completed_stage_file_change_blocks_resume(self):
        run=self.run_batch(); self.assertEqual(3,run.returncode,run.stdout)
        Path(self.events()[0]['feature']).write_text('changed')
        resumed=self.resume(); self.assertNotEqual(0,resumed.returncode,resumed.stdout)
        self.assertEqual(2,len(self.events()))
    def test_completed_stage_report_change_blocks_resume(self):
        run=self.run_batch(); self.assertEqual(3,run.returncode,run.stdout)
        flow=json.loads(self.execution.read_text())
        Path(flow['execution']['stages']['day1']['report']).write_text('{}')
        resumed=self.resume(); self.assertNotEqual(0,resumed.returncode,resumed.stdout)
        self.assertEqual(2,len(self.events()))
    def test_old_flow_never_executes(self):
        flow=json.loads(self.flow_path.read_text()); flow['schema_version']=1; self.flow_path.write_text(json.dumps(flow))
        run=self.run_batch(); self.assertNotEqual(0,run.returncode,run.stdout)
        self.assertEqual([],self.events())
    def test_changed_yaml_id_requires_fresh_evidence(self):
        self.source.write_text(self.source.read_text().replace('210010011','999999999'))
        run=self.run_batch(); self.assertNotEqual(0,run.returncode,run.stdout)
        self.assertEqual([],self.events())
    def test_default_model_and_override(self):
        for model in ('ollama/AE&I/Qwen3.8-27B','ollama/test-override'):
            env=self.env.copy(); env['OPENCODE_MODEL']=model
            r=subprocess.run(['ruby',str(BATCH),'--help'],env=env,text=True,capture_output=True)
            self.assertEqual(0,r.returncode,r.stderr); self.assertIn(model,r.stdout)
    def test_plan_compile_mcp_finalize_and_offline_handoff(self):
        self.flow_path.unlink()
        plan_writer=self.root/'plan_writer.py'
        plan_writer.write_text('import os,json\nfrom pathlib import Path\nPath(os.environ["ADMIN_PLAN_PATH"]).write_text('+repr(json.dumps(self.plan))+')\n')
        browser=self.root/'browser.py'
        browser.write_text('import sys,os,json\nfrom pathlib import Path\nsys.path.insert(0,'+repr(str(ROOT/'tools'))+')\n'+
          'from admin_test_support import evidence_events\n'+
          'print(json.dumps({"type":"text","padding":"x"*(9*1024*1024)}))\n'+
          'f=json.loads(Path(os.environ["ADMIN_EXPLORATION_FLOW_PATH"]).read_text())\n'+
          'for i,e in enumerate(evidence_events(f)):\n'+
          ' print(json.dumps({"part":{"type":"tool","tool":"playwright_browser_run_code_unsafe","callID":str(i),"state":{"status":"completed","output":"ODP_ADMIN_EVENT "+json.dumps(e)}}}))\n'+
          'Path(os.environ["ADMIN_EXPLORATION_REPORT_PATH"]).write_text(json.dumps({"schema_version":2,"kind":"admin_exploration","case_id":f["case_id"],"status":"passed"}))\n')
        run=self.run_batch('--admin-explore','--admin-plan-command',f'python3 {plan_writer}',
          '--admin-explore-command',f'python3 {browser}','--admin-evidence-root',str(self.root/'evidence'))
        self.assertEqual(3,run.returncode,run.stdout)
        runs=list((self.root/'evidence').glob('*/*'))
        self.assertEqual(1,len(runs))
        self.assertGreater((runs[0]/'opencode-events.jsonl').stat().st_size,9*1024*1024)
        for name in ('admin-plan.json','admin-flow.json','admin-bindings.json','admin-evidence.json','handoff-report.json'):
            self.assertTrue((runs[0]/name).is_file(),name)

if __name__=='__main__': unittest.main()
