#!/usr/bin/env python3
"""Find reusable Admin GUI flows in the generated catalog index."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any


SCRIPT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_INDEX = SCRIPT_ROOT / "odpt-automation-skill" / "Admin_GUI" / "flow_catalog" / "INDEX.json"


def matches(flow: dict[str, Any], query: str) -> bool:
    needle = query.casefold()
    page = flow.get("page", {})
    values = [
        flow.get("flow_id", ""),
        flow.get("case_id", ""),
        flow.get("name", ""),
        page.get("label", ""),
        page.get("route", ""),
        page.get("operation", ""),
        *flow.get("keywords", []),
    ]
    return any(needle in str(value).casefold() for value in values)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("query", help="flow ID, route, page label, or keyword")
    parser.add_argument(
        "--index",
        default=None,
        help="catalog index path (defaults to the PageExplore checkout containing this script)",
    )
    parser.add_argument(
        "--status",
        choices=["verified", "observed", "inferred"],
        help="restrict by evidence status",
    )
    parser.add_argument("--json", action="store_true", dest="as_json")
    args = parser.parse_args()
    configured = Path(args.index) if args.index else DEFAULT_INDEX
    # Keep a relative explicit path relative to the caller's working directory,
    # but resolve the bundled default from the script location.  This makes
    # `python3 PageExplore/tools/find_admin_flow.py ...` work when invoked from
    # the runtime checkout instead of requiring a second `cd`.
    path = configured if configured.is_absolute() else configured.resolve()
    if not path.is_file():
        print(f"ERROR: index does not exist: {path}", file=sys.stderr)
        return 2
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        print(f"ERROR: cannot parse {path}: {error}", file=sys.stderr)
        return 2
    if not isinstance(payload, dict) or payload.get('schema_version') != 2:
        print('ERROR: rebuild the Admin v2 catalog index; v1 indexes are unsupported',file=sys.stderr)
        return 2
    flows = [flow for flow in payload.get("flows", []) if isinstance(flow, dict)]
    results = [
        flow
        for flow in flows
        if matches(flow, args.query)
        and (args.status is None or flow.get("evidence_status") == args.status)
    ]
    if args.as_json:
        print(json.dumps(results, ensure_ascii=False, indent=2))
    else:
        for flow in results:
            page = flow.get("page", {})
            print(
                f"{flow.get('flow_id')}\t{flow.get('evidence_status')}\t"
                f"{page.get('route', '')}\t{flow.get('path', '')}"
            )
    return 0 if results else 1


if __name__ == "__main__":
    raise SystemExit(main())
