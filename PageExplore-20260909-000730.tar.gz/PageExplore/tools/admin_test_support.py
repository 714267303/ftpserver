"""Local v2 test fixtures. No website, credentials or model calls."""
import copy
import json
from pathlib import Path

from admin_flow.common import ROOT
from admin_flow.compiler import compile_plan
from admin_flow.source import read_case

INDEX = ROOT / 'odpt-automation-skill/Step_Index.json'
PAGES = ROOT / 'pageExplore'
ROUTE = '/UI/uiSmpIdSearchTable'


def fixture(root):
    root = Path(root)
    source = root / 'case.yaml'
    source.write_text('''Key: ODP-T2194
TestSteps:
- Execution Channel: admin_gui
  PageExplore Profile: pageExplore/pages/uiSmpIdSearchTable.md
  Test Script (Step-by-Step) - Step: Maker update cancellation method, checker approve then verify.
  Test Script (Step-by-Step) - Test Data: |-
    SMP ID: 210010011
    Method: CP
    Effective: Update for tomorrow
    Status: Active
  Test Script (Step-by-Step) - Expected Result: Cancellation method CP and status Active.
''')
    ref = lambda name: {'param': name}
    plan = {'schema_version': 2, 'kind': 'admin_plan', 'flow_id': 'admin.smp.update.v2',
            'case_id': 'ODP-T2194', 'name': 'Update SMP cancellation method', 'channel': 'admin',
            'parameters': {name: {'origin': 'yaml', 'step': 1, 'key': key}
                           for name, key in [('record','SMP ID'),('method','Method'),('effective','Effective'),('status','Status')]},
            'sessions': {}, 'actions': [], 'cleanup': {'action': 'reject', 'session': 'checker'}}
    for n, role in enumerate(('maker', 'checker'), 1):
        plan['parameters'][role + '_user'] = {'origin':'dataset','alias': f'admin_gui_user{n}'}
        plan['parameters'][role + '_password'] = {'origin':'dataset','alias': f'admin_gui_user{n}_password'}
        plan['sessions'][role] = {'role':role,'browser': f'browser_admin_gui_user{n}',
                                  'user':ref(role+'_user'),'password':ref(role+'_password')}
    subject = {'SMP ID':ref('record')}
    def add(aid, op, args=None, phase='shared', session='maker'):
        plan['actions'].append({'id':aid,'operation':op,'session':session,'phase':phase,
                               'page':ROUTE,'source_steps':[1], 'subject':copy.deepcopy(subject), 'args':args or {}})
    add('navigate', 'navigate')
    add('search', 'search', {'fields':subject})
    add('detail','open_detail',{'column':'SMP ID','fields':subject})
    add('effective','effective_date',{'type':ref('effective')})
    add('edit','set_fields',{'fields':{'Cancellation Method':ref('method')}})
    add('save','submit')
    add('message','confirm_message',{'message':'Your action has been sent.'})
    add('close','close_dialog')
    add('approve','approve',{'identifier':ref('record'),'requester_session':'maker'},'feature','checker')
    add('return','navigate',phase='feature')
    add('search_after','search',{'fields':subject},'feature')
    add('verify','verify_table',{'fields':{**subject,'Cancellation Method':ref('method'),'Status':ref('status')}},'feature')
    plan_path = root / 'admin-plan.json'
    plan_path.write_text(json.dumps(plan))
    return source, plan_path, plan


def compile_fixture(root):
    source, plan_path, plan = fixture(root)
    return compile_plan(plan, read_case(source), INDEX, PAGES)


def evidence_events(flow):
    common = {'plan_sha256':flow['identity']['plan'],'source_sha256':flow['identity']['source'], 'status':'passed'}
    subject = flow['actions'][1]['subject']
    events = []
    def add(op, session='maker', observed=None, **extra):
        events.append({**common,'operation':op,'session':session,'route':ROUTE,'subject':subject,
                       'observed':observed or {'visible':True}, **extra})
    add('session', observed={'authenticated':True, 'context_id':'maker-context'})
    for action in flow['actions']:
        if action['phase'] != 'shared':
            continue
        if action['operation'] == 'effective_date':
            add('baseline', observed={'fields':{'SMP ID':subject['SMP ID'],'Cancellation Method':'CA','Status':'Active'}, 'pending_request':False})
        observed = {'visible':True}
        if 'fields' in action['args']:
            observed['fields'] = action['args']['fields']
        if action['operation'] == 'effective_date':
            observed['effective_type'] = action['args']['type']
        if action['operation'] == 'submit':
            observed.update(request_status='Pending', request_id='a'*64)
        add(action['operation'], observed=observed, action_id=action['id'], subject=action['subject'])
    add('session','checker',{'authenticated':True, 'context_id':'checker-context'})
    add('reject','checker',{'pending_request':False, 'request_id':'a'*64})
    add('restore',observed={'fields':{'SMP ID':subject['SMP ID'],'Cancellation Method':'CA','Status':'Active'},'pending_request':False})
    return events


def transcript(root, events):
    path = Path(root) / 'opencode-events.jsonl'
    path.write_text(''.join(json.dumps({'type':'tool_use','part':{'type':'tool','tool':'playwright_browser_run_code_unsafe',
                        'callID':str(i),'state':{'status':'completed','output':'ODP_ADMIN_EVENT '+json.dumps(e)}}})+'\n'
                            for i,e in enumerate(events)))
    return path


def verified_fixture(root):
    from admin_flow.evidence import validate_evidence
    flow = compile_fixture(root)
    path = transcript(root, evidence_events(flow))
    report = {'schema_version':2,'kind':'admin_exploration','case_id':flow['case_id'],'status':'passed'}
    evidence = validate_evidence(flow, path, report)
    flow.update(evidence_status='verified', evidence={**evidence, 'transcript':str(path)})
    output = Path(root) / 'admin-flow.json'
    output.write_text(json.dumps(flow))
    return flow, output
