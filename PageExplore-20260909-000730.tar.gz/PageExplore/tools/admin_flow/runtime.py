"""Step_Index matching and exact Gherkin behavior comparison. No browser execution."""
from __future__ import annotations
import hashlib
import json
import os
import re
from pathlib import Path
from typing import Any, Mapping

SECRET_HEADER_RE = re.compile(r"(?:password|passwd|secret|api[_ -]?key)", re.I)
ADMIN_PREFIXES = ()

class ConversionError(ValueError):
    """Raised for malformed flow manifests or unsafe composition."""


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_json(path: Path) -> dict[str, Any]:
    if not path.is_file():
        raise ConversionError(f"input does not exist: {path}")
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise ConversionError(f"cannot parse JSON: {path}") from error
    if not isinstance(value, dict):
        raise ConversionError(f"JSON root must be an object: {path}")
    return value


def write_json_atomic(path: Path, value: Mapping[str, Any]) -> None:
    """Replace one manifest without exposing a partially written JSON file."""

    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp-{os.getpid()}")
    try:
        temporary.write_text(
            json.dumps(value, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        os.chmod(temporary, 0o600)
        temporary.replace(path)
    finally:
        if temporary.exists():
            temporary.unlink()


def clean_text(value: Any, field: str, limit: int = 2000) -> str:
    text = "" if value is None else str(value)
    text = text.replace("\r\n", "\n").replace("\r", "\n").strip()
    if not text:
        raise ConversionError(f"{field} must not be empty")
    if len(text) > limit:
        raise ConversionError(f"{field} exceeds {limit} characters")
    return text


def clean_line_text(value: Any, field: str, limit: int = 2000) -> str:
    """Validate text that will occupy one Gherkin line."""

    text = clean_text(value, field, limit)
    if "\n" in text:
        raise ConversionError(f"{field} must be a single line")
    return text


def normalize_tag(value: Any) -> str:
    """Return a valid single-line Gherkin tag."""

    tag = clean_line_text(value, "tag", 200)
    if not tag.startswith("@"):
        tag = "@" + tag
    # Existing ODP features use metadata tags such as @FEATURE=Binary and
    # @CASE=ODP10.1.6. Keep the validation strict about whitespace/control
    # characters while allowing the project-supported metadata punctuation.
    if not re.fullmatch(r"@[A-Za-z0-9_.:=+\-]+", tag):
        raise ConversionError(f"tag contains unsupported characters: {tag}")
    return tag


def normalize_step_text(value: str) -> str:
    text = value.strip()
    text = re.sub(r"^(?:Given|When|Then|And|But|\*)\s+", "", text, flags=re.I)
    return text.strip()


def signature_source_kinds(item: Mapping[str, Any]) -> set[str]:
    kinds = {str(item.get("source_kind", ""))}
    kinds.update(str(kind) for kind in (item.get("source_kinds", []) or []))
    return kinds


def signature_sources(item: Mapping[str, Any]) -> list[str]:
    sources = [str(item.get("source", ""))]
    for evidence in item.get("evidence", []) or []:
        if isinstance(evidence, Mapping):
            sources.append(str(evidence.get("source", "")))
    return [source.replace("\\", "/") for source in sources if source]


def signature_authorities(item: Mapping[str, Any]) -> set[str]:
    authorities = {str(item.get("authority", ""))}
    authorities.update(str(value) for value in (item.get("authorities", []) or []))
    return authorities


def signature_priority(item: Mapping[str, Any]) -> int:
    """Prefer current-project custom steps, then other runtime signatures."""

    is_custom_step = any(
        source.startswith("features/customized_steps/")
        or "/features/customized_steps/" in source
        for source in signature_sources(item)
    )
    authorities = signature_authorities(item)
    if is_custom_step and "runtime_source" in authorities:
        return 0
    if "runtime_source" in authorities:
        return 1
    return 2


def signature_requires_table(item: Mapping[str, Any]) -> bool:
    arguments = [str(value).lower() for value in (item.get("arguments", []) or [])]
    if any(value in {"table", "usertable"} for value in arguments):
        return True
    try:
        argument_count = int(item.get("argument_count", 0))
        capture_count = re.compile(
            str(item.get("pattern", "")).replace(r"\z", r"\Z")
        ).groups
        # Cucumber passes a trailing DataTable/DocString in addition to regex
        # captures. In this Admin vocabulary that extra structured argument is
        # the table the manifest must provide.
        return argument_count > capture_count
    except (TypeError, ValueError, re.error):
        return False


def signature_matches(normalized: str, item: Mapping[str, Any]) -> bool:
    """Match a trusted Step_Index pattern, with a conservative fallback.

    Most runtime Ruby step expressions are also valid Python regular
    expressions.  Matching the complete expression is needed for constrained
    alternations such as ``(Current Record|Update Record)``; the historical
    fragment-only matcher rejected those valid executable steps.  Keep the
    fragment matcher for the small number of Ruby-only expressions that
    Python cannot compile.
    """

    pattern = str(item.get("pattern", ""))
    try:
        if re.fullmatch(pattern.replace(r"\z", r"\Z"), normalized):
            return True
    except re.error:
        pass

    return False


def match_known_step(text: str, signatures: list[dict[str, Any]]) -> dict[str, Any]:
    normalized = normalize_step_text(text)

    # Step_Index is the executable authority. Preserve its original ordering
    # within each priority tier so duplicate signatures remain deterministic.
    prioritized = sorted(
        enumerate(signatures), key=lambda pair: (signature_priority(pair[1]), pair[0])
    )
    for _, item in prioritized:
        if not signature_source_kinds(item).intersection({"admin_gui", "shared_public"}):
            continue
        if not signature_matches(normalized, item):
            continue
        priority = signature_priority(item)
        return {
            "known": True,
            "match_source": (
                "step_index_customized_runtime"
                if priority == 0
                else "step_index_runtime"
                if priority == 1
                else "step_index_snapshot"
            ),
            "signature": str(item.get("signature", "")),
            "pattern": str(item.get("pattern", "")),
            "source": str(item.get("source", "")),
            "line": item.get("line"),
            "authority": str(item.get("authority", "")),
            "source_kind": str(item.get("source_kind", "")),
            "arguments": [str(value) for value in (item.get("arguments", []) or [])],
            "argument_count": item.get("argument_count"),
            "requires_table": signature_requires_table(item),
        }

    # Prefixes are a degraded-mode aid only when Step_Index is unavailable.
    # With a populated index, accepting a broad prefix would hide a missing or
    # invented UAT step instead of producing the required review marker.
    if not signatures:
        prefix = next(
            (
                value
                for value in ADMIN_PREFIXES
                if normalized == value.rstrip() or normalized.startswith(value)
            ),
            None,
        )
        if prefix:
            return {
                "known": True,
                "match_source": "fallback_admin_prefix",
                "prefix": prefix,
            }

    return {"known": False, "match_source": "unknown"}


def is_known_step(text: str, signatures: list[dict[str, Any]]) -> bool:
    return bool(match_known_step(text, signatures)["known"])


def load_signatures(path: Path | None) -> list[dict[str, Any]]:
    if path is None or not path.is_file():
        return []
    payload = load_json(path)
    steps = payload.get("steps", [])
    return steps if isinstance(steps, list) else []


def looks_like_placeholder(value: str) -> bool:
    value = value.strip()
    return (
        not value
        or value.startswith("<")
        or value.startswith("${")
        or value.startswith("ENV[")
        or value.endswith("_password")
        or value.endswith("_token")
        or value.startswith("password_")
    )


def sanitize_cell(value: Any, header: str, reviews: list[str], location: str) -> str:
    text = str(value if value is not None else "").replace("\n", " ").strip()
    if "|" in text:
        text = text.replace("|", "\\|")
    if SECRET_HEADER_RE.search(header) and text and not looks_like_placeholder(text):
        reviews.append(f"SECRET_LITERAL_REDACTED:{location}")
        return "<REVIEW_SECRET>"
    return text


def normalize_table(raw: Any, reviews: list[str], location: str) -> list[list[str]]:
    if raw is None:
        return []
    if isinstance(raw, str):
        rows = []
        for line in raw.splitlines():
            line = line.strip()
            if not line:
                continue
            if not (line.startswith("|") and line.endswith("|")):
                raise ConversionError(f"{location} string table must contain pipe rows")
            rows.append([cell.strip() for cell in line.strip("|").split("|")])
        return sanitize_rows(rows, reviews, location)
    if raw == []:
        return []
    if not isinstance(raw, list) or not raw:
        raise ConversionError(f"{location} table must be a non-empty array")
    if all(isinstance(row, Mapping) for row in raw):
        headers: list[str] = []
        for row in raw:
            for key in row:
                key_text = str(key)
                if key_text not in headers:
                    headers.append(key_text)
        result = [headers]
        for row_index, row in enumerate(raw, 1):
            result.append(
                [
                    sanitize_cell(row.get(header, ""), header, reviews, f"{location}[{row_index}].{header}")
                    for header in headers
                ]
            )
        return result
    if all(isinstance(row, list) for row in raw):
        rows = [list(row) for row in raw]
        return sanitize_rows(rows, reviews, location)
    raise ConversionError(f"{location} table rows must all be objects or arrays")


def sanitize_rows(rows: list[list[Any]], reviews: list[str], location: str) -> list[list[str]]:
    """Normalize pipe cells and redact secret columns in array tables too."""

    if not rows:
        return []
    headers = [str(value or "").strip() for value in rows[0]]
    if not headers or any(len(row) != len(headers) for row in rows):
        raise ConversionError(f"{location} table rows must have a consistent width")
    result: list[list[str]] = []
    for row_index, row in enumerate(rows):
        result.append(
            [
                sanitize_cell(
                    cell,
                    headers[column] if row_index > 0 and headers[column] else f"column_{column + 1}",
                    reviews,
                    f"{location}[{row_index + 1}][{column + 1}]",
                )
                for column, cell in enumerate(row)
            ]
        )
    width = len(result[0])
    if width == 0 or any(len(row) != width for row in result):
        raise ConversionError(f"{location} table rows must have a consistent width")
    return result


def normalize_step(raw: Any, index: int, signatures: list[dict[str, Any]], reviews: list[str]) -> dict[str, Any]:
    mcp_execution = ""
    if isinstance(raw, str):
        text = clean_line_text(raw, f"steps[{index}]")
        table = []
    elif isinstance(raw, Mapping):
        text = clean_line_text(raw.get("text", raw.get("step", "")), f"steps[{index}].text")
        table = normalize_table(raw.get("table"), reviews, f"steps[{index}].table")
        mcp_execution = str(raw.get("mcp_execution", "")).strip()
        if mcp_execution not in {"", "validated_read_only", "deferred_to_feature"}:
            raise ConversionError(
                f"steps[{index}].mcp_execution must be validated_read_only or deferred_to_feature"
            )
    else:
        raise ConversionError(f"steps[{index}] must be a string or object")

    match = match_known_step(text, signatures)
    if not match["known"]:
        reviews.append(f"UNKNOWN_STEP:{index}:{normalize_step_text(text)[:160]}")
    elif match.get("requires_table") and not table:
        # Matching a Ruby expression is insufficient when the step definition
        # also requires a Cucumber DataTable.  Literal operations such as
        # ``Approve if updated with :`` have no visible capture groups, so a
        # missing table otherwise survives until runtime.
        reviews.append(f"MISSING_TABLE:{index}:{normalize_step_text(text)[:160]}")
    normalized = {
        "text": normalize_step_text(text),
        "table": table,
        "known": match["known"],
        "match": match,
    }
    if mcp_execution:
        normalized["mcp_execution"] = mcp_execution
    return normalized


def validate_admin_login_shapes(
    steps_by_section: list[tuple[str, list[dict[str, Any]]]], reviews: list[str]
) -> None:
    """Flag a multi-user login table instead of silently emitting a bad flow.

    The executable Admin login step owns one browser session.  A table with
    multiple user rows attempt to reuse that session after the first
    login has navigated away from the login form.  Keep the finding as a review
    reason so a human can split the flow into one Open/Login/Save sequence per
    user without the converter guessing at browser lifecycle details.
    """

    for section, steps in steps_by_section:
        for index, step in enumerate(steps):
            if step.get("text") != "Login Trading Admin with:":
                continue
            rows = step.get("table") or []
            if len(rows) < 3:
                continue
            # Accept the header spellings used by both the generated corpus
            # and hand-authored manifests (User ID, UserID, user_id, User,
            # or ID) while leaving the table's original spelling intact.
            headers = [
                re.sub(r"[\s_-]+", "", str(item).strip().lower())
                for item in rows[0]
            ]
            user_index = next(
                (
                    column
                    for column, header in enumerate(headers)
                    if header in {"userid", "user", "id"}
                ),
                None,
            )
            if user_index is None:
                continue
            users = [
                str(row[user_index]).strip()
                for row in rows[1:]
                if user_index < len(row) and str(row[user_index]).strip()
            ]
            # The executable step historically permits repeated rows for one
            # user when an expected login error is being checked.  The unsafe
            # shape is a table that tries to establish multiple sessions, so
            # compare distinct user identities rather than raw row count.
            if len(set(users)) > 1:
                reviews.append(
                    "MULTI_USER_LOGIN_REQUIRES_SEPARATE_BROWSER_SESSIONS:"
                    f"{section}[{index}]"
                )



def split_gherkin_row(value: str) -> list[str]:
    """Split one Gherkin DataTable row while retaining escaped pipes."""

    text = value.strip()
    if not (text.startswith("|") and text.endswith("|")):
        raise ConversionError("DataTable row must begin and end with a pipe")
    cells: list[str] = []
    current: list[str] = []
    escaped = False
    for character in text[1:-1]:
        if escaped:
            current.append('\n' if character == 'n' else character if character in {'|', '\\'} else '\\' + character)
            escaped = False
        elif character == "\\":
            escaped = True
        elif character == "|":
            cells.append("".join(current).strip())
            current = []
        else:
            current.append(character)
    if escaped:
        current.append("\\")
    cells.append("".join(current).strip())
    return cells


def parse_admin_feature_behavior(feature_text: str) -> dict[str, Any]:
    """Extract executable Admin behavior without treating prose as steps."""

    sections: dict[str, list[dict[str, Any]]] = {"background": [], "steps": []}
    current_section: str | None = None
    current_step: dict[str, Any] | None = None
    scenario_count = 0
    tags: list[str] = []
    errors: list[str] = []
    feature_count = 0
    background_count = 0

    for line_number, line in enumerate(feature_text.splitlines(), 1):
        stripped = line.strip()
        if not stripped or stripped.startswith('#'):
            continue
        if re.match(r'^Feature\s*:', stripped):
            feature_count += 1
            continue
        if re.match(r'^(Scenario Outline|Examples|Rule)\s*:', stripped) or stripped.startswith(('"""', '```')):
            errors.append(f'unsupported Gherkin structure at line {line_number}')
            continue
        if stripped.startswith("@"):
            tags.extend(token for token in stripped.split() if token.startswith("@"))
            current_step = None
            continue
        if re.match(r"^Background\s*:", stripped, flags=re.I):
            background_count += 1
            if scenario_count:
                errors.append('Background must precede Scenario')
            current_section = "background"
            current_step = None
            continue
        if re.match(r"^(?:Scenario|Scenario Outline)\s*:", stripped, flags=re.I):
            scenario_count += 1
            current_section = "steps"
            current_step = None
            continue
        step_match = re.match(
            r"^(?:\*|Given|When|Then|And|But)\s+(.+?)\s*$",
            stripped,
            flags=re.I,
        )
        if step_match and current_section:
            current_step = {
                "text": normalize_step_text(step_match.group(1)),
                "table": [],
                "line": line_number,
            }
            sections[current_section].append(current_step)
            continue
        if stripped.startswith("|") and stripped.endswith("|") and current_step:
            current_step["table"].append(split_gherkin_row(stripped))
            continue
        errors.append(f'unrecognized Gherkin line {line_number}')
        current_step = None

    return {
        **sections,
        "tags": tags,
        "scenario_count": scenario_count,
        "errors": errors,
        "feature_count": feature_count,
        "background_count": background_count,
    }


def expected_admin_behavior(manifest: Mapping[str, Any]) -> dict[str, Any]:
    def compact(step: Mapping[str, Any]) -> dict[str, Any]:
        return {
            "text": str(step["text"]),
            "table": [list(row) for row in (step.get("table") or [])],
        }

    return {
        "background": [compact(step) for step in manifest.get("background", [])],
        "steps": [compact(step) for step in manifest.get("steps", [])],
    }


def compare_admin_feature_to_flow(
    manifest: Mapping[str, Any], feature_text: str
) -> dict[str, Any]:
    """Require the standalone Feature to express exactly the MCP hand-off."""

    actual = parse_admin_feature_behavior(feature_text)
    expected = expected_admin_behavior(manifest)
    mismatches: list[dict[str, Any]] = []
    for section in ("background", "steps"):
        actual_steps = [
            {"text": step["text"], "table": step["table"]}
            for step in actual[section]
        ]
        if actual_steps != expected[section]:
            mismatches.append(
                {
                    "section": section,
                    "expected_count": len(expected[section]),
                    "actual_count": len(actual_steps),
                    "first_difference": next(
                        (
                            index
                            for index, (left, right) in enumerate(
                                zip(expected[section], actual_steps), 1
                            )
                            if left != right
                        ),
                        min(len(expected[section]), len(actual_steps)) + 1,
                    ),
                }
            )

    tags = set(actual["tags"])
    if tags != {'@FEATURE=AdminGUI', '@CASE=' + manifest['case_id']} or len(tags) != len(actual['tags']):
        mismatches.append({"section": "tags", "reason": "tags differ from compiled contract"})
    if actual['errors'] or actual['feature_count'] != 1 or actual['background_count'] > 1:
        mismatches.append({"section": "structure", "reason": "unsupported or invalid Gherkin", "errors": actual['errors']})
    forbidden_tags = sorted(
        tag
        for tag in tags
        if tag == "@ADMIN_SETUP" or tag == "@REVIEW" or tag.startswith("@FEATURE=Binary")
    )
    if forbidden_tags:
        mismatches.append(
            {"section": "tags", "reason": "forbidden standalone Admin tag", "tags": forbidden_tags}
        )
    if actual["scenario_count"] != 1:
        mismatches.append(
            {
                "section": "structure",
                "reason": "standalone Admin Feature must contain exactly one Scenario",
                "actual_count": actual["scenario_count"],
            }
        )

    return {
        "aligned": not mismatches,
        "mode": "standalone_admin_exact",
        "flow_step_count": len(expected["background"]) + len(expected["steps"]),
        "feature_step_count": len(actual["background"]) + len(actual["steps"]),
        "mismatches": mismatches,
    }

