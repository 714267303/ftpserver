"""Private artifact I/O and canonical identity, shared by the v2 pipeline."""
from __future__ import annotations

import hashlib
import json
import os
import re
import tempfile
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
VERSION = 2


class FlowError(ValueError):
    pass


def digest(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                     separators=(",", ":")).encode()).hexdigest()


def file_hash(path: str | Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read_json(path: str | Path) -> dict:
    path = Path(path)
    if path.is_symlink() or not path.is_file():
        raise FlowError(f"missing or unsafe artifact: {path}")
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise FlowError(f"artifact must be an object: {path}")
    return data


def write_json(path: str | Path, data: dict) -> None:
    write_text(path, json.dumps(data, ensure_ascii=False, indent=2) + "\n")


def write_text(path: str | Path, value: str) -> None:
    path = Path(path)
    if path.is_symlink():
        raise FlowError(f"refusing to overwrite symlink: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            stream.write(value)
            stream.flush()
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def require(condition: bool, message: str) -> None:
    if not condition:
        raise FlowError(message)


def identifier(value: Any, field: str) -> str:
    require(isinstance(value, str) and bool(re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.:-]{0,199}", value)),
            f"invalid {field}")
    return value


def v2(data: dict, kind: str) -> None:
    require(data.get("schema_version") == VERSION and data.get("kind") == kind,
            f"expected {kind} schema_version=2; old Admin artifacts must be regenerated")
