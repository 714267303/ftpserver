"""Maintained operation adapters. Only this module produces executable wording."""
from __future__ import annotations

from .common import require

KINDS = {"navigate", "search", "open_detail", "set_fields", "effective_date", "submit",
         "confirm_message", "close_dialog", "approve", "verify_table", "verify_fields",
         "commit", "wait"}
MUTATIONS = {"set_fields", "effective_date", "submit"}


def scalar(value, label):
    require(isinstance(value, (str, int)) and not isinstance(value, bool), f"{label} must be text")
    text = str(value)
    require(bool(text.strip()) and not any(c in text for c in '\n\r\x00"'), f"invalid {label}")
    return text


def table(values):
    require(isinstance(values, dict) and bool(values), "operation requires fields")
    require(all(isinstance(v, (str, int)) and not isinstance(v, bool) and str(v).strip() and '\x00' not in str(v)
                for v in values.values()), 'invalid field value')
    return [[scalar(k, "field") for k in values], [str(v) for v in values.values()]]


def compile_operation(action, page, session, sessions):
    kind = action["operation"]
    args = action.get("args", {})
    label = page.label if page else ""
    detail = scalar(args.get("detail", label.removeprefix("Maintain ") + " Detail"), "detail page")
    rows = []
    if kind == "navigate":
        text = f'Select Trading Admin Left Menu "{page.menu_path}"'
    elif kind == "search":
        text, rows = f'Search in Trading Admin "{label}" page with:', table(args.get("fields"))
    elif kind == "open_detail":
        text = f'Double click table "{label}" column "{scalar(args.get("column"), "column")}" with:'
        rows = table(args.get("fields"))
    elif kind in {"set_fields", "verify_fields"}:
        verb = "Set" if kind == "set_fields" else "Check"
        text, rows = f'{verb} Trading Admin "{detail}" info as:', table(args.get("fields"))
    elif kind == "effective_date":
        choice = scalar(args.get("type"), "effective type")
        card = scalar(args.get("card", "Current Record"), "record card")
        text = f'Select effective type "{choice}" in detail info page "{detail}" "{card}" card'
    elif kind in {"submit", "commit", "close_dialog"}:
        button = scalar(args.get("button", "Save" if kind in {"submit", "commit"} else "Close"), "button")
        require(button.lower() not in {"approve", "reject", "cancel", "withdraw"},
                "approval and cleanup must use their dedicated branches")
        if kind in {"submit", "commit"}:
            require(button.lower() in {"save", "submit", "confirm", "ok"}, "submit must name a submission control")
        text = f'Click button "{button}" in Trading Admin detail info page "{detail}"'
        if kind == "close_dialog" or args.get("confirm_window") is True:
            text += " confirm window"
    elif kind == "confirm_message":
        text = f'Check the confirm message "{scalar(args.get("message"), "message")}" in Trading Admin detail info page "{detail}" confirm window'
    elif kind == "approve":
        maker = args.get("requester_session")
        require(maker in sessions and sessions[maker]["role"] == "maker", "approval needs the maker session")
        require(session["role"] == "checker" and maker != action["session"], "approval needs an independent checker")
        text = "Approve if updated with :"
        rows = [["Current Page", "Approver Browser", "Function Name", "Identifier", "Requester", "Req Status"],
                [detail, session["browser"], label, scalar(args.get("identifier"), "identifier"),
                 sessions[maker]["user"], "Pending"]]
    elif kind == "verify_table":
        text, rows = f'Check table "{label}" contains visible rows with:', table(args.get("fields"))
    elif kind == "wait":
        seconds = args.get("seconds")
        require(type(seconds) is int and 0 < seconds <= 30, "wait seconds must be between 1 and 30")
        text = f"Wait {seconds} seconds"
    else:
        raise ValueError(f"unsupported Admin operation: {kind}")
    return {"text": text, "table": rows}


def session_steps(session):
    return [{"text": "Open browser", "table": []},
            {"text": "Login Trading Admin with:", "table": [["User ID", "User Password"], [session["user"], session["password"]]]},
            {"text": "Clear Alert If Exist", "table": []},
            {"text": f'Save current browser to {session["browser"]}', "table": []}]
