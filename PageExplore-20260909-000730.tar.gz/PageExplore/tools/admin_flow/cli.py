"""Standalone v2 pipeline commands, also used by the Ruby batch entry point."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from .common import ROOT, VERSION, FlowError, digest, file_hash, read_json, write_json, write_text, require, v2
from .compiler import compile_plan, recompile, render, compare
from .source import read_case
from .evidence import validate_evidence, verify_saved_evidence


def main():
    parser = argparse.ArgumentParser(description="Admin plan v2 compiler and evidence verifier")
    parser.add_argument("--plan")
    parser.add_argument("--yaml")
    parser.add_argument("--flow")
    parser.add_argument("--observations")
    parser.add_argument("--draft", action="store_true")
    parser.add_argument("--transcript")
    parser.add_argument("--exploration-report")
    parser.add_argument("--output-flow")
    parser.add_argument("--output")
    parser.add_argument("--report")
    parser.add_argument("--verify-feature")
    parser.add_argument("--validate-only", action="store_true")
    parser.add_argument('--require-evidence', action='store_true')
    parser.add_argument("--step-index", default=str(ROOT / "odpt-automation-skill/Step_Index.json"))
    parser.add_argument("--page-explore-root", default=str(ROOT / "pageExplore"))
    args = parser.parse_args()
    require(bool(args.plan) != bool(args.flow), "provide exactly one of --plan or --flow")
    if args.plan:
        require(bool(args.yaml), "--plan requires --yaml")
        observations = read_json(args.observations) if args.observations else None
        flow = compile_plan(read_json(args.plan), read_case(args.yaml), args.step_index,
                            args.page_explore_root, observations, args.draft)
    else:
        flow = read_json(args.flow)
        recompile(flow, args.step_index, args.page_explore_root)
        if args.yaml:
            require(read_case(args.yaml)["sha256"] == flow["identity"]["source"],
                    "current YAML differs from the compiled Admin contract")
    if args.transcript:
        require(bool(args.exploration_report), "--transcript requires --exploration-report")
        evidence = validate_evidence(flow, args.transcript, read_json(args.exploration_report))
        flow["evidence"] = {**evidence, "transcript": str(Path(args.transcript).resolve())}
        flow["evidence_status"] = "verified"
    if args.verify_feature:
        verify_saved_evidence(flow)
        comparison = compare(flow, Path(args.verify_feature).read_text(encoding="utf-8"))
        if args.report:
            write_json(args.report, comparison)
        print(json.dumps(comparison))
        return 0 if comparison["aligned"] else 4
    if args.output_flow:
        write_json(args.output_flow, flow)
        write_json(Path(args.output_flow).with_name("admin-bindings.json"), flow["bindings"])
    if args.output:
        verify_saved_evidence(flow)
        evidence = flow.get("evidence", {})
        require(flow.get("evidence_status") == "verified" and evidence.get("contract_sha256") == flow["contract_sha256"],
                "Feature generation requires verified evidence for this contract")
        require(not flow["bindings"]["unresolved"], "unresolved observations cannot generate a Feature")
        write_text(args.output, render(flow))
    if args.require_evidence:
        verify_saved_evidence(flow)
    summary = {"schema_version": VERSION, "kind": "admin_compilation", "status": "passed",
               "case_id": flow["case_id"], "contract_sha256": flow["contract_sha256"],
               "action_count": len(flow["actions"]), "step_count": len(flow["steps"]),
               "unresolved": flow["bindings"]["unresolved"]}
    if args.report:
        write_json(args.report, summary)
    print(json.dumps(summary))
    return 0
