"""Validate ordered browser observations from completed MCP outputs, never code inputs."""
from __future__ import annotations

import json
import re
from pathlib import Path

from .common import FlowError, VERSION, digest, file_hash, require, v2

MARKER = "ODP_ADMIN_EVENT "


def output_records(value):
    if isinstance(value, dict):
        for key, child in value.items():
            if key in {'code', 'input', 'script'}:
                continue
            yield from output_records(child)
    elif isinstance(value, list):
        for child in value:
            yield from output_records(child)
    elif isinstance(value, str):
        # Playwright commonly wraps a console result in a JSON string.
        stripped = value.strip()
        if stripped.startswith('"'):
            try:
                yield from output_records(json.loads(stripped))
                return
            except json.JSONDecodeError:
                pass
        result_section = True
        for line in value.splitlines():
            if line.startswith('### '):
                result_section = bool(re.match(r'^### (?:Result|Console(?: messages)?)\s*$', line, re.I))
                continue
            if not result_section:
                continue
            if line.strip().startswith(('"', '{', '[')):
                try:
                    decoded = json.loads(line.strip())
                except json.JSONDecodeError:
                    pass
                else:
                    yield from output_records(decoded)
                    continue
            match = re.match(r'^\s*(?:-\s+)?(?:\[LOG\]\s*)?ODP_ADMIN_EVENT\s+(.+)$', line)
            if not match:
                continue
            tail = match.group(1)
            try:
                result, _ = json.JSONDecoder().raw_decode(tail)
            except json.JSONDecodeError:
                continue
            if isinstance(result, dict):
                yield result


def browser_records(path):
    records, seen = [], set()
    with Path(path).open(encoding="utf-8-sig") as stream:
        for line_number, line in enumerate(stream, 1):
            line = re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]', '', line)
            if not line.strip():
                continue
            try:
                event = json.loads(line)
            except json.JSONDecodeError as error:
                # stdout and stderr share the durable transcript. Plain CLI warnings
                # aren't tool events; a damaged JSON event must still fail closed.
                if line.lstrip().startswith(('{','[')) or MARKER in line:
                    raise FlowError(f"truncated or malformed MCP evidence at line {line_number}") from error
                continue
            if not isinstance(event, dict):
                continue
            part = event.get("part", event)
            if not isinstance(part, dict) or part.get("type") not in {"tool", "tool_use"}:
                continue
            tool = str(part.get("tool", ""))
            state = part.get("state", {})
            if "playwright" not in tool.lower() or state.get("status") != "completed" or state.get("error"):
                continue
            cid = part.get("callID", part.get("id", str(line_number)))
            if cid in seen:
                continue
            seen.add(cid)
            for record in output_records(state.get("output")):
                records.append({**record, "tool_call": cid, "line": line_number})
    return records


def validate_evidence(flow, transcript, model_report):
    v2(model_report, 'admin_exploration')
    require(model_report.get('case_id') == flow['case_id'], 'exploration report case mismatch')
    require(not flow["bindings"]["unresolved"], "resolve observed bindings before evidence validation")
    require(model_report.get("status") == "passed", "MCP did not report a completed rollback validation")
    require(not model_report.get('first_failure') and model_report.get('final_approval_executed') is not True and
            all(model_report.get(k) is not False for k in ('clean_state','cleanup_completed','final_state_restored')),
            'exploration report contains a failure or conflicting cleanup claim')
    events = browser_records(transcript)
    require(bool(events), "no structured Admin observations in completed Playwright output")
    plan_hash, source_hash = flow["identity"]["plan"], flow["identity"]["source"]
    shared = {a['id']: a for a in flow['actions'] if a['phase'] == 'shared'}
    auxiliary = {'session','baseline','restore',flow['plan']['cleanup']['action']} - {'none'}
    targets = {(a['page'],digest(a['subject'])) for a in flow['actions'] if a['operation'] in {'set_fields','effective_date','submit'}}
    for record in events:
        require(record.get("plan_sha256") == plan_hash and record.get("source_sha256") == source_hash,
                "MCP evidence belongs to a different plan or source YAML")
        require(record.get("operation") != "approve", "Approve was executed during MCP rollback exploration")
        require(record.get("status") == "passed", "MCP action or assertion did not pass")
        if record.get('action_id'):
            require(record['action_id'] in shared, 'unexpected action outside the shared MCP plan')
        else:
            require(record.get('operation') in auxiliary, 'unexpected browser observation operation')
            if record.get('operation') != 'session':
                require((record.get('route'),digest(record.get('subject'))) in targets, 'unexpected rollback record identity')
    required_sessions = {a['session'] for a in shared.values()}
    if flow['plan']['cleanup']['action'] != 'none':
        required_sessions.add(flow['plan']['cleanup']['session'])
    context_ids = set()
    for session in required_sessions:
        matches = [(i,e) for i,e in enumerate(events) if e.get('operation') == 'session' and e.get('session') == session]
        require(len(matches) == 1, f'{session}: exactly one authenticated browser session observation is required')
        index, event = matches[0]
        observed = event.get('observed', {})
        require(observed.get('authenticated') is True and bool(observed.get('context_id')), 'browser login was not verified')
        require(observed['context_id'] not in context_ids, 'maker/checker must use independent browser contexts')
        context_ids.add(observed['context_id'])
        require(all(index < i for i,e in enumerate(events) if e is not event and e.get('session') == session),
                f'{session}: login evidence must precede actions')
    cursor, matched, subjects = 0, [], {}
    for action in flow["actions"]:
        if action["phase"] != "shared":
            continue
        candidates = [(i, r) for i, r in enumerate(events) if r.get("action_id") == action["id"]]
        require(len(candidates) == 1, f'{action["id"]}: exactly one completed observation is required')
        index, record = candidates[0]
        require(index >= cursor, f'{action["id"]}: browser actions are out of plan order')
        cursor = index + 1
        for key in ("operation", "session"):
            require(record.get(key) == action[key], f'{action["id"]}: observation {key} mismatch')
        require(record.get("route") == action["page"], f'{action["id"]}: observed page differs from plan')
        require(record.get("subject", {}) == action["subject"], f'{action["id"]}: browser record identity differs from bindings')
        observed = record.get("observed")
        require(isinstance(observed, dict) and bool(observed), f'{action["id"]}: missing browser state')
        args = action.get("args", {})
        if "fields" in args:
            actual = observed.get("fields", {})
            require(isinstance(actual, dict) and all(str(actual.get(k)) == str(v) for k, v in args["fields"].items()),
                    f'{action["id"]}: browser fields differ from intended values')
        if action["operation"] == "effective_date":
            require(observed.get("effective_type") == args["type"], "effective date was not observed")
        if action["operation"] == "submit":
            require(observed.get("request_status") == "Pending", "submission did not produce a pending request")
            require(isinstance(observed.get('request_id'),str) and re.fullmatch(r'[a-f0-9]{64}',observed['request_id']) is not None,
                    'submission must identify the UI request using its SHA-256 (never a redacted UUID)')
        if action["subject"]:
            key = digest({"route": action["page"], "subject": action["subject"]})
            subjects[key] = {"route": action["page"], "subject": action["subject"]}
        matched.append({"action_id": action["id"], "tool_call": record["tool_call"], "line": record["line"]})
    cleanup = flow["plan"]["cleanup"]
    mutated = [a for a in flow["actions"] if a["operation"] in {"set_fields", "effective_date", "submit"}]
    for target in {digest({"route": a["page"], "subject": a["subject"]}): {"route": a["page"], "subject": a["subject"]} for a in mutated}.values():
        baseline = [(i, e) for i, e in enumerate(events) if e.get("operation") == "baseline" and e.get("subject") == target["subject"] and e.get("route") == target["route"]]
        restored = [(i, e) for i, e in enumerate(events) if e.get("operation") == "restore" and e.get("subject") == target["subject"] and e.get("route") == target["route"]]
        require(len(baseline) == 1 and len(restored) == 1, "each changed record needs baseline and restored-state observations")
        first_mutation = min(i for i, e in enumerate(events) if e.get("action_id") in {a['id'] for a in mutated if a['subject'] == target['subject'] and a['page'] == target['route']})
        require(baseline[0][0] < first_mutation and restored[0][0] >= cursor, "baseline/restore observations are out of order")
        before, after = baseline[0][1].get("observed", {}), restored[0][1].get("observed", {})
        require(isinstance(before.get("fields"), dict) and bool(before["fields"]), "baseline must contain active record fields")
        required_fields = set(target['subject'])
        for a in mutated:
            if a['subject'] == target['subject'] and a['page'] == target['route']:
                required_fields.update(a.get('args', {}).get('fields', {}))
        require(required_fields <= set(before['fields']) and before.get('pending_request') is False,
                'baseline must include record identity, edited fields and no pre-existing pending request')
        require(before.get("fields") == after.get("fields") and after.get("pending_request") is False,
                "original record or pending request was not restored")
        rollback = [(i, e) for i, e in enumerate(events) if e.get("operation") == cleanup["action"] and e.get("subject") == target["subject"] and e.get("route") == target["route"]]
        require(len(rollback) == 1 and cursor <= rollback[0][0] < restored[0][0], "cleanup action must precede restored-state observation")
        require(rollback[0][1].get("session") == cleanup.get("session"), "cleanup used a different session")
        require(rollback[0][1].get("observed", {}).get("pending_request") is False, "cleanup did not remove pending request")
        submissions = [e for e in events if e.get('operation') == 'submit' and e.get('subject') == target['subject'] and e.get('route') == target['route']]
        if submissions:
            require(len(submissions) == 1 and rollback[0][1]['observed'].get('request_id') == submissions[0]['observed']['request_id'],
                    'cleanup must target exactly the request created by this exploration')
    return {"schema_version": VERSION, "kind": "admin_evidence", "status": "passed",
            "case_id": flow["case_id"], "contract_sha256": flow["contract_sha256"],
            "transcript_sha256": file_hash(transcript), "actions": matched,
            "cleanup_action": cleanup["action"], "cleanup_completed": True,
            "final_state_restored": True, "final_approval_executed": False}


def verify_saved_evidence(flow):
    evidence = flow.get('evidence', {})
    require(flow.get('evidence_status') == 'verified' and evidence.get('contract_sha256') == flow['contract_sha256'],
            'verified browser evidence is required for this Admin contract')
    path = evidence.get('transcript')
    require(isinstance(path, str) and Path(path).is_file() and not Path(path).is_symlink(), 'original MCP transcript is required')
    require(file_hash(path) == evidence.get('transcript_sha256'), 'MCP transcript changed after verification')
    expected = validate_evidence(flow, path, {'schema_version':2,'kind':'admin_exploration',
                                             'case_id':flow['case_id'],'status':'passed'})
    require(all(evidence.get(k) == v for k,v in expected.items()), 'saved browser evidence differs from the transcript')
    return True
