"""Compile a business plan with current data into a standalone Admin contract."""
from __future__ import annotations

import copy
import re
from pathlib import Path

from admin_page_contract import load_page_catalog, validate_page_contract
from .common import VERSION, ROOT, digest, file_hash, identifier, require, v2
from .source import read_case, resolve_parameters, bind
from .operations import KINDS, MUTATIONS, compile_operation, session_steps, scalar
from .runtime import load_signatures, normalize_step, compare_admin_feature_to_flow


def compile_plan(plan, case, step_index, page_root, observations=None, draft=False):
    v2(plan, "admin_plan")
    require(not set(plan) - {'schema_version','kind','flow_id','case_id','name','channel','parameters','sessions','actions','cleanup','keywords','value_sets','object_sets'},
            'unknown plan keys; executable text belongs to the compiler')
    identifier(plan.get("flow_id"), "flow_id")
    require(plan.get("case_id") == case["case_id"], "plan case_id differs from source YAML")
    require(plan.get("channel") in {"admin", "hybrid"}, "plan channel must be admin or hybrid")
    actual_channel = 'admin' if all(s['channel'] == 'admin_gui' for s in case['steps']) else 'hybrid'
    require(plan['channel'] == actual_channel, 'plan channel differs from source YAML')
    require(isinstance(plan.get("name"), str) and bool(plan["name"].strip()), "plan name is required")
    require(isinstance(plan.get("parameters"), dict), "plan parameters must be an object")
    require(all(isinstance(item, dict) for item in plan['parameters'].values()), 'parameters must declare sources')
    unresolved = [name for name, item in plan["parameters"].items() if item.get("origin") == "observation" and name not in (observations or {})]
    observed = dict(observations or {})
    if draft:
        observed.update({name: f"unresolved_{name}" for name in unresolved})
    parameters = resolve_parameters(plan, case, observed)
    catalog = load_page_catalog(page_root)
    signatures = load_signatures(Path(step_index))
    require(bool(signatures), "Step_Index is required")
    raw_sessions = plan.get("sessions")
    require(isinstance(raw_sessions, dict) and bool(raw_sessions), "plan sessions are required")
    sessions = bind(raw_sessions, parameters)
    for name, session in sessions.items():
        identifier(name, "session")
        require(isinstance(session, dict), 'session must be an object')
        require(session.get("role") in {"maker", "checker", "user"}, "invalid session role")
        scalar(session.get("browser"), "browser alias")
        for field in ("user", "password"):
            ref = raw_sessions[name].get(field)
            require(isinstance(ref, dict) and set(ref) == {"param"} and
                    parameters.get(ref["param"], {}).get("origin") == "dataset",
                    f"session {field} must reference a dataset parameter, never credentials")
    require(len({s["browser"] for s in sessions.values()}) == len(sessions), "browser aliases must be unique")
    maker_users = {s["user"] for s in sessions.values() if s["role"] == "maker"}
    require(not maker_users.intersection(s["user"] for s in sessions.values() if s["role"] == "checker"),
            "maker and checker must use different dataset users")
    actions = plan.get("actions")
    require(isinstance(actions, list) and bool(actions), "plan actions are required")
    source_steps = {s["index"]: s for s in case["steps"] if s["channel"] == "admin_gui"}
    require(bool(source_steps), "source has no admin_gui TestSteps")
    steps, action_map, resolved_actions = [], {}, []
    opened, positions, covered, details = set(), {}, set(), {}
    current = None
    approval_subjects, submitted_subjects = set(), set()
    submission_sessions = {}
    pages, subject_bindings = {}, {}
    phase_started = False
    for raw in actions:
        require(isinstance(raw, dict), 'actions must be objects')
        require(not set(raw) - {'id','operation','session','phase','page','source_steps','subject','args'}, 'unknown action keys')
        require(isinstance(raw.get('args', {}), dict), 'action args must be an object')
        require(isinstance(raw.get('args', {}).get('fields', {}), dict), 'action fields must be an object')
        aid = identifier(raw.get("id"), "action id")
        require(aid not in action_map, f"duplicate action id {aid}")
        require(raw.get("operation") in KINDS, f"unknown operation in {aid}; add a maintained adapter first")
        source_ids = raw.get("source_steps")
        require(isinstance(source_ids, list) and source_ids and all(type(i) is int and i in source_steps for i in source_ids),
                f"{aid}: source_steps must reference Admin YAML steps")
        covered.update(source_ids)
        action = bind(raw, parameters)
        role_id = action.get("session")
        require(role_id in sessions, f"{aid}: session not declared")
        phase = action.get("phase")
        require(phase in {"shared", "feature"}, f"{aid}: phase must be shared or feature")
        if phase == "feature":
            phase_started = True
        require(not (phase_started and phase == "shared"), "shared path cannot resume after Feature-only branch")
        kind = action["operation"]
        require(kind != "approve" or phase == "feature", "Approve is deferred to Feature")
        require(kind != 'commit' or phase == 'feature', 'persistent non-countersign Save is deferred to Feature')
        require(kind not in MUTATIONS or phase == "shared", "maker changes must be browser validated")
        route = action.get("page")
        page = catalog.by_route.get(route)
        require(page is not None, f"{aid}: unknown PageExplore route")
        pages[route] = {"route": route, "label": page.label, "profile": page.profile_reference,
                        "profile_sha256": file_hash(page.profile_path)}
        if role_id not in opened:
            steps.extend(session_steps(sessions[role_id]))
            opened.add(role_id)
            current = role_id
        elif current != role_id:
            steps.append({"text": f'Switch browser to "{sessions[role_id]["browser"]}" and maximize', "table": []})
            current = role_id
        if kind == "navigate":
            positions[role_id] = route
            details.pop(role_id, None)
        elif kind != "approve":
            require(positions.get(role_id) == route, f"{aid}: explicit navigation in this session is required")
        subject = raw.get("subject", {})
        require(isinstance(subject, dict), f"{aid}: subject must be an object")
        for field, ref in subject.items():
            require(isinstance(ref, dict) and set(ref) == {"param"}, f"{aid}: subject must use bound parameter references")
            require(parameters[ref['param']].get('source_field') != 'expected', f'{aid}: record identity must come from Test Data or UI discovery')
        subject_value = bind(subject, parameters)
        if kind in {"search", "open_detail", "set_fields", "effective_date", "submit", "commit", "approve", "verify_table", "verify_fields"}:
            require(bool(subject_value), f"{aid}: record identity is required")
        for field, value in raw.get('args', {}).get('fields', {}).items():
            require(isinstance(value, dict) and set(value) == {'param'}, f'{aid}: variable field {field} must use a parameter')
            require(kind in {'verify_table','verify_fields'} or parameters[value['param']].get('source_field') != 'expected',
                    f'{aid}: Expected Result parameters are only for assertions')
        if kind in {"search", "open_detail", "verify_table"}:
            fields = action.get("args", {}).get("fields", {})
            require(all(fields.get(k) == v for k, v in subject_value.items()), f"{aid}: target fields differ from bound subject")
        if kind == "approve":
            require(action.get("args", {}).get("identifier") in subject_value.values(), f"{aid}: approval targets a different record")
        subject_key = digest({"page": route, "subject": subject_value})
        if kind == 'open_detail':
            details[role_id] = subject_key
        if kind in {'set_fields','effective_date','submit','commit','verify_fields'}:
            require(details.get(role_id) == subject_key, f'{aid}: open the same record detail before editing or submitting')
        if kind == 'effective_date':
            choice = str(action.get('args', {}).get('type', ''))
            action['args']['type'] = {'tomorrow':'Update for tomorrow','today':'Update for today'}.get(choice.lower(), choice)
        if kind == "submit":
            require(sessions[role_id]["role"] == "maker", "submission requires maker session")
            require(subject_key not in submitted_subjects, f'{aid}: duplicate maker submission for the same record')
            submitted_subjects.add(subject_key)
            submission_sessions[subject_key] = role_id
        if kind == "approve":
            require(subject_key in submitted_subjects, f"{aid}: no matching maker submission")
            require(subject_key not in approval_subjects, f'{aid}: duplicate approval for the same record')
            require(action.get('args', {}).get('requester_session') == submission_sessions[subject_key],
                    f'{aid}: requester differs from the submitting maker')
            approval_subjects.add(subject_key)
        step = compile_operation(action, page, sessions[role_id], sessions)
        if kind == "approve":
            step["mcp_execution"] = "deferred_to_feature"
        if kind == 'commit':
            step['mcp_execution'] = 'deferred_to_feature'
        step["action_id"] = aid
        step['page_route'] = route
        steps.append(step)
        action_map[aid] = len(steps)
        resolved_actions.append({**action, "subject": subject_value})
        subject_bindings[aid] = subject_value
    require(covered == set(source_steps), "plan must cover every source Admin TestStep")
    for idx, source in source_steps.items():
        linked = [a for a in resolved_actions if idx in a['source_steps']]
        kinds = {a['operation'] for a in linked}
        profile = source['profile']
        require(not profile or any(Path(pages[a['page']]['profile']).name == Path(profile).name for a in linked),
                f'source step {idx}: declared PageExplore profile is not covered')
        # Data may contain values like "Update for tomorrow" or "Approval Status"
        # even in a read-only search. Only action prose supplies omission hints.
        intent = source['step']
        # Conservative omissions checks, not a proof of natural-language equivalence.
        if re.search(r'\b(?:update|change|modify|edit)\b', intent, re.I):
            require('set_fields' in kinds, f'source step {idx}: update intent is missing set_fields')
            require(bool(kinds & {'submit','commit'}), f'source step {idx}: update intent is missing its save operation')
        if re.search(r'\bapprov(?:e|al)\b', intent, re.I):
            require({'submit','approve'} <= kinds, f'source step {idx}: missing submission/approval path')
        require(not source['expected'].strip() or bool(kinds & {'verify_table','verify_fields','confirm_message'}),
                f'source step {idx}: expected result needs a verification action')
        if 'approve' in kinds:
            approval_index = max(i for i,a in enumerate(linked) if a['operation'] == 'approve')
            require(any(a['operation'] in {'verify_table','verify_fields'} for a in linked[approval_index+1:]),
                    f'source step {idx}: verify business state after approval')
    require(submitted_subjects == approval_subjects, "every maker submission needs a corresponding Feature approval")
    cleanup = plan.get("cleanup")
    require(isinstance(cleanup, dict), "cleanup policy is required")
    expected_cleanup = "reject" if submitted_subjects else "cancel" if any(a["operation"] in MUTATIONS for a in actions) else "none"
    require(cleanup.get("action") == expected_cleanup, f"cleanup must be {expected_cleanup}")
    if expected_cleanup == "reject":
        require(cleanup.get("session") in sessions and sessions[cleanup["session"]]["role"] == "checker", "Reject cleanup requires checker")
    elif expected_cleanup == 'cancel':
        require(cleanup.get('session') in sessions, 'Cancel cleanup requires a declared session')
    reviews = []
    normalized = []
    background = []
    require(isinstance(plan.get('value_sets', []), list) and isinstance(plan.get('object_sets', []), list), 'resource sets must be lists')
    for dataset in plan.get("value_sets", ["admin_gui_value"]):
        value = scalar(dataset, "value set")
        background.append({"text": f"Load value from {value}", "table": []})
    for objects in plan.get("object_sets", ["odp-web-object"]):
        background.append({"text": f'Load object description from {scalar(objects, "object set")}', "table": []})
    for i, step in enumerate(background + steps):
        normalized.append(normalize_step(step, i, signatures, reviews))
    require(not reviews, "Step_Index mapping failed: " + ", ".join(reviews))
    flat = {"page": next(iter(pages.values())), "background": background, "steps": steps}
    page_issues = validate_page_contract(flat, page_root)
    require(not page_issues, "page/field contract failed: " + str(page_issues))
    bindings = {"schema_version": VERSION, "kind": "admin_bindings", "case_id": case["case_id"],
                "source_sha256": case["sha256"], "parameters": parameters, "unresolved": unresolved}
    identity = {"plan": digest(plan), "source": case["sha256"], "bindings": digest(bindings),
                "step_index": file_hash(step_index), "sitemap": file_hash(Path(page_root) / "sitemap.md"),
                "profiles": {route: value["profile_sha256"] for route, value in pages.items()},
                "compiler": digest({p.name: file_hash(p) for p in Path(__file__).parent.glob('*.py')})}
    identity['page_validator'] = file_hash(ROOT / 'tools/admin_page_contract.py')
    identity['yaml_parser'] = file_hash(ROOT / 'tools/lib/case_source.rb')
    compiled = {"schema_version": VERSION, "kind": "admin_flow", "flow_id": plan["flow_id"],
                "case_id": case["case_id"], "name": plan["name"], "channel": plan["channel"],
                "source_yaml": case["path"], "plan": copy.deepcopy(plan), "bindings": bindings,
                "identity": identity, "contract_sha256": digest(identity), "pages": pages,
                "page": flat["page"], "background": background, "steps": steps,
                'step_matches': [{'section':'background' if i < len(background) else 'steps',
                                  'index':i+1 if i < len(background) else i-len(background)+1,
                                  'match': item['match']} for i,item in enumerate(normalized)],
                "actions": resolved_actions, "action_steps": action_map,
                "evidence_status": "observed", "evidence": {},
                "reuse": {"safe_to_reuse": False, "keywords": plan.get("keywords", [])}}
    return compiled


def recompile(flow, step_index, page_root):
    v2(flow, "admin_flow")
    observed = {name: p["value"] for name, p in flow["bindings"]["parameters"].items() if p["origin"] == "observation"}
    compiled = compile_plan(flow["plan"], read_case(flow["source_yaml"]), step_index, page_root, observed)
    require(compiled["contract_sha256"] == flow["contract_sha256"], "Admin source, bindings, adapters or reference indexes changed; recompile and validate")
    require(compiled["steps"] == flow["steps"] and compiled["background"] == flow["background"], "compiled Admin flow was edited; repair the plan")
    for field in ('actions', 'bindings', 'identity', 'pages', 'page', 'action_steps', 'step_matches', 'case_id', 'channel', 'name'):
        require(compiled[field] == flow[field], f'compiled Admin {field} was edited; repair the plan')
    return compiled


def render(flow):
    def row(cells):
        return "        | " + " | ".join(str(c).replace('\\','\\\\').replace('|','\\|').replace('\n','\\n') for c in cells) + " |"
    lines = [f'@FEATURE=AdminGUI @CASE={identifier(flow["case_id"], "case_id")}',
             f'Feature: {scalar(flow["name"], "name")}', ""]
    for section, header in (("background", "Background:"), ("steps", f'Scenario: {flow["case_id"]}')):
        if not flow[section]:
            continue
        lines.append("    " + header)
        for step in flow[section]:
            lines.append("        * " + step["text"])
            lines.extend(row(cells) for cells in step.get("table", []))
        lines.append("")
    return "\n".join(lines)


def compare(flow, text):
    return compare_admin_feature_to_flow(flow, text)
