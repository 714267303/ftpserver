"""Read YAML through Ruby's safe parser; resolve only explicit data selectors."""
from __future__ import annotations

import json
import re
import subprocess
from pathlib import Path
from typing import Any

from .common import ROOT, FlowError, digest, require


def read_case(path: str | Path) -> dict:
    run = subprocess.run(["ruby", str(ROOT / "tools/lib/case_source.rb"), str(path)],
                         text=True, capture_output=True, timeout=30)
    require(run.returncode == 0, run.stderr.strip() or "cannot parse source YAML")
    case = json.loads(run.stdout)
    require(bool(case["case_id"]), "source YAML has no case Key")
    return case


def resolve_parameters(plan: dict, case: dict, observations: dict | None = None) -> dict:
    result = {}
    for name, selector in plan.get("parameters", {}).items():
        require(isinstance(selector, dict), f"parameter {name} must declare its source")
        origin = selector.get("origin")
        if origin == "yaml":
            index = selector.get("step")
            require(type(index) is int and 1 <= index <= len(case["steps"]), f"invalid source step for {name}")
            field = selector.get("field", "testdata")
            require(field in {'testdata', 'expected'}, f"{name}: select Test Data or Expected Result explicitly")
            text = case["steps"][index - 1][field]
            if "key" in selector:
                key = selector["key"]
                require(isinstance(key, str) and key.strip(), f"empty data key for {name}")
                matches = re.findall(r"^\s*" + re.escape(key) + r"\s*[:：]\s*(.+?)\s*$", text, re.M | re.I)
                require(len(matches) == 1, f"{name}: Test Data key must resolve exactly once in step {index}")
                value = matches[0]
            else:
                # Explicit span for prose or table cells. Never substitute from Precondition.
                value = selector.get("text")
                require(isinstance(value, str) and value and value in text,
                        f"{name}: selected literal is absent from source Test Data step {index}")
            result[name] = {"value": value, "origin": origin, "source_step": index, 'source_field': field,
                            "source_sha256": digest(text)}
        elif origin == "dataset":
            value = selector.get("alias")
            require(isinstance(value, str) and re.fullmatch(r"[A-Za-z_][A-Za-z0-9_.-]*", value) is not None,
                    f"{name}: invalid dataset alias")
            result[name] = {"value": value, "origin": origin}
        elif origin == "observation":
            value = (observations or {}).get(name)
            require(isinstance(value, str) and bool(value.strip()),
                    f"{name}: exploration must supply an observed data binding before compilation")
            result[name] = {"value": value, "origin": origin}
        else:
            raise FlowError(f"{name}: unsupported parameter origin")
    return result


def bind(value: Any, parameters: dict) -> Any:
    if isinstance(value, dict):
        if set(value) == {"param"}:
            name = value["param"]
            require(name in parameters, f"unknown parameter reference: {name}")
            return parameters[name]["value"]
        return {key: bind(child, parameters) for key, child in value.items()}
    if isinstance(value, list):
        return [bind(child, parameters) for child in value]
    require(isinstance(value, (str, int, bool)) or value is None, "invalid action parameter")
    return value
