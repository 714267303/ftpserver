#!/usr/bin/env python3
"""Admin v2 compiler. Old Gherkin-list manifests must be regenerated."""
import sys
from admin_flow.cli import main
from admin_flow.common import FlowError

if __name__ == "__main__":
    try:
        sys.exit(main())
    except (FlowError, ValueError, KeyError, TypeError, OSError) as error:
        print(f"Admin compilation failed: {error}", file=sys.stderr)
        sys.exit(2)
