#!/usr/bin/env python3
"""Boundary tests for the Feature execution/repair wrapper."""

from __future__ import annotations

import hashlib
import json
import os
import subprocess
import tempfile
import textwrap
import unittest
from pathlib import Path
from admin_test_support import verified_fixture
from admin_flow.compiler import render


ROOT = Path(__file__).resolve().parents[1]
RUNNER = ROOT / "tools" / "run_feature_debug.rb"


class RunnerModelSelectionTest(unittest.TestCase):
    def test_qwen_is_default_and_environment_override_is_preserved(self) -> None:
        environment = os.environ.copy()
        environment.pop("OPENCODE_MODEL", None)
        default_result = subprocess.run(
            ["ruby", str(RUNNER), "--help"],
            cwd=ROOT,
            env=environment,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=30,
            check=False,
        )
        self.assertEqual(0, default_result.returncode, default_result.stdout)
        self.assertIn(
            "OpenCode model (default: ollama/AE&I/Qwen3.8-27B)",
            default_result.stdout,
        )

        environment["OPENCODE_MODEL"] = "ollama/operator-override"
        override_result = subprocess.run(
            ["ruby", str(RUNNER), "--help"],
            cwd=ROOT,
            env=environment,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=30,
            check=False,
        )
        self.assertEqual(0, override_result.returncode, override_result.stdout)
        self.assertIn(
            "OpenCode model (default: ollama/operator-override)",
            override_result.stdout,
        )


class FeatureRepairBoundaryTest(unittest.TestCase):
    def test_admin_drift_is_blocked_before_cucumber_and_rebuilt_before_repair_run(self):
        with tempfile.TemporaryDirectory() as temporary:
            root=Path(temporary); flow,flow_path=verified_fixture(root)
            feature=root/'case.admin.feature'
            feature.write_text(render(flow).replace('210010011','wrong_record'))
            marker=root/'cucumber-called'
            cucumber=root/'cucumber.rb'
            cucumber.write_text('File.write('+repr(str(marker))+',"called")\nputs "1 scenario (1 passed)"\nputs "23 steps (23 passed)"\n')
            report=root/'report.json'
            cmd=['ruby',str(RUNNER),str(feature),'--workdir',str(root),'--report',str(report),
                 '--playwright-flow',str(flow_path),'--data-preflight','off','--cucumber-command',f'ruby {cucumber}']
            run=subprocess.run(cmd,text=True,capture_output=True,timeout=30)
            self.assertEqual(4,run.returncode,run.stdout+run.stderr)
            self.assertFalse(marker.exists())
            self.assertEqual('blocked_contract',json.loads(report.read_text())['execution']['status'])
            repaired=subprocess.run(cmd+['--repair'],text=True,capture_output=True,timeout=30)
            self.assertEqual(0,repaired.returncode,repaired.stdout+repaired.stderr)
            self.assertTrue(marker.exists()); self.assertEqual(render(flow),feature.read_text())

    def test_staged_repair_cannot_change_admin_datatable_before_rerun(self):
        with tempfile.TemporaryDirectory() as temporary:
            root=Path(temporary); flow,flow_path=verified_fixture(root)
            feature=root/'case.admin.feature'; feature.write_text(render(flow))
            marker=root/'runs'
            cucumber=root/'cucumber.rb'
            cucumber.write_text('File.open('+repr(str(marker))+',"a") { |f| f.puts "run" }\nwarn "locator not found (Selenium::WebDriver::Error::NoSuchElementError)"\nwarn "23 steps (1 failed, 22 passed)"\nexit 1\n')
            repair=root/'repair.rb'
            repair.write_text('Dir.glob("target/*.feature").each { |p| File.write(p, File.read(p).gsub("210010011", "wrong_record")) }\n')
            report=root/'report.json'
            run=subprocess.run(['ruby',str(RUNNER),str(feature),'--workdir',str(root),'--report',str(report),
                '--playwright-flow',str(flow_path),'--data-preflight','off','--cucumber-command',f'ruby {cucumber}',
                '--repair','--repair-attempts','1','--repair-experience-dir',str(root/'experience'),
                '--repair-opencode-command',f'ruby {repair}'],text=True,capture_output=True,timeout=30)
            self.assertNotEqual(0,run.returncode,run.stdout+run.stderr)
            self.assertEqual(['run'],marker.read_text().splitlines())
            self.assertEqual(render(flow),feature.read_text())
            payload=json.loads(report.read_text())
            self.assertIn('contract',json.dumps(payload['repair']).lower())

    def test_custom_ruby_step_failure_never_invokes_repair_or_changes_files(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            runtime = Path(temporary)
            feature = runtime / "features" / "case.feature"
            custom_step = runtime / "features" / "customized_steps" / "user_special_steps.rb"
            feature.parent.mkdir(parents=True)
            custom_step.parent.mkdir(parents=True)
            feature.write_text(
                textwrap.dedent(
                    """\
                    @FEATURE=Binary
                    Feature: custom step boundary

                    Scenario: use a user step
                        * User special action
                    """
                ),
                encoding="utf-8",
            )
            custom_step.write_text(
                'Given(/^User special action$/) { nil.missing_user_method }\n',
                encoding="utf-8",
            )
            feature_before = hashlib.sha256(feature.read_bytes()).hexdigest()
            ruby_before = hashlib.sha256(custom_step.read_bytes()).hexdigest()

            fake_cucumber = runtime / "fake_cucumber.rb"
            fake_cucumber.write_text(
                textwrap.dedent(
                    """\
                    #!/usr/bin/env ruby
                    warn "features/customized_steps/user_special_steps.rb:42:in `block': undefined method `missing_user_method' for nil:NilClass (NoMethodError)"
                    warn "1 scenario (1 failed)"
                    warn "1 step (1 failed)"
                    exit 1
                    """
                ),
                encoding="utf-8",
            )
            fake_cucumber.chmod(0o755)
            repair_marker = runtime / "repair-command-was-called"
            fake_repair = runtime / "fake_repair.rb"
            fake_repair.write_text(
                textwrap.dedent(
                    f"""\
                    #!/usr/bin/env ruby
                    File.write({str(repair_marker)!r}, "called\\n")
                    exit 0
                    """
                ),
                encoding="utf-8",
            )
            fake_repair.chmod(0o755)
            report = runtime / "report.json"

            result = subprocess.run(
                [
                    "ruby",
                    str(RUNNER),
                    str(feature),
                    "--workdir",
                    str(runtime),
                    "--cucumber-command",
                    str(fake_cucumber),
                    "--report",
                    str(report),
                    "--repair",
                    "--repair-opencode-command",
                    str(fake_repair),
                    "--data-preflight",
                    "off",
                ],
                cwd=ROOT,
                env=os.environ.copy(),
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                timeout=30,
                check=False,
            )

            self.assertNotEqual(0, result.returncode, result.stdout)
            payload = json.loads(report.read_text(encoding="utf-8"))
            self.assertEqual(
                "custom_step_implementation",
                payload["execution"]["failure_classification"]["category"],
            )
            self.assertEqual("blocked_runtime", payload["repair"]["status"])
            self.assertEqual(
                "custom_step_implementation", payload["repair"]["stop_reason"]
            )
            self.assertEqual([], payload["repair"]["attempts"])
            self.assertFalse(repair_marker.exists(), result.stdout)
            self.assertEqual(feature_before, hashlib.sha256(feature.read_bytes()).hexdigest())
            self.assertEqual(ruby_before, hashlib.sha256(custom_step.read_bytes()).hexdigest())


if __name__ == "__main__":
    unittest.main()
