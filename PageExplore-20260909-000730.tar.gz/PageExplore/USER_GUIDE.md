# PageExplore User Guide

This is the canonical tester-facing guide for the portable PageExplore
delivery. It assumes the bundle is copied into a project such as:

```text
ProjectA/
  features/
  resource/
  PageExplore/
```

`PageExplore/` contains documentation, conversion skills, indexes, and
diagnostic tools. It is not the UAT runtime. The runtime project supplies the
Ruby gems, custom steps, data files, services, and credentials required by
Cucumber.

## 1. Quick Paths

Run commands from the `ProjectA/` root unless stated otherwise. Always pass
`--run-workdir .` (or the absolute ProjectA path) when a Feature is executed.

Generate Excel -> YAML -> Feature without executing the Feature:

```bash
ruby PageExplore/tools/batch_transform_tc.rb \
  EXCEL_DIR YAML_DIR features/test_case/CASE
```

This is the normal generation mode when account/session aliases, credentials,
or environment records such as an SMP ID have not been assigned yet. It does
not claim that the generated Web or Binary business flow was executed.

Validate Gherkin and step-definition matching without business-side effects:

```bash
ruby PageExplore/tools/batch_transform_tc.rb \
  EXCEL_DIR YAML_DIR features/test_case/CASE \
  --run-generated --dry-run \
  --run-workdir . \
  --cucumber-command 'cucumber'
```

Inspect runtime-data readiness without starting Cucumber, Playwright, or the
repair model:

```bash
ruby PageExplore/tools/batch_transform_tc.rb \
  EXCEL_DIR YAML_DIR features/test_case/CASE \
  --run-generated --preflight-only \
  --run-workdir .
```

Generate and run each new Feature:

```bash
ruby PageExplore/tools/batch_transform_tc.rb \
  EXCEL_DIR YAML_DIR features/test_case/CASE \
  --run-generated \
  --run-workdir . \
  --cucumber-command 'bundle exec cucumber'
```

Generate, repair failures, and rerun until Cucumber passes:

```bash
export DISPLAY=:99
ruby PageExplore/tools/batch_transform_tc.rb \
  EXCEL_DIR YAML_DIR features/test_case/CASE \
  --repair-generated \
  --run-workdir . \
  --cucumber-command 'bundle exec cucumber' \
  --repair-attempts 2
```

The no-value `--repair` after the three directories is equivalent to
`--repair-generated`. `0` is the default and means no repair-cycle limit:
the loop stops when Cucumber passes or when a repair/model/boundary error
prevents another safe cycle.

For an Admin or Hybrid case, that command owns the complete ordered pipeline:

1. `Step 2`: parse Excel and generate YAML.
2. `Step 3`: inspect `Execution Channel` and classify the case.
3. `Step 1`: reuse a verified flow, or validate the missing Admin path through
   Playwright MCP and roll the validation request back.
4. `Step 4`: deterministically generate `<case>.admin.feature` from the Admin
   flow and compare its ordered steps and DataTables with the MCP hand-off.
5. `Step 5A`: run and, when safely justified, repair only the standalone Admin
   Feature.
6. `Step 6`: promote the flow only from the passing standalone Admin report.
7. `Step 7`: for a single-day Hybrid case, generate `<case>.feature`; for a
   next-trading-day case, generate `<case>-Day1.feature` and
   `<case>-Day2.feature`. In both cases also generate
   `<case>.execution-flow.json`, which is the machine-readable run order.
   Non-Admin Features are never merged into the Admin artifact for repair.

If Playwright and rollback completed but the run stopped only at
`admin_flow_correctness`, the recorded run can be handed back to the semantic
stage without repeating browser actions:

```bash
ruby PageExplore/tools/batch_transform_tc.rb EXCEL_DIR YAML_DIR TARGET_DIR \
  --repair-generated \
  --admin-handoff-run outputs/admin/CASE_ID/run-TIMESTAMP
```

Use the exact run directory printed by the failed invocation. Recovery rejects
a different YAML hash when one was recorded, reruns all report/transcript and
semantic checks, and remains blocked when the browser did not prove required
submission or rollback behavior. It reuses the existing same-name YAML and skips
both Excel parsing and Excel-to-YAML model generation.

For a single-day Hybrid case, the execution flow contains two Feature stages:

```text
admin -> continuation
```

For a cross-day case such as ODP-T2194, it contains three Features and one
external gate:

```text
admin -> day1 -> night_batch (external gate) -> day2
```

Day1 ends with `Save FIX dumpfile <case>-Day1`, while the Day2 Background
loads the same dump. The YAML `batch` TestStep is not rendered as `Wait`,
`@REVIEW`, or invented Gherkin. In a real `--run-generated` or
`--repair-generated` execution, the batch exits with code 3 after Day1 and
records `execution.status=waiting_for_gate` in the JSON. After an operator or
scheduler has really completed night batch and the market is OPEN, resume only
the remaining stage with the same runtime options:

```bash
ruby PageExplore/tools/batch_transform_tc.rb \
  --run-execution-flow features/test_case/CASE/<case>.execution-flow.json \
  --complete-gate night_batch \
  --repair-generated \
  --run-workdir . \
  --cucumber-command 'bundle exec cucumber'
```

`--complete-gate` is accepted only after that flow has already stopped at the
named gate; it cannot be supplied to collapse Day1, night batch, and Day2 into
one run. Dry-run and preflight modes validate every Feature without completing
or changing the real external-gate state.

If an Admin repair changes the ordered flow or a DataTable away from the MCP
handoff, the batch deterministically rebuilds only `<case>.admin.feature` from
that flow and retests it once. The non-Admin continuation remains withheld
until the realigned Admin Feature passes.

During Admin exploration, explicit YAML Test Data is declared the runtime-data
authority over conflicting aliases in Precondition or Step prose.
The integrated MCP stage uses rollback validation. In a maker/checker case it
submits the maker request, finds it in the checker countersign view, then
Rejects it and verifies that the original active state remains. It never clicks
Approve. Without countersign it Cancels before persistent save. The Reject or
Cancel is cleanup evidence and is not emitted into the semantic manifest. The
manifest retains the required approval with
`mcp_execution=deferred_to_feature`; the generated Feature repeats the maker
operation and performs Approve during Step 5. A run cannot pass unless cleanup
and restored state are both reported and supported by the MCP transcript.

Binary-only cases mark the Admin exploration and flow-promotion stages as not
applicable. Conversion-only mode does not execute the Feature; pass
`--admin-explore` if it should capture a missing Admin flow anyway.

Repair one existing Feature without converting Excel or YAML:

```bash
ruby PageExplore/tools/batch_transform_tc.rb \
  --repair features/test_case/CASE/case.feature \
  --run-workdir . \
  --cucumber-command 'cucumber' \
  --repair-attempts 2
```

The standalone equivalent is:

```bash
ruby PageExplore/tools/run_feature_debug.rb features/test_case/CASE/case.feature \
  --workdir . \
  --cucumber-command 'cucumber' \
  --repair
```

`--debug-feature` and `--diagnose` are read-only diagnosis modes. They do not
edit a Feature. Use explicit `--repair` when modification is intended.

The existing-Feature command first preflights runtime references, then runs
Cucumber once. It invokes OpenCode only after an actionable Cucumber failure.
It does not invoke Playwright MCP unless a flow and replay adapter are supplied
explicitly as described in section 6.

## 2. Runtime and Model Configuration

Before Admin exploration, copy `.env.example` to the runtime project root and
set `ODP_URL`, maker `ODP_USERNAME`/`ODP_PASSWORD`, and, for maker/checker
cases, `ODP_CHECKER_USERNAME`/`ODP_CHECKER_PASSWORD`. In the portable layout this
is `ProjectA/.env`, beside `ProjectA/features`, `ProjectA/resource`, and
`ProjectA/PageExplore`; it is not `ProjectA/PageExplore/.env`. Do not commit or
package `.env`. The batch
runner resolves the non-secret `ODP_URL` itself (from `--odp-url`, the exported
`ODP_URL`, or the runtime `.env`) and gives only that URL through the process
environment. The Playwright MCP process receives the dotenv path through
`--secrets` to redact matching values in browser-tool responses; this option
does not substitute dotenv key names supplied as browser inputs. During Admin
exploration only, the model reads that exact dotenv file before navigation and
uses `ODP_USERNAME`/`ODP_PASSWORD` for maker submission and
`ODP_CHECKER_USERNAME`/`ODP_CHECKER_PASSWORD` for Reject cleanup (or the
corresponding `SECRET_ODP_*` aliases) solely as Playwright login-field values.
It must not enter the literal key names.
Excel/YAML conversion remains credential-blind, and Admin file writes remain
limited to the isolated evidence directory. The batch redacts the configured
login values from terminal output and the OpenCode transcript; reports and flow
manifests must never contain them.
These four dotenv values are only for MCP submission and rollback. The
generated Feature still resolves `admin_gui_user1`/`admin_gui_user2`
credentials from the runtime `resource/admin_gui_value.csv`; configure those
aliases separately.

Snapshot element refs are observation-only in Admin exploration. Ref-based
click/type/fill/select/hover/drag tools are denied; the agent uses fresh
snapshots to discover current role/name/label/id information, then performs UI
actions through raw Playwright locator code or reviewed qaGrid guide snippets.
Direct backend calls and fetch/XHR overrides remain prohibited. If the model
process stops without writing its required
report, the parent batch process creates a deterministic failed report from the
redacted event transcript. This preserves diagnostics but never converts an
incomplete exploration into a pass.

`ODP_URL` can be written as a full URL (`https://10.0.0.1/`) or as the legacy
host/IP shorthand (`10.0.0.1` or `10.0.0.1:8443`); shorthand is normalized to
HTTPS. The observed landing-page forms
`/ESUI/eventServerLanding.html?login_mode=both` and
`/ESUI/eventServerLanding_html?login_mode=both` are also accepted and reduced
to the base URL. Other query strings, fragments, and credentials are rejected.

For the portable delivery, create it from the project root with:

```bash
cd /path/to/ProjectA
cp PageExplore/.env.example .env
```

An inherited empty or placeholder `ODP_URL` no longer masks a valid dotenv
file. The runner checks both its launch directory and the parent of the copied
`PageExplore/` tree. A failed lookup reports every checked path and whether it
was missing, unreadable, missing the key, or had an invalid URL. To bypass path
discovery completely, use:

```bash
ruby PageExplore/tools/batch_transform_tc.rb ... \
  --odp-url 'https://odp-host/' \
  --playwright-mcp-secrets "$PWD/.env"
```

The default OpenCode model is the provider-qualified model:

```text
ollama/AE&I/Qwen3.8-27B
```

Select any model printed by `opencode models` with either command:

```bash
--model provider/model
```

or:

```bash
export OPENCODE_MODEL='ollama/AE&I/Qwen3.8-27B'
```

An explicit `--model` or `-m` already present in a custom OpenCode command is
preserved. `opencode models` lists configured models but does not prove that
the provider endpoint is reachable. Verify the configured `/v1/models`
endpoint before a repair run. If a provider requires an environment API key,
allowlist only that variable through `OPENCODE_ENV_ALLOWLIST`.

### Playwright MCP HTTPS certificates

Playwright MCP is started by OpenCode as a local MCP server. The internal ODP
HTTPS certificate is therefore handled by the Playwright browser context, not
by the model provider. The maintained installer enables the browser-side
bypass by default:

```bash
sudo env PLAYWRIGHT_MCP_IGNORE_HTTPS_ERRORS=1 \
  bash path/to/install_playwright_mcp.sh
```

The generated `mcp.playwright.command` contains
`--ignore-https-errors` and the generated MCP entry also records the matching
environment variable. To configure an existing ProjectA manually, add that
flag to the Playwright command in `opencode.json` or `opencode.jsonc`:

```jsonc
{
  "$schema": "https://opencode.ai/config.json",
  "mcp": {
    "playwright": {
      "type": "local",
      "command": [
        "/opt/playwright-mcp/runtime/node",
        "/opt/playwright-mcp/current/node_modules/@playwright/mcp/cli.js",
        "--isolated",
        "--ignore-https-errors"
      ],
      "cwd": ".",
      "enabled": true
    }
  }
}
```

Omitting `--headless` is the Playwright MCP headed mode. For the maintained VNC
image, export `DISPLAY=:99` before starting the batch; the batch also detects
an existing `/tmp/.X11-unix/X99` socket. It removes a historical `--headless`
argument from the temporary OpenCode MCP entry unless
`--playwright-mcp-headless` is explicitly supplied. This normalization does
not rewrite the project's `opencode.json[c]`.

Recent Playwright MCP releases also accept
`PLAYWRIGHT_MCP_IGNORE_HTTPS_ERRORS=1`; it can be supplied in the local MCP
entry's `environment` object or exported before starting OpenCode. The flag
and variable affect browser navigation only. They do not disable TLS
verification for the Ollama/OpenAI-compatible provider; use a trusted CA
(for example `NODE_EXTRA_CA_CERTS`) for that connection instead. Do not use
the global `NODE_TLS_REJECT_UNAUTHORIZED=0` workaround.

The Feature runner and batch transformer set this non-sensitive Playwright MCP
variable to `1` by default when they launch OpenCode for diagnosis or repair;
set `PLAYWRIGHT_MCP_IGNORE_HTTPS_ERRORS=0` to opt out for that invocation.
Other environment variables remain filtered unless explicitly allowlisted.

The separate Python `web-playwright` runner follows the same default and sets
`PW_IGNORE_HTTPS_ERRORS=true`; set it to `false` when that runner must verify
the certificate. This setting is independent of the Cucumber/Selenium driver.

If an OpenCode config already exists, the installer intentionally leaves it
unchanged and writes a template at its configured template path. Merge the
`mcp.playwright` entry, restart OpenCode, and verify with
`opencode mcp list --print-logs --log-level DEBUG`. The OpenCode key is
`mcp`; a `.mcp.json` file using `mcpServers` belongs to other clients and is
not the entry read by this OpenCode setup.

The runner discovers `ProjectA/opencode.json` or `opencode.jsonc` from
`--run-workdir` and its parents. Set `OPENCODE_CONFIG` when the project keeps
the file elsewhere. The repair staging permission overlay still restricts
the model to the staged Feature.

The Cucumber command is passed as a command string. For a Bundler checkout use
`'bundle exec cucumber'`; for a checkout with a globally available executable
use `'cucumber'`. The runner appends the absolute Feature path unless the
command contains the `{feature}` placeholder.

## 3. Admin Exploration Knowledge

Read these files in order before using Playwright MCP:

1. `PageExplore/pageExplore/sitemap.md` for login, SPA navigation, and routes.
2. `PageExplore/pageExplore/pages/INDEX.md` and the selected page profile.
3. `PageExplore/pageExplore/GRID_OPERATION_GUIDE.md` before any Grid action.

ODP uses a React SPA and canvas-based qaGrid tables. Read Grid data through
`window.qaGridApi[gridKey]`. Use Playwright `page.route('**/api/private/subscribeView')`
for server filtering and double-click the canvas wrapper for row details.
Do not call backend APIs directly, override `fetch`/`XMLHttpRequest`, copy
dynamic UUIDs, or use `qaGridApi.setRowData()` as a business operation.

Successful semantic Admin flows are stored under:

```text
PageExplore/odpt-automation-skill/Admin_GUI/flow_catalog/
```

Only schema v2 contracts with `evidence_status: verified` and
`reuse.safe_to_reuse: true` are selected automatically. Source, bindings,
adapters, page references and transcript hashes are verified again. Old v1
artifacts must be regenerated; there is no unverified-flow override.

Read [Admin pipeline v2](odpt-automation-skill/Admin_GUI/Admin_Pipeline_V2.md).
The model writes `admin-plan.json` before MCP, scripts compile and validate it,
and MCP produces structured observations. Finalization writes `admin-flow.json`,
`admin-bindings.json`, `admin-evidence.json` and `handoff-report.json`.
`--admin-handoff-run RUN_DIR` consumes the original v2 plan/YAML/transcript and
never repeats Excel conversion or MCP.

`--repair-generated` explores a missing plan through MCP; `--admin-explore`
enables it for other generation modes. `--no-admin-explore` requires reusable
evidence. Headed mode is default, with `--playwright-mcp-headless` available.
MCP uses maker submission and checker Reject cleanup. Feature uses Approve.
Browser timeout limits total elapsed time as well as inactivity.

## 4. Conversion

The Excel parser can inspect one workbook without running the full batch:

```bash
python3 PageExplore/odp-tc-excel-yaml-skill/parse_excel.py case.xlsx
python3 PageExplore/odp-tc-excel-yaml-skill/parse_excel.py case.xlsx 0
```

The second argument is a zero-based case row. Follow
`PageExplore/odp-tc-excel-yaml-skill/SKILL.md` and `rules.md`: preserve source
keys, data, order, and expected-result counts; do not invent checks.

For reviewed Admin manifests, the deterministic converter can be used
directly:

```bash
python3 PageExplore/tools/admin_feature_converter.py \
  --flow path/to/flow.json \
  --output features/test_case/CASE/case.admin.feature \
  --report features/test_case/CASE/case.conversion.json \
  --step-index PageExplore/odpt-automation-skill/Step_Index.json
```

Hybrid uses the same independent Admin compiler. The complete Background,
ordered steps, DataTables, tags and Scenario structure must equal the compiled
contract before execution. Invalid mappings or unverified evidence fail closed.
The compiler report carries the contract hash, action count and step count;
compiled steps carry action IDs to trace back to source and MCP observations.

Cross-day Hybrid produces Admin, Day1 and Day2 Features plus execution-flow v2.
It records source/Feature/report/contract hashes and verifies them on resume.
Day1 success stops at an external night-batch gate. Day2 runs only after explicit
operator acknowledgement. Failed or interrupted execution may have changed
business state and cannot be silently repeated by resume.

## 5. Running, Diagnosing, and Repairing

Run one Feature:

```bash
ruby PageExplore/tools/run_feature_debug.rb path/to/case.feature \
  --workdir . \
  --cucumber-command 'bundle exec cucumber' \
  --report outputs/feature-runs/case.json \
  --log outputs/feature-runs/case.log
```

Diagnose a failed Feature without changing it:

```bash
ruby PageExplore/tools/run_feature_debug.rb path/to/case.feature \
  --workdir . \
  --cucumber-command 'bundle exec cucumber' \
  --diagnose
```

Repair mode runs Cucumber first. Only after a failure does OpenCode receive a
bounded, redacted report and a disposable staging copy. The staging tree
contains read-only Skill, PageExplore, ODP-document, and index references;
runtime `features/`, `resource/`, browser state, and credentials are not
copied. Only the staged Feature is editable. The runner audits hashes and
changed paths, atomically promotes that one file, and reruns Cucumber.

User-defined/special Ruby steps remain read-only even in repair mode. If a
code exception such as `NoMethodError`, `NameError`, or `ArgumentError`
originates under `features/customized_steps/` or
`features/step_definitions/`, the report uses category
`custom_step_implementation`, automatic repair is withheld, and the Feature
is left unchanged. Correct the user `.rb` implementation manually, then rerun
the same Feature or execution flow.

Repair stops immediately when Cucumber returns success. It also stops on a
model error, timeout, unauthorized path change, missing Feature, concurrent
target change, or a finite `--repair-attempts` limit. A repair transcript is
written to `.repair.md` after every model call. A `rerun_N.log` is written only
when the model completed within the boundary and a rerun actually started.

Reports and logs include execution status, Feature/index hashes, detected
error-code fields, category-scoped matches, and explicit FIX field/value enum
matches. Output is captured with a byte limit and redacted after complete
capture so values split across chunks cannot bypass filtering.

### Runtime-data readiness and skipped steps

In repair mode, `--data-preflight auto` blocks Cucumber and model repair when
the tool can prove that a referenced value file, placeholder, or symbolic
runtime value is unresolved. The scan checks the ProjectA `resource/`,
`resources/`, `features/`, and `config/` trees. Finding an alias such as
`smp_id_ca1` proves only that it is configured somewhere; it does not prove
that the current ODP page contains the resolved SMP record or that a session
can authenticate.

Use `--allow-unresolved-data` only to collect one real Cucumber result. The
model repair remains withheld because missing test data is not a Feature bug.
Use `--data-preflight off` only after a human confirms that the runtime resolves
the value outside the scanned project data contract.

Cucumber prints failed and skipped steps together. For example,
`64 steps (1 failed, 57 skipped, 6 passed)` means only six steps completed and
the other 57 were not executed. If the failure is the Admin login, a later SMP
search did not run, so the report must not claim that the SMP ID was missing.
Once login is repaired and execution reaches the search/assertion, an actual
missing-row message is classified as `runtime_data_lookup`.

After a real run, `runtime_data_lookup`, `credential_or_session`, and
`environment_or_browser` failures stop as `blocked_runtime`; OpenCode is not
allowed to rewrite the Feature around external state. The only exception is a
`runtime_data_lookup` for which a verified, safe replay adapter passes with the
current Feature/bindings hashes. That evidence establishes a real
Playwright/Cucumber divergence that repair may investigate.

The runner never skips selected steps inside one Scenario: later steps depend
on earlier state. For partial runtime validation, split genuinely independent
flows into tagged Scenarios and pass Cucumber arguments explicitly, for
example `--cucumber-arg=--tags --cucumber-arg=@data-independent`. Otherwise
use `--dry-run` for syntax/step-definition validation only.

Useful runner options:

| Option | Purpose |
|---|---|
| `--repair` | Repair only the requested Feature, with bounded reruns |
| `--diagnose` / `--debug` | Read-only model diagnosis after failure |
| `--repair-attempts N` | Repair/rerun limit; 1..5, default 2 |
| `--repair-opencode-command CMD` | Command used for repair |
| `--allow-review` | Permit a Feature tagged `@REVIEW` |
| `--dry-run` | Pass `--dry-run` to Cucumber |
| `--preflight-only` | Report data readiness without Cucumber, Playwright, or OpenCode |
| `--data-preflight MODE` | `auto`, `block`, `report`, or `off` runtime-data policy |
| `--allow-unresolved-data` | Collect Cucumber evidence but withhold model repair |
| `--cucumber-arg ARG` | Forward one Cucumber argument; repeatable |
| `--binary-debug` | Set `LOGLEVEL=DEBUG`, `WABI_FIX_DEBUG=1`, `WABI_TIMING=1` |
| `--error-category ID` | Disambiguate a generic numeric reason code; repeatable |
| `--fix-index PATH` | Override the FIX dictionary index |
| `--error-index PATH` | Override the error-code index |
| `--grid-index PATH` | Override the qaGrid index |
| `--odp-doc-index PATH` | Override the ODP business-document index |
| `--step-index PATH` | Override the runtime UAT Step index |

`--binary-debug` affects only a Feature execution. It is useful for Binary/FIX
failures but does not repair a Web login or provider connection problem.

## 6. Admin contract repair

Run `run_feature_debug.rb FEATURE --playwright-flow FLOW --repair` to restore a
Feature that drifted from a verified v2 contract, before Cucumber starts. This
recompilation checks the source and original transcript. Subsequent model repair
is isolated; a table/step/order change outside the contract is blocked before
promotion or rerun. User custom `.rb` files are read-only.

If the compiled plan or adapter is itself wrong, repair that source and validate
it. Do not modify the Feature to hide the mismatch, add Binary operations, or
invent browser evidence. Changed plan/data requires fresh MCP validation;
mapping-only fixes can re-finalize the original observations when still valid.
The default repair limit is 2 attempts (allowed 1..5), and unchanged output stops
retries. Automatic live replay between Admin repair attempts is unsupported.

## 7. Business Documents and Indexes

The restored ODP Functional Specifications are under
`PageExplore/odp-docs/`. Use `INDEX.md` to select only the relevant document
sections. Business prose explains intent; runtime Step definitions and
`Step_Index.json` decide executable Gherkin syntax.

The tester bundle ships read-only indexes:

| Index | Purpose |
|---|---|
| `odpt-automation-skill/Step_Index.json` | Available UAT/Gherkin steps |
| `odpt-automation-skill/FIXODPMSG_Index.json` | FIX fields and enum values |
| `odpt-automation-skill/Error_Code_Index.json` | Error meanings by category |
| `pageExplore/qaGrid/qaGridApi_Index.json` | Grid methods and key patterns |
| `pageExplore/pages/INDEX.json` | Page routes and schemas |
| `odp-docs/INDEX.json` | Functional Specification selection/provenance |
| `Admin_GUI/flow_catalog/INDEX.json` | Reviewed semantic Admin flows |
| `repair_experience/INDEX.json` | Review-gated repair findings |

Testers normally do not rebuild indexes. Maintainers can run the builders and
their `--check` modes from the PageExplore source checkout; the qaGrid builder
has no `--check` flag, so compare its generated JSON/Markdown with the
committed files. The source `uat/odp_doc.md` snapshot is maintenance input and
is not part of the tester delivery bundle.

## 8. Repair Experience

Every explicit repair run that reaches a model attempt writes a redacted
candidate to:

```text
PageExplore/odpt-automation-skill/repair_experience/inbox/
```

Inbox records are quarantined review material. They contain structured
symptoms and hashes, not full Features, credentials, cookies, locators, or raw
transcripts. A human may generalize a finding into
`repair_experience/lessons/` only after independent review and a clean replay.
Only `status=verified` with `reuse.safe_to_reuse=true` is supplied as positive
guidance. Failed shapes do not belong in the positive Admin flow catalog.

## 9. Safety and Packaging

The conversion and repair commands reject `--auto` and
`--dangerously-skip-permissions`. Diagnosis and conversion receive a reduced
environment; do not allowlist ODP passwords, cookies, or business tokens.
`@REVIEW` is blocked by default. Reports, logs, and repair candidates are
created with private permissions.

The delivery archive has top-level directory `PageExplore/`. It excludes the
runtime `features/`, `resource/`, `uat/`, credentials, browser traces,
screenshots, run reports, caches, and repair inbox candidates. Install it
beside the runtime project, not over the runtime checkout.

Maintainer archive example:

```bash
tar \
  --exclude='uat_skill/.env' \
  --exclude='uat_skill/.git' \
  --exclude='uat_skill/UAT_SKILL使用手册.md' \
  --exclude='uat_skill/features' \
  --exclude='uat_skill/resource' \
  --exclude='uat_skill/ai' \
  --exclude='uat_skill/automation' \
  --exclude='uat_skill/uat' \
  --exclude='uat_skill/artifacts' \
  --exclude='uat_skill/screenshots' \
  --exclude='uat_skill/logs' \
  --exclude='uat_skill/bigmapVariable' \
  --exclude='uat_skill/outputs' \
  --exclude='uat_skill/temp' \
  --exclude='uat_skill/**/run_reports' \
  --exclude='uat_skill/**/feature_run_reports' \
  --exclude='uat_skill/odpt-automation-skill/repair_experience/inbox' \
  --exclude='uat_skill/**/__pycache__' \
  --exclude='uat_skill/**/*.pyc' \
  --transform='s,^uat_skill,PageExplore,' \
  -czf /path/PageExplore-YYYYMMDD.tar.gz \
  uat_skill
sha256sum /path/PageExplore-YYYYMMDD.tar.gz
```

Before handoff, run the Ruby syntax checks, the Skill validator, index checks,
and a checksum verification. A local smoke run only verifies wrapper/report
plumbing; a real Cucumber or ODP replay still requires the configured
ProjectA runtime and services.

## 10. Command Help

```bash
ruby PageExplore/tools/batch_transform_tc.rb --help
ruby PageExplore/tools/run_feature_debug.rb --help
python3 PageExplore/tools/admin_feature_converter.py --help
python3 PageExplore/tools/find_admin_flow.py --help
```

For detailed runner semantics, see
`PageExplore/odpt-automation-skill/Feature_Run_and_Debug.md`.
