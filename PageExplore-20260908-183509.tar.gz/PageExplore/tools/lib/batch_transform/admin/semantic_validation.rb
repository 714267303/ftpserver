# frozen_string_literal: true

# Admin manifest normalization, source coverage, and semantic validation.

module BatchTransform
  module Admin
    module SemanticValidation
      private

      def write_json_atomic(path, payload)
        destination = expanded_path(path)
        raise "refusing to overwrite symlink: #{destination}" if File.symlink?(destination)
        FileUtils.mkdir_p(File.dirname(destination))
        temporary = File.join(
          File.dirname(destination),
          ".#{File.basename(destination)}.tmp-#{Process.pid}-#{SecureRandom.hex(4)}"
        )
        begin
          File.write(temporary, JSON.pretty_generate(payload) + "\n", encoding: 'UTF-8')
          File.chmod(0o600, temporary)
          File.rename(temporary, destination)
        ensure
          File.delete(temporary) if File.exist?(temporary)
        end
        destination
      end

      def json_object_at(path, label)
        raise "#{label} does not exist: #{path}" unless File.file?(path) && !File.symlink?(path)

        value = JSON.parse(File.read(path, encoding: 'UTF-8'))
        raise "#{label} must contain a JSON object: #{path}" unless value.is_a?(Hash)

        value
      rescue JSON::ParserError => e
        raise "#{label} is not valid JSON (#{path}): #{e.message}"
      end

      # Apply only PageExplore facts that have one unique answer (for example an
      # exact route's profile/label or the sole menu that owns the following page
      # operation).  The Python contract checker writes the corrected candidate in
      # place and returns unresolved issues separately; those issues are rejected by
      # the strict semantic pass below rather than being guessed here.
      def normalize_admin_page_contract_file(candidate_path)
        command = [
          PYTHON_BIN,
          ADMIN_CONVERTER,
          '--flow', candidate_path,
          '--page-explore-root', PAGE_EXPLORE_ROOT,
          '--normalize-page-contract'
        ]
        stdout, stderr, status = Open3.capture3(
          opencode_environment,
          *command,
          chdir: Dir.pwd
        )
        payload_line = stdout.lines.reverse.find { |line| line.lstrip.start_with?('{') }
        payload = payload_line && JSON.parse(payload_line)
        unless payload.is_a?(Hash)
          detail = stderr.to_s.strip.empty? ? stdout.to_s.strip : stderr.to_s.strip
          detail = 'page-contract normalizer returned no JSON result' if detail.empty?
          raise compact_admin_transcript_error(detail, max_chars: 800)
        end
        # Exit 2 means deterministic repairs were applied but another semantic issue
        # (such as missing navigation) remains.  That is a valid normalization
        # result and is intentionally handled by admin_manifest_semantic_validation.
        unless status.success? || status.exitstatus == 2
          raise "page-contract normalizer failed with exit #{status.exitstatus}"
        end
        payload
      rescue JSON::ParserError => e
        raise "page-contract normalizer returned invalid JSON: #{e.message}"
      end

      def normalize_admin_flow_candidate_artifacts(candidate_path:, report_path:, case_id:, phase:)
        manifest = json_object_at(candidate_path, 'Admin flow candidate')
        report = json_object_at(report_path, 'Admin exploration report')
        source_hash = Digest::SHA256.file(candidate_path).hexdigest
        supplied_hash = report['manifest_sha256'].to_s.strip
        unless supplied_hash.empty? || supplied_hash == source_hash
          raise 'Admin exploration report manifest_sha256 does not match the candidate before runner normalization'
        end

        manifest, changes = normalize_admin_flow_candidate(manifest, case_id: case_id)
        # Persist structural compatibility fixes first so the independent page
        # contract process always reads the same candidate that this runner saw.
        write_json_atomic(candidate_path, manifest) unless changes.empty?

        page_contract = normalize_admin_page_contract_file(candidate_path)
        Array(page_contract['repairs']).each do |repair|
          next unless repair.is_a?(Hash)

          location = repair['path'] || if repair['section']
                                         "#{repair['section']}[#{repair['index']}]"
                                       end
          suffix = location.to_s.empty? ? '' : ":#{location}"
          changes << "page_contract.#{repair['code']}#{suffix}"
        end
        manifest = json_object_at(candidate_path, 'Page-contract-normalized Admin flow candidate')
        if report['admin_steps_validated'].to_i.positive? && manifest['steps'].is_a?(Array) &&
           report['admin_steps_validated'].to_i != manifest['steps'].length
          report['admin_steps_validated'] = manifest['steps'].length
          changes << 'aligned_report.admin_steps_validated'
        end
        return [manifest, report, changes] if changes.empty?

        write_json_atomic(candidate_path, manifest)
        result_hash = Digest::SHA256.file(candidate_path).hexdigest
        history = Array(report['runner_manifest_normalization']).select { |item| item.is_a?(Hash) }
        history << {
          'phase' => phase.to_s,
          'normalized_at' => Time.now.utc.iso8601,
          'source_sha256' => source_hash,
          'result_sha256' => result_hash,
          'changes' => changes
        }
        report['runner_manifest_normalization'] = history
        report['flow_id_inferred_by_runner'] = true if changes.include?('inferred_flow_id')
        report['manifest_sha256'] = result_hash
        write_json_atomic(report_path, report)
        [manifest, report, changes]
      end

      def record_admin_manifest_semantic_repair(report_path:, candidate_path:, source_hash:, outcome:, initial_reason:)
        report = json_object_at(report_path, 'Admin exploration report')
        result_hash = readable_artifact?(candidate_path) ? Digest::SHA256.file(candidate_path).hexdigest : nil
        repair_transcript = outcome[:transcript]
        repair = {
          'attempted' => true,
          'mode' => 'browser_free',
          'completed_at' => Time.now.utc.iso8601,
          'status' => outcome[:ok] ? 'completed' : 'failed',
          'source_sha256' => source_hash,
          'result_sha256' => result_hash,
          'initial_validation_error' => admin_semantic_validation_summary(initial_reason),
          'transcript_path' => repair_transcript && workspace_reference(repair_transcript)
        }.compact
        repair['failure_reason'] = compact_admin_transcript_error(outcome[:reason], max_chars: 600) unless outcome[:ok]
        report['semantic_repair'] = repair
        tools = Array(report['mcp_tools_used']).map(&:to_s)
        repair_tools = transcript_playwright_tool_names(repair_transcript)
        unless repair_tools.empty?
          report['semantic_repair']['status'] = 'failed'
          report['semantic_repair']['failure_reason'] =
            'browser-free semantic repair transcript unexpectedly contains Playwright tool use'
          outcome[:ok] = false
          outcome[:reason] = report['semantic_repair']['failure_reason']
        end
        report['mcp_tools_used'] = tools
        # The model cannot edit the report and does not calculate hashes. The runner
        # binds the repaired candidate to the existing, already-validated browser
        # evidence here before the second full validation pass.
        report['manifest_sha256'] = result_hash if result_hash
        write_json_atomic(report_path, report)
        report
      end

      def admin_manifest_validation_command(candidate_path)
        Shellwords.join([
          PYTHON_BIN,
          ADMIN_CONVERTER,
          '--flow', candidate_path,
          '--step-index', STEP_INDEX,
          '--page-explore-root', PAGE_EXPLORE_ROOT,
          '--validate-only',
          '--semantic-strict'
        ])
      end

      def admin_manifest_semantic_validation(candidate_path)
        stdout, stderr, status = Open3.capture3(
          opencode_environment,
          *Shellwords.split(admin_manifest_validation_command(candidate_path)),
          chdir: Dir.pwd
        )
        return { ok: true, summary: stdout.to_s.strip } if status.success?

        detail = stderr.to_s.strip.empty? ? stdout.to_s.strip : stderr.to_s.strip
        detail = 'strict Admin semantic validation failed without diagnostics' if detail.empty?
        { ok: false, reason: compact_admin_transcript_error(detail, max_chars: 1600) }
      rescue StandardError => e
        { ok: false, reason: "#{e.class}: #{e.message}" }
      end

      def admin_semantic_validation_summary(value)
        text = value.to_s
        indexed = text.scan(/\b(UNKNOWN_STEP|MISSING_TABLE):(\d+)/).map do |kind, index|
          "#{kind}[#{index}]"
        end
        flags = %w[
          MULTI_USER_LOGIN_REQUIRES_SEPARATE_BROWSER_SESSIONS
          SECRET_LITERAL_REDACTED
          STEP_INDEX_UNAVAILABLE
          SOURCE_REVIEW
          STANDALONE_MISSING_OPEN_BROWSER
          STANDALONE_MISSING_ADMIN_LOGIN
          STANDALONE_MISSING_ADMIN_OPERATION
          STANDALONE_MISSING_MAKER_MUTATION
          STANDALONE_MISSING_MAKER_SUBMISSION
          STANDALONE_MISSING_CHECKER_SESSION
          STANDALONE_APPROVAL_PRECEDES_MAKER_ACTION
          YAML_UPDATE_MISSING_SEARCH
          YAML_UPDATE_MISSING_DETAIL_OPEN
          YAML_EFFECTIVE_DATE_MISSING
          YAML_POSTCONDITION_MISSING
          YAML_PAGE_PROFILE_AMBIGUOUS
          YAML_PAGE_PROFILE_MISMATCH
          SOURCE_COVERAGE
        ].select { |flag| text.include?(flag) }
        page_contract = text.scan(/PAGE_CONTRACT:([A-Z0-9_]+)/).flatten.map do |code|
          "PAGE_CONTRACT[#{code}]"
        end
        issues = (indexed + flags + page_contract).uniq
        return 'strict Step_Index semantic validation failed; inspect all candidate steps and tables' if issues.empty?

        "strict Step_Index semantic validation failed: #{issues.join(', ')}"
      end

      def admin_semantic_evidence_gap(value, report: nil, transcript_path: nil,
                                      approval_requested: false, require_transcript_mcp: false)
        text = value.to_s
        blockers = %w[
          STANDALONE_MISSING_OPEN_BROWSER
          STANDALONE_MISSING_ADMIN_LOGIN
          STANDALONE_MISSING_ADMIN_OPERATION
          STANDALONE_MISSING_MAKER_MUTATION
          STANDALONE_MISSING_MAKER_SUBMISSION
          STANDALONE_APPROVAL_PRECEDES_MAKER_ACTION
          YAML_UPDATE_MISSING_SEARCH
          YAML_UPDATE_MISSING_DETAIL_OPEN
          YAML_EFFECTIVE_DATE_MISSING
          YAML_POSTCONDITION_MISSING
        ].select { |flag| text.include?(flag) }
        if text.include?('STANDALONE_MISSING_CHECKER_SESSION') &&
           !checker_session_semantic_repair_supported?(
             report: report,
             transcript_path: transcript_path,
             approval_requested: approval_requested,
             require_transcript_mcp: require_transcript_mcp
           )
          blockers << 'STANDALONE_MISSING_CHECKER_SESSION'
        end
        blockers.concat(text.scan(/PAGE_CONTRACT:([A-Z0-9_]+)/).flatten.map { |code| "PAGE_CONTRACT[#{code}]" })
        blockers.uniq
      end

      def yaml_test_step_blocks(yaml_path)
        lines = File.readlines(yaml_path, encoding: 'UTF-8')
        in_steps = false
        blocks = []
        current = []
        lines.each do |line|
          unless in_steps
            in_steps = true if line.match?(/^\s*TestSteps:\s*$/)
            next
          end
          # Generated YAML uses both an indentless sequence and the conventional
          # two-space form. Split only on known TestSteps entry fields so a nested
          # list inside a block scalar cannot become a false source step.
          if line.match?(/^\s*-\s+(?:Key|Name|Step|Test Script \(Step-by-Step\) - Step):/i)
            blocks << current.join unless current.empty?
            current = [line]
          else
            current << line unless current.empty?
          end
        end
        blocks << current.join unless current.empty?
        blocks.each_with_index.map { |block, index| { index: index + 1, text: block } }
      rescue StandardError
        []
      end

      def yaml_admin_step_blocks(yaml_path)
        yaml_test_step_blocks(yaml_path).select do |item|
          block = item[:text]
          block.match?(/^\s*(?:-\s*)?(?:Execution Channel|execution_channel):\s*(?:"admin_gui"|'admin_gui'|admin_gui)\s*(?:#.*)?$/i)
        end
      end

      def yaml_admin_step_text(yaml_path)
        yaml_admin_step_blocks(yaml_path).map { |item| item[:text] }.join("\n")
      rescue StandardError
        ''
      end

      def admin_source_coverage_issues(manifest, yaml_path)
        admin_blocks = yaml_admin_step_blocks(yaml_path)
        return [] if admin_blocks.empty?

        coverage = manifest['source_coverage']
        return ['SOURCE_COVERAGE_MISSING'] unless coverage.is_a?(Array) && !coverage.empty?

        expected_yaml_indices = admin_blocks.map { |item| item[:index] }
        actual_yaml_indices = []
        covered_flow_indices = []
        issues = []
        step_count = Array(manifest['steps']).length
        flow_steps = Array(manifest['steps'])
        source_by_index = admin_blocks.to_h { |item| [item[:index], item[:text]] }
        coverage.each_with_index do |entry, index|
          unless entry.is_a?(Hash)
            issues << "SOURCE_COVERAGE_INVALID_ENTRY[#{index}]"
            next
          end
          yaml_index = entry['yaml_step_index']
          flow_indices = entry['flow_step_indices']
          unless yaml_index.is_a?(Integer) && yaml_index.positive?
            issues << "SOURCE_COVERAGE_INVALID_YAML_INDEX[#{index}]"
            next
          end
          actual_yaml_indices << yaml_index
          unless flow_indices.is_a?(Array) && !flow_indices.empty? &&
                 flow_indices.all? { |value| value.is_a?(Integer) && value.positive? && value <= step_count }
            issues << "SOURCE_COVERAGE_INVALID_FLOW_INDICES[#{yaml_index}]"
            next
          end
          covered_flow_indices.concat(flow_indices)
          source_text = source_by_index[yaml_index]
          next unless source_text

          mapped_categories = flow_indices.flat_map do |flow_index|
            admin_flow_step_categories(flow_steps[flow_index - 1])
          end.uniq
          missing_intents = required_admin_intents(source_text) - mapped_categories
          missing_intents.each do |intent|
            issues << "SOURCE_COVERAGE_INTENT_MISSING[yaml:#{yaml_index}:#{intent}]"
          end
        end
        missing_yaml = expected_yaml_indices - actual_yaml_indices
        extra_yaml = actual_yaml_indices - expected_yaml_indices
        duplicate_yaml = actual_yaml_indices.tally.select { |_key, count| count > 1 }.keys
        missing_flow = (1..step_count).to_a - covered_flow_indices
        issues << "SOURCE_COVERAGE_MISSING_YAML_STEPS[#{missing_yaml.join(',')}]" unless missing_yaml.empty?
        issues << "SOURCE_COVERAGE_NON_ADMIN_YAML_STEPS[#{extra_yaml.join(',')}]" unless extra_yaml.empty?
        issues << "SOURCE_COVERAGE_DUPLICATE_YAML_STEPS[#{duplicate_yaml.join(',')}]" unless duplicate_yaml.empty?
        issues << "SOURCE_COVERAGE_UNMAPPED_FLOW_STEPS[#{missing_flow.join(',')}]" unless missing_flow.empty?
        issues
      end

      def admin_flow_step_categories(step)
        text = admin_semantic_step_text(step)
        categories = []
        categories << 'navigation' if text.match?(/\ASelect Trading Admin Left Menu /i)
        categories << 'search' if text.match?(/\ASearch in Trading Admin /i)
        categories << 'open_detail' if text.match?(/\ADouble click table |\AGo to Edit reference /i)
        categories << 'mutate' if text.match?(/\A(?:Set Trading Admin |Add Table Item in |Modify (?:Auto-sort )?Table|Modify Table in Admin GUI |Admin GUI |Create .* if not exists|update ")/i) ||
                                   text.match?(/\AClick button "(?:New Record|Clone Record|Delete|Activate|Deactivate|Suspend|Unsuspend)"/i)
        categories << 'effective_date' if text.match?(/\ASelect effective type /i)
        categories << 'submit' if text.match?(/\A(?:Save Trading Admin |Click button "(?:Save|Submit|Confirm|OK)" in Trading Admin|Create .* if not exists|update ")/i)
        categories << 'deferred_approval' if final_approval_semantic_step?(step)
        categories << 'verify' if text.match?(/\A(?:Check table |Check Trading Admin |Check field |Check text input )/i)
        categories
      end

      def required_admin_intents(source_text)
        # Case metadata commonly says Status: Approved and names a Checker even when
        # the business step has no countersign. Ignore those metadata scalars before
        # deriving action intent, just as yaml_requests_final_approval? does.
        metadata = /^\s*(?:-\s*)?(?:Checker(?:\s+2)?|Status):/i
        text = source_text.to_s.each_line.reject { |line| line.match?(metadata) }.join
        intents = []
        update = text.match?(/\b(?:change|update|modify|edit|delete|deactivate|activate|suspend|unsuspend)\b/i)
        create = text.match?(/\b(?:create|add)\s+(?:a\s+)?new\b|\bnew\s+record\b/i)
        if update
          intents.concat(%w[navigation search open_detail mutate submit])
        elsif create
          intents.concat(%w[navigation mutate submit])
        elsif text.match?(/\b(?:search|find|look\s*up|filter)\b/i)
          intents.concat(%w[navigation search])
        end
        intents << 'effective_date' if text.match?(/\btomorrow\b|\bnext\s+(?:business|trading)\s+day\b/i)
        intents << 'deferred_approval' if text.match?(ADMIN_APPROVAL_REQUEST_PATTERN)
        intents << 'verify' if text.match?(/\b(?:verify|check|ensure)\b/i)
        intents.uniq
      end

      def yaml_admin_page_profiles(yaml_path)
        yaml_admin_step_blocks(yaml_path).flat_map do |item|
          item[:text].scan(
            /^\s*(?:-\s*)?PageExplore Profile:\s*(?:"([^"]+)"|'([^']+)'|(\S+))\s*(?:#.*)?$/i
          ).map { |captures| captures.compact.first.to_s.strip }
        end.reject(&:empty?).uniq
      rescue StandardError
        []
      end

      def admin_yaml_page_profile_issues(manifest, yaml_path)
        profiles = yaml_admin_page_profiles(yaml_path)
        return [] if profiles.empty?
        return ['YAML_PAGE_PROFILE_AMBIGUOUS'] if profiles.length > 1

        page = manifest['page'].is_a?(Hash) ? manifest['page'] : {}
        actual = page['profile'].to_s.strip
        expected = profiles.first
        return [] if !actual.empty? && File.basename(actual).casecmp?(File.basename(expected))

        ['YAML_PAGE_PROFILE_MISMATCH']
      end

      def admin_yaml_intent_requirements(yaml_path)
        text = yaml_admin_step_text(yaml_path)
        return {} if text.empty?

        update_existing = text.match?(/\b(?:change|update|modify|edit)\b/i) &&
                          !text.match?(/\b(?:create|add)\s+(?:a\s+)?new\b|\bnew\s+record\b/i)
        {
          update_existing: update_existing,
          effective_date: text.match?(/\btomorrow\b|\bnext\s+(?:business|trading)\s+day\b/i),
          postcondition: text.match?(/verify\s+from\s+Admin\s+GUI|verify.{0,120}\b(?:shows?|display(?:s|ed)?|remains?)\b|check.{0,80}\bAdmin\s+GUI\b/im)
        }
      end

      def admin_standalone_flow_issues(manifest, approval_requested:, maker_submission:, yaml_path: nil)
        all_steps = Array(manifest['background']) + Array(manifest['steps'])
        texts = all_steps.map { |step| admin_semantic_step_text(step) }.reject(&:empty?)
        issues = []
        issues.concat(admin_source_coverage_issues(manifest, yaml_path)) if yaml_path
        issues.concat(admin_yaml_page_profile_issues(manifest, yaml_path)) if yaml_path

        issues << 'STANDALONE_MISSING_OPEN_BROWSER' unless texts.any? { |text| text.casecmp?('Open browser') }
        login_positions = texts.each_index.select { |index| texts[index].casecmp?('Login Trading Admin with:') }
        issues << 'STANDALONE_MISSING_ADMIN_LOGIN' if login_positions.empty?

        session_or_plumbing = /\A(?:Open browser|Login Trading Admin with:|Clear Alert If Exist|Save current browser to |Switch browser to |Close the browser|Load value from |Load object description from |Screenshot|Wait )/i
        meaningful_positions = texts.each_index.reject do |index|
          text = texts[index]
          text.match?(session_or_plumbing) || final_approval_semantic_step?(all_steps[index])
        end
        issues << 'STANDALONE_MISSING_ADMIN_OPERATION' if meaningful_positions.empty?

        if maker_submission
          mutation_pattern = /\A(?:Set Trading Admin |Select effective type |Add Table Item in |Modify (?:Auto-sort )?Table|Modify Table in Admin GUI |Admin GUI |Create .* if not exists|update ")/i
          submission_pattern = /\A(?:Save Trading Admin |Click button "(?:Save|Submit|Confirm|OK)" in Trading Admin|Create .* if not exists|update ")/i
          mutation_positions = texts.each_index.select { |index| texts[index].match?(mutation_pattern) }
          submission_positions = texts.each_index.select { |index| texts[index].match?(submission_pattern) }
          issues << 'STANDALONE_MISSING_MAKER_MUTATION' if mutation_positions.empty?
          issues << 'STANDALONE_MISSING_MAKER_SUBMISSION' if submission_positions.empty?

          if approval_requested
            saved_browser_count = texts.count { |text| text.match?(/\ASave current browser to /i) }
            if login_positions.length < 2 || saved_browser_count < 2
              issues << 'STANDALONE_MISSING_CHECKER_SESSION'
            end
            approval_position = all_steps.index { |step| final_approval_semantic_step?(step) }
            last_maker_position = (mutation_positions + submission_positions).max
            if approval_position && last_maker_position && approval_position < last_maker_position
              issues << 'STANDALONE_APPROVAL_PRECEDES_MAKER_ACTION'
            end
          end
        end

        requirements = yaml_path ? admin_yaml_intent_requirements(yaml_path) : {}
        if requirements[:update_existing]
          search_positions = texts.each_index.select { |index| texts[index].match?(/\ASearch in Trading Admin /i) }
          detail_positions = texts.each_index.select do |index|
            texts[index].match?(/\ADouble click table /i) ||
              texts[index].match?(/\AGo to Edit reference /i) ||
              texts[index].match?(/\Aupdate "/i)
          end
          issues << 'YAML_UPDATE_MISSING_SEARCH' if search_positions.empty?
          issues << 'YAML_UPDATE_MISSING_DETAIL_OPEN' if detail_positions.empty?
        end
        if requirements[:effective_date]
          effective = texts.any? do |text|
            text.match?(/\ASelect effective type .*\btomorrow\b/i) ||
              text.match?(/\Aupdate ".*\btomorrow\b/i)
          end
          issues << 'YAML_EFFECTIVE_DATE_MISSING' unless effective
        end
        if requirements[:postcondition]
          check_positions = texts.each_index.select do |index|
            texts[index].match?(/\A(?:Check table |Check Trading Admin |Check field |Check text input )/i)
          end
          final_action_position = all_steps.index { |step| final_approval_semantic_step?(step) }
          final_action_position ||= texts.each_index.select do |index|
            texts[index].match?(/\A(?:Save Trading Admin |Click button "(?:Save|Submit|Confirm|OK)" in Trading Admin)/i)
          end.max
          postcondition_present = check_positions.any? do |position|
            final_action_position.nil? || position > final_action_position
          end
          issues << 'YAML_POSTCONDITION_MISSING' unless postcondition_present
        end

        issues.uniq
      end

      # A catalog entry promoted by an older combined Admin+Binary pipeline may be
      # marked reusable even though it contains only the deferred Approve operation.
      # Re-check the complete standalone contract against the current YAML before it
      # can bypass MCP exploration.  This is read-only: an obsolete catalog entry is
      # ignored, not silently rewritten or demoted.
      def reusable_admin_flow_case_issues(path, yaml_path)
        manifest = json_object_at(path, 'reviewed Admin flow')
        approval_requested = yaml_requests_final_approval?(yaml_path)
        maker_submission = approval_requested ||
                           manifest.dig('exploration', 'maker_submission_executed') == true
        issues = admin_standalone_flow_issues(
          manifest,
          approval_requested: approval_requested,
          maker_submission: maker_submission,
          yaml_path: yaml_path
        )
        approval_steps = Array(manifest['steps']).select { |step| final_approval_semantic_step?(step) }
        if approval_requested && approval_steps.empty?
          issues << 'STANDALONE_MISSING_DEFERRED_APPROVAL'
        end
        approval_steps.each do |step|
          unless step.is_a?(Hash) && step['mcp_execution'].to_s == 'deferred_to_feature'
            issues << 'STANDALONE_APPROVAL_NOT_DEFERRED_TO_FEATURE'
          end
        end
        cleanup_steps = (Array(manifest['background']) + Array(manifest['steps'])).select do |step|
          rollback_cleanup_semantic_step?(step)
        end
        issues << 'STANDALONE_CONTAINS_MCP_CLEANUP' unless cleanup_steps.empty?
        semantic = admin_manifest_semantic_validation(path)
        unless semantic[:ok]
          issues << "ADMIN_FLOW_SEMANTIC_PREFLIGHT:#{admin_semantic_validation_summary(semantic[:reason])}"
        end
        issues.uniq
      rescue StandardError => e
        ["STANDALONE_FLOW_READ_ERROR:#{e.class}"]
      end

      def admin_manifest_repair_prompt(yaml_path:, candidate_path:, report_path:, case_id:, channel:, evidence_dir:,
                                       validation_reason:)
        schema_path = File.join(AUTO_SKILL, 'Admin_GUI', 'flow_catalog', 'schema.json')
        <<~TEXT
          Repair only the semantic Admin flow JSON for case '#{case_id}'. Browser
          exploration and rollback already completed; do not use Playwright, shell,
          bash, Python, another executable, network access, `.env`, credentials, or
          any browser/backend tool. This repair must not repeat or simulate MCP and
          must not perform any business action.

          Read these sources:
            1. YAML test case '#{yaml_path}'
            2. candidate '#{candidate_path}'
            3. exact schema '#{schema_path}'
            4. Step Index '#{STEP_INDEX}'
            5. relevant Admin rules under '#{File.join(AUTO_SKILL, 'Admin_GUI')}'
            6. PageExplore sitemap '#{File.join(PAGE_EXPLORE_ROOT, 'sitemap.md')}'
            7. the candidate page profile under '#{File.join(PAGE_EXPLORE_ROOT, 'pages')}'
            8. compact human-authored Feature flow index
               '#{File.join(AUTO_SKILL, 'Admin_GUI', 'Feature_Flow_Index.md')}', when
               present, as read-only corroborating examples only
            9. only when that index names a directly relevant example, a small,
               bounded line range from
               '#{File.join(SCRIPT_ROOT, 'uat', 'uat_admin_feature.txt')}'

          Never read the complete human-authored Feature corpus. Use its compact
          index first and inspect only the smallest directly relevant excerpt.

          The deterministic validator reported:
            #{admin_semantic_validation_summary(validation_reason)}

          Edit only '#{candidate_path}' within '#{evidence_dir}'. Do not edit the
          exploration report; the runner records repair provenance and hashes after
          validating your candidate. Preserve case_id '#{case_id}', channel '#{channel}', the
          validated page identity, evidence, audit metadata, and the report's browser
          and cleanup facts. Do not change a passed cleanup result into a different
          claim. Do not add MCP Reject/Cancel cleanup to manifest steps.

          Make the candidate conform exactly to the schema. It must contain
          schema_version, flow_id, case_id, name, channel, evidence_status, page
          (label/route/profile), non-empty steps, evidence, and reuse with keywords
          and safe_to_reuse=false. Every step object must use `text`. Replace browser
          summaries or invented prose with exact executable Admin/shared operations
          proven by Step_Index. Include each required DataTable with documented
          headers and dataset placeholders. Never put secret values or live browser
          values into the manifest. A required final `Approve if updated with :`
          operation must include its full documented DataTable and
          `mcp_execution="deferred_to_feature"`; ordinary steps omit mcp_execution.
          Every Admin login must be a complete independent Feature session:
          `Open browser`, one-user `Login Trading Admin with:` DataTable,
          `Clear Alert If Exist`, then `Save current browser to ...`. For a
          maker/checker flow, place a checker session before the deferred approval
          and make its saved-browser alias match the approval table's `Approver
          Browser`. Derive dataset placeholders from the maintained conventions;
          never copy login values from browser evidence or a dotenv file.
          Reject/Cancel remains evidence-only and must not appear in semantic steps.
          The menu/page chain is a deterministic contract, not a wording choice:
          every `Select Trading Admin Left Menu` value must be the exact parent/child
          path owning `page.route` in sitemap.md, and every following Search/table/
          detail operation must name that selected page until another menu step is
          executed. Use profile columns/detail fields for DataTable headers. Existing
          Features can confirm established sequencing, but they cannot override the
          sitemap, page profile, or Step_Index and must never be copied wholesale.
          Add or repair `source_coverage`: exactly one entry for every 1-based YAML
          TestSteps item with Execution Channel admin_gui, with non-empty 1-based
          `flow_step_indices`; collectively the entries must cover every manifest
          step. The optional `intent` list documents why the mapped steps implement
          that source entry. Coverage metadata never substitutes for an actual step.
          Preserve every original `step_index` and `operation` as audit metadata on
          the first exact UAT step that represents that source action; expand one
          browser summary into multiple exact steps when needed. Never drop a source
          action merely to make strict validation pass.
          Do not invent an operation when no Step_Index mapping can be proven; leave
          the candidate explicit so the runner fails safely.

          Do not calculate a hash and do not modify the report. Read the edited
          candidate back and self-check it against the schema and Step_Index before
          stopping.
        TEXT
      end

      def admin_manifest_repair_environment(yaml_path:, candidate_path:, report_path:, evidence_dir:)
        environment = conversion_permission_environment(
          read_roots: [File.dirname(yaml_path), File.dirname(candidate_path), AUTO_SKILL,
                       STEP_INDEX, PAGE_EXPLORE_ROOT, SCRIPT_ROOT],
          edit_roots: [candidate_path]
        )
        config = JSON.parse(environment.fetch('OPENCODE_CONFIG_CONTENT'))
        permission = config.fetch('permission')
        # Be explicit even though the base environment already denies executables.
        # Semantic repair has no reason to see browser tools or runtime secrets.
        permission['read']['*.env'] = 'deny'
        permission['read']['*.env.*'] = 'deny'
        permission['playwright_*'] = 'deny'
        permission['mcp.playwright.*'] = 'deny'
        permission['mcp'] = 'deny'
        environment['OPENCODE_CONFIG_CONTENT'] = JSON.generate(config)
        environment
      rescue JSON::ParserError => e
        raise "cannot construct OpenCode semantic-repair permissions: #{e.message}"
      end

      def repair_admin_manifest_semantics(yaml_path:, candidate_path:, report_path:, case_id:, channel:, evidence_dir:,
                                          validation_reason:)
        source_manifest = json_object_at(candidate_path, 'Admin flow candidate before semantic repair')
        prompt = admin_manifest_repair_prompt(
          yaml_path: yaml_path,
          candidate_path: candidate_path,
          report_path: report_path,
          case_id: case_id,
          channel: channel,
          evidence_dir: evidence_dir,
          validation_reason: validation_reason
        )
        transcript_path = File.join(evidence_dir, 'manifest-repair-events.jsonl')
        result = run_opencode(
          "Step 1/7: Browser-free Admin manifest repair: #{case_id}",
          build_admin_manifest_repair_command(prompt),
          retry_on_hang: false,
          environment: admin_manifest_repair_environment(
            yaml_path: yaml_path,
            candidate_path: candidate_path,
            report_path: report_path,
            evidence_dir: evidence_dir
          ),
          timeout_seconds: [ADMIN_EXPLORE_TIMEOUT, 300].min,
          capture_path: transcript_path,
          model_prompt: prompt
        )
        ok = result[:exit_code].to_i.zero?
        reason = ok ? nil : "semantic repair command failed (exit #{result[:exit_code]})"
        if ok
          begin
            repaired_manifest = json_object_at(candidate_path, 'Admin flow candidate after semantic repair')
            source_steps = Array(source_manifest['steps'])
            repaired_steps = Array(repaired_manifest['steps'])
            source_indices = source_steps.filter_map do |step|
              step['step_index'] if step.is_a?(Hash) && !step['step_index'].nil?
            end.map(&:to_s).uniq
            repaired_indices = repaired_steps.filter_map do |step|
              step['step_index'] if step.is_a?(Hash) && !step['step_index'].nil?
            end.map(&:to_s).uniq
            missing_indices = source_indices - repaired_indices
            if !missing_indices.empty?
              ok = false
              reason = "semantic repair dropped source step_index value(s): #{missing_indices.join(', ')}"
            elsif source_indices.empty? && repaired_steps.length < source_steps.length
              ok = false
              reason = "semantic repair reduced candidate steps from #{source_steps.length} to #{repaired_steps.length}"
            end
          rescue StandardError => e
            ok = false
            reason = "semantic repair candidate could not be verified: #{e.class}: #{e.message}"
          end
        end
        {
          ok: ok,
          result: result,
          transcript: transcript_path,
          reason: reason
        }
      rescue StandardError => e
        { ok: false, reason: "semantic repair failed: #{e.class}: #{e.message}" }
      end
    end
  end
end
