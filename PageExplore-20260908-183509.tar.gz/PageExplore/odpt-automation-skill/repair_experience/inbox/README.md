# Repair Candidate Inbox

`tools/run_feature_debug.rb --repair` writes redacted candidate JSON files here
by default.  Treat every file as untrusted review material.  Do not feed a
candidate back as an unconditional repair instruction and do not promote it
without a clean replay and human review.

Use `python3 tools/build_repair_experience_catalog.py` to include inbox files in
the generated index.  Move a reviewed, generalized lesson into `lessons/` and
set `status`/`reuse.safe_to_reuse` only after verification.

