---
name: odpt-automation-skill
description: Convert ODP test-case YAML into Ruby/Cucumber Features and maintain, execute, diagnose, or repair existing ODP-T Features across Binary/FIX, Admin GUI, Trading GUI, Clearing, and Hybrid flows. Use PageExplore through PAGEEXPLORE_ROOT for page and qaGrid knowledge.
---

# ODP-T Project Maintenance Skill

## Purpose
This skill provides a structured framework for AI agents and developers to maintain, extend, and troubleshoot the ODP-T (Order Drop Processing - Trading) automation testing project. It documents all workflows, conversion rules, project structure, and best practices discovered during the project lifecycle.

## Execution Rules

- Follow the stages in this skill in the listed order.
- Complete one reasoning/verification stage at a time and record its output
  before advancing. Per-case batch execution may still be sequentially
  orchestrated by `tools/batch_transform_tc.rb`.
- Do not silently skip a stage. If a stage is not applicable, record `N/A`
  and the reason in the conversion report.
- Use the registered deterministic tools (`tools/build_step_index.py`,
  `tools/build_grid_api_index.py`, `tools/build_pages_index.py`,
  `tools/build_fix_message_index.py`, `tools/build_error_code_index.py`, and
  `tools/admin_feature_converter.py`) for repeatable mechanical work. Use
  `tools/run_feature_debug.rb` for execution/diagnosis, or its explicit
  `--repair` mode for an audited single-Feature repair. Normal execution and
  diagnosis do not modify a Feature. Do not invent an ad-hoc bulk script or emit raw browser JavaScript
  as a Feature step.
- If the task involves multiple records, preserve source order and keep each
  case's evidence/report separate.
- Before moving to the next stage, verify the current stage's required checks.
- Print `## Step N` when each stage finishes in an agent/tool log.
- Before completing the task, check that every source step is represented and
  that no `@REVIEW` reason remains unexplained.

## When to Use This Skill
Use this skill whenever you are asked to:
   - Create new test case feature files from YAML test case specifications
- Modify existing feature files (Binary, Admin GUI, Trading GUI, Clearing)
- Convert a Playwright MCP Admin exploration into a reviewed Admin or Hybrid Feature
- Add new test cases to the automation framework
- Update dataset configurations (`dataSet-*.csv` files)
- Troubleshoot failing test scenarios
- Run a generated or manually edited Feature and diagnose a failure with the
  indexed FIX/error/Grid context
- Refactor feature files or step definitions
- Document transform rules or project knowledge
- Plan test execution via automation plans (`automation/plan/*.csv`)
- Update skill documentation after any project changes

## Project Background
The ODP-T project is an automated testing framework for HKEX ODP (Order Drop Processing) trading system. It uses:
- **Cucumber** (Gherkin) for test case definitions (`.feature` files)
- **Ruby** for custom step definitions (`features/customized_steps/`)
- **FIX protocol** for binary interface message exchange
- **Selenium WebDriver** for GUI testing (Admin GUI, Trading GUI)
- **WABI framework** for test execution and reporting

## Transform Rule Files

| Domain | Rule File(s) |
|---|---|
| Common/Shared Rules | `conversion-rules.md` |
| Master Index | `INDEX.md` |
| Admin GUI | `Admin_GUI/index.md` |
| Binary Interface | `Binary_Interface/INDEX.md` |
| FIX dictionary enums | `FIXODPMSG_Index.md` and `.json` |
| Reject/status reason catalog | `Error_Code_Index.md` and `.json` |
| Trading GUI | `Trading_GUI/index.md` |
| Clearing Interface | `Clearing_Interface_Transform_Rules.md` |
| Admin conversion boundary | `Admin_GUI/Feature_Converter.md` |
| Reusable Admin flows | `Admin_GUI/flow_catalog/INDEX.md` |
| Repair experience | `repair_experience/INDEX.md` |
| PageExplore knowledge | `${PAGEEXPLORE_ROOT}/README.md`, then its page/Grid indexes |
| ODP business specifications | `../odp-docs/INDEX.md` then the relevant restored FS document |
| Admin page profiles | `${PAGEEXPLORE_ROOT}/pages/INDEX.md` then the selected profile |
| Feature execution/diagnosis | `Feature_Run_and_Debug.md` and `tools/run_feature_debug.rb` |

## Runtime and Evidence Authorities

The project has three different kinds of knowledge and they must not be
conflated:

| Kind | Authority | Use |
|---|---|---|
| Executable step | Ruby step sources in the target UAT checkout and the installed `wabi-web` gem at `/usr/local/share/gems/gems/wabi-web-*/` | Final syntax and runtime behavior |
| Snapshot/index | `uat/uat_step.txt`, `Step_Index.json`, and indexes under `${PAGEEXPLORE_ROOT}/` | Candidate lookup and routing; refresh when sources change |
| Exploration evidence | Playwright MCP trace, screenshots, network summary, and `${PAGEEXPLORE_ROOT}/evidence/` | Prove what was observed; never directly executable |

Resolve `PAGEEXPLORE_ROOT` from the environment. If it is unset in the
portable bundle, use the sibling `../pageExplore/` directory. PageExplore is
an independent knowledge source, not a subdirectory of this Skill.

Resolve the ODP business-document index from `ODP_DOC_INDEX` when supplied;
otherwise use the sibling `../odp-docs/INDEX.json`. Select the relevant
Functional Specification before converting or repairing a case whose behavior
depends on an ODP business rule. Use that document for intent and expected
behavior only; the target runtime's installed step definitions and the
`Step_Index` remain authoritative for executable Gherkin syntax.

For Binary debugging, resolve wire enum values through `FIXODPMSG_Index` and
reject/status text through `Error_Code_Index`. Keep the category in every
lookup (`CATEGORY_ID:CODE`); a numeric code is not globally unique.

The `Step_Index` is recommended, but it is not a second step implementation.
A missing or stale external gem is a visible verification warning, not a
reason to guess a step signature.

## Executable Step Priority

Choose executable wording in this order:

1. Current project `features/customized_steps/**/*.rb`.
2. `Step_Index.json` generated from the same runtime/customized steps.
3. Existing verified Feature examples and verified Admin flow manifests.
4. Skill rules, ODP documents, and PageExplore profiles as guidance only.
5. Emit `@REVIEW` when no executable step can be proven.

Do not replace a missing project step with a Playwright locator, browser
JavaScript, dynamic UUID, `qaGridApi` mutation call, or invented Gherkin.

## Channel Selection

Classify the YAML case before loading detailed rules:

| Channel | Signal | Compiler path |
|---|---|---|
| `binary` | FIX/Binary send or expect only | Existing Binary rules and transformer |
| `admin` | Admin GUI setup/assertions only | Playwright evidence -> reviewed manifest -> `admin_feature_converter.py` |
| `hybrid` | Admin setup is required before Binary/Proxy traffic | Generate/validate a standalone Admin Feature first, then generate the non-Admin continuation separately |

`tools/batch_transform_tc.rb` reads each YAML `Execution Channel`. If an
`admin_gui` step is present, the batch must resolve a matching reviewed Admin
manifest before YAML-to-Feature conversion. It must stop instead of silently
routing that case through the Binary/generic model path. The bundled
`Admin_GUI/flow_catalog/flows/` directory is searched by default; only
`verified` and `safe_to_reuse` entries are selected automatically.

For a generation repair invoked with `--repair-generated`, the batch owns the
full Admin/Hybrid lifecycle in the required `2 -> 3 -> 1 -> 4 -> 5 -> 6 -> 7`
order: Excel to YAML, channel classification, reuse or rollback-validation
Playwright MCP execution of the Admin setup, cleanup, standalone Admin Feature
generation, exact semantic comparison, conditional Admin repair/retest, and
flow validation/promotion. Only afterward is a Hybrid non-Admin continuation
generated and tested as a separate Feature. A missing flow
is explored automatically in this mode. `--admin-explore` opts another
generation mode into exploration; `--no-admin-explore` requires an existing
reusable flow. Browser exploration is headed by default and needs `DISPLAY`;
`--playwright-mcp-headless` is the explicit no-display mode. MCP submits a
maker request and Rejects it through the checker as cleanup (or Cancels before
save when no countersign exists), but never executes Approve. Required approval
is mapped from Step_Index and deferred to the generated Feature.

For Admin or Hybrid, load [`Admin_GUI/index.md`](Admin_GUI/index.md),
the PageExplore [`Grid_API_Core_Index.md`](../pageExplore/qaGrid/Grid_API_Core_Index.md),
[`Step_Index.md`](Step_Index.md), the relevant page profile, and
[`Admin_GUI/Feature_Converter.md`](Admin_GUI/Feature_Converter.md)
before choosing function rules. For Binary-only cases, retain the existing
lazy Binary rule path.

## Standard Workflow

### A. New Feature File Creation (YAML → Feature)

1. **Read source test case**
   - Load the YAML test case file from the `ai/TC/<Folder>/` directory.
   - Read the source YAML file carefully, including precondition, objective, step descriptions, test data, and expected results.
   - Preserve the original YAML step order within the `TestSteps` list.

2. **Analyze the test case and summarize required steps**
   - Identify the overall test domain, business flow, and scenario purpose.
   - Count all test steps in the YAML `TestSteps` list.
   - For each YAML step, identify the business action, expected feature step, rule category, FS mapping need, and dataset update need.

3. **Identify required rule categories**
   - Do not blindly load all transformation rules.
   - Determine required Admin GUI, Trading GUI, Binary, Clearing, dataset, Day1/Day2, and multi-case rules from the test case.
   - Classify the case as `binary`, `admin`, or `hybrid` before selecting the
     detailed rules. A case that configures Admin state and then sends Binary
     traffic is `hybrid`, not two unrelated conversions.

4. **Locate and load corresponding skill rules**
   - Start from `conversion-rules.md`, then load only relevant detailed rule files.
   - Search the skill folder if a required rule cannot be found directly.
   - For `admin`/`hybrid`, load `Admin_GUI/index.md`, `Step_Index.md`,
     `Admin_GUI/Feature_Converter.md`, and the relevant contract/profile under
     `${PAGEEXPLORE_ROOT}/` before writing steps.

5. **Read Functional Specification**
   - Use `../odp-docs/INDEX.md` (or `ODP_DOC_INDEX`) to locate the relevant
     restored Functional Specification. Load only the needed document sections.
     A project-specific `ai/FS/` copy may supplement it when explicitly
     supplied, but does not replace the indexed ODP source without provenance.
   - Confirm field names, values, message structures, mandatory fields, optional fields, and business validation logic.

6. **Read reference feature files**
   - Examine similar existing feature files and align structure, wording, tags, datasets, and naming conventions.

6b. **Validate Admin setup and normalize the evidence (Admin/Hybrid only)**
   - Search `Admin_GUI/flow_catalog/INDEX.md` by route/keyword first. A
     verified reusable flow can be parameterized for the case; an observed or
     inferred flow is only an exploration reference and must be replayed.
   - Before navigating with Playwright MCP, confirm the OpenCode local MCP
     command includes `--ignore-https-errors` (the maintained installer uses
     this by default) or its equivalent
     `PLAYWRIGHT_MCP_IGNORE_HTTPS_ERRORS=1` when the internal ODP endpoint
     uses an untrusted certificate. Set the switch to `0` only when browser
     certificate verification is required. This is browser-only configuration;
     do not disable TLS verification for the model provider.
   - Use Playwright MCP to validate the setup path from a clean state and roll it back. Read
     `Admin_GUI/flow_catalog/schema.json` first, then
     `${PAGEEXPLORE_ROOT}/sitemap.md`,
     `${PAGEEXPLORE_ROOT}/GRID_OPERATION_GUIDE.md`, and the selected
     `${PAGEEXPLORE_ROOT}/pages/` profile before navigation.
   - For maker/checker flows, submit the maker request, validate it from the
     checker session, then Reject it and verify the original state. For other
     forms Cancel before persistent save. Never click Approve. Keep the
     approval required by the YAML in the manifest as a Step_Index-backed
     object with `mcp_execution=deferred_to_feature`; do not emit cleanup as a
     Feature step.
   - Record route, action order, screenshots/errors, and redacted Grid
     observations (`getColumnDefs`, row shape, runtime key pattern). Never
     copy a UUID, credential, or raw `setRowData` call into a Feature.
   - Convert the reviewed result into a versioned Admin flow manifest. Every
     manifest action must use `steps[].text`, name an existing UAT step from
     `Step_Index.json`, and include any DataTable required by its runtime
     signature. Use `page.route`/`page.profile`; do not emit `page_route`,
     `uat_step`, or `mcp_execution=completed`.
   - Add `source_coverage` mapping every 1-based YAML Admin TestStep to the
     1-based flow steps that implement it. Every flow step must be covered;
     coverage metadata cannot substitute for an omitted operation.
   - Run the PageExplore-backed page contract before Feature generation. It
     derives all menu/route/profile relationships from `sitemap.md`, tracks
     each saved browser's current page, and validates Search/table/detail names
     plus profile fields. Correct only a uniquely provable mismatch; block an
     ambiguous page chain. Require the Playwright transcript to have observed
     the declared route in a completed tool result.
   - Existing human-authored Features (including `uat/uat_admin_feature.txt`)
     are read-only corroborating evidence for normal wording and order during
     repair. They never override sitemap, the selected profile, Step_Index, or
     the current case's YAML values.
   - Treat browser evidence and semantic JSON validation separately. Allow the
     batch to normalize only mechanically provable shape mistakes. If the
     browser rollback passed but Step_Index validation still fails, make at
     most one browser-free semantic repair with Playwright, credentials,
     shell, network, and business actions disabled; never rerun MCP merely to
     repair the handoff JSON.
   - Do not use browser-free repair to add behavior that the flow omitted.
     Missing navigation/search/detail/mutation/submission/checker Reject
     evidence/effective-date handling or requested verification is an evidence
     gap: quarantine the candidate and require a fresh rollback-validation MCP
     run. If maker submit plus checker Reject cleanup and final-state restoration
     are already proven, a missing checker Feature-session skeleton before the
     deferred Approve is manifest composition, not missing browser behavior, and
     may be repaired without MCP.
   - Run `tools/admin_feature_converter.py --standalone-admin` to create the
     independent Admin Feature. Compare its complete Background, ordered
     scenario steps, and DataTables to the MCP manifest before execution.
     Do not compose it with the Binary Feature for initial validation or
     repair. Unknown steps,
     `observed`/`inferred` evidence, and review notes must produce `@REVIEW`;
     use `--strict` only after the rollback-validation MCP pass has completed.
   - Keep the manifest, conversion report, and Playwright evidence together so
     a generated step can be traced back to the exploration that justified it.
   - After a successful standalone Admin validation pass, persist the semantic manifest under
     `Admin_GUI/flow_catalog/flows/`, refresh the catalog, and promote it to
     `safe_to_reuse` only after the generated Feature also passes.

6c. **Check repair experience before composing a flow**
   - Read `repair_experience/INDEX.md` for recurring failure and anti-pattern
     findings. A `candidate` or `reviewed` lesson is human-review context only;
     it is not loaded as an executable correction.
   - Apply a lesson as positive guidance only when both
     `status=verified` and `reuse.safe_to_reuse=true`. Re-check the current
     Feature, runtime source, and evidence even for a verified lesson.

7. **Apply matched conversion rules**
   - Each generated `## Step N` must be traceable to one or more YAML `TestSteps` entries.
   - Preserve original business intent, test data, and expected result.
   - For `binary`, use the existing FIX rule path. For `admin`, render the
     manifest through the Admin converter. For a single-day `hybrid`, render
     the Admin manifest into `<case>.admin.feature` and Binary/Trading GUI/
     Clearing steps into `<case>.feature`. If a `batch` TestStep marks a next
     trading/business day, instead render `<case>-Day1.feature` and
     `<case>-Day2.feature`, plus `<case>.execution-flow.json`. Never insert the
     Admin setup into a non-Admin continuation.
   - A next-day batch step is an external execution gate. Do not translate it
     into `Wait`, `@REVIEW`, shell code, or invented Gherkin. Day1 saves
     `<case>-Day1` with `Save FIX dumpfile`; Day2 loads it in Background.
   - Cross-check the expected business transition against the selected ODP FS;
     do not infer a rule from a failing screenshot or a model explanation.

7b. **Extract YAML metadata for feature header**
   - Map `Key`, `Name`, `Objective`, `Labels`, and `Folder` to feature tags/header.
   - Determine the correct `@FEATURE` tag per `conversion-rules.md`.

8. **Create feature file**
   - Create under `features/test_case/<Domain>/`.
   - Ensure correct tags, scenario name, case ID, dataset reference, step numbering, and business flow.
   - A generated Admin draft must retain `@REVIEW` until all report reasons
     are resolved; do not present it as runnable. A single-day Hybrid owns two
     independent Features; a cross-day Hybrid owns three. Neither may use
     another Feature to hide a review marker or unsupported step. The
     execution-flow JSON is orchestration metadata, not a fourth Feature.

9. **Update dataset**
   - Add the new `case_id` mapping to the appropriate `resource/dataSet-ODP*.csv` file.
   - Do not delete or overwrite unrelated dataset entries.

10. **Update transformation rule document if needed**
   - Add reusable new patterns to the appropriate rule document.

11. **Step-by-step verification**
   - Re-read YAML, count all `TestSteps`, and verify every step is represented in the feature file.
   - Check common omissions: Trading GUI verification, Clearing verification, Day1 presetting, dataset mapping, FS mapping, and expected result validation.

12. **Final validation**
   - Confirm feature syntax, style, dataset references, FS mappings, and step coverage.
   - Run the target runtime's dry run through `tools/run_feature_debug.rb`.
     For a Hybrid case, validate `<case>.admin.feature` against the MCP flow
     and execute/repair it independently first. Only after it passes, validate
     the separate non-Admin Feature(s) without supplying Admin flow evidence
     to that repair. Follow `<case>.execution-flow.json`; never execute Day2
     until its external `night_batch` gate has been explicitly completed.
   - Keep the JSON report and redacted log with the case evidence. A wrapper
     smoke test is not evidence that the target Cucumber/WABI environment is
     available.

## Feature Execution and Diagnosis

Generation remains independent from execution. The default batch mode only
creates Features. Opt in explicitly with `--run-generated`,
`--debug-generated`, or `--repair-generated`; diagnosis is read-only, while
the repair mode invokes the audited edit/rerun loop for every generated
Feature and stops each loop when Cucumber passes. For Admin/Hybrid cases,
`--repair-generated` also enables missing-flow Playwright MCP exploration
before generation. A trailing no-value
`--repair` after the three generation directories is equivalent to
`--repair-generated`. Add
`--binary-debug` to pass `LOGLEVEL=DEBUG`, `WABI_FIX_DEBUG=1`, and
`WABI_TIMING=1` to the Cucumber process for that run. The equivalent batch
environment setting is `FEATURE_BINARY_DEBUG=1`.

For a Feature that a user has edited, run the same standalone wrapper:

```bash
ruby tools/run_feature_debug.rb path/to/case.feature \
  --workdir /path/to/uat-checkout \
  --cucumber-command 'bundle exec cucumber' \
  --diagnose
```

The wrapper records a redacted log, a JSON report, the Feature hash, index
hashes, explicit FIX field/value enum matches, detected error-code field
labels, and category-scoped matches. It automatically scopes known FIX fields and accepts repeatable
`--error-category CATEGORY_ID` hints for generic log output. Diagnosis mode
never rewrites the Feature. For an explicitly authorized repair, pass
`--repair`; the runner restricts edits to the requested Feature, records the
before/after hash and changed paths, and reruns until success (or until
`--repair-attempts N`; `0` means no limit). `@REVIEW` drafts are blocked unless `--allow-review` is explicit;
resolve conversion review reasons before treating a run as valid. See
[`Feature_Run_and_Debug.md`](Feature_Run_and_Debug.md) for batch flags,
existing-Feature mode, bounded-output timeout behavior, and runtime
prerequisites. Batch conversion uses a permissioned opencode command with a
restricted environment; automatic permission flags are rejected. Assisted
transforms run only newly created Features, while a local deterministic Admin
conversion may use its explicit output path.
For batch diagnosis, configure `OPENCODE_DEBUG_CMD` or
`--diagnose-opencode-command`; conversion and diagnosis commands are kept
separate.

For an Admin/Hybrid repair, use `--playwright-flow PATH` to attach the reviewed
positive-flow manifest. The runner compares its semantic steps with the
Feature. To collect fresh browser evidence, configure an explicit
`--playwright-replay-command` adapter with `{flow}` and optionally `{report}`,
`{feature}`, `{bindings}`, and `{attempt}`. Pass project-private real values
through `--playwright-bindings PATH`; they are hashed but never sent to the
repair model. An authoritative replay must acknowledge the current Feature
and bindings hashes in its report. Use `--playwright-replay-mode each_attempt` when
the baseline must be replayed before every model repair. Keep Playwright and
Cucumber serialized unless they use isolated environments and data. The
Playwright phase is read/evidence-only; it cannot edit the Feature, and raw
locators, JavaScript, dynamic IDs, or qaGrid mutations must not cross into
Gherkin. See `Feature_Run_and_Debug.md` for the adapter report contract.

Repair defaults to `--data-preflight auto`. Known missing inputs and aliases,
and aliases whose data source cannot be checked, block model repair. A runtime
alias found in project data is only configured, not proven valid on the ODP
page. Use `--preflight-only` for readiness, `--allow-unresolved-data` for one
evidence-only Cucumber run, and `--data-preflight off` only after reviewing a
false positive. Never infer a failure from Cucumber steps reported as skipped.

OpenCode uses the configured internal model `ollama/DeepSeek-V4-Flash-INT8` by
default. Select another
provider-qualified model with `--model provider/model` or `OPENCODE_MODEL`; the
same setting is forwarded to conversion, diagnosis, and repair. An explicit
`--model`/`-m` already present in a custom OpenCode command takes precedence.

Batch conversion searches the bundled Admin flow catalog by default and only
selects flows marked `verified` and `safe_to_reuse`. An explicit
`--admin-flow-dir` may point to case-local manifests; observed/inferred flows
still need the explicit `--allow-unverified-admin-flow` opt-in. Initial
missing-flow exploration is integrated into the generation batch when
`--repair-generated` or `--admin-explore` is selected. Browser replay between
Feature repair attempts is a separate operation and still requires a
project-owned `--playwright-replay-command` adapter.

## Repair Experience and Promotion

Every explicit `--repair` run that performs at least one repair attempt records
a redacted candidate under `repair_experience/inbox/`. The candidate contains hashes, statuses, and
structured error observations, not passwords, cookies, raw browser traces, or
the complete Feature. Review candidates, generalize them into a lesson under
`repair_experience/lessons/`, replay from a clean state, and set
`status=verified` plus `reuse.safe_to_reuse=true` only after the resulting
Feature passes. Refresh the deterministic index with:

```bash
python3 tools/build_repair_experience_catalog.py
python3 tools/build_repair_experience_catalog.py --check
```

Do not automatically promote a model explanation or feed an unverified
candidate back as a repair instruction. This separation prevents a transient
environment failure or an incorrect model edit from becoming accumulated
experience.

## Mandatory Rule Loading Principle

The AI must not blindly load all transformation rules at the beginning. Analyze the YAML test case first, summarize required feature steps, identify rule categories, then load only the corresponding rule files.

## Rules for AI Behavior
1. **Always read skill files first** before making any project changes
2. **Always update related documentation** when code or rules change
3. **Use reference feature files** for patterns before creating new ones
4. **Follow naming conventions exactly** - don't deviate from established formats
5. **Verify dataset CSV files** after adding new test cases
6. **Mark unclear rules** as "To be confirmed" instead of guessing
7. **Use targeted edits** for localized changes
8. **Interface Selection Rule**: If a test case mentions input/place/send order/quote/trade but does NOT explicitly specify Trading GUI or Binary interface, then use Binary interface for the operation.
