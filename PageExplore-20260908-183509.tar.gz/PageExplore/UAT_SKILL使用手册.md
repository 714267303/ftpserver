# PageExplore 使用手册（兼容入口）

> The canonical tester guide is [`USER_GUIDE.md`](USER_GUIDE.md). This
> localized file remains in the maintainer source checkout for compatibility
> and is excluded from tester delivery archives.

版本日期：2026-09-02  
适用目录：测试人员项目根目录下的 `PageExplore/`

## 1. 用途与边界

`PageExplore` 是 ODP-T 自动化测试的知识、转换和诊断工具包，主要用于：

- 使用 Playwright MCP 探索 ODP Trading Admin 页面；
- 将 Excel 测试案例转换为 YAML，再转换为 Ruby/Cucumber Feature；
- 根据已审核的 Admin GUI 流程生成 Admin 或 Admin+Binary Hybrid Feature；
- 可选运行新生成的 Feature；
- 运行人工修改后的既有 Feature，并在失败时调用 opencode 做只读诊断；
- 通过显式 `--repair` 让 opencode 修复指定 Feature，并复跑直到成功；
- 查询 Admin 页面、qaGrid API、UAT Step、FIX 枚举和错误码索引；
- 持久化已探索的 Admin GUI 业务流程，供后续案例复用。

本目录不是完整的 UAT 运行时。`features/customized_steps/` 是步骤参考和索引来源，不能替代目标 `wabi-fix` checkout 中的 Gem、配置、数据集、服务地址和 Cucumber 环境。实际 Feature 执行必须通过 `--workdir` 指向已配置的目标 UAT checkout。

Admin 页面探索只能通过 Playwright MCP 操作浏览器。不要直接调用后端接口，不要覆盖浏览器的 `fetch`/`XMLHttpRequest`，也不要把 Playwright locator、动态 UUID、原始 JavaScript 或 `qaGridApi.setRowData()` 当作最终业务步骤。

## 2. 三条最短使用路径

交付时把 `PageExplore/` 放在测试项目根目录，例如：

```text
ProjectA/
  features/
  resource/
  PageExplore/
```

以下示例从 `PageExplore/` 目录执行以保持路径简短；若从 `ProjectA/`
根目录执行，请在工具路径前加 `PageExplore/`。Feature 的 `--workdir`
始终指向包含 `features/`、`resource/` 和运行时配置的测试项目。

### 2.1 只生成 Feature，不运行

这是批处理的默认行为：

```bash
ruby tools/batch_transform_tc.rb EXCEL_DIR YAML_DIR FEATURE_DIR
```

### 2.2 生成后运行，并诊断失败案例

```bash
ruby tools/batch_transform_tc.rb EXCEL_DIR YAML_DIR FEATURE_DIR \
  --debug-generated \
  --binary-debug \
  --run-workdir /path/to/wabi-fix-uat \
  --cucumber-command 'bundle exec cucumber' \
  --run-report-dir outputs/feature-runs
```

`--debug-generated` 表示生成成功后运行，只有失败时才调用 opencode 诊断。若只运行、不需要模型诊断，改用 `--run-generated`。

### 2.3 人工修改 Feature 后直接运行或调试

```bash
# 只运行
ruby tools/run_feature_debug.rb path/to/case.feature \
  --workdir /path/to/wabi-fix-uat \
  --cucumber-command 'bundle exec cucumber'

# 运行并诊断失败
ruby tools/run_feature_debug.rb path/to/case.feature \
  --workdir /path/to/wabi-fix-uat \
  --cucumber-command 'bundle exec cucumber' \
  --diagnose \
  --binary-debug \
  --error-category ORDER_REJECT

# 失败后让 opencode 修复指定 Feature，并复跑直到成功
ruby tools/run_feature_debug.rb path/to/case.feature \
  --workdir /path/to/wabi-fix-uat \
  --cucumber-command 'bundle exec cucumber' \
  --repair \
  --repair-attempts 0
```

诊断是只读操作，不会修改 Feature。
`--repair` 是单独的显式修改模式，只允许改指定 Feature；不要与
`--diagnose` 同时使用。

## 3. 环境准备

### 3.1 基础依赖

| 场景 | 需要的环境 |
|---|---|
| 阅读文档、查询索引 | 常规文本编辑器、Python 3 |
| Admin 页面探索 | 可用的 Playwright MCP、可访问的 ODP 环境 |
| Excel/YAML/Feature 转换 | Python 3、Ruby、opencode |
| Feature dry-run/执行 | 目标 checkout 的 Ruby、Bundler、Cucumber、WABI Gem 和运行配置 |
| Binary/FIX 调试 | 上述运行时，以及可连接的 Binary/FIX 服务 |

Excel 解析器使用 Python 标准库读取 `.xlsx`；旧 `.xls` 或复杂工作簿应先确认转换工具是否支持。

### 3.2 ODP 页面探索配置

在运行时项目根目录复制示例文件并填入本地值。交付布局中应放在
`ProjectA/.env`，与 `features/`、`resource/`、`PageExplore/` 同级，**不要**放在
`ProjectA/PageExplore/.env`：

```bash
cd /path/to/ProjectA
cp PageExplore/.env.example .env
```

若直接在本源码目录运行，则使用 `cp .env.example .env`。

也可以直接设置环境变量：

```bash
export ODP_URL='https://odp.example/'
export ODP_USERNAME='<your-user>'
export ODP_PASSWORD='<your-password>'
export ODP_CHECKER_USERNAME='<your-checker-user>'
export ODP_CHECKER_PASSWORD='<your-checker-password>'
```

注意：

- `ODP_URL` 应包含末尾 `/`；
- 兼容旧配置中的主机/IP 简写，例如 `10.161.65.56` 或
  `10.161.65.56:8443`；运行器会按 HTTPS 规范化。浏览器登录页
  `/ESUI/eventServerLanding.html?login_mode=both`（以及旧环境中的
  `/ESUI/eventServerLanding_html?login_mode=both`）也会自动还原为基地址；其他查询串、片段或账号密码会被拒绝；
- `.env` 含凭据，不要提交、分享或放入交付压缩包；
- 登录步骤和选择器以 `pageExplore/sitemap.md` 为准；
- TLS 证书校验策略由 Playwright MCP 的运行配置控制。

批处理会在启动 Admin MCP 前由父进程解析 `ODP_URL`（优先级为
`--odp-url`、已导出的 `ODP_URL`、运行时 `.env`），并把它作为唯一的非敏感
导航配置传给探索模型。Playwright MCP 的 `--secrets` 仅用于对浏览器工具返回值
脱敏，不会将 dotenv 键名替换成实际值。仅在 Admin 探索阶段，模型
拥有整个运行项目（包括该 `.env`）的读取权限；它会在首次浏览器导航前读取
`ODP_USERNAME/ODP_PASSWORD` 作为 maker 凭据，并在 maker/checker 案例中读取
`ODP_CHECKER_USERNAME/ODP_CHECKER_PASSWORD` 作为 Reject 清理凭据（均兼容
对应的 `SECRET_ODP_*` 别名），且仅将实际值用于浏览器登录字段。Excel/YAML 转换模型仍不可读取凭据，
Admin 文件写权限仍仅限本次 evidence 目录。终端和 OpenCode transcript 会按实际
登录值再次脱敏，report 和 flow manifest 禁止保存账号、密码、Cookie 或 Token。
这四个 dotenv 值只供 MCP 提交和回滚验证使用；生成的 Feature 仍从运行项目的
`resource/admin_gui_value.csv` 解析 `admin_gui_user1`/`admin_gui_user2` 及其密码别名，
两处配置需要分别准备。
页面 snapshot 中的 ref 在 Admin 探索中仅用于观察；基于 ref 的 click/type/fill/
select/hover/drag 工具已禁用。模型通过新 snapshot 获取当前的 role/name/label/id，
然后使用 raw Playwright locator 或 `GRID_OPERATION_GUIDE.md` 中的审核模板操作 UI，但仍禁止直连
后端或覆盖 fetch/XHR。如果模型退出时未写 `exploration-report.json`，父进程会根据
已脱敏 transcript 生成确定性失败报告，仅用于诊断，不会把未完成探索标记为通过。
MCP 已完成提交、验证和 Reject/Cancel 回滚后，批处理会单独检查
`admin-flow.json`。`page_route`、`uat_step` 等可确定转换的结构错误会自动规范化并
记录修改前后 SHA-256；自然语言步骤或缺少 DataTable（例如无表格的
`Approve if updated with :`）则最多触发一次无浏览器语义修复。该修复阶段禁止
Playwright/MCP、shell、网络、`.env` 和业务操作，不会因为 JSON 写错而重跑已经
完成的浏览器流程；仍无法通过 Step_Index 校验时保留证据并以 `ADMIN-FAIL` 结束。
若地址或 secrets 文件缺失，批处理
会在启动模型前给出明确的配置错误。无效或仍是 `${ODP_URL}` 占位符的进程环境
变量不会再遮住有效的 `.env`；失败诊断会列出检查过的路径及“文件不存在、不可读、
缺少键或 URL 格式无效”等原因，但不会输出用户名或密码。

若需要完全绕过自动发现，可使用绝对、明确的参数：

```bash
ruby PageExplore/tools/batch_transform_tc.rb ... \
  --odp-url 'https://odp-host/' \
  --playwright-mcp-secrets "$PWD/.env"
```

### 3.3 Feature 运行时配置

推荐显式传参：

```bash
--workdir /path/to/wabi-fix-uat
--cucumber-command 'bundle exec cucumber'
```

也可以使用环境变量：

```bash
export UAT_RUNTIME_ROOT='/path/to/wabi-fix-uat'
export CUCUMBER_CMD='bundle exec cucumber'
```

运行前至少确认：

```bash
cd "$UAT_RUNTIME_ROOT"
bundle exec cucumber --version
```

## 4. 目录导航

| 路径 | 作用 |
|---|---|
| `README.md` | 项目入口和关键规则 |
| `AGENTS.md` | Playwright 探索的强制阅读与操作边界 |
| `pageExplore/sitemap.md` | 登录、SPA 导航、96 个 Admin 页面路由 |
| `pageExplore/GRID_OPERATION_GUIDE.md` | qaGrid 过滤、分页、详情页和常见陷阱 |
| `pageExplore/pages/INDEX.md` | 根据 PageExplore 快照生成的页面总索引 |
| `pageExplore/pages/<route>.md` | 单页字段、主键、cacheName 和 Grid 元数据 |
| `odp-tc-excel-yaml-skill/` | Excel 到 YAML 的规则与解析器 |
| `odpt-automation-skill/` | YAML 到 Feature 的主技能、领域规则和索引 |
| `odpt-automation-skill/Binary_Interface/` | Binary/FIX Feature 转换规则 |
| `odpt-automation-skill/Admin_GUI/` | Admin GUI 操作和 Feature 转换规则 |
| `odpt-automation-skill/Trading_GUI/` | Trading GUI 操作规则 |
| `odpt-automation-skill/Admin_GUI/flow_catalog/` | 可检索的 Admin 语义流程目录 |
| `odpt-automation-skill/repair_experience/` | 修复候选、复核经验和反模式目录 |
| `features/customized_steps/` | UAT Ruby 步骤参考快照，不是完整运行时 |
| `pageExplore/evidence/` | 页面探索与 qaGrid 的原始证据快照，仅用于重建知识库索引 |
| `odp-docs/` | Restored ODP Functional Specifications; business-reference knowledge base |
| `uat/` | UAT Step、工具和既有 Feature 的参考快照；不存放页面/qaGrid 知识 |
| `tools/` | 转换、索引、运行和诊断工具 |

常用机器可读索引：

| 索引 | 用途 |
|---|---|
| `odpt-automation-skill/Step_Index.json` | 查找已有 Gherkin Step |
| `pageExplore/qaGrid/qaGridApi_Index.json` | 查找 Grid key pattern、方法和字段 |
| `odp-docs/INDEX.json` | Select an ODP Functional Specification and verify source/hash provenance |
| `odpt-automation-skill/FIXODPMSG_Index.json` | 查询 FIX 字段和枚举 wire value |
| `odpt-automation-skill/Error_Code_Index.json` | 按类别查询错误码含义 |
| `pageExplore/pages/INDEX.json` | 页面路由和 profile 元数据 |
| `odpt-automation-skill/Admin_GUI/flow_catalog/INDEX.json` | Admin 流程状态和检索数据 |
| `odpt-automation-skill/repair_experience/INDEX.json` | 修复经验的状态、证据和可复用标志 |

The packaged `odp-docs/INDEX.md` is for document selection and
`odp-docs/INDEX.json` is for tooling. Read the relevant FS sections before
mapping a business transition to Feature steps; runtime UAT step definitions
still decide whether a Gherkin step is executable. Source-bundle restoration is
maintainer-only packaging work and is outside the normal test-user workflow.

## 5. 使用 Playwright MCP 探索 Admin GUI

### 5.1 强制阅读顺序

在导航前阅读：

1. `pageExplore/sitemap.md`；
2. `pageExplore/pages/INDEX.md`；
3. 目标页面的 `pageExplore/pages/<route>.md`。

涉及 Grid 操作时，再阅读 `pageExplore/GRID_OPERATION_GUIDE.md`。

### 5.2 核心规则

- 集成的 MCP 阶段使用回滚验证：maker 提交待审批请求，checker 验证 countersign 路径后执行 `Reject`，并确认原业务状态未改变；无 countersign 的表单在持久化前执行 `Cancel`；
- MCP 不点击 `Approve`。`Reject`/`Cancel` 只属于探索清理，不写入语义 flow；YAML 要求的审批步骤仍标记为 `mcp_execution=deferred_to_feature`，由生成的 Feature 执行 `Approve`；
- ODP 是 React SPA，qaGrid 是 canvas 表格，不存在可直接定位的 HTML `<table>` 行列；
- 已登录后通过 `history.pushState` 和 `PopStateEvent` 做 SPA 导航，不对受保护页面直接 `page.goto()`；
- Grid 数据通过 `window.qaGridApi[gridKey]` 读取；
- 运行时 Grid key 可能包含 UUID，必须按 page profile 的 `keyPattern` 匹配，不能复制一次运行中的完整 key；
- 服务端过滤使用 `page.route('**/api/private/subscribeView')`，重新注册前先 `unroute()`；
- 布尔值使用字符串 `"Y"`/`"N"`；
- 分页保持 Grid 原始 `pageSize`，收集结果后按页面 profile 的主键去重；
- 不要用 `setRowData()` 模拟业务提交，它会改变 Grid 内部状态；
- 页面探索结束后恢复路由和分页状态。

### 5.3 证据保存

一次独立探索建议使用：

```text
outputs/admin/<case-id>/run-001/
  notes.md
  trace.zip
  screenshots/
  network-summary.json
  grid-observations.json
```

原始证据目录可以保留动态 locator、UUID 和受控的行数据，但必须限制访问并脱敏。不要把凭据、Cookie、Authorization header 或完整业务数据写入语义 flow manifest。

## 6. 持久化和复用 Admin GUI 流程

推荐生命周期：

```text
Playwright MCP 干净状态下提交并 Reject/Cancel 回滚（不 Approve）
  -> outputs/admin/<case>/run-###/ 原始证据
  -> flow_catalog/flows/<flow-id>.json 语义步骤
  -> 构建并检查 catalog
  -> 生成 Admin/Hybrid Feature
  -> Cucumber dry-run 和实际重放
  -> 标记为 verified + safe_to_reuse=true
```

查询已有流程：

```bash
python3 tools/find_admin_flow.py 'SMP ID List'
python3 tools/find_admin_flow.py 'SMP ID List' --status verified
python3 tools/find_admin_flow.py 'SMP ID List' --json
```

重新生成并校验 catalog：

```bash
python3 tools/build_admin_flow_catalog.py
python3 tools/build_admin_flow_catalog.py --check
```

当前随包 catalog 的状态是：1 个 `observed` 流程、0 个 `verified` 流程、0 个可安全自动复用流程。`observed`/`inferred` 只能帮助下次探索，不能视作已经跑通。

批处理默认只选择同时满足以下条件的流程：

```text
evidence_status = verified
reuse.safe_to_reuse = true
```

`--allow-unverified-admin-flow` 只应在人工检查并明确接受风险后使用。

## 7. Excel 到 YAML

先阅读：

- `odp-tc-excel-yaml-skill/SKILL.md`；
- `odp-tc-excel-yaml-skill/rules.md`。

解析单个 Excel 测试案例：

```bash
python3 odp-tc-excel-yaml-skill/parse_excel.py path/to/case.xlsx
python3 odp-tc-excel-yaml-skill/parse_excel.py path/to/case.xlsx 0
```

第二个参数是从 0 开始的案例行序号。解析器输出 JSON；YAML 生成仍需遵循技能规则，尤其是：

- 不新增源 Excel 没有的检查点；
- Expected Result 数量必须与源案例一致；
- 每个 GUI 检查点写明系统和窗口；
- Excel 未指定订单接口时，按技能规则默认归入 Binary；
- 保留原始 Key、Name、Status、数据和步骤顺序。

通常直接使用批处理即可同时完成 Excel 到 YAML 和 YAML 到 Feature：

```bash
ruby tools/batch_transform_tc.rb EXCEL_DIR YAML_DIR FEATURE_DIR
```

## 8. YAML 到 Feature

### 8.1 批量转换

```bash
ruby tools/batch_transform_tc.rb EXCEL_DIR YAML_DIR FEATURE_DIR
```

默认只转换，不执行 Feature。批处理保持逐案例顺序，转换失败、找不到新 Feature 或请求的执行失败时返回非零状态。

批处理默认检索包内 `odpt-automation-skill/Admin_GUI/flow_catalog/flows/`。
如果 YAML 的 `Execution Channel` 包含 `admin_gui`，不会再误走 Binary/普通模型
转换。使用 `--repair-generated` 时，如找不到同案例且可复用的 Admin flow，批处理
会自动通过 OpenCode 启动本地 Playwright MCP，提交测试请求、验证 Admin
页面和语义步骤、执行 Reject/Cancel 回滚并保存证据；其他生成模式可用 `--admin-explore` 显式启用，
`--no-admin-explore` 则要求
事先已有可复用 flow。

Admin/Hybrid 的执行边界如下：

1. 第 2 步：Excel 转 YAML；
2. 第 3 步：读取 `Execution Channel` 并分类；
3. 第 1 步：复用已审核 flow，或用 Playwright MCP 验证并回滚缺失的 Admin 流程；
4. 第 4 步：先根据 flow 确定性生成独立的 `<case>.admin.feature`，逐项比较 Background、Step 顺序和 DataTable；
5. 第 5A 步：单独运行 Admin Feature，仅修复该 Admin Feature；
6. 第 6 步：仅根据独立 Admin Feature 的报告提升 flow。失败时 flow 保持
   `safe_to_reuse=false` 并降级隔离为 `observed`。
7. 第 7 步：Hybrid 在 Admin 验收之后生成非 Admin Feature 和
   `<case>.execution-flow.json`。单日案例生成 `<case>.feature`；包含下一交易日
   batch 边界的案例生成 `<case>-Day1.feature` 与 `<case>-Day2.feature`。

Admin 和非 Admin Feature 不再合并后调试；非 Admin 失败不会导致已通过的 Admin flow 降级。
如果 Admin 修复后的 Step 顺序或 DataTable 与 MCP flow 不一致，批处理只会
根据 flow 重建 `<case>.admin.feature` 并再测一次，不会用 Binary Feature
去修复 Admin 行为。

跨日 Hybrid 的执行流固定为：

```text
admin -> day1 -> night_batch（外部关卡）-> day2
```

因此 ODP-T2194 会生成 3 个 Feature 和 1 个执行流 JSON。Day1 末尾使用
`Save FIX dumpfile <case>-Day1`，Day2 的 Background 加载同一个 dump。
night batch 不会转换成 `Wait`、`@REVIEW` 或虚构的 Gherkin。真实运行在 Day1
通过后以状态码 3 停在关卡；确认夜批完成且市场状态为 OPEN 后续跑：

```bash
ruby PageExplore/tools/batch_transform_tc.rb \
  --run-execution-flow features/test_case/CASE/<case>.execution-flow.json \
  --complete-gate night_batch \
  --repair-generated --run-workdir . \
  --cucumber-command 'bundle exec cucumber'
```

只有已经处于 `waiting_for_gate` 的执行流才能确认该关卡，所以不能在首次运行时
用参数跳过夜批。`--dry-run` 和 `--preflight-only` 可以无副作用地校验全部 Feature。

第 1 步会提交 maker 待审批请求，但不会执行 checker `Approve`；checker 使用
`Reject` 完成回滚，且必须确认没有遗留 Pending 请求、原业务状态未改变。需要的
`Approve` 作为简短、已维护的 Step_Index 语义步骤保留在 flow 中，由第 5 步实际
运行 Feature 时执行。只有 MCP 清理成功且 Feature 通过后，第 6 步才允许复用此 flow。

Playwright MCP 默认使用 headed 模式，VNC 环境先设置 `DISPLAY=:99`；无显示服务时
使用 `--playwright-mcp-headless`。首次缺 flow 的自动探索不需要
`--playwright-replay-command`；该 adapter 只用于 Feature 修复期间的重复浏览器重放。

生成后直接进入修复循环：

```bash
ruby tools/batch_transform_tc.rb EXCEL_DIR YAML_DIR FEATURE_DIR \
  --repair-generated \
  --run-workdir /path/to/wabi-fix-uat \
  --cucumber-command 'bundle exec cucumber' \
  --repair-attempts 0
```

也可以在三个目录参数之后使用不带值的 `--repair`。`--repair FEATURE`
表示只修复一个已有 Feature，不执行 Excel/YAML 转换；生成模式的 `--repair`
建议放在三个目录参数之后，避免可选参数误把目录当成 Feature 路径。

常用参数：

| 参数 | 作用 |
|---|---|
| `--channel auto|binary|admin|hybrid` | 指定转换通道 |
| `--admin-flow-dir DIR` | 指定 Admin flow manifest 目录 |
| `--admin-explore` / `--no-admin-explore` | 启用或禁止缺失 Admin flow 的 MCP 探索 |
| `--admin-evidence-root DIR` | 指定每次 MCP 探索的隔离证据根目录 |
| `--playwright-mcp-headed` | 使用可在 VNC 中观察的浏览器（默认） |
| `--playwright-mcp-headless` | 在没有 DISPLAY 的环境中无头运行 |
| `--odp-url URL` | 指定 Admin MCP 使用的 ODP 浏览器地址（覆盖 `ODP_URL`/`.env`，仅为非敏感配置） |
| `--playwright-mcp-secrets PATH` | 指定 MCP 优先使用、Admin 模型必要时可读取的 dotenv 凭据文件 |
| `--playwright-mcp-node/cli/browser PATH` | 指定非标准离线安装中的 Node、MCP CLI 和浏览器路径 |
| `--deterministic-admin` | 使用本地确定性 Admin converter |
| `--binary-base-dir DIR` | Hybrid 模式的 Binary 基础 Feature 目录 |
| `--strict-admin` | 遇到未知/未验证 Admin 步骤时失败 |
| `--run-generated` | 生成成功后运行新 Feature |
| `--run-execution-flow PATH` | 按执行流状态续跑尚未完成的 Feature |
| `--complete-gate ID` | 确认执行流已经等待的外部关卡；可重复 |
| `--debug-generated` | 生成后运行，失败时诊断 |
| `--repair-generated` | 生成后运行；失败时修复每个 Feature 并复跑直到成功 |
| `--repair`（放在三个目录参数之后且不带值） | `--repair-generated` 的简写；不要与 `--repair FEATURE` 混用 |
| `--binary-debug` | 为 Cucumber 开启 WABI/FIX 低层日志 |
| `--error-category ID` | 错误码类别提示，可重复 |
| `--verbose-model-output` | 打印完整的已脱敏子进程/模型事件；默认只显示流程、Prompt、进度和状态 |
| `--progress-interval SECONDS` | 设置精简日志的进度打印间隔（默认 15 秒） |
| `--dry-run` | 将 Cucumber 执行改为 dry-run |
| `--allow-review` | 允许执行带 `@REVIEW` 的草稿 |

### 8.2 确定性 Admin Feature 转换

```bash
python3 tools/admin_feature_converter.py \
  --flow path/to/flow.json \
  --standalone-admin \
  --output path/to/case.admin.feature \
  --report path/to/case.conversion.json \
  --step-index odpt-automation-skill/Step_Index.json
```

Hybrid 在批处理中也使用上述 `--standalone-admin`，然后独立生成非 Admin Feature。
如果需要检查已生成 Admin Feature 是否仍与 MCP flow 一致：

```bash
python3 tools/admin_feature_converter.py \
  --flow path/to/flow.json \
  --standalone-admin \
  --verify-feature path/to/case.admin.feature \
  --step-index odpt-automation-skill/Step_Index.json \
  --semantic-strict
```

原始 recorder 文件只适合生成待审核草稿：

```bash
python3 tools/admin_feature_converter.py \
  --recording-flow path/to/recording.flow.json \
  --case-id CASE-ID \
  --output path/to/case.admin.feature \
  --report path/to/case.conversion.json
```

未知 Step、未验证证据和 review note 会产生 `@REVIEW`。不要把带 `@REVIEW` 的文件当作已完成案例。

转换报告中的 `step_matches` 会记录每一步命中的 `source`、`signature` 和
`match_source`。存在 `Step_Index.json` 时，仅命中宽泛前缀不再算可执行步骤；必须
命中当前 runtime/customized step，否则保留为 `@REVIEW`。

### 8.3 测试人员项目中的目录布局

交付给测试人员时，将整个 `PageExplore/` 目录放在测试项目根目录下，
不要依赖固定的 `/vncworkspace` 路径。典型结构如下：

```text
ProjectA/
  features/
    test_case/
  resource/
  PageExplore/
    tools/
    odpt-automation-skill/
    pageExplore/
```

从 `ProjectA` 根目录执行工具，并把运行时 checkout 设为当前目录：

```bash
ruby PageExplore/tools/batch_transform_tc.rb \
  --repair features/test_case/CASE/case.feature \
  --run-workdir . \
  --cucumber-command 'bundle exec cucumber'
```

工具、Skill 和 PageExplore 知识库默认都从脚本所在的 `PageExplore/`
目录解析。只有明确设置 `ODP_LEGACY_REPO_ROOT` 时才会查找旧 checkout；
`PAGEEXPLORE_ROOT` 可用于知识库确实单独挂载的场景。

## 9. 运行和调试 Feature

### 9.1 独立 runner

```bash
ruby tools/run_feature_debug.rb path/to/case.feature \
  --workdir /path/to/wabi-fix-uat \
  --cucumber-command 'bundle exec cucumber' \
  --report outputs/feature-runs/case.json \
  --log outputs/feature-runs/case.log
```

常用参数：

| 参数 | 作用 |
|---|---|
| `--diagnose` / `--debug` | 仅在失败后调用 opencode 诊断 |
| `--repair` | 失败后让 opencode 只修改指定 Feature，并复跑直到成功 |
| `--binary-debug` | 给 Cucumber 注入 `LOGLEVEL=DEBUG`、`WABI_FIX_DEBUG=1`、`WABI_TIMING=1` |
| `--error-category CATEGORY_ID` | 限定错误码类别，可重复 |
| `--dry-run` | 运行 Cucumber dry-run |
| `--allow-review` | 明确允许执行带 `@REVIEW` 的文件 |
| `--timeout SECONDS` | Feature 超时 |
| `--diagnose-timeout SECONDS` | opencode 诊断超时 |
| `--repair-opencode-command CMD` | 指定 Feature 修复用的 opencode 命令 |
| `--repair-attempts N` | 修复/复跑轮数上限；`0` 表示直到成功 |
| `--repair-experience-dir DIR` | 脱敏修复候选写入目录（默认 `odpt-automation-skill/repair_experience/inbox`） |
| `--repair-experience-index PATH` | 提供已验证经验索引给修复提示词 |
| `--fix-index PATH` | 指定 FIX 枚举索引 |
| `--error-index PATH` | 指定错误码索引 |
| `--grid-index PATH` | 指定 qaGrid 索引 |
| `--step-index PATH` | 指定 Step 索引 |
| `--playwright-flow PATH` | 关联已审核的 Playwright/MCP 语义流程 JSON |
| `--playwright-replay-command CMD` | 调用项目自有 Playwright/MCP replay adapter；支持 `{flow}`、`{report}`、`{feature}`、`{attempt}` |
| `--playwright-workdir DIR` | replay adapter 的工作目录 |
| `--playwright-replay-mode MODE` | `off`、`before_feature`、`on_failure`（默认）或 `each_attempt` |
| `--playwright-timeout SECONDS` | 单次 Playwright replay 超时 |

runner 会生成：

- JSON 执行报告；
- 脱敏后的合并输出日志；
- 使用 `--diagnose` 且执行失败时的 `.diagnosis.md`。
- 使用 `--repair` 时的 `.repair.md`、每轮复跑日志和修复审计信息。
- 使用 `--repair` 时写入 `repair_experience/inbox/` 的脱敏候选记录（仅复核用途）。

用户定义的 special/customized Ruby Step 是自动修复的硬边界。如果异常栈中的
`NoMethodError`、`NameError`、`ArgumentError` 等代码错误来自
`features/customized_steps/*.rb` 或 `features/step_definitions/*.rb`，报告分类为
`custom_step_implementation`，不启动 OpenCode 修复，也不会通过改 Feature
绕过错误。所有用户 `.rb` 文件始终只读，需要人工修复后再续跑原 Feature 或
execution flow。

修复日志的生成时机需要区分：每次调用 opencode 后都会写入
`.repair.md`，其中保留脱敏后的模型交互结果；只有模型命令正常完成、
目标 Feature 仍存在且没有越权变更时，runner 才会继续执行 Cucumber，
并写入对应的 `rerun_N.log`。因此报告中的
`repair_permission_denied` 表示 transcript 已写入但复跑尚未开始，
不应期待该轮存在 `rerun_N.log`。JSON 报告中的 `output_exists`、
`rerun_attempted`、`rerun_log` 和 `rerun_count` 用于确认每个文件是否
实际落盘以及是否真正进入复跑阶段。

报告包含 Feature hash、索引 hash、执行状态、错误码观察、按类别匹配结果和明确出现的 FIX `Field=Value` 枚举解释。

### 9.2 通过批处理入口运行既有 Feature

```bash
# 不诊断
ruby tools/batch_transform_tc.rb \
  --run-feature path/to/case.feature \
  --run-workdir /path/to/wabi-fix-uat \
  --cucumber-command 'bundle exec cucumber'

# 失败时诊断
ruby tools/batch_transform_tc.rb \
  --debug-feature path/to/case.feature \
  --binary-debug \
  --run-report-dir outputs/feature-runs \
  --run-workdir /path/to/wabi-fix-uat \
  --cucumber-command 'bundle exec cucumber'
```

`--run-feature` 与 `--debug-feature` 互斥。

如需让 opencode 修改一个已有 Feature 并在修改后复跑，使用
`--repair FEATURE`，不需要再加 `--debug-feature`：

```bash
ruby tools/batch_transform_tc.rb \
  --repair path/to/case.feature \
  --run-workdir /path/to/wabi-fix-uat \
  --cucumber-command 'bundle exec cucumber' \
  --repair-attempts 0
```

流程会先运行 Cucumber；失败后只允许修改指定 Feature，记录修改前后
hash 和变更路径，再复跑。复跑成功即停止。`--repair-attempts N` 可设置
最大修复/复跑轮数，`0`（默认）表示持续到成功；OpenCode 执行错误、越权
修改或 Feature 被删除时会停止。`--repair-opencode-command`（或
`OPENCODE_REPAIR_CMD`）用于指定修复命令。`--debug-feature` 仍保持只读诊断。

每轮实际调用修复器后还会把脱敏后的候选记录写入
`odpt-automation-skill/repair_experience/inbox/`（可用
`--repair-experience-dir` 指定目录）。候选只用于复核，不能直接作为下一轮
的确定性修复指令。将通用结论整理到 `repair_experience/lessons/`，在干净环境
重放并确认 Feature 成功后，才可以设置 `status=verified` 和
`reuse.safe_to_reuse=true`。`Admin_GUI/flow_catalog/` 只保存成功且经过验证的
Playwright 正向执行流；失败形状和反模式留在 `repair_experience/`，不要把两类
内容混成一个“正确流”目录。

本例中的 Admin maker/checker 登录必须拆成两个完整会话：每个 `Open browser`
只跟一个一行的 `Login Trading Admin with:` 表，再执行对应的
`Save current browser`。不要把两个用户放在同一张登录表后保存同一个浏览器。

### 9.2.1 Playwright-assisted Web repair

For an Admin or Hybrid Feature, `--playwright-flow` attaches a reviewed semantic
flow and adds a static step-order comparison to the run report. A Playwright MCP
server is a protocol service, so the runner requires a project-owned replay
adapter when fresh browser evidence is needed:

```bash
ruby tools/batch_transform_tc.rb \
  --repair path/to/case.feature \
  --run-workdir /path/to/wabi-fix-uat \
  --cucumber-command 'bundle exec cucumber' \
  --playwright-flow PageExplore/odpt-automation-skill/Admin_GUI/flow_catalog/flows/flow.json \
  --playwright-replay-command 'project-playwright-replay --flow {flow} --report {report}' \
  --playwright-replay-mode each_attempt
```

The adapter must exit zero for a successful replay. When `{report}` is used, it
must write JSON with `schema_version`, `status`, `steps`, and `first_failure`.
The runner stores a redacted replay log/report and tells the repair model to
locate the first divergence between Playwright and Cucumber. Playwright
locators, browser JavaScript, dynamic UUIDs, credentials, and direct
`qaGridApi` mutations are never copied into Feature steps. Playwright and
Cucumber are serialized because Admin flows may mutate the same ODP state.

The repair model works in a disposable staging worktree and only the staged
Feature is editable. After hash/path auditing, the runner atomically promotes
that Feature back to the runtime checkout. The staging process inherits the
provider configuration from `ProjectA/opencode.jsonc` (or `OPENCODE_CONFIG`) so
the configured model endpoint remains available while runtime files stay
outside the model's readable worktree.

### 9.3 Binary/FIX 错误定位

若日志包含明确字段，例如：

```text
OrderRejectReason=2038
Side=1
```

runner 会分别查询错误码和 FIX 枚举。若日志只有通用 `reason_code=18`，必须给出业务类别：

```bash
--error-category ORDER_REJECT
```

同一个数字在 Order、Amend、Cancel、Quote 等类别中可能有不同含义，不能只按数字做全局解释。

## 10. opencode 配置与安全边界

转换命令默认是：

```text
opencode run --pure --thinking
```

The default model is the internal Ollama model
`ollama/DeepSeek-V4-Flash-INT8`. Select any
provider-qualified model printed by `opencode models` with:

```bash
--model provider/model
```

For example, `--model ollama/DeepSeek-V4-Flash-INT8`. The environment
equivalent is `OPENCODE_MODEL`. This setting is forwarded consistently to
conversion, diagnosis, and repair; an explicit `--model` or `-m` already in a
custom command takes precedence.

`opencode models` only lists models resolved from configuration; it does not
verify that the provider endpoint is reachable. For the internal Ollama model,
check the configured `/v1/models` endpoint from the tester project before
starting a repair. If the API key is provided by an environment variable,
allowlist only that variable with `OPENCODE_ENV_ALLOWLIST`.

自定义转换命令：

```bash
export OPENCODE_CONVERSION_COMMAND='opencode run --pure --thinking'
```

批处理拒绝 `--auto` 和 `--dangerously-skip-permissions`。转换子进程不会继承 ODP 凭据。只有本地 provider 确实需要额外变量时，才显式加入：

```bash
export OPENCODE_ENV_ALLOWLIST='PROVIDER_REQUIRED_VARIABLE'
```

Feature 失败诊断命令与转换命令分开配置：

```bash
export OPENCODE_DEBUG_CMD='opencode run --pure --thinking'
```

或：

```bash
--diagnose-opencode-command 'opencode run --pure --thinking'
```

不要把 ODP 密码、Cookie 或业务 token 加入 opencode allowlist。

## 11. 索引使用和健康检查

索引是随 `PageExplore/` 一起交付的只读知识入口。常用索引如下：

| 索引 | 用途 |
|---|---|
| `odpt-automation-skill/FIXODPMSG_Index.json` | FIX 字段和枚举 wire value |
| `odpt-automation-skill/Error_Code_Index.json` | 按类别查询错误码含义 |
| `pageExplore/qaGrid/qaGridApi_Index.json` | Grid key、方法和字段结构 |
| `pageExplore/pages/INDEX.json` | 页面路由和 profile 元数据 |
| `odpt-automation-skill/Step_Index.json` | 查找可用 Gherkin Step |
| `odp-docs/INDEX.json` | 选择 ODP Functional Specification |
| `odpt-automation-skill/Admin_GUI/flow_catalog/INDEX.json` | 已审核 Admin 流程 |
| `odpt-automation-skill/repair_experience/INDEX.json` | 修复经验状态和证据 |

测试人员通常不需要重建这些索引。只需在交付包目录执行一致性检查：

```bash
python3 tools/build_pages_index.py --check
python3 tools/build_admin_flow_catalog.py --check
python3 tools/build_repair_experience_catalog.py --check
```

索引重建属于 PageExplore 维护流程，不是测试案例转换或 Feature 修复的
常规步骤。`repair_experience/inbox/` 中的候选必须人工复核，只有
`status=verified` 且 `reuse.safe_to_reuse=true` 的条目才会作为正向指导。

## 12. 发布前检查

```bash
ruby -c tools/run_feature_debug.rb
ruby -c tools/batch_transform_tc.rb

python3 tools/build_error_code_index.py --check
python3 tools/build_pages_index.py --check
python3 tools/build_admin_flow_catalog.py --check
python3 tools/build_repair_experience_catalog.py --check
```

再确认没有本地输出和凭据：

```bash
find . -type d \( \
  -name '__pycache__' -o \
  -name 'run_reports' -o \
  -name 'feature_run_reports' -o \
  -name 'outputs' \
\) -print

find . -type f \( \
  -name '.env' -o \
  -name '*.pyc' -o \
  -name '*.p12' -o \
  -name '*.pfx' -o \
  -name '*.pem' -o \
  -name '*.key' \
\) -print
```

## 13. 安全和审核规则

- 不把 `.env`、凭据、Cookie、Authorization header、私钥放入包或 flow catalog；
- `@REVIEW` 默认不能执行；只有人工确认后才能使用 `--allow-review`；
- `observed`/`inferred` Admin flow 默认不能自动复用；
- runner 单次执行 Feature，不因超时自动重跑，避免重复下单或重复修改 Admin 数据；
- 报告、日志和诊断文件默认使用 `0600`；批处理生成目录会收紧为 `0700`；
- runner 拒绝让 report/log/diagnosis 与输入 Feature 指向同一文件；
- Cucumber 输出在完整有界捕获后统一脱敏，防止分块日志绕过过滤；
- `FEATURE_MAX_OUTPUT_BYTES` 控制 Feature 输出上限，默认 8 MiB；
- `OPENCODE_MAX_OUTPUT_BYTES` 控制转换输出上限，默认 8 MiB；
- `uat/` 中的 Feature/Step 快照以及 `pageExplore/evidence/` 中的页面和
  qaGrid 原始证据可能包含内部标识或测试数据，按内部资料管理，不要发送到非受控环境。

## 14. 常见问题

### 14.1 `blocked_review`

Feature 带有 `@REVIEW`。先查看转换报告，解决 unknown Step、未验证证据和 review reason。只有明确接受未解决风险时才传 `--allow-review`。

### 14.2 找不到生成的 Feature

批处理只会自动运行本轮新生成且可唯一定位的 Feature。旧文件即使存在，也不会被辅助转换模式误当成本轮输出。检查目标目录、文件名和转换日志。

### 14.3 Admin flow 未被选中

检查：

- YAML case ID/别名是否与 manifest 对应；
- `--admin-flow-dir` 是否正确；
- manifest 是否为 `verified`；
- `reuse.safe_to_reuse` 是否为 `true`；
- 是否存在多个歧义匹配。

### 14.4 Cucumber 命令不存在或 Step 不匹配

当前 `PageExplore` 不是完整运行时。确认 `--workdir` 指向目标 checkout，并在该目录内确认 Bundler、Cucumber、WABI Gem 和自定义 Step 已安装。

### 14.5 错误码找到多个解释

增加 `--error-category`。不要根据全局数字匹配直接修改断言。

### 14.6 页面 Grid key 数量不是 1

页面可能同时存在主表、子表或 dialog Grid。读取对应 page profile 和 qaGrid 索引，按 `keyPattern`/活动容器筛选；不要选择 `Object.keys(...)[0]`。

### 14.7 转换或运行输出过大

按需要调低或调高：

```bash
export OPENCODE_MAX_OUTPUT_BYTES=8388608
export FEATURE_MAX_OUTPUT_BYTES=8388608
```

超出部分会标记为 truncated。

## 15. 打包和迁移

交付给测试人员时，压缩包顶层目录应命名为 `PageExplore/`，并由测试人员
放入 `ProjectA/` 根目录。下面命令假设维护者的源码目录仍叫
`uat_skill/`；打包时用 `--transform` 将顶层名称改为 `PageExplore/`：

```bash
tar \
  --exclude='uat_skill/.env' \
  --exclude='uat_skill/.git' \
  --exclude='uat_skill/UAT_SKILL使用手册.md' \
  --exclude='uat_skill/features' \
  --exclude='uat_skill/resource' \
  --exclude='uat_skill/ai' \
  --exclude='uat_skill/automation' \
  --exclude='uat_skill/uat' \
  --exclude='uat_skill/artifacts' \
  --exclude='uat_skill/screenshots' \
  --exclude='uat_skill/logs' \
  --exclude='uat_skill/bigmapVariable' \
  --exclude='uat_skill/outputs' \
  --exclude='uat_skill/temp' \
  --exclude='uat_skill/**/run_reports' \
  --exclude='uat_skill/**/feature_run_reports' \
  --exclude='uat_skill/odpt-automation-skill/repair_experience/inbox' \
  --exclude='uat_skill/**/__pycache__' \
  --exclude='uat_skill/**/*.pyc' \
  --transform='s,^uat_skill,PageExplore,' \
  -czf /home/weipeng/hkcode/PageExplore-YYYYMMDD.tar.gz \
  uat_skill

sha256sum /home/weipeng/hkcode/PageExplore-YYYYMMDD.tar.gz \
  > /home/weipeng/hkcode/PageExplore-YYYYMMDD.tar.gz.sha256
```

迁移后验证：

```bash
sha256sum -c PageExplore-YYYYMMDD.tar.gz.sha256
tar -tzf PageExplore-YYYYMMDD.tar.gz | sed -n '1,40p'
```

压缩包应包含 `pageExplore/` 知识库、`tools/`、Skill、生成索引、语义 flow catalog、已恢复的 `odp-docs/` 和必要的参考快照；不应包含运行时 `features/`、`resource/`、原始 `uat/` 快照、`.env`、浏览器 trace、运行报告、缓存或临时诊断文件。运行时步骤和数据由 `ProjectA/features/`、`ProjectA/resource/` 提供。

## 16. 命令帮助

```bash
ruby tools/batch_transform_tc.rb --help
ruby tools/run_feature_debug.rb --help
python3 tools/admin_feature_converter.py --help
python3 tools/find_admin_flow.py --help
python3 tools/build_admin_flow_catalog.py --help
python3 tools/build_repair_experience_catalog.py --help
python3 tools/build_fix_message_index.py --help
python3 tools/build_error_code_index.py --help
python3 tools/build_grid_api_index.py --help
python3 tools/build_step_index.py --help
python3 tools/build_pages_index.py --help
```
