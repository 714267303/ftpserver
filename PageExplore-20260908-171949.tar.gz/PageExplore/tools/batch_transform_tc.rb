#!/usr/bin/env ruby
# frozen_string_literal: true

# Tool: Batch Transform Excel Test Cases through the seven-stage UAT pipeline
# Usage: ruby tools/batch_transform_tc.rb [excel_folder] [yaml_folder] [target_dir] [options]
#
# The Admin/Hybrid repair path executes these stages in the required order:
#   2. Excel -> YAML
#   3. inspect and classify the execution channel
#   1. launch Playwright MCP, validate a missing Admin path, then roll it back
#   4. generate a standalone Admin Feature from the MCP semantic flow
#   5. compare/run/repair that Admin Feature independently
#   6. promote the Admin flow only from the independent Admin result
#   7. for Hybrid, generate separate non-Admin lifecycle Feature(s) and an
#      execution-flow manifest; a cross-day flow stops at its external batch
#      gate and is resumed explicitly after that gate has completed
# Binary-only conversion keeps the same entry point but skips the Admin stage.
#
# Usage Examples:
#   ruby tools/batch_transform_tc.rb
#   ruby tools/batch_transform_tc.rb ./excel_tcs ./yaml_tcs features/test_case/Error_Cancel_Adj_Trade/AI
#   ruby tools/batch_transform_tc.rb ./excel_tcs ./yaml_tcs ./features --repair
#   ruby tools/batch_transform_tc.rb --repair features/test_case/CASE/case.feature --run-workdir /path/to/uat-checkout

require 'fileutils'
require 'digest'
require 'json'
require 'open3'
require 'optparse'
require 'rbconfig'
require 'shellwords'
require 'securerandom'
require 'time'
require 'uri'

# Resolve bundled tools from the checkout containing this script.  The
# historical repository stores skills under ``skills/`` while this portable
# snapshot stores them beside ``tools/``; both layouts are supported.
SCRIPT_ROOT = File.expand_path('..', __dir__)
BATCH_TRANSFORM_ENTRYPOINT = File.expand_path(__FILE__)
# OpenCode expects the provider-qualified name returned by `opencode models`.
# The tester checkout uses its configured internal Ollama endpoint by default.
# Keep the default in one place so conversion, diagnosis, and repair use the
# same model unless an operator explicitly overrides it.
DEFAULT_OPENCODE_MODEL = begin
  configured_model = ENV.fetch('OPENCODE_MODEL', 'ollama/DeepSeek-V4-Flash-INT8').to_s.strip
  configured_model.empty? ? 'ollama/DeepSeek-V4-Flash-INT8' : configured_model
end
# A legacy checkout is an explicit compatibility opt-in.  It must never win
# over the PageExplore tree copied into the test project's own checkout.
LEGACY_REPO_ROOT = ENV.fetch('ODP_LEGACY_REPO_ROOT', '').to_s.strip
PAGE_EXPLORE_ROOT = File.expand_path(
  ENV.fetch('PAGEEXPLORE_ROOT', File.join(SCRIPT_ROOT, 'pageExplore'))
)

def optional_legacy_path(*parts)
  return nil if LEGACY_REPO_ROOT.empty?

  File.join(LEGACY_REPO_ROOT, *parts)
end

def first_existing_path(paths, directory: false)
  paths.find do |path|
    directory ? File.directory?(path) : File.file?(path)
  end
end

def bundled_skill_path(name)
  roots = [
    File.join(SCRIPT_ROOT, 'skills'),
    SCRIPT_ROOT,
    optional_legacy_path('skills'),
    LEGACY_REPO_ROOT.empty? ? nil : LEGACY_REPO_ROOT
  ]
  roots = roots.compact
  first_existing_path(roots.map { |root| File.join(root, name) }, directory: true) ||
    File.join(SCRIPT_ROOT, name)
end

DEFAULT_ADMIN_CONVERTER = first_existing_path([
  File.join(SCRIPT_ROOT, 'tools', 'admin_feature_converter.py'),
  optional_legacy_path('tools', 'admin_feature_converter.py')
].compact) || File.join(SCRIPT_ROOT, 'tools', 'admin_feature_converter.py')
DEFAULT_STEP_INDEX = first_existing_path([
  File.join(SCRIPT_ROOT, 'skills', 'odpt-automation-skill', 'Step_Index.json'),
  File.join(SCRIPT_ROOT, 'odpt-automation-skill', 'Step_Index.json'),
  optional_legacy_path('skills', 'odpt-automation-skill', 'Step_Index.json'),
  optional_legacy_path('odpt-automation-skill', 'Step_Index.json')
].compact) || File.join(SCRIPT_ROOT, 'odpt-automation-skill', 'Step_Index.json')
DEFAULT_ODP_DOC_INDEX = first_existing_path([
  File.join(SCRIPT_ROOT, 'odp-docs', 'INDEX.json'),
  optional_legacy_path('odp-docs', 'INDEX.json')
].compact) || File.join(SCRIPT_ROOT, 'odp-docs', 'INDEX.json')
DEFAULT_FEATURE_RUNNER = first_existing_path([
  File.join(SCRIPT_ROOT, 'tools', 'run_feature_debug.rb'),
  optional_legacy_path('tools', 'run_feature_debug.rb')
].compact) || File.join(SCRIPT_ROOT, 'tools', 'run_feature_debug.rb')
DEFAULT_ADMIN_FLOW_DIR = File.join(
  ENV.fetch('AUTO_SKILL', bundled_skill_path('odpt-automation-skill')),
  'Admin_GUI', 'flow_catalog', 'flows'
)
DEFAULT_ADMIN_EVIDENCE_ROOT = File.join(Dir.pwd, 'outputs', 'admin')

# --- Configuration ---
# The first three positional arguments are intentionally unchanged for
# compatibility with existing internal invocations.
batch_options = {
  admin_flow_dir: ENV.fetch('ADMIN_FLOW_DIR', DEFAULT_ADMIN_FLOW_DIR),
  binary_base_dir: ENV['BINARY_BASE_DIR'],
  channel: ENV.fetch('TRANSFORM_CHANNEL', 'auto'),
  converter_mode: ENV.fetch('ADMIN_CONVERTER_MODE', 'assisted'),
  converter: ENV.fetch('ADMIN_CONVERTER', DEFAULT_ADMIN_CONVERTER),
  excel_yaml_mode: ENV.fetch('EXCEL_YAML_MODE', 'assisted'),
  yaml_only: ENV.fetch('TC_BATCH_YAML_ONLY', '0') == '1',
  model: ENV.fetch('OPENCODE_MODEL', DEFAULT_OPENCODE_MODEL).to_s.strip,
  odp_doc_index: ENV.fetch('ODP_DOC_INDEX', DEFAULT_ODP_DOC_INDEX),
  opencode_command: ENV.fetch('OPENCODE_CONVERSION_COMMAND', 'opencode run --pure --thinking'),
  diagnose_command: ENV['OPENCODE_DEBUG_CMD'],
  opencode_env_allowlist: ENV.fetch('OPENCODE_ENV_ALLOWLIST', ''),
  step_index: ENV.fetch('STEP_INDEX', DEFAULT_STEP_INDEX),
  python: ENV.fetch('PYTHON_BIN', 'python3'),
  strict_admin: ENV.fetch('STRICT_ADMIN_CONVERSION', '0') == '1',
  run_generated: ENV.fetch('RUN_GENERATED_FEATURES', '0') == '1',
  debug_generated: ENV.fetch('DEBUG_GENERATED_FEATURES', '0') == '1',
  repair_generated: ENV.fetch('REPAIR_GENERATED_FEATURES', '0') == '1',
  repair_feature: ENV['REPAIR_FEATURE'],
  repair_attempts: ENV.fetch('FEATURE_REPAIR_ATTEMPTS', '0'),
  repair_experience_dir: ENV['FEATURE_REPAIR_EXPERIENCE_DIR'],
  repair_experience_index: ENV['FEATURE_REPAIR_EXPERIENCE_INDEX'],
  debug_feature: ENV['DEBUG_FEATURE'],
  run_feature: ENV['RUN_FEATURE'],
  run_execution_flow: ENV['RUN_EXECUTION_FLOW'],
  completed_gates: ENV.fetch('COMPLETED_EXECUTION_GATES', '').split(',').map(&:strip).reject(&:empty?),
  repair_command: ENV['OPENCODE_REPAIR_CMD'] || ENV['OPENCODE_DEBUG_CMD'],
  feature_runner: ENV.fetch('FEATURE_RUNNER', DEFAULT_FEATURE_RUNNER),
  run_report_dir: ENV['FEATURE_RUN_REPORT_DIR'],
  cucumber_command: ENV['CUCUMBER_CMD'],
  cucumber_args: [],
  run_workdir: ENV['UAT_RUNTIME_ROOT'],
  feature_timeout: ENV.fetch('FEATURE_TIMEOUT_SECONDS', '1800'),
  binary_debug: ENV.fetch('FEATURE_BINARY_DEBUG', '0') == '1',
  playwright_flow: ENV['PLAYWRIGHT_FLOW'],
  playwright_replay_command: ENV['PLAYWRIGHT_REPLAY_COMMAND'],
  playwright_bindings: ENV['PLAYWRIGHT_BINDINGS'],
  allow_unverified_playwright_flow: ENV.fetch('ALLOW_UNVERIFIED_PLAYWRIGHT_FLOW', '0') == '1',
  playwright_workdir: ENV['PLAYWRIGHT_WORKDIR'],
  playwright_replay_mode: ENV.fetch('PLAYWRIGHT_REPLAY_MODE', 'on_failure'),
  playwright_timeout: ENV.fetch('PLAYWRIGHT_TIMEOUT_SECONDS', '900'),
  data_preflight: ENV.fetch('FEATURE_DATA_PREFLIGHT', 'auto'),
  allow_unresolved_data: ENV.fetch('ALLOW_UNRESOLVED_DATA', '0') == '1',
  preflight_only: ENV.fetch('FEATURE_PREFLIGHT_ONLY', '0') == '1',
  error_categories: ENV.fetch('FEATURE_ERROR_CATEGORIES', '').split(',').map(&:strip).reject(&:empty?),
  allow_review: ENV.fetch('ALLOW_REVIEW_FEATURES', '0') == '1',
  allow_unverified_admin_flow: ENV.fetch('ALLOW_UNVERIFIED_ADMIN_FLOW', '0') == '1',
  dry_run: ENV.fetch('FEATURE_DRY_RUN', '0') == '1',
  # A missing Admin flow is explored automatically only for an explicit
  # generation-repair run.  Ordinary conversion remains side-effect free;
  # --admin-explore opts into the browser workflow for other run modes.
  admin_explore_mode: ENV.fetch('ADMIN_EXPLORE_MISSING_FLOW', 'auto'),
  admin_explore_command: ENV['ADMIN_EXPLORE_COMMAND'],
  admin_explore_timeout: ENV.fetch('ADMIN_EXPLORE_TIMEOUT_SECONDS', '1800'),
  admin_evidence_root: ENV.fetch('ADMIN_EVIDENCE_ROOT', DEFAULT_ADMIN_EVIDENCE_ROOT),
  # This slot is only the explicit CLI override. ODP_URL from the process
  # environment is resolved later alongside the supported dotenv locations so
  # an inherited placeholder cannot hide a valid runtime .env file.
  odp_url: nil,
  playwright_mcp_command: ENV['PLAYWRIGHT_MCP_COMMAND'],
  playwright_mcp_secrets: ENV['PLAYWRIGHT_MCP_SECRETS_FILE'],
  playwright_mcp_output_dir: ENV['PLAYWRIGHT_MCP_OUTPUT_DIR'],
  playwright_mcp_browser: ENV['PLAYWRIGHT_MCP_BROWSER_EXECUTABLE'],
  playwright_mcp_node: ENV['PLAYWRIGHT_MCP_NODE'],
  playwright_mcp_cli: ENV['PLAYWRIGHT_MCP_CLI'],
  playwright_mcp_headless: ENV.fetch('PLAYWRIGHT_MCP_HEADLESS', '0') == '1',
  verbose_model_output: ENV.fetch('TC_BATCH_VERBOSE_MODEL_OUTPUT', '0') == '1',
  progress_interval: ENV.fetch('TC_BATCH_PROGRESS_INTERVAL_SECONDS', '15')
}
repair_command_explicit = !ENV['OPENCODE_REPAIR_CMD'].to_s.strip.empty?

option_parser = OptionParser.new do |opts|
  opts.banner = 'Usage: ruby tools/batch_transform_tc.rb [excel_folder] [yaml_folder] [target_dir] [options]'
  opts.on('--admin-flow-dir DIR', 'Directory containing reviewed *.json Admin flows (default: bundled catalog)') do |value|
    batch_options[:admin_flow_dir] = value
  end
  opts.on('--binary-base-dir DIR', 'Directory containing independent non-Admin Features for Hybrid continuation') do |value|
    batch_options[:binary_base_dir] = value
  end
  opts.on('--channel MODE', %w[auto binary admin hybrid], 'Transform channel (default: auto)') do |value|
    batch_options[:channel] = value
  end
  opts.on('--deterministic-admin', 'Use the local Admin converter when a manifest is available') do
    batch_options[:converter_mode] = 'deterministic'
  end
  opts.on('--admin-converter PATH', 'Admin converter executable/script path') do |value|
    batch_options[:converter] = value
  end
  opts.on('--excel-yaml-mode MODE', %w[assisted deterministic], 'Excel-to-YAML mode (default: assisted)') do |value|
    batch_options[:excel_yaml_mode] = value
  end
  opts.on('--yaml-only', 'Stop after Excel-to-YAML conversion') do
    batch_options[:yaml_only] = true
  end
  opts.on('--model PROVIDER/MODEL', "OpenCode model (default: #{DEFAULT_OPENCODE_MODEL})") do |value|
    batch_options[:model] = value
  end
  opts.on('--odp-doc-index PATH', 'ODP functional-specification index JSON') do |value|
    batch_options[:odp_doc_index] = value
  end
  opts.on('--opencode-command CMD', 'Safe opencode conversion command (prompt is appended or replaces {prompt})') do |value|
    batch_options[:opencode_command] = value
    batch_options[:repair_command] = value unless repair_command_explicit
  end
  opts.on('--opencode-env-allowlist NAMES', 'Comma-separated extra environment names for opencode conversion') do |value|
    batch_options[:opencode_env_allowlist] = value
  end
  opts.on('--diagnose-opencode-command CMD', 'opencode command forwarded for Feature failure diagnosis') do |value|
    batch_options[:diagnose_command] = value
  end
  opts.on('--repair-opencode-command CMD', 'opencode command forwarded for Feature repair') do |value|
    batch_options[:repair_command] = value
    repair_command_explicit = true
  end
  opts.on('--step-index PATH', 'Machine-readable UAT Step_Index.json') do |value|
    batch_options[:step_index] = value
  end
  opts.on('--strict-admin', 'Fail deterministic Admin conversion on review reasons') do
    batch_options[:strict_admin] = true
  end
  opts.on('--run-generated', 'Run each successfully generated Feature with the local runner') do
    batch_options[:run_generated] = true
  end
  opts.on('--debug-generated', 'Run generated Features and diagnose failures with opencode') do
    batch_options[:debug_generated] = true
    batch_options[:run_generated] = true
  end
  opts.on('--repair [PATH]', 'Repair PATH; without PATH, repair each generated Feature until passed') do |value|
    if value && !value.to_s.strip.empty?
      batch_options[:repair_feature] = value
    else
      batch_options[:repair_generated] = true
      batch_options[:run_generated] = true
    end
  end
  opts.on('--repair-generated', 'Repair each generated Feature and rerun until passed') do
    batch_options[:repair_generated] = true
    batch_options[:run_generated] = true
  end
  opts.on('--repair-attempts N', Integer, 'Maximum repair/rerun cycles; 0 means until passed (default: 0)') do |value|
    batch_options[:repair_attempts] = value.to_s
  end
  opts.on('--repair-experience-dir DIR', 'Directory for redacted repair candidates') do |value|
    batch_options[:repair_experience_dir] = value
  end
  opts.on('--repair-experience-index PATH', 'Verified repair-experience index JSON') do |value|
    batch_options[:repair_experience_index] = value
  end
  opts.on('--run-feature PATH', 'Run one existing Feature without model diagnosis') do |value|
    batch_options[:run_feature] = value
  end
  opts.on('--run-execution-flow PATH', 'Resume a generated *.execution-flow.json in declared stage order') do |value|
    batch_options[:run_execution_flow] = value
    batch_options[:run_generated] = true
  end
  opts.on('--complete-gate ID', 'Acknowledge a completed external execution-flow gate (repeatable)') do |value|
    batch_options[:completed_gates] << value
  end
  opts.on('--debug-feature PATH', 'Run one existing Feature and diagnose failures with opencode') do |value|
    batch_options[:debug_feature] = value
  end
  opts.on('--feature-runner PATH', 'Feature runner script (default: tools/run_feature_debug.rb)') do |value|
    batch_options[:feature_runner] = value
  end
  opts.on('--run-report-dir DIR', 'Directory for generated Feature run reports') do |value|
    batch_options[:run_report_dir] = value
  end
  opts.on('--cucumber-command CMD', 'Cucumber command forwarded to the Feature runner') do |value|
    batch_options[:cucumber_command] = value
  end
  opts.on('--cucumber-arg ARG', 'Additional Cucumber argument forwarded to the runner (repeatable)') do |value|
    batch_options[:cucumber_args] << value
  end
  opts.on('--run-workdir DIR', 'Runtime checkout working directory forwarded to runner') do |value|
    batch_options[:run_workdir] = value
  end
  opts.on('--feature-timeout SECONDS', Integer, 'Feature execution timeout') do |value|
    batch_options[:feature_timeout] = value.to_s
  end
  opts.on('--binary-debug', 'Enable low-level WABI/FIX debug output for Feature runs') do
    batch_options[:binary_debug] = true
  end
  opts.on('--playwright-flow PATH', 'Playwright flow/evidence manifest used during Web repair') do |value|
    batch_options[:playwright_flow] = value
  end
  opts.on('--playwright-replay-command CMD', 'Command that replays the Playwright flow; supports {flow}, {report}, {feature}, {attempt}, {bindings}') do |value|
    batch_options[:playwright_replay_command] = value
  end
  opts.on('--playwright-bindings PATH', 'Private JSON value bindings passed to a Playwright adapter as {bindings}') do |value|
    batch_options[:playwright_bindings] = value
  end
  opts.on('--allow-unverified-playwright-flow', 'Allow replay of an unverified flow (non-authoritative)') do
    batch_options[:allow_unverified_playwright_flow] = true
  end
  opts.on('--playwright-workdir DIR', 'Working directory for the Playwright replay command') do |value|
    batch_options[:playwright_workdir] = value
  end
  opts.on('--playwright-replay-mode MODE', %w[off before_feature on_failure each_attempt], 'Playwright replay timing (default: on_failure)') do |value|
    batch_options[:playwright_replay_mode] = value
  end
  opts.on('--playwright-timeout SECONDS', Integer, 'Timeout for a Playwright replay') do |value|
    batch_options[:playwright_timeout] = value.to_s
  end
  opts.on('--data-preflight MODE', %w[auto off report block], 'Runtime alias/placeholder preflight mode') do |value|
    batch_options[:data_preflight] = value
  end
  opts.on('--allow-unresolved-data', 'Run despite unresolved runtime aliases') do
    batch_options[:allow_unresolved_data] = true
    batch_options[:data_preflight] = 'report'
  end
  opts.on('--preflight-only', 'Write data readiness reports without running Cucumber or OpenCode') do
    batch_options[:preflight_only] = true
  end
  opts.on('--error-category CATEGORY_ID', 'Category-scoped error lookup forwarded to runner (repeatable)') do |value|
    batch_options[:error_categories] << value
  end
  opts.on('--dry-run', 'Pass --dry-run to the Feature runner (execution mode)') do
    batch_options[:dry_run] = true
  end
  opts.on('--allow-review', 'Allow execution of Features carrying @REVIEW') do
    batch_options[:allow_review] = true
  end
  opts.on('--allow-unverified-admin-flow', 'Allow observed/inferred Admin manifests explicitly') do
    batch_options[:allow_unverified_admin_flow] = true
  end
  opts.on('--admin-explore', 'Explore a missing Admin flow through Playwright MCP') do
    batch_options[:admin_explore_mode] = 'always'
  end
  opts.on('--no-admin-explore', 'Do not launch Playwright MCP for a missing Admin flow') do
    batch_options[:admin_explore_mode] = 'off'
  end
  opts.on('--admin-explore-command CMD', 'OpenCode/MCP exploration command (prompt replaces {prompt})') do |value|
    batch_options[:admin_explore_command] = value
  end
  opts.on('--admin-explore-timeout SECONDS', Integer, 'Silent timeout for an Admin exploration') do |value|
    batch_options[:admin_explore_timeout] = value.to_s
  end
  opts.on('--admin-evidence-root DIR', 'Root directory for isolated Admin MCP evidence') do |value|
    batch_options[:admin_evidence_root] = value
  end
  opts.on('--odp-url URL', 'ODP browser base URL (overrides ODP_URL/.env; non-secret)') do |value|
    batch_options[:odp_url] = value
  end
  opts.on('--playwright-mcp-command CMD', 'Playwright MCP server command used for automatic exploration') do |value|
    batch_options[:playwright_mcp_command] = value
  end
  opts.on('--playwright-mcp-secrets PATH', 'dotenv file passed to Playwright MCP as --secrets') do |value|
    batch_options[:playwright_mcp_secrets] = value
  end
  opts.on('--playwright-mcp-output-dir DIR', 'Base output directory for Playwright MCP artifacts') do |value|
    batch_options[:playwright_mcp_output_dir] = value
  end
  opts.on('--playwright-mcp-node PATH', 'Node executable for the offline Playwright MCP package') do |value|
    batch_options[:playwright_mcp_node] = value
  end
  opts.on('--playwright-mcp-cli PATH', 'Offline @playwright/mcp cli.js path') do |value|
    batch_options[:playwright_mcp_cli] = value
  end
  opts.on('--playwright-mcp-browser PATH', 'Chromium/Chrome executable for Playwright MCP') do |value|
    batch_options[:playwright_mcp_browser] = value
  end
  opts.on('--playwright-mcp-headless', 'Run automatic Playwright exploration headless') do
    batch_options[:playwright_mcp_headless] = true
  end
  opts.on('--playwright-mcp-headed', 'Run automatic Playwright exploration headed (default)') do
    batch_options[:playwright_mcp_headless] = false
  end
  opts.on('--verbose-model-output', 'Print full redacted child/model event output (default: compact)') do
    batch_options[:verbose_model_output] = true
  end
  opts.on('--progress-interval SECONDS', Integer, 'Compact-mode progress interval (default: 15)') do |value|
    batch_options[:progress_interval] = value.to_s
  end
  opts.on('-h', '--help', 'Show this help') do
    puts opts
    exit 0
  end
end

begin
  option_parser.parse!(ARGV)
rescue OptionParser::ParseError => e
  warn e.message
  warn option_parser
  exit 2
end

# ``--repair`` has an optional Feature argument for the existing-Feature mode.
# If it appears before the three positional directories, OptionParser consumes
# the first directory as that optional argument. Recover that unambiguous
# directory form so both ``--repair DIR DIR DIR`` and the documented trailing
# no-value form select generation repair rather than an invalid Feature path.
if batch_options[:repair_feature] &&
   !batch_options[:repair_feature].to_s.match?(/\.feature\z/i) &&
   ARGV.length >= 2
  ARGV.unshift(batch_options[:repair_feature])
  batch_options[:repair_feature] = nil
  batch_options[:repair_generated] = true
  batch_options[:run_generated] = true
end

# The environment-variable forms must have the same implications as the CLI
# forms: diagnosis and repair both require execution of generated Features.
batch_options[:run_generated] = true if batch_options[:debug_generated] ||
                                        batch_options[:repair_generated] ||
                                        batch_options[:run_execution_flow]

unless %w[auto binary admin hybrid].include?(batch_options[:channel])
  warn "Invalid TRANSFORM_CHANNEL: #{batch_options[:channel]}"
  exit 2
end
unless %w[assisted deterministic].include?(batch_options[:converter_mode])
  warn "Invalid ADMIN_CONVERTER_MODE: #{batch_options[:converter_mode]}"
  exit 2
end
unless %w[assisted deterministic].include?(batch_options[:excel_yaml_mode])
  warn "Invalid EXCEL_YAML_MODE: #{batch_options[:excel_yaml_mode]}"
  exit 2
end

feature_modes = %i[repair_feature debug_feature run_feature].select { |key| batch_options[key] }
if feature_modes.length > 1
  warn 'Use only one of --repair, --debug-feature, and --run-feature'
  exit 2
end
if batch_options[:repair_generated] && !feature_modes.empty?
  warn '--repair (without PATH) cannot be combined with --repair PATH, --debug-feature, or --run-feature'
  exit 2
end
if batch_options[:run_execution_flow] && !feature_modes.empty?
  warn '--run-execution-flow cannot be combined with --repair PATH, --debug-feature, or --run-feature'
  exit 2
end
if !batch_options[:completed_gates].empty? && !batch_options[:run_execution_flow]
  warn '--complete-gate requires --run-execution-flow'
  exit 2
end
if batch_options[:repair_generated] && batch_options[:debug_generated]
  warn '--repair cannot be combined with --debug-generated; repair already diagnoses through the repair runner'
  exit 2
end
begin
  repair_attempts_value = Integer(batch_options[:repair_attempts].to_s, 10)
rescue ArgumentError
  warn '--repair-attempts must be an integer'
  exit 2
end
if repair_attempts_value.negative?
  warn '--repair-attempts must be zero or positive'
  exit 2
end
unless %w[off before_feature on_failure each_attempt].include?(batch_options[:playwright_replay_mode].to_s)
  warn "Invalid PLAYWRIGHT_REPLAY_MODE: #{batch_options[:playwright_replay_mode]}"
  exit 2
end
unless %w[auto off report block].include?(batch_options[:data_preflight].to_s)
  warn "Invalid FEATURE_DATA_PREFLIGHT: #{batch_options[:data_preflight]}"
  exit 2
end
unless %w[auto always off].include?(batch_options[:admin_explore_mode].to_s)
  warn "Invalid ADMIN_EXPLORE_MISSING_FLOW: #{batch_options[:admin_explore_mode]} (use auto, always, or off)"
  exit 2
end
begin
  admin_explore_timeout_value = Integer(batch_options[:admin_explore_timeout].to_s, 10)
rescue ArgumentError
  warn '--admin-explore-timeout must be an integer'
  exit 2
end
if admin_explore_timeout_value <= 0
  warn '--admin-explore-timeout must be positive'
  exit 2
end
begin
  playwright_timeout_value = Integer(batch_options[:playwright_timeout].to_s, 10)
rescue ArgumentError
  warn '--playwright-timeout must be an integer'
  exit 2
end
if playwright_timeout_value <= 0
  warn '--playwright-timeout must be positive'
  exit 2
end
begin
  progress_interval_value = Integer(batch_options[:progress_interval].to_s, 10)
rescue ArgumentError
  warn '--progress-interval must be an integer'
  exit 2
end
if progress_interval_value <= 0
  warn '--progress-interval must be positive'
  exit 2
end
if !batch_options[:playwright_replay_command].to_s.strip.empty? &&
   batch_options[:playwright_flow].to_s.strip.empty? &&
   (feature_modes.any? || batch_options[:admin_flow_dir].to_s.strip.empty?)
  warn '--playwright-replay-command requires --playwright-flow, or --admin-flow-dir during conversion'
  exit 2
end
if !batch_options[:playwright_bindings].to_s.strip.empty? &&
   batch_options[:playwright_replay_command].to_s.strip.empty?
  warn '--playwright-bindings requires --playwright-replay-command'
  exit 2
end
if !batch_options[:playwright_bindings].to_s.strip.empty? &&
   !batch_options[:playwright_replay_command].to_s.include?('{bindings}')
  warn '--playwright-replay-command must contain {bindings} when --playwright-bindings is supplied'
  exit 2
end

EXCEL_FOLDER = ARGV[0] || 'ai/TC/ODP17'
YAML_FOLDER  = ARGV[1] || File.join('ai/TC', File.basename(EXCEL_FOLDER), 'yaml')
TARGET_DIR   = ARGV[2] || 'features/test_case/Error_Cancel_Adj_Trade/AI'
ADMIN_FLOW_DIR = batch_options[:admin_flow_dir]
BINARY_BASE_DIR = batch_options[:binary_base_dir]
TRANSFORM_CHANNEL = batch_options[:channel]
ADMIN_CONVERTER_MODE = batch_options[:converter_mode]
ADMIN_CONVERTER = batch_options[:converter]
EXCEL_YAML_MODE = batch_options[:excel_yaml_mode]
YAML_ONLY = batch_options[:yaml_only]
OPENCODE_MODEL = batch_options[:model].to_s.strip.empty? ? DEFAULT_OPENCODE_MODEL : batch_options[:model].to_s.strip
ODP_DOC_INDEX = batch_options[:odp_doc_index].to_s.strip.empty? ? DEFAULT_ODP_DOC_INDEX : batch_options[:odp_doc_index]
OPENCODE_CONVERSION_COMMAND = batch_options[:opencode_command]
OPENCODE_DEBUG_COMMAND = batch_options[:diagnose_command]
OPENCODE_REPAIR_COMMAND = batch_options[:repair_command]
OPENCODE_ENV_ALLOWLIST = batch_options[:opencode_env_allowlist]
STEP_INDEX = batch_options[:step_index]
PYTHON_BIN = batch_options[:python]
STRICT_ADMIN_CONVERSION = batch_options[:strict_admin]
RUN_GENERATED = batch_options[:run_generated]
DEBUG_GENERATED = batch_options[:debug_generated]
REPAIR_FEATURE = batch_options[:repair_feature]
REPAIR_ATTEMPTS = repair_attempts_value
REPAIR_EXPERIENCE_DIR = batch_options[:repair_experience_dir]
REPAIR_EXPERIENCE_INDEX = batch_options[:repair_experience_index]
DEBUG_FEATURE = batch_options[:debug_feature]
RUN_FEATURE = batch_options[:run_feature]
RUN_EXECUTION_FLOW = batch_options[:run_execution_flow]
COMPLETED_EXECUTION_GATES = batch_options[:completed_gates].map(&:to_s).map(&:strip).reject(&:empty?).uniq.freeze
FEATURE_RUNNER = batch_options[:feature_runner]
FEATURE_RUN_REPORT_DIR = batch_options[:run_report_dir]
CUCUMBER_COMMAND = batch_options[:cucumber_command]
CUCUMBER_ARGS = batch_options[:cucumber_args].freeze
FEATURE_RUN_WORKDIR = batch_options[:run_workdir]
FEATURE_TIMEOUT = batch_options[:feature_timeout]
FEATURE_BINARY_DEBUG = batch_options[:binary_debug]
REPAIR_GENERATED = batch_options[:repair_generated]
PLAYWRIGHT_FLOW = batch_options[:playwright_flow]
PLAYWRIGHT_REPLAY_COMMAND = batch_options[:playwright_replay_command]
PLAYWRIGHT_BINDINGS = batch_options[:playwright_bindings]
ALLOW_UNVERIFIED_PLAYWRIGHT_FLOW = batch_options[:allow_unverified_playwright_flow]
PLAYWRIGHT_WORKDIR = batch_options[:playwright_workdir]
PLAYWRIGHT_REPLAY_MODE = batch_options[:playwright_replay_mode]
PLAYWRIGHT_TIMEOUT = playwright_timeout_value
DATA_PREFLIGHT = batch_options[:data_preflight]
ALLOW_UNRESOLVED_DATA = batch_options[:allow_unresolved_data]
PREFLIGHT_ONLY = batch_options[:preflight_only]
FEATURE_ERROR_CATEGORIES = batch_options[:error_categories].uniq.freeze
ALLOW_REVIEW_FEATURES = batch_options[:allow_review]
ALLOW_UNVERIFIED_ADMIN_FLOW = batch_options[:allow_unverified_admin_flow]
FEATURE_DRY_RUN = batch_options[:dry_run]
ADMIN_EXPLORE_MODE = batch_options[:admin_explore_mode].to_s
ADMIN_EXPLORE_COMMAND = batch_options[:admin_explore_command]
ADMIN_EXPLORE_TIMEOUT = admin_explore_timeout_value
ADMIN_EVIDENCE_ROOT = batch_options[:admin_evidence_root]
ODP_URL_OVERRIDE = batch_options[:odp_url]
PLAYWRIGHT_MCP_COMMAND = batch_options[:playwright_mcp_command]
PLAYWRIGHT_MCP_SECRETS = batch_options[:playwright_mcp_secrets]
PLAYWRIGHT_MCP_OUTPUT_DIR = batch_options[:playwright_mcp_output_dir]
PLAYWRIGHT_MCP_BROWSER = batch_options[:playwright_mcp_browser]
PLAYWRIGHT_MCP_NODE = batch_options[:playwright_mcp_node]
PLAYWRIGHT_MCP_CLI = batch_options[:playwright_mcp_cli]
PLAYWRIGHT_MCP_HEADLESS = batch_options[:playwright_mcp_headless]
VERBOSE_MODEL_OUTPUT = batch_options[:verbose_model_output]
MODEL_PROGRESS_INTERVAL = progress_interval_value

# Keep the historical internal defaults, but allow a checkout to override the
# skill roots without editing this script.  ``bundled_skill_path`` handles both
# ``skills/<name>`` and the portable snapshot's ``<name>`` layout.
EXCEL_YAML_SKILL = ENV.fetch(
  'EXCEL_YAML_SKILL',
  bundled_skill_path('odp-tc-excel-yaml-skill')
)
AUTO_SKILL = ENV.fetch(
  'AUTO_SKILL',
  bundled_skill_path('odpt-automation-skill')
)

EXCEL_EXTENSIONS = %w[.xlsx .xls].freeze
YAML_EXECUTION_CHANNELS = %w[
  admin_gui trading_gui binary_proxy clearing batch manual_or_unspecified
].freeze

# Colors for terminal output
GREEN  = "\e[32m"
YELLOW = "\e[33m"
CYAN   = "\e[36m"
RED    = "\e[31m"
BOLD   = "\e[1m"
RESET  = "\e[0m"

# Values registered here are used only for output redaction. Admin exploration
# may read the runtime dotenv file as a browser-login fallback, so the parent
# process must also scrub those exact values from OpenCode event JSON before a
# transcript or optional verbose terminal output is written.
BATCH_REDACTION_VALUES = []

# Functional implementation lives under tools/lib/batch_transform. Keeping
# this file as the stable launcher preserves all historical CLI invocations.
require_relative "lib/batch_transform"
BatchTransform.install!

if __FILE__ == $PROGRAM_NAME
  exit(main)
end
