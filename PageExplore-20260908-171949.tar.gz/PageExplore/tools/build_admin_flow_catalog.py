#!/usr/bin/env python3
"""Index reviewed, reusable Admin GUI flow manifests.

The catalog is intentionally separate from raw Playwright recordings.  A
catalog flow contains semantic UAT step text plus evidence pointers; dynamic
locators, browser JavaScript, credentials, and UUIDs belong in the referenced
run directory and are never indexed here.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from pathlib import Path
from typing import Any


SCHEMA_VERSION = 1
FLOW_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.:-]{2,199}$")


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_flow(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise ValueError(f"cannot parse {path}: {error}") from error
    if not isinstance(value, dict):
        raise ValueError(f"{path}: root must be an object")
    if value.get("schema_version") != SCHEMA_VERSION:
        raise ValueError(f"{path}: schema_version must be {SCHEMA_VERSION}")
    flow_id = str(value.get("flow_id", ""))
    if not FLOW_ID_RE.fullmatch(flow_id):
        raise ValueError(f"{path}: invalid flow_id")
    for field in ("case_id", "name", "channel", "evidence_status", "page", "steps", "evidence", "reuse"):
        if field not in value:
            raise ValueError(f"{path}: missing required field {field}")
    if not isinstance(value["name"], str) or not value["name"].strip():
        raise ValueError(f"{path}: name must be a non-empty string")
    if value["channel"] not in {"admin", "hybrid"}:
        raise ValueError(f"{path}: channel must be admin or hybrid")
    if value["evidence_status"] not in {"verified", "observed", "inferred"}:
        raise ValueError(f"{path}: invalid evidence_status")
    if not isinstance(value["steps"], list) or not value["steps"]:
        raise ValueError(f"{path}: steps must be a non-empty array")
    for index, step in enumerate(value["steps"]):
        if isinstance(step, str):
            if not step.strip():
                raise ValueError(f"{path}: steps[{index}] must not be empty")
            continue
        if not isinstance(step, dict) or not isinstance(step.get("text"), str) or not step["text"].strip():
            raise ValueError(f"{path}: steps[{index}] object requires non-empty text")
        mcp_execution = step.get("mcp_execution")
        if mcp_execution not in {None, "validated_read_only", "deferred_to_feature"}:
            raise ValueError(f"{path}: steps[{index}] has invalid mcp_execution")
        if "table" in step and not isinstance(step["table"], (list, str)):
            raise ValueError(f"{path}: steps[{index}].table must be an array or string")
    page = value["page"]
    if not isinstance(page, dict) or not isinstance(page.get("route"), str) or not page["route"].startswith("/UI/"):
        raise ValueError(f"{path}: page.route must be a string beginning with /UI/")
    if not isinstance(page.get("profile"), str) or not page["profile"].strip():
        raise ValueError(f"{path}: page.profile must be a non-empty string")
    reuse = value["reuse"]
    if not isinstance(reuse, dict) or not isinstance(reuse.get("safe_to_reuse"), bool):
        raise ValueError(f"{path}: reuse.safe_to_reuse must be boolean")
    if not isinstance(reuse.get("keywords"), list) or not all(
        isinstance(item, str) for item in reuse["keywords"]
    ):
        raise ValueError(f"{path}: reuse.keywords must be an array of strings")
    evidence = value["evidence"]
    if not isinstance(evidence, dict):
        raise ValueError(f"{path}: evidence must be an object")
    source_coverage = value.get("source_coverage")
    if source_coverage is not None:
        if not isinstance(source_coverage, list) or not source_coverage:
            raise ValueError(f"{path}: source_coverage must be a non-empty array")
        for index, entry in enumerate(source_coverage):
            if not isinstance(entry, dict):
                raise ValueError(f"{path}: source_coverage[{index}] must be an object")
            yaml_index = entry.get("yaml_step_index")
            flow_indices = entry.get("flow_step_indices")
            if not isinstance(yaml_index, int) or isinstance(yaml_index, bool) or yaml_index < 1:
                raise ValueError(f"{path}: source_coverage[{index}].yaml_step_index must be positive")
            if not isinstance(flow_indices, list) or not flow_indices or not all(
                isinstance(item, int) and not isinstance(item, bool) and 1 <= item <= len(value["steps"])
                for item in flow_indices
            ):
                raise ValueError(
                    f"{path}: source_coverage[{index}].flow_step_indices must reference manifest steps"
                )
    return value


def step_count(flow: dict[str, Any]) -> int:
    count = len(flow.get("steps", []))
    count += len(flow.get("background", [])) if isinstance(flow.get("background"), list) else 0
    return count


def build(root: Path, flows_dir: Path | None = None) -> dict[str, Any]:
    schema_path = root / "schema.json"
    flow_root = flows_dir or (root / "flows")
    # A custom case-local flow directory may keep INDEX.json beside its
    # manifests.  The index is an aggregate, not a flow, so never feed it back
    # through manifest validation.
    flow_paths = sorted(
        path
        for path in flow_root.glob("*.json")
        if path.name not in {"INDEX.json", "schema.json"} and not path.is_symlink()
    )
    flows: list[dict[str, Any]] = []
    seen: dict[str, Path] = {}
    errors: list[str] = []
    for path in flow_paths:
        try:
            flow = load_flow(path)
        except ValueError as error:
            errors.append(str(error))
            continue
        flow_id = str(flow["flow_id"])
        if flow_id in seen:
            errors.append(f"duplicate flow_id {flow_id}: {seen[flow_id]} and {path}")
            continue
        seen[flow_id] = path
        page = flow["page"]
        reuse = flow["reuse"]
        evidence = flow["evidence"]
        flows.append(
            {
                "flow_id": flow_id,
                "case_id": str(flow["case_id"]),
                "name": str(flow["name"]),
                "channel": flow["channel"],
                "evidence_status": flow["evidence_status"],
                "path": path.as_posix(),
                "sha256": sha256(path),
                "page": {
                    "label": str(page.get("label", "")),
                    "route": str(page.get("route", "")),
                    "profile": str(page.get("profile", "")),
                    "operation": str(page.get("operation", "")),
                },
                "step_count": step_count(flow),
                "keywords": [str(item) for item in reuse.get("keywords", []) if str(item).strip()],
                "safe_to_reuse": bool(reuse.get("safe_to_reuse")),
                "before_binary": bool(reuse.get("before_binary", False)),
                "evidence_files": sorted(
                    str(item)
                    for key in ("playwright_runs", "traces", "screenshots", "logs")
                    for item in evidence.get(key, [])
                    if isinstance(item, str) and item.strip()
                ),
            }
        )
    flows.sort(key=lambda item: (item["page"]["route"], item["flow_id"]))
    return {
        "schema_version": SCHEMA_VERSION,
        "catalog": root.as_posix(),
        "schema": schema_path.as_posix() if schema_path.is_file() else None,
        "stats": {
            "flow_files": len(flow_paths),
            "indexed_flows": len(flows),
            "verified": sum(1 for item in flows if item["evidence_status"] == "verified"),
            "observed": sum(1 for item in flows if item["evidence_status"] == "observed"),
            "inferred": sum(1 for item in flows if item["evidence_status"] == "inferred"),
            "safe_to_reuse": sum(1 for item in flows if item["safe_to_reuse"]),
            "errors": len(errors),
        },
        "errors": errors,
        "flows": flows,
    }


def markdown(payload: dict[str, Any], json_path: Path, flows_dir: Path | None = None) -> str:
    stats = payload["stats"]
    lines = [
        "# Admin GUI Reusable Flow Catalog",
        "",
        "This index is generated from reviewed semantic manifests under",
        "`Admin_GUI/flow_catalog/flows/`. Playwright traces and screenshots are",
        "evidence pointers only; they are not copied into Features or this index.",
        "",
        f"Machine-readable index: [`{json_path.name}`]({json_path.name})",
        "",
        "## Coverage",
        "",
        "| Metric | Count |",
        "|---|---:|",
        f"| Flow files | {stats['flow_files']} |",
        f"| Indexed flows | {stats['indexed_flows']} |",
        f"| Verified | {stats['verified']} |",
        f"| Observed | {stats['observed']} |",
        f"| Inferred | {stats['inferred']} |",
        f"| Marked safe to reuse | {stats['safe_to_reuse']} |",
        f"| Catalog errors | {stats['errors']} |",
        "",
        "Only `evidence_status=verified` and `reuse.safe_to_reuse=true` flows may",
        "be selected automatically for a strict conversion. An `observed` flow",
        "is a shortcut for exploration planning and must be replayed first.",
        "",
        "## Flows",
        "",
        "| Flow ID | Page | Channel | Evidence | Steps | Reuse | Manifest |",
        "|---|---|---|---|---:|---|---|",
    ]
    for item in payload["flows"]:
        manifest = Path(item["path"]).name
        # INDEX.md normally lives beside ``flows/``; custom case-local flow
        # directories are also supported by the batch orchestrator.
        flow_root = flows_dir or (Path(payload["catalog"]) / "flows")
        try:
            manifest_link = Path(item["path"]).relative_to(json_path.parent).as_posix()
        except ValueError:
            manifest_link = f"{flow_root.name}/{manifest}"
        lines.append(
            f"| `{item['flow_id']}` | `{item['page']['route']}` | `{item['channel']}` | "
            f"`{item['evidence_status']}` | {item['step_count']} | "
            f"{'yes' if item['safe_to_reuse'] else 'review'} | [{manifest}]({manifest_link}) |"
        )
    if payload.get("errors"):
        lines.extend(["", "## Errors", ""])
        lines.extend(f"- {error}" for error in payload["errors"])
    lines.extend(
        [
            "",
            "## Add A Flow",
            "",
            "1. Save the raw Playwright MCP trace/screenshots in an isolated run",
            "   directory, for example `outputs/admin/<case>/run-001/`.",
            "2. Copy the semantic UAT-step manifest into",
            "   `Admin_GUI/flow_catalog/flows/<flow-id>.json` and keep dynamic",
            "   values as dataset placeholders.",
            "3. Record the page profile, redacted Grid observations, and evidence",
            "   paths. Never add raw locator code, credentials, or UUIDs.",
            "4. Replay from a clean state, then set `evidence_status` and",
            "   `safe_to_reuse` to `verified`/`true` only after the feature passes.",
            "",
            "```bash",
            "python3 tools/build_admin_flow_catalog.py",
            "python3 tools/build_admin_flow_catalog.py --check",
            "```",
            "",
        ]
    )
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--catalog", default="odpt-automation-skill/Admin_GUI/flow_catalog")
    parser.add_argument(
        "--flows-dir",
        help="directory containing manifests (defaults to <catalog>/flows)",
    )
    parser.add_argument("--output-json", default="odpt-automation-skill/Admin_GUI/flow_catalog/INDEX.json")
    parser.add_argument("--output-md", default="odpt-automation-skill/Admin_GUI/flow_catalog/INDEX.md")
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    root = Path(args.catalog)
    flows_dir = Path(args.flows_dir) if args.flows_dir else root / "flows"
    if not flows_dir.is_dir():
        print(f"ERROR: flow directory does not exist: {flows_dir}", file=sys.stderr)
        return 2
    payload = build(root, flows_dir)
    json_path = Path(args.output_json)
    md_path = Path(args.output_md)
    json_text = json.dumps(payload, ensure_ascii=False, indent=2) + "\n"
    md_text = markdown(payload, json_path, flows_dir)
    if args.check:
        stale = []
        if not json_path.is_file() or json_path.read_text(encoding="utf-8") != json_text:
            stale.append(str(json_path))
        if not md_path.is_file() or md_path.read_text(encoding="utf-8") != md_text:
            stale.append(str(md_path))
        if stale or payload["errors"]:
            if stale:
                print("STALE: " + ", ".join(stale), file=sys.stderr)
            for error in payload["errors"]:
                print("ERROR: " + error, file=sys.stderr)
            return 1
        print("Admin flow catalog is up to date")
        return 0
    json_path.parent.mkdir(parents=True, exist_ok=True)
    md_path.parent.mkdir(parents=True, exist_ok=True)
    json_path.write_text(json_text, encoding="utf-8")
    md_path.write_text(md_text, encoding="utf-8")
    print(f"Wrote {json_path} and {md_path}")
    print(f"Flows: {payload['stats']['indexed_flows']}; errors: {payload['stats']['errors']}")
    return 1 if payload["errors"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
