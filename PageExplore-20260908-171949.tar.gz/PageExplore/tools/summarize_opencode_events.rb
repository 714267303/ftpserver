#!/usr/bin/env ruby
# frozen_string_literal: true

# Summarize one compact/redacted OpenCode JSONL transcript without printing
# tool inputs or tool outputs. The input may be an Admin exploration run
# directory, an opencode-events.jsonl file, or "-" for stdin.

require 'json'
require 'optparse'
require 'time'

PLACEHOLDER_PATTERN = /\A\$?\{?(?:SECRET_)?ODP_(?:CHECKER_)?(?:USERNAME|PASSWORD)\}?\z/i
PLAYWRIGHT_PATTERN = /(?:\A|[_.-])playwright(?:[_.-]|\z)/i
WRITE_PATTERN = /(?:\A|[_.-])(?:write|edit|apply_patch)(?:[_.-]|\z)/i

def format_number(value)
  value.to_i.to_s.reverse.scan(/.{1,3}/).join(',').reverse
end

def format_duration(seconds)
  return 'n/a' unless seconds

  total = [seconds.round, 0].max
  hours = total / 3600
  minutes = (total % 3600) / 60
  secs = total % 60
  hours.positive? ? format('%02d:%02d:%02d', hours, minutes, secs) : format('%02d:%02d', minutes, secs)
end

def timestamp_seconds(value)
  number = Float(value)
  number > 10_000_000_000 ? number / 1000.0 : number
rescue ArgumentError, TypeError
  nil
end

def sanitize(value, limit: 360)
  text = value.is_a?(String) ? value.dup : JSON.generate(value)
  text = text.encode('UTF-8', invalid: :replace, undef: :replace, replace: '?')
  text.gsub!(/(\b(?:password|passwd|secret|token|authorization|api[_-]?key)\b\s*[:=]\s*)[^\s,;}\]]+/i, '\\1<redacted>')
  text.gsub!(/(\b(?:Bearer|Basic|Token)\s+)[^\s,;}\]]+/i, '\\1<redacted>')
  text.gsub!(/[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}/i, '<email>')
  text.gsub!(/[0-9a-f]{8}-[0-9a-f-]{27,}/i, '<uuid>')
  text.gsub!(/[\r\n\t]+/, ' ')
  text.gsub!(/\s+/, ' ')
  text.strip!
  text.length > limit ? "#{text[0, limit]}..." : text
rescue JSON::GeneratorError
  '<unprintable>'
end

def contains_literal_placeholder?(value)
  case value
  when String
    PLACEHOLDER_PATTERN.match?(value.strip)
  when Array
    value.any? { |item| contains_literal_placeholder?(item) }
  when Hash
    value.values.any? { |item| contains_literal_placeholder?(item) }
  else
    false
  end
end

def event_part(event)
  event['part'].is_a?(Hash) ? event['part'] : {}
end

def tool_event?(event)
  part = event_part(event)
  event['type'].to_s == 'tool_use' || part['type'].to_s == 'tool'
end

def finish_event?(event)
  part = event_part(event)
  event['type'].to_s == 'step_finish' || part['type'].to_s == 'step-finish'
end

def read_events(io)
  events = []
  malformed = []
  io.each_line.with_index(1) do |line, line_number|
    next if line.strip.empty?

    begin
      value = JSON.parse(line)
      if value.is_a?(Hash)
        events << [line_number, value]
      else
        malformed << [line_number, 'JSON value is not an object']
      end
    rescue JSON::ParserError => e
      malformed << [line_number, e.message]
    end
  end
  [events, malformed]
end

def artifact_summary(path, kind)
  result = {
    'path' => path,
    'exists' => File.file?(path) && !File.symlink?(path),
    'readable' => File.file?(path) && File.readable?(path) && !File.symlink?(path)
  }
  return result unless result['readable']

  result['bytes'] = File.size(path)
  payload = JSON.parse(File.read(path, encoding: 'UTF-8'))
  result['valid_json'] = payload.is_a?(Hash)
  unless payload.is_a?(Hash)
    result['parse_error'] = 'top-level JSON value is not an object'
    return result
  end

  result['schema_version'] = payload['schema_version']
  result['case_id'] = payload['case_id']
  result['channel'] = payload['channel']
  if kind == :report
    result['status'] = payload['status']
    result['clean_state'] = payload['clean_state']
    result['exploration_mode'] = payload['exploration_mode']
    result['business_mutations_executed'] = payload['business_mutations_executed']
    result['maker_submission_executed'] = payload['maker_submission_executed']
    result['final_approval_executed'] = payload['final_approval_executed']
    result['cleanup_action'] = payload['cleanup_action']
    result['cleanup_completed'] = payload['cleanup_completed']
    result['final_state_restored'] = payload['final_state_restored']
    result['final_approval_deferred_to_feature'] = payload['final_approval_deferred_to_feature']
    result['admin_steps_executed'] = payload['admin_steps_executed']
    result['admin_steps_validated'] = payload['admin_steps_validated']
    failure = payload['first_failure'] || payload['failure_reason'] || payload['failure'] || payload['reason'] || payload['error']
    result['first_failure'] = sanitize(failure) if failure
  else
    result['flow_id'] = payload['flow_id']
    result['route'] = payload.dig('page', 'route')
    result['step_count'] = payload['steps'].is_a?(Array) ? payload['steps'].length : nil
    result['safe_to_reuse'] = payload.dig('reuse', 'safe_to_reuse')
  end
  result
rescue JSON::ParserError => e
  result['valid_json'] = false
  result['parse_error'] = sanitize(e.message)
  result
rescue StandardError => e
  result['parse_error'] = sanitize("#{e.class}: #{e.message}")
  result
end

def summarize(events, malformed, source:, run_dir:, timeline:)
  timestamps = events.filter_map { |_line, event| timestamp_seconds(event['timestamp']) }
  started_at = timestamps.min
  ended_at = timestamps.max

  # OpenCode can emit updates for the same call ID. Keep the latest state so a
  # pending/running event is not counted as a second tool call.
  tool_calls = {}
  finishes = {}
  events.each do |line_number, event|
    part = event_part(event)
    timestamp = timestamp_seconds(event['timestamp']) || line_number.to_f
    if tool_event?(event)
      identity = part['callID'] || part['id'] || "line-#{line_number}"
      current = tool_calls[identity]
      next if current && current['timestamp'].to_f > timestamp

      state = part['state'].is_a?(Hash) ? part['state'] : {}
      tool_calls[identity] = {
        'id' => identity,
        'line' => line_number,
        'timestamp' => timestamp,
        'tool' => (part['tool'] || event['tool'] || '<unknown>').to_s,
        'status' => (state['status'] || part['status'] || 'unknown').to_s,
        'error' => state['error'] || part['error'] || event['error'],
        'literal_login_placeholder' => contains_literal_placeholder?(state['input'] || part['input'])
      }
    end

    next unless finish_event?(event)

    identity = part['id'] || "line-#{line_number}"
    tokens = part['tokens'].is_a?(Hash) ? part['tokens'] : {}
    cache = tokens['cache'].is_a?(Hash) ? tokens['cache'] : {}
    finishes[identity] = {
      'line' => line_number,
      'timestamp' => timestamp,
      'reason' => (part['reason'] || event['reason'] || 'unknown').to_s,
      'input' => tokens['input'].to_i,
      'output' => tokens['output'].to_i,
      'reasoning' => tokens['reasoning'].to_i,
      'total' => tokens['total'].to_i,
      'cache_read' => cache['read'].to_i,
      'cache_write' => cache['write'].to_i
    }
  end

  calls = tool_calls.values.sort_by { |call| [call['timestamp'], call['line']] }
  turns = finishes.values.sort_by { |finish| [finish['timestamp'], finish['line']] }
  tool_counts = calls.group_by { |call| call['tool'] }.transform_values do |group|
    statuses = group.group_by { |call| call['status'] }.transform_values(&:length)
    {
      'count' => group.length,
      'statuses' => statuses.sort.to_h,
      'errors' => group.count { |call| call['status'].casecmp?('error') || call['error'] }
    }
  end.sort_by { |name, data| [-data['count'], name] }.to_h
  errors = calls.filter_map do |call|
    next unless call['status'].casecmp?('error') || call['error']

    {
      'line' => call['line'],
      'tool' => call['tool'],
      'status' => call['status'],
      'error' => sanitize(call['error'] || 'tool status=error')
    }
  end

  token_fields = %w[input output reasoning total cache_read cache_write]
  token_sums = token_fields.to_h { |field| [field, turns.sum { |turn| turn[field].to_i }] }
  token_peaks = token_fields.to_h { |field| [field, turns.map { |turn| turn[field].to_i }.max.to_i] }
  finish_reasons = turns.group_by { |turn| turn['reason'] }.transform_values(&:length).sort.to_h
  playwright_calls = calls.count { |call| PLAYWRIGHT_PATTERN.match?(call['tool']) }
  write_calls = calls.count { |call| WRITE_PATTERN.match?(call['tool']) }
  placeholder_calls = calls.count do |call|
    PLAYWRIGHT_PATTERN.match?(call['tool']) && call['literal_login_placeholder']
  end

  artifacts = nil
  if run_dir
    artifacts = {
      'admin_flow' => artifact_summary(File.join(run_dir, 'admin-flow.json'), :manifest),
      'exploration_report' => artifact_summary(File.join(run_dir, 'exploration-report.json'), :report)
    }
  end

  findings = []
  findings << 'Transcript contains no valid JSON events.' if events.empty?
  findings << 'No Playwright MCP tool call was recorded; exploration did not reach the browser.' if playwright_calls.zero?
  if placeholder_calls.positive?
    findings << "Detected #{placeholder_calls} Playwright call(s) whose input contains a literal ODP login key; standard Playwright MCP --secrets does not substitute tool inputs."
  end
  findings << "Detected #{errors.length} failed tool call(s); inspect the sanitized error list." if errors.any?
  if token_peaks['input'] >= 64_000
    findings << "Peak model input was #{format_number(token_peaks['input'])} tokens; repeated tool turns at this context size are a major latency source."
  end
  if artifacts
    missing = artifacts.filter_map { |name, item| name unless item['readable'] }
    findings << "Required Admin artifact(s) missing or unreadable: #{missing.join(', ')}." if missing.any?
    if missing.any? && write_calls.zero?
      findings << 'No write/edit tool call was recorded before the model stopped.'
    elsif missing.any?
      findings << 'A write/edit tool was called, but the required artifact pair is incomplete; inspect write errors and destination paths.'
    end
    report = artifacts['exploration_report']
    if report['readable'] && report['status'].to_s != '' && report['status'].to_s.downcase != 'passed'
      findings << "Exploration report status is #{report['status'].inspect}#{report['first_failure'] ? ": #{report['first_failure']}" : ''}."
    end
  end

  result = {
    'source' => source,
    'run_dir' => run_dir,
    'events' => {
      'valid' => events.length,
      'malformed' => malformed.length,
      'first_timestamp' => started_at && Time.at(started_at).utc.iso8601(3),
      'last_timestamp' => ended_at && Time.at(ended_at).utc.iso8601(3),
      'observed_duration_seconds' => started_at && ended_at ? (ended_at - started_at).round(3) : nil
    },
    'model' => {
      'turns' => turns.length,
      'finish_reasons' => finish_reasons,
      'token_sums_across_turns' => token_sums,
      'token_peaks_per_turn' => token_peaks
    },
    'tools' => {
      'calls' => calls.length,
      'playwright_calls' => playwright_calls,
      'write_or_edit_calls' => write_calls,
      'literal_login_placeholder_calls' => placeholder_calls,
      'by_name' => tool_counts,
      'errors' => errors
    },
    'artifacts' => artifacts,
    'findings' => findings
  }
  if timeline
    result['model']['timeline'] = turns.map do |turn|
      turn.merge('offset_seconds' => started_at ? (turn['timestamp'] - started_at).round(3) : nil)
    end
  end
  result
end

def print_human(summary, error_limit:, timeline:)
  puts 'OpenCode Event Statistics'
  puts "Source:   #{summary['source']}"
  puts "Run dir:  #{summary['run_dir'] || 'n/a (stdin)'}"
  events = summary['events']
  puts "Events:   #{format_number(events['valid'])} valid, #{format_number(events['malformed'])} malformed"
  puts "Observed: #{format_duration(events['observed_duration_seconds'])}"

  model = summary['model']
  sums = model['token_sums_across_turns']
  peaks = model['token_peaks_per_turn']
  puts
  puts 'Model'
  puts "  Turns:            #{format_number(model['turns'])}"
  puts "  Finish reasons:   #{model['finish_reasons'].map { |key, count| "#{key}=#{count}" }.join(', ')}"
  puts "  Input token sum:  #{format_number(sums['input'])}"
  puts "  Peak input/turn:  #{format_number(peaks['input'])}"
  puts "  Output token sum: #{format_number(sums['output'])}"
  puts "  Reasoning sum:    #{format_number(sums['reasoning'])}"
  puts "  Cache read sum:   #{format_number(sums['cache_read'])}"

  tools = summary['tools']
  puts
  puts 'Tools'
  puts "  Calls:                      #{format_number(tools['calls'])}"
  puts "  Playwright calls:           #{format_number(tools['playwright_calls'])}"
  puts "  Write/edit calls:           #{format_number(tools['write_or_edit_calls'])}"
  puts "  Literal login placeholders: #{format_number(tools['literal_login_placeholder_calls'])}"
  puts '  By name:'
  if tools['by_name'].empty?
    puts '    (none)'
  else
    tools['by_name'].each do |name, data|
      statuses = data['statuses'].map { |status, count| "#{status}=#{count}" }.join(', ')
      puts format('    %-44s %4d  %s', name, data['count'], statuses)
    end
  end

  if error_limit.positive? && tools['errors'].any?
    puts
    puts "Tool Errors (first #{[error_limit, tools['errors'].length].min})"
    tools['errors'].first(error_limit).each do |error|
      puts "  line #{error['line']} #{error['tool']}: #{error['error']}"
    end
  end

  if summary['artifacts']
    puts
    puts 'Artifacts'
    summary['artifacts'].each do |name, artifact|
      state = if !artifact['exists']
                'missing'
              elsif !artifact['readable']
                'unreadable'
              elsif artifact['valid_json'] == false
                "invalid JSON: #{artifact['parse_error']}"
              else
                "present (#{format_number(artifact['bytes'])} bytes)"
              end
      puts "  #{name}: #{state}"
      if artifact['readable'] && artifact['valid_json'] != false
        details = %w[
          status case_id channel route step_count exploration_mode
          business_mutations_executed maker_submission_executed
          final_approval_executed cleanup_action cleanup_completed
          final_state_restored
          final_approval_deferred_to_feature admin_steps_executed
          admin_steps_validated safe_to_reuse first_failure
        ].filter_map do |key|
          "#{key}=#{artifact[key].inspect}" if artifact.key?(key) && !artifact[key].nil?
        end
        puts "    #{details.join(', ')}" unless details.empty?
      end
    end
  end

  if timeline && model['timeline']
    puts
    puts 'Model Timeline'
    model['timeline'].each_with_index do |turn, index|
      puts format(
        '  %3d  +%8.1fs  reason=%-12s input=%9s output=%7s cache_read=%9s',
        index + 1,
        turn['offset_seconds'].to_f,
        turn['reason'],
        format_number(turn['input']),
        format_number(turn['output']),
        format_number(turn['cache_read'])
      )
    end
  end

  puts
  puts 'Findings'
  if summary['findings'].empty?
    puts '  No obvious structural issue detected.'
  else
    summary['findings'].each { |finding| puts "  - #{finding}" }
  end
end

options = {
  json: false,
  timeline: false,
  error_limit: 10,
  strict: false
}

parser = OptionParser.new do |opts|
  opts.banner = 'Usage: ruby tools/summarize_opencode_events.rb RUN_DIR|JSONL|- [options]'
  opts.on('--json', 'Print machine-readable JSON') { options[:json] = true }
  opts.on('--timeline', 'Include one row per model turn') { options[:timeline] = true }
  opts.on('--errors N', Integer, 'Show at most N sanitized tool errors (default: 10)') do |value|
    raise OptionParser::InvalidArgument, 'N must be non-negative' if value.negative?

    options[:error_limit] = value
  end
  opts.on('--strict', 'Exit 1 when tools failed or required Admin artifacts are incomplete') do
    options[:strict] = true
  end
  opts.on('-h', '--help', 'Show this help') do
    puts opts
    exit 0
  end
end

begin
  parser.parse!
rescue OptionParser::ParseError => e
  warn "Error: #{e.message}"
  warn parser
  exit 2
end

input = ARGV.shift
if input.nil? || !ARGV.empty?
  warn parser
  exit 2
end

run_dir = nil
source = nil
io = nil
close_io = false
if input == '-'
  source = '<stdin>'
  io = $stdin
else
  expanded = File.expand_path(input)
  if File.directory?(expanded)
    run_dir = expanded
    source = File.join(run_dir, 'opencode-events.jsonl')
  else
    source = expanded
    run_dir = File.dirname(expanded) if File.basename(expanded) == 'opencode-events.jsonl'
  end
  unless File.file?(source) && File.readable?(source) && !File.symlink?(source)
    warn "Error: transcript is not a readable regular file: #{source}"
    exit 2
  end
  io = File.open(source, 'r:UTF-8')
  close_io = true
end

begin
  events, malformed = read_events(io)
ensure
  io.close if close_io
end

summary = summarize(
  events,
  malformed,
  source: source,
  run_dir: run_dir,
  timeline: options[:timeline]
)

if options[:json]
  puts JSON.pretty_generate(summary)
else
  print_human(summary, error_limit: options[:error_limit], timeline: options[:timeline])
end

strict_failure = summary.dig('tools', 'errors').any?
if summary['artifacts']
  strict_failure ||= summary['artifacts'].values.any? { |artifact| !artifact['readable'] || artifact['valid_json'] == false }
end
exit(options[:strict] && strict_failure ? 1 : 0)
