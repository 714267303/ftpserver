#!/usr/bin/env python3
"""Build a redacted qaGridApi observation index from application logs.

The output contains key patterns, method counts, column/row field names and
source hashes.  It intentionally omits row values and function arguments so
the generated index can be checked into the skill without turning test data
into a rule.  Use the raw logs as sensitive evidence and keep them outside
the model context unless a case requires a bounded excerpt.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any


PAGE_EXPLORE_ROOT = Path(os.environ.get("PAGEEXPLORE_ROOT", "pageExplore")).expanduser()


SEPARATOR_RE = re.compile(r"\n={10,}\n")
HEADER_RE = {
    "time": re.compile(r"^Time\s*:\s*(.+)$", re.M),
    "api_name": re.compile(r"^API Name\s*:\s*(.+)$", re.M),
    "api_key": re.compile(r"^API Key\s*:\s*(.+)$", re.M),
    "function": re.compile(r"^Function\s*:\s*(.+?)(?=\nResult\s*:)", re.M | re.S),
    "result": re.compile(r"^Result\s*:\s*(.*)$", re.M | re.S),
}
UUID_RE = re.compile(r"[0-9a-f]{8}-[0-9a-f-]{27,}", re.I)
METHOD_RE = re.compile(r"^\s*([A-Za-z_$][\w$]*)\s*\(")


def file_hash(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def knowledge_path(path: Path, root: Path) -> str:
    """Return a mount-independent path when ``path`` belongs to PageExplore."""

    try:
        return path.resolve().relative_to(root.resolve()).as_posix()
    except ValueError:
        return path.as_posix()


def parse_json(value: str) -> Any:
    try:
        return json.loads(value.strip())
    except (TypeError, ValueError):
        return None


def normalize_key(key: str) -> str:
    return UUID_RE.sub("<uuid>", key.strip())


def namespace(key: str) -> str:
    """Classify a key without relying on its run-specific UUID.

    Trading keys are consistently prefixed with ``ui``.  Admin detail grids
    use a dialog identifier, which is stable enough for evidence routing even
    though the UUID in the middle is not.  Unknown keys remain visible rather
    than being silently assigned to either UI.
    """

    lowered = key.lower()
    # Some Admin dialog keys (for example ``uiRgNotificationDetailDialog``)
    # also begin with ``ui``.  Dialog shape is the stronger signal and must be
    # checked before the Trading page prefix.
    if "detaildialog_" in lowered or lowered.startswith("smpidlistdetaildialog_"):
        return "admin_gui"
    if lowered.startswith("ui"):
        return "trading_gui"
    return "unknown"


def shape_fields(value: Any) -> set[str]:
    fields: set[str] = set()
    if isinstance(value, dict):
        fields.update(
            str(key)
            for key in value.keys()
            if not re.fullmatch(r"\d+", str(key)) and not str(key).startswith("@")
        )
        for child in value.values():
            fields.update(shape_fields(child))
    elif isinstance(value, list):
        for child in value:
            fields.update(shape_fields(child))
    return fields


def parse_function_argument(function: str, method: str) -> Any:
    """Parse JSON arguments for data-bearing Grid calls when possible.

    ``setRowData`` is logged as JavaScript and some captures contain trailing
    commas.  We only use the parsed shape (field names), never values; a parse
    failure therefore falls back to an empty set instead of guessing.
    """

    prefix = f"{method}("
    if not function.startswith(prefix):
        return None
    argument = function[len(prefix):]
    if argument.endswith(")"):
        argument = argument[:-1]
    argument = re.sub(r",\s*([}\]])", r"\1", argument.strip())
    return parse_json(argument)


def observed_fields(method: str, result: Any, function: str = "") -> set[str]:
    """Extract business field names without leaking row indexes or UI metadata."""

    if method == "getColumnDefs" and isinstance(result, list):
        return {
            str(item.get("field"))
            for item in result
            if isinstance(item, dict) and item.get("field") not in (None, "")
        }
    if method in {"getRowData", "getVisibleRowData"}:
        return shape_fields(result)
    if method == "setRowData":
        return shape_fields(parse_function_argument(function, method))
    return set()


def parse_record(block: str, source: Path) -> dict[str, Any] | None:
    key_match = HEADER_RE["api_key"].search(block)
    function_match = HEADER_RE["function"].search(block)
    if not key_match or not function_match:
        return None
    raw_key = key_match.group(1).strip()
    function = " ".join(function_match.group(1).split())
    method_match = METHOD_RE.match(function)
    method = method_match.group(1) if method_match else function.split("(", 1)[0].strip()
    result_match = HEADER_RE["result"].search(block)
    result = parse_json(result_match.group(1)) if result_match else None
    return {
        "source": source.as_posix(),
        "time": (HEADER_RE["time"].search(block) or ["", ""])[1].strip(),
        "api_name": (HEADER_RE["api_name"].search(block) or ["", ""])[1].strip(),
        "key": raw_key,
        "canonical_key": normalize_key(raw_key),
        "namespace": namespace(raw_key),
        "method": method,
        "result": result,
        "function": function,
    }


def parse_file(path: Path) -> list[dict[str, Any]]:
    text = path.read_text(encoding="utf-8", errors="replace")
    records: list[dict[str, Any]] = []
    for block in SEPARATOR_RE.split(text):
        parsed = parse_record(block, path)
        if parsed:
            records.append(parsed)
    return records


def parse_page_profiles(root: Path) -> list[dict[str, Any]]:
    """Read the small, YAML-like page profile headers without PyYAML.

    Profiles are documentation rather than a runtime parser input, so this
    intentionally extracts only routing metadata needed by the index.
    """

    profiles: list[dict[str, Any]] = []
    if not root.is_dir():
        return profiles
    for path in sorted(root.glob("*.md")):
        text = path.read_text(encoding="utf-8", errors="replace")
        if not re.search(r"^label:\s*", text, re.M) or not re.search(
            r"^hasGrid:\s*true\s*$", text, re.M
        ):
            continue
        label = re.search(r'^label:\s*["\']?([^"\'\n]+)', text, re.M)
        route = re.search(r'^route:\s*["\']?([^"\'\n]+)', text, re.M)
        key_pattern = re.search(r'^  keyPattern:\s*["\']?([^"\'\n]+)', text, re.M)
        status = re.search(r'^  observationStatus:\s*["\']?([^"\'\n]+)', text, re.M)
        sub_patterns = re.findall(
            r'^\s+keyPattern:\s*["\']?([^"\'\n]+)', text, re.M
        )
        columns = [
            value
            for value in re.findall(r'^\s+- field:\s*["\']?([^"\'\n]*)', text, re.M)
            if value
        ]
        profiles.append(
            {
                "path": path.as_posix(),
                "label": (label.group(1).strip() if label else path.stem),
                "route": route.group(1).strip() if route else "",
                "key_pattern": key_pattern.group(1).strip() if key_pattern else "",
                "sub_key_patterns": sorted(set(item.strip() for item in sub_patterns)),
                "observation_status": status.group(1).strip() if status else "unknown",
                "column_count": len(columns),
                "columns": columns,
            }
        )
    return profiles


def build(paths: list[Path], pages_root: Path | None = None) -> dict[str, Any]:
    knowledge_root = pages_root.parent if pages_root else PAGE_EXPLORE_ROOT
    records = [record for path in paths for record in parse_file(path)]
    families: dict[str, dict[str, Any]] = {}
    method_counts = Counter(record["method"] for record in records)
    api_counts = Counter(record["api_name"] for record in records)
    for record in records:
        family = record["canonical_key"]
        entry = families.setdefault(
            family,
            {
                "key_pattern": family,
                "namespace": record["namespace"],
                "observed_keys": set(),
                "methods": {},
                "field_names": set(),
                "sources": set(),
            },
        )
        entry["observed_keys"].add(record["key"])
        entry["sources"].add(record["source"])
        method = record["method"]
        method_info = entry["methods"].setdefault(method, {"count": 0, "field_names": set()})
        method_info["count"] += 1
        fields = observed_fields(record["method"], record["result"], record.get("function", ""))
        method_info["field_names"].update(fields)
        entry["field_names"].update(fields)

    def jsonable(value: Any) -> Any:
        if isinstance(value, set):
            return sorted(value)
        if isinstance(value, dict):
            return {key: jsonable(item) for key, item in value.items()}
        if isinstance(value, list):
            return [jsonable(item) for item in value]
        return value

    family_list = [jsonable(families[key]) for key in sorted(families)]
    for family in family_list:
        family["observed_key_count"] = len(family.pop("observed_keys", []))
        family["source_count"] = len(family.pop("sources", []))
        family["methods"] = {
            name: jsonable(info) for name, info in sorted(family["methods"].items())
        }
    page_profiles = parse_page_profiles(pages_root) if pages_root else []
    for profile in page_profiles:
        profile["path"] = knowledge_path(Path(profile["path"]), knowledge_root)
    return {
        "schema_version": 1,
        "api_name": "qaGridApi",
        "sources": [
            {
                "path": knowledge_path(path, knowledge_root),
                "sha256": file_hash(path),
                "records": len(parse_file(path)),
            }
            for path in paths
        ],
        "stats": {
            "records": len(records),
            "unique_key_patterns": len(family_list),
            "unique_exact_keys": len({record["key"] for record in records}),
            "api_names": dict(sorted(api_counts.items())),
            "methods": dict(sorted(method_counts.items())),
            "page_profiles": len(page_profiles),
            "verified_or_observed_page_profiles": sum(
                profile["observation_status"] in {"observed", "verified"}
                for profile in page_profiles
            ),
        },
        "families": family_list,
        "page_profiles": page_profiles,
    }


def render_markdown(payload: dict[str, Any]) -> str:
    stats = payload["stats"]
    lines = [
        "# qaGridApi Observation Index",
        "",
        "Generated from redacted shape evidence.  Read the shared contract in",
        "[`Grid_API_Core_Index.md`](Grid_API_Core_Index.md) before using this file.",
        "Observed values are telemetry, not business expectations.",
        "",
        "## Snapshot",
        "",
        f"- Records: `{stats['records']}`",
        f"- Exact keys: `{stats['unique_exact_keys']}`",
        f"- Key patterns: `{stats['unique_key_patterns']}`",
        f"- Page profiles with `hasGrid: true`: `{stats.get('page_profiles', 0)}`",
        f"- Observed/verified page profiles: `{stats.get('verified_or_observed_page_profiles', 0)}`",
        "",
        "| Source | SHA-256 | Records |",
        "|---|---|---:|",
    ]
    for source in payload["sources"]:
        lines.append(f"| `{source['path']}` | `{source['sha256']}` | {source['records']} |")
    lines.extend(
        [
            "",
            "## Method Counts",
            "",
            "| Method | Calls |",
            "|---|---:|",
        ]
    )
    for method, count in sorted(stats["methods"].items(), key=lambda item: (-item[1], item[0])):
        lines.append(f"| `{method}` | {count} |")
    lines.extend(["", "## Key Families", "", "| Namespace | Key pattern | Observed exact keys | Methods | Fields |", "|---|---|---:|---|---|"])
    for family in payload["families"]:
        methods = ", ".join(f"`{name}` ({info['count']})" for name, info in family["methods"].items())
        fields = ", ".join(f"`{field}`" for field in family["field_names"])
        lines.append(f"| `{family['namespace']}` | `{family['key_pattern']}` | {family['observed_key_count']} | {methods or '-'} | {fields or '-'} |")
    profiles = payload.get("page_profiles", [])
    if profiles:
        lines.extend(
            [
                "",
                "## Page Profile Coverage",
                "",
                "Page profiles carry the page-specific label, columns, and Grid",
                "observation status. The shared contract remains authoritative",
                "for method safety and runtime key discovery.",
                "",
                "| Profile | Route | Status | Columns | Key pattern |",
                "|---|---|---|---:|---|",
            ]
        )
        for profile in profiles:
            lines.append(
                f"| `{profile['path']}` | `{profile['route']}` | `{profile['observation_status']}` | "
                f"{profile['column_count']} | `{profile['key_pattern'] or 'runtime-discovered'}` |"
            )
    lines.extend(
        [
            "",
            "## Use by Consumers",
            "",
            "- Use key patterns to select a runtime Grid, never an exact UUID.",
            "- Use column/row field names to maintain the matching page profile.",
            "- Use method counts and call order as exploration hints only.",
            "- Do not generate a status assertion or a mutation step from a log value alone.",
            "- Promote an observation to `verified` only after a clean Playwright replay and a matching visible assertion pass.",
            "",
            "The full machine-readable shape is in `qaGridApi_Index.json`.",
            "",
        ]
    )
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", action="append", dest="inputs", help="qaGrid log path (repeatable)")
    parser.add_argument("--pages", default=str(PAGE_EXPLORE_ROOT / "pages"), help="page profile directory (optional)")
    parser.add_argument("--json-output", default=str(PAGE_EXPLORE_ROOT / "qaGrid" / "qaGridApi_Index.json"))
    parser.add_argument("--markdown-output", default=str(PAGE_EXPLORE_ROOT / "qaGrid" / "qaGridApi_Index.md"))
    args = parser.parse_args()
    inputs = [Path(path) for path in (args.inputs or [
        str(PAGE_EXPLORE_ROOT / "evidence" / "qaGrid" / "grid_log.txt"),
        str(PAGE_EXPLORE_ROOT / "evidence" / "qaGrid" / "odp_admin_gui_grid_api.log"),
        str(PAGE_EXPLORE_ROOT / "evidence" / "qaGrid" / "odp_admin_gui_grid_api_additional.log"),
    ])]
    missing = [path for path in inputs if not path.is_file()]
    if missing:
        parser.error("input does not exist: " + ", ".join(str(path) for path in missing))
    pages_root = Path(args.pages)
    payload = build(inputs, pages_root if pages_root.is_dir() else None)
    json_path = Path(args.json_output)
    markdown_path = Path(args.markdown_output)
    json_path.parent.mkdir(parents=True, exist_ok=True)
    markdown_path.parent.mkdir(parents=True, exist_ok=True)
    json_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    markdown_path.write_text(render_markdown(payload), encoding="utf-8")
    print(f"JSON index written: {json_path}")
    print(f"Markdown index written: {markdown_path}")
    print(f"Records: {payload['stats']['records']}; key patterns: {payload['stats']['unique_key_patterns']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
