#!/usr/bin/env ruby
# frozen_string_literal: true

# Tool: Split ODP17.xlsx into individual test case Excel files
# Usage: ruby tools/split_tc_excel.rb [source_xlsx]
#
# This tool reads an Excel file containing multiple test cases (rows with Key column)
# and splits each test case into its own separate Excel file.
#
# The output files are saved to: ai/TC/split/<TestCaseKey>.xlsx
# with the same column structure as the original.

require 'roo'
require 'write_xlsx'
require 'fileutils'

# --- Configuration ---
SOURCE_FILE = ARGV[0] || 'ai/TC/ODP17.xlsx'
OUTPUT_DIR  = SOURCE_FILE.gsub(".xlsx", "")

# Column indices (1-based, matching the Excel columns we observed)
COL_KEY            = 1  # A: Key (ODP-Txxxxx)
COL_NAME           = 2  # B: Name
COL_STATUS         = 3  # C: Status
COL_PRECONDITION   = 4  # D: Precondition
COL_OBJECTIVE      = 5  # E: Objective
COL_FOLDER         = 6  # F: Folder
COL_PRIORITY       = 7  # G: Priority
COL_COMPONENT      = 8  # H: Component
COL_LABELS         = 9  # I: Labels
COL_OWNER          = 10 # J: Owner
COL_EST_TIME       = 11 # K: Estimated Time
COL_COV_ISSUES     = 12 # L: Coverage (Issues)
COL_COV_PAGES      = 13 # M: Coverage (Pages)
COL_CHECKER        = 14 # N: Checker
COL_CHECKER2       = 15 # O: Checker 2
COL_STEP           = 16 # P: Step
COL_TEST_DATA      = 17 # Q: Test Data
COL_EXPECTED       = 18 # R: Expected Result
COL_PLAIN_TEXT     = 19 # S: Plain Text
COL_BDD            = 20 # T: BDD

HEADERS = [
  'Key', 'Name', 'Status', 'Precondition', 'Objective', 'Folder',
  'Priority', 'Component', 'Labels', 'Owner', 'Estimated Time',
  'Coverage (Issues)', 'Coverage (Pages)', 'Checker', 'Checker 2',
  'Test Script (Step-by-Step) - Step',
  'Test Script (Step-by-Step) - Test Data',
  'Test Script (Step-by-Step) - Expected Result',
  'Test Script (Plain Text)',
  'Test Script (BDD)'
].freeze

def log(msg)
  puts "[SPLIT] #{msg}"
end

def sanitize_filename(name)
  # Replace characters that are problematic in filenames
  name.to_s
      .gsub(%r{[/\\:*?"<>|]}, '_')
      .gsub(/\s+/, '_')
      .gsub(/_+/, '_')
      .gsub(/^_|_$/, '')
      .downcase
end

# Parse the Excel file and identify test case boundaries
def parse_test_cases(xlsx, sheet_name)
  xlsx.default_sheet = sheet_name
  last_row = xlsx.last_row

  test_cases = []
  current_tc = nil

  (2..last_row).each do |row|
    key = xlsx.cell(row, COL_KEY)
    name = xlsx.cell(row, COL_NAME)

    if key && !key.to_s.strip.empty?
      # Start of a new test case
      # Save previous test case if exists
      test_cases << current_tc if current_tc

      current_tc = {
        key: key.to_s.strip,
        name: name.to_s.strip,
        start_row: row,
        end_row: row,
        rows_data: []
      }
    end

    if current_tc
      current_tc[:end_row] = row
      # Collect all cell values for this row
      row_data = {}
      (1..xlsx.last_column).each do |col|
        val = xlsx.cell(row, col)
        row_data[col] = val unless val.nil?
      end
      current_tc[:rows_data] << row_data
    end
  end

  # Save the last test case
  test_cases << current_tc if current_tc

  test_cases
end

# Write a single test case to its own Excel file
def write_test_case(tc, output_dir)
  key = tc[:key]
  name = tc[:name]

  # Create a safe filename: Key_ShortName.xlsx
  # Take first 40 chars of the name to keep filename reasonable
  short_name = sanitize_filename(name)
  short_name = short_name[0, 60] if short_name.length > 60
  filename = "#{key}_#{short_name}.xlsx"
  filepath = File.join(output_dir, filename)

  # Ensure output directory exists
  FileUtils.mkdir_p(output_dir)

  workbook = WriteXLSX.new(filepath)
  worksheet = workbook.add_worksheet('Sheet0')

  # Write headers with format - use simple bold format
  header_format = workbook.add_format
  header_format.set_bold
  header_format.set_border(1)
  header_format.set_text_wrap
  header_format.set_valign('vcenter')

  HEADERS.each_with_index do |hdr, idx|
    worksheet.write(0, idx, hdr, header_format)
  end

  # Write data rows
  data_format = workbook.add_format
  data_format.set_text_wrap
  data_format.set_valign('top')
  data_format.set_border(1)

  tc[:rows_data].each_with_index do |row_data, row_idx|
    (1..HEADERS.length).each do |col|
      val = row_data[col]
      next if val.nil?

      # Ensure val is a string for WriteXLSX
      str_val = val.to_s
      worksheet.write(row_idx + 1, col - 1, str_val, data_format) unless str_val.empty?
    end
  end

  # Adjust column widths
  column_widths = [15, 40, 10, 60, 60, 50, 10, 20, 20, 15, 12, 15, 15, 15, 15, 60, 40, 60, 80, 80]
  column_widths.each_with_index do |width, idx|
    worksheet.set_column(idx, idx, width)
  end

  workbook.close

  log "Created: #{filename} (#{tc[:rows_data].length} rows)"
  filepath
end

# --- Main Execution ---
def main
  log "Reading source file: #{SOURCE_FILE}"

  unless File.exist?(SOURCE_FILE)
    puts "ERROR: Source file not found: #{SOURCE_FILE}"
    exit 1
  end

  xlsx = Roo::Spreadsheet.open(SOURCE_FILE)
  sheet = xlsx.sheets.first
  log "Sheet: #{sheet}"

  test_cases = parse_test_cases(xlsx, sheet)
  log "Found #{test_cases.length} test cases in the spreadsheet\n"

  # Display summary
  puts "\n#{'=' * 80}"
  puts "Test Cases Found:"
  puts "#{'=' * 80}"
  test_cases.each_with_index do |tc, idx|
    puts "  [#{idx + 1}] #{tc[:key]} - #{tc[:name]}"
  end

  # Create output directory and write each test case
  log "\nSplitting test cases to: #{OUTPUT_DIR}"
  FileUtils.rm_rf(OUTPUT_DIR)
  FileUtils.mkdir_p(OUTPUT_DIR)

  test_cases.each do |tc|
    write_test_case(tc, OUTPUT_DIR)
  end

  puts "\n#{'=' * 80}"
  puts "Split complete! #{test_cases.length} test case files created in:"
  puts "  #{File.expand_path(OUTPUT_DIR)}"
  puts "#{'=' * 80}"

  # Return the list of generated files for further processing
  output_files = Dir.glob(File.join(OUTPUT_DIR, '*.xlsx')).sort
  output_files
end

main if __FILE__ == $PROGRAM_NAME