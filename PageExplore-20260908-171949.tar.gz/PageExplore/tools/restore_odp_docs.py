#!/usr/bin/env python3
"""Restore the file bundle embedded in ``uat/odp_doc.md``.

The supplied ODP functional specifications are distributed as one Markdown
snapshot with ``<FILE:path>`` / ``</FILE>`` delimiters.  This utility restores
those files below a dedicated knowledge root and writes deterministic indexes
for humans and tooling.  It intentionally never follows absolute or parent
directory paths from the snapshot.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
from pathlib import Path, PurePosixPath
from typing import Iterable


FILE_RE = re.compile(r"^<FILE:(?P<path>[^>]+)>\s*$")
END_MARKER = "</FILE>"
SCHEMA_VERSION = 1


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def safe_relative_path(raw_path: str) -> str:
    """Return a normalized relative POSIX path or raise ``ValueError``."""

    value = raw_path.strip().replace("\\", "/")
    path = PurePosixPath(value)
    if not value or path.is_absolute() or any(part in {"", ".", ".."} for part in path.parts):
        raise ValueError(f"unsafe embedded path: {raw_path!r}")
    return path.as_posix()


def parse_bundle(source: Path) -> list[dict[str, object]]:
    lines = source.read_text(encoding="utf-8").splitlines(keepends=True)
    entries: list[dict[str, object]] = []
    current: dict[str, object] | None = None
    body: list[str] = []

    def finish(end_line: int) -> None:
        nonlocal current, body
        if current is None:
            raise ValueError(f"unexpected {END_MARKER} at source line {end_line}")
        content = "".join(body)
        # The delimiter occupies its own line.  Drop only the separator line
        # introduced by the snapshot format, preserving document content.
        if content.startswith("\n"):
            content = content[1:]
        data = content.encode("utf-8")
        current.update(
            {
                "source_end_line": end_line,
                "content": content,
                "bytes": len(data),
                "lines": len(content.splitlines()),
                "sha256": sha256_bytes(data),
            }
        )
        entries.append(current)
        current = None
        body = []

    for line_number, line in enumerate(lines, start=1):
        marker = FILE_RE.match(line.rstrip("\r\n"))
        if marker:
            if current is not None:
                raise ValueError(f"missing {END_MARKER} before source line {line_number}")
            relative = safe_relative_path(marker.group("path"))
            current = {"path": relative, "source_start_line": line_number}
            body = []
            continue
        if line.strip() == END_MARKER:
            finish(line_number)
            continue
        if current is not None:
            body.append(line)
        elif line.strip():
            raise ValueError(f"content outside a file block at source line {line_number}")

    if current is not None:
        raise ValueError(f"unterminated file block for {current['path']}")
    if not entries:
        raise ValueError(f"no {FILE_RE.pattern} markers found in {source}")
    return entries


def relative_source(source: Path, output: Path) -> str:
    try:
        return os.path.relpath(source, output).replace(os.sep, "/")
    except ValueError:
        return str(source)


def write_restored_files(entries: Iterable[dict[str, object]], output: Path) -> None:
    for entry in entries:
        target = output / "files" / str(entry["path"])
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(str(entry["content"]), encoding="utf-8", newline="")


def build_index(entries: list[dict[str, object]], source: Path, output: Path) -> dict[str, object]:
    clean_entries = [
        {
            "path": entry["path"],
            "restored_path": f"files/{entry['path']}",
            "source_start_line": entry["source_start_line"],
            "source_end_line": entry["source_end_line"],
            "bytes": entry["bytes"],
            "lines": entry["lines"],
            "sha256": entry["sha256"],
        }
        for entry in entries
    ]
    return {
        "schema_version": SCHEMA_VERSION,
        "source": relative_source(source, output),
        "root": ".",
        "stats": {
            "file_count": len(clean_entries),
            "total_bytes": sum(int(item["bytes"]) for item in clean_entries),
            "total_lines": sum(int(item["lines"]) for item in clean_entries),
        },
        "files": clean_entries,
    }


def markdown_index(index: dict[str, object]) -> str:
    lines = [
        "# ODP Functional Specification Index",
        "",
        "This index is generated from the bundled `odp_doc.md` snapshot. The",
        "restored specifications are business-reference documents for Feature",
        "generation, diagnosis, and repair; executable UAT step definitions and",
        "the target runtime remain authoritative for syntax and behavior.",
        "",
        f"- Source: `{index['source']}`",
        f"- Files: `{index['stats']['file_count']}`",
        f"- Restored root: `files/`",
        "",
        "| Specification | Restored file | Source lines | Size | SHA-256 |",
        "|---|---|---:|---:|---|",
    ]
    for item in index["files"]:  # type: ignore[index]
        path = str(item["path"]).replace("|", "\\|")
        restored = str(item["restored_path"]).replace("|", "\\|")
        source_lines = f"{item['source_start_line']}-{item['source_end_line']}"
        lines.append(
            f"| `{path}` | [`{restored}`](<{restored}>) | {source_lines} | {item['bytes']} bytes / {item['lines']} lines | `{item['sha256']}` |"
        )
    return "\n".join(lines) + "\n"


def read_existing_index(path: Path) -> dict[str, object] | None:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None


def restore(source: Path, output: Path, check: bool = False) -> int:
    entries = parse_bundle(source)
    index = build_index(entries, source.resolve(), output.resolve())
    expected_files = {output / "files" / str(entry["path"]): str(entry["content"]) for entry in entries}
    expected = {
        output / "INDEX.json": json.dumps(index, indent=2, ensure_ascii=False) + "\n",
        output / "INDEX.md": markdown_index(index),
    }
    if check:
        for path, content in {**expected, **expected_files}.items():
            if not path.is_file() or path.read_text(encoding="utf-8") != content:
                print(f"out of date: {path}")
                return 1
        return 0

    output.mkdir(parents=True, exist_ok=True)
    # Do not remove unrelated files in the knowledge root.  Stale restored
    # files are detected by the check below and can be removed intentionally
    # by a maintainer after reviewing the source snapshot.
    write_restored_files(entries, output)
    (output / "INDEX.json").write_text(expected[output / "INDEX.json"], encoding="utf-8")
    (output / "INDEX.md").write_text(expected[output / "INDEX.md"], encoding="utf-8")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--source",
        default=str(Path(__file__).resolve().parents[1] / "uat" / "odp_doc.md"),
        help="Embedded ODP document bundle (default: uat/odp_doc.md)",
    )
    parser.add_argument(
        "--output",
        default=str(Path(__file__).resolve().parents[1] / "odp-docs"),
        help="Sibling knowledge root to populate (default: odp-docs)",
    )
    parser.add_argument("--check", action="store_true", help="Verify restored files and indexes without writing")
    args = parser.parse_args()
    source = Path(args.source).resolve()
    output = Path(args.output).resolve()
    if not source.is_file():
        parser.error(f"source does not exist: {source}")
    try:
        return restore(source, output, check=args.check)
    except (OSError, ValueError) as error:
        parser.error(str(error))
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
