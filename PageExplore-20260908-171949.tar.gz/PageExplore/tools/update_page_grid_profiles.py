#!/usr/bin/env python3
"""Add the shared qaGridApi contract metadata to page profiles.

Page files intentionally retain their existing column and business metadata.
This mechanical updater only inserts a ``gridApi`` block for profiles marked
``hasGrid: true`` and leaves an observed block (for example the SMP ID List
detail profile) untouched.
"""

from __future__ import annotations

import argparse
import os
from pathlib import Path


PAGE_EXPLORE_ROOT = Path(os.environ.get("PAGEEXPLORE_ROOT", "pageExplore")).expanduser()
SHARED_INDEX = "../qaGrid/Grid_API_Core_Index.md"
ADMIN_INDEX = "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"


def block() -> str:
    return (
        "gridApi:\n"
        '  apiName: "qaGridApi"\n'
        '  keyPattern: "runtime-discovered; page-specific UUID key"\n'
        '  discovery: "active page/container, never a hard-coded UUID"\n'
        '  observationStatus: "inferred"\n'
        f'  sharedIndex: "{SHARED_INDEX}"\n'
        f'  observationIndex: "{ADMIN_INDEX}"\n'
    )


def update(path: Path) -> bool:
    text = path.read_text(encoding="utf-8")
    if "hasGrid: true" not in text:
        return False
    # These source strings are migration aliases only. New profiles always
    # point to the PageExplore-owned indexes declared above.
    updated = text.replace(
        'sharedIndex: "../odpt-automation-skill/Grid_API_Core_Index.md"',
        f'sharedIndex: "{SHARED_INDEX}"',
    ).replace(
        'observationIndex: "../odpt-automation-skill/Admin_GUI/Grid_API_Observation_Index.md"',
        f'observationIndex: "{ADMIN_INDEX}"',
    )
    if "gridApi:" not in updated:
        marker = "hasGrid: true\n"
        updated = updated.replace(marker, marker + block(), 1)
    if updated == text:
        return False
    path.write_text(updated, encoding="utf-8")
    return True


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pages", default=str(PAGE_EXPLORE_ROOT / "pages"))
    args = parser.parse_args()
    root = Path(args.pages)
    changed = [path for path in sorted(root.glob("*.md")) if update(path)]
    print(f"Updated page profiles: {len(changed)}")
    for path in changed:
        print(path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
