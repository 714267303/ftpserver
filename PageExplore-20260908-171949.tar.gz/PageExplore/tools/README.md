# Tools layout

The public commands remain directly under `tools/` so existing automation can
keep invoking the same paths.

## Batch conversion

- `batch_transform_tc.rb` — stable Excel/YAML/Admin/Feature pipeline CLI.
- `lib/batch_transform/` — its Ruby implementation, split by pipeline stage.
- `admin_feature_converter.py` and `admin_page_contract.py` — deterministic
  Admin manifest conversion and PageExplore contract validation.
- `run_feature_debug.rb` — isolated Feature execution, diagnosis and repair.
- `summarize_opencode_events.rb` — redacted OpenCode event statistics.

## Index and documentation maintenance

The `build_*.py`, `restore_odp_docs.py`, and `update_page_grid_profiles.py`
commands maintain generated indexes and PageExplore documentation. They remain
standalone commands rather than runtime batch modules.

## Source preparation

- `split_tc_excel.rb` — split source workbooks into per-case inputs.
- `find_admin_flow.py` — locate a compatible reviewed Admin flow.

## Regression tests

Files named `test_*.py` cover the tools above. They intentionally remain at
their existing import paths for compatibility. Run the core suite with:

```bash
PYTHONPATH=tools python3 -m unittest -v \
  tools.test_admin_page_contract \
  tools.test_admin_feature_converter \
  tools.test_batch_transform_pipeline \
  tools.test_run_feature_debug
```
