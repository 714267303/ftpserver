#!/usr/bin/env python3
"""Build a provenance-preserving index of ODP error and status codes.

The service description has appeared in more than one shape over time.  The
checked-in reference is a CSV, while newer hand-offs commonly use an object
whose ``Error Code Index`` member contains ``category``/``entries`` arrays.
This tool accepts both formats and keeps the category as part of the lookup
key.  A numeric code is not globally unique: for example ``2000`` has
different meanings for order, quote and cancel responses.

The input files remain authoritative.  The generated files are a searchable
projection and deliberately retain unknown JSON columns in ``attributes`` so
that information such as ``Priority``, ``Binary`` and ``Scenario`` is not
silently discarded.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Iterable


SCHEMA_VERSION = 1
SCRIPT_ROOT = Path(__file__).resolve().parents[1]

# The CSV was normalized before the JSON hand-off was supplied.  Keep these
# aliases so both source vocabularies resolve to the same stable category ID,
# while preserving each source's original category label on the entry.
CATEGORY_ALIASES = {
    "SOLICITED_CANCEL_REASON": "CANCEL_REASON_SOLICITED",
    "UNSOLICITED_CANCEL_REASON": "CANCEL_REASON_UNSOLICITED",
    "PENDING_TRADE_CANCEL_REASON": "BLOCK_TRADE_PENDING_CANCEL_REASON",
    "BUSINESS_REJECT_REASON_TEXT": "BUSINESS_REJECT_REASON_TEXT",
}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def slug(value: Any) -> str:
    text = str(value or "").strip().upper()
    text = re.sub(r"[^A-Z0-9]+", "_", text).strip("_")
    return CATEGORY_ALIASES.get(text, text or "UNSPECIFIED")


def label_from_id(value: str) -> str:
    return re.sub(r"\s+", " ", value.replace("_", " ").strip()).title()


def first_value(mapping: dict[str, Any], names: Iterable[str], default: Any = "") -> Any:
    lowered = {str(key).strip().lower(): value for key, value in mapping.items()}
    for name in names:
        key = name.strip().lower()
        if key in lowered:
            return lowered[key]
    return default


def parse_priority(value: Any) -> tuple[int | None, Any]:
    """Return a numeric priority and the original value when it is not numeric."""

    if value is None:
        return None, None
    raw = str(value).strip()
    if not raw:
        return None, ""
    if re.fullmatch(r"[+-]?\d+", raw):
        return int(raw), int(raw)
    return None, value


def split_code_values(code: str) -> list[str]:
    """Split a display code such as ``9991 / 9998`` without changing it."""

    values = [part.strip() for part in re.split(r"\s*(?:/|\||,)\s*", code) if part.strip()]
    return values or ([code] if code else [])


def source_status(value: Any, default: str) -> str:
    text = str(value or "").strip()
    return text or default


def make_entry(
    *,
    category_id: str,
    category_label: str,
    source_category: str,
    code: Any,
    reason_text: Any,
    priority: Any = None,
    status: Any = None,
    attributes: dict[str, Any] | None = None,
    source: str,
    source_format: str,
    source_row: int | None = None,
) -> dict[str, Any]:
    code_text = "" if code is None else str(code).strip()
    reason = "" if reason_text is None else str(reason_text)
    numeric_priority, priority_value = parse_priority(priority)
    entry: dict[str, Any] = {
        "category_id": category_id,
        "category": category_label,
        "source_category": source_category,
        "code": code_text,
        "code_values": split_code_values(code_text),
        "reason_text": reason,
        "source_status": source_status(status, "USER_SUPPLIED"),
        "source": source,
        "source_format": source_format,
    }
    if numeric_priority is not None:
        entry["priority"] = numeric_priority
    elif priority_value not in (None, ""):
        # Preserve unusual priorities (for example a spreadsheet marker)
        # instead of coercing them to zero.
        entry["priority_raw"] = priority_value
    if source_row is not None:
        entry["source_row"] = source_row
    if attributes:
        entry["attributes"] = {str(key): value for key, value in sorted(attributes.items())}
    return entry


def csv_entries(path: Path) -> list[dict[str, Any]]:
    entries: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if not reader.fieldnames:
            raise ValueError(f"{path}: CSV has no header")
        for row_number, row in enumerate(reader, 2):
            category_raw = first_value(row, ("Category", "category"), "UNSPECIFIED")
            category_label = label_from_id(str(category_raw))
            category_id = slug(category_raw)
            code = first_value(row, ("Code", "Reason Code", "reason_code"), "")
            reason = first_value(row, ("ReasonText", "Reason Text", "reason_text"), "")
            priority = first_value(row, ("Priority", "priority"), "")
            status = first_value(row, ("SourceStatus", "Source Status", "source_status"), "")
            known = {
                "category",
                "code",
                "reasontext",
                "reason code",
                "reason_text",
                "priority",
                "sourcestatus",
                "source status",
                "source_status",
            }
            attributes = {
                key: value
                for key, value in row.items()
                if str(key).strip().lower() not in known and value not in (None, "")
            }
            entries.append(
                make_entry(
                    category_id=category_id,
                    category_label=category_label,
                    source_category=str(category_raw).strip(),
                    code=code,
                    reason_text=reason,
                    priority=priority,
                    status=status,
                    attributes=attributes,
                    source=path.as_posix(),
                    source_format="csv",
                    source_row=row_number,
                )
            )
    return entries


def category_blocks(value: Any) -> list[tuple[str, Any]]:
    """Normalize supported JSON roots to ``(category, entries)`` blocks."""

    if isinstance(value, dict):
        # Exact hand-off shape from the service description.
        for key, candidate in value.items():
            if str(key).strip().lower() == "error code index":
                return category_blocks(candidate)
        if "categories" in value and isinstance(value["categories"], list):
            return category_blocks(value["categories"])
        if "category" in value and "entries" in value:
            return [(str(value.get("category") or "UNSPECIFIED"), value.get("entries"))]
        # Also accept a mapping of category label to an entry list.
        blocks: list[tuple[str, Any]] = []
        for key, candidate in value.items():
            if isinstance(candidate, list):
                blocks.append((str(key), candidate))
        if blocks:
            return blocks
        return []
    if isinstance(value, list):
        blocks = []
        for item in value:
            if not isinstance(item, dict):
                continue
            category = first_value(item, ("category", "Category", "label", "id"), "UNSPECIFIED")
            entries = first_value(item, ("entries", "Entries", "items"), [])
            blocks.append((str(category), entries))
        return blocks
    return []


def json_entries_text(text: str, source: str) -> list[dict[str, Any]]:
    try:
        value = json.loads(text)
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError(f"{source}: cannot parse JSON: {exc}") from exc
    entries: list[dict[str, Any]] = []
    for category_raw, raw_entries in category_blocks(value):
        category_text = str(category_raw).strip() or "UNSPECIFIED"
        category_id = slug(category_text)
        if not isinstance(raw_entries, list):
            continue
        for index, raw in enumerate(raw_entries, 1):
            if not isinstance(raw, dict):
                continue
            code = first_value(
                raw,
                ("Reason Code", "reason code", "reason_code", "Code", "code", "#"),
                "",
            )
            # Logout Text uses a numbered ``#`` and has no reason-code key.
            reason = first_value(
                raw,
                ("Reason Text", "reason text", "reason_text", "Logout Text", "logout text"),
                "",
            )
            priority = first_value(raw, ("Priority", "priority"), None)
            status = first_value(raw, ("SourceStatus", "Source Status", "source_status"), "")
            known = {
                "reason code",
                "reason_code",
                "code",
                "#",
                "reason text",
                "reason_text",
                "logout text",
                "priority",
                "sourcestatus",
                "source status",
                "source_status",
            }
            attributes = {
                str(key): item
                for key, item in raw.items()
                if str(key).strip().lower() not in known
            }
            entries.append(
                make_entry(
                    category_id=category_id,
                    category_label=category_text,
                    source_category=category_text,
                    code=code,
                    reason_text=reason,
                    priority=priority,
                    status=status,
                    attributes=attributes,
                    source=source,
                    source_format="json",
                    source_row=index,
                )
            )
    return entries


def json_entries(path: Path) -> list[dict[str, Any]]:
    try:
        text = path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError) as exc:
        raise ValueError(f"{path}: cannot read JSON: {exc}") from exc
    return json_entries_text(text, path.as_posix())


def discover_default_csv() -> Path:
    candidates = [
        SCRIPT_ROOT / "skill_assets" / "ODP_BinaryInterface_Jerry_01" / "poc_stage3" / "sources" / "user_supplied" / "odp_t_binary_v1_1_service_description_20260713" / "reject_reason_catalog.csv",
        SCRIPT_ROOT.parent / "skill_assets" / "ODP_BinaryInterface_Jerry_01" / "poc_stage3" / "sources" / "user_supplied" / "odp_t_binary_v1_1_service_description_20260713" / "reject_reason_catalog.csv",
        SCRIPT_ROOT / "../skill_assets/ODP_BinaryInterface_Jerry_01/poc_stage3/sources/user_supplied/odp_t_binary_v1_1_service_description_20260713/reject_reason_catalog.csv",
    ]
    for candidate in candidates:
        if candidate.is_file():
            return candidate.resolve()
    raise SystemExit("reject_reason_catalog.csv not found; pass --csv PATH")


def discover_default_json() -> list[Path]:
    """Return checked-in hand-off JSON sources, when present.

    Keeping this discovery here makes the generated index reproducible with a
    plain ``--check`` invocation after the supplied JSON has been captured.
    Callers can pass one or more ``--json`` arguments to select another set.
    """

    source_root = SCRIPT_ROOT / "odpt-automation-skill" / "sources"
    return sorted(path.resolve() for path in source_root.glob("error_code_index_user_supplied_*.json") if path.is_file())


def deduplicate(entries: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Remove byte-for-byte duplicate rows while retaining source evidence."""

    grouped: dict[tuple[Any, ...], dict[str, Any]] = {}
    for entry in entries:
        key = (
            entry["category_id"],
            entry["code"],
            entry["reason_text"],
            entry.get("priority"),
            entry.get("priority_raw"),
            json.dumps(entry.get("attributes", {}), sort_keys=True, ensure_ascii=True),
        )
        current = grouped.get(key)
        if current is None:
            current = dict(entry)
            current["evidence"] = [
                {
                    "source": entry["source"],
                    "source_format": entry["source_format"],
                    "source_row": entry.get("source_row"),
                    "source_status": entry["source_status"],
                }
            ]
            grouped[key] = current
        else:
            current.setdefault("evidence", []).append(
                {
                    "source": entry["source"],
                    "source_format": entry["source_format"],
                    "source_row": entry.get("source_row"),
                    "source_status": entry["source_status"],
                }
            )
            statuses = sorted({str(current.get("source_status", "")), str(entry.get("source_status", ""))} - {""})
            if statuses:
                current["source_statuses"] = statuses
    result = list(grouped.values())
    for entry in result:
        evidence = entry.get("evidence", [])
        if len(evidence) > 1:
            entry["duplicate_evidence_count"] = len(evidence)
    result.sort(key=lambda item: (item["category_id"], item["code"], item["reason_text"], item["source"]))
    return result


def build(csv_paths: list[Path], json_paths: list[Path]) -> dict[str, Any]:
    raw_entries: list[dict[str, Any]] = []
    source_info: list[dict[str, Any]] = []
    for path in csv_paths:
        path = path.expanduser().resolve()
        if not path.is_file():
            raise ValueError(f"input does not exist: {path}")
        parsed = csv_entries(path)
        source_format = "csv"
        raw_entries.extend(parsed)
        source_info.append(
            {
                "path": path.as_posix(),
                "sha256": sha256(path),
                "format": source_format,
                "entries": len(parsed),
                "authority": "SME_APPROVED_REFERENCE" if source_format == "csv" else "USER_SUPPLIED_JSON",
            }
        )
    for raw_path in json_paths:
        # ``--json -`` makes it possible to import a hand-off directly from a
        # pipe without first writing a copy containing unrelated conversation
        # or browser-log data.
        if str(raw_path) == "-":
            data = sys.stdin.buffer.read()
            try:
                text = data.decode("utf-8")
            except UnicodeDecodeError as exc:
                raise ValueError(f"<stdin>: cannot decode JSON as UTF-8: {exc}") from exc
            parsed = json_entries_text(text, "<stdin>")
            source_info.append(
                {
                    "path": "<stdin>",
                    "sha256": sha256_bytes(data),
                    "format": "json",
                    "entries": len(parsed),
                    "authority": "USER_SUPPLIED_JSON",
                }
            )
        else:
            path = raw_path.expanduser().resolve()
            if not path.is_file():
                raise ValueError(f"input does not exist: {path}")
            parsed = json_entries(path)
            source_info.append(
                {
                    "path": path.as_posix(),
                    "sha256": sha256(path),
                    "format": "json",
                    "entries": len(parsed),
                    "authority": "USER_SUPPLIED_JSON",
                }
            )
        raw_entries.extend(parsed)

    entries = deduplicate(raw_entries)
    categories: dict[str, dict[str, Any]] = {}
    for entry in entries:
        item = categories.setdefault(
            entry["category_id"],
            {
                "category_id": entry["category_id"],
                "category": entry["category"],
                "source_categories": set(),
                "entries": [],
            },
        )
        # Prefer the explicit label from a supplied JSON hand-off when the
        # legacy CSV uses a different word order (for example, ``Pending
        # Trade Cancel Reason`` vs ``Block Trade Pending Cancel Reason``).
        # Both labels remain available in ``source_categories``.
        if entry["source_format"] == "json":
            item["category"] = entry["category"]
        item["source_categories"].add(entry["source_category"])
        item["entries"].append(entry)

    category_list: list[dict[str, Any]] = []
    for category_id in sorted(categories):
        item = categories[category_id]
        item["source_categories"] = sorted(item["source_categories"])
        item["entries"] = sorted(item["entries"], key=lambda value: (value["code"], value["reason_text"]))
        category_list.append(item)

    pair_counter = Counter((entry["category_id"], value) for entry in raw_entries for value in entry["code_values"])
    duplicate_pairs = sorted(
        f"{category}:{code}" for (category, code), count in pair_counter.items() if count > 1
    )
    lookup: dict[str, list[dict[str, Any]]] = defaultdict(list)
    global_code_lookup: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for entry in entries:
        ref = {
            "category_id": entry["category_id"],
            "code": entry["code"],
            "reason_text": entry["reason_text"],
            "source": entry["source"],
            "source_row": entry.get("source_row"),
        }
        for code in entry["code_values"]:
            lookup[f"{entry['category_id']}:{code}"].append(ref)
            global_code_lookup[code].append(ref)

    coverage_status = "expanded_json_and_reference_csv" if json_paths else "reference_csv_only"
    notes = [
        "Category plus code is the lookup key; a code alone is ambiguous.",
        "The XML dictionary does not enumerate all business reject reasons, so this index keeps reason catalogs separate from FIX enum fields.",
    ]
    if not json_paths:
        notes.append("The expanded Error Code Index pasted in the hand-off was not present as a file; pass it with --json to include every supplied row.")
    payload: dict[str, Any] = {
        "schema_version": SCHEMA_VERSION,
        "index_kind": "odp_error_code",
        "coverage_status": coverage_status,
        "notes": notes,
        "sources": source_info,
        "stats": {
            "raw_entries": len(raw_entries),
            "entries": len(entries),
            "categories": len(category_list),
            "unique_category_code_pairs": len(pair_counter),
            "duplicate_category_code_pairs": len(duplicate_pairs),
            "duplicate_category_code_keys": duplicate_pairs,
            "unique_codes": len(global_code_lookup),
            "csv_sources": sum(1 for item in source_info if item["format"] == "csv"),
            "json_sources": sum(1 for item in source_info if item["format"] == "json"),
        },
        "categories": category_list,
        "lookup": {key: value for key, value in sorted(lookup.items())},
        "global_code_lookup": {key: value for key, value in sorted(global_code_lookup.items())},
    }
    return payload


def md_cell(value: Any) -> str:
    text = "" if value is None else str(value)
    text = text.replace("|", "\\|").replace("\n", "<br>").replace("\r", "")
    return text


def render_markdown(payload: dict[str, Any], json_path: Path) -> str:
    stats = payload["stats"]
    lines = [
        "# ODP Error Code Index",
        "",
        "This file is generated from the listed CSV/JSON sources. The source",
        "rows remain authoritative; category plus code is the stable lookup",
        "key because the same numeric code can have different meanings in",
        "different response messages.",
        "",
        f"Machine-readable index: [`{json_path.name}`]({json_path.name})",
        "",
        "## Coverage",
        "",
        f"- Status: `{payload['coverage_status']}`",
        f"- Raw entries: `{stats['raw_entries']}`",
        f"- Indexed entries: `{stats['entries']}`",
        f"- Categories: `{stats['categories']}`",
        f"- Unique category/code pairs: `{stats['unique_category_code_pairs']}`",
        f"- Duplicate category/code pairs in source rows: `{stats['duplicate_category_code_pairs']}`",
        "",
        "The expanded hand-off JSON can be imported without editing this file:",
        "",
        "```bash",
        "python3 tools/build_error_code_index.py --json path/to/error-code-index.json",
        "```",
        "",
        "## Sources",
        "",
        "| Format | Authority | Entries | SHA-256 | Path |",
        "|---|---|---:|---|---|",
    ]
    for source in payload["sources"]:
        lines.append(
            f"| `{source['format']}` | `{source['authority']}` | {source['entries']} | `{source['sha256']}` | `{source['path']}` |"
        )
    lines.extend(
        [
            "",
            "## Categories",
            "",
            "| Category ID | Category | Entries | Source categories |",
            "|---|---|---:|---|",
        ]
    )
    for category in payload["categories"]:
        lines.append(
            f"| `{category['category_id']}` | {md_cell(category['category'])} | {len(category['entries'])} | {md_cell(', '.join(category['source_categories']))} |"
        )
    lines.extend(
        [
            "",
            "## Entries",
            "",
            "Priority is numeric when the source value is numeric; unusual source values are retained as `priority_raw` in JSON.",
            "",
            "| Category | Code | Reason text | Priority | Status | Source |",
            "|---|---|---|---:|---|---|",
        ]
    )
    for category in payload["categories"]:
        for entry in category["entries"]:
            priority = entry.get("priority", entry.get("priority_raw", ""))
            status = entry.get("source_status", "")
            if entry.get("duplicate_evidence_count", 0) > 1:
                status = f"{status} (evidence x{entry['duplicate_evidence_count']})"
            lines.append(
                f"| `{entry['category_id']}` | `{md_cell(entry['code'])}` | {md_cell(entry['reason_text'])} | `{md_cell(priority)}` | `{md_cell(status)}` | `{md_cell(entry['source'])}:{entry.get('source_row', '')}` |"
            )
    lines.extend(
        [
            "",
            "## Use in Debugging",
            "",
            "- Resolve a response field with `CATEGORY_ID:CODE`; do not resolve by numeric code alone.",
            "- Treat `SME_APPROVED_REFERENCE` and `USER_SUPPLIED_JSON` as provenance labels, not interchangeable verification levels.",
            "- Keep unknown attributes (for example `FIX`, `Binary`, `Scenario`, `Remarks`, and `Col4`) when building scenario prompts.",
            "- The FIX XML enum index is separate: use `FIXODPMSG_Index.json` for wire-field enum meanings and this index for reject/status reason text.",
            "",
        ]
    )
    return "\n".join(lines)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", action="append", dest="csv_paths", help="reject catalog CSV (repeatable)")
    parser.add_argument("--json", action="append", dest="json_paths", help="expanded Error Code Index JSON (repeatable)")
    parser.add_argument("--csv-only", action="store_true", help="ignore checked-in JSON hand-off sources")
    parser.add_argument("--output-json", type=Path, default=SCRIPT_ROOT / "odpt-automation-skill" / "Error_Code_Index.json")
    parser.add_argument("--output-md", type=Path, default=SCRIPT_ROOT / "odpt-automation-skill" / "Error_Code_Index.md")
    parser.add_argument("--check", action="store_true", help="fail if generated outputs are stale")
    args = parser.parse_args(argv)

    csv_paths = [Path(path) for path in args.csv_paths] if args.csv_paths else [discover_default_csv()]
    if args.csv_only and args.json_paths:
        parser.error("--csv-only cannot be combined with --json")
    json_paths = [] if args.csv_only else (
        [Path(path) for path in args.json_paths]
        if args.json_paths is not None
        else discover_default_json()
    )
    try:
        payload = build(csv_paths, json_paths)
    except ValueError as exc:
        parser.error(str(exc))
    json_text = json.dumps(payload, ensure_ascii=False, indent=2) + "\n"
    md_text = render_markdown(payload, args.output_json)
    if args.check:
        stale = []
        if not args.output_json.is_file() or args.output_json.read_text(encoding="utf-8") != json_text:
            stale.append(str(args.output_json))
        if not args.output_md.is_file() or args.output_md.read_text(encoding="utf-8") != md_text:
            stale.append(str(args.output_md))
        if stale:
            print("STALE: " + ", ".join(stale), file=sys.stderr)
            return 1
        print("Error code index is up to date")
        return 0
    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    args.output_md.parent.mkdir(parents=True, exist_ok=True)
    args.output_json.write_text(json_text, encoding="utf-8")
    args.output_md.write_text(md_text, encoding="utf-8")
    print(f"Wrote {args.output_json} and {args.output_md}")
    summary = dict(payload["stats"])
    # The full duplicate-key list is useful in JSON but makes a command-line
    # run unreadable; report its count here and leave details in the artifact.
    summary["duplicate_category_code_keys"] = summary.pop("duplicate_category_code_keys", [])[:5]
    summary["duplicate_category_code_keys_truncated"] = payload["stats"]["duplicate_category_code_pairs"] > 5
    print(json.dumps(summary, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
