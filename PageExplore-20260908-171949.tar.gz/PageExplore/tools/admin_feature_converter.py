#!/usr/bin/env python3
r"""Convert reviewed Playwright/Admin flow evidence into WABI Gherkin.

The converter intentionally consumes a small, explicit flow manifest rather
than guessing business intent from raw Playwright locators.  It can render a
stand-alone Admin Feature or prepend Admin setup to an existing Binary
Feature.  Unknown steps and unverified evidence are retained as review
markers, never silently discarded.

Example manifest (JSON):

{
  "schema_version": 1,
  "flow_id": "admin.odp10.1.6.smp_id_list.v1",
  "case_id": "ODP10.1.6",
  "name": "Configure SMP state before binary orders",
  "channel": "hybrid",
  "evidence_status": "verified",
  "page": {
    "label": "Maintain SMP ID List",
    "route": "/UI/uiSmpIdListSearchTable",
    "profile": "pageExplore/pages/uiSmpIdListSearchTable.md"
  },
  "background": ["Load value from admin_gui_value"],
  "steps": [
    {"text": "Open browser"},
    {"text": "Login Trading Admin with:",
     "table": [["User ID", "User Password"],
                ["admin_gui_user1", "admin_gui_user1_password"]]},
    {"text": "Select Trading Admin Left Menu \"Participant>Maintain SMP ID List\""}
  ],
  "evidence": {},
  "reuse": {"keywords": ["SMP ID List"], "safe_to_reuse": false}
}

Raw ``recording.flow.json`` output is evidence for the manifest author.  It
does not contain enough field values to generate a confident Admin Feature by
itself; use ``--recording-flow`` only to produce a review draft.

The integrated Playwright MCP stage uses rollback validation: it rejects a
submitted maker request (or cancels before save) after validating the path. A
final approval may be tagged ``mcp_execution=deferred_to_feature`` in the
manifest; the converter emits that semantic Approve step while omitting the
MCP-only cleanup action.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
from pathlib import Path
from typing import Any, Mapping

try:
    from admin_page_contract import (
        PageContractError,
        format_issues as format_page_contract_issues,
        repair_page_contract,
        validate_page_contract,
    )
except ModuleNotFoundError:  # pragma: no cover - package-style test imports
    from tools.admin_page_contract import (
        PageContractError,
        format_issues as format_page_contract_issues,
        repair_page_contract,
        validate_page_contract,
    )


SCHEMA_VERSION = 1
VALID_CHANNELS = {"admin", "hybrid"}
VALID_EVIDENCE = {"verified", "observed", "inferred"}
SECRET_HEADER_RE = re.compile(r"(?:password|passwd|secret|token|api[_ -]?key)", re.I)
DEFAULT_PAGE_EXPLORE_ROOT = Path(__file__).resolve().parents[1] / "pageExplore"

# These prefixes mirror the executable Admin vocabulary.  The complete
# signature list is loaded from Step_Index.json when available; the prefixes
# make validation useful even when the snapshot has not been regenerated.
ADMIN_PREFIXES = (
    "Open browser",
    "Login Trading Admin with:",
    "Clear Alert If Exist",
    "Save current browser to ",
    "Switch browser to ",
    "Close the browser",
    "Select Trading Admin Left Menu ",
    "Search in Trading Admin ",
    "Set Trading Admin ",
    "Save Trading Admin ",
    "Check Trading Admin ",
    "Check table ",
    "Double click table ",
    "Select table ",
    "Set table ",
    "Add Table Item in ",
    "Modify Table Item in ",
    "Modify Auto-sort Table Item in ",
    "Modify Table in Admin GUI ",
    "Scroll detail page ",
    "Scroll \"",
    "Select effective type ",
    "Check effective ",
    "Click button ",
    "Check the confirm message ",
    "Check field ",
    "Check massage ",
    "Check Dropdown List ",
    "Check text input ",
    "Go to Edit reference ",
    "Click \"up\" arrow",
    "Click \"down\" arrow",
    "Assign ",
    "Generate ",
    "Get value ",
    "Admin GUI ",
    "Import file ",
    "CONNECT WS with:",
    "CLOSE CONNECT with:",
    "add new ",
    "update \"",
    "move the trading state ",
    "set the trading state ",
    "Create instrument series if not exists :",
    "Create Combo if not exists :",
    "Approve if updated with :",
    "Screenshot",
    "Wait ",
    "Load value from ",
    "Load object description from ",
    "Load FIX dumpfile ",
    "Save FIX dumpfile ",
    "Replace the value of ",
    "Change \"",
)


class ConversionError(ValueError):
    """Raised for malformed flow manifests or unsafe composition."""


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_json(path: Path) -> dict[str, Any]:
    if not path.is_file():
        raise ConversionError(f"input does not exist: {path}")
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise ConversionError(f"cannot parse JSON: {path}") from error
    if not isinstance(value, dict):
        raise ConversionError(f"JSON root must be an object: {path}")
    return value


def write_json_atomic(path: Path, value: Mapping[str, Any]) -> None:
    """Replace one manifest without exposing a partially written JSON file."""

    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp-{os.getpid()}")
    try:
        temporary.write_text(
            json.dumps(value, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        os.chmod(temporary, 0o600)
        temporary.replace(path)
    finally:
        if temporary.exists():
            temporary.unlink()


def clean_text(value: Any, field: str, limit: int = 2000) -> str:
    text = "" if value is None else str(value)
    text = text.replace("\r\n", "\n").replace("\r", "\n").strip()
    if not text:
        raise ConversionError(f"{field} must not be empty")
    if len(text) > limit:
        raise ConversionError(f"{field} exceeds {limit} characters")
    return text


def clean_line_text(value: Any, field: str, limit: int = 2000) -> str:
    """Validate text that will occupy one Gherkin line."""

    text = clean_text(value, field, limit)
    if "\n" in text:
        raise ConversionError(f"{field} must be a single line")
    return text


def normalize_tag(value: Any) -> str:
    """Return a valid single-line Gherkin tag."""

    tag = clean_line_text(value, "tag", 200)
    if not tag.startswith("@"):
        tag = "@" + tag
    # Existing ODP features use metadata tags such as @FEATURE=Binary and
    # @CASE=ODP10.1.6. Keep the validation strict about whitespace/control
    # characters while allowing the project-supported metadata punctuation.
    if not re.fullmatch(r"@[A-Za-z0-9_.:=+\-]+", tag):
        raise ConversionError(f"tag contains unsupported characters: {tag}")
    return tag


def normalize_step_text(value: str) -> str:
    text = value.strip()
    text = re.sub(r"^(?:Given|When|Then|And|But|\*)\s+", "", text, flags=re.I)
    return text.strip()


def signature_source_kinds(item: Mapping[str, Any]) -> set[str]:
    kinds = {str(item.get("source_kind", ""))}
    kinds.update(str(kind) for kind in (item.get("source_kinds", []) or []))
    return kinds


def signature_sources(item: Mapping[str, Any]) -> list[str]:
    sources = [str(item.get("source", ""))]
    for evidence in item.get("evidence", []) or []:
        if isinstance(evidence, Mapping):
            sources.append(str(evidence.get("source", "")))
    return [source.replace("\\", "/") for source in sources if source]


def signature_authorities(item: Mapping[str, Any]) -> set[str]:
    authorities = {str(item.get("authority", ""))}
    authorities.update(str(value) for value in (item.get("authorities", []) or []))
    return authorities


def signature_priority(item: Mapping[str, Any]) -> int:
    """Prefer current-project custom steps, then other runtime signatures."""

    is_custom_step = any(
        source.startswith("features/customized_steps/")
        or "/features/customized_steps/" in source
        for source in signature_sources(item)
    )
    authorities = signature_authorities(item)
    if is_custom_step and "runtime_source" in authorities:
        return 0
    if "runtime_source" in authorities:
        return 1
    return 2


def signature_requires_table(item: Mapping[str, Any]) -> bool:
    arguments = [str(value).lower() for value in (item.get("arguments", []) or [])]
    if any(value in {"table", "usertable"} for value in arguments):
        return True
    try:
        argument_count = int(item.get("argument_count", 0))
        capture_count = re.compile(
            str(item.get("pattern", "")).replace(r"\z", r"\Z")
        ).groups
        # Cucumber passes a trailing DataTable/DocString in addition to regex
        # captures. In this Admin vocabulary that extra structured argument is
        # the table the manifest must provide.
        return argument_count > capture_count
    except (TypeError, ValueError, re.error):
        return False


def signature_matches(normalized: str, item: Mapping[str, Any]) -> bool:
    """Match a trusted Step_Index pattern, with a conservative fallback.

    Most runtime Ruby step expressions are also valid Python regular
    expressions.  Matching the complete expression is needed for constrained
    alternations such as ``(Current Record|Update Record)``; the historical
    fragment-only matcher rejected those valid executable steps.  Keep the
    fragment matcher for the small number of Ruby-only expressions that
    Python cannot compile.
    """

    pattern = str(item.get("pattern", ""))
    try:
        if re.fullmatch(pattern.replace(r"\z", r"\Z"), normalized):
            return True
    except re.error:
        pass

    literal = re.sub(r"^/|/$", "", pattern)
    literal = re.sub(r"\(\?[imsx-]+\)", "", literal)
    literal = literal.replace("\\/", "/")
    literal = re.sub(r"\^|\$", "", literal)
    fragments = [
        part
        for part in re.split(
            r"\(\.\*\??\)|\.\*\??|\(\.\+\??\)|\.\+\??|\\\.", literal
        )
        if part
    ]
    fragments = [re.sub(r"\\(.)", r"\1", part) for part in fragments]
    return bool(fragments) and all(
        fragment.strip() in normalized for fragment in fragments if fragment.strip()
    )


def match_known_step(text: str, signatures: list[dict[str, Any]]) -> dict[str, Any]:
    normalized = normalize_step_text(text)

    # Step_Index is the executable authority. Preserve its original ordering
    # within each priority tier so duplicate signatures remain deterministic.
    prioritized = sorted(
        enumerate(signatures), key=lambda pair: (signature_priority(pair[1]), pair[0])
    )
    for _, item in prioritized:
        if not signature_source_kinds(item).intersection({"admin_gui", "shared_public"}):
            continue
        if not signature_matches(normalized, item):
            continue
        priority = signature_priority(item)
        return {
            "known": True,
            "match_source": (
                "step_index_customized_runtime"
                if priority == 0
                else "step_index_runtime"
                if priority == 1
                else "step_index_snapshot"
            ),
            "signature": str(item.get("signature", "")),
            "pattern": str(item.get("pattern", "")),
            "source": str(item.get("source", "")),
            "line": item.get("line"),
            "authority": str(item.get("authority", "")),
            "source_kind": str(item.get("source_kind", "")),
            "arguments": [str(value) for value in (item.get("arguments", []) or [])],
            "argument_count": item.get("argument_count"),
            "requires_table": signature_requires_table(item),
        }

    # Prefixes are a degraded-mode aid only when Step_Index is unavailable.
    # With a populated index, accepting a broad prefix would hide a missing or
    # invented UAT step instead of producing the required review marker.
    if not signatures:
        prefix = next(
            (
                value
                for value in ADMIN_PREFIXES
                if normalized == value.rstrip() or normalized.startswith(value)
            ),
            None,
        )
        if prefix:
            return {
                "known": True,
                "match_source": "fallback_admin_prefix",
                "prefix": prefix,
            }

    return {"known": False, "match_source": "unknown"}


def is_known_step(text: str, signatures: list[dict[str, Any]]) -> bool:
    return bool(match_known_step(text, signatures)["known"])


def load_signatures(path: Path | None) -> list[dict[str, Any]]:
    if path is None or not path.is_file():
        return []
    payload = load_json(path)
    steps = payload.get("steps", [])
    return steps if isinstance(steps, list) else []


def looks_like_placeholder(value: str) -> bool:
    value = value.strip()
    return (
        not value
        or value.startswith("<")
        or value.startswith("${")
        or value.startswith("ENV[")
        or value.endswith("_password")
        or value.endswith("_token")
        or value.startswith("password_")
    )


def sanitize_cell(value: Any, header: str, reviews: list[str], location: str) -> str:
    text = str(value if value is not None else "").replace("\n", " ").strip()
    if "|" in text:
        text = text.replace("|", "\\|")
    if SECRET_HEADER_RE.search(header) and text and not looks_like_placeholder(text):
        reviews.append(f"SECRET_LITERAL_REDACTED:{location}")
        return "<REVIEW_SECRET>"
    return text


def normalize_table(raw: Any, reviews: list[str], location: str) -> list[list[str]]:
    if raw is None:
        return []
    if isinstance(raw, str):
        rows = []
        for line in raw.splitlines():
            line = line.strip()
            if not line:
                continue
            if not (line.startswith("|") and line.endswith("|")):
                raise ConversionError(f"{location} string table must contain pipe rows")
            rows.append([cell.strip() for cell in line.strip("|").split("|")])
        return sanitize_rows(rows, reviews, location)
    if not isinstance(raw, list) or not raw:
        raise ConversionError(f"{location} table must be a non-empty array")
    if all(isinstance(row, Mapping) for row in raw):
        headers: list[str] = []
        for row in raw:
            for key in row:
                key_text = str(key)
                if key_text not in headers:
                    headers.append(key_text)
        result = [headers]
        for row_index, row in enumerate(raw, 1):
            result.append(
                [
                    sanitize_cell(row.get(header, ""), header, reviews, f"{location}[{row_index}].{header}")
                    for header in headers
                ]
            )
        return result
    if all(isinstance(row, list) for row in raw):
        width = max(len(row) for row in raw)
        rows = [list(row) + [""] * (width - len(row)) for row in raw]
        return sanitize_rows(rows, reviews, location)
    raise ConversionError(f"{location} table rows must all be objects or arrays")


def sanitize_rows(rows: list[list[Any]], reviews: list[str], location: str) -> list[list[str]]:
    """Normalize pipe cells and redact secret columns in array tables too."""

    if not rows:
        return []
    headers = [str(value or "").strip() for value in rows[0]]
    result: list[list[str]] = []
    for row_index, row in enumerate(rows):
        result.append(
            [
                sanitize_cell(
                    cell,
                    headers[column] if row_index > 0 and headers[column] else f"column_{column + 1}",
                    reviews,
                    f"{location}[{row_index + 1}][{column + 1}]",
                )
                for column, cell in enumerate(row)
            ]
        )
    width = len(result[0])
    if width == 0 or any(len(row) != width for row in result):
        raise ConversionError(f"{location} table rows must have a consistent width")
    return result


def normalize_step(raw: Any, index: int, signatures: list[dict[str, Any]], reviews: list[str]) -> dict[str, Any]:
    mcp_execution = ""
    if isinstance(raw, str):
        text = clean_line_text(raw, f"steps[{index}]")
        table = []
    elif isinstance(raw, Mapping):
        text = clean_line_text(raw.get("text", raw.get("step", "")), f"steps[{index}].text")
        table = normalize_table(raw.get("table"), reviews, f"steps[{index}].table")
        mcp_execution = str(raw.get("mcp_execution", "")).strip()
        if mcp_execution not in {"", "validated_read_only", "deferred_to_feature"}:
            raise ConversionError(
                f"steps[{index}].mcp_execution must be validated_read_only or deferred_to_feature"
            )
    else:
        raise ConversionError(f"steps[{index}] must be a string or object")

    match = match_known_step(text, signatures)
    if not match["known"]:
        reviews.append(f"UNKNOWN_STEP:{index}:{normalize_step_text(text)[:160]}")
    elif match.get("requires_table") and not table:
        # Matching a Ruby expression is insufficient when the step definition
        # also requires a Cucumber DataTable.  Literal operations such as
        # ``Approve if updated with :`` have no visible capture groups, so a
        # missing table otherwise survives until runtime.
        reviews.append(f"MISSING_TABLE:{index}:{normalize_step_text(text)[:160]}")
    normalized = {
        "text": normalize_step_text(text),
        "table": table,
        "known": match["known"],
        "match": match,
    }
    if mcp_execution:
        normalized["mcp_execution"] = mcp_execution
    return normalized


def validate_admin_login_shapes(
    steps_by_section: list[tuple[str, list[dict[str, Any]]]], reviews: list[str]
) -> None:
    """Flag a multi-user login table instead of silently emitting a bad flow.

    The executable Admin login step owns one browser session.  A table with
    multiple user rows attempt to reuse that session after the first
    login has navigated away from the login form.  Keep the finding as a review
    reason so a human can split the flow into one Open/Login/Save sequence per
    user without the converter guessing at browser lifecycle details.
    """

    for section, steps in steps_by_section:
        for index, step in enumerate(steps):
            if step.get("text") != "Login Trading Admin with:":
                continue
            rows = step.get("table") or []
            if len(rows) < 3:
                continue
            # Accept the header spellings used by both the generated corpus
            # and hand-authored manifests (User ID, UserID, user_id, User,
            # or ID) while leaving the table's original spelling intact.
            headers = [
                re.sub(r"[\s_-]+", "", str(item).strip().lower())
                for item in rows[0]
            ]
            user_index = next(
                (
                    column
                    for column, header in enumerate(headers)
                    if header in {"userid", "user", "id"}
                ),
                None,
            )
            if user_index is None:
                continue
            users = [
                str(row[user_index]).strip()
                for row in rows[1:]
                if user_index < len(row) and str(row[user_index]).strip()
            ]
            # The executable step historically permits repeated rows for one
            # user when an expected login error is being checked.  The unsafe
            # shape is a table that tries to establish multiple sessions, so
            # compare distinct user identities rather than raw row count.
            if len(set(users)) > 1:
                reviews.append(
                    "MULTI_USER_LOGIN_REQUIRES_SEPARATE_BROWSER_SESSIONS:"
                    f"{section}[{index}]"
                )


def normalize_manifest(raw: Mapping[str, Any], signatures: list[dict[str, Any]]) -> tuple[dict[str, Any], list[str]]:
    try:
        schema_version = int(raw.get("schema_version", 0))
    except (TypeError, ValueError) as error:
        raise ConversionError(f"schema_version must be {SCHEMA_VERSION}") from error
    if schema_version != SCHEMA_VERSION:
        raise ConversionError(f"schema_version must be {SCHEMA_VERSION}")
    case_id = clean_line_text(raw.get("case_id"), "case_id", 200)
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.:-]{0,199}", case_id):
        raise ConversionError("case_id contains unsupported characters")
    channel = str(raw.get("channel", "admin")).strip().lower()
    if channel not in VALID_CHANNELS:
        raise ConversionError(f"channel must be one of {sorted(VALID_CHANNELS)}")
    evidence_status = str(raw.get("evidence_status", "inferred")).strip().lower()
    if evidence_status not in VALID_EVIDENCE:
        raise ConversionError(f"evidence_status must be one of {sorted(VALID_EVIDENCE)}")
    reviews: list[str] = []
    if not signatures:
        reviews.append("STEP_INDEX_UNAVAILABLE:PREFIX_FALLBACK_IS_NON_AUTHORITATIVE")
    raw_background = raw.get("background", [])
    if not isinstance(raw_background, list):
        raise ConversionError("background must be an array")
    background = [normalize_step(item, index, signatures, reviews) for index, item in enumerate(raw_background)]
    raw_steps = raw.get("steps", [])
    if not isinstance(raw_steps, list) or not raw_steps:
        raise ConversionError("steps must be a non-empty array")
    steps = [normalize_step(item, index, signatures, reviews) for index, item in enumerate(raw_steps)]
    validate_admin_login_shapes(
        [("background", background), ("steps", steps)],
        reviews,
    )
    if evidence_status != "verified":
        reviews.append(f"EVIDENCE_STATUS:{evidence_status}")
    raw_review = raw.get("review", []) or []
    if not isinstance(raw_review, list):
        raise ConversionError("review must be an array")
    raw_tags = raw.get("tags", []) or []
    if not isinstance(raw_tags, list):
        raise ConversionError("tags must be an array")
    for value in raw_review:
        reviews.append(f"SOURCE_REVIEW:{clean_text(value, 'review item', 500)}")
    manifest = {
        "schema_version": SCHEMA_VERSION,
        "case_id": case_id,
        "name": clean_line_text(raw.get("name", case_id), "name", 500),
        "channel": channel,
        "evidence_status": evidence_status,
        "tags": [normalize_tag(tag) for tag in raw_tags if str(tag).strip()],
        "background": background,
        "steps": steps,
        "evidence": raw.get("evidence", {}) if isinstance(raw.get("evidence", {}), Mapping) else {},
        "reviews": sorted(set(reviews)),
    }
    return manifest, manifest["reviews"]


def render_table(rows: list[list[str]], indent: str = "\t") -> list[str]:
    result: list[str] = []
    for row in rows:
        result.append(indent + "| " + " | ".join(str(cell) for cell in row) + " |")
    return result


def render_step(step: Mapping[str, Any], indent: str = "\t") -> list[str]:
    lines = [indent + "* " + str(step["text"])]
    rows = step.get("table") or []
    if rows:
        lines.extend(render_table(rows, indent + "\t"))
    return lines


def feature_tags(
    manifest: Mapping[str, Any],
    review: list[str],
    *,
    output_channel: str | None = None,
) -> list[str]:
    tags = [normalize_tag(tag) for tag in manifest.get("tags", []) if str(tag).strip()]
    channel = output_channel or str(manifest.get("channel", "admin"))
    if output_channel == "admin":
        # A source Hybrid manifest may carry Binary composition tags.  They do
        # not describe the independent Admin artifact and must not leak into
        # the first validation target.
        tags = [
            tag
            for tag in tags
            if not tag.startswith("@FEATURE=") and tag != "@ADMIN_SETUP"
        ]
    if channel == "admin" and not any(
        tag.startswith("@FEATURE=") for tag in tags
    ):
        tags.append("@FEATURE=AdminGUI")
    if not any(tag.startswith("@CASE=") for tag in tags):
        tags.append(f"@CASE={manifest['case_id']}")
    if channel == "hybrid" and "@ADMIN_SETUP" not in tags:
        tags.append("@ADMIN_SETUP")
    if review and "@REVIEW" not in tags:
        tags.append("@REVIEW")
    return tags


def evidence_comments(manifest: Mapping[str, Any], reviews: list[str]) -> list[str]:
    evidence = manifest.get("evidence", {})
    comments = [
        "# Generated by tools/admin_feature_converter.py",
        f"# Evidence status: {manifest.get('evidence_status', 'inferred')}",
    ]
    if isinstance(evidence, Mapping):
        for key in ("playwright_run", "recording_flow", "grid_trace", "grid_summary"):
            value = evidence.get(key)
            if value:
                # Evidence comments are useful for traceability, but a raw
                # recording path can contain a run UUID or an accidental line
                # break. Keep those details in the JSON report instead.
                safe_value = re.sub(
                    r"[0-9a-f]{8}-[0-9a-f-]{27,}", "<uuid>", str(value), flags=re.I
                )
                safe_value = " ".join(safe_value.split())
                comments.append(f"# Evidence {key}: {safe_value[:500]}")
    for item in reviews:
        comments.append(f"# REVIEW: {item}")
    return comments


def render_standalone(manifest: Mapping[str, Any], reviews: list[str]) -> str:
    # A Hybrid manifest is deliberately rendered as an Admin-only artifact in
    # standalone mode.  Its original ``channel`` remains available in the
    # conversion report, while the executable Feature gets the Admin runtime
    # tag and never inherits ``@ADMIN_SETUP`` from the later non-Admin phase.
    tags = feature_tags(manifest, reviews, output_channel="admin")
    lines = tags + [f"Feature: {manifest['name']}"]
    background = manifest.get("background", [])
    if background:
        lines.extend(["", "Background:"])
        for step in background:
            lines.extend(render_step(step))
    lines.extend(["", *evidence_comments(manifest, reviews), f"Scenario: {manifest['name']}"])
    for step in manifest["steps"]:
        lines.extend(render_step(step))
    return "\n".join(lines) + "\n"


def split_gherkin_row(value: str) -> list[str]:
    """Split one Gherkin DataTable row while retaining escaped pipes."""

    text = value.strip()
    if not (text.startswith("|") and text.endswith("|")):
        raise ConversionError("DataTable row must begin and end with a pipe")
    cells: list[str] = []
    current: list[str] = []
    escaped = False
    for character in text[1:-1]:
        if escaped:
            current.append(character)
            escaped = False
        elif character == "\\":
            escaped = True
            current.append(character)
        elif character == "|":
            cells.append("".join(current).strip())
            current = []
        else:
            current.append(character)
    if escaped:
        current.append("\\")
    cells.append("".join(current).strip())
    return cells


def parse_admin_feature_behavior(feature_text: str) -> dict[str, Any]:
    """Extract executable Admin behavior without treating prose as steps."""

    sections: dict[str, list[dict[str, Any]]] = {"background": [], "steps": []}
    current_section: str | None = None
    current_step: dict[str, Any] | None = None
    scenario_count = 0
    tags: list[str] = []

    for line_number, line in enumerate(feature_text.splitlines(), 1):
        stripped = line.strip()
        if stripped.startswith("@"):
            tags.extend(token for token in stripped.split() if token.startswith("@"))
            current_step = None
            continue
        if re.match(r"^Background\s*:", stripped, flags=re.I):
            current_section = "background"
            current_step = None
            continue
        if re.match(r"^(?:Scenario|Scenario Outline)\s*:", stripped, flags=re.I):
            scenario_count += 1
            current_section = "steps"
            current_step = None
            continue
        step_match = re.match(
            r"^(?:\*|Given|When|Then|And|But)\s+(.+?)\s*$",
            stripped,
            flags=re.I,
        )
        if step_match and current_section:
            current_step = {
                "text": normalize_step_text(step_match.group(1)),
                "table": [],
                "line": line_number,
            }
            sections[current_section].append(current_step)
            continue
        if stripped.startswith("|") and stripped.endswith("|") and current_step:
            current_step["table"].append(split_gherkin_row(stripped))
            continue
        if stripped and not stripped.startswith("#"):
            current_step = None

    return {
        **sections,
        "tags": tags,
        "scenario_count": scenario_count,
    }


def expected_admin_behavior(manifest: Mapping[str, Any]) -> dict[str, Any]:
    def compact(step: Mapping[str, Any]) -> dict[str, Any]:
        return {
            "text": str(step["text"]),
            "table": [list(row) for row in (step.get("table") or [])],
        }

    return {
        "background": [compact(step) for step in manifest.get("background", [])],
        "steps": [compact(step) for step in manifest.get("steps", [])],
    }


def compare_admin_feature_to_flow(
    manifest: Mapping[str, Any], feature_text: str
) -> dict[str, Any]:
    """Require the standalone Feature to express exactly the MCP hand-off."""

    actual = parse_admin_feature_behavior(feature_text)
    expected = expected_admin_behavior(manifest)
    mismatches: list[dict[str, Any]] = []
    for section in ("background", "steps"):
        actual_steps = [
            {"text": step["text"], "table": step["table"]}
            for step in actual[section]
        ]
        if actual_steps != expected[section]:
            mismatches.append(
                {
                    "section": section,
                    "expected_count": len(expected[section]),
                    "actual_count": len(actual_steps),
                    "first_difference": next(
                        (
                            index
                            for index, (left, right) in enumerate(
                                zip(expected[section], actual_steps), 1
                            )
                            if left != right
                        ),
                        min(len(expected[section]), len(actual_steps)) + 1,
                    ),
                }
            )

    tags = set(actual["tags"])
    if "@FEATURE=AdminGUI" not in tags:
        mismatches.append({"section": "tags", "reason": "missing @FEATURE=AdminGUI"})
    forbidden_tags = sorted(
        tag
        for tag in tags
        if tag == "@ADMIN_SETUP" or tag == "@REVIEW" or tag.startswith("@FEATURE=Binary")
    )
    if forbidden_tags:
        mismatches.append(
            {"section": "tags", "reason": "forbidden standalone Admin tag", "tags": forbidden_tags}
        )
    if actual["scenario_count"] != 1:
        mismatches.append(
            {
                "section": "structure",
                "reason": "standalone Admin Feature must contain exactly one Scenario",
                "actual_count": actual["scenario_count"],
            }
        )

    return {
        "aligned": not mismatches,
        "mode": "standalone_admin_exact",
        "flow_step_count": len(expected["background"]) + len(expected["steps"]),
        "feature_step_count": len(actual["background"]) + len(actual["steps"]),
        "mismatches": mismatches,
    }


def strip_feature_comments(lines: list[str]) -> list[str]:
    # Keep all comments from the base feature.  This helper exists only to
    # identify the first executable scenario line without parsing Gherkin.
    return lines


def compose_hybrid(base_text: str, manifest: Mapping[str, Any], reviews: list[str]) -> str:
    if "Feature:" not in base_text or "Scenario:" not in base_text:
        raise ConversionError("base feature must contain Feature: and Scenario:")
    lines = strip_feature_comments(base_text.splitlines())
    scenario_index = next((i for i, line in enumerate(lines) if re.match(r"^\s*Scenario:", line)), None)
    if scenario_index is None:
        raise ConversionError("base feature has no Scenario:")

    # Add tags immediately above the first Feature/Scenario metadata block.
    existing_tags = {line.strip() for line in lines[:scenario_index] if line.strip().startswith("@")}
    additions = [tag for tag in feature_tags(manifest, reviews) if tag not in existing_tags]
    insert_at = next((i for i, line in enumerate(lines[:scenario_index]) if line.startswith("Feature:")), 0)
    lines[insert_at:insert_at] = additions
    scenario_index += len(additions)

    # Keep manifest background steps in Gherkin Background when the base has
    # one. They are setup shared by the scenario, not Binary assertions.
    background_steps = list(manifest.get("background", []))
    if background_steps:
        background_index = next(
            (
                i
                for i in range(scenario_index)
                if re.match(r"^\s*Background:\s*$", lines[i])
            ),
            None,
        )
        rendered_background: list[str] = []
        for step in background_steps:
            rendered_background.extend(render_step(step))
        if background_index is None:
            lines[scenario_index:scenario_index] = ["", "Background:", *rendered_background, ""]
            scenario_index += len(rendered_background) + 3
        else:
            # Insert immediately before Scenario; this keeps any existing
            # Background steps and comments intact while preserving order.
            lines[scenario_index:scenario_index] = rendered_background + [""]
            scenario_index += len(rendered_background) + 1

    # Insert Admin action steps immediately before Set ISODP true when
    # present; otherwise insert after the Scenario declaration.
    insertion = next(
        (i for i in range(scenario_index + 1, len(lines)) if "Set ISODP true" in lines[i]),
        scenario_index + 1,
    )
    setup_lines: list[str] = [""] + evidence_comments(manifest, reviews)
    for step in manifest.get("steps", []):
        setup_lines.extend(render_step(step))
    setup_lines.append("")
    lines[insertion:insertion] = setup_lines
    return "\n".join(lines).rstrip() + "\n"


def summarize_recording_flow(path: Path) -> dict[str, Any]:
    payload = load_json(path)
    actions = payload.get("actions", [])
    pages = payload.get("pages", [])
    warnings = payload.get("warnings", [])
    if not isinstance(actions, list):
        actions = []
    method_counts: dict[str, int] = {}
    for action in actions:
        if isinstance(action, Mapping):
            name = str(action.get("action", "unknown"))
            method_counts[name] = method_counts.get(name, 0) + 1
    return {
        "path": path.as_posix(),
        "sha256": sha256(path),
        "schema_version": payload.get("schema_version"),
        "pages": len(pages) if isinstance(pages, list) else 0,
        "actions": len(actions),
        "action_counts": method_counts,
        "warnings": list(warnings) if isinstance(warnings, list) else [],
    }


def review_draft_from_recording(path: Path, case_id: str) -> dict[str, Any]:
    summary = summarize_recording_flow(path)
    steps = [
        {
            "text": f"TODO: map {summary['actions']} Playwright actions to reviewed Admin steps",
        }
    ]
    # The placeholder is deliberately an unknown step, causing @REVIEW. It
    # makes the missing semantic mapping visible without emitting a false
    # executable action.
    return {
        "schema_version": SCHEMA_VERSION,
        "case_id": case_id,
        "name": f"Admin setup review for {case_id}",
        "channel": "admin",
        "evidence_status": "observed",
        "evidence": {"recording_flow": str(path), "recording_summary": summary},
        "steps": steps,
        "review": ["RAW_RECORDING_REQUIRES_SEMANTIC_STEP_MAPPING"],
    }


def write_report(
    path: Path,
    manifest: Mapping[str, Any],
    reviews: list[str],
    output: Path,
    base: Path | None,
    *,
    render_mode: str,
    page_contract_issues: list[dict[str, Any]] | None = None,
) -> None:
    step_matches = []
    for section in ("background", "steps"):
        for index, step in enumerate(manifest.get(section, [])):
            match = step.get("match", {})
            step_matches.append(
                {
                    "section": section,
                    "index": index,
                    "text": step["text"],
                    "mcp_execution": step.get("mcp_execution"),
                    **match,
                }
            )
    report = {
        "schema_version": SCHEMA_VERSION,
        "case_id": manifest["case_id"],
        "channel": manifest["channel"],
        "render_mode": render_mode,
        "evidence_status": manifest["evidence_status"],
        "output": output.as_posix(),
        "base_feature": base.as_posix() if base else None,
        "review_required": bool(reviews),
        "review_reasons": reviews,
        "step_count": len(manifest["steps"]),
        "deferred_to_feature_steps": [
            item["text"]
            for item in step_matches
            if item.get("mcp_execution") == "deferred_to_feature"
        ],
        "unknown_steps": [item["text"] for item in step_matches if not item["known"]],
        "step_matches": step_matches,
        "evidence": manifest.get("evidence", {}),
        "page_contract": {
            "valid": not page_contract_issues,
            "issues": page_contract_issues or [],
        },
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--flow", help="normalized Admin flow manifest JSON")
    parser.add_argument("--recording-flow", help="raw recording.flow.json; produces a review draft")
    parser.add_argument("--case-id", help="case ID for --recording-flow")
    parser.add_argument("--base-feature", help="existing Binary feature for hybrid composition")
    parser.add_argument(
        "--standalone-admin",
        action="store_true",
        help="render a Hybrid/Admin manifest as an independent Admin GUI Feature",
    )
    parser.add_argument(
        "--verify-feature",
        help="verify that an existing standalone Admin Feature exactly matches --flow",
    )
    parser.add_argument("--output", help="output .feature path")
    parser.add_argument("--report", help="optional conversion report JSON")
    parser.add_argument("--step-index", default="odpt-automation-skill/Step_Index.json")
    parser.add_argument(
        "--page-explore-root",
        default=str(DEFAULT_PAGE_EXPLORE_ROOT),
        help="PageExplore root containing sitemap.md and pages/ profiles",
    )
    parser.add_argument(
        "--normalize-page-contract",
        action="store_true",
        help=(
            "repair uniquely provable route/profile/menu mismatches in --flow in place, "
            "then report any unresolved page-contract issue"
        ),
    )
    parser.add_argument("--strict", action="store_true", help="fail instead of emitting @REVIEW for unknown steps")
    parser.add_argument(
        "--validate-only",
        action="store_true",
        help="validate and normalize the manifest without rendering a Feature",
    )
    parser.add_argument(
        "--semantic-strict",
        action="store_true",
        help="fail validation for semantic/runtime issues while allowing pre-promotion evidence status",
    )
    args = parser.parse_args()

    if bool(args.flow) == bool(args.recording_flow):
        parser.error("provide exactly one of --flow or --recording-flow")
    if args.standalone_admin and args.base_feature:
        parser.error("--standalone-admin cannot be combined with --base-feature")
    if args.verify_feature and args.recording_flow:
        parser.error("--verify-feature requires --flow")
    if args.verify_feature and (args.output or args.base_feature):
        parser.error("--verify-feature cannot be combined with --output or --base-feature")
    if args.normalize_page_contract and args.recording_flow:
        parser.error("--normalize-page-contract requires --flow")
    if args.normalize_page_contract and (
        args.output or args.report or args.base_feature or args.verify_feature or args.validate_only
    ):
        parser.error("--normalize-page-contract is a standalone in-place operation")
    if args.recording_flow:
        if not args.case_id:
            parser.error("--case-id is required with --recording-flow")
        raw_manifest = review_draft_from_recording(Path(args.recording_flow), args.case_id)
    else:
        raw_manifest = load_json(Path(args.flow))

    page_explore_root = Path(args.page_explore_root)
    if args.normalize_page_contract:
        try:
            repaired, repairs = repair_page_contract(raw_manifest, page_explore_root)
            if repairs:
                write_json_atomic(Path(args.flow), repaired)
            issues = validate_page_contract(repaired, page_explore_root)
        except PageContractError as error:
            raise ConversionError(f"PageExplore contract unavailable: {error}") from error
        print(
            json.dumps(
                {
                    "normalized": bool(repairs),
                    "repairs": repairs,
                    "valid": not issues,
                    "issues": issues,
                },
                ensure_ascii=False,
            )
        )
        return 0 if not issues else 2

    try:
        page_contract_issues = validate_page_contract(raw_manifest, page_explore_root)
    except PageContractError as error:
        page_contract_issues = [{"code": "PAGEEXPLORE_CONTRACT_UNAVAILABLE"}]
        page_contract_failure = str(error)
    else:
        page_contract_failure = ""

    step_index = Path(args.step_index)
    signatures = load_signatures(step_index)

    manifest, reviews = normalize_manifest(raw_manifest, signatures)
    reviews.extend(
        f"PAGE_CONTRACT:{item}"
        for item in format_page_contract_issues(page_contract_issues)
    )
    if page_contract_failure:
        reviews.append("PAGE_CONTRACT_SOURCE_UNAVAILABLE")
    reviews = sorted(set(reviews))
    manifest["reviews"] = reviews
    semantic_reviews = [
        item for item in reviews if not item.startswith("EVIDENCE_STATUS:")
    ]
    if args.semantic_strict and semantic_reviews:
        raise ConversionError(
            "semantic validation blocked: " + ", ".join(semantic_reviews)
        )
    if args.strict and reviews:
        raise ConversionError("strict conversion blocked: " + ", ".join(reviews))

    if args.verify_feature:
        feature_path = Path(args.verify_feature)
        if not feature_path.is_file():
            raise ConversionError(f"Feature does not exist: {feature_path}")
        comparison = compare_admin_feature_to_flow(
            manifest,
            feature_path.read_text(encoding="utf-8"),
        )
        print(json.dumps(comparison, ensure_ascii=False))
        if not comparison["aligned"]:
            raise ConversionError(
                "standalone Admin Feature behavior diverges from the MCP flow"
            )
        return 0

    if args.validate_only:
        print(
            json.dumps(
                {
                    "valid": not reviews,
                    "semantic_valid": not semantic_reviews,
                    "case_id": manifest["case_id"],
                    "step_count": len(manifest["steps"]),
                    "review_reasons": reviews,
                    "semantic_review_reasons": semantic_reviews,
                    "page_contract": {
                        "valid": not page_contract_issues,
                        "issues": page_contract_issues,
                    },
                },
                ensure_ascii=False,
            )
        )
        return 0

    if not args.output:
        parser.error("--output is required unless --validate-only is used")
    output = Path(args.output)

    if args.standalone_admin:
        base = None
        render_mode = "standalone_admin"
        rendered = render_standalone(manifest, reviews)
    elif args.base_feature:
        if manifest["channel"] != "hybrid":
            raise ConversionError("--base-feature requires manifest channel=hybrid")
        base = Path(args.base_feature)
        if not base.is_file():
            raise ConversionError(f"base feature does not exist: {base}")
        rendered = compose_hybrid(base.read_text(encoding="utf-8"), manifest, reviews)
        render_mode = "hybrid_composed"
    else:
        if manifest["channel"] == "hybrid":
            raise ConversionError(
                "manifest channel=hybrid requires --base-feature or --standalone-admin"
            )
        base = None
        rendered = render_standalone(manifest, reviews)
        render_mode = "standalone_admin"

    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(rendered, encoding="utf-8")
    if args.report:
        write_report(
            Path(args.report),
            manifest,
            reviews,
            output,
            base,
            render_mode=render_mode,
            page_contract_issues=page_contract_issues,
        )
    print(f"Feature written: {output}")
    print(f"Steps: {len(manifest['steps'])}; review_required={bool(reviews)}")
    if reviews:
        for item in reviews:
            print(f"REVIEW: {item}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except ConversionError as error:
        print(f"ERROR: {error}", file=sys.stderr)
        raise SystemExit(2)
