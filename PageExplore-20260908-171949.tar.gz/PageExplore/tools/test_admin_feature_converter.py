#!/usr/bin/env python3
"""Focused regression tests for standalone Admin flow conversion."""

from __future__ import annotations

import unittest

import admin_feature_converter as converter


def manifest() -> dict:
    return {
        "case_id": "ODP-T2194",
        "name": "Maintain SMP ID",
        "channel": "hybrid",
        "evidence_status": "verified",
        "tags": ["@FEATURE=Binary", "@ADMIN_SETUP"],
        "background": [],
        "steps": [
            {
                "text": "Open browser",
                "table": [],
            },
            {
                "text": "Approve if updated with :",
                "table": [
                    ["Function Name", "Identifier"],
                    ["Maintain SMP ID", "smp_id"],
                ],
                "mcp_execution": "deferred_to_feature",
            },
        ],
        "evidence": {},
        "reviews": [],
    }


class StandaloneAdminFeatureTest(unittest.TestCase):
    def test_hybrid_manifest_renders_as_independent_admin_feature(self) -> None:
        source = manifest()
        rendered = converter.render_standalone(source, [])

        self.assertIn("@FEATURE=AdminGUI", rendered)
        self.assertNotIn("@FEATURE=Binary", rendered)
        self.assertNotIn("@ADMIN_SETUP", rendered)
        self.assertNotIn("Background:", rendered)
        self.assertTrue(converter.compare_admin_feature_to_flow(source, rendered)["aligned"])

    def test_comparison_detects_datatable_drift(self) -> None:
        source = manifest()
        rendered = converter.render_standalone(source, []).replace(
            "| Maintain SMP ID | smp_id |",
            "| Maintain SMP ID | wrong_id |",
        )

        comparison = converter.compare_admin_feature_to_flow(source, rendered)
        self.assertFalse(comparison["aligned"])
        self.assertEqual("steps", comparison["mismatches"][0]["section"])

    def test_comparison_detects_extra_admin_step(self) -> None:
        source = manifest()
        rendered = converter.render_standalone(source, []).replace(
            "\t* Approve if updated with :",
            "\t* Clear Alert If Exist\n\t* Approve if updated with :",
        )

        comparison = converter.compare_admin_feature_to_flow(source, rendered)
        self.assertFalse(comparison["aligned"])
        self.assertEqual(3, comparison["feature_step_count"])


if __name__ == "__main__":
    unittest.main()
