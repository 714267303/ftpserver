#!/usr/bin/env python3
"""Deterministic Admin menu/page/profile contract validation.

The runtime Step Index proves that a Gherkin sentence is executable.  It does
not prove that the sentence names the right ODP menu or that the following
operation belongs to the selected page.  This module builds that missing
contract from PageExplore's sitemap and per-page profiles, then checks a
semantic Admin flow as a small browser/page state machine.

Only facts that are unique in the checked-in PageExplore corpus are repaired.
Ambiguous or missing navigation is reported and must be reviewed; it is never
guessed from a case-specific heuristic.
"""

from __future__ import annotations

import copy
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping


NAVIGATION_RE = re.compile(
    r'^Select Trading Admin Left Menu\s+"([^"]+)"\s*$', re.I
)
SEARCH_RE = re.compile(
    r'^Search in Trading Admin\s+"([^"]+)"\s+page with\s*:\s*$', re.I
)
TABLE_RE = re.compile(
    r'^(?:Double click|Check|Select|Set)\s+table\s+"([^"]+)"', re.I
)
FORM_RE = re.compile(
    r'^(?:Set|Save|Check)\s+Trading Admin\s+"([^"]+)"\s+info', re.I
)
DETAIL_PAGE_RE = re.compile(
    r'\bin\s+(?:Trading Admin\s+)?detail info page\s+"([^"]+)"', re.I
)
ADMIN_PAGE_RE = re.compile(
    r'\bin Trading Admin\s+"([^"]+)"\s+page\b', re.I
)
SAVE_BROWSER_RE = re.compile(r'^Save current browser to\s+"?([^"\s]+)"?$', re.I)
SWITCH_BROWSER_RE = re.compile(
    r'^Switch browser to\s+"?([^"\s]+)"?(?:\s+and\s+maximize)?$', re.I
)
APPROVAL_RE = re.compile(r'^Approve if updated with\s*:\s*$', re.I)


class PageContractError(ValueError):
    """Raised when PageExplore itself cannot provide a deterministic contract."""


@dataclass(frozen=True)
class PageSpec:
    parent_menu: str
    label: str
    route: str
    profile_reference: str
    profile_path: Path
    columns: frozenset[str]
    detail_fields: frozenset[str]
    profiled: bool

    @property
    def menu_path(self) -> str:
        return f"{self.parent_menu}>{self.label}"

    @property
    def detail_aliases(self) -> frozenset[str]:
        aliases = {self.label, f"{self.label} Detail"}
        if self.label.lower().startswith("maintain "):
            aliases.add(f"{self.label[len('Maintain '):]} Detail")
        return frozenset(normalize_name(value) for value in aliases)


@dataclass(frozen=True)
class PageCatalog:
    root: Path
    by_route: Mapping[str, PageSpec]
    by_menu: Mapping[str, PageSpec]
    by_label: Mapping[str, tuple[PageSpec, ...]]


def normalize_name(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "").strip()).casefold()


def normalize_header(value: Any) -> str:
    text = re.sub(r"\s*\[[^\]]+\]\s*$", "", str(value or "").strip())
    return normalize_name(text)


def _unquote_markdown(value: str) -> str:
    text = value.strip().strip("`").strip()
    if len(text) >= 2 and text[0] == text[-1] and text[0] in {'"', "'"}:
        return text[1:-1]
    return text


def _profile_metadata(path: Path) -> dict[str, Any]:
    if not path.is_file() or path.is_symlink():
        raise PageContractError(f"PageExplore profile is missing: {path}")

    label = ""
    route = ""
    profiled = False
    section = ""
    columns: set[str] = set()
    detail_fields: set[str] = set()
    in_frontmatter = False

    for line in path.read_text(encoding="utf-8").splitlines():
        if line.strip() == "---":
            if in_frontmatter:
                break
            in_frontmatter = True
            continue
        if not in_frontmatter:
            continue

        top_key = re.match(r"^([A-Za-z][A-Za-z0-9_]*):\s*(.*?)\s*$", line)
        if top_key:
            key, value = top_key.groups()
            section = key
            if key == "label":
                label = _unquote_markdown(value)
            elif key == "route":
                route = _unquote_markdown(value)
            elif key == "profiled":
                profiled = value.strip().lower() == "true"
            continue

        if section == "columns":
            match = re.match(r'^\s+headerName:\s*(.*?)\s*$', line)
            if match:
                value = _unquote_markdown(match.group(1))
                if value:
                    columns.add(value)
        elif section == "details":
            match = re.match(r'^\s+-\s+label:\s*(.*?)\s*$', line)
            if match:
                value = _unquote_markdown(match.group(1))
                if value:
                    detail_fields.add(value)

    return {
        "label": label,
        "route": route,
        "profiled": profiled,
        "columns": frozenset(columns),
        "detail_fields": frozenset(detail_fields),
    }


def load_page_catalog(page_explore_root: str | Path) -> PageCatalog:
    root = Path(page_explore_root).resolve()
    sitemap = root / "sitemap.md"
    if not sitemap.is_file() or sitemap.is_symlink():
        raise PageContractError(f"PageExplore sitemap is missing: {sitemap}")

    parent = ""
    by_route: dict[str, PageSpec] = {}
    by_menu: dict[str, PageSpec] = {}
    labels: dict[str, list[PageSpec]] = {}

    for line_number, line in enumerate(
        sitemap.read_text(encoding="utf-8").splitlines(), 1
    ):
        heading = re.match(r"^###\s+\d+\.\s+(.+?)\s*$", line)
        if heading:
            # Parenthetical text expands an abbreviation; it is not part of
            # the actual sidebar label (for example "SMP (Special ...)").
            parent = re.sub(r"\s+\([^)]*\)\s*$", "", heading.group(1)).strip()
            continue
        if not parent or not re.match(r"^\|\s*\d+\s*\|", line):
            continue

        cells = [cell.strip() for cell in line.strip().strip("|").split("|")]
        if len(cells) < 4:
            continue
        label = _unquote_markdown(cells[1])
        route_match = re.search(r"`?(/UI/[A-Za-z0-9_-]+)`?", cells[2])
        profile_match = re.search(r"\((pages/[A-Za-z0-9_.-]+\.md)\)", line)
        if not label or not route_match or not profile_match:
            continue

        route = route_match.group(1)
        root_name = root.name or "pageExplore"
        profile_reference = f"{root_name}/{profile_match.group(1)}"
        profile_path = root / profile_match.group(1)
        metadata = _profile_metadata(profile_path)
        if metadata["route"] and metadata["route"] != route:
            raise PageContractError(
                f"sitemap/profile route mismatch at sitemap line {line_number}: "
                f"{route} != {metadata['route']}"
            )
        if metadata["label"] and normalize_name(metadata["label"]) != normalize_name(label):
            raise PageContractError(
                f"sitemap/profile label mismatch at sitemap line {line_number}: "
                f"{label} != {metadata['label']}"
            )

        spec = PageSpec(
            parent_menu=parent,
            label=label,
            route=route,
            profile_reference=profile_reference,
            profile_path=profile_path,
            columns=metadata["columns"],
            detail_fields=metadata["detail_fields"],
            profiled=bool(metadata["profiled"]),
        )
        if route in by_route:
            raise PageContractError(f"duplicate PageExplore route: {route}")
        menu_key = normalize_name(spec.menu_path)
        if menu_key in by_menu:
            raise PageContractError(f"duplicate PageExplore menu path: {spec.menu_path}")
        by_route[route] = spec
        by_menu[menu_key] = spec
        labels.setdefault(normalize_name(label), []).append(spec)

    if not by_route:
        raise PageContractError(f"no Admin pages parsed from {sitemap}")
    return PageCatalog(
        root=root,
        by_route=by_route,
        by_menu=by_menu,
        by_label={key: tuple(value) for key, value in labels.items()},
    )


def _step_text(step: Any) -> str:
    if isinstance(step, Mapping):
        return str(step.get("text", step.get("step", step.get("uat_step", "")))).strip()
    return str(step or "").strip()


def _set_step_text(step: Any, text: str) -> Any:
    if isinstance(step, Mapping):
        value = dict(step)
        if "text" in value or ("step" not in value and "uat_step" not in value):
            value["text"] = text
        elif "step" in value:
            value["step"] = text
        else:
            value["uat_step"] = text
        return value
    return text


def _all_steps(manifest: Mapping[str, Any]) -> list[tuple[str, int, Any]]:
    result: list[tuple[str, int, Any]] = []
    for section in ("background", "steps"):
        raw = manifest.get(section, [])
        if isinstance(raw, list):
            result.extend((section, index, step) for index, step in enumerate(raw))
    return result


def _resolve_page_name(
    catalog: PageCatalog, name: str, *, detail: bool = False
) -> tuple[PageSpec | None, bool]:
    key = normalize_name(name)
    candidates: list[PageSpec] = list(catalog.by_label.get(key, ()))
    if detail:
        candidates.extend(
            spec for spec in catalog.by_route.values() if key in spec.detail_aliases
        )
    unique = {spec.route: spec for spec in candidates}
    if len(unique) == 1:
        return next(iter(unique.values())), False
    return None, len(unique) > 1


def _page_binding(
    text: str, catalog: PageCatalog
) -> tuple[str, str, PageSpec | None, bool] | None:
    match = SEARCH_RE.match(text)
    if match:
        spec, ambiguous = _resolve_page_name(catalog, match.group(1))
        return "search", match.group(1), spec, ambiguous
    match = TABLE_RE.match(text)
    if match:
        spec, ambiguous = _resolve_page_name(catalog, match.group(1))
        return "table", match.group(1), spec, ambiguous
    match = FORM_RE.match(text)
    if match:
        spec, ambiguous = _resolve_page_name(catalog, match.group(1), detail=True)
        return "detail", match.group(1), spec, ambiguous
    match = DETAIL_PAGE_RE.search(text)
    if match:
        spec, ambiguous = _resolve_page_name(catalog, match.group(1), detail=True)
        return "detail", match.group(1), spec, ambiguous
    match = ADMIN_PAGE_RE.search(text)
    if match:
        spec, ambiguous = _resolve_page_name(catalog, match.group(1))
        return "page", match.group(1), spec, ambiguous
    return None


def _table_rows(step: Any) -> list[list[str]]:
    if not isinstance(step, Mapping):
        return []
    raw = step.get("table")
    if isinstance(raw, str):
        return [
            [cell.strip() for cell in line.strip().strip("|").split("|")]
            for line in raw.splitlines()
            if line.strip().startswith("|") and line.strip().endswith("|")
        ]
    if not isinstance(raw, list) or not raw:
        return []
    if all(isinstance(row, list) for row in raw):
        return [[str(cell or "").strip() for cell in row] for row in raw]
    if all(isinstance(row, Mapping) for row in raw):
        headers: list[str] = []
        for row in raw:
            for key in row:
                if str(key) not in headers:
                    headers.append(str(key))
        return [headers] + [
            [str(row.get(header, "") or "").strip() for header in headers]
            for row in raw
        ]
    return []


def _issue(code: str, section: str = "", index: int | None = None, **details: Any) -> dict[str, Any]:
    value: dict[str, Any] = {"code": code}
    if section:
        value["section"] = section
    if index is not None:
        value["index"] = index
    value.update(details)
    return value


def repair_page_contract(
    manifest: Mapping[str, Any], page_explore_root: str | Path
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    """Repair only unique route/profile/menu facts from PageExplore."""

    catalog = load_page_catalog(page_explore_root)
    repaired = copy.deepcopy(dict(manifest))
    repairs: list[dict[str, Any]] = []
    page = repaired.get("page")
    primary: PageSpec | None = None
    if isinstance(page, dict):
        primary = catalog.by_route.get(str(page.get("route", "")).strip())
        if primary:
            expected = {
                "label": primary.label,
                "profile": primary.profile_reference,
            }
            for key, value in expected.items():
                before = str(page.get(key, "")).strip()
                if before != value:
                    page[key] = value
                    repairs.append(
                        _issue(
                            f"PAGE_{key.upper()}_FROM_ROUTE",
                            path=f"page.{key}",
                            before=before,
                            after=value,
                        )
                    )

    flattened = _all_steps(repaired)
    navigation_positions = [
        position
        for position, (_section, _index, step) in enumerate(flattened)
        if NAVIGATION_RE.match(_step_text(step))
    ]
    for nav_number, position in enumerate(navigation_positions):
        section, index, step = flattened[position]
        current_text = _step_text(step)
        match = NAVIGATION_RE.match(current_text)
        if not match:
            continue
        end = (
            navigation_positions[nav_number + 1]
            if nav_number + 1 < len(navigation_positions)
            else len(flattened)
        )
        segment_pages: dict[str, PageSpec] = {}
        for _next_section, _next_index, next_step in flattened[position + 1 : end]:
            binding = _page_binding(_step_text(next_step), catalog)
            if binding and binding[2]:
                segment_pages[binding[2].route] = binding[2]
        expected_spec: PageSpec | None = None
        if len(segment_pages) == 1:
            expected_spec = next(iter(segment_pages.values()))
        elif not segment_pages and len(navigation_positions) == 1:
            expected_spec = primary
        declared_spec = catalog.by_menu.get(normalize_name(match.group(1)))
        # An invalid menu can be replaced by the segment's one provable page.
        # When both sides are valid but conflict, change the menu only if the
        # operation and the manifest's primary route independently agree. In a
        # multi-page flow without that corroboration, leave the contradiction
        # for validation instead of guessing which valid page name was wrong.
        repair_is_proven = expected_spec and (
            declared_spec is None
            or (
                primary is not None
                and expected_spec.route == primary.route
                and declared_spec.route != primary.route
            )
        )
        if repair_is_proven and normalize_name(match.group(1)) != normalize_name(expected_spec.menu_path):
            new_text = f'Select Trading Admin Left Menu "{expected_spec.menu_path}"'
            repaired[section][index] = _set_step_text(step, new_text)
            flattened[position] = (section, index, repaired[section][index])
            repairs.append(
                _issue(
                    "MENU_PATH_FROM_UNIQUE_PAGE",
                    section,
                    index,
                    before=match.group(1),
                    after=expected_spec.menu_path,
                    route=expected_spec.route,
                )
            )
    return repaired, repairs


def _validate_fields(
    step: Any,
    binding_kind: str,
    spec: PageSpec,
    section: str,
    index: int,
) -> list[dict[str, Any]]:
    rows = _table_rows(step)
    if not rows or not spec.profiled:
        return []
    if binding_kind in {"search", "table", "page"}:
        allowed = {normalize_header(value) for value in spec.columns if value}
    elif binding_kind == "detail":
        allowed = {normalize_header(value) for value in spec.detail_fields if value}
    else:
        return []
    if not allowed:
        return []
    unknown = sorted(
        {
            str(value).strip()
            for value in rows[0]
            if str(value).strip() and normalize_header(value) not in allowed
        }
    )
    if not unknown:
        return []
    return [
        _issue(
            "TABLE_FIELD_NOT_IN_PAGE_PROFILE",
            section,
            index,
            page=spec.label,
            fields=unknown,
        )
    ]


def _validate_approval_page(
    step: Any, primary: PageSpec | None, section: str, index: int, catalog: PageCatalog
) -> list[dict[str, Any]]:
    if not APPROVAL_RE.match(_step_text(step)) or not isinstance(step, Mapping):
        return []
    rows = _table_rows(step)
    if len(rows) < 2:
        return []
    headers = [normalize_header(value) for value in rows[0]]
    try:
        function_index = headers.index(normalize_header("Function Name"))
    except ValueError:
        return []
    issues: list[dict[str, Any]] = []
    for row in rows[1:]:
        if function_index >= len(row) or not row[function_index].strip():
            continue
        spec, ambiguous = _resolve_page_name(catalog, row[function_index])
        if ambiguous or not spec:
            issues.append(
                _issue("APPROVAL_FUNCTION_PAGE_UNKNOWN", section, index)
            )
        elif primary and spec.route != primary.route:
            issues.append(
                _issue(
                    "APPROVAL_FUNCTION_PAGE_MISMATCH",
                    section,
                    index,
                    expected_page=primary.label,
                    actual_page=spec.label,
                )
            )
    return issues


def validate_page_contract(
    manifest: Mapping[str, Any], page_explore_root: str | Path
) -> list[dict[str, Any]]:
    """Validate route/profile/menu/page/field relationships for any Admin flow."""

    catalog = load_page_catalog(page_explore_root)
    issues: list[dict[str, Any]] = []
    page = manifest.get("page")
    primary: PageSpec | None = None
    if not isinstance(page, Mapping):
        issues.append(_issue("PRIMARY_PAGE_MISSING"))
    else:
        route = str(page.get("route", "")).strip()
        primary = catalog.by_route.get(route)
        if not primary:
            issues.append(_issue("PRIMARY_ROUTE_NOT_IN_SITEMAP", route=route))
        else:
            if normalize_name(page.get("label")) != normalize_name(primary.label):
                issues.append(
                    _issue(
                        "PRIMARY_LABEL_ROUTE_MISMATCH",
                        expected=primary.label,
                        route=route,
                    )
                )
            profile = str(page.get("profile", "")).strip().replace("\\", "/")
            accepted_profiles = {
                primary.profile_reference,
                f"pages/{primary.profile_path.name}",
                primary.profile_path.as_posix(),
            }
            if profile not in accepted_profiles:
                issues.append(
                    _issue(
                        "PRIMARY_PROFILE_ROUTE_MISMATCH",
                        expected=primary.profile_reference,
                        route=route,
                    )
                )

    browser_counter = 0
    active_browser = "implicit"
    browser_aliases: dict[str, str] = {}
    browser_routes: dict[str, str | None] = {active_browser: None}
    primary_navigation_count = 0

    for section, index, step in _all_steps(manifest):
        text = _step_text(step)
        if text.casefold() == "open browser":
            browser_counter += 1
            active_browser = f"browser-{browser_counter}"
            browser_routes[active_browser] = None
            continue
        if text.casefold() == "login trading admin with:":
            browser_routes.setdefault(active_browser, None)
            browser_routes[active_browser] = None
            continue
        saved = SAVE_BROWSER_RE.match(text)
        if saved:
            browser_aliases[saved.group(1)] = active_browser
            continue
        switched = SWITCH_BROWSER_RE.match(text)
        if switched:
            alias = switched.group(1)
            if alias not in browser_aliases:
                issues.append(_issue("UNKNOWN_SAVED_BROWSER", section, index))
            else:
                active_browser = browser_aliases[alias]
            continue

        navigation = NAVIGATION_RE.match(text)
        if navigation:
            spec = catalog.by_menu.get(normalize_name(navigation.group(1)))
            if not spec:
                issues.append(
                    _issue("MENU_PATH_NOT_IN_SITEMAP", section, index)
                )
                browser_routes[active_browser] = None
            else:
                browser_routes[active_browser] = spec.route
                if primary and spec.route == primary.route:
                    primary_navigation_count += 1
            continue

        issues.extend(_validate_approval_page(step, primary, section, index, catalog))
        binding = _page_binding(text, catalog)
        if not binding:
            continue
        kind, raw_name, spec, ambiguous = binding
        if ambiguous:
            issues.append(_issue("OPERATION_PAGE_AMBIGUOUS", section, index))
            continue
        if not spec:
            # A table can legitimately be a sub-detail grid rather than a
            # sidebar page. Search/form/page operations cannot.
            if kind != "table":
                issues.append(
                    _issue(
                        "OPERATION_PAGE_NOT_IN_SITEMAP",
                        section,
                        index,
                        operation_kind=kind,
                    )
                )
            continue
        actual_route = browser_routes.get(active_browser)
        if actual_route is None:
            issues.append(
                _issue(
                    "OPERATION_MISSING_PRIOR_NAVIGATION",
                    section,
                    index,
                    expected_menu=spec.menu_path,
                )
            )
        elif actual_route != spec.route:
            actual = catalog.by_route.get(actual_route)
            issues.append(
                _issue(
                    "OPERATION_PAGE_DOES_NOT_MATCH_SELECTED_MENU",
                    section,
                    index,
                    expected_menu=spec.menu_path,
                    selected_menu=actual.menu_path if actual else "unknown",
                )
            )
        issues.extend(_validate_fields(step, kind, spec, section, index))

    if primary and primary_navigation_count == 0:
        issues.append(
            _issue(
                "PRIMARY_PAGE_NOT_NAVIGATED",
                expected_menu=primary.menu_path,
                route=primary.route,
            )
        )
    # Keep stable order but avoid repeating the same failure for a multi-row
    # approval table or several equivalent parser matches.
    unique: list[dict[str, Any]] = []
    seen: set[str] = set()
    for issue in issues:
        key = repr(sorted(issue.items()))
        if key not in seen:
            seen.add(key)
            unique.append(issue)
    return unique


def format_issue(issue: Mapping[str, Any]) -> str:
    code = str(issue.get("code", "PAGE_CONTRACT_ERROR"))
    location = ""
    if issue.get("section"):
        location = f":{issue['section']}[{issue.get('index', '?')}]"
    details: list[str] = []
    for key in (
        "route",
        "expected_menu",
        "selected_menu",
        "expected_page",
        "actual_page",
        "page",
    ):
        if issue.get(key):
            details.append(f"{key}={issue[key]}")
    return f"{code}{location}" + (f" ({', '.join(details)})" if details else "")


def format_issues(issues: Iterable[Mapping[str, Any]]) -> list[str]:
    return [format_issue(issue) for issue in issues]
