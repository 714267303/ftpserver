#!/usr/bin/env python3
"""Build the review-gated ODP-T repair experience catalog.

Repair runs write redacted candidate records to ``repair_experience/inbox``.
Human-reviewed semantic lessons live in ``repair_experience/lessons``.  This
tool validates both buckets and produces deterministic JSON/Markdown indexes;
it never promotes a candidate or edits a lesson.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from pathlib import Path
from typing import Any


SCHEMA_VERSION = 1
LESSON_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.:-]{2,199}$")
VALID_STATUS = {"candidate", "reviewed", "verified", "rejected"}
VALID_SOURCE_TYPES = {"repair_run", "repair_review", "manual"}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def as_string_list(value: Any, field: str, path: Path, *, required: bool = False) -> list[str]:
    if value is None and not required:
        return []
    if not isinstance(value, list):
        raise ValueError(f"{path}: {field} must be an array")
    result = [str(item).strip() for item in value]
    if any(not item for item in result):
        raise ValueError(f"{path}: {field} cannot contain empty values")
    return result


def load_lesson(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise ValueError(f"cannot parse {path}: {error}") from error
    if not isinstance(value, dict):
        raise ValueError(f"{path}: root must be an object")
    if value.get("schema_version") != SCHEMA_VERSION:
        raise ValueError(f"{path}: schema_version must be {SCHEMA_VERSION}")

    lesson_id = str(value.get("lesson_id", ""))
    if not LESSON_ID_RE.fullmatch(lesson_id):
        raise ValueError(f"{path}: invalid lesson_id")
    status = str(value.get("status", ""))
    if status not in VALID_STATUS:
        raise ValueError(f"{path}: status must be one of {sorted(VALID_STATUS)}")
    title = str(value.get("title", "")).strip()
    if not title:
        raise ValueError(f"{path}: title must not be empty")

    scope = as_string_list(value.get("scope"), "scope", path, required=True)
    symptoms = as_string_list(value.get("symptoms", []), "symptoms", path)
    anti_patterns = as_string_list(value.get("anti_patterns", []), "anti_patterns", path)
    preferred_pattern = as_string_list(value.get("preferred_pattern", []), "preferred_pattern", path)
    constraints = as_string_list(value.get("constraints", []), "constraints", path)

    evidence = value.get("evidence")
    if not isinstance(evidence, dict):
        raise ValueError(f"{path}: evidence must be an object")
    source_type = str(evidence.get("source_type", ""))
    if source_type not in VALID_SOURCE_TYPES:
        raise ValueError(f"{path}: evidence.source_type must be one of {sorted(VALID_SOURCE_TYPES)}")
    references = as_string_list(evidence.get("references"), "evidence.references", path, required=True)

    reuse = value.get("reuse")
    if not isinstance(reuse, dict) or not isinstance(reuse.get("safe_to_reuse"), bool):
        raise ValueError(f"{path}: reuse.safe_to_reuse must be boolean")
    safe_to_reuse = bool(reuse["safe_to_reuse"])
    if status == "verified" and not safe_to_reuse:
        raise ValueError(f"{path}: verified lessons must set reuse.safe_to_reuse=true")
    if status != "verified" and safe_to_reuse:
        raise ValueError(f"{path}: only verified lessons may set reuse.safe_to_reuse=true")

    # Return the original payload for future schema-compatible fields while
    # normalizing the values used by the generated index.
    value["scope"] = scope
    value["symptoms"] = symptoms
    value["anti_patterns"] = anti_patterns
    value["preferred_pattern"] = preferred_pattern
    value["constraints"] = constraints
    value["evidence"]["references"] = references
    return value


def discover(root: Path) -> list[tuple[str, Path]]:
    paths: list[tuple[str, Path]] = []
    for bucket in ("inbox", "lessons"):
        bucket_root = root / bucket
        if not bucket_root.is_dir():
            continue
        paths.extend((bucket, path) for path in sorted(bucket_root.glob("*.json")))
    return paths


def build(root: Path) -> dict[str, Any]:
    schema_path = root / "schema.json"
    records = discover(root)
    lessons: list[dict[str, Any]] = []
    seen: dict[str, Path] = {}
    errors: list[str] = []
    for bucket, path in records:
        try:
            lesson = load_lesson(path)
            # The inbox is a quarantine boundary.  A record there may be a
            # candidate (or an explicit rejection), but it can never become
            # an eligible verified lesson until it is moved into lessons/.
            if bucket == "inbox" and (
                lesson["status"] == "verified" or lesson["reuse"]["safe_to_reuse"]
            ):
                raise ValueError(
                    f"{path}: verified/safe lessons must be moved from inbox/ to lessons/"
                )
        except ValueError as error:
            errors.append(str(error))
            continue
        lesson_id = str(lesson["lesson_id"])
        if lesson_id in seen:
            errors.append(f"duplicate lesson_id {lesson_id}: {seen[lesson_id]} and {path}")
            continue
        seen[lesson_id] = path
        evidence = lesson["evidence"]
        lessons.append(
            {
                "lesson_id": lesson_id,
                "title": str(lesson["title"]),
                "status": str(lesson["status"]),
                "bucket": bucket,
                "path": path.as_posix(),
                "sha256": sha256(path),
                "scope": list(lesson["scope"]),
                "symptoms": list(lesson["symptoms"]),
                "anti_patterns": list(lesson["anti_patterns"]),
                "preferred_pattern": list(lesson["preferred_pattern"]),
                "safe_to_reuse": bool(lesson["reuse"]["safe_to_reuse"]),
                "evidence_source": str(evidence["source_type"]),
                "evidence_references": list(evidence["references"]),
            }
        )

    lessons.sort(key=lambda item: (item["status"], item["lesson_id"]))
    return {
        "schema_version": SCHEMA_VERSION,
        "catalog": root.as_posix(),
        "schema": schema_path.as_posix() if schema_path.is_file() else None,
        "stats": {
            "lesson_files": len(records),
            "indexed_lessons": len(lessons),
            "inbox_candidates": sum(1 for item in lessons if item["bucket"] == "inbox"),
            "candidate": sum(1 for item in lessons if item["status"] == "candidate"),
            "reviewed": sum(1 for item in lessons if item["status"] == "reviewed"),
            "verified": sum(1 for item in lessons if item["status"] == "verified"),
            "rejected": sum(1 for item in lessons if item["status"] == "rejected"),
            "safe_to_reuse": sum(1 for item in lessons if item["safe_to_reuse"]),
            "errors": len(errors),
        },
        "errors": errors,
        "lessons": lessons,
    }


def markdown(payload: dict[str, Any], json_path: Path) -> str:
    stats = payload["stats"]
    lines = [
        "# ODP-T Repair Experience Catalog",
        "",
        "This index is generated from redacted candidates in `inbox/` and",
        "semantic lessons in `lessons/`.  It is a review queue, not an",
        "unrestricted prompt transcript.",
        "",
        f"Machine-readable index: [`{json_path.name}`]({json_path.name})",
        "",
        "## Trust policy",
        "",
        "Only `status=verified` together with `reuse.safe_to_reuse=true` may",
        "provide positive automatic repair guidance.  Candidate entries are",
        "retained for human review and are not loaded as automatic repair",
        "guidance.",
        "",
        "| Metric | Count |",
        "|---|---:|",
        f"| Lesson files | {stats['lesson_files']} |",
        f"| Indexed lessons | {stats['indexed_lessons']} |",
        f"| Inbox candidates | {stats['inbox_candidates']} |",
        f"| Candidate | {stats['candidate']} |",
        f"| Reviewed | {stats['reviewed']} |",
        f"| Verified | {stats['verified']} |",
        f"| Rejected | {stats['rejected']} |",
        f"| Safe to reuse | {stats['safe_to_reuse']} |",
        f"| Catalog errors | {stats['errors']} |",
        "",
        "## Lessons",
        "",
        "| Lesson ID | Status | Bucket | Scope | Reuse | Manifest |",
        "|---|---|---|---|---|---|",
    ]
    for item in payload["lessons"]:
        manifest = Path(item["path"]).name
        scope = ", ".join(item["scope"])
        # INDEX.md lives beside ``lessons/`` and ``inbox/``; keep links
        # relative to the catalog so they remain valid when the package is
        # opened outside the repository root.
        manifest_link = f"{item['bucket']}/{manifest}"
        lines.append(
            f"| `{item['lesson_id']}` | `{item['status']}` | `{item['bucket']}` | "
            f"{scope} | {'yes' if item['safe_to_reuse'] else 'review'} | "
            f"[{manifest}]({manifest_link}) |"
        )
    if payload["errors"]:
        lines.extend(["", "## Errors", ""])
        lines.extend(f"- {error}" for error in payload["errors"])
    lines.extend(
        [
            "",
            "## Lifecycle",
            "",
            "1. Run a Feature with `tools/run_feature_debug.rb --repair`; the",
            "   runner writes a redacted candidate to `inbox/`.",
            "2. Review the failure and remove case-specific values, credentials,",
            "   locators, UUIDs, and raw transcripts.",
            "3. Move the generalized lesson to `lessons/`, replay it from a clean",
            "   state, and set `status=verified` and `safe_to_reuse=true` only",
            "   after the resulting Feature passes.",
            "4. Run this builder with `--check` in CI or before packaging.",
            "",
        ]
    )
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--catalog", default="odpt-automation-skill/repair_experience")
    parser.add_argument("--output-json", default="odpt-automation-skill/repair_experience/INDEX.json")
    parser.add_argument("--output-md", default="odpt-automation-skill/repair_experience/INDEX.md")
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()

    root = Path(args.catalog)
    if not root.is_dir():
        print(f"ERROR: catalog directory does not exist: {root}", file=sys.stderr)
        return 2
    payload = build(root)
    json_path = Path(args.output_json)
    md_path = Path(args.output_md)
    json_text = json.dumps(payload, ensure_ascii=False, indent=2) + "\n"
    md_text = markdown(payload, json_path)

    if args.check:
        stale: list[str] = []
        if not json_path.is_file() or json_path.read_text(encoding="utf-8") != json_text:
            stale.append(str(json_path))
        if not md_path.is_file() or md_path.read_text(encoding="utf-8") != md_text:
            stale.append(str(md_path))
        if stale:
            print("STALE: " + ", ".join(stale), file=sys.stderr)
        for error in payload["errors"]:
            print("ERROR: " + error, file=sys.stderr)
        return 1 if stale or payload["errors"] else 0

    json_path.parent.mkdir(parents=True, exist_ok=True)
    md_path.parent.mkdir(parents=True, exist_ok=True)
    json_path.write_text(json_text, encoding="utf-8")
    md_path.write_text(md_text, encoding="utf-8")
    print(f"Wrote {json_path} and {md_path}")
    print(f"Lessons: {payload['stats']['indexed_lessons']}; errors: {payload['stats']['errors']}")
    for error in payload["errors"]:
        print("ERROR: " + error, file=sys.stderr)
    return 1 if payload["errors"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
