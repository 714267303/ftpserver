#!/usr/bin/env python3
"""Build a searchable index from a WABI FIX XML dictionary.

``FIXODPMSG.xml`` is the application-message dictionary used by the Binary
steps.  The XML is intentionally kept as the source of truth; this script
only produces a deterministic, reviewable projection of it.  In particular,
enum values retain their wire value and the exact XML description.  A small
human-readable ``meaning`` is added as a convenience and is explicitly
derived from the description rather than presented as an independent rule.

The optional ``--transport`` argument can index the sibling ``FIXODP.xml``
session dictionary in the same output.  This is useful when diagnosing
Logon/Logout/Reject failures, while keeping the application dictionary as the
primary ``dictionary`` member.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any, Iterable


SCRIPT_ROOT = Path(__file__).resolve().parents[1]


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def required_flag(value: str | None) -> bool | None:
    if value is None:
        return None
    upper = value.strip().upper()
    if upper in {"Y", "YES", "TRUE", "1"}:
        return True
    if upper in {"N", "NO", "FALSE", "0"}:
        return False
    return None


def humanize(value: str) -> str:
    """Turn an enum identifier into a readable hint without changing it."""

    text = re.sub(r"[_-]+", " ", value.strip())
    text = re.sub(r"\s+", " ", text)
    return text.title()


def member(node: ET.Element) -> dict[str, Any]:
    """Return an ordered XML member reference (field/group/component)."""

    result: dict[str, Any] = {"kind": node.tag}
    for key in ("name", "required", "number", "length", "type", "specType"):
        value = node.get(key)
        if value is not None:
            result[key] = value
    flag = required_flag(node.get("required"))
    if flag is not None:
        result["required_flag"] = flag
    return result


def parse_members(container: ET.Element) -> list[dict[str, Any]]:
    """Preserve direct child order for fields, groups and component refs."""

    return [member(child) for child in list(container) if child.tag in {"field", "group", "component"}]


def parse_enum(value: ET.Element) -> dict[str, Any]:
    raw = value.get("enum", "")
    description = value.get("description", "")
    item: dict[str, Any] = {
        "value": raw,
        "description": description,
        "meaning": humanize(description) if description else "",
    }
    # Keep any vendor attributes that carry useful meaning, without copying
    # arbitrary XML extensions into the index.
    for key in ("name", "label", "text"):
        if value.get(key) is not None:
            item[key] = value.get(key)
    return item


def parse_dictionary(path: Path) -> dict[str, Any]:
    try:
        root = ET.parse(path).getroot()
    except (ET.ParseError, OSError) as exc:
        raise SystemExit(f"unable to parse FIX dictionary {path}: {exc}") from exc

    fields_node = root.find("fields")
    messages_node = root.find("messages")
    components_node = root.find("components")

    fields: list[dict[str, Any]] = []
    field_by_name: dict[str, dict[str, Any]] = {}
    if fields_node is not None:
        for field in fields_node.findall("field"):
            item: dict[str, Any] = {"name": field.get("name", "")}
            for key in ("number", "length", "type", "specType"):
                if field.get(key) is not None:
                    item[key] = field.get(key)
            values = [parse_enum(value) for value in field.findall("value")]
            if values:
                item["enum_values"] = values
            field_by_name[item["name"]] = item
            fields.append(item)

    messages: list[dict[str, Any]] = []
    if messages_node is not None:
        for message in messages_node.findall("message"):
            item: dict[str, Any] = {
                "name": message.get("name", ""),
                "msgtype": message.get("msgtype", ""),
                "msgcat": message.get("msgcat", ""),
                "members": parse_members(message),
            }
            item["fields"] = [
                ref["name"] for ref in item["members"] if ref["kind"] == "field" and ref.get("name")
            ]
            item["components"] = [
                ref["name"]
                for ref in item["members"]
                if ref["kind"] == "component" and ref.get("name")
            ]
            messages.append(item)

    components: list[dict[str, Any]] = []
    groups: list[dict[str, Any]] = []
    if components_node is not None:
        for component in components_node.findall("component"):
            item = {
                "name": component.get("name", ""),
                "members": parse_members(component),
            }
            item["fields"] = [
                ref["name"] for ref in item["members"] if ref["kind"] == "field" and ref.get("name")
            ]
            item["groups"] = [
                ref["name"] for ref in item["members"] if ref["kind"] == "group" and ref.get("name")
            ]
            components.append(item)
            for group in component.findall("group"):
                group_item = {
                    "name": group.get("name", ""),
                    "required": group.get("required"),
                    "required_flag": required_flag(group.get("required")),
                    "members": parse_members(group),
                }
                group_item["fields"] = [
                    ref["name"]
                    for ref in group_item["members"]
                    if ref["kind"] == "field" and ref.get("name")
                ]
                groups.append(group_item)

    def section_members(name: str) -> list[dict[str, Any]]:
        node = root.find(name)
        return parse_members(node) if node is not None else []

    header = section_members("header")
    trailer = section_members("trailer")

    # Build reverse references so a debugger can start at an enum/field and
    # immediately see which messages use it.  Group members are expanded one
    # level through the component definitions; the original ordered members
    # remain available above for exact wire layout.
    field_usage: dict[str, dict[str, list[str]]] = {
        field["name"]: {"messages": [], "components": [], "groups": [], "header": [], "trailer": []}
        for field in fields
        if field.get("name")
    }

    def add_usage(name: str, bucket: str, owner: str) -> None:
        if name in field_usage and owner not in field_usage[name][bucket]:
            field_usage[name][bucket].append(owner)

    for ref in header:
        if ref.get("name"):
            add_usage(ref["name"], "header", "header")
    for ref in trailer:
        if ref.get("name"):
            add_usage(ref["name"], "trailer", "trailer")

    component_by_name = {item["name"]: item for item in components}
    group_by_name = {item["name"]: item for item in groups}

    def fields_in_group(name: str, seen: set[str] | None = None) -> Iterable[str]:
        seen = set() if seen is None else seen
        if name in seen:
            return
        seen.add(name)
        group = group_by_name.get(name)
        if group is None:
            return
        for ref in group["members"]:
            if ref["kind"] == "field" and ref.get("name"):
                yield ref["name"]
            elif ref["kind"] == "group" and ref.get("name"):
                yield from fields_in_group(ref["name"], seen)

    def fields_in_component(name: str, seen: set[str] | None = None) -> Iterable[str]:
        seen = set() if seen is None else seen
        if name in seen:
            return
        seen.add(name)
        component = component_by_name.get(name)
        if component is None:
            return
        for ref in component["members"]:
            if ref["kind"] == "field" and ref.get("name"):
                yield ref["name"]
            elif ref["kind"] == "component" and ref.get("name"):
                yield from fields_in_component(ref["name"], seen)
            elif ref["kind"] == "group" and ref.get("name"):
                yield from fields_in_group(ref["name"])

    for component in components:
        owner = component["name"]
        for name in fields_in_component(owner):
            add_usage(name, "components", owner)
        for group_name in component.get("groups", []):
            for name in fields_in_group(group_name):
                add_usage(name, "groups", group_name)

    for message in messages:
        owner = message["name"]
        for ref in message["members"]:
            if ref["kind"] == "field" and ref.get("name"):
                add_usage(ref["name"], "messages", owner)
            elif ref["kind"] == "component" and ref.get("name"):
                for name in fields_in_component(ref["name"]):
                    add_usage(name, "messages", owner)
            elif ref["kind"] == "group" and ref.get("name"):
                for name in fields_in_group(ref["name"]):
                    add_usage(name, "messages", owner)

    for field in fields:
        usage = field_usage.get(field["name"], {})
        field["used_by"] = {
            key: sorted(value) for key, value in usage.items() if value
        }

    enum_fields = [field for field in fields if field.get("enum_values")]
    enum_by_code: dict[str, list[dict[str, str]]] = {}
    for field in enum_fields:
        for enum in field["enum_values"]:
            enum_by_code.setdefault(enum["value"], []).append(
                {
                    "field": field["name"],
                    "description": enum.get("description", ""),
                }
            )

    return {
        "format": root.tag,
        "version": {
            key: root.get(key)
            for key in ("type", "major", "minor", "servicepack")
            if root.get(key) is not None
        },
        "source": {"path": path.as_posix(), "sha256": sha256(path)},
        "stats": {
            "messages": len(messages),
            "components": len(components),
            "groups": len(groups),
            "fields": len(fields),
            "enum_fields": len(enum_fields),
            "enum_values": sum(len(field.get("enum_values", [])) for field in fields),
            "header_fields": len(header),
            "trailer_fields": len(trailer),
        },
        "header": header,
        "trailer": trailer,
        "messages": messages,
        "components": components,
        "groups": groups,
        "fields": fields,
        "enum_lookup": {
            field["name"]: field["enum_values"] for field in enum_fields
        },
        "enum_code_lookup": {
            code: entries for code, entries in sorted(enum_by_code.items())
        },
    }


def resolve_default_input() -> Path:
    candidates = [
        SCRIPT_ROOT.parent / "etc" / "FIXODPMSG.xml",
        Path("../etc/FIXODPMSG.xml"),
    ]
    candidates.extend(sorted(Path("/usr/local/share/gems/gems").glob("wabi-fix-*/etc/FIXODPMSG.xml")))
    for candidate in candidates:
        if candidate.is_file():
            return candidate.resolve()
    raise SystemExit("FIXODPMSG.xml not found; pass --input PATH")


def render_markdown(payload: dict[str, Any]) -> str:
    dictionary = payload["dictionary"]
    stats = dictionary["stats"]
    version = dictionary.get("version", {})
    if version.get("major") is not None and version.get("minor") is not None:
        version_text = f"{version.get('type', 'FIX')} {version['major']}.{version['minor']}"
        if version.get("servicepack") is not None:
            version_text += f" SP{version['servicepack']}"
    else:
        version_text = " ".join(
            str(version[key])
            for key in ("type", "major", "minor", "servicepack")
            if version.get(key) is not None
        ) or "unknown"
    lines = [
        "# FIXODPMSG Enum and Message Index",
        "",
        "This index is generated from the XML dictionary.  The XML remains the",
        "authority; `meaning` values are readability hints derived from the",
        "exact enum `description`.  Do not use this file to invent values absent",
        "from the dictionary.",
        "",
        "## Source",
        "",
        f"- Path: `{dictionary['source']['path']}`",
        f"- SHA-256: `{dictionary['source']['sha256']}`",
        f"- Version: `{version_text}`",
        f"- Messages: `{stats['messages']}`",
        f"- Components: `{stats['components']}`",
        f"- Fields: `{stats['fields']}`",
        f"- Enum fields: `{stats['enum_fields']}`",
        f"- Enum values: `{stats['enum_values']}`",
        "",
        "## Enum Values",
        "",
        "The wire `value` and XML `description` are retained exactly.  A field",
        "may reuse a numeric value with a different meaning, so look up by",
        "`field + value`, never by value alone.",
        "",
        "| Field | Number | Type | Wire value | XML description | Meaning hint | Used by |",
        "|---|---:|---|---|---|---|---|",
    ]
    for field in dictionary["fields"]:
        values = field.get("enum_values", [])
        if not values:
            continue
        used = field.get("used_by", {})
        owners = ", ".join(used.get("messages", [])[:6])
        if len(used.get("messages", [])) > 6:
            owners += ", ..."
        if not owners:
            owners = ", ".join(used.get("components", []))
        for enum in values:
            description = enum.get("description", "").replace("|", "\\|")
            meaning = enum.get("meaning", "").replace("|", "\\|")
            lines.append(
                f"| `{field['name']}` | `{field.get('number', '')}` | `{field.get('specType', field.get('type', ''))}` | `{enum.get('value', '')}` | {description} | {meaning} | {owners} |"
            )

    lines.extend(["", "## Messages", "", "| MsgType | Name | Category | Fields | Components |", "|---:|---|---|---|---|"])
    for message in dictionary["messages"]:
        fields = ", ".join(message.get("fields", [])) or "-"
        components = ", ".join(message.get("components", [])) or "-"
        lines.append(
            f"| `{message.get('msgtype', '')}` | `{message.get('name', '')}` | `{message.get('msgcat', '')}` | {fields} | {components} |"
        )

    lines.extend(["", "## Header and Trailer", "", "- Header: " + ", ".join(ref.get("name", "") for ref in dictionary["header"])])
    lines.append("- Trailer: " + ", ".join(ref.get("name", "") for ref in dictionary["trailer"]))

    related = payload.get("related_dictionaries", [])
    if related:
        lines.extend(["", "## Related Dictionaries", "", "The following optional dictionaries were indexed alongside the application dictionary:", ""])
        for item in related:
            lines.append(
                f"- `{item['source']['path']}` (SHA-256 `{item['source']['sha256']}`; {item['stats']['enum_values']} enum values)"
            )
    lines.append("")
    return "\n".join(lines)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=None, help="FIXODPMSG.xml path")
    parser.add_argument("--transport", type=Path, action="append", default=[], help="optional transport dictionary (repeatable)")
    parser.add_argument("--output-json", type=Path, default=SCRIPT_ROOT / "odpt-automation-skill" / "FIXODPMSG_Index.json")
    parser.add_argument("--output-md", type=Path, default=SCRIPT_ROOT / "odpt-automation-skill" / "FIXODPMSG_Index.md")
    args = parser.parse_args(argv)

    input_path = (args.input or resolve_default_input()).expanduser().resolve()
    if not input_path.is_file():
        raise SystemExit(f"FIX dictionary not found: {input_path}")
    payload: dict[str, Any] = {
        "schema_version": 1,
        "dictionary": parse_dictionary(input_path),
        "related_dictionaries": [],
    }
    for transport in args.transport:
        path = transport.expanduser().resolve()
        if not path.is_file():
            raise SystemExit(f"transport dictionary not found: {path}")
        payload["related_dictionaries"].append(parse_dictionary(path))

    payload["stats"] = {
        "primary": payload["dictionary"]["stats"],
        "related_count": len(payload["related_dictionaries"]),
        "related_enum_values": sum(item["stats"]["enum_values"] for item in payload["related_dictionaries"]),
    }
    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    args.output_md.parent.mkdir(parents=True, exist_ok=True)
    args.output_json.write_text(json.dumps(payload, indent=2, ensure_ascii=True) + "\n", encoding="utf-8")
    args.output_md.write_text(render_markdown(payload), encoding="utf-8")
    print(json.dumps(payload["stats"], sort_keys=True))
    return 0


if __name__ == "__main__":
    sys.exit(main())
