#!/usr/bin/env python3
"""Regression tests for the PageExplore-backed Admin page contract."""

from __future__ import annotations

import copy
import unittest
from pathlib import Path

import admin_page_contract as contract


ROOT = Path(__file__).resolve().parents[1]
PAGE_EXPLORE = ROOT / "pageExplore"


def flow(route: str, label: str, profile: str, menu: str) -> dict:
    return {
        "schema_version": 1,
        "flow_id": "admin.contract.test.v1",
        "case_id": "ODP-T-CONTRACT",
        "name": "Page contract test",
        "channel": "admin",
        "evidence_status": "verified",
        "page": {"label": label, "route": route, "profile": profile},
        "steps": [
            "Open browser",
            {
                "text": "Login Trading Admin with:",
                "table": [
                    ["User ID", "User Password"],
                    ["admin_gui_user1", "admin_gui_user1_password"],
                ],
            },
            "Save current browser to browser_admin_gui_user1",
            f'Select Trading Admin Left Menu "{menu}"',
            {
                "text": f'Search in Trading Admin "{label}" page with:',
                "table": [["SMP ID"], ["smp_id"]],
            },
        ],
    }


class AdminPageContractTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.catalog = contract.load_page_catalog(PAGE_EXPLORE)

    def test_catalog_is_built_for_all_sitemap_pages(self) -> None:
        self.assertEqual(96, len(self.catalog.by_route))
        self.assertEqual(
            "SMP>Maintain SMP ID",
            self.catalog.by_route["/UI/uiSmpIdSearchTable"].menu_path,
        )
        self.assertEqual(
            "Participant>Maintain SMP ID List",
            self.catalog.by_route["/UI/uiSmpIdListSearchTable"].menu_path,
        )

    def test_unique_following_page_repairs_wrong_parent_and_child(self) -> None:
        source = flow(
            "/UI/uiSmpIdSearchTable",
            "Maintain SMP ID",
            "pageExplore/pages/uiSmpIdSearchTable.md",
            "Participant>Maintain SMP ID List",
        )
        repaired, repairs = contract.repair_page_contract(source, PAGE_EXPLORE)

        self.assertEqual(
            'Select Trading Admin Left Menu "SMP>Maintain SMP ID"',
            repaired["steps"][3],
        )
        self.assertEqual("MENU_PATH_FROM_UNIQUE_PAGE", repairs[0]["code"])
        self.assertEqual([], contract.validate_page_contract(repaired, PAGE_EXPLORE))

    def test_smp_id_list_remains_a_distinct_participant_page(self) -> None:
        source = flow(
            "/UI/uiSmpIdListSearchTable",
            "Maintain SMP ID List",
            "pageExplore/pages/uiSmpIdListSearchTable.md",
            "Participant>Maintain SMP ID List",
        )
        source["steps"][4]["table"] = [["SMP ID List ID"], ["smp_id_list"]]
        self.assertEqual([], contract.validate_page_contract(source, PAGE_EXPLORE))

    def test_operation_without_prior_navigation_is_blocked(self) -> None:
        source = flow(
            "/UI/uiSmpIdSearchTable",
            "Maintain SMP ID",
            "pageExplore/pages/uiSmpIdSearchTable.md",
            "SMP>Maintain SMP ID",
        )
        del source["steps"][3]
        codes = {
            item["code"]
            for item in contract.validate_page_contract(source, PAGE_EXPLORE)
        }
        self.assertIn("OPERATION_MISSING_PRIOR_NAVIGATION", codes)
        self.assertIn("PRIMARY_PAGE_NOT_NAVIGATED", codes)

    def test_operation_on_a_different_selected_page_is_blocked(self) -> None:
        source = flow(
            "/UI/uiSmpIdSearchTable",
            "Maintain SMP ID",
            "pageExplore/pages/uiSmpIdSearchTable.md",
            "Participant>Maintain SMP ID List",
        )
        codes = {
            item["code"]
            for item in contract.validate_page_contract(source, PAGE_EXPLORE)
        }
        self.assertIn("OPERATION_PAGE_DOES_NOT_MATCH_SELECTED_MENU", codes)
        self.assertIn("PRIMARY_PAGE_NOT_NAVIGATED", codes)

    def test_profile_rejects_a_field_from_a_similar_page(self) -> None:
        source = flow(
            "/UI/uiSmpIdSearchTable",
            "Maintain SMP ID",
            "pageExplore/pages/uiSmpIdSearchTable.md",
            "SMP>Maintain SMP ID",
        )
        source["steps"][4]["table"] = [["SMP ID List ID"], ["wrong"]]
        issues = contract.validate_page_contract(source, PAGE_EXPLORE)
        self.assertIn(
            "TABLE_FIELD_NOT_IN_PAGE_PROFILE", {item["code"] for item in issues}
        )

    def test_route_deterministically_repairs_label_and_profile(self) -> None:
        source = flow(
            "/UI/uiSmpIdSearchTable",
            "Maintain SMP ID",
            "wrong/profile.md",
            "SMP>Maintain SMP ID",
        )
        source["page"]["label"] = "Maintain SMP ID List"
        repaired, repairs = contract.repair_page_contract(source, PAGE_EXPLORE)
        self.assertEqual("Maintain SMP ID", repaired["page"]["label"])
        self.assertEqual(
            "pageExplore/pages/uiSmpIdSearchTable.md", repaired["page"]["profile"]
        )
        self.assertEqual(2, len(repairs))

    def test_generic_non_smp_page_uses_same_contract(self) -> None:
        source = {
            "page": {
                "label": "Maintain Exchange",
                "route": "/UI/uiExchangeSearchTable",
                "profile": "pageExplore/pages/uiExchangeSearchTable.md",
            },
            "steps": [
                "Open browser",
                'Select Trading Admin Left Menu "Inst. Hierarchy>Maintain Exchange"',
                {
                    "text": 'Search in Trading Admin "Maintain Exchange" page with:',
                    "table": [["Exchange ID"], ["exchange_id"]],
                },
            ],
        }
        self.assertEqual([], contract.validate_page_contract(source, PAGE_EXPLORE))

    def test_browser_switch_restores_each_sessions_page_state(self) -> None:
        source = flow(
            "/UI/uiSmpIdSearchTable",
            "Maintain SMP ID",
            "pageExplore/pages/uiSmpIdSearchTable.md",
            "SMP>Maintain SMP ID",
        )
        source["steps"].extend(
            [
                "Open browser",
                "Save current browser to browser_admin_gui_user2",
                'Select Trading Admin Left Menu "Countersign>Countersign Request"',
                'Switch browser to "browser_admin_gui_user1" and maximize',
                {
                    "text": 'Check table "Maintain SMP ID" contains visible rows with:',
                    "table": [["SMP ID"], ["smp_id"]],
                },
            ]
        )
        self.assertEqual([], contract.validate_page_contract(source, PAGE_EXPLORE))


if __name__ == "__main__":
    unittest.main()

