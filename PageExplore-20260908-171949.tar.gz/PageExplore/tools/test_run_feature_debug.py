#!/usr/bin/env python3
"""Boundary tests for the Feature execution/repair wrapper."""

from __future__ import annotations

import hashlib
import json
import os
import subprocess
import tempfile
import textwrap
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
RUNNER = ROOT / "tools" / "run_feature_debug.rb"


class FeatureRepairBoundaryTest(unittest.TestCase):
    def test_custom_ruby_step_failure_never_invokes_repair_or_changes_files(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            runtime = Path(temporary)
            feature = runtime / "features" / "case.feature"
            custom_step = runtime / "features" / "customized_steps" / "user_special_steps.rb"
            feature.parent.mkdir(parents=True)
            custom_step.parent.mkdir(parents=True)
            feature.write_text(
                textwrap.dedent(
                    """\
                    @FEATURE=Binary
                    Feature: custom step boundary

                    Scenario: use a user step
                        * User special action
                    """
                ),
                encoding="utf-8",
            )
            custom_step.write_text(
                'Given(/^User special action$/) { nil.missing_user_method }\n',
                encoding="utf-8",
            )
            feature_before = hashlib.sha256(feature.read_bytes()).hexdigest()
            ruby_before = hashlib.sha256(custom_step.read_bytes()).hexdigest()

            fake_cucumber = runtime / "fake_cucumber.rb"
            fake_cucumber.write_text(
                textwrap.dedent(
                    """\
                    #!/usr/bin/env ruby
                    warn "features/customized_steps/user_special_steps.rb:42:in `block': undefined method `missing_user_method' for nil:NilClass (NoMethodError)"
                    warn "1 scenario (1 failed)"
                    warn "1 step (1 failed)"
                    exit 1
                    """
                ),
                encoding="utf-8",
            )
            fake_cucumber.chmod(0o755)
            repair_marker = runtime / "repair-command-was-called"
            fake_repair = runtime / "fake_repair.rb"
            fake_repair.write_text(
                textwrap.dedent(
                    f"""\
                    #!/usr/bin/env ruby
                    File.write({str(repair_marker)!r}, "called\\n")
                    exit 0
                    """
                ),
                encoding="utf-8",
            )
            fake_repair.chmod(0o755)
            report = runtime / "report.json"

            result = subprocess.run(
                [
                    "ruby",
                    str(RUNNER),
                    str(feature),
                    "--workdir",
                    str(runtime),
                    "--cucumber-command",
                    str(fake_cucumber),
                    "--report",
                    str(report),
                    "--repair",
                    "--repair-opencode-command",
                    str(fake_repair),
                    "--data-preflight",
                    "off",
                ],
                cwd=ROOT,
                env=os.environ.copy(),
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                timeout=30,
                check=False,
            )

            self.assertNotEqual(0, result.returncode, result.stdout)
            payload = json.loads(report.read_text(encoding="utf-8"))
            self.assertEqual(
                "custom_step_implementation",
                payload["execution"]["failure_classification"]["category"],
            )
            self.assertEqual("blocked_runtime", payload["repair"]["status"])
            self.assertEqual(
                "custom_step_implementation", payload["repair"]["stop_reason"]
            )
            self.assertEqual([], payload["repair"]["attempts"])
            self.assertFalse(repair_marker.exists(), result.stdout)
            self.assertEqual(feature_before, hashlib.sha256(feature.read_bytes()).hexdigest())
            self.assertEqual(ruby_before, hashlib.sha256(custom_step.read_bytes()).hexdigest())


if __name__ == "__main__":
    unittest.main()
