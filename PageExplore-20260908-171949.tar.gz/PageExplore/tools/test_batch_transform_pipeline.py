#!/usr/bin/env python3
"""Local integration tests for the split Admin/Hybrid batch pipeline."""

from __future__ import annotations

import json
import os
import subprocess
import tempfile
import textwrap
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BATCH = ROOT / "tools" / "batch_transform_tc.rb"
CONVERTER = ROOT / "tools" / "admin_feature_converter.py"
STEP_INDEX = ROOT / "odpt-automation-skill" / "Step_Index.json"


class SplitHybridPipelineTest(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        self.excel = self.root / "excel"
        self.yaml = self.root / "yaml"
        self.target = self.root / "target"
        self.flows = self.root / "flows"
        self.binary = self.root / "binary"
        self.excel_skill = self.root / "excel-skill"
        for directory in (
            self.excel,
            self.yaml,
            self.target,
            self.flows,
            self.binary,
            self.excel_skill,
        ):
            directory.mkdir()

        self.case_base = "ODP-T2194_case"
        (self.excel / f"{self.case_base}.xlsx").write_bytes(b"mock workbook")
        self._write_fake_excel_parser()
        self._write_admin_flow()
        self._write_binary_feature()
        self.run_log = self.root / "feature-runs.jsonl"
        self.runner = self.root / "fake_feature_runner.rb"
        self._write_fake_feature_runner()

    def tearDown(self) -> None:
        self.temporary.cleanup()

    def _write_fake_excel_parser(self) -> None:
        parser = self.excel_skill / "parse_excel.py"
        parser.write_text(
            textwrap.dedent(
                """\
                import json
                import os
                import sys

                if "--all" in sys.argv:
                    print(json.dumps([{"key": "ODP-T2194"}]))
                elif "--yaml" in sys.argv:
                    mode = os.environ.get("FAKE_CASE_MODE", "hybrid")
                    lines = ["---", "Key: ODP-T2194", "TestSteps:"]
                    if mode in {"admin", "hybrid", "hybrid_cross_day"}:
                        lines.extend([
                            "- Key: ODP-T2194",
                            '  Test Script (Step-by-Step) - Step: "Maintain SMP ID"',
                            '  PageExplore Profile: "pageExplore/pages/uiSmpIdSearchTable.md"',
                            '  Execution Channel: "admin_gui"',
                        ])
                    if mode in {"binary", "hybrid", "hybrid_cross_day"}:
                        lines.extend([
                            '- Test Script (Step-by-Step) - Step: "Send Day1 order"',
                            '  Execution Channel: "binary_proxy"',
                        ])
                    if mode == "hybrid_cross_day":
                        lines.extend([
                            '- Test Script (Step-by-Step) - Step: "After night batch advance to next business day and wait for market status OPEN"',
                            '  Execution Channel: "batch"',
                            '- Test Script (Step-by-Step) - Step: "Send Day2 order"',
                            '  Execution Channel: "binary_proxy"',
                        ])
                    print("\\n".join(lines))
                else:
                    raise SystemExit(2)
                """
            ),
            encoding="utf-8",
        )

    def _write_admin_flow(self) -> None:
        flow = {
            "schema_version": 1,
            "flow_id": "admin.odp-t2194.mock.v1",
            "case_id": "ODP-T2194",
            "name": "ODP-T2194 standalone Admin setup",
            "channel": "hybrid",
            "evidence_status": "verified",
            "page": {
                "label": "Maintain SMP ID",
                "route": "/UI/uiSmpIdSearchTable",
                "profile": "pageExplore/pages/uiSmpIdSearchTable.md",
            },
            "tags": ["@FEATURE=Binary", "@ADMIN_SETUP"],
            "steps": [
                "Open browser",
                {
                    "text": "Login Trading Admin with:",
                    "table": [
                        ["User ID", "User Password"],
                        ["admin_gui_user1", "admin_gui_user1_password"],
                    ],
                },
                "Clear Alert If Exist",
                "Save current browser to browser_admin_gui_user1",
                'Select Trading Admin Left Menu "SMP>Maintain SMP ID"',
                {
                    "text": 'Search in Trading Admin "Maintain SMP ID" page with:',
                    "table": [["SMP ID"], ["smp_id"]],
                },
            ],
            "source_coverage": [
                {
                    "yaml_step_index": 1,
                    "flow_step_indices": [1, 2, 3, 4, 5, 6],
                    "intent": ["navigation", "search"],
                }
            ],
            "evidence": {},
            "reuse": {
                "keywords": ["SMP ID", "Maintain SMP ID"],
                "safe_to_reuse": True,
            },
        }
        (self.flows / "ODP-T2194.json").write_text(
            json.dumps(flow, indent=2) + "\n", encoding="utf-8"
        )

    def _write_binary_feature(self) -> None:
        (self.binary / "ODP-T2194.feature").write_text(
            textwrap.dedent(
                """\
                @FEATURE=Binary @CASE=ODP-T2194
                Feature: ODP-T2194 non-Admin continuation

                Scenario: send one order
                    * Set ISODP true
                    * Wait 1 seconds
                """
            ),
            encoding="utf-8",
        )

    def _write_cross_day_features(self) -> None:
        (self.binary / "ODP-T2194-Day1.feature").write_text(
            textwrap.dedent(
                """\
                @FEATURE=Binary @CASE=ODP-T2194-Day1
                Feature: ODP-T2194 Day1

                Scenario: verify CA before night batch
                    * Set ISODP true
                    * Wait 1 seconds
                    * Save FIX dumpfile ODP-T2194-Day1
                """
            ),
            encoding="utf-8",
        )
        (self.binary / "ODP-T2194-Day2.feature").write_text(
            textwrap.dedent(
                """\
                @FEATURE=Binary @CASE=ODP-T2194-Day2
                Feature: ODP-T2194 Day2

                Background:
                    * Load FIX dumpfile ODP-T2194-Day1

                Scenario: verify CP after effective date
                    * Set ISODP true
                    * Wait 1 seconds
                """
            ),
            encoding="utf-8",
        )

    def _write_fake_feature_runner(self) -> None:
        self.runner.write_text(
            textwrap.dedent(
                """\
                #!/usr/bin/env ruby
                require 'digest'
                require 'fileutils'
                require 'json'

                feature = File.expand_path(ARGV.fetch(0))
                report_index = ARGV.index('--report')
                report = File.expand_path(ARGV.fetch(report_index + 1))
                event = { 'feature' => feature, 'args' => ARGV }
                File.open(ENV.fetch('FAKE_RUN_LOG'), 'a') { |file| file.puts(JSON.generate(event)) }

                mutation_marker = ENV.fetch('FAKE_MUTATION_MARKER')
                mutate_admin = ENV['FAKE_MUTATE_ADMIN_ONCE'] == '1' &&
                               feature.end_with?('.admin.feature') &&
                               !File.exist?(mutation_marker)
                if mutate_admin
                  File.open(feature, 'a') { |file| file.puts("    * Wait 99 seconds") }
                  File.write(mutation_marker, "mutated\\n")
                end
                fail_admin = ENV['FAKE_ADMIN_FAIL'] == '1' && feature.end_with?('.admin.feature')
                status = fail_admin ? 'failed' : 'passed'
                category = fail_admin ? 'assertion_mismatch' : 'none'
                payload = {
                  'feature' => {
                    'path' => feature,
                    'sha256' => Digest::SHA256.file(feature).hexdigest
                  },
                  'execution' => {
                    'status' => status,
                    'failure_classification' => { 'category' => category }
                  }
                }
                FileUtils.mkdir_p(File.dirname(report))
                File.write(report, JSON.pretty_generate(payload) + "\\n")
                exit(fail_admin ? 1 : 0)
                """
            ),
            encoding="utf-8",
        )

    def run_batch(
        self,
        *,
        fail_admin: bool = False,
        mutate_admin_once: bool = False,
        case_mode: str = "hybrid",
    ) -> subprocess.CompletedProcess[str]:
        if case_mode == "admin":
            flow_path = self.flows / "ODP-T2194.json"
            flow = json.loads(flow_path.read_text())
            flow["channel"] = "admin"
            flow_path.write_text(json.dumps(flow, indent=2) + "\n")
        environment = os.environ.copy()
        environment.update(
            {
                "EXCEL_YAML_SKILL": str(self.excel_skill),
                "AUTO_SKILL": str(ROOT / "odpt-automation-skill"),
                "PAGEEXPLORE_ROOT": str(ROOT / "pageExplore"),
                "FAKE_RUN_LOG": str(self.run_log),
                "FAKE_ADMIN_FAIL": "1" if fail_admin else "0",
                "FAKE_MUTATE_ADMIN_ONCE": "1" if mutate_admin_once else "0",
                "FAKE_MUTATION_MARKER": str(self.root / "admin-mutated"),
                "FAKE_CASE_MODE": case_mode,
                "NO_COLOR": "1",
            }
        )
        command = [
            "ruby",
            str(BATCH),
            str(self.excel),
            str(self.yaml),
            str(self.target),
            "--excel-yaml-mode",
            "deterministic",
            "--repair-generated" if mutate_admin_once else "--run-generated",
            "--no-admin-explore",
            "--admin-flow-dir",
            str(self.flows),
            "--binary-base-dir",
            str(self.binary),
            "--admin-converter",
            str(CONVERTER),
            "--step-index",
            str(STEP_INDEX),
            "--feature-runner",
            str(self.runner),
        ]
        return subprocess.run(
            command,
            cwd=ROOT,
            env=environment,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=30,
            check=False,
        )

    def events(self) -> list[dict]:
        if not self.run_log.exists():
            return []
        return [json.loads(line) for line in self.run_log.read_text().splitlines()]

    def test_entrypoint_loads_functional_components(self) -> None:
        environment = os.environ.copy()
        environment["BATCH_HELPER_PATH"] = str(BATCH)
        result = subprocess.run(
            [
                "ruby",
                "-rjson",
                "-e",
                "ARGV.clear; load ENV.fetch('BATCH_HELPER_PATH'); "
                "puts JSON.generate(BatchTransform::COMPONENTS.map(&:name))",
            ],
            cwd=ROOT,
            env=environment,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=30,
            check=False,
        )
        self.assertEqual(0, result.returncode, result.stdout)
        self.assertEqual(
            [
                "BatchTransform::Core",
                "BatchTransform::Admin::Configuration",
                "BatchTransform::Admin::Prompt",
                "BatchTransform::Admin::SemanticValidation",
                "BatchTransform::Admin::EvidenceValidation",
                "BatchTransform::Admin::Exploration",
                "BatchTransform::FeaturePipeline",
                "BatchTransform::ExecutionFlow",
                "BatchTransform::Pipeline",
            ],
            json.loads(result.stdout),
        )

    def test_hybrid_runs_standalone_admin_before_separate_binary(self) -> None:
        result = self.run_batch()
        self.assertEqual(0, result.returncode, result.stdout)

        admin = self.target / f"{self.case_base}.admin.feature"
        non_admin = self.target / f"{self.case_base}.feature"
        self.assertTrue(admin.is_file())
        self.assertTrue(non_admin.is_file())
        self.assertIn("@FEATURE=AdminGUI", admin.read_text())
        self.assertNotIn("Set ISODP true", admin.read_text())
        self.assertIn("Set ISODP true", non_admin.read_text())
        self.assertNotIn("Login Trading Admin with:", non_admin.read_text())

        execution_flow = self.target / f"{self.case_base}.execution-flow.json"
        self.assertTrue(execution_flow.is_file())
        flow = json.loads(execution_flow.read_text())
        self.assertEqual(["admin", "continuation"], [stage["id"] for stage in flow["stages"]])

        events = self.events()
        self.assertEqual([str(admin), str(non_admin)], [item["feature"] for item in events])
        self.assertIn("--playwright-flow", events[0]["args"])
        self.assertNotIn("--playwright-flow", events[1]["args"])

    def test_admin_failure_withholds_non_admin_generation_and_run(self) -> None:
        result = self.run_batch(fail_admin=True)
        self.assertNotEqual(0, result.returncode, result.stdout)

        admin = self.target / f"{self.case_base}.admin.feature"
        non_admin = self.target / f"{self.case_base}.feature"
        self.assertTrue(admin.is_file())
        self.assertFalse(non_admin.exists())
        self.assertEqual([str(admin)], [item["feature"] for item in self.events()])
        self.assertIn("[ADMIN-RUN-FAIL]", result.stdout)

    def test_admin_only_case_runs_only_standalone_admin_feature(self) -> None:
        result = self.run_batch(case_mode="admin")
        self.assertEqual(0, result.returncode, result.stdout)

        admin = self.target / f"{self.case_base}.admin.feature"
        non_admin = self.target / f"{self.case_base}.feature"
        self.assertTrue(admin.is_file())
        self.assertFalse(non_admin.exists())
        self.assertEqual([str(admin)], [item["feature"] for item in self.events()])

    def test_binary_only_case_never_uses_admin_flow(self) -> None:
        binary_source = self.binary / "ODP-T2194.feature"
        wrapper = self.root / "fake_binary_transformer.rb"
        wrapper.write_text(
            textwrap.dedent(
                f'''\
                #!/usr/bin/env ruby
                require 'fileutils'
                FileUtils.cp(
                  {str(binary_source)!r},
                  {str(self.target / f"{self.case_base}.feature")!r}
                )
                '''
            ),
            encoding="utf-8",
        )
        wrapper.chmod(0o755)
        environment = os.environ.copy()
        environment.update(
            {
                "EXCEL_YAML_SKILL": str(self.excel_skill),
                "AUTO_SKILL": str(ROOT / "odpt-automation-skill"),
                "PAGEEXPLORE_ROOT": str(ROOT / "pageExplore"),
                "FAKE_RUN_LOG": str(self.run_log),
                "FAKE_ADMIN_FAIL": "0",
                "FAKE_MUTATE_ADMIN_ONCE": "0",
                "FAKE_MUTATION_MARKER": str(self.root / "admin-mutated"),
                "FAKE_CASE_MODE": "binary",
            }
        )
        result = subprocess.run(
            [
                "ruby",
                str(BATCH),
                str(self.excel),
                str(self.yaml),
                str(self.target),
                "--excel-yaml-mode",
                "deterministic",
                "--run-generated",
                "--no-admin-explore",
                "--admin-flow-dir",
                str(self.flows),
                "--opencode-command",
                str(wrapper),
                "--feature-runner",
                str(self.runner),
            ],
            cwd=ROOT,
            env=environment,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=30,
            check=False,
        )
        self.assertEqual(0, result.returncode, result.stdout)
        generated = self.target / f"{self.case_base}.feature"
        self.assertTrue(generated.is_file())
        self.assertFalse((self.target / f"{self.case_base}.admin.feature").exists())
        events = self.events()
        self.assertEqual([str(generated)], [item["feature"] for item in events])
        self.assertNotIn("--playwright-flow", events[0]["args"])

    def test_admin_behavior_drift_is_rebuilt_and_retested_before_binary(self) -> None:
        result = self.run_batch(mutate_admin_once=True)
        self.assertEqual(0, result.returncode, result.stdout)

        admin = self.target / f"{self.case_base}.admin.feature"
        non_admin = self.target / f"{self.case_base}.feature"
        events = self.events()
        self.assertEqual(
            [str(admin), str(admin), str(non_admin)],
            [item["feature"] for item in events],
        )
        self.assertNotIn("Wait 99 seconds", admin.read_text())
        self.assertIn("behavior realigned with the MCP flow", result.stdout)

    def test_legacy_approve_only_flow_cannot_bypass_admin_exploration(self) -> None:
        flow_path = self.flows / "ODP-T2194.json"
        flow = json.loads(flow_path.read_text())
        flow["steps"] = [
            {
                "text": "Approve if updated with :",
                "table": [
                    [
                        "Current Page",
                        "Approver Browser",
                        "Function Name",
                        "Identifier",
                        "Requester",
                        "Req Status",
                    ],
                    [
                        "SMP ID Detail",
                        "browser_admin_gui_user2",
                        "Maintain SMP ID",
                        "smp_id",
                        "admin_gui_user1",
                        "Pending",
                    ],
                ],
                "mcp_execution": "deferred_to_feature",
            }
        ]
        flow_path.write_text(json.dumps(flow, indent=2) + "\n")

        result = self.run_batch()
        self.assertNotEqual(0, result.returncode, result.stdout)
        self.assertEqual([], self.events())
        self.assertIn("Ignoring incomplete standalone Admin flow", result.stdout)
        self.assertIn("matching reviewed Admin flow manifest", result.stdout)
        self.assertIn("[ADMIN-FLOW-FAIL]", result.stdout)

    def test_wrong_menu_page_contract_is_blocked_before_feature_generation(self) -> None:
        flow_path = self.flows / "ODP-T2194.json"
        flow = json.loads(flow_path.read_text())
        flow["steps"][4] = (
            'Select Trading Admin Left Menu "Participant>Maintain SMP ID List"'
        )
        flow_path.write_text(json.dumps(flow, indent=2) + "\n")

        result = self.run_batch()
        self.assertNotEqual(0, result.returncode, result.stdout)
        self.assertEqual([], self.events())
        self.assertFalse(
            (self.target / f"{self.case_base}.admin.feature").exists()
        )
        self.assertIn("ADMIN_FLOW_SEMANTIC_PREFLIGHT", result.stdout)
        self.assertIn("PAGE_CONTRACT", result.stdout)

    def test_missing_yaml_source_coverage_is_blocked_before_feature_generation(self) -> None:
        flow_path = self.flows / "ODP-T2194.json"
        flow = json.loads(flow_path.read_text())
        del flow["source_coverage"]
        flow_path.write_text(json.dumps(flow, indent=2) + "\n")

        result = self.run_batch()
        self.assertNotEqual(0, result.returncode, result.stdout)
        self.assertEqual([], self.events())
        self.assertFalse(
            (self.target / f"{self.case_base}.admin.feature").exists()
        )
        self.assertIn("SOURCE_COVERAGE_MISSING", result.stdout)

    def test_yaml_page_profile_conflict_is_blocked_before_feature_generation(self) -> None:
        flow_path = self.flows / "ODP-T2194.json"
        flow = json.loads(flow_path.read_text())
        flow["page"] = {
            "label": "Maintain SMP ID List",
            "route": "/UI/uiSmpIdListSearchTable",
            "profile": "pageExplore/pages/uiSmpIdListSearchTable.md",
        }
        flow["steps"][4] = (
            'Select Trading Admin Left Menu "Participant>Maintain SMP ID List"'
        )
        flow["steps"][5]["text"] = (
            'Search in Trading Admin "Maintain SMP ID List" page with:'
        )
        flow["steps"][5]["table"] = [["SMP ID List ID"], ["smp_id_list"]]
        flow_path.write_text(json.dumps(flow, indent=2) + "\n")

        result = self.run_batch()
        self.assertNotEqual(0, result.returncode, result.stdout)
        self.assertEqual([], self.events())
        self.assertFalse(
            (self.target / f"{self.case_base}.admin.feature").exists()
        )
        self.assertIn("YAML_PAGE_PROFILE_MISMATCH", result.stdout)

    def test_admin_correctness_failure_is_persisted_in_exploration_report(self) -> None:
        report_path = self.root / "exploration-report.json"
        report_path.write_text(
            json.dumps(
                {
                    "schema_version": 1,
                    "status": "passed",
                    "case_id": "ODP-T2194",
                },
                indent=2,
            )
            + "\n",
            encoding="utf-8",
        )
        environment = os.environ.copy()
        environment.update(
            {
                "BATCH_HELPER_PATH": str(BATCH),
                "ADMIN_REPORT_PATH": str(report_path),
            }
        )
        result = subprocess.run(
            [
                "ruby",
                "-e",
                textwrap.dedent(
                    """\
                    ARGV.clear
                    load ENV.fetch('BATCH_HELPER_PATH')
                    record_admin_correctness_failure(
                      ENV.fetch('ADMIN_REPORT_PATH'),
                      'PAGE_CONTRACT:OPERATION_PAGE_DOES_NOT_MATCH_SELECTED_MENU'
                    )
                    """
                ),
            ],
            cwd=ROOT,
            env=environment,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=30,
            check=False,
        )
        self.assertEqual(0, result.returncode, result.stdout)

        report = json.loads(report_path.read_text(encoding="utf-8"))
        self.assertEqual("failed", report["status"])
        self.assertEqual(
            "admin_flow_correctness", report["first_failure"]["stage"]
        )
        self.assertEqual("failed", report["correctness_validation"]["status"])
        self.assertIn(
            "PAGE_CONTRACT[OPERATION_PAGE_DOES_NOT_MATCH_SELECTED_MENU]",
            report["correctness_validation"]["reason"],
        )

    def test_cross_day_hybrid_writes_ordered_flow_and_waits_before_day2(self) -> None:
        self._write_cross_day_features()
        result = self.run_batch(case_mode="hybrid_cross_day")
        self.assertEqual(3, result.returncode, result.stdout)

        admin = self.target / f"{self.case_base}.admin.feature"
        day1 = self.target / f"{self.case_base}-Day1.feature"
        day2 = self.target / f"{self.case_base}-Day2.feature"
        combined = self.target / f"{self.case_base}.feature"
        execution_flow = self.target / f"{self.case_base}.execution-flow.json"
        self.assertTrue(admin.is_file())
        self.assertTrue(day1.is_file())
        self.assertTrue(day2.is_file())
        self.assertFalse(combined.exists())
        self.assertTrue(execution_flow.is_file())
        self.assertIn("Save FIX dumpfile ODP-T2194-Day1", day1.read_text())
        self.assertIn("Load FIX dumpfile ODP-T2194-Day1", day2.read_text())

        flow = json.loads(execution_flow.read_text())
        self.assertEqual("cross_trading_day", flow["lifecycle"])
        self.assertEqual(
            ["admin", "day1", "night_batch", "day2"],
            [stage["id"] for stage in flow["stages"]],
        )
        self.assertEqual("waiting_for_gate", flow["execution"]["status"])
        self.assertEqual("passed", flow["execution"]["stages"]["admin"]["status"])
        self.assertEqual("passed", flow["execution"]["stages"]["day1"]["status"])
        self.assertEqual("waiting", flow["execution"]["stages"]["night_batch"]["status"])
        self.assertEqual("pending", flow["execution"]["stages"]["day2"]["status"])
        self.assertEqual(
            [str(admin), str(day1)],
            [item["feature"] for item in self.events()],
        )
        self.assertIn("[WAIT-GATE]", result.stdout)
        self.assertIn(
            f"ruby {BATCH} --run-execution-flow {execution_flow}", result.stdout
        )

        environment = os.environ.copy()
        environment.update(
            {
                "AUTO_SKILL": str(ROOT / "odpt-automation-skill"),
                "PAGEEXPLORE_ROOT": str(ROOT / "pageExplore"),
                "FAKE_RUN_LOG": str(self.run_log),
                "FAKE_ADMIN_FAIL": "0",
                "FAKE_MUTATE_ADMIN_ONCE": "0",
                "FAKE_MUTATION_MARKER": str(self.root / "admin-mutated"),
                "NO_COLOR": "1",
            }
        )
        resumed = subprocess.run(
            [
                "ruby",
                str(BATCH),
                "--run-execution-flow",
                str(execution_flow),
                "--complete-gate",
                "night_batch",
                "--feature-runner",
                str(self.runner),
            ],
            cwd=ROOT,
            env=environment,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=30,
            check=False,
        )
        self.assertEqual(0, resumed.returncode, resumed.stdout)
        self.assertEqual(
            [str(admin), str(day1), str(day2)],
            [item["feature"] for item in self.events()],
        )
        completed_flow = json.loads(execution_flow.read_text())
        self.assertEqual("passed", completed_flow["execution"]["status"])
        self.assertEqual(
            "completed",
            completed_flow["execution"]["stages"]["night_batch"]["status"],
        )
        self.assertEqual("passed", completed_flow["execution"]["stages"]["day2"]["status"])


if __name__ == "__main__":
    unittest.main()
