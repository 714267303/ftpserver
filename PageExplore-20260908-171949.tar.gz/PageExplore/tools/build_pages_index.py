#!/usr/bin/env python3
"""Build a deterministic index of the maintained Admin GUI page profiles.

``pageExplore/evidence/pageExploreV2.txt`` is a concatenated Playwright
exploration snapshot. The individual files under ``pageExplore/pages/`` are
the maintained profiles and may
contain additional runtime observations (for example the qaGrid contract).
This tool combines both sources without overwriting either one:

* snapshot metadata proves what was present in the exploration capture;
* maintained metadata is used for the profile link and Grid status;
* scalar drift is reported so a stale profile cannot go unnoticed.

The generated JSON is intended for tooling and the Markdown file is intended
for lazy-loading by the transformation skill.  No values from row data or
credentials are copied into the index.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
from pathlib import Path
from typing import Any


SCHEMA_VERSION = 1
PAGE_EXPLORE_ROOT = Path(os.environ.get("PAGEEXPLORE_ROOT", "pageExplore")).expanduser()
MARKER_RE = re.compile(r"^<FILE:(.*?)>\s*$", re.MULTILINE)
SCALAR_KEYS = ("label", "route", "cacheName", "pkField", "hasGrid")


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def sha256_file(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


def knowledge_path(path: Path, root: Path) -> str:
    """Return a mount-independent path when ``path`` belongs to PageExplore."""

    try:
        return path.resolve().relative_to(root.resolve()).as_posix()
    except ValueError:
        return path.as_posix()


def scalar(text: str, key: str) -> str | None:
    """Read a simple YAML-like scalar from a profile front matter block."""

    # Profiles use two-space indentation for nested Grid fields.  Restrict
    # indentation to horizontal whitespace so ``\s*`` cannot consume a prior
    # line while operating in multiline mode.
    match = re.search(r"^[ \t]*" + re.escape(key) + r":\s*(.*)$", text, re.MULTILINE)
    if not match:
        return None
    value = match.group(1).strip()
    if len(value) >= 2 and value[0] == value[-1] and value[0] in {"\"", "'"}:
        value = value[1:-1]
    return value


def bool_scalar(text: str, key: str) -> bool | None:
    value = scalar(text, key)
    if value is None:
        return None
    lowered = value.lower()
    if lowered in {"true", "yes", "y"}:
        return True
    if lowered in {"false", "no", "n"}:
        return False
    return None


def list_scalar(text: str, key: str) -> list[str]:
    """Parse the compact ``["a", "b"]`` lists used by page profiles."""

    value = scalar(text, key)
    if value is None:
        return []
    if value.startswith("[") and value.endswith("]"):
        body = value[1:-1]
        return [item.strip().strip("\"'") for item in body.split(",") if item.strip()]
    return []


def quoted(value: str | None) -> str | None:
    if value is None:
        return None
    value = value.strip()
    if len(value) >= 2 and value[0] == value[-1] and value[0] in {"\"", "'"}:
        return value[1:-1]
    return value


def columns(text: str) -> list[dict[str, str]]:
    """Extract the ordered columns while tolerating hand-formatted profiles."""

    result: list[dict[str, str]] = []
    current: dict[str, str] | None = None
    for line in text.splitlines():
        field_match = re.match(r"^\s*-\s*field:\s*(.*?)\s*$", line)
        if field_match:
            if current is not None:
                result.append(current)
            current = {"field": quoted(field_match.group(1)) or ""}
            continue
        if current is None:
            continue
        header_match = re.match(r"^\s*headerName:\s*(.*?)\s*$", line)
        if header_match:
            current["headerName"] = quoted(header_match.group(1)) or ""
    if current is not None:
        result.append(current)
    return result


def details(text: str) -> list[dict[str, Any]]:
    """Extract detail field labels/types for search and form routing."""

    result: list[dict[str, Any]] = []
    heading: str | None = None
    field: dict[str, str] | None = None
    for line in text.splitlines():
        heading_match = re.match(r"^\s*-\s*heading:\s*(.*?)\s*$", line)
        if heading_match:
            if field is not None:
                field["heading"] = heading or ""
                result.append(field)
                field = None
            heading = quoted(heading_match.group(1)) or ""
            continue
        label_match = re.match(r"^\s*-\s*label:\s*(.*?)\s*$", line)
        if label_match:
            if field is not None:
                field["heading"] = heading or ""
                result.append(field)
            field = {"label": quoted(label_match.group(1)) or ""}
            continue
        type_match = re.match(r"^\s*type:\s*(.*?)\s*$", line)
        if field is not None and type_match:
            field["type"] = quoted(type_match.group(1)) or ""
    if field is not None:
        field["heading"] = heading or ""
        result.append(field)
    return result


def grid_metadata(text: str) -> dict[str, Any]:
    block_match = re.search(r"^gridApi:\s*$([\s\S]*?)(?=^[A-Za-z][A-Za-z0-9_]*:|\Z)", text, re.MULTILINE)
    if not block_match:
        return {}
    block = block_match.group(1)
    value: dict[str, Any] = {}
    for key in ("apiName", "keyPattern", "discovery", "observationStatus", "sharedIndex", "observationIndex"):
        item = scalar(block, key)
        if item is not None:
            value[key] = item
    sub_tables: list[dict[str, str]] = []
    current: dict[str, str] | None = None
    for line in block.splitlines():
        name_match = re.match(r"^\s*-\s*name:\s*(.*?)\s*$", line)
        if name_match:
            if current is not None:
                sub_tables.append(current)
            current = {"name": quoted(name_match.group(1)) or ""}
            continue
        if current is None:
            continue
        for key in ("keyPattern", "observationStatus"):
            item_match = re.match(r"^\s+" + re.escape(key) + r":\s*(.*?)\s*$", line)
            if item_match:
                current[key] = quoted(item_match.group(1)) or ""
    if current is not None:
        sub_tables.append(current)
    if sub_tables:
        value["subTables"] = sub_tables
    return value


def parse_profile(text: str, path: str) -> dict[str, Any]:
    values = {key: scalar(text, key) for key in SCALAR_KEYS}
    parsed: dict[str, Any] = {
        "path": path,
        "label": values.get("label") or Path(path).stem,
        "route": values.get("route") or "",
        "cache_name": values.get("cacheName") or "",
        "pk_field": values.get("pkField") or "",
        "has_grid": bool_scalar(text, "hasGrid"),
        "columns": columns(text),
        "boolean_fields": list_scalar(text, "booleanFields"),
        "code_fields": list_scalar(text, "codeFields"),
        "sample_fields": list_scalar(text, "sampleFields"),
        "details": details(text),
        "grid_api": grid_metadata(text),
    }
    return parsed


def snapshot_profiles(path: Path) -> tuple[list[dict[str, Any]], str]:
    raw = path.read_bytes()
    text = raw.decode("utf-8", errors="replace")
    matches = list(MARKER_RE.finditer(text))
    profiles: list[dict[str, Any]] = []
    for index, match in enumerate(matches):
        file_path = match.group(1).strip()
        start = match.end()
        end = matches[index + 1].start() if index + 1 < len(matches) else len(text)
        body = text[start:end]
        if "/pages/" not in file_path:
            continue
        relative = Path(file_path.lstrip("./"))
        if relative.parent.as_posix() != "pages":
            continue
        parsed = parse_profile(body, relative.as_posix())
        parsed["source"] = {
            "kind": "pageExploreV2",
            "path": path.as_posix(),
            "line": text[: match.start()].count("\n") + 1,
            "sha256": sha256_bytes(body.encode("utf-8")),
        }
        profiles.append(parsed)
    return profiles, sha256_bytes(raw)


def merge_profile(snapshot: dict[str, Any], pages_root: Path) -> dict[str, Any]:
    current_path = pages_root / Path(snapshot["path"]).name
    merged = dict(snapshot)
    merged["current_path"] = current_path.as_posix()
    merged["current_exists"] = current_path.is_file()
    merged["current_sha256"] = sha256_file(current_path) if current_path.is_file() else None
    merged["drift"] = []
    if not current_path.is_file():
        merged["drift"].append("missing_current_profile")
        merged["maintained"] = None
        return merged

    maintained = parse_profile(current_path.read_text(encoding="utf-8", errors="replace"), current_path.as_posix())
    merged["maintained"] = maintained
    for key in ("label", "route", "cache_name", "pk_field", "has_grid"):
        if snapshot.get(key) != maintained.get(key):
            merged["drift"].append(key)
    # A current profile can add a runtime Grid observation without changing
    # the snapshot.  Keep that distinction explicit in the output.
    merged["observation_status"] = (maintained.get("grid_api") or {}).get("observationStatus", "unknown")
    merged["grid_key_pattern"] = (maintained.get("grid_api") or {}).get("keyPattern", "")
    merged["snapshot_has_grid"] = snapshot.get("has_grid")
    merged["maintained_has_grid"] = maintained.get("has_grid")
    return merged


def build(snapshot_path: Path, pages_root: Path) -> dict[str, Any]:
    knowledge_root = pages_root.parent
    profiles, source_hash = snapshot_profiles(snapshot_path)
    merged = [merge_profile(profile, pages_root) for profile in profiles]
    for item in merged:
        item["source"]["path"] = knowledge_path(Path(item["source"]["path"]), knowledge_root)
        item["current_path"] = knowledge_path(Path(item["current_path"]), knowledge_root)
        if item.get("maintained"):
            item["maintained"]["path"] = knowledge_path(
                Path(item["maintained"]["path"]), knowledge_root
            )
    merged.sort(key=lambda item: (item.get("route", ""), item.get("path", "")))
    drift = [item for item in merged if item.get("drift")]
    return {
        "schema_version": SCHEMA_VERSION,
        "source": {
            "snapshot": knowledge_path(snapshot_path, knowledge_root),
            "sha256": source_hash,
        },
        "maintained_root": knowledge_path(pages_root, knowledge_root),
        "stats": {
            "snapshot_profiles": len(profiles),
            "maintained_profiles": sum(1 for item in merged if item.get("current_exists")),
            "has_grid": sum(1 for item in merged if item.get("snapshot_has_grid") is True),
            "no_grid": sum(1 for item in merged if item.get("snapshot_has_grid") is False),
            "observation_status": _counts(item.get("observation_status", "unknown") for item in merged),
            "drifted_profiles": len(drift),
        },
        "profiles": merged,
    }


def _counts(values: Any) -> dict[str, int]:
    counts: dict[str, int] = {}
    for value in values:
        key = str(value)
        counts[key] = counts.get(key, 0) + 1
    return dict(sorted(counts.items()))


def markdown(payload: dict[str, Any], json_path: Path) -> str:
    stats = payload["stats"]
    lines = [
        "# Admin GUI Pages Index",
        "",
        "This file is generated by `tools/build_pages_index.py`. It combines the",
        "`evidence/pageExploreV2.txt` exploration snapshot with the maintained profiles",
        "under `pages/`; it does not replace either source.",
        "",
        "## Provenance",
        "",
        f"- Snapshot: `{payload['source']['snapshot']}`",
        f"- Snapshot SHA-256: `{payload['source']['sha256']}`",
        f"- Machine-readable index: [`{json_path.name}`]({json_path.name})",
        "",
        "## Coverage",
        "",
        "| Metric | Count |",
        "|---|---:|",
        f"| Snapshot profiles | {stats['snapshot_profiles']} |",
        f"| Maintained profiles present | {stats['maintained_profiles']} |",
        f"| Profiles marked `hasGrid: true` | {stats['has_grid']} |",
        f"| Profiles marked `hasGrid: false` | {stats['no_grid']} |",
        f"| Profiles with metadata drift | {stats['drifted_profiles']} |",
        "",
        "Observation status is read from the maintained `gridApi` block:",
        ", ".join(f"`{key}`={value}" for key, value in stats["observation_status"].items()) or "`unknown`=0",
        ".",
        "",
    ]
    if stats["drifted_profiles"]:
        lines.extend(["## Drift", "", "| Profile | Differences |", "|---|---|"])
        for item in payload["profiles"]:
            if item.get("drift"):
                lines.append(f"| `{item['path']}` | {', '.join(item['drift'])} |")
        lines.append("")
    lines.extend([
        "## Profiles",
        "",
        "| # | Label | Route | Grid | Primary key | Grid observation | Profile |",
        "|---:|---|---|:---:|---|---|---|",
    ])
    for index, item in enumerate(payload["profiles"], 1):
        profile_name = Path(item["path"]).name
        profile_link = f"[{profile_name}]({profile_name})"
        grid = "yes" if item.get("snapshot_has_grid") else "no"
        status = item.get("observation_status", "unknown")
        lines.append(
            f"| {index} | {item['label']} | `{item['route']}` | {grid} | "
            f"`{item['pk_field'] or '-'}` | `{status}` | {profile_link} |"
        )
    lines.extend([
        "",
        "## Refresh",
        "",
        "```bash",
        "python3 tools/build_pages_index.py",
        "```",
        "",
        "Use `--check` in CI or before a transformation to fail when the generated",
        "index is stale. A profile is considered drifted when its route, label,",
        "cache name, primary key, or `hasGrid` value differs from the snapshot.",
        "",
    ])
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--snapshot", default=str(PAGE_EXPLORE_ROOT / "evidence" / "pageExploreV2.txt"))
    parser.add_argument("--pages-root", default=str(PAGE_EXPLORE_ROOT / "pages"))
    parser.add_argument("--output-json", default=str(PAGE_EXPLORE_ROOT / "pages" / "INDEX.json"))
    parser.add_argument("--output-md", default=str(PAGE_EXPLORE_ROOT / "pages" / "INDEX.md"))
    parser.add_argument("--check", action="store_true", help="fail if generated files differ")
    args = parser.parse_args()

    snapshot_path = Path(args.snapshot)
    pages_root = Path(args.pages_root)
    if not snapshot_path.is_file():
        print(f"ERROR: snapshot does not exist: {snapshot_path}", file=sys.stderr)
        return 2
    payload = build(snapshot_path, pages_root)
    json_text = json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=False) + "\n"
    md_text = markdown(payload, Path(args.output_json))
    json_path = Path(args.output_json)
    md_path = Path(args.output_md)
    if args.check:
        stale = []
        if not json_path.is_file() or json_path.read_text(encoding="utf-8") != json_text:
            stale.append(str(json_path))
        if not md_path.is_file() or md_path.read_text(encoding="utf-8") != md_text:
            stale.append(str(md_path))
        if stale:
            print("STALE: " + ", ".join(stale), file=sys.stderr)
            return 1
        print("Pages index is up to date")
        return 0
    json_path.parent.mkdir(parents=True, exist_ok=True)
    md_path.parent.mkdir(parents=True, exist_ok=True)
    json_path.write_text(json_text, encoding="utf-8")
    md_path.write_text(md_text, encoding="utf-8")
    print(f"Wrote {json_path} and {md_path}")
    print(
        f"Profiles: {payload['stats']['snapshot_profiles']}; "
        f"drifted: {payload['stats']['drifted_profiles']}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
