# frozen_string_literal: true

# Shared output, conversion, filesystem, and OpenCode process helpers.

module BatchTransform
  module Core
    private

    def register_batch_redaction_values(values)
      Array(values).each do |value|
        text = value.to_s
        next if text.empty?

        BATCH_REDACTION_VALUES << text unless BATCH_REDACTION_VALUES.include?(text)
      end
    end

    def log(msg)
      puts "#{GREEN}[TC-BATCH]#{RESET} #{redact_batch(msg)}"
    end

    # Batch conversion and Feature execution may echo prompts, paths, or runtime
    # diagnostics.  Keep the terminal output consistent with the standalone
    # runner's redacted logs so a copied transcript does not become a secret
    # transport.
    def redact_sensitive_table_values_batch(text, sensitive_key)
      active_columns = nil
      text.to_s.each_line.map do |line|
        unless line.include?('|')
          active_columns = nil
          next line
        end

        cells = line.split('|', -1)
        header_columns = cells.each_index.select do |index|
          cells[index].match?(Regexp.new("\\A\\s*(?:user\\s+)?#{sensitive_key}\\s*\\z", Regexp::IGNORECASE))
        end
        if header_columns.any?
          active_columns = header_columns
          next line
        end

        separator = cells.all? { |cell| cell.match?(/\A\s*:?-{3,}:?\s*\z/) || cell.strip.empty? }
        next line if separator || active_columns.nil?

        active_columns.each do |index|
          next if index >= cells.length

          cells[index] = cells[index].sub(/\S.*\S|\S/) { '<redacted>' }
        end
        cells.join('|')
      end.join
    end

    def redacted_token_preserving_quotes(value)
      text = value.to_s
      return '"<redacted>"' if text.start_with?('"')
      return "'<redacted>'" if text.start_with?("'")

      '<redacted>'
    end

    def redact_batch(value)
      text = value.to_s.encode('UTF-8', invalid: :replace, undef: :replace, replace: '?')
      # Scrub longer values first so one credential cannot expose part of another.
      BATCH_REDACTION_VALUES.sort_by { |item| -item.length }.each do |secret|
        variants = [secret]
        begin
          variants << JSON.generate(secret)[1...-1]
        rescue StandardError
          nil
        end
        variants.compact.uniq.each do |variant|
          next if variant.empty?

          text = text.gsub(variant, '<redacted>')
        end
      end
      text = text.gsub(/[0-9a-f]{8}-[0-9a-f-]{27,}/i, '<uuid>')
      text = text.gsub(/[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}/i, '<email>')
      sensitive_key = '(?:user(?:name|[\\s_-]*id)?|login(?:name|[\\s_-]*id)?|password|passwd|secret|token|access[\\s_-]*token|refresh[\\s_-]*token|api[\\s_-]*key|client[\\s_-]*secret|authorization|proxy[\\s_-]*authorization)'
      sensitive_key_with_prefix = "(?<![A-Za-z0-9])(?:[A-Za-z0-9]+[_-])*#{sensitive_key}"
      quoted_value = '(?:"(?:\\\\.|[^"])*"|\'(?:\\\\.|[^\'])*\')'
      text = text.gsub(/((?:-p|--password|--passwd|--secret|--token|--api[_-]?key)\s+)(?:#{quoted_value}|[^\s,|}\]]+)/i, '\\1<redacted>')
      text = text.gsub(/((?:["']?)(?:authorization|proxy[\\s_-]*authorization)(?:["']?)\s*[:=]\s*(?:bearer|basic|token)\s+)#{quoted_value}|((?:["']?)(?:authorization|proxy[\\s_-]*authorization)(?:["']?)\s*[:=]\s*(?:bearer|basic|token)\s+)[^\s,|}\]]+/i) do
        prefix = Regexp.last_match(1) || Regexp.last_match(2)
        "#{prefix}<redacted>"
      end
      text = text.gsub(/((?:["']?#{sensitive_key_with_prefix}["']?|:\s*#{sensitive_key})\s*(?:\\?=\\?>|\\?=|\\?:)\s*)(#{quoted_value}|[^,\s|}\]\r\n]+)/i) do
        "#{Regexp.last_match(1)}#{redacted_token_preserving_quotes(Regexp.last_match(2))}"
      end
      text = text.gsub(/([|][ \t]*(?:user[ \t]+)?#{sensitive_key}[ \t]*[|][ \t]*)(?=[^|\r\n]*\S)[^|\r\n]*/i, '\\1<redacted>')
      text = text.gsub(/(\b(?:Bearer|Basic|Token)\s+)[^\s,|}\]]+/i, '\\1<redacted>')
      redact_sensitive_table_values_batch(text, sensitive_key)
    end

    def warn(msg)
      puts "#{YELLOW}[WARN]#{RESET} #{redact_batch(msg)}"
    end

    def error(msg)
      puts "#{RED}[ERROR]#{RESET} #{redact_batch(msg)}"
    end

    def info(msg)
      puts "#{CYAN}[INFO]#{RESET} #{redact_batch(msg)}"
    end

    # Format elapsed seconds into a human-readable string
    def format_elapsed(seconds)
      if seconds >= 3600
        hrs  = (seconds / 3600).to_i
        mins = ((seconds % 3600) / 60).to_i
        secs = (seconds % 60).to_i
        format('%02d:%02d:%02d', hrs, mins, secs)
      elsif seconds >= 60
        mins = (seconds / 60).to_i
        secs = (seconds % 60).to_i
        format('%02d:%02d', mins, secs)
      else
        format('%.1fs', seconds)
      end
    end

    # Build opencode command to convert Excel to YAML
    def model_flag_present?(tokens)
      tokens.any? do |token|
        value = token.to_s
        value == '--model' || value == '-m' || value.start_with?('--model=')
      end
    end

    def append_opencode_model(tokens, model = OPENCODE_MODEL)
      value = model.to_s.strip
      return tokens if value.empty? || model_flag_present?(tokens)

      tokens + ['--model', value]
    end

    def build_opencode_command(prompt)
      tokens = Shellwords.split(OPENCODE_CONVERSION_COMMAND.to_s)
      raise ArgumentError, 'opencode conversion command is empty' if tokens.empty?
      if tokens.any? { |token| token.to_s.match?(/\A--(?:auto|dangerously-skip-permissions)(?:=|\z)/) }
        raise ArgumentError, 'opencode conversion command cannot enable automatic/dangerous permissions'
      end
      tokens = append_opencode_model(tokens)

      replaced = false
      tokens = tokens.map do |token|
        if token.include?('{prompt}')
          replaced = true
          token.gsub('{prompt}', prompt)
        else
          token
        end
      end
      tokens << prompt unless replaced
      Shellwords.join(tokens)
    end

    def excel_to_yaml_prompt(excel_path, yaml_path, parsed_json_path: nil)
      if parsed_json_path
        <<~TEXT
          Read the local Excel-to-YAML instructions at '#{File.join(EXCEL_YAML_SKILL, 'SKILL.md')}' and '#{File.join(EXCEL_YAML_SKILL, 'rules.md')}', then convert the pre-parsed Excel test case JSON '#{parsed_json_path}' to yaml and save to '#{yaml_path}'. Do not invoke a named/registered skill alias for this local path; the runtime may not register filesystem skills.
          The JSON was produced from source Excel '#{excel_path}' by parse_excel.py --all before this opencode run.
          Treat the JSON as the authoritative Excel content. Do not run shell, bash, python, or any executable tool, and do not read the binary Excel file.
          Preserve every literal value from each JSON `steps[i].testdata` field in
          the corresponding YAML `TestSteps[i]` Test Data block. You may reformat
          the block, but never replace a source ID/code/value with an alias taken
          from the precondition, step text, specification, or PageExplore. If
          source fields conflict, retain the source Test Data values and expose the
          ambiguity instead of silently choosing one.
          Use ODP documents from '#{ODP_DOC_INDEX}' only to clarify business intent, and PageExplore from '#{PAGE_EXPLORE_ROOT}' only to identify Admin/Trading GUI pages, fields, grids, and routes. When an ODP index entry has both `path` and `restored_path`, resolve the document under the index directory using `restored_path` (the source-relative `path` may not exist in the bundle).
          Add Execution Channel metadata to every TestSteps item. Save exactly to '#{yaml_path}', not to a filename derived from the skill template.
        TEXT
      else
        "Read the local Excel-to-YAML instructions at '#{File.join(EXCEL_YAML_SKILL, 'SKILL.md')}' and '#{File.join(EXCEL_YAML_SKILL, 'rules.md')}', then process the excel test case '#{excel_path}' to yaml and save to '#{yaml_path}'. Do not invoke a named/registered skill alias for this local path; the runtime may not register filesystem skills."
      end
    end

    def build_excel_to_yaml_command(excel_path, yaml_path, parsed_json_path: nil)
      build_opencode_command(excel_to_yaml_prompt(excel_path, yaml_path, parsed_json_path: parsed_json_path))
    end

    # Build opencode command to transform YAML to target
    def yaml_transform_prompt(yaml_path, channel_override: nil, target_dir: nil, exclude_admin: false,
                              lifecycle: nil, output_base_name: nil)
      destination = target_dir || TARGET_DIR
      requested_channel = channel_override || TRANSFORM_CHANNEL
      prompt = "Read the local automation instructions at '#{File.join(AUTO_SKILL, 'SKILL.md')}' and the relevant rule/index files under '#{AUTO_SKILL}', then transform test case '#{yaml_path}' to '#{destination}'. Do not invoke a named/registered skill alias for this local path; the runtime may not register filesystem skills."
      prompt += <<~TEXT

        Apply the current skill contracts: for Binary or Hybrid state hand-off emit
        `Save FIX dumpfile <name>` and `Load FIX dumpfile <name>` (never the legacy
        `Save/Load bigmap file` names). For Admin maker/checker workflows, each
        `Login Trading Admin with:` table must contain one user and each user must
        have its own `Open browser` and `Save current browser` session. Consult the
        review-gated `repair_experience/INDEX.md`; candidate entries are human
        review material and are not executable instructions. The independent
        PageExplore knowledge root is '#{PAGE_EXPLORE_ROOT}'; read page profiles
        and qaGrid knowledge there, not from the user Skill directory.
        ODP business specifications are indexed at '#{ODP_DOC_INDEX}'. Select the
        relevant FS document from that index to preserve business intent; when an
        entry has both `path` and `restored_path`, read `restored_path` below the
        index directory because `path` is source-relative and may not exist. Do not
        copy business prose as executable steps, and keep runtime Step_Index and
        installed step definitions authoritative for Gherkin syntax.
        Prefer project-owned runtime steps under '#{File.join(SCRIPT_ROOT, 'features', 'customized_steps')}'
        and Step_Index before generic examples or invented wording. If no executable
        step is proven, emit @REVIEW instead of creating a new unsupported Gherkin step.
      TEXT
      if exclude_admin
        prompt += <<~TEXT

          This source YAML is a Hybrid case, but this invocation creates only the
          independent non-Admin continuation Feature artifact(s). Include
          TestSteps whose Execution Channel is binary_proxy, batch, trading_gui,
          clearing, or manual_or_unspecified when they are needed by the case,
          preserving their source order. Exclude every admin_gui TestStep and do not recreate,
          summarize, or infer any Admin setup from the precondition, objective, or
          prose. The Admin Feature is generated and validated separately from its
          MCP manifest.

          The output must not contain @FEATURE=AdminGUI, @ADMIN_SETUP, `Login
          Trading Admin with:`, saved Admin browser sessions, Trading Admin menu/
          search/form operations, maker/checker setup, or `Approve if updated
          with :`. Do not copy an Admin block merely to make later Binary data seem
          initialized.
        TEXT
        if lifecycle && lifecycle[:cross_day]
          case_id = primary_yaml_identifier(yaml_path)
          feature_base = output_base_name || File.basename(yaml_path, '.yaml')
          dump_name = "#{case_id}-Day1"
          prompt += <<~TEXT

            This YAML has exactly one next-trading-day boundary represented by its
            `batch` TestStep. Emit exactly two fresh Features, named exactly:
              '#{feature_base}-Day1.feature'
              '#{feature_base}-Day2.feature'
            Put non-Admin TestSteps before the batch boundary only in Day1 and
            TestSteps after it only in Day2. The batch TestStep is an external
            orchestration gate: do not render it as Gherkin, `@REVIEW`, `Wait`, a
            shell command, or an invented batch step. End Day1 with exactly
            `* Save FIX dumpfile #{dump_name}` and load that state in the Day2
            Background with exactly `* Load FIX dumpfile #{dump_name}`. Never put
            both days into one Feature and do not create '#{feature_base}.feature'.
          TEXT
        else
          prompt += "\nEmit one fresh non-Admin Feature below '#{destination}'.\n"
        end
      elsif requested_channel != 'auto'
        prompt += "\nThe requested channel is #{requested_channel}; do not silently switch channels."
      end
      prompt
    end

    # Extract stable identifiers from the YAML without requiring a YAML parser.
    # The Excel->YAML stage is allowed to use richer parsing; this lookup only
    # chooses a nearby manifest by filename/key and never interprets test data.
    def yaml_identifiers(yaml_path)
      text = File.read(yaml_path, encoding: 'UTF-8')
      ids = []
      text.scan(/^\s*(?:-\s*)?(?:Key|key):\s*["']?([A-Za-z0-9][A-Za-z0-9._-]*)/).each do |match|
        ids << match[0]
      end
      ids << File.basename(yaml_path, '.*')
      ids.uniq
    rescue StandardError => e
      warn "Cannot inspect YAML identifiers for #{yaml_path}: #{e.message}"
      [File.basename(yaml_path, '.*')]
    end

    # Read the constrained routing scalar emitted by the Excel-to-YAML stage. This
    # deliberately does not deserialize arbitrary YAML objects; it only accepts the
    # documented single-line field and validates every observed value below.
    def yaml_execution_channels(yaml_path)
      channels = []
      File.foreach(yaml_path, encoding: 'UTF-8') do |line|
        match = line.match(
          /^\s*(?:-\s*)?(?:Execution Channel|execution_channel):\s*(?:"([^"]+)"|'([^']+)'|([A-Za-z0-9_-]+))\s*(?:#.*)?$/
        )
        channels << match.captures.compact.first.to_s.strip.downcase if match
      end
      channels.reject(&:empty?).uniq
    rescue StandardError => e
      warn "Cannot inspect YAML execution channels for #{yaml_path}: #{e.message}"
      []
    end

    CROSS_TRADING_DAY_MARKER = /(?:night\s*batch|after\s+(?:the\s+)?(?:night\s*)?batch|next\s+(?:business|trading)\s+day|advance\s+(?:the\s+)?system\s+to\s+(?:the\s+)?next\s+day|夜批|下一?个?交易日|次日)/i

    # The Execution Channel scalar is intentionally inspected without loading an
    # arbitrary YAML object.  A batch step only becomes a lifecycle boundary when
    # the source also says that execution advances to another trading/business
    # day.  Same-day batch utilities therefore remain ordinary non-Admin steps.
    def yaml_lifecycle(yaml_path)
      text = File.read(yaml_path, encoding: 'UTF-8')
      batch_occurrences = text.scan(
        /^\s*(?:-\s*)?(?:Execution Channel|execution_channel):\s*(?:"batch"|'batch'|batch)\s*(?:#.*)?$/i
      ).length
      cross_day = batch_occurrences.positive? && text.match?(CROSS_TRADING_DAY_MARKER)
      {
        kind: cross_day ? 'cross_trading_day' : 'single_run',
        cross_day: cross_day,
        batch_boundaries: cross_day ? batch_occurrences : 0
      }
    rescue StandardError => e
      warn "Cannot inspect YAML lifecycle for #{yaml_path}: #{e.message}"
      { kind: 'single_run', cross_day: false, batch_boundaries: 0 }
    end

    def transform_channel_from_yaml(channels)
      has_admin = channels.include?('admin_gui')
      has_non_admin = channels.any? { |channel| channel != 'admin_gui' }
      return 'hybrid' if has_admin && has_non_admin
      return 'admin' if has_admin
      return 'binary' if has_non_admin

      nil
    end

    # Find a reviewed manifest using exact filenames only. Ambiguous matches are
    # rejected so a case cannot accidentally consume another case's setup.
    def manifest_identifiers(payload, path)
      values = []
      %w[case_id source_yaml yaml_file source_file excel_file].each do |key|
        value = payload[key]
        next unless value.is_a?(String) && !value.strip.empty?

        values << File.basename(value, '.*')
        values << File.basename(value, '.json')
      end
      aliases = payload['aliases']
      if aliases.is_a?(Array)
        values.concat(
          aliases.select { |value| value.is_a?(String) }.map { |value| File.basename(value, '.*') }
        )
      end
      values << File.basename(path, '.json')
      values.map(&:to_s).map(&:strip).reject(&:empty?).uniq
    end

    def reusable_admin_flow?(path)
      payload = JSON.parse(File.read(path, encoding: 'UTF-8'))
      verified = payload['evidence_status'].to_s == 'verified'
      safe = payload.dig('reuse', 'safe_to_reuse') == true
      return true if ALLOW_UNVERIFIED_ADMIN_FLOW
      return true if verified && safe

      warn "Ignoring unverified Admin flow #{path}; require evidence_status=verified and reuse.safe_to_reuse=true"
      false
    rescue StandardError => e
      warn "Ignoring invalid Admin flow #{path}: #{e.message}"
      false
    end

    def find_admin_flow(yaml_path)
      return nil if ADMIN_FLOW_DIR.to_s.strip.empty?

      root = File.expand_path(ADMIN_FLOW_DIR)
      unless File.directory?(root)
        warn "Admin flow directory not found: #{ADMIN_FLOW_DIR}"
        return nil
      end

      identifiers = yaml_identifiers(yaml_path)
      candidates = identifiers.flat_map do |identifier|
        [File.join(root, "#{identifier}.json"), File.join(root, "#{identifier}.admin-flow.json")]
      end.uniq.select { |path| File.file?(path) && !File.symlink?(path) }

      # Scan only JSON manifests and compare stable aliases, never dynamic UI IDs.
      recursive = Dir.glob(File.join(root, '**', '*.json')).select do |path|
        next false if File.symlink?(path)

        begin
          payload = JSON.parse(File.read(path, encoding: 'UTF-8'))
          manifest_identifiers(payload, path).any? do |identifier|
            identifiers.include?(identifier) ||
              identifiers.include?(identifier.sub(/\.admin-flow\z/, ''))
          end
        rescue StandardError
          false
        end
      end
      candidates = (candidates + recursive).uniq.select { |path| reusable_admin_flow?(path) }
      candidates.reject! do |path|
        issues = reusable_admin_flow_case_issues(path, yaml_path)
        next false if issues.empty?

        warn "Ignoring incomplete standalone Admin flow #{path}: #{issues.join(', ')}"
        true
      end

      if candidates.length > 1
        warn "Multiple Admin manifests match #{File.basename(yaml_path)}: #{candidates.join(', ')}"
        return nil
      end
      candidates.first
    end

    def manifest_channel(path)
      value = JSON.parse(File.read(path, encoding: 'UTF-8'))
      channel = value.fetch('channel', 'admin').to_s.downcase
      unless %w[admin hybrid].include?(channel)
        warn "Unsupported Admin manifest channel #{channel.inspect}: #{path}"
        return nil
      end
      channel
    rescue StandardError => e
      warn "Cannot read Admin manifest #{path}: #{e.message}"
      nil
    end

    def find_binary_base(yaml_path, flow_path = nil)
      return nil if BINARY_BASE_DIR.to_s.strip.empty?

      identifiers = yaml_identifiers(yaml_path)
      if flow_path
        begin
          payload = JSON.parse(File.read(flow_path, encoding: 'UTF-8'))
          identifiers.concat(manifest_identifiers(payload, flow_path))
        rescue StandardError => e
          warn "Cannot inspect Admin manifest for Binary base lookup #{flow_path}: #{e.message}"
        end
      end
      identifiers.uniq!
      candidates = identifiers.flat_map do |identifier|
        [File.join(File.expand_path(BINARY_BASE_DIR), "#{identifier}.feature"),
         File.join(File.expand_path(BINARY_BASE_DIR), "#{identifier}.binary.feature")]
      end.uniq.select { |path| File.file?(path) && !File.symlink?(path) }
      if candidates.length > 1
        warn "Multiple Binary base Features match #{File.basename(yaml_path)}: #{candidates.join(', ')}"
        return nil
      end
      candidates.first
    end

    def find_binary_bases(yaml_path, flow_path: nil, lifecycle: { cross_day: false })
      unless lifecycle[:cross_day]
        single = find_binary_base(yaml_path, flow_path)
        return single ? [single] : []
      end
      return [] if BINARY_BASE_DIR.to_s.strip.empty?

      identifiers = yaml_identifiers(yaml_path)
      if flow_path
        begin
          payload = JSON.parse(File.read(flow_path, encoding: 'UTF-8'))
          identifiers.concat(manifest_identifiers(payload, flow_path))
        rescue StandardError => e
          warn "Cannot inspect Admin manifest for cross-day Binary lookup #{flow_path}: #{e.message}"
        end
      end
      root = File.expand_path(BINARY_BASE_DIR)
      pairs = identifiers.uniq.filter_map do |identifier|
        day1 = File.join(root, "#{identifier}-Day1.feature")
        day2 = File.join(root, "#{identifier}-Day2.feature")
        next unless [day1, day2].all? { |path| File.file?(path) && !File.symlink?(path) }

        [day1, day2]
      end
      if pairs.length > 1
        warn "Multiple cross-day Binary Feature pairs match #{File.basename(yaml_path)}: #{pairs.flatten.join(', ')}"
        return []
      end
      pairs.first || []
    end

    def build_admin_converter_command(flow_path, output_path, report_path, strict: false)
      args = [PYTHON_BIN, ADMIN_CONVERTER, '--flow', flow_path, '--output', output_path,
              '--report', report_path, '--step-index', STEP_INDEX,
              '--page-explore-root', PAGE_EXPLORE_ROOT, '--standalone-admin']
      args << '--strict' if STRICT_ADMIN_CONVERSION || strict
      Shellwords.join(args)
    end

    def admin_feature_consistency_command(flow_path, feature_path)
      Shellwords.join([
        PYTHON_BIN,
        ADMIN_CONVERTER,
        '--flow', flow_path,
        '--step-index', STEP_INDEX,
        '--page-explore-root', PAGE_EXPLORE_ROOT,
        '--standalone-admin',
        '--verify-feature', feature_path,
        '--semantic-strict'
      ])
    end

    def validate_admin_feature_consistency(flow_path, feature_path)
      return { ok: false, reason: 'Admin flow is missing' } unless readable_artifact?(flow_path)
      return { ok: false, reason: 'standalone Admin Feature is missing' } unless readable_artifact?(feature_path)

      stdout, stderr, status = Open3.capture3(
        opencode_environment,
        *Shellwords.split(admin_feature_consistency_command(flow_path, feature_path)),
        chdir: Dir.pwd
      )
      if status.success?
        payload = JSON.parse(stdout.lines.find { |line| line.lstrip.start_with?('{') }.to_s)
        return { ok: true, comparison: payload }
      end

      detail = stderr.to_s.strip.empty? ? stdout.to_s.strip : stderr.to_s.strip
      detail = 'standalone Admin Feature consistency validation failed without diagnostics' if detail.empty?
      { ok: false, reason: compact_admin_transcript_error(detail, max_chars: 1200) }
    rescue StandardError => e
      { ok: false, reason: "standalone Admin Feature consistency validation failed: #{e.class}: #{e.message}" }
    end

    # Render one Admin-only executable artifact from the semantic MCP hand-off and
    # immediately prove that no step, ordering, or DataTable value drifted during
    # conversion.  Hybrid callers use this same path: composition with the later
    # Binary/Batch continuation is deliberately not supported here.
    def render_standalone_admin_feature(flow_path:, feature_path:, report_path:, label:)
      before_signature = artifact_signature(feature_path)
      command = build_admin_converter_command(
        flow_path,
        feature_path,
        report_path,
        strict: !ALLOW_UNVERIFIED_ADMIN_FLOW
      )
      result = run_opencode(
        label,
        command,
        environment: conversion_permission_environment(
          read_roots: [File.dirname(flow_path), AUTO_SKILL, STEP_INDEX, ODP_DOC_INDEX,
                       File.dirname(ODP_DOC_INDEX), PAGE_EXPLORE_ROOT, SCRIPT_ROOT],
          edit_roots: [TARGET_DIR]
        )
      )
      failure = conversion_failure_reason(
        result,
        artifact_path: feature_path,
        before_signature: before_signature,
        require_fresh: false
      )
      if failure.nil?
        consistency = validate_admin_feature_consistency(flow_path, feature_path)
        failure = consistency[:reason] unless consistency[:ok]
      end
      { ok: failure.nil?, result: result, reason: failure }
    rescue StandardError => e
      {
        ok: false,
        result: { exit_code: 1, elapsed: 0.0, elapsed_formatted: '0.0s' },
        reason: "standalone Admin Feature rendering failed: #{e.class}: #{e.message}"
      }
    end

    def deterministic_admin_command?(flow_path, force: false)
      return false unless flow_path
      return true if force || ADMIN_CONVERTER_MODE == 'deterministic'

      false
    end

    def admin_output_path(base_name, flow_path)
      File.join(TARGET_DIR, "#{base_name}.admin.feature")
    end

    def admin_report_path(base_name)
      File.join(TARGET_DIR, 'admin_conversion_reports', "#{base_name}.json")
    end

    def excel_parse_artifact_path(yaml_path)
      File.join(File.dirname(yaml_path), '.parsed_excel', "#{File.basename(yaml_path, '.yaml')}.json")
    end

    def parse_excel_to_artifact(excel_path, yaml_path)
      parser = File.join(EXCEL_YAML_SKILL, 'parse_excel.py')
      return [nil, "Excel parser not found: #{parser}"] unless File.file?(parser)

      output_path = excel_parse_artifact_path(yaml_path)
      FileUtils.mkdir_p(File.dirname(output_path))
      stdout, stderr, status = Open3.capture3(PYTHON_BIN, parser, '--all', excel_path)
      unless status.success?
        detail = stderr.to_s.strip.empty? ? stdout.to_s.strip : stderr.to_s.strip
        detail = 'no parser output' if detail.empty?
        return [nil, "Excel parser failed with #{status.exitstatus}: #{detail}"]
      end

      cases = JSON.parse(stdout)
      return [nil, "Excel parser returned no test cases: #{excel_path}"] if cases.respond_to?(:empty?) && cases.empty?

      File.write(output_path, "#{JSON.pretty_generate(cases)}\n", encoding: 'UTF-8')
      log "Parsed Excel JSON ready: #{output_path} (#{cases.length} case#{cases.length == 1 ? '' : 's'})"
      [output_path, nil]
    rescue JSON::ParserError => e
      [nil, "Excel parser returned invalid JSON: #{e.message}"]
    rescue StandardError => e
      [nil, "Excel parser failed: #{e.class}: #{e.message}"]
    end

    def deterministic_excel_to_yaml(excel_path, yaml_path)
      parser = File.join(EXCEL_YAML_SKILL, 'parse_excel.py')
      return [{ exit_code: 127, elapsed: 0.0, elapsed_formatted: '0.0s' }, "Excel parser not found: #{parser}"] unless File.file?(parser)

      start_time = Process.clock_gettime(Process::CLOCK_MONOTONIC)
      stdout, stderr, status = Open3.capture3(PYTHON_BIN, parser, '--yaml', excel_path)
      elapsed = Process.clock_gettime(Process::CLOCK_MONOTONIC) - start_time
      result = {
        exit_code: status.exitstatus,
        elapsed: elapsed,
        elapsed_formatted: format_elapsed(elapsed),
        output: stderr.to_s,
        spawn_error: nil
      }
      unless status.success?
        detail = stderr.to_s.strip.empty? ? stdout.to_s.strip : stderr.to_s.strip
        detail = 'no parser output' if detail.empty?
        return [result, "Excel deterministic YAML failed with #{status.exitstatus}: #{detail}"]
      end

      FileUtils.mkdir_p(File.dirname(yaml_path))
      File.write(yaml_path, stdout, encoding: 'UTF-8')
      [result, nil]
    rescue StandardError => e
      [
        { exit_code: 1, elapsed: 0.0, elapsed_formatted: '0.0s', output: e.message, spawn_error: e.message },
        "Excel deterministic YAML failed: #{e.class}: #{e.message}"
      ]
    end

    TIMEOUT_SECONDS = 20 * 60 # 20 minutes without output = hang
    MAX_RETRIES = 2           # max retries after timeout kill
    MAX_CAPTURE_BYTES = Integer(ENV.fetch('OPENCODE_MAX_OUTPUT_BYTES', '8388608'), 10)

    def opencode_environment
      allowed = /\A(?:PATH|HOME|USER|LOGNAME|SHELL|TERM|PWD|LANG|LC_[A-Z0-9_]+|XDG_[A-Z0-9_]+|OPENCODE_[A-Z0-9_]+|PLAYWRIGHT_MCP_IGNORE_HTTPS_ERRORS|PAGEEXPLORE_ROOT|NO_COLOR|FORCE_COLOR)\z/
      sensitive_name = /(?:PASSWORD|PASSWD|SECRET|TOKEN|API[_-]?KEY|AUTH|COOKIE|CREDENTIAL)/i
      explicit = OPENCODE_ENV_ALLOWLIST.to_s.split(',').map(&:strip).reject(&:empty?)
      environment = ENV.each_with_object({}) do |(key, value), result|
        result[key] = value if (allowed.match?(key) && !sensitive_name.match?(key)) || explicit.include?(key)
      end
      environment['PLAYWRIGHT_MCP_IGNORE_HTTPS_ERRORS'] = ENV.fetch(
        'PLAYWRIGHT_MCP_IGNORE_HTTPS_ERRORS', '1'
      )
      environment
    end

    # Conversion inputs and outputs are often siblings of this documentation
    # checkout (for example ../ai and ../features).  Give opencode an explicit,
    # path-scoped policy so it does not ask for an external-directory permission
    # that the non-interactive batch process cannot approve.  The model can read
    # the source/skill trees, but may edit only the stage output roots.
    def conversion_permission_environment(read_roots:, edit_roots:)
      normalize_root = lambda do |path|
        value = File.expand_path(path.to_s)
        File.directory?(value) ? File.realpath(value) : value
      rescue StandardError
        File.expand_path(path.to_s)
      end
      read_roots = Array(read_roots).filter_map do |path|
        next if path.to_s.strip.empty?

        normalize_root.call(path)
      end.uniq
      edit_roots = Array(edit_roots).filter_map do |path|
        next if path.to_s.strip.empty?

        normalize_root.call(path)
      end.uniq
      external_rules = { '*' => 'deny' }
      # An external-directory approval is needed for either reading an input or
      # opening an output path.  Include edit roots here as well; the separate
      # ``edit`` rules below remain the authoritative write boundary.
      (read_roots + edit_roots).uniq.each do |root|
        external_rules[root] = 'allow'
        external_rules["#{root}/*"] = 'allow'
        external_rules["#{root}/**"] = 'allow'
      end
      edit_rules = { '*' => 'deny' }
      edit_roots.each do |root|
        aliases = [root]
        # Without a Git checkout OpenCode records the project worktree as `/`.
        # Its legacy edit tool consequently checks an absolute output root without
        # the leading slash. Permit that exact root-relative alias as well.
        root_relative = root.delete_prefix(File::SEPARATOR)
        aliases << root_relative unless root_relative == root
        aliases.uniq.each do |permission_root|
          edit_rules[permission_root] = 'allow'
          edit_rules["#{permission_root}/*"] = 'allow'
          edit_rules["#{permission_root}/**"] = 'allow'
        end
      end
      config = {
        '$schema' => 'https://opencode.ai/config.json',
        'permission' => {
          '*' => 'deny',
          'read' => {
            '*' => 'allow',
            '*.env' => 'deny',
            '*.env.*' => 'deny',
            '*.pem' => 'deny',
            '*.key' => 'deny',
            '*password*' => 'deny',
            '*secret*' => 'deny',
            '*credential*' => 'deny',
            '.git/**' => 'deny'
          },
          'list' => 'allow',
          'glob' => 'allow',
          'grep' => 'allow',
          'edit' => edit_rules,
          'external_directory' => external_rules,
          'skill' => 'allow',
          'bash' => 'deny',
          'execute' => 'deny',
          'webfetch' => 'deny',
          'websearch' => 'deny',
          'task' => 'deny',
          'question' => 'deny'
        }
      }
      opencode_environment.merge('OPENCODE_CONFIG_CONTENT' => JSON.generate(config))
    end

    # Run a single opencode/runner command with output timeout monitoring.
    # Conversion commands may retry after a silent hang; Feature execution is
    # deliberately single-shot because replaying it can duplicate side effects.
    def print_model_prompt(prompt)
      info 'Model prompt:'
      puts redact_batch(prompt).to_s.each_line.map { |line| "  #{line}" }.join
      $stdout.flush
    end

    def run_opencode(label, cmd, retry_on_hang: true, environment: nil,
                     timeout_seconds: TIMEOUT_SECONDS, capture_path: nil,
                     model_prompt: nil, sensitive_values: nil)
      register_batch_redaction_values(sensitive_values)
      info "Start: #{label}"
      print_model_prompt(model_prompt) unless model_prompt.to_s.empty?
      log "Command: #{redact_batch(cmd)}" if VERBOSE_MODEL_OUTPUT
      info "[RUNNING] #{label} (0.0s)"

      overall_start = Process.clock_gettime(Process::CLOCK_MONOTONIC)
      max_retries = retry_on_hang ? MAX_RETRIES : 0
      retries = 0
      exit_code = nil
      # Keep the final attempt's captured values visible after the retry loop.
      # Ruby block-local initialization otherwise makes the return hash raise a
      # NameError even when the child command completed successfully.
      output = String.new(encoding: Encoding::BINARY)
      spawn_error = nil

      begin
        command_tokens = Shellwords.split(cmd.to_s)
        raise ArgumentError, 'command is empty' if command_tokens.empty?
      rescue ArgumentError => e
        error "Cannot start command: #{e.message}"
        return { exit_code: 2, elapsed: 0.0, elapsed_formatted: '0.0s' }
      end

      loop do
        start_time = Process.clock_gettime(Process::CLOCK_MONOTONIC)
        last_output_time = start_time
        next_progress_time = start_time + MODEL_PROGRESS_INTERVAL
        hang_kill = false
        exit_code = nil
        output = String.new(encoding: Encoding::BINARY)
        output_truncated = false

        if retries > 0
          warn ">>> Attempt #{retries + 1}/#{max_retries + 1} (re-run after hang)<<<"
        end

        pid = nil
        popen_status = nil
        spawn_error = nil
        spawn_options = { chdir: Dir.pwd }
        spawn_options[:unsetenv_others] = true if environment
        begin
          Open3.popen2e(environment || {}, *command_tokens, **spawn_options) do |stdin, io, wait_thr|
            stdin.close
            pid = wait_thr.pid
            loop do
              readable = IO.select([io], nil, nil, 0.25)
              if readable
                begin
                  chunk = io.read_nonblock(8192)
                  if output.bytesize < MAX_CAPTURE_BYTES
                    remaining = MAX_CAPTURE_BYTES - output.bytesize
                    output << chunk.byteslice(0, remaining)
                    output_truncated = true if chunk.bytesize > remaining
                  else
                    output_truncated = true
                  end
                  last_output_time = Process.clock_gettime(Process::CLOCK_MONOTONIC)
                rescue IO::WaitReadable
                  # Continue to the timeout check below.
                rescue EOFError
                  break
                end
              end

              # Check elapsed silence on every polling cycle, including when a
              # child writes a partial line without a newline.
              now = Process.clock_gettime(Process::CLOCK_MONOTONIC)
              if now >= next_progress_time
                info "[RUNNING] #{label} (#{format_elapsed(now - overall_start)})"
                next_progress_time += MODEL_PROGRESS_INTERVAL while next_progress_time <= now
              end
              idle_time = now - last_output_time
              if idle_time >= timeout_seconds.to_i
                action = max_retries.positive? ? 'Killing and re-running.' : 'Killing without an automatic retry.'
                warn "No output for #{(idle_time / 60).to_i}min - process appears hung (PID: #{pid}). #{action}"
                Process.kill('TERM', pid) rescue nil
                sleep 2
                Process.kill('KILL', pid) rescue nil
                hang_kill = true
                break
              end
            end

            # Drain any bytes already buffered by the pipe without blocking.  A
            # descendant holding the pipe open is bounded by the same timeout on
            # the next retry rather than blocking on gets/readline.
            loop do
              chunk = io.read_nonblock(8192, exception: false)
              break if chunk.nil? || chunk == :wait_readable || chunk == :eof

              if output.bytesize < MAX_CAPTURE_BYTES
                remaining = MAX_CAPTURE_BYTES - output.bytesize
                output << chunk.byteslice(0, remaining)
                output_truncated = true if chunk.bytesize > remaining
              else
                output_truncated = true
              end
            end
            popen_status = wait_thr.value
          end
        rescue Errno::ENOENT, Errno::EACCES => e
          spawn_error = e.message
          output << e.message.to_s.b
        end

        if output_truncated
          output << "\n[output truncated after #{MAX_CAPTURE_BYTES} bytes]\n".b
        end
        # Default output is deliberately compact: OpenCode --format=json can emit
        # tens of thousands of event lines. Keep the bounded output for validation
        # and evidence, and expose it on the terminal only under the explicit
        # verbose switch after the complete transcript has been redacted.
        if VERBOSE_MODEL_OUTPUT && !output.empty?
          print redact_batch(output)
          $stdout.flush
        end

        exit_code = if spawn_error
                      127
                    elsif hang_kill
                      nil
                    else
                      popen_status&.exitstatus
                    end

        if hang_kill
          # On hang, retry only when the caller explicitly allows it; on the final
          # attempt, return a failure to the caller for reporting/diagnosis.
          retries += 1
          if retries > max_retries
            if max_retries.positive?
              error "Exceeded #{max_retries} retries after hang detection. Giving up."
            else
              error 'Child command produced no output until timeout; automatic retry is disabled.'
            end
            exit_code = -1
          else
            sleep 3
            next
          end
        end

        break
      end

      overall_elapsed = Process.clock_gettime(Process::CLOCK_MONOTONIC) - overall_start

      redacted_output = redact_batch(output)
      if capture_path && !capture_path.to_s.strip.empty?
        begin
          FileUtils.mkdir_p(File.dirname(File.expand_path(capture_path)))
          File.write(capture_path, redacted_output, encoding: 'UTF-8')
          File.chmod(0o600, capture_path)
        rescue StandardError => e
          warn "Could not write command transcript #{capture_path}: #{e.message}"
        end
      end

      if exit_code.to_i.zero?
        log "[DONE] #{label} (Duration: #{format_elapsed(overall_elapsed)}, exit: 0)"
      else
        error "[FAILED] #{label} (Duration: #{format_elapsed(overall_elapsed)}, exit: #{exit_code || -1})"
        warn 'Full child/model output is hidden in compact mode; rerun with --verbose-model-output if the stage did not write a diagnostic report.' unless VERBOSE_MODEL_OUTPUT
      end

      {
        exit_code: exit_code || -1,
        elapsed: overall_elapsed,
        elapsed_formatted: format_elapsed(overall_elapsed),
        output: redacted_output,
        spawn_error: spawn_error
      }
    end

    def permission_failure_output?(result)
      # OpenCode can recover from a failed exploratory Read/Grep/Glob call and
      # still create the requested artifact.  Do not treat a bare
      # `Read ... failed` (or `ripgrep execution failed`) line as a permission
      # failure; only explicit permission/access markers should fail the stage.
      result[:output].to_s.each_line.any? do |line|
        value = line.to_s.strip
        next false if value.empty?

        value.match?(\
          /\b(?:EACCES|EPERM|PermissionError)\b/i
        ) || value.match?(\
          /\boperation\s+not\s+permitted\b/i
        ) || value.match?(\
          /\b(?:permission|access)\s+(?:requested|request|denied|error|rejected|forbidden|blocked|not\s+allowed)\b/i
        ) || value.match?(\
          /\b(?:denied|rejected|forbidden)\s+(?:permission|access)\b/i
        ) || value.match?(\
          /\bnot\s+authorized\b/i
        ) || value.match?(\
          /\b(?:do\s+not|don't|does\s+not|doesn't)\s+have\s+(?:permission|access)\b/i
        ) || value.match?(\
          /\bexternal[_\s-]?directory\b[^\n]*(?:deny|denied|request|reject|rejected|forbidden|failed|blocked)\b/i
        ) || value.match?(\
          /\bauto[-\s]?reject(?:ed)?\b/i
        ) || value.match?(\
          /\b(?:read|write|edit)\b[^\n]{0,160}\b(?:permission|access)\b[^\n]{0,80}\b(?:denied|rejected|forbidden|failed)\b/i
        ) || value.match?(\
          /\b(?:permission|access)\b[^\n]{0,160}\b(?:read|write|edit)\b[^\n]{0,80}\b(?:denied|rejected|forbidden|failed)\b/i
        )
      end
    end

    def readable_artifact?(path)
      File.file?(path) && File.size(path).positive?
    rescue StandardError
      false
    end

    def artifact_signature(path)
      return nil unless readable_artifact?(path)

      stat = File.stat(path)
      [stat.size, stat.mtime.to_f, Digest::SHA256.file(path).hexdigest]
    rescue StandardError
      nil
    end

    def conversion_failure_reason(result, artifact_path: nil, before_signature: :unchecked, require_fresh: false)
      return "command exited with #{result[:exit_code]}" unless result[:exit_code].to_i.zero?
      return 'command reported a permission failure' if permission_failure_output?(result)
      return nil unless artifact_path

      after_signature = artifact_signature(artifact_path)
      return "artifact missing or empty: #{artifact_path}" if after_signature.nil?
      if require_fresh && before_signature != :unchecked && after_signature == before_signature
        return "artifact was not created or updated: #{artifact_path}"
      end
      nil
    end
  end
end
