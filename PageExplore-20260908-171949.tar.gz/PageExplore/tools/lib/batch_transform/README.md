# Batch Transform internals

`tools/batch_transform_tc.rb` is the stable command-line entry point. Its
implementation is split here by responsibility so changes to one pipeline
stage do not require editing one monolithic Ruby file.

| Component | Responsibility |
|---|---|
| `core.rb` | Logging/redaction, YAML classification, conversion commands, file and OpenCode process helpers |
| `admin/configuration.rb` | Admin YAML detection, dotenv lookup, ODP URL and Playwright MCP configuration |
| `admin/prompt.rb` | Rollback-exploration prompts, commands and scoped OpenCode environments |
| `admin/semantic_validation.rb` | Manifest normalization, YAML source coverage and Step Index validation |
| `admin/evidence_validation.rb` | Transcript/report validation, cleanup proof, catalog quarantine and promotion |
| `admin/exploration.rb` | End-to-end MCP exploration orchestration |
| `feature_pipeline.rb` | Admin Feature alignment plus Admin/non-Admin generation and execution helpers |
| `execution_flow.rb` | Ordered hybrid lifecycle manifests, external gates and resume handling |
| `pipeline.rb` | Per-case pipeline coordination and final summary |

`tools/lib/batch_transform.rb` loads these components and installs their
private methods on `Object`. That intentionally preserves the method lookup
and CLI behavior of the former top-level implementation. New code should be
placed in the narrowest component above; avoid adding workflow logic back to
the launcher.

The modules share the immutable runtime constants initialized by the launcher.
They are internal implementation modules, not an independent public API.
