# frozen_string_literal: true

module BatchTransform
  module Admin
    # ---------------------------------------------------------------------------
    # Admin exploration orchestration
    #
    # A conversion-only invocation must remain deterministic and side-effect free.
    # The explicit generation/repair path, however, can validate a missing Admin
    # setup through Playwright MCP. For a maker/checker workflow, browser
    # exploration submits the maker request, validates the countersign path, and
    # rejects that request as cleanup. The final approval remains a semantic step
    # deferred to the generated Feature. For a flow without countersign, MCP must
    # cancel before a persistent save. The browser adapter writes a candidate and
    # a small machine-readable report into an isolated run directory. The batch
    # process validates both artifacts before copying the candidate into the flow
    # catalog. Keeping this boundary here (rather than teaching the YAML model to
    # fabricate a flow) makes the 2 -> 3 -> 1 -> 4 -> 5 -> 6 -> 7 lifecycle
    # auditable and testable.

    ADMIN_FLOW_ID_PATTERN = /\A[A-Za-z0-9][A-Za-z0-9_.:-]{2,199}\z/
    class AdminManifestSemanticError < RuntimeError; end

    ADMIN_APPROVAL_REQUEST_PATTERN = /\b(?:approv(?:e(?:s|d|r)?|ing|al)|countersign)\b|maker[- ]checker/i
    ADMIN_APPROVAL_ACTION_TERM_PATTERN = /\bapprove\b|approve(?:btn|button|selected|action)\b/i
    ADMIN_REJECT_ACTION_TERM_PATTERN = /\breject\b|reject(?:btn|button|selected|action)\b/i
    ADMIN_CANCEL_ACTION_TERM_PATTERN = /\bcancel\b|cancel(?:btn|button|selected|action)\b/i

    ODP_MAKER_USERNAME_KEYS = %w[SECRET_ODP_USERNAME ODP_USERNAME].freeze
    ODP_MAKER_PASSWORD_KEYS = %w[SECRET_ODP_PASSWORD ODP_PASSWORD].freeze
    ODP_CHECKER_USERNAME_KEYS = %w[SECRET_ODP_CHECKER_USERNAME ODP_CHECKER_USERNAME].freeze
    ODP_CHECKER_PASSWORD_KEYS = %w[SECRET_ODP_CHECKER_PASSWORD ODP_CHECKER_PASSWORD].freeze
  end
end

require_relative "admin/configuration"
require_relative "admin/prompt"
require_relative "admin/semantic_validation"
require_relative "admin/evidence_validation"
require_relative "admin/exploration"
