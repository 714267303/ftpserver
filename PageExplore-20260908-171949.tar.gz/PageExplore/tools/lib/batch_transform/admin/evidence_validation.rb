# frozen_string_literal: true

# Playwright evidence, rollback report, catalog, and promotion validation.

module BatchTransform
  module Admin
    module EvidenceValidation
      private

      def exploration_report_status?(value)
        %w[passed success verified].include?(value.to_s.strip.downcase)
      end

      def compact_admin_failure_value(value, depth = 0)
        return nil if depth > 4 || value.nil?

        case value
        when String
          text = value.strip
          text.empty? ? nil : text
        when Numeric, TrueClass, FalseClass
          value.to_s
        when Array
          value.filter_map { |item| compact_admin_failure_value(item, depth + 1) }.first
        when Hash
          parts = []
          %w[stage step action operation].each do |key|
            detail = compact_admin_failure_value(value[key], depth + 1)
            parts << "#{key}=#{detail}" if detail
          end
          %w[reason failure_reason error message detail details description].each do |key|
            detail = compact_admin_failure_value(value[key], depth + 1)
            parts << detail if detail
          end
          return parts.uniq.join(': ') unless parts.empty?

          value.each_value do |child|
            detail = compact_admin_failure_value(child, depth + 1)
            return detail if detail
          end
          nil
        end
      end

      def admin_exploration_failure_detail(report)
        return nil unless report.is_a?(Hash)

        %w[first_failure failure_reason failure reason error message].each do |key|
          detail = compact_admin_failure_value(report[key])
          return detail if detail
        end

        failed_step = Array(report['steps']).find do |step|
          step.is_a?(Hash) && %w[failed error blocked].include?(step['status'].to_s.strip.downcase)
        end
        compact_admin_failure_value(failed_step)
      end

      def admin_exploration_report_failure(report_path)
        return nil unless readable_artifact?(report_path)

        report = json_object_at(report_path, 'Admin exploration report')
        return nil if exploration_report_status?(report['status'])

        detail = admin_exploration_failure_detail(report)
        status = report['status'].to_s.strip
        status = 'unknown' if status.empty?
        reason = detail || "exploration report status=#{status.inspect}"
        "#{reason}; report: #{expanded_path(report_path)}"
      rescue StandardError => e
        "could not parse failed exploration report (#{e.message}); report: #{expanded_path(report_path)}"
      end

      def opencode_command?(command)
        first = Shellwords.split(command.to_s).first.to_s
        File.basename(first) == 'opencode'
      rescue ArgumentError
        false
      end

      def transcript_playwright_tool_names(path)
        return [] unless File.file?(path) && !File.symlink?(path)

        names = []
        File.foreach(path, encoding: 'UTF-8') do |line|
          begin
            event = JSON.parse(line)
          rescue JSON::ParserError
            next
          end
          pending = [event]
          until pending.empty?
            value = pending.pop
            case value
            when Hash
              type = value['type'].to_s
              if type.match?(/tool/i)
                %w[tool tool_name name].each do |key|
                  name = value[key].to_s
                  names << name if name.match?(/(?:^|[_.-])playwright(?:[_.-]|$)/i)
                end
              end
              pending.concat(value.values)
            when Array
              pending.concat(value)
            end
          end
        end
        names.uniq
      rescue StandardError
        []
      end

      # Prove that a value was present in an executed Playwright call rather than in
      # the model prompt. This binds a manifest's declared /UI/ route to browser
      # evidence and prevents a syntactically valid but fabricated page identity
      # from reaching Feature generation.
      def transcript_playwright_observed_value?(path, expected)
        needle = expected.to_s.strip
        return false if needle.empty? || !File.file?(path) || File.symlink?(path)

        File.foreach(path, encoding: 'UTF-8') do |line|
          begin
            event = JSON.parse(line)
          rescue JSON::ParserError
            next
          end
          pending = [event]
          until pending.empty?
            value = pending.pop
            case value
            when Hash
              type = value['type'].to_s
              tool_name = if type.match?(/tool/i)
                            (value['tool'] || value['tool_name'] || value['name']).to_s
                          else
                            ''
                          end
              if tool_name.match?(/(?:^|[_.-])playwright(?:[_.-]|$)/i)
                state = value['state'].is_a?(Hash) ? value['state'] : {}
                status = (state['status'] || value['status']).to_s.downcase
                completed = status.empty? || %w[completed success passed].include?(status)
                unless state['error'] || value['error'] || !completed
                  # Input proves only that the model attempted a navigation. Require
                  # the completed tool result/snapshot metadata to contain the route
                  # so a locator script mentioning the expected path cannot serve as
                  # self-authored evidence of success.
                  payload = {
                    'output' => state.key?('output') ? state['output'] : value['output'],
                    'title' => state['title'] || value['title'],
                    'metadata' => state['metadata'] || value['metadata']
                  }
                  return true if JSON.generate(payload).include?(needle)
                end
              end
              pending.concat(value.values)
            when Array
              pending.concat(value)
            end
          end
        end
        false
      rescue StandardError
        false
      end

      # Return a small, non-secret diagnostic when a Playwright tool input performs
      # one labeled UI action. Snapshot outputs are intentionally ignored: merely
      # observing an Approve/Reject/Cancel button is not execution evidence.
      def transcript_playwright_labeled_action(path, term_pattern, variable_stem)
        return nil unless File.file?(path) && !File.symlink?(path)

        File.foreach(path, encoding: 'UTF-8').with_index(1) do |line, line_number|
          begin
            event = JSON.parse(line)
          rescue JSON::ParserError
            next
          end
          pending = [event]
          until pending.empty?
            value = pending.pop
            case value
            when Hash
              type = value['type'].to_s
              tool_name = if type.match?(/tool/i)
                            (value['tool'] || value['tool_name'] || value['name']).to_s
                          else
                            ''
                          end
              if tool_name.match?(/(?:^|[_.-])playwright(?:[_.-]|$)/i)
                state = value['state'].is_a?(Hash) ? value['state'] : {}
                input = state.key?('input') ? state['input'] : value['input']
                input_text = if input.is_a?(Hash)
                               input['code'] || input['javascript'] || JSON.generate(input)
                             elsif input.is_a?(String)
                               input
                             else
                               JSON.generate(input || {})
                end
                direct_click = tool_name.match?(/(?:^|[_.-])(?:click|tap|press)(?:[_.-]|$)/i) &&
                               input_text.match?(term_pattern)
                action_term_source = term_pattern.source
                action_term = '(?:\\.(?:click|tap|press)\\s*\\(|dispatchEvent\\s*\\(|\\.evaluate\\s*\\([^)]*\\.click)'
                labeled_action = Regexp.new(
                  "(?:#{action_term_source})[^;\\n]{0,240}(?:#{action_term})|" \
                    "\\b#{variable_stem}[A-Za-z0-9_]*\\s*\\.(?:click|tap|press)\\s*\\(",
                  Regexp::IGNORECASE
                )
                raw_code_action = tool_name.match?(/run[_-]?code/i) && input_text.match?(labeled_action)
                return { 'line' => line_number, 'tool' => tool_name } if direct_click || raw_code_action
              end
              pending.concat(value.values)
            when Array
              pending.concat(value)
            end
          end
        end
        nil
      rescue StandardError
        nil
      end

      # Approve is deliberately deferred to the generated Feature. Seeing the
      # control is allowed; clicking it during rollback validation is forbidden.
      def transcript_final_approval_action(path)
        transcript_playwright_labeled_action(path, ADMIN_APPROVAL_ACTION_TERM_PATTERN, 'approve')
      end

      def transcript_reject_action(path)
        transcript_playwright_labeled_action(path, ADMIN_REJECT_ACTION_TERM_PATTERN, 'reject')
      end

      def transcript_cancel_action(path)
        transcript_playwright_labeled_action(path, ADMIN_CANCEL_ACTION_TERM_PATTERN, 'cancel')
      end

      def compact_admin_transcript_error(value, max_chars: 480)
        text = redact_batch(value).to_s
        text = text.gsub(/\e\[[0-9;]*[A-Za-z]/, '')
        text = text.gsub(/[\r\n\t]+/, ' ').gsub(/\s+/, ' ').strip
        # Browser call logs can embed an entire HTML element and its current values.
        # Keep the exception summary while excluding DOM dumps from the report.
        text = text.split(/\bCall log:/i, 2).first.to_s.strip
        text = text.sub(/\s+-\s+locator resolved to\b.*\z/i, '').strip
        text = text.gsub(/<[^>]+>/, '<element>')
        text.length > max_chars ? "#{text[0, max_chars]}..." : text
      end

      # Extract only non-secret control-plane diagnostics from the already-redacted
      # OpenCode transcript. Tool inputs and successful outputs are deliberately not
      # copied into the fallback report.
      def transcript_tool_diagnostics(path)
        return {
          'tool_calls' => 0,
          'tool_errors' => 0,
          'malformed_events' => 0,
          'mcp_tools_used' => [],
          'last_tool_error' => nil
        } unless File.file?(path) && !File.symlink?(path)

        calls = {}
        malformed = 0
        File.foreach(path, encoding: 'UTF-8').with_index(1) do |line, line_number|
          next if line.strip.empty?

          begin
            event = JSON.parse(line)
          rescue JSON::ParserError
            malformed += 1
            next
          end
          next unless event.is_a?(Hash)

          part = event['part'].is_a?(Hash) ? event['part'] : {}
          next unless event['type'].to_s == 'tool_use' || part['type'].to_s == 'tool'

          state = part['state'].is_a?(Hash) ? part['state'] : {}
          identity = part['callID'].to_s
          identity = part['id'].to_s if identity.empty?
          identity = "line-#{line_number}" if identity.empty?
          calls[identity] = {
            'line' => line_number,
            'tool' => (part['tool'] || event['tool'] || '<unknown>').to_s,
            'status' => (state['status'] || part['status'] || 'unknown').to_s,
            'error' => state['error'] || part['error'] || event['error']
          }
        end

        ordered = calls.values.sort_by { |call| call['line'] }
        errors = ordered.select do |call|
          call['status'].casecmp?('error') || !call['error'].nil?
        end
        playwright_tools = ordered.map { |call| call['tool'] }.select do |name|
          name.match?(/(?:^|[_.-])playwright(?:[_.-]|$)/i)
        end.uniq
        last_error = errors.last
        {
          'tool_calls' => ordered.length,
          'tool_errors' => errors.length,
          'malformed_events' => malformed,
          'mcp_tools_used' => playwright_tools,
          'last_tool_error' => if last_error
                                 {
                                   'tool' => last_error['tool'],
                                   'reason' => compact_admin_transcript_error(last_error['error'] || 'tool status=error')
                                 }
                               end
        }
      rescue StandardError => e
        {
          'tool_calls' => 0,
          'tool_errors' => 0,
          'malformed_events' => 0,
          'mcp_tools_used' => [],
          'last_tool_error' => nil,
          'diagnostic_error' => compact_admin_transcript_error("#{e.class}: #{e.message}")
        }
      end

      # The model is still responsible for its normal report. If it exits without
      # one, create a deterministic failed report after the transcript is closed so
      # every failure remains machine-readable without interfering with model writes.
      def ensure_admin_exploration_failure_report(report_path:, candidate_path:, case_id:, channel:, evidence_dir:,
                                                  transcript_path:, result:, approval_requested:)
        return false if readable_artifact?(report_path)

        diagnostics = transcript_tool_diagnostics(transcript_path)
        last_error = diagnostics['last_tool_error']
        stage = if last_error
                  'playwright_tool'
                elsif diagnostics['mcp_tools_used'].empty?
                  'mcp_startup'
                else
                  'agent_completion'
                end
        exit_code = result[:exit_code].to_i
        reason = if last_error
                   "Admin exploration agent exited without writing its report after #{diagnostics['tool_errors']} " \
                     "tool error(s); last error from #{last_error['tool']}: #{last_error['reason']}"
                 elsif exit_code.zero?
                   'Admin exploration agent exited successfully without writing exploration-report.json'
                 else
                   "Admin exploration command exited with status #{exit_code} without writing exploration-report.json"
                 end

        payload = {
          'schema_version' => 1,
          'status' => 'failed',
          'case_id' => case_id,
          'channel' => channel,
          'clean_state' => false,
          'exploration_mode' => 'rollback_validation',
          # Without the model-authored report the runner cannot prove whether a
          # maker request was submitted or whether cleanup reached its final state.
          'business_mutations_executed' => nil,
          'maker_submission_executed' => nil,
          'final_approval_executed' => !transcript_final_approval_action(transcript_path).nil?,
          'cleanup_action' => if transcript_reject_action(transcript_path)
                                'reject'
                              elsif transcript_cancel_action(transcript_path)
                                'cancel'
                              else
                                'unknown'
                              end,
          'cleanup_completed' => false,
          'final_state_restored' => false,
          'final_approval_deferred_to_feature' => approval_requested == true,
          'admin_steps_executed' => 0,
          'admin_steps_validated' => 0,
          'mcp_tools_used' => diagnostics['mcp_tools_used'],
          'evidence_dir' => expanded_path(evidence_dir),
          'manifest_path' => expanded_path(candidate_path),
          'first_failure' => {
            'stage' => stage,
            'reason' => reason
          },
          'runner_fallback' => {
            'generated' => true,
            'generated_at' => Time.now.utc.iso8601,
            'command_exit_code' => exit_code,
            'elapsed_seconds' => result[:elapsed].to_f.round(3),
            'tool_calls' => diagnostics['tool_calls'],
            'tool_errors' => diagnostics['tool_errors'],
            'malformed_events' => diagnostics['malformed_events'],
            'last_tool_error' => last_error,
            'transcript_path' => expanded_path(transcript_path)
          }
        }
        write_json_atomic(report_path, payload)
        true
      rescue StandardError => e
        warn "Could not create fallback Admin exploration report: #{e.message}"
        false
      end

      def manifest_case_match?(manifest_case_id, yaml_path)
        actual = manifest_case_id.to_s.strip
        return false if actual.empty?

        yaml_identifiers(yaml_path).any? { |item| item.to_s.strip.casecmp?(actual) }
      end

      def validate_admin_exploration_artifacts(candidate_path:, report_path:, yaml_path:, case_id:, channel:, evidence_dir:,
                                               transcript_path:, require_transcript_mcp:)
        manifest, report, = normalize_admin_flow_candidate_artifacts(
          candidate_path: candidate_path,
          report_path: report_path,
          case_id: case_id,
          phase: 'artifact_validation'
        )
        approval_requested = yaml_requests_final_approval?(yaml_path)

        unless report['schema_version'].to_i == 1
          raise "Admin exploration report schema_version must be 1: #{report_path}"
        end
        unless exploration_report_status?(report['status'])
          detail = admin_exploration_failure_detail(report)
          suffix = detail ? ": #{detail}" : ''
          raise "Admin exploration did not pass (status=#{report['status'].inspect})#{suffix}; report: #{report_path}"
        end
        unless report['case_id'].to_s.strip.casecmp?(case_id.to_s.strip)
          raise "Admin exploration report case_id does not match #{case_id}: #{report['case_id'].inspect}"
        end
        unless report['channel'].to_s.strip.downcase == channel.to_s.strip.downcase
          raise "Admin exploration report channel does not match #{channel}: #{report['channel'].inspect}"
        end
        unless report['clean_state'] == true
          raise 'Admin exploration report must set clean_state=true'
        end
        unless report['exploration_mode'].to_s == 'rollback_validation'
          raise 'Admin exploration report must set exploration_mode=rollback_validation'
        end
        unless report['final_approval_executed'] == false
          raise 'Admin exploration report must set final_approval_executed=false'
        end
        unless report['cleanup_completed'] == true
          raise 'Admin exploration report must prove cleanup_completed=true'
        end
        unless report['final_state_restored'] == true
          raise 'Admin exploration report must prove final_state_restored=true'
        end
        expected_cleanup = approval_requested ? 'reject' : 'cancel'
        unless report['cleanup_action'].to_s.downcase == expected_cleanup
          raise "Admin exploration report cleanup_action must be #{expected_cleanup.inspect}"
        end
        if approval_requested
          unless report['maker_submission_executed'] == true && report['business_mutations_executed'] == true
            raise 'Maker/checker validation must submit the maker request before Reject cleanup'
          end
        elsif report['maker_submission_executed'] != false || report['business_mutations_executed'] != false
          raise 'No-countersign validation must Cancel without persisting a business mutation'
        end
        unless report['admin_steps_executed'].to_i.positive?
          raise 'Admin exploration report contains no executed Admin steps'
        end
        unless report['admin_steps_validated'].to_i.positive?
          raise 'Admin exploration report contains no validated semantic Admin steps'
        end

        tools_used = Array(report['mcp_tools_used']).map(&:to_s)
        reported_mcp = report['mcp_used'] == true || tools_used.any? do |name|
          name.match?(/(?:^|[_.-])playwright(?:[_.-]|$)/i)
        end
        raise 'Admin exploration report contains no Playwright MCP evidence' unless reported_mcp
        if require_transcript_mcp && transcript_playwright_tool_names(transcript_path).empty?
          raise 'OpenCode transcript contains no executed Playwright MCP tool event'
        end
        forbidden_approval = transcript_final_approval_action(transcript_path)
        if forbidden_approval
          raise "Admin MCP validation attempted a forbidden final approval action at transcript line " \
                "#{forbidden_approval['line']} (#{forbidden_approval['tool']})"
        end
        if require_transcript_mcp
          cleanup_evidence = approval_requested ? transcript_reject_action(transcript_path) : transcript_cancel_action(transcript_path)
          unless cleanup_evidence
            raise "OpenCode transcript contains no executed #{expected_cleanup.capitalize} cleanup action"
          end
        end

        declared_manifest_path = report['manifest_path'].to_s.strip
        raise 'Admin exploration report must declare manifest_path' if declared_manifest_path.empty?
        unless expanded_path(declared_manifest_path) == expanded_path(candidate_path)
          raise 'Admin exploration report manifest_path does not match the isolated candidate'
        end
        declared_evidence_dir = report['evidence_dir'].to_s.strip
        raise 'Admin exploration report must declare evidence_dir' if declared_evidence_dir.empty?
        unless expanded_path(declared_evidence_dir) == expanded_path(evidence_dir)
          raise 'Admin exploration report evidence_dir does not match the isolated run directory'
        end

        unless manifest['schema_version'].to_i == 1
          raise 'Admin flow candidate schema_version must be 1'
        end
        unless manifest_case_match?(manifest['case_id'], yaml_path)
          raise "Admin flow candidate case_id #{manifest['case_id'].inspect} does not match #{case_id}"
        end
        unless manifest['channel'].to_s.strip.downcase == channel.to_s.strip.downcase
          raise "Admin flow candidate channel #{manifest['channel'].inspect} does not match #{channel}"
        end
        raise 'Admin flow candidate name is required' if manifest['name'].to_s.strip.empty?
        unless %w[verified observed inferred].include?(manifest['evidence_status'].to_s.strip.downcase)
          raise 'Admin flow candidate evidence_status must be verified, observed, or inferred'
        end
        unless manifest['page_route'].to_s.strip.empty?
          raise 'Admin flow candidate contains unresolved legacy page_route; use page.route'
        end
        page = manifest['page']
        unless page.is_a?(Hash) && page['route'].to_s.start_with?('/UI/') && !page['profile'].to_s.strip.empty?
          raise 'Admin flow candidate page.route must begin with /UI/ and page.profile is required'
        end
        if require_transcript_mcp &&
           !transcript_playwright_observed_value?(transcript_path, page['route'].to_s)
          raise "OpenCode transcript contains no completed Playwright observation of declared route #{page['route']}"
        end
        flow_id = manifest['flow_id'].to_s.strip
        unless ADMIN_FLOW_ID_PATTERN.match?(flow_id)
          raise "Admin flow candidate has invalid flow_id: #{manifest['flow_id'].inspect}"
        end
        steps = manifest['steps']
        unless steps.is_a?(Array) && !steps.empty?
          raise 'Admin flow candidate must contain at least one semantic step'
        end
        steps.each_with_index do |step, index|
          text = step.is_a?(Hash) ? step['text'] : step
          raise "Admin flow candidate step #{index + 1} has no text" if text.to_s.strip.empty?
        end
        unless report['admin_steps_validated'].to_i == steps.length
          raise 'Admin exploration report admin_steps_validated must equal the candidate manifest steps count'
        end
        background_steps = Array(manifest['background'])
        background_steps.each_with_index do |step, index|
          text = step.is_a?(Hash) ? step['text'] : step
          raise "Admin flow candidate background step #{index + 1} has no text" if text.to_s.strip.empty?
        end
        background_approval_steps = background_steps.select { |step| final_approval_semantic_step?(step) }
        unless background_approval_steps.empty?
          raise 'Deferred final approval must be in manifest steps, not Background'
        end
        approval_steps = steps.select { |step| final_approval_semantic_step?(step) }
        cleanup_steps = (background_steps + steps).select { |step| rollback_cleanup_semantic_step?(step) }
        unless cleanup_steps.empty?
          raise 'Candidate manifest must describe the Feature path and must not include MCP Reject/Cancel cleanup steps'
        end
        if approval_requested && approval_steps.empty?
          raise 'YAML requires final approval but the candidate manifest contains no semantic approval step'
        end
        if !approval_requested && !approval_steps.empty?
          raise 'Candidate manifest contains a final approval step that the YAML did not request'
        end
        approval_steps.each do |step|
          unless step.is_a?(Hash) && step['mcp_execution'].to_s == 'deferred_to_feature'
            raise 'Every final approval step must set mcp_execution=deferred_to_feature'
          end
        end
        unless report['final_approval_deferred_to_feature'] == approval_requested
          raise 'Admin exploration report final_approval_deferred_to_feature does not match the YAML approval requirement'
        end
        standalone_issues = admin_standalone_flow_issues(
          manifest,
          approval_requested: approval_requested,
          maker_submission: report['maker_submission_executed'] == true,
          yaml_path: yaml_path
        )
        unless standalone_issues.empty?
          raise AdminManifestSemanticError,
                "Admin flow candidate is not a complete standalone Feature hand-off: #{standalone_issues.join(', ')}"
        end
        unless manifest['evidence'].is_a?(Hash)
          raise 'Admin flow candidate evidence must be an object'
        end
        unless manifest['reuse'].is_a?(Hash)
          raise 'Admin flow candidate reuse must be an object'
        end
        unless manifest['reuse']['keywords'].is_a?(Array)
          raise 'Admin flow candidate reuse.keywords must be an array'
        end
        unless manifest['reuse']['safe_to_reuse'] == false
          raise 'A newly explored Admin flow must start with reuse.safe_to_reuse=false'
        end

        semantic_validation = admin_manifest_semantic_validation(candidate_path)
        unless semantic_validation[:ok]
          raise AdminManifestSemanticError,
                "Admin flow candidate semantic validation failed: #{semantic_validation[:reason]}"
        end

        report['correctness_validation'] = {
          'status' => 'passed',
          'page_contract' => 'passed',
          'step_index' => 'passed',
          'standalone_completeness' => 'passed',
          'yaml_page_profile' => yaml_admin_page_profiles(yaml_path).empty? ? 'not_declared' : 'matched',
          'source_coverage' => 'passed',
          'admin_yaml_steps' => yaml_admin_step_blocks(yaml_path).length,
          'coverage_entries' => Array(manifest['source_coverage']).length,
          'playwright_route_evidence' => require_transcript_mcp ? 'observed_in_completed_tool_output' : 'external_adapter_attested',
          'declared_route' => page['route'].to_s
        }

        # If the model supplied a hash, verify it.  Otherwise add one below; this
        # keeps the report contract usable by MCP agents that cannot run a checksum
        # command because shell execution is intentionally denied.
        actual_hash = Digest::SHA256.file(candidate_path).hexdigest
        supplied_hash = report['manifest_sha256'].to_s.strip
        unless supplied_hash.empty? || supplied_hash == actual_hash
          raise 'Admin exploration report manifest_sha256 does not match the candidate'
        end
        unless path_within?(candidate_path, evidence_dir)
          raise 'Admin flow candidate must be written inside its isolated evidence directory'
        end
        unless path_within?(report_path, evidence_dir)
          raise 'Admin exploration report must be written inside its isolated evidence directory'
        end

        report['manifest_sha256'] = actual_hash
        report['candidate_validated_at'] = Time.now.utc.iso8601
        [manifest, report]
      end

      def persist_admin_flow_candidate(manifest:, report:, report_path:, evidence_dir:, yaml_path:, case_id:, channel:)
        flow_dir = expanded_path(ADMIN_FLOW_DIR)
        FileUtils.mkdir_p(flow_dir)
        FileUtils.chmod_R(0o700, flow_dir)

        flow_id = manifest['flow_id'].to_s
        destination = File.join(flow_dir, "#{flow_id}.json")
        if File.file?(destination) || File.symlink?(destination)
          suffix = Time.now.utc.strftime('%Y%m%d%H%M%S')
          flow_id = "#{flow_id}.batch.#{suffix}"
          flow_id = flow_id[0, 200]
          raise "generated flow_id is invalid after collision suffix: #{flow_id}" unless ADMIN_FLOW_ID_PATTERN.match?(flow_id)
          destination = File.join(flow_dir, "#{flow_id}.json")
          # A same-second collision is possible when two workers explore one case.
          counter = 0
          while File.exist?(destination) || File.symlink?(destination)
            counter += 1
            candidate_id = "#{flow_id}.#{counter}"[0, 200]
            raise 'could not allocate a unique Admin flow filename' unless ADMIN_FLOW_ID_PATTERN.match?(candidate_id)
            destination = File.join(flow_dir, "#{candidate_id}.json")
            flow_id = candidate_id
          end
        end

        evidence = manifest['evidence'].is_a?(Hash) ? manifest['evidence'].dup : {}
        evidence['playwright_runs'] = Array(evidence['playwright_runs']).map(&:to_s).reject(&:empty?)
        evidence['playwright_runs'] << workspace_reference(evidence_dir) unless evidence['playwright_runs'].include?(workspace_reference(evidence_dir))
        evidence['logs'] = Array(evidence['logs']).map(&:to_s).reject(&:empty?)
        evidence['logs'] << workspace_reference(report_path) unless evidence['logs'].include?(workspace_reference(report_path))
        reuse = manifest['reuse'].is_a?(Hash) ? manifest['reuse'].dup : {}
        reuse['keywords'] = Array(reuse['keywords']).map(&:to_s).reject(&:empty?)
        reuse['safe_to_reuse'] = false
        manifest = manifest.merge(
          'flow_id' => flow_id,
          'case_id' => case_id,
          'channel' => channel,
          'evidence_status' => 'verified',
          'evidence' => evidence,
          'reuse' => reuse,
          'source_yaml' => expanded_path(yaml_path),
          'exploration' => {
            'status' => 'passed',
            'mode' => 'rollback_validation',
            'business_mutations_executed' => report['business_mutations_executed'],
            'maker_submission_executed' => report['maker_submission_executed'],
            'final_approval_executed' => false,
            'cleanup_action' => report['cleanup_action'].to_s,
            'cleanup_completed' => true,
            'final_state_restored' => true,
            'final_approval_deferred_to_feature' => report['final_approval_deferred_to_feature'] == true,
            'admin_steps_executed' => report['admin_steps_executed'].to_i,
            'admin_steps_validated' => report['admin_steps_validated'].to_i,
            'correctness_validation' => report['correctness_validation'],
            'report' => workspace_reference(report_path),
            'evidence_dir' => workspace_reference(evidence_dir),
            'verified_at' => Time.now.utc.iso8601,
            'safe_to_reuse' => false
          }
        )
        report = report.merge(
          'manifest_path' => destination,
          'flow_id' => flow_id,
          'persisted_path' => destination
        )
        write_json_atomic(destination, manifest)
        write_json_atomic(report_path, report)
        [destination, manifest, report]
      end

      def workspace_reference(path)
        absolute = expanded_path(path)
        root = expanded_path(Dir.pwd)
        return absolute.delete_prefix("#{root}#{File::SEPARATOR}") if path_within?(absolute, root)

        absolute
      end

      def admin_catalog_root
        flow_dir = expanded_path(ADMIN_FLOW_DIR)
        File.basename(flow_dir) == 'flows' ? File.dirname(flow_dir) : flow_dir
      end

      def refresh_admin_flow_catalog
        builder = File.join(SCRIPT_ROOT, 'tools', 'build_admin_flow_catalog.py')
        root = admin_catalog_root
        configured_flow_dir = expanded_path(ADMIN_FLOW_DIR)
        standard_layout = File.basename(configured_flow_dir) == 'flows'
        flows = standard_layout ? File.join(root, 'flows') : configured_flow_dir
        return { ok: false, reason: "flow catalog builder not found: #{builder}" } unless File.file?(builder)
        return { ok: false, reason: "flow catalog directory not found: #{flows}" } unless File.directory?(flows)

        output_json = File.join(root, 'INDEX.json')
        output_md = File.join(root, 'INDEX.md')
        catalog_arg = path_within?(root, Dir.pwd) ? workspace_reference(root) : root
        flows_arg = path_within?(flows, Dir.pwd) ? workspace_reference(flows) : flows
        output_json_arg = path_within?(output_json, Dir.pwd) ? workspace_reference(output_json) : output_json
        output_md_arg = path_within?(output_md, Dir.pwd) ? workspace_reference(output_md) : output_md
        stdout, stderr, status = Open3.capture3(
          opencode_environment,
          PYTHON_BIN,
          builder,
          '--catalog', catalog_arg,
          '--flows-dir', flows_arg,
          '--output-json', output_json_arg,
          '--output-md', output_md_arg
        )
        unless status.success?
          detail = stderr.to_s.strip.empty? ? stdout.to_s.strip : stderr.to_s.strip
          detail = 'no catalog-builder output' if detail.empty?
          return { ok: false, reason: "catalog refresh failed (#{status.exitstatus}): #{redact_batch(detail)}" }
        end
        { ok: true, index: output_json, output: redact_batch(stdout) }
      rescue StandardError => e
        { ok: false, reason: "catalog refresh failed: #{e.class}: #{e.message}" }
      end

      def demote_admin_flow(path, reason)
        return false unless path && File.file?(path) && !File.symlink?(path)

        manifest = json_object_at(path, 'Admin flow manifest')
        manifest['evidence_status'] = 'observed'
        manifest['reuse'] = {} unless manifest['reuse'].is_a?(Hash)
        manifest['reuse']['safe_to_reuse'] = false
        review = Array(manifest['review']).map(&:to_s)
        review << "BATCH_VERIFICATION_FAILED:#{redact_batch(reason)}"
        manifest['review'] = review.uniq
        write_json_atomic(path, manifest)
        true
      rescue StandardError => e
        warn "Could not demote Admin flow #{path}: #{e.message}"
        false
      end

      def quarantine_admin_flow(path, reason)
        demoted = demote_admin_flow(path, reason)
        catalog = refresh_admin_flow_catalog
        {
          ok: demoted && catalog[:ok],
          quarantined: demoted,
          reason: reason.to_s,
          catalog: catalog
        }
      rescue StandardError => e
        { ok: false, quarantined: demoted == true, reason: e.message, catalog: { ok: false } }
      end

      def feature_contains_admin_step?(feature_text, semantic_text)
        expected = semantic_text.to_s.strip
        return false if expected.empty?

        feature_text.each_line.any? do |line|
          actual = line.strip.sub(/\A(?:Given|When|Then|And|But|\*)\s+/i, '').strip
          actual == expected
        end
      end

      def promote_admin_flow(path, feature_report_path:, feature_path:, run_status:)
        return { ok: false, reason: 'no Admin flow to promote' } unless path && File.file?(path) && !File.symlink?(path)
        unless run_status.to_s == 'passed'
          demote_admin_flow(path, "Feature status=#{run_status}")
          return { ok: false, reason: "Feature did not pass (#{run_status})" }
        end
        unless feature_path && File.file?(feature_path) && !File.symlink?(feature_path)
          return { ok: false, reason: 'generated Feature is missing or is a symlink' }
        end
        if feature_report_path.to_s.strip.empty? || !File.file?(feature_report_path) || File.symlink?(feature_report_path)
          return { ok: false, reason: 'Feature run report is missing or is a symlink' }
        end

        # Step 7 validates the artifact that was actually executed, rather than
        # trusting the runner exit code alone.  This prevents a stale/partial report
        # or an explicitly allowed @REVIEW draft from promoting browser evidence.
        feature_report = json_object_at(feature_report_path, 'Feature run report')
        reported_status = feature_report.dig('execution', 'status') || feature_report['status']
        unless %w[passed success].include?(reported_status.to_s)
          return { ok: false, reason: "Feature run report status is not passed (#{reported_status.inspect})" }
        end
        feature_text = File.read(feature_path, encoding: 'UTF-8')
        if feature_text.match?(/^\s*@REVIEW(?:\s|$)/i)
          return { ok: false, reason: 'generated Feature still carries @REVIEW' }
        end
        consistency = validate_admin_feature_consistency(path, feature_path)
        unless consistency[:ok]
          return {
            ok: false,
            reason: "standalone Admin Feature does not match MCP semantic flow: #{consistency[:reason]}"
          }
        end
        reported_feature = feature_report['feature'].is_a?(Hash) ? feature_report['feature'] : {}
        reported_path = reported_feature['path'].to_s.strip
        if !reported_path.empty? && expanded_path(reported_path) != expanded_path(feature_path)
          return { ok: false, reason: 'Feature run report points to a different Feature path' }
        end
        reported_sha = reported_feature['sha256'].to_s.strip
        actual_sha = Digest::SHA256.file(feature_path).hexdigest
        if reported_sha.match?(/\A[0-9a-f]{64}\z/i) && reported_sha.casecmp?(actual_sha) != 0
          return { ok: false, reason: 'Feature run report hash does not match the generated Feature' }
        end

        manifest = json_object_at(path, 'Admin flow manifest')
        unless manifest['evidence_status'].to_s == 'verified'
          return { ok: false, reason: 'Admin flow evidence is not verified' }
        end
        deferred_approval_steps = Array(manifest['steps']).select do |step|
          step.is_a?(Hash) && step['mcp_execution'].to_s == 'deferred_to_feature' &&
            final_approval_semantic_step?(step)
        end
        if manifest.dig('exploration', 'final_approval_deferred_to_feature') == true
          if deferred_approval_steps.empty?
            return { ok: false, reason: 'Admin flow declares deferred final approval but has no deferred approval step' }
          end
          missing_approval = deferred_approval_steps.find do |step|
            !feature_contains_admin_step?(feature_text, admin_semantic_step_text(step))
          end
          if missing_approval
            return {
              ok: false,
              reason: "generated Feature is missing deferred approval step: #{admin_semantic_step_text(missing_approval)}"
            }
          end
        end
        manifest['reuse'] = {} unless manifest['reuse'].is_a?(Hash)
        manifest['reuse']['safe_to_reuse'] = true
        manifest['reuse']['before_binary'] = true if manifest['channel'].to_s == 'hybrid'
        manifest['exploration'] = {} unless manifest['exploration'].is_a?(Hash)
        manifest['exploration']['safe_to_reuse'] = true
        manifest['exploration']['feature'] = workspace_reference(feature_path)
        manifest['exploration']['feature_report'] = workspace_reference(feature_report_path) if feature_report_path
        if manifest['exploration']['final_approval_deferred_to_feature'] == true
          manifest['exploration']['final_approval_feature_validation'] = 'passed'
        end
        manifest['exploration']['promoted_at'] = Time.now.utc.iso8601
        manifest['review'] = [] if manifest['review'].is_a?(Array)
        original_manifest = JSON.parse(JSON.generate(json_object_at(path, 'Admin flow manifest')))
        write_json_atomic(path, manifest)
        catalog = refresh_admin_flow_catalog
        unless catalog[:ok]
          # Promotion is transactional with catalog regeneration.  Leave the flow
          # quarantined if the index cannot be refreshed, and make a best-effort
          # second refresh so a stale safe_to_reuse entry is not left behind.
          rollback = original_manifest
          rollback['evidence_status'] = 'observed'
          rollback['reuse'] = {} unless rollback['reuse'].is_a?(Hash)
          rollback['reuse']['safe_to_reuse'] = false
          rollback['review'] = Array(rollback['review']).map(&:to_s)
          rollback['review'] << "BATCH_VERIFICATION_FAILED:#{redact_batch(catalog[:reason])}"
          rollback['review'].uniq!
          begin
            write_json_atomic(path, rollback)
            refresh_admin_flow_catalog
          rescue StandardError => rollback_error
            warn "Could not quarantine failed Admin flow promotion #{path}: #{rollback_error.message}"
          end
          return { ok: false, reason: catalog[:reason], catalog: catalog, quarantined: true }
        end

        { ok: true, path: path, catalog: catalog[:index] }
      rescue StandardError => e
        { ok: false, reason: "Admin flow promotion failed: #{e.class}: #{e.message}" }
      end

      def record_admin_correctness_failure(report_path, reason)
        return unless report_path && readable_artifact?(report_path)

        report = json_object_at(report_path, 'Admin exploration report')
        summary = admin_semantic_validation_summary(reason)
        if summary.start_with?('strict Step_Index semantic validation failed;')
          summary = compact_admin_transcript_error(reason, max_chars: 800)
        end
        report['status'] = 'failed'
        report['correctness_validation'] = {
          'status' => 'failed',
          'reason' => summary,
          'validated_at' => Time.now.utc.iso8601
        }
        report['first_failure'] = {
          'stage' => 'admin_flow_correctness',
          'reason' => summary
        }
        write_json_atomic(report_path, report)
      rescue StandardError => e
        warn "Could not record Admin flow correctness failure: #{e.message}"
      end
    end
  end
end
