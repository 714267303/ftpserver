# frozen_string_literal: true

# End-to-end Admin MCP exploration orchestration.

module BatchTransform
  module Admin
    module Exploration
      private

      def run_admin_exploration(yaml_path:, case_id:, channel:)
        approval_requested = yaml_requests_final_approval?(yaml_path)
        preflight_error = admin_mcp_preflight_error
        return { ok: false, reason: preflight_error } if preflight_error
        browser_command_expected = PLAYWRIGHT_MCP_COMMAND.to_s.strip != '' ||
                                   ADMIN_EXPLORE_COMMAND.to_s.strip == '' ||
                                   ADMIN_EXPLORE_COMMAND.to_s.match?(/\bopencode\b/)
        if browser_command_expected && !PLAYWRIGHT_MCP_HEADLESS && headed_display.nil?
          return {
            ok: false,
            reason: 'headed Playwright MCP requires DISPLAY (set DISPLAY=:99 for the VNC Xvfb or pass --playwright-mcp-headless)'
          }
        end
        odp_url = configured_odp_url
        if browser_command_expected && odp_url.nil?
          return {
            ok: false,
            reason: odp_url_configuration_error
          }
        end
        configured_secrets = PLAYWRIGHT_MCP_SECRETS.to_s.strip
        if !configured_secrets.empty? && playwright_mcp_secrets_path.nil?
          return { ok: false, reason: "configured Playwright MCP secrets file is unavailable: #{configured_secrets}" }
        end
        if browser_command_expected && ADMIN_EXPLORE_COMMAND.to_s.strip.empty? &&
           PLAYWRIGHT_MCP_COMMAND.to_s.strip.empty? && !playwright_mcp_credentials_configured?
          return {
            ok: false,
            reason: 'Playwright MCP dotenv secrets file was not found/readable; create the runtime .env or pass --playwright-mcp-secrets PATH'
          }
        end
        if browser_command_expected && ADMIN_EXPLORE_COMMAND.to_s.strip.empty? &&
           PLAYWRIGHT_MCP_COMMAND.to_s.strip.empty? && playwright_mcp_secrets_path
          missing_keys = playwright_mcp_missing_login_secret_keys(require_checker: approval_requested)
          unless missing_keys.empty?
            return {
              ok: false,
              reason: "Playwright MCP dotenv is missing required login key(s): #{missing_keys.join(', ')}"
            }
          end
        end
        root = expanded_path(ADMIN_EVIDENCE_ROOT)
        slug = safe_admin_slug(case_id)
        timestamp = Time.now.utc.strftime('%Y%m%dT%H%M%SZ')
        run_dir = File.join(root, slug, "run-#{timestamp}-#{Process.pid}-#{SecureRandom.hex(3)}")
        FileUtils.mkdir_p(run_dir)
        FileUtils.chmod_R(0o700, run_dir)
        candidate_path = File.join(run_dir, 'admin-flow.json')
        report_path = File.join(run_dir, 'exploration-report.json')
        transcript_path = File.join(run_dir, 'opencode-events.jsonl')

        environment = admin_exploration_environment(
          read_roots: [File.dirname(yaml_path), AUTO_SKILL, STEP_INDEX, ODP_DOC_INDEX,
                       File.dirname(ODP_DOC_INDEX), PAGE_EXPLORE_ROOT, SCRIPT_ROOT],
          edit_roots: [run_dir],
          evidence_dir: run_dir
        )
        # These non-secret hand-off variables make a project-owned adapter possible
        # without parsing the natural-language prompt.  They are also useful for a
        # deterministic local adapter in CI; credentials are never placed here.
        environment.merge!(
          'ADMIN_EXPLORATION_CASE_ID' => case_id.to_s,
          'ADMIN_EXPLORATION_CHANNEL' => channel.to_s,
          'ADMIN_EXPLORATION_YAML' => expanded_path(yaml_path),
          'ADMIN_EXPLORATION_FLOW_PATH' => candidate_path,
          'ADMIN_EXPLORATION_REPORT_PATH' => report_path,
          'ADMIN_EXPLORATION_EVIDENCE_DIR' => run_dir,
          'ADMIN_EXPLORATION_ODP_URL' => odp_url.to_s
        )
        prompt = admin_exploration_prompt(
          yaml_path: expanded_path(yaml_path),
          case_id: case_id,
          channel: channel,
          candidate_path: candidate_path,
          report_path: report_path,
          evidence_dir: run_dir,
          odp_url: odp_url,
          project_root: expanded_path(Dir.pwd),
          dotenv_path: playwright_mcp_secrets_path
        )
        command = build_admin_exploration_command(prompt)
        require_transcript_mcp = opencode_command?(command)
        result = run_opencode(
          "Step 1/7: Playwright MCP Admin exploration: #{case_id}",
          command,
          retry_on_hang: false,
          environment: environment,
          timeout_seconds: ADMIN_EXPLORE_TIMEOUT,
          capture_path: transcript_path,
          model_prompt: prompt,
          sensitive_values: playwright_mcp_login_secret_values
        )
        fallback_report_created = ensure_admin_exploration_failure_report(
          report_path: report_path,
          candidate_path: candidate_path,
          case_id: case_id,
          channel: channel,
          evidence_dir: run_dir,
          transcript_path: transcript_path,
          result: result,
          approval_requested: approval_requested
        )
        warn "Admin exploration agent omitted its report; wrote runner fallback: #{report_path}" if fallback_report_created
        reported_failure = admin_exploration_report_failure(report_path)
        unless result[:exit_code].to_i.zero?
          return {
            ok: false,
            reason: reported_failure || "Playwright MCP exploration command failed (exit #{result[:exit_code]})",
            result: result,
            run_dir: run_dir,
            report: report_path,
            transcript: transcript_path
          }
        end
        if reported_failure
          return {
            ok: false,
            reason: reported_failure,
            result: result,
            run_dir: run_dir,
            report: report_path,
            transcript: transcript_path
          }
        end
        unless readable_artifact?(candidate_path) && readable_artifact?(report_path)
          return {
            ok: false,
            reason: "exploration did not write both #{candidate_path} and #{report_path}",
            result: result,
            run_dir: run_dir,
            report: report_path,
            transcript: transcript_path
          }
        end

        _normalized_manifest, _normalized_report, normalization_changes =
          normalize_admin_flow_candidate_artifacts(
            candidate_path: candidate_path,
            report_path: report_path,
            case_id: case_id,
            phase: 'post_mcp'
          )
        unless normalization_changes.empty?
          log "[NORMALIZED] Admin candidate compatibility fields: #{normalization_changes.join(', ')}"
        end

        semantic_repair = nil
        begin
          manifest, report = validate_admin_exploration_artifacts(
            candidate_path: candidate_path,
            report_path: report_path,
            yaml_path: yaml_path,
            case_id: case_id,
            channel: channel,
            evidence_dir: run_dir,
            transcript_path: transcript_path,
            require_transcript_mcp: require_transcript_mcp
          )
        rescue AdminManifestSemanticError => semantic_error
          evidence_gaps = admin_semantic_evidence_gap(semantic_error.message)
          unless evidence_gaps.empty?
            raise AdminManifestSemanticError,
                  "Admin flow has browser/intent evidence gaps that cannot be repaired offline " \
                  "(#{evidence_gaps.join(', ')}); discard this candidate and run a fresh Playwright MCP rollback validation"
          end
          source_hash = Digest::SHA256.file(candidate_path).hexdigest
          warn 'Admin browser evidence passed but its semantic manifest is not executable; starting one browser-free repair.'
          semantic_repair = repair_admin_manifest_semantics(
            yaml_path: yaml_path,
            candidate_path: candidate_path,
            report_path: report_path,
            case_id: case_id,
            channel: channel,
            evidence_dir: run_dir,
            validation_reason: semantic_error.message
          )
          repaired_report = record_admin_manifest_semantic_repair(
            report_path: report_path,
            candidate_path: candidate_path,
            source_hash: source_hash,
            outcome: semantic_repair,
            initial_reason: semantic_error.message
          )
          unless semantic_repair[:ok]
            raise AdminManifestSemanticError,
                  "Browser-free Admin manifest repair failed; Playwright MCP was not rerun: #{semantic_repair[:reason]}"
          end

          repaired_manifest_payload = json_object_at(candidate_path, 'Repaired Admin flow candidate')
          if repaired_report['admin_steps_validated'].to_i.positive? && repaired_manifest_payload['steps'].is_a?(Array)
            repaired_report['admin_steps_validated'] = repaired_manifest_payload['steps'].length
            write_json_atomic(report_path, repaired_report)
          end

          _repaired_manifest, _repaired_report, repair_normalization_changes =
            normalize_admin_flow_candidate_artifacts(
              candidate_path: candidate_path,
              report_path: report_path,
              case_id: case_id,
              phase: 'post_semantic_repair'
            )
          unless repair_normalization_changes.empty?
            log "[NORMALIZED] Repaired Admin candidate compatibility fields: #{repair_normalization_changes.join(', ')}"
          end
          begin
            manifest, report = validate_admin_exploration_artifacts(
              candidate_path: candidate_path,
              report_path: report_path,
              yaml_path: yaml_path,
              case_id: case_id,
              channel: channel,
              evidence_dir: run_dir,
              transcript_path: transcript_path,
              require_transcript_mcp: require_transcript_mcp
            )
          rescue AdminManifestSemanticError => repaired_error
            raise AdminManifestSemanticError,
                  "Browser-free Admin manifest repair did not produce an executable manifest; " \
                  "Playwright MCP was not rerun: #{admin_semantic_validation_summary(repaired_error.message)}"
          end
        end
        flow_path, persisted_manifest, persisted_report = persist_admin_flow_candidate(
          manifest: manifest,
          report: report,
          report_path: report_path,
          evidence_dir: run_dir,
          yaml_path: yaml_path,
          case_id: case_id,
          channel: channel
        )
        catalog = refresh_admin_flow_catalog
        unless catalog[:ok]
          demote_admin_flow(flow_path, catalog[:reason])
          return {
            ok: false,
            reason: catalog[:reason],
            result: result,
            run_dir: run_dir,
            flow_path: flow_path,
            report: report_path,
            transcript: transcript_path
          }
        end
        {
          ok: true,
          result: result,
          run_dir: run_dir,
          flow_path: flow_path,
          report: report_path,
          transcript: transcript_path,
          manifest: persisted_manifest,
          report_payload: persisted_report,
          semantic_repair: semantic_repair,
          catalog: catalog[:index]
        }
      rescue ArgumentError => e
        { ok: false, reason: e.message, run_dir: defined?(run_dir) ? run_dir : nil }
      rescue AdminManifestSemanticError => e
        record_admin_correctness_failure(defined?(report_path) ? report_path : nil, e.message)
        {
          ok: false,
          reason: "Admin manifest handoff failed after browser exploration; Playwright MCP was not rerun: #{e.message}",
          run_dir: defined?(run_dir) ? run_dir : nil,
          report: defined?(report_path) ? report_path : nil,
          transcript: defined?(transcript_path) ? transcript_path : nil,
          browser_rerun: false
        }
      rescue StandardError => e
        record_admin_correctness_failure(defined?(report_path) ? report_path : nil, e.message)
        {
          ok: false,
          reason: "Admin exploration failed: #{e.class}: #{e.message}",
          run_dir: defined?(run_dir) ? run_dir : nil,
          report: defined?(report_path) ? report_path : nil,
          transcript: defined?(transcript_path) ? transcript_path : nil
        }
      end
    end
  end
end
