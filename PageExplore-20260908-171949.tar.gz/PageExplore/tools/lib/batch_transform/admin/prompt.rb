# frozen_string_literal: true

# Prompts, commands, and scoped environments for Admin exploration.

module BatchTransform
  module Admin
    module Prompt
      private

      def admin_exploration_prompt(yaml_path:, case_id:, channel:, candidate_path:, report_path:, evidence_dir:, odp_url: nil,
                                   project_root: Dir.pwd, dotenv_path: nil)
        navigation_url = odp_url.to_s.strip.empty? ? '<ODP_URL_NOT_CONFIGURED>' : "#{odp_url}ESUI/eventServerLanding.html"
        approval_requested = yaml_requests_final_approval?(yaml_path)
        expected_cleanup = approval_requested ? 'reject' : 'cancel'
        flow_schema = File.join(AUTO_SKILL, 'Admin_GUI', 'flow_catalog', 'schema.json')
        <<~TEXT
          Explore, validate, and roll back the Admin GUI portion of test case
          '#{yaml_path}' for case '#{case_id}' through the configured Playwright MCP
          server, then create a semantic hand-off.

          This is a rollback-validation Admin stage for a #{channel} case. Do not send
          Binary/FIX orders or run batch or clearing steps. Exercise the actual Admin
          form using the YAML Test Data. When the case uses maker/checker approval,
          submit the maker request, validate that the expected pending countersign
          request can be found by the checker, then Reject and confirm that request as
          cleanup. Never click Approve or an approval confirmation. When no
          countersign request is created, validate the entered form and use Cancel
          before any persistent save. A passed exploration must leave no pending or
          approved request and must leave the active business record in its original
          state.

          Cleanup is mandatory even after an intermediate validation failure. If a
          maker request was submitted, make a best-effort checker Reject before
          writing the failed report. If cleanup cannot be proven, set status to
          failed, cleanup_completed to false, final_state_restored to false, and put
          the cleanup failure in first_failure. Never claim a pass while a pending
          request or changed active record may remain.

          The candidate manifest is the complete source for a standalone Admin GUI
          Feature, not a small delta to splice into a Binary Feature and not the MCP
          cleanup path. It must contain, in execution order, every maintained UAT
          step needed to reproduce the validated Admin behavior: value loading when
          required, browser creation, one-user login sessions, saved maker/checker
          browser sessions, menu navigation, search/detail selection, maker edits,
          effective-date selection, submission/confirmation, final approval, and
          post-approval checks that the YAML requires. Do not emit only the final
          Approve operation. One MCP/browser action may expand to several exact
          Step_Index steps.

          Add `source_coverage` as the completeness map. For every source YAML
          TestSteps entry whose Execution Channel is admin_gui, add exactly one
          object containing its 1-based `yaml_step_index` and every 1-based
          `flow_step_indices` entry that implements it. Every manifest step must be
          covered by at least one source entry. Add a short `intent` array (for
          example navigation, search, open_detail, mutate, submit,
          deferred_approval, verify). This map is audited by the runner and must not
          claim coverage for an action that is absent from `steps`.

          Treat the PageExplore sitemap as an executable page contract. Resolve the
          exact sidebar parent and child from the selected route before writing any
          menu step. The manifest's `page.label`, `page.route`, `page.profile`, every
          `Select Trading Admin Left Menu` path, and every following Search/table/
          detail page name must describe the same page until an explicit navigation
          changes it. Do not infer a parent menu from a similar label. After each
          menu navigation, take a snapshot that exposes the current /UI/ route so
          the runner can bind the semantic flow to actual Playwright evidence.

          The candidate manifest describes the later Feature, not the cleanup path.
          The batch runner classified this YAML as
          final_approval_required=#{approval_requested}; use cleanup_action="#{expected_cleanup}".
          If the YAML requires maker/checker approval, keep the required Approve
          operation in the candidate so the generated Feature executes it later. Map
          it to the shortest applicable maintained Step_Index operation (for example
          `Approve if updated with :` when its exact signature and table fit), and
          encode it as an object with
          `"mcp_execution":"deferred_to_feature"`. Do not put the MCP Reject/Cancel
          cleanup action in manifest steps. The live Reject validates the checker
          route and safely rolls back the maker request; it does not replace the
          Feature's Approve step.
          Treat explicit values in each YAML Test Data block as the runtime data
          authority. If a Test Data value conflicts with an alias in Precondition,
          Step, or prose, use the explicit Test Data value and record the ambiguity;
          never silently replace it with the alias.

          Before navigation, read these project resources in order:
            1. the exact candidate schema '#{flow_schema}'
            2. '#{File.join(PAGE_EXPLORE_ROOT, 'sitemap.md')}'
            3. '#{File.join(PAGE_EXPLORE_ROOT, 'GRID_OPERATION_GUIDE.md')}' when a grid is used
            4. the relevant '#{File.join(PAGE_EXPLORE_ROOT, 'pages')}' profile
            5. the Admin rules and runtime Step_Index under '#{AUTO_SKILL}' and '#{STEP_INDEX}'
            6. existing human-authored examples at
               '#{File.join(SCRIPT_ROOT, 'uat', 'uat_admin_feature.txt')}', when
               present, only as read-only sequence/wording corroboration; examples
               never override sitemap, the selected profile, or Step_Index
          Use the ODP document index '#{ODP_DOC_INDEX}' only to clarify business intent;
          resolve an entry's `restored_path` below the index directory when both
          `path` and `restored_path` are present.
          You have read access to the complete runtime project at '#{project_root}'.
          Use that access for project documentation, runtime steps, configuration, and
          the login procedure below.  Write access remains limited to '#{evidence_dir}'.
          The batch runner has already resolved the non-secret ODP base URL.  Navigate
          first to exactly '#{navigation_url}'.  Do not guess a hostname, search logs,
          or inspect browser history to discover the URL. If the URL is
          '<ODP_URL_NOT_CONFIGURED>', stop and write both
          required artifacts with status 'failed' and explain that ODP_URL is missing.
          Before the first browser navigation, use the OpenCode file-read tool to read
          exactly '#{dotenv_path || '<NO_DOTENV_FILE_CONFIGURED>'}'. The maker login is
          ODP_USERNAME/ODP_PASSWORD (or SECRET_ODP_USERNAME/SECRET_ODP_PASSWORD). A
          maker/checker flow additionally requires
          ODP_CHECKER_USERNAME/ODP_CHECKER_PASSWORD (or the corresponding
          SECRET_ODP_CHECKER_* aliases). Use the actual private values only as
          Playwright fill/type arguments. Never pass any dotenv key name as browser
          input. The Playwright MCP `--secrets` file redacts matching values in tool
          responses; it does not substitute key names. If any credential required by
          this case is missing, do not submit a maker request: write both required
          artifacts with status 'failed', identify the configuration stage in
          `first_failure`, and stop.

          For each login, follow the sitemap sequence without snapshot refs: navigate,
          take an unscoped snapshot for observation, use
          `playwright_browser_run_code_unsafe` with the visible role/name to click
          "Login via WebAM", take another unscoped snapshot, then use the documented
          stable IDs to fill the visible login fields with the private values already
          read from the dotenv file and submit with `button.login-Button`. Use the
          maker credentials for submission and a separate checker session (or a clean
          logout/login transition) for countersign validation and Reject cleanup.
          Never use shell/python/bash, direct backend requests, window.fetch,
          XMLHttpRequest, qaGridApi.setRowData, or invented Gherkin. Raw Playwright
          locator code through `playwright_browser_run_code_unsafe` is allowed for UI
          interaction. Prefer visible role/name/label text, documented stable element
          IDs, and the reviewed snippets in GRID_OPERATION_GUIDE.md; do not use it to
          bypass the backend/network prohibitions above.

          Do not use shell, grep, Python, or another executable to read the dotenv
          file. Never quote,
          summarize, echo, or otherwise reveal a username, password, credential,
          cookie, token, UUID, or raw secret value in model text, terminal-oriented
          output, the report, the flow manifest, or any other written artifact.

          Treat every file and browser value as sensitive even when it is not one of
          the login keys: never reproduce raw values from `.env`, credential
          files, cookies, tokens, or Authorization data in text or artifacts.

          Playwright snapshot references are ephemeral observation handles and are
          not action targets in this workflow. Ref-based click/type/fill/select/
          hover/drag tools are disabled. Use each unscoped snapshot only to observe
          the current visible role/name/label/id, then perform UI actions through
          `playwright_browser_run_code_unsafe` with stable locators. Take a new
          unscoped snapshot after every navigation, action, dialog transition, or
          visible React re-render. Never pass a `[ref=...]` value to any tool. If a
          stale-ref error is encountered from an unexpected path, discard it, take a
          new snapshot, and continue with a stable raw locator; never retry the old
          ref. For the documented login page, prefer stable role/name and `#loginid`,
          `#loginpassword`, and `button.login-Button` locators.
          Before ending, always write both the candidate manifest and the report,
          including a failed report when the first required Admin action cannot be
          completed.

          Save the candidate semantic manifest JSON exactly to '#{candidate_path}' and
          the exploration report exactly to '#{report_path}'. Keep raw MCP traces,
          screenshots, and logs below '#{evidence_dir}'. The candidate must conform
          to '#{flow_schema}'. Use this exact top-level shape (replace angle-bracket
          descriptions with the correct semantic values):

            {
              "schema_version": 1,
              "flow_id": "admin.#{safe_admin_slug(case_id).downcase}.mcp.v1",
              "case_id": "#{case_id}",
              "name": "<short Admin flow name>",
              "channel": "#{channel}",
              "evidence_status": "observed",
              "page": {
                "label": "<label from the page profile>",
                "route": "/UI/<exact route>",
                "profile": "pageExplore/pages/<route basename>.md"
              },
              "background": [
                {"text": "<exact executable shared setup Step_Index text>"}
              ],
              "steps": [
                {
                  "text": "Open browser"
                },
                {
                  "text": "Login Trading Admin with:",
                  "table": [["User ID", "User Password"], ["<maker dataset user>", "<maker dataset password>"]]
                },
                {
                  "text": "<exact executable maker/navigation Step_Index text>",
                  "table": [["<header>"], ["<dataset placeholder>"]]
                },
                {
                  "text": "<exact executable checker/final-approval Step_Index text>",
                  "table": [["<documented header>"], ["<dataset placeholder>"]],
                  "mcp_execution": "deferred_to_feature"
                }
              ],
              "source_coverage": [
                {
                  "yaml_step_index": 1,
                  "flow_step_indices": [1, 2, 3, 4],
                  "intent": ["navigation", "search", "mutate"]
                }
              ],
              "evidence": {},
              "reuse": {"keywords": ["<stable page/function keyword>"], "safe_to_reuse": false}
            }

          Never use top-level `page_route`; the route belongs at `page.route`, and
          `page.profile` is mandatory. Every object in `steps` must use `text`; never
          substitute `uat_step`, `operation`, or `step_index` for `text` (those may
          only be optional audit metadata). Step text must be an exact executable
          runtime Step_Index operation, not a natural-language browser summary. Add
          every DataTable required by the matched Step_Index signature. In particular,
          `Approve if updated with :` requires its documented table. Omit
          `mcp_execution` for ordinary maker steps; `validated_read_only` is allowed
          only for a read-only semantic step, and a required unexecuted Approve must
          use `deferred_to_feature`. Never write `mcp_execution: "completed"`.

          Use dataset placeholders rather than secret or environment-specific live
          values. Include deferred approval steps required by the YAML even though
          MCP does not execute Approve. Exclude Reject/Cancel cleanup from semantic
          steps. Set reuse.safe_to_reuse to false. After writing both JSON files,
          read the candidate back, compare every required field and enum against the
          schema, verify `admin_steps_validated` equals the number of candidate
          `steps`, and correct any mismatch before ending.

          The report must be JSON with at least:
            {"schema_version":1,"status":"passed","case_id":"#{case_id}",
             "channel":"#{channel}","clean_state":true,
             "exploration_mode":"rollback_validation",
             "business_mutations_executed":#{approval_requested},
             "maker_submission_executed":#{approval_requested},
             "final_approval_executed":false,
             "cleanup_action":"#{expected_cleanup}","cleanup_completed":true,
             "final_state_restored":true,
             "final_approval_deferred_to_feature":#{approval_requested},
             "admin_steps_executed":<browser-action-count>,
             "admin_steps_validated":<candidate-manifest-steps-count>,
             "mcp_tools_used":["playwright_..."],
             "evidence_dir":"#{evidence_dir}","manifest_path":"#{candidate_path}"}
          For a maker/checker case, a passed report must set
          maker_submission_executed=true, business_mutations_executed=true,
          cleanup_action="reject", cleanup_completed=true, and
          final_state_restored=true. For a no-countersign case, do not persist a
          change; use cleanup_action="cancel". Set
          `final_approval_deferred_to_feature` to true exactly when the YAML or
          candidate requires approval. Set status to failed and put the first concrete
          failure in a `first_failure` object containing `stage` and `reason` if the
          validation or cleanup did not complete.
          Do not put credentials or field values in that reason. The batch process will calculate/verify the manifest hash and
          will not promote a failed or ambiguous exploration.
        TEXT
      end

      def build_admin_exploration_command(prompt)
        configured = ADMIN_EXPLORE_COMMAND.to_s.strip
        configured = 'opencode run --thinking --format json' if configured.empty?
        tokens = Shellwords.split(configured)
        raise ArgumentError, 'Admin exploration command is empty' if tokens.empty?
        forbidden = tokens.select do |token|
          token.to_s.match?(/\A--(?:pure|auto|dangerously-skip-permissions)(?:=|\z)/)
        end
        unless forbidden.empty?
          raise ArgumentError, "Admin exploration command cannot use #{forbidden.join(', ')}"
        end
        tokens = append_opencode_model(tokens)
        replaced = false
        tokens = tokens.map do |token|
          if token.include?('{prompt}')
            replaced = true
            token.gsub('{prompt}', prompt)
          else
            token
          end
        end
        tokens << prompt unless replaced
        Shellwords.join(tokens)
      end

      def build_admin_manifest_repair_command(prompt)
        # Do not reuse ADMIN_EXPLORE_COMMAND here: it may be a project-owned browser
        # adapter rather than OpenCode. Semantic repair is an isolated model pass and
        # its permission overlay disables MCP/browser/executable tools.
        tokens = append_opencode_model(%w[opencode run --pure --thinking --format json])
        Shellwords.join(tokens + [prompt])
      end

      def admin_exploration_environment(read_roots:, edit_roots:, evidence_dir:)
        project_root = expanded_path(Dir.pwd)
        dotenv_path = playwright_mcp_secrets_path
        environment = conversion_permission_environment(
          read_roots: [project_root, dotenv_path, *Array(read_roots)],
          edit_roots: edit_roots
        )
        config = JSON.parse(environment.fetch('OPENCODE_CONFIG_CONTENT'))
        permission = config.fetch('permission')
        # Admin exploration is the one model stage allowed to inspect runtime
        # configuration, including ProjectA/.env. The model reads the selected file
        # before login and uses its ODP credentials only as browser fill values. The
        # external-directory policy still limits access to the runtime project and
        # the explicitly configured dotenv path; edit permissions remain scoped to
        # this run's evidence directory.
        permission['read'] = {
          '*' => 'allow',
          '.git/**' => 'deny'
        }
        # OpenCode names local MCP tools after their server/tool pair.  Keep a
        # wildcard for both the current `playwright_*` names and future capabilities,
        # while bash/execute remain denied by the base permission overlay.
        permission['playwright_*'] = 'allow'
        permission['mcp.playwright.*'] = 'allow'
        permission['mcp'] = 'allow'
        # Snapshot refs are tied to one transient accessibility-tree generation and
        # proved unreliable across React renders. Keep snapshots for observation,
        # explicitly allow raw Playwright locators, and make stale-ref actions
        # impossible in the Admin model environment.
        permission['playwright_browser_run_code_unsafe'] = 'allow'
        %w[click type fill_form select_option hover drag].each do |action|
          permission["playwright_browser_#{action}"] = 'deny'
          permission["mcp.playwright.browser_#{action}"] = 'deny'
        end

        configured_output_dir = PLAYWRIGHT_MCP_OUTPUT_DIR.to_s.strip
        output_dir = if configured_output_dir.empty?
                       File.join(evidence_dir, 'playwright')
                     else
                       # Treat the configured value as a base, then isolate every
                       # case/run below it.  A shared MCP output directory otherwise
                       # lets traces from two cases be mistaken for one another.
                       File.join(expanded_path(configured_output_dir), safe_admin_slug(File.basename(evidence_dir)))
                     end
        output_dir = expanded_path(output_dir)
        FileUtils.mkdir_p(output_dir)
        FileUtils.chmod_R(0o700, output_dir)

        server_command = playwright_mcp_server_command(output_dir)
        if server_command
          config['mcp'] = {
            'playwright' => {
              'type' => 'local',
              'command' => Shellwords.split(server_command),
              'cwd' => Dir.pwd,
              'enabled' => true,
              'timeout' => 120_000
            }
          }
        elsif (existing = existing_playwright_mcp_entry)
          # Reuse an installed project MCP entry when its CLI path is not one of the
          # conventional offline locations.  Normalize the headless switch here so
          # --playwright-mcp-headed works even with the installer's historical
          # `--headless` template.
          config['mcp'] = {'playwright' => normalize_existing_playwright_entry(existing[1], output_dir)}
        end
        environment['OPENCODE_CONFIG_CONTENT'] = JSON.generate(config)

        project_config = opencode_config_path_for(Dir.pwd)
        environment['OPENCODE_CONFIG'] = project_config if project_config
        # This is deliberately the only ODP value exposed through the model process
        # environment. It is navigation configuration, not a credential; login
        # values are read from the selected dotenv file with the model file tool and
        # are also registered with the transcript/terminal redactor by the caller.
        odp_url = configured_odp_url
        environment['ODP_URL'] = odp_url if odp_url
        unless PLAYWRIGHT_MCP_HEADLESS
          display = headed_display
          environment['DISPLAY'] = display if display
        end
        environment['PLAYWRIGHT_MCP_IGNORE_HTTPS_ERRORS'] = ENV.fetch(
          'PLAYWRIGHT_MCP_IGNORE_HTTPS_ERRORS', '1'
        )
        environment
      rescue JSON::ParserError => e
        raise "cannot construct OpenCode exploration permissions: #{e.message}"
      end
    end
  end
end
