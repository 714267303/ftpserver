# frozen_string_literal: true

require_relative "batch_transform/core"
require_relative "batch_transform/admin"
require_relative "batch_transform/feature_pipeline"
require_relative "batch_transform/execution_flow"
require_relative "batch_transform/pipeline"

module BatchTransform
  COMPONENTS = [
    Core,
    Admin::Configuration,
    Admin::Prompt,
    Admin::SemanticValidation,
    Admin::EvidenceValidation,
    Admin::Exploration,
    FeaturePipeline,
    ExecutionFlow,
    Pipeline
  ].freeze

  def self.install!(target = Object)
    COMPONENTS.each { |component| target.__send__(:include, component) }
  end
end
