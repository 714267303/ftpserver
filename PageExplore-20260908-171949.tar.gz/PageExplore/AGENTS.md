# MANDATORY: Read These Files Before Tasks

**This directory contains ODP website exploration documentation together with
maintained conversion, indexing, and Feature-repair tools.** Documentation is
the source of truth for website exploration; scripts and generated indexes may
be edited or run when the task explicitly requires it.

> **Configuration**: Copy `.env.example` to `.env` and set `ODP_URL`, the maker
> `ODP_USERNAME`/`ODP_PASSWORD`, and, for maker/checker cases, the cleanup
> `ODP_CHECKER_USERNAME`/`ODP_CHECKER_PASSWORD`.

## Scope and Safety
Edits and local verification of files in this directory are allowed. Keep
changes scoped to the requested task, preserve source/evidence provenance, and
do not modify an external runtime checkout, website data, credentials, or
browser state unless that operation is explicitly requested. When exploring
the ODP website, use Playwright MCP and follow the reading order below.

All files under `pageExplore/` (or the directory configured by
`PAGEEXPLORE_ROOT`) are resources for exploring the website. Read them **on
demand** based on the task. The PageExplore knowledge base is independent of
the user skills under `odpt-automation-skill/`.

| File | When to Read | Why |
|------|-------------|------|
| `pageExplore/sitemap.md` | **BEFORE navigating to any page** | Login procedure, SPA navigation, all 96 page routes, qaGrid API reference, per-page profile links |
| `pageExplore/GRID_OPERATION_GUIDE.md` | **BEFORE any grid task** (filtering, pagination, opening details) | Templates (page.route, paginate, XHR override), opening row detail via double-click, cacheName pattern, filter value conventions, common pitfalls |
| `pageExplore/selenium_solution.md` | **When working with Selenium-based automation** | Alternative automation approach and considerations |
| `pageExplore/pages/<routeName>.md` | **BEFORE working on a specific page** | Per-page schema (columns, pkField, boolean/code fields, cacheName, filterability notes) — linked from sitemap |

## Concept Summary

- **SPA**: React, canvas-based qaGrid tables (no DOM table elements)
- **Data**: Accessed via `window.qaGridApi[gridKey]` — never fetch backend APIs directly
- **Filtering**: Use `page.route('**/api/private/subscribeView')` + click "Apply" button (see `pageExplore/GRID_OPERATION_GUIDE.md` for complete templates)
- **Opening Detail**: Double-click row on `#canvasTableWrapperRef` with `{ force: true, position: { x: 100, y: 48 + rowIndex * 48 + 24 } }` (see `pageExplore/GRID_OPERATION_GUIDE.md`)
- **Key rules**: `**/api/private/subscribeView` (NOT `**/subscribeView`), always `unroute()` before re-routing, boolean values are `"Y"`/`"N"`, cacheName is `<pageName>PermCache` with lowercase first letter
- **Never override** `window.fetch`/`XMLHttpRequest` — use Playwright's `page.route()` instead

## Sitemap Reference

- All 96 pages with exact routes and per-page profile links: `pageExplore/sitemap.md`
- Route pattern: search pages `/UI/ui<CamelCaseFunction>SearchTable`, action forms `/UI/ui<CamelCaseFunction>`
- Per-page profiles in `pageExplore/pages/`: columns, cacheName, pkField, boolean/code fields

## Website Configuration (from `.env`)

- **URL**: `${ODP_URL}`
- **Maker**: `${ODP_USERNAME}` / `${ODP_PASSWORD}`
- **Checker cleanup**: `${ODP_CHECKER_USERNAME}` / `${ODP_CHECKER_PASSWORD}`
- **Browser SSL/TLS**: The Playwright MCP installer ignores the internal ODP
  certificate by default (`PLAYWRIGHT_MCP_IGNORE_HTTPS_ERRORS=1`). Set it to
  `0` to restore browser verification. This applies only to browser
  navigation; keep provider TLS verification enabled and never use the global
  `NODE_TLS_REJECT_UNAUTHORIZED=0` workaround.
