# Standardization Rules for ODP Test Case YAML Generation

## Standard Step Phrasings

### GUI Actions
- "Use Maker user, go to the 'Bulk Import from File' dialog in the Admin GUI to upload the CSV file"
- "Use Checker user, perform the 'Countersign' action"
- "Through Admin GUI, <create/modify/delete> <entity>"
- "Use <role> account" (e.g., Maker, Checker, Admin)
- "Login as <participant/role>, navigate to <module> page"
- "Navigate to <function> in <system>"

### System Operations
- "Advance the system to the next business day"
- "Advance the system to <specific time/state>"
- "Reset the system to <state>"

### Order/Trade Operations
- "During <session_type> matching sessions, <action>"
- "Input a <order_type> Order on <instrument> via <Binary/Trading GUI>"

### File Upload / Bulk Import (Admin GUI, FS10013 §4.1.3)
- "Use Maker user, go to the 'Bulk Import from File' dialog in the Admin GUI to upload the CSV file containing the following <entity> record(s):"
- Allowed Import Types: Underlying, Inst. Type, Inst. Class, Instrument, Combo Type, Combo Class, Combo, Access Group by Type, Special Trading Days, Non-Trading Days, MMP, Price Tick, Instrument Class Price Tick Limit, Combo Class Price Tick Limit, SMP Token, SMP Token List, Order Flow Session, Legal IP Address List

## Step/Expected Result Interface/Window Rules

Every step action and every expected result MUST specify which system and which window/page.

| Vague Description | Clarified with System + Window |
|---|---|
| "check Open/High/Low/Last/Volume" | "Check in the Price Information window of the Trading GUI" |
| "trade records are updated" (participant) | "Check the Trade View and Trade History in the External Trading GUI" |
| "trade records are updated" (internal) | "Check the Trade View and Trade History in the Internal Trading GUI" |
| "total volume are reflected" | "Check the Market Statistic window of the Internal/External Trading GUI" |
| "Dynamic Ref.Price ... check from Admin GUI" | "Check in Admin GUI > Price Supervision > Control & Monitor Price Limit — the Current Reference Price field" |
| "order executed message are sent" | "Check the Trade View in each participant's Trading GUI" |
| "accepted by the system" (file upload) | "Verify from the 'Bulk Import from File' dialog of the Admin GUI" |
| "rejected by the system" | "Verify the rejection message in the <input dialog/window> of the <system>" |
| "is activated" (combo) | "Verify from the Maintain Combo page of the Admin GUI" |
| "is activated" (instrument) | "Verify from the Maintain Instrument page of the Admin GUI" |
| "FTD and FTT" (combo creation) | "Check the First Trading Date and First Trading Time — verify from the 'Bulk Import from File' dialog of the Admin GUI" |

## System and Window Reference

### External Trading GUI (FS10014a - ODP Online GUI):
- `Price Information` (6.15) — Open/High/Low/Last Price, Volume
- `Trade View` (6.22) — Trade records per participant
- `Trade History` (6.9) — Trade history per participant
- `Trade History Aggregated` (6.10) — Aggregated trade data
- `Market Statistic` (6.19) — Total volume, trade count aggregates
- `Ticker` (6.11) — Real-time price ticker
- `Order Depth` (6.16) — Order book depth
- `Exchange On-Behalf Trade` (6.32) — For exchange staff placing on-behalf trades

### Internal Trading GUI:
- `Trade View` — Internal trade records
- `Trade History` — Internal trade history
- `Price Information` — Price statistics
- `Market Statistic` — Internal aggregate statistics

### Admin GUI (FS10013 - Market Operation Admin GUI):
- `Bulk Import from File` (4.1.3) — Bulk upload of records via CSV file
- `Price Supervision > Control & Monitor Price Limit` (4.8.12) — Current Reference Price, Next Day Reference Price, Price Upper/Lower Limit
- `Price Supervision > Maintain Reference Price Source` (4.8.7) — Reference price source config
- `Price Supervision > Maintain Reference Price Calculation Rule` (4.8.8) — Calculation rules
- `Price Supervision > Maintain Price Tick` (4.8.1) — Tick size configuration
- `Order Book > Maintain Instrument` (4.2.7) — Instrument order book management
- `Maintain Combo` (4.3.4) — Combo orderbook management

### Binary Interface:
- Default interface for placing orders/quotes when Excel does not specify
- FIX messages: New Order Single, Order Cancel, etc.

## YAML Formatting Rules

- Use `|-` for multiline string values (test data, expected results, preconditions)
- Use `"<text>"` for single-line values containing special characters
- First `TestSteps` list item contains ALL metadata + first step
- Subsequent items only contain step/expected result, no metadata
- Preserve tabs as actual tab characters in data tables
- Remove non-breaking spaces and trailing whitespace from lines

## Label Convention
- Preserve existing labels from Excel exactly (e.g., Batch-3, Batch-1)
- Do NOT invent or add labels beyond what Excel specifies
