#!/usr/bin/env python3
"""
Parse ODP test case Excel files and extract FS document text.
Handles both single-row (1 row per case) and multi-row (continuation rows) formats.

Usage:
  python3 parse_excel.py <excel_path> [row_number]    # Parse a single Excel test case
  python3 parse_excel.py --all <excel_path>            # Parse ALL test cases as JSON array
  python3 parse_excel.py --fs <docx_path>              # Extract FS text
  python3 parse_excel.py --fs-search <docx_path> <keyword>  # Search FS for keyword
"""

import sys
import os
import re
import json
import zipfile
import csv
import xml.etree.ElementTree as ET

NS = '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'

HEADER_TO_FIELD = {
    'Key': 'Key', 'Name': 'Name', 'Status': 'Status', 'Precondition': 'Precondition',
    'Objective': 'Objective', 'Folder': 'Folder', 'Priority': 'Priority',
    'Component': 'Component', 'Labels': 'Labels', 'Owner': 'Owner',
    'Estimated Time': 'Estimated Time', 'Coverage (Issues)': 'Coverage_Issues',
    'Coverage (Pages)': 'Coverage_Pages', 'Checker': 'Checker',
    'Checker 2': 'Checker_2', 'Auto Checker': 'Auto_Checker',
    'Auto Owner': 'Auto_Owner', 'Step': 'Step', 'Test Data': 'Test_Data',
    'Expected Result': 'Expected_Result', 'Plain Text': 'Plain_Text', 'BDD': 'BDD',
    'Test Script (Plain Text)': 'Plain_Text', 'Test Script (BDD)': 'BDD',
}

CASE_FIELDS = {
    'key': 'Key',
    'name': 'Name',
    'status': 'Status',
    'precondition': 'Precondition',
    'objective': 'Objective',
    'folder': 'Folder',
    'priority': 'Priority',
    'labels': 'Labels',
    'owner': 'Owner',
    'coverage': 'Coverage_Issues',
    'checker': 'Checker',
    'checker_2': 'Checker_2',
    'plain_text': 'Plain_Text',
    'bdd': 'BDD',
}

STEP_FIELDS = {
    'step': 'Step',
    'testdata': 'Test_Data',
    'expected': 'Expected_Result',
}

COLUMN_FALLBACK = {
    'A': 'Key', 'B': 'Name', 'C': 'Status', 'D': 'Precondition',
    'E': 'Objective', 'F': 'Folder', 'G': 'Priority', 'H': 'Component',
    'I': 'Labels', 'J': 'Owner', 'K': 'Estimated Time', 'L': 'Coverage_Issues',
    'M': 'Coverage_Pages', 'N': 'Checker', 'O': 'Checker_2',
    'P': 'Step', 'Q': 'Test_Data', 'R': 'Expected_Result',
    'S': 'Plain_Text', 'T': 'BDD',
}


def extract_cell_text(cell, shared_strings, ns=NS):
    """Extract text from a cell (inlineStr or shared string or numeric)."""
    cell_type = cell.get('t')
    v = cell.find(f'{ns}v')
    if cell_type == 's' and v is not None and v.text:
        idx = int(v.text)
        return shared_strings[idx] if idx < len(shared_strings) else ''
    inline = cell.find(f'{ns}is')
    if inline is not None:
        return ''.join(t.text for t in inline.iter(f'{ns}t') if t.text)
    if v is not None and v.text:
        return v.text
    return ''


def normalize_text(value):
    if value is None:
        return ''
    text = str(value)
    if text.strip().lower() == 'nan':
        return ''
    return text.replace('\\n', '\n').replace('\\t', '\t')


def parse_shared_strings(zf):
    try:
        with zf.open('xl/sharedStrings.xml') as f:
            tree = ET.parse(f)
        return [''.join(t.text for t in si.iter(NS + 't') if t.text)
                for si in tree.getroot().findall(NS + 'si')]
    except Exception:
        return []


def field_from_header(header_text):
    header_text = normalize_text(header_text).strip()
    candidates = [header_text]
    if ' - ' in header_text:
        candidates.append(header_text.split(' - ')[-1].strip())
    for candidate in candidates:
        if candidate in HEADER_TO_FIELD:
            return HEADER_TO_FIELD[candidate]
    return None


def detect_header_mapping(zf, shared_strings=None):
    shared_strings = shared_strings or []
    try:
        with zf.open('xl/worksheets/sheet1.xml') as f:
            tree = ET.parse(f)
        header_row = tree.getroot().findall(f'{NS}sheetData/{NS}row')
        if not header_row:
            return COLUMN_FALLBACK

        mapping = {}
        for cell in header_row[0].findall(f'{NS}c'):
            ref = cell.get('r')
            col_match = re.match(r'([A-Z]+)', ref)
            if not col_match:
                continue
            col_ref = col_match.group(1)
            field_name = field_from_header(extract_cell_text(cell, shared_strings))
            if field_name:
                mapping[col_ref] = field_name

        return mapping if len(mapping) >= 5 else COLUMN_FALLBACK
    except Exception:
        return COLUMN_FALLBACK


def _build_cell_dict(row_elem, shared_strings):
    cells = {}
    for cell in row_elem.findall(f'{NS}c'):
        ref = cell.get('r')
        col_match = re.match(r'([A-Z]+)', ref)
        if not col_match:
            continue
        col_ref = col_match.group(1)
        cells[col_ref] = extract_cell_text(cell, shared_strings)
    return cells


def is_row_empty(cells):
    return not any(cells.get(c, '').strip() for c in cells)


def row_fields_from_cells(cells, col_map):
    fields = {}
    for col_letter, field_name in col_map.items():
        fields[field_name] = normalize_text(cells.get(col_letter, ''))
    return fields


def is_field_row_empty(fields):
    return not any(value.strip() for value in fields.values())


def infer_execution_channel(step, expected=''):
    text = f"{step}\n{expected}".lower()
    if any(token in text for token in ['admin gui', 'trading admin', 'countersign', 'maintain ']):
        return 'admin_gui'
    if any(token in text for token in ['trading gui', 'price information', 'trade view', 'order depth', 'price depth']):
        return 'trading_gui'
    if any(token in text for token in ['binary', 'fix', 'proxy', 'newordersingle', 'new order', 'mass quote', 'single quote']):
        return 'binary_proxy'
    if 'clearing' in text:
        return 'clearing'
    if any(token in text for token in ['night batch', 'after batch', 'next business day', 'next trading day']):
        return 'batch'
    return 'manual_or_unspecified'


def build_step(fields):
    step = {output_name: fields.get(field_name, '') for output_name, field_name in STEP_FIELDS.items()}
    step['execution_channel'] = infer_execution_channel(step.get('step', ''), step.get('expected', ''))
    step['source_evidence'] = 'excel'
    return step


def build_case(fields):
    case = {output_name: fields.get(field_name, '') for output_name, field_name in CASE_FIELDS.items()}
    case['steps'] = []
    return case


def parse_field_rows(field_rows):
    has_multiline = any(
        not row.get('Key', '').strip() and (
            row.get('Step', '').strip() or
            row.get('Test_Data', '').strip() or
            row.get('Expected_Result', '').strip()
        )
        for row in field_rows
        if not is_field_row_empty(row)
    )
    return _parse_multiline_fields(field_rows) if has_multiline else _parse_single_row_fields(field_rows)


def _parse_single_row_fields(field_rows):
    cases = []
    for fields in field_rows:
        if is_field_row_empty(fields):
            continue
        key = fields.get('Key', '').strip()
        if not key:
            continue
        case = build_case(fields)
        step = build_step(fields)
        if step['step'].strip() or step['testdata'].strip() or step['expected'].strip():
            case['steps'].append(step)
        case['execution_channels'] = sorted({item['execution_channel'] for item in case['steps']})
        cases.append(case)
    return cases


def _parse_multiline_fields(field_rows):
    cases = []
    current = None
    for fields in field_rows:
        if is_field_row_empty(fields):
            continue
        key = fields.get('Key', '').strip()
        if key:
            if current:
                current['execution_channels'] = sorted({item['execution_channel'] for item in current['steps']})
                cases.append(current)
            current = build_case(fields)
        if current:
            step = build_step(fields)
            if step['step'].strip() or step['testdata'].strip() or step['expected'].strip():
                current['steps'].append(step)
    if current:
        current['execution_channels'] = sorted({item['execution_channel'] for item in current['steps']})
        cases.append(current)
    return cases


def read_excel(filepath, row_num=1):
    """Read a single test case row from Excel."""
    with zipfile.ZipFile(filepath, 'r') as zf:
        shared = parse_shared_strings(zf)
        col_map = detect_header_mapping(zf, shared)
        with zf.open('xl/worksheets/sheet1.xml') as f:
            tree = ET.parse(f)

        rows = tree.getroot().findall(f'{NS}sheetData/{NS}row')
        if row_num >= len(rows):
            print(f"Error: row {row_num} out of range (total {len(rows)} rows)", file=sys.stderr)
            sys.exit(1)

        cells = _build_cell_dict(rows[row_num], shared)
        result = {}
        for col_letter, field_name in col_map.items():
            result[field_name] = cells.get(col_letter, '')
        return result


def read_all_test_cases(filepath):
    """Read all test cases from Excel, handling both single-row and multi-row formats."""
    if filepath.lower().endswith(('.md', '.tsv', '.txt')):
        return read_all_text_test_cases(filepath)

    with zipfile.ZipFile(filepath, 'r') as zf:
        shared = parse_shared_strings(zf)
        col_map = detect_header_mapping(zf, shared)
        with zf.open('xl/worksheets/sheet1.xml') as f:
            tree = ET.parse(f)
        all_rows = tree.getroot().findall(f'{NS}sheetData/{NS}row')

    field_rows = [
        row_fields_from_cells(_build_cell_dict(row_elem, shared), col_map)
        for row_elem in all_rows[1:]
    ]
    return parse_field_rows(field_rows)


def read_all_text_test_cases(filepath):
    with open(filepath, encoding='utf-8') as handle:
        lines = [line.rstrip('\n') for line in handle if line.strip()]
    if lines and lines[0].strip().lower().startswith('sheet'):
        lines = lines[1:]
    if not lines:
        return []

    reader = csv.reader(lines, delimiter='\t')
    rows = list(reader)
    if not rows:
        return []
    header = rows[0]
    index_map = {}
    for index, header_text in enumerate(header):
        field_name = field_from_header(header_text)
        if field_name:
            index_map[index] = field_name
    field_rows = []
    for row in rows[1:]:
        fields = {}
        for index, field_name in index_map.items():
            fields[field_name] = normalize_text(row[index]) if index < len(row) else ''
        field_rows.append(fields)
    return parse_field_rows(field_rows)


def yaml_scalar(value):
    text = normalize_text(value)
    escaped = (
        text
        .replace('\\', '\\\\')
        .replace('"', '\\"')
        .replace('\r', '\\r')
        .replace('\n', '\\n')
        .replace('\t', '\\t')
    )
    return f'"{escaped}"'


def yaml_block_lines(value, indent):
    text = normalize_text(value)
    if not text.strip():
        return [' ' * indent]
    return [(' ' * indent) + line for line in text.splitlines()]


def case_to_yaml(case):
    lines = ['---', f"Key: {yaml_scalar(case.get('key', ''))}", 'TestSteps:']
    steps = case.get('steps') or []
    if not steps:
        steps = [{'step': '', 'testdata': '', 'expected': '', 'execution_channel': 'manual_or_unspecified'}]
    for index, step in enumerate(steps):
        prefix = '- ' if index == 0 else '- '
        lines.append(f"{prefix}Execution Channel: {yaml_scalar(step.get('execution_channel', 'manual_or_unspecified'))}")
        lines.append(f"  Source Evidence: {yaml_scalar(step.get('source_evidence', 'excel'))}")
        if index == 0:
            lines.extend([
                f"  Key: {yaml_scalar(case.get('key', ''))}",
                f"  Name: {yaml_scalar(case.get('name', ''))}",
                f"  Status: {yaml_scalar(case.get('status', ''))}",
                '  Precondition: |-',
                *yaml_block_lines(case.get('precondition', ''), 4),
                f"  Objective: {yaml_scalar(case.get('objective', ''))}",
                f"  Folder: {yaml_scalar(case.get('folder', ''))}",
                f"  Priority: {yaml_scalar(case.get('priority', ''))}",
                f"  Labels: {yaml_scalar(case.get('labels', ''))}",
                f"  Owner: {yaml_scalar(case.get('owner', ''))}",
                f"  Coverage (Issues): {yaml_scalar(case.get('coverage', ''))}",
                f"  Checker: {yaml_scalar(case.get('checker', ''))}",
            ])
        lines.extend([
            '  Test Script (Step-by-Step) - Step: |-',
            *yaml_block_lines(step.get('step', ''), 4),
            '  Test Script (Step-by-Step) - Test Data: |-',
            *yaml_block_lines(step.get('testdata', ''), 4),
            '  Test Script (Step-by-Step) - Expected Result: |-',
            *yaml_block_lines(step.get('expected', ''), 4),
        ])
    return '\n'.join(lines) + '\n'


def cases_to_yaml(cases):
    if len(cases) != 1:
        documents = [case_to_yaml(case).strip() for case in cases]
        return '\n'.join(documents) + '\n'
    return case_to_yaml(cases[0])


def _parse_single_row(data_rows, shared):
    cases = []
    for row_elem in data_rows:
        cells = _build_cell_dict(row_elem, shared)
        if is_row_empty(cells):
            continue
        key = cells.get('A', '').strip()
        if not key:
            continue
        cases.append({
            'key': key,
            'name': cells.get('B', ''),
            'status': cells.get('C', ''),
            'precondition': cells.get('D', ''),
            'objective': cells.get('E', ''),
            'folder': cells.get('F', ''),
            'priority': cells.get('G', ''),
            'labels': cells.get('I', ''),
            'owner': cells.get('J', ''),
            'coverage': cells.get('L', ''),
            'checker': cells.get('P', ''),
            'checker_2': cells.get('O', ''),
            'steps': [{
                'step': cells.get('Q', ''),
                'testdata': cells.get('R', ''),
                'expected': cells.get('S', ''),
            }],
            'plain_text': cells.get('T', ''),
            'bdd': cells.get('U', ''),
        })
    return cases


def _parse_multiline(data_rows, shared):
    """Parse multi-row format: first row has metadata + first step, continuation rows have steps."""
    cases = []
    current = None

    for row_elem in data_rows:
        cells = _build_cell_dict(row_elem, shared)
        if is_row_empty(cells):
            continue

        key = cells.get('A', '').strip()

        if key:
            if current:
                cases.append(current)
            current = {
                'key': key,
                'name': cells.get('B', ''),
                'status': cells.get('C', ''),
                'precondition': cells.get('D', ''),
                'objective': cells.get('E', ''),
                'folder': cells.get('F', ''),
                'priority': cells.get('G', ''),
                'labels': cells.get('I', ''),
                'owner': cells.get('J', ''),
                'coverage': cells.get('L', ''),
                'checker': cells.get('P', ''),
                'checker_2': cells.get('O', ''),
                'steps': [],
                'plain_text': cells.get('T', ''),
                'bdd': cells.get('U', ''),
            }
            step = cells.get('Q', '').strip()
            if step:
                current['steps'].append({
                    'step': step,
                    'testdata': cells.get('R', ''),
                    'expected': cells.get('S', '').strip(),
                })
        elif current:
            step = cells.get('Q', '').strip()
            testdata = cells.get('R', '')
            expected = cells.get('S', '').strip()
            if step or testdata or expected:
                current['steps'].append({
                    'step': step,
                    'testdata': testdata,
                    'expected': expected,
                })

    if current:
        cases.append(current)
    return cases


def extract_fs_text(docx_path, section_id=None):
    if not os.path.exists(docx_path):
        print(f"File not found: {docx_path}", file=sys.stderr)
        sys.exit(1)
    try:
        with zipfile.ZipFile(docx_path, 'r') as zf:
            with zf.open('word/document.xml') as f:
                content = f.read().decode('utf-8')
        texts = re.findall(r'<w:t[^>]*>([^<]*)</w:t>', content)
        full_text = '\n'.join(texts)
        if section_id:
            pattern = re.escape(section_id)
            match = re.search(pattern, full_text)
            if match:
                start = match.start()
                next_match = re.search(r'#FS\d+_[A-Z09_]+', full_text[start + len(section_id):])
                end = start + len(section_id) + next_match.start() if next_match else start + 5000
                return {'section_id': section_id, 'content': full_text[start:end], 'full_text': full_text}
            else:
                return {'content': full_text[:5000], 'full_text': full_text}
        return {'content': full_text[:10000], 'full_text': full_text}
    except zipfile.BadZipFile:
        print(f"Not a valid .docx file: {docx_path}", file=sys.stderr)
        sys.exit(1)


def search_fs(docx_path, keyword):
    if not os.path.exists(docx_path):
        print(f"File not found: {docx_path}", file=sys.stderr)
        sys.exit(1)
    try:
        with zipfile.ZipFile(docx_path, 'r') as zf:
            with zf.open('word/document.xml') as f:
                content = f.read().decode('utf-8')
        texts = re.findall(r'<w:t[^>]*>([^<]*)</w:t>', content)
        full_text = '\n'.join(texts)
        matches = []
        for m in re.finditer(re.escape(keyword), full_text, re.IGNORECASE):
            start = max(0, m.start() - 200)
            end = min(len(full_text), m.end() + 800)
            matches.append({'position': m.start(), 'context': full_text[start:end], 'matched_text': m.group()})
        return {'keyword': keyword, 'matches': matches[:10], 'total_matches': len(matches)}
    except zipfile.BadZipFile:
        print(f"Not a valid .docx file: {docx_path}", file=sys.stderr)
        sys.exit(1)


def list_excel_rows(filepath):
    cases = read_all_test_cases(filepath)
    return [{'row': i + 1, 'key': c['key'], 'name': c['name'], 'status': c['status']} for i, c in enumerate(cases)]


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)

    if sys.argv[1] == '--fs':
        if len(sys.argv) < 3:
            print("Usage: python3 parse_excel.py --fs <docx_path> [section_id]")
            sys.exit(1)
        result = extract_fs_text(sys.argv[2], sys.argv[3] if len(sys.argv) > 3 else None)
        if 'full_text' in result:
            del result['full_text']
        print(json.dumps(result, ensure_ascii=False, indent=2))

    elif sys.argv[1] == '--fs-search':
        if len(sys.argv) < 4:
            print("Usage: python3 parse_excel.py --fs-search <docx_path> <keyword>")
            sys.exit(1)
        result = search_fs(sys.argv[2], sys.argv[3])
        print(json.dumps(result, ensure_ascii=False, indent=2))

    elif sys.argv[1] == '--list':
        if len(sys.argv) < 3:
            print("Usage: python3 parse_excel.py --list <excel_path>")
            sys.exit(1)
        cases = list_excel_rows(sys.argv[2])
        print(json.dumps(cases, ensure_ascii=False, indent=2))

    elif sys.argv[1] == '--all':
        if len(sys.argv) < 3:
            print("Usage: python3 parse_excel.py --all <excel_path>")
            sys.exit(1)
        cases = read_all_test_cases(sys.argv[2])
        print(json.dumps(cases, ensure_ascii=False, indent=2))

    elif sys.argv[1] == '--yaml':
        if len(sys.argv) < 3:
            print("Usage: python3 parse_excel.py --yaml <excel_or_tsv_path>")
            sys.exit(1)
        cases = read_all_test_cases(sys.argv[2])
        print(cases_to_yaml(cases), end='')

    else:
        filepath = sys.argv[1]
        row_num = int(sys.argv[2]) if len(sys.argv) > 2 else 1
        result = read_excel(filepath, row_num)
        print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
