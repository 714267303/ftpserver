# UAT Step Index

This file combines the Ruby step snapshot with any available target
checkout sources.  It is a routing index, not an implementation copy.
Runtime source and installed gem versions remain the executable authority.

## Provenance

- Schema: `1`
- Snapshot SHA-256: `f3ea263b2506f8fd41f0181d604c6858235e8ea10017236d84a00c4bd68d58fd`
- Unique signatures: `257`
- Raw definitions: `514`
- Runtime-source definitions: `257`
- Runtime-source files: `23`
- External runtime: `/usr/local/share/gems/gems/wabi-web-*/` (optional; resolve at execution time)

## External Runtime Resolution

## Target Checkout Resolution

- Root: `features/customized_steps`
- Status: `found`
- Files: `23`

- Status: `not_found`
- Glob: `/usr/local/share/gems/gems/wabi-web-*`
- Candidates: `0`

## Related Snapshots

These files are intentionally not merged into the executable step list:

| File | Role | Authority |
|---|---|---|
| `uat/uat_tool.txt` | Batch/split orchestration snapshot | evidence only; inspect the live tool before execution |
| `uat/uat_admin_feature.txt` | Real Feature-flow corpus | evidence; route through `Feature_Flow_Index.md` |
| `pageExplore/evidence/page_explore.txt` | Playwright exploration guidance | evidence; use maintained sitemap/Grid guide |

## Authority and Loading

| Library | Source | Authority | Load rule |
|---|---|---|---|
| Admin custom steps | logical files `admin_gui_steps.rb`, `admin_gui_ws_class_steps.rb` inside the snapshot | target-checkout runtime authority; snapshot observed here | load for Admin/Hybrid |
| Trading custom steps | logical file `trading_gui_steps.rb` inside the snapshot | target-checkout runtime authority; snapshot observed here | load for Trading/Hybrid |
| Shared custom steps | logical files `public_steps.rb`, `public_class.rb` inside the snapshot | target-checkout runtime authority; snapshot observed here | load for all GUI channels |
| Binary custom/core steps | logical `binary_steps.rb` + WABI runtime | target-checkout/runtime authority | load for Binary/Hybrid |
| Snapshot | `uat/uat_step.txt` | observed evidence | use to discover candidates; verify against runtime |
| Target checkout | `features/customized_steps/**/*.rb` | executable when present | preferred local authority; pass `--runtime-root` for another checkout |
| wabi-web | `/usr/local/share/gems/gems/wabi-web-*/` | external runtime | inspect installed version at run time; never guess API |

## Signature Counts

| Source kind | Definitions | Unique signatures |
|---|---:|---:|
| `admin_gui` | 154 | 77 |
| `binary_or_core` | 14 | 7 |
| `other` | 26 | 13 |
| `shared_public` | 72 | 36 |
| `simulator` | 36 | 18 |
| `trading_gui` | 212 | 106 |

## High-Value Admin Vocabulary

These signatures are the preferred targets for the Admin converter.
The complete machine-readable list is in `Step_Index.json`.

| Intent | Signature fragment |
|---|---|
| login | `Login Trading Admin with:` |
| navigation | `Select Trading Admin Left Menu "..."` |
| search | `Search in Trading Admin "..." page with:` |
| form | `Set Trading Admin "..." info as:` |
| detail | `Double click table "..." column "..." with:` |
| table assertion | `Check table "..." contains ...` |
| sub-table add | `Add Table Item in "..." info popup page with:` |
| sub-table update | `Modify Table Item in "..." info popup page with:` |
| effective type | `Select effective type "..." in detail info page ...` |
| countersign | `Click button "Approve|Reject" ...` |
| WebSocket setup | `CONNECT WS with:` / `add new ... with user ...` |

## Converter Policy

1. Select the runtime channel (`admin`, `binary`, or `hybrid`) before loading steps.
2. Match an emitted line to an exact signature in this index or the selected runtime library.
3. Treat `snapshot_observed` and inferred mappings as draft-only; add `@REVIEW` until replayed.
4. Do not emit raw JavaScript or a raw Playwright locator as a Feature step.
5. Preserve unknown actions in a review report rather than silently dropping them.

## Machine-Readable Source

`Step_Index.json` contains every normalized signature, argument count, source line, and evidence reference.
