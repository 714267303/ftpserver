# FIXODPMSG Enum and Message Index

This index is generated from the XML dictionary.  The XML remains the
authority; `meaning` values are readability hints derived from the
exact enum `description`.  Do not use this file to invent values absent
from the dictionary.

## Source

- Path: `/home/weipeng/hkcode/wabi-fix-4.7.5.9.9.2/etc/FIXODPMSG.xml`
- SHA-256: `6bf7924af5cd61955f80fcdfb39a981afe26a6c8096cd1e8b3bd596a6fea2301`
- Version: `FIX 5.0 SP2`
- Messages: `64`
- Components: `8`
- Fields: `189`
- Enum fields: `54`
- Enum values: `142`

## Enum Values

The wire `value` and XML `description` are retained exactly.  A field
may reuse a numeric value with a different meaning, so look up by
`field + value`, never by value alone.

| Field | Number | Type | Wire value | XML description | Meaning hint | Used by |
|---|---:|---|---|---|---|---|
| `Side` | `203` | `UINT8` | `1` | BUY | Buy | ErrorTradeClaimAck, ErrorTradeClaimNotification, ErrorTradeClaimRequest, ErrorTradeClaimStatusReport, ExchangeOnBehalfTrade, MassOrderCancelReport, ... |
| `Side` | `203` | `UINT8` | `2` | SELL | Sell | ErrorTradeClaimAck, ErrorTradeClaimNotification, ErrorTradeClaimRequest, ErrorTradeClaimStatusReport, ExchangeOnBehalfTrade, MassOrderCancelReport, ... |
| `OrderType` | `204` | `UINT8` | `2` | LIMIT | Limit | NewOrderSingle, OrderAccepted, OrderAmended, OrderExecuted, OrderRestated |
| `OrderType` | `204` | `UINT8` | `3` | MARKET_TO_LIMIT | Market To Limit | NewOrderSingle, OrderAccepted, OrderAmended, OrderExecuted, OrderRestated |
| `TimeInForce` | `207` | `UINT8` | `0` | DAY | Day | NewOrderSingle, OrderAccepted, OrderAmendRequest, OrderAmended, OrderExecuted, OrderRestated |
| `TimeInForce` | `207` | `UINT8` | `1` | GOOD_TILL_CANCELLED | Good Till Cancelled | NewOrderSingle, OrderAccepted, OrderAmendRequest, OrderAmended, OrderExecuted, OrderRestated |
| `TimeInForce` | `207` | `UINT8` | `3` | IMMEDIATE_OR_CANCEL | Immediate Or Cancel | NewOrderSingle, OrderAccepted, OrderAmendRequest, OrderAmended, OrderExecuted, OrderRestated |
| `TimeInForce` | `207` | `UINT8` | `4` | FILL_OR_KILL | Fill Or Kill | NewOrderSingle, OrderAccepted, OrderAmendRequest, OrderAmended, OrderExecuted, OrderRestated |
| `TimeInForce` | `207` | `UINT8` | `6` | GOOD_TILL_DATE | Good Till Date | NewOrderSingle, OrderAccepted, OrderAmendRequest, OrderAmended, OrderExecuted, OrderRestated |
| `TimeInForce` | `207` | `UINT8` | `9` | AT_CROSSING | At Crossing | NewOrderSingle, OrderAccepted, OrderAmendRequest, OrderAmended, OrderExecuted, OrderRestated |
| `PositionEffect` | `210` | `TEXT` | `O` | OPEN | Open | BlockTradeLegMatched, ExchangeOnBehalfTrade, NewOrderSingle, OnePartyBlockTradeAck, OnePartyBlockTradeConfirmed, OnePartyBlockTradeRequest, ... |
| `PositionEffect` | `210` | `TEXT` | `C` | CLOSE | Close | BlockTradeLegMatched, ExchangeOnBehalfTrade, NewOrderSingle, OnePartyBlockTradeAck, OnePartyBlockTradeConfirmed, OnePartyBlockTradeRequest, ... |
| `AHTIndicator` | `217` | `UINT8` | `0` | NON_AHT_ORDER | Non Aht Order | NewOrderSingle, OrderAccepted, OrderAmended, OrderRestated |
| `AHTIndicator` | `217` | `UINT8` | `1` | AHT_ORDER | Aht Order | NewOrderSingle, OrderAccepted, OrderAmended, OrderRestated |
| `OrderStatus` | `221` | `UINT8` | `0` | NEW | New | OrderAmendRejected, OrderAmended, OrderCancelRejected, OrderDoneforDay, OrderExecuted, OrderRestated |
| `OrderStatus` | `221` | `UINT8` | `1` | PARTIALLY_FILLED | Partially Filled | OrderAmendRejected, OrderAmended, OrderCancelRejected, OrderDoneforDay, OrderExecuted, OrderRestated |
| `OrderStatus` | `221` | `UINT8` | `2` | FILLED | Filled | OrderAmendRejected, OrderAmended, OrderCancelRejected, OrderDoneforDay, OrderExecuted, OrderRestated |
| `OrderStatus` | `221` | `UINT8` | `3` | DONE_FOR_DAY | Done For Day | OrderAmendRejected, OrderAmended, OrderCancelRejected, OrderDoneforDay, OrderExecuted, OrderRestated |
| `OrderStatus` | `221` | `UINT8` | `4` | CANCELLED | Cancelled | OrderAmendRejected, OrderAmended, OrderCancelRejected, OrderDoneforDay, OrderExecuted, OrderRestated |
| `OrderStatus` | `221` | `UINT8` | `6` | PENDING_CANCEL | Pending Cancel | OrderAmendRejected, OrderAmended, OrderCancelRejected, OrderDoneforDay, OrderExecuted, OrderRestated |
| `OrderStatus` | `221` | `UINT8` | `8` | REJECTED | Rejected | OrderAmendRejected, OrderAmended, OrderCancelRejected, OrderDoneforDay, OrderExecuted, OrderRestated |
| `OrderStatus` | `221` | `UINT8` | `9` | SUSPENDED | Suspended | OrderAmendRejected, OrderAmended, OrderCancelRejected, OrderDoneforDay, OrderExecuted, OrderRestated |
| `OrderStatus` | `221` | `UINT8` | `10` | PENDING_NEW | Pending New | OrderAmendRejected, OrderAmended, OrderCancelRejected, OrderDoneforDay, OrderExecuted, OrderRestated |
| `OrderStatus` | `221` | `UINT8` | `12` | EXPIRED | Expired | OrderAmendRejected, OrderAmended, OrderCancelRejected, OrderDoneforDay, OrderExecuted, OrderRestated |
| `OrderStatus` | `221` | `UINT8` | `14` | PENDING_AMEND | Pending Amend | OrderAmendRejected, OrderAmended, OrderCancelRejected, OrderDoneforDay, OrderExecuted, OrderRestated |
| `AggressorIndicator` | `233` | `UINT8` | `0` | PASSIVE | Passive | OrderExecuted |
| `AggressorIndicator` | `233` | `UINT8` | `1` | AGGRESSOR | Aggressor | OrderExecuted |
| `TradeConfirmationIndicator` | `234` | `TEXT` | `P` | PROVISIONAL_TRADE | Provisional Trade | BlockTradeLegMatched, ExchangeOnBehalfTrade, OrderExecuted, TradeAdjusted, TradeCancelled, TradePartiallyCancelled |
| `TradeConfirmationIndicator` | `234` | `TEXT` | `F` | FIRM_TRADE | Firm Trade | BlockTradeLegMatched, ExchangeOnBehalfTrade, OrderExecuted, TradeAdjusted, TradeCancelled, TradePartiallyCancelled |
| `OrderAttributeFlags` | `236` | `UINT8` | `0` | COD_INDICATOR_NO | Cod Indicator No | NewOrderSingle, OrderAccepted, OrderAmendRequest, OrderAmended, OrderRestated |
| `OrderAttributeFlags` | `236` | `UINT8` | `1` | COD_INDICATOR_YES | Cod Indicator Yes | NewOrderSingle, OrderAccepted, OrderAmendRequest, OrderAmended, OrderRestated |
| `ExecRestatementReason` | `238` | `UINT8` | `1` | GTD_GTC_RELOADED | Gtd Gtc Reloaded | OrderRestated |
| `ExecRestatementReason` | `238` | `UINT8` | `101` | MARKET_TO_LIMIT_CONVERTED_TO_LIMIT_WITH_PRICE_ASSIGNED | Market To Limit Converted To Limit With Price Assigned | OrderRestated |
| `ExecRestatementReason` | `238` | `UINT8` | `102` | NON_AHT_GTD_ORDER_SUSPENDED_BEFORE_AHT_SESSION | Non Aht Gtd Order Suspended Before Aht Session | OrderRestated |
| `TradeType` | `239` | `UINT8` | `0` | T_TRADE | T Trade | BlockTradeLegMatched, ExchangeOnBehalfTrade, OrderExecuted |
| `TradeType` | `239` | `UINT8` | `10` | T_PLUS_1_AHT_TRADE | T Plus 1 Aht Trade | BlockTradeLegMatched, ExchangeOnBehalfTrade, OrderExecuted |
| `MatchType` | `240` | `UINT8` | `4` | AUTO_MATCH | Auto Match | OrderExecuted |
| `MatchType` | `240` | `UINT8` | `5` | CROSS_AUCTION | Cross Auction | OrderExecuted |
| `LegSide` | `244` | `UINT8` | `1` | BUY | Buy | BlockTradeLegMatched, OrderExecuted, TradeAdjusted |
| `LegSide` | `244` | `UINT8` | `2` | SELL | Sell | BlockTradeLegMatched, OrderExecuted, TradeAdjusted |
| `UserRequestType` | `250` | `UINT8` | `5` | REQUEST_THROTTLE_LIMIT | Request Throttle Limit | ThrottleRequest, ThrottleResponse |
| `ThrottleAction` | `251` | `UINT8` | `2` | REJECTED | Rejected | ThrottleResponse |
| `ThrottleType` | `252` | `UINT8` | `0` | INBOUND_RATE | Inbound Rate | ThrottleResponse |
| `ThrottleTimeUnit` | `255` | `UINT8` | `0` | SECONDS | Seconds | ThrottleResponse |
| `OrderCancelReason` | `256` | `UINT16` | `2500` | CANCELLED_BY_ORDER_CANCEL_REQUEST | Cancelled By Order Cancel Request | OrderCancelled |
| `OrderCancelReason` | `256` | `UINT16` | `2501` | CANCELLED_BY_MASS_ORDER_CANCEL_REQUEST | Cancelled By Mass Order Cancel Request | OrderCancelled |
| `OrderCancelReason` | `256` | `UINT16` | `2502` | QUOTE_CANCELLED_DUE_TO_QUOTE_AMEND | Quote Cancelled Due To Quote Amend | OrderCancelled |
| `OrderCancelReason` | `256` | `UINT16` | `2503` | QUOTE_CANCELLED_DUE_TO_QUOTE_CANCEL_ACTION | Quote Cancelled Due To Quote Cancel Action | OrderCancelled |
| `QuoteAttributeFlags` | `257` | `UINT8` | `0` | CANCEL_ON_MMP_TRIGGERED_NO | Cancel On Mmp Triggered No | OrderAccepted |
| `QuoteAttributeFlags` | `257` | `UINT8` | `1` | CANCEL_ON_MMP_TRIGGERED_YES | Cancel On Mmp Triggered Yes | OrderAccepted |
| `MassOrderCancelScope` | `259` | `UINT8` | `1` | CANCEL_ORDERS_ONLY | Cancel Orders Only | MassOrderCancelReport, MassOrderCancelRequest, OboMassOrderCancelReport, OboMassOrderCancelRequest |
| `MassOrderCancelScope` | `259` | `UINT8` | `2` | CANCEL_QUOTES_ONLY | Cancel Quotes Only | MassOrderCancelReport, MassOrderCancelRequest, OboMassOrderCancelReport, OboMassOrderCancelRequest |
| `MassOrderCancelScope` | `259` | `UINT8` | `3` | CANCEL_ORDERS_AND_QUOTES | Cancel Orders And Quotes | MassOrderCancelReport, MassOrderCancelRequest, OboMassOrderCancelReport, OboMassOrderCancelRequest |
| `MassOrderCancelRequestType` | `260` | `UINT8` | `1` | CANCEL_FOR_SECURITY | Cancel For Security | MassOrderCancelRequest, OboMassOrderCancelRequest |
| `MassOrderCancelRequestType` | `260` | `UINT8` | `2` | CANCEL_FOR_UNDERLYING | Cancel For Underlying | MassOrderCancelRequest, OboMassOrderCancelRequest |
| `MassOrderCancelRequestType` | `260` | `UINT8` | `5` | CANCEL_FOR_INSTRUMENT_OR_COMBO_TYPE | Cancel For Instrument Or Combo Type | MassOrderCancelRequest, OboMassOrderCancelRequest |
| `MassOrderCancelRequestType` | `260` | `UINT8` | `7` | CANCEL_ALL | Cancel All | MassOrderCancelRequest, OboMassOrderCancelRequest |
| `MassOrderCancelRequestType` | `260` | `UINT8` | `8` | CANCEL_FOR_MARKET | Cancel For Market | MassOrderCancelRequest, OboMassOrderCancelRequest |
| `MassOrderCancelRequestType` | `260` | `UINT8` | `10` | CANCEL_FOR_INSTRUMENT_OR_COMBO_CLASS | Cancel For Instrument Or Combo Class | MassOrderCancelRequest, OboMassOrderCancelRequest |
| `MassOrderCancelResponse` | `265` | `UINT8` | `0` | CANCEL_REQUEST_REJECTED | Cancel Request Rejected | MassOrderCancelReport, OboMassOrderCancelReport |
| `MassOrderCancelResponse` | `265` | `UINT8` | `1` | CANCEL_FOR_SECURITY | Cancel For Security | MassOrderCancelReport, OboMassOrderCancelReport |
| `MassOrderCancelResponse` | `265` | `UINT8` | `2` | CANCEL_FOR_UNDERLYING | Cancel For Underlying | MassOrderCancelReport, OboMassOrderCancelReport |
| `MassOrderCancelResponse` | `265` | `UINT8` | `5` | CANCEL_FOR_INSTRUMENT_OR_COMBO_TYPE | Cancel For Instrument Or Combo Type | MassOrderCancelReport, OboMassOrderCancelReport |
| `MassOrderCancelResponse` | `265` | `UINT8` | `7` | CANCEL_ALL | Cancel All | MassOrderCancelReport, OboMassOrderCancelReport |
| `MassOrderCancelResponse` | `265` | `UINT8` | `8` | CANCEL_FOR_MARKET | Cancel For Market | MassOrderCancelReport, OboMassOrderCancelReport |
| `MassOrderCancelResponse` | `265` | `UINT8` | `10` | CANCEL_FOR_INSTRUMENT_OR_COMBO_CLASS | Cancel For Instrument Or Combo Class | MassOrderCancelReport, OboMassOrderCancelReport |
| `TradeCancelReason` | `267` | `UINT16` | `1` | ERROR_TRADE_APPROVED_BY_BOTH_EPS | Error Trade Approved By Both Eps | TradeCancelled, TradePartiallyCancelled |
| `TradeCancelReason` | `267` | `UINT16` | `2` | ERROR_TRADE_APPROVED_BY_COMMITTEE | Error Trade Approved By Committee | TradeCancelled, TradePartiallyCancelled |
| `TradeCancelReason` | `267` | `UINT16` | `3` | INVALID_BLOCK_TRADE | Invalid Block Trade | TradeCancelled, TradePartiallyCancelled |
| `TradeCancelReason` | `267` | `UINT16` | `99` | OTHER | Other | TradeCancelled, TradePartiallyCancelled |
| `OBOCancelStatus` | `272` | `UINT8` | `0` | ACCEPTED | Accepted | OboSingelOrderCancelAck |
| `OBOCancelStatus` | `272` | `UINT8` | `1` | REJECTED | Rejected | OboSingelOrderCancelAck |
| `AggregatedTrade` | `273` | `UINT8` | `0` | NO | No | BlockTradeLegMatched, OnePartyBlockTradeAck, OnePartyBlockTradeConfirmed, OnePartyBlockTradeRequest, TwoPartyBlockTradeAck, TwoPartyBlockTradeRequest |
| `AggregatedTrade` | `273` | `UINT8` | `1` | YES | Yes | BlockTradeLegMatched, OnePartyBlockTradeAck, OnePartyBlockTradeConfirmed, OnePartyBlockTradeRequest, TwoPartyBlockTradeAck, TwoPartyBlockTradeRequest |
| `BlockTradeLegSide` | `284` | `UINT8` | `1` | BUY | Buy | BlockTradeLegMatched, OnePartyBlockTradeAck, OnePartyBlockTradeConfirmed, OnePartyBlockTradeRequest, OnePartyBlockTradeSubmissionNotification |
| `BlockTradeLegSide` | `284` | `UINT8` | `2` | SELL | Sell | BlockTradeLegMatched, OnePartyBlockTradeAck, OnePartyBlockTradeConfirmed, OnePartyBlockTradeRequest, OnePartyBlockTradeSubmissionNotification |
| `BlockTradeType` | `285` | `UINT8` | `0` | INTERNAL_BLOCK_TRADE | Internal Block Trade | BlockTradeLegMatched |
| `BlockTradeType` | `285` | `UINT8` | `1` | INTERBANK_BLOCK_TRADE | Interbank Block Trade | BlockTradeLegMatched |
| `BuyerPositionEffect` | `295` | `TEXT` | `O` | OPEN | Open | TwoPartyBlockTradeAck, TwoPartyBlockTradeRequest |
| `BuyerPositionEffect` | `295` | `TEXT` | `C` | CLOSE | Close | TwoPartyBlockTradeAck, TwoPartyBlockTradeRequest |
| `EnablePriceWarning` | `302` | `UINT8` | `0` | NO | No | OnePartyBlockTradeRequest, TwoPartyBlockTradeRequest |
| `EnablePriceWarning` | `302` | `UINT8` | `1` | YES | Yes | OnePartyBlockTradeRequest, TwoPartyBlockTradeRequest |
| `ErrorTradeClaimStatus` | `306` | `UINT8` | `0` | REQUEST_RECEIVED | Request Received | ErrorTradeClaimAck, ErrorTradeClaimContraSideConsentAck, ErrorTradeClaimStatusReport |
| `ErrorTradeClaimStatus` | `306` | `UINT8` | `1` | REQUEST_REJECTED | Request Rejected | ErrorTradeClaimAck, ErrorTradeClaimContraSideConsentAck, ErrorTradeClaimStatusReport |
| `ErrorTradeClaimStatus` | `306` | `UINT8` | `2` | REGISTRATION_ACCEPTED | Registration Accepted | ErrorTradeClaimAck, ErrorTradeClaimContraSideConsentAck, ErrorTradeClaimStatusReport |
| `ErrorTradeClaimStatus` | `306` | `UINT8` | `3` | REGISTRATION_REJECTED | Registration Rejected | ErrorTradeClaimAck, ErrorTradeClaimContraSideConsentAck, ErrorTradeClaimStatusReport |
| `ErrorTradeClaimStatus` | `306` | `UINT8` | `4` | CLAIM_APPROVED | Claim Approved | ErrorTradeClaimAck, ErrorTradeClaimContraSideConsentAck, ErrorTradeClaimStatusReport |
| `ErrorTradeClaimStatus` | `306` | `UINT8` | `5` | CLAIM_REJECTED | Claim Rejected | ErrorTradeClaimAck, ErrorTradeClaimContraSideConsentAck, ErrorTradeClaimStatusReport |
| `IncludeFutures` | `312` | `UINT8` | `0` | NO | No | MmpParametersAck, MmpParametersUpdateRequest |
| `IncludeFutures` | `312` | `UINT8` | `1` | YES | Yes | MmpParametersAck, MmpParametersUpdateRequest |
| `KillSwitchAction` | `315` | `UINT8` | `1` | APPLY_KILL_SWITCH | Apply Kill Switch | KillSwitchAck, KillSwitchRequest |
| `KillSwitchAction` | `315` | `UINT8` | `2` | RESUME_FROM_KILL_SWITCH | Resume From Kill Switch | KillSwitchAck, KillSwitchRequest |
| `KillSwitchStatus` | `318` | `UINT8` | `0` | ACCEPTED | Accepted | KillSwitchAck |
| `KillSwitchStatus` | `318` | `UINT8` | `1` | REJECTED | Rejected | KillSwitchAck |
| `LegOperation` | `319` | `UINT8` | `1` | BUY | Buy | SecurityDefinition, SecurityDefinitionRequest |
| `LegOperation` | `319` | `UINT8` | `2` | SELL | Sell | SecurityDefinition, SecurityDefinitionRequest |
| `LookupRejectReason` | `324` | `UINT16` | `0` | INVALID_COMPID_OR_INVALID_IP_ADDRESS | Invalid Compid Or Invalid Ip Address | LookupResponse |
| `LookupRejectReason` | `324` | `UINT16` | `1` | CLIENT_IS_BLOCKED | Client Is Blocked | LookupResponse |
| `LookupStatus` | `325` | `UINT8` | `0` | ACCEPTED | Accepted | LookupResponse |
| `LookupStatus` | `325` | `UINT8` | `1` | REJECTED | Rejected | LookupResponse |
| `MessagePriority` | `326` | `UINT8` | `0` | CRITICAL | Critical | News |
| `MessagePriority` | `326` | `UINT8` | `1` | IMPORTANT | Important | News |
| `MessagePriority` | `326` | `UINT8` | `2` | NORMAL | Normal | News |
| `MMPParametersStatus` | `329` | `UINT8` | `0` | ACCEPTED | Accepted | MmpParametersAck |
| `MMPParametersStatus` | `329` | `UINT8` | `1` | REJECTED | Rejected | MmpParametersAck |
| `MMPReleaseStatus` | `332` | `UINT8` | `0` | ACCEPTED | Accepted | MmpReleaseAck |
| `MMPReleaseStatus` | `332` | `UINT8` | `1` | REJECTED | Rejected | MmpReleaseAck |
| `MMPReleaseType` | `333` | `UINT8` | `1` | RELEASE_MMP_FROZEN_PERIOD | Release Mmp Frozen Period | MmpReleaseAck, MmpReleaseRequest |
| `MMPParametersResponseType` | `335` | `UINT8` | `1` | ENQUIRE_MMP_PARAMETERS | Enquire Mmp Parameters | MmpParametersAck |
| `MMPParametersResponseType` | `335` | `UINT8` | `2` | UPDATE_MMP_PARAMETERS | Update Mmp Parameters | MmpParametersAck |
| `PendingTradeCancelReason` | `349` | `UINT16` | `1` | INTERBANK_BLOCK_TRADE_CANCELLED_BY_ORIGINATOR | Interbank Block Trade Cancelled By Originator | OnePartyBlockTradeCancellationNotification |
| `PendingTradeCancelReason` | `349` | `UINT16` | `2` | INTERBANK_BLOCK_TRADE_DECLINED_BY_COUNTERPARTY | Interbank Block Trade Declined By Counterparty | OnePartyBlockTradeCancellationNotification |
| `QuoteRequestStatus` | `359` | `UINT8` | `0` | ACCEPTED | Accepted | QuoteRequestAck |
| `QuoteRequestStatus` | `359` | `UINT8` | `1` | REJECTED | Rejected | QuoteRequestAck |
| `ResponseAction` | `367` | `UINT8` | `0` | ACCEPT | Accept | ErrorTradeClaimContraSideConsentAck, ErrorTradeClaimContraSideConsentRequest |
| `ResponseAction` | `367` | `UINT8` | `1` | DECLINE | Decline | ErrorTradeClaimContraSideConsentAck, ErrorTradeClaimContraSideConsentRequest |
| `SecurityResponseType` | `372` | `UINT8` | `1` | ACCEPT_SECURITY_PROPOSAL | Accept Security Proposal | SecurityDefinition |
| `SecurityResponseType` | `372` | `UINT8` | `2` | ACCEPT_SECURITY_PROPOSAL_WITH_REVISIONS | Accept Security Proposal With Revisions | SecurityDefinition |
| `SecurityResponseType` | `372` | `UINT8` | `5` | REJECT_SECURITY_PROPOSAL | Reject Security Proposal | SecurityDefinition |
| `SellerPositionEffect` | `379` | `TEXT` | `O` | OPEN | Open | TwoPartyBlockTradeAck, TwoPartyBlockTradeRequest |
| `SellerPositionEffect` | `379` | `TEXT` | `C` | CLOSE | Close | TwoPartyBlockTradeAck, TwoPartyBlockTradeRequest |
| `SpecialIndicator` | `382` | `UINT8` | `1` | BTIC | Btic | BlockTradeLegMatched, OnePartyBlockTradeAck, OnePartyBlockTradeConfirmed, OnePartyBlockTradeRequest, TwoPartyBlockTradeAck, TwoPartyBlockTradeRequest |
| `SpecialIndicator` | `382` | `UINT8` | `2` | PPR2 | Ppr2 | BlockTradeLegMatched, OnePartyBlockTradeAck, OnePartyBlockTradeConfirmed, OnePartyBlockTradeRequest, TwoPartyBlockTradeAck, TwoPartyBlockTradeRequest |
| `BlockTradeStatus` | `390` | `UINT8` | `0` | ACCEPTED | Accepted | OnePartyBlockTradeAck, OnePartyBlockTradeCancelAck, OnePartyBlockTradeDeclineAck, TwoPartyBlockTradeAck |
| `BlockTradeStatus` | `390` | `UINT8` | `1` | REJECTED | Rejected | OnePartyBlockTradeAck, OnePartyBlockTradeCancelAck, OnePartyBlockTradeDeclineAck, TwoPartyBlockTradeAck |
| `BlockTradeStatus` | `390` | `UINT8` | `2` | CANCELLED | Cancelled | OnePartyBlockTradeAck, OnePartyBlockTradeCancelAck, OnePartyBlockTradeDeclineAck, TwoPartyBlockTradeAck |
| `BlockTradeStatus` | `390` | `UINT8` | `3` | CONFIRMED | Confirmed | OnePartyBlockTradeAck, OnePartyBlockTradeCancelAck, OnePartyBlockTradeDeclineAck, TwoPartyBlockTradeAck |
| `BlockTradeStatus` | `390` | `UINT8` | `4` | DECLINED | Declined | OnePartyBlockTradeAck, OnePartyBlockTradeCancelAck, OnePartyBlockTradeDeclineAck, TwoPartyBlockTradeAck |
| `TradeSubType` | `399` | `UINT16` | `1` | MATCHES_OUTRIGHT_EXPLICIT_ORDER | Matches Outright Explicit Order | OrderExecuted |
| `TradeSubType` | `399` | `UINT16` | `2` | MATCHES_IMPLIED_ORDER | Matches Implied Order | OrderExecuted |
| `OfferQuoteAttributeFlags` | `400` | `UINT8` | `0` | CANCEL_ON_MMP_TRIGGERED_NO | Cancel On Mmp Triggered No | MassQuote, SingleQuote |
| `OfferQuoteAttributeFlags` | `400` | `UINT8` | `1` | CANCEL_ON_MMP_TRIGGERED_YES | Cancel On Mmp Triggered Yes | MassQuote, SingleQuote |
| `CancelHintMode` | `405` | `UINT8` | `0` | RANGE_MATCHING | Range Matching | MassOrderCancelReport, MassOrderCancelRequest, OboMassOrderCancelReport, OboMassOrderCancelRequest |
| `CancelHintMode` | `405` | `UINT8` | `1` | BITWISE_AND_MATCHING | Bitwise And Matching | MassOrderCancelReport, MassOrderCancelRequest, OboMassOrderCancelReport, OboMassOrderCancelRequest |
| `BidQuoteAttributeFlags` | `413` | `UINT8` | `0` | CANCEL_ON_MMP_TRIGGERED_NO | Cancel On Mmp Triggered No | MassQuote, SingleQuote |
| `BidQuoteAttributeFlags` | `413` | `UINT8` | `1` | CANCEL_ON_MMP_TRIGGERED_YES | Cancel On Mmp Triggered Yes | MassQuote, SingleQuote |
| `SessionCancellationScope` | `415` | `UINT8` | `1` | DESIGNATED_SESSION | Designated Session | OboMassOrderCancelReport, OboMassOrderCancelRequest |
| `SessionCancellationScope` | `415` | `UINT8` | `2` | ALL_SESSIONS_OF_THIS_EP | All Sessions Of This Ep | OboMassOrderCancelReport, OboMassOrderCancelRequest |
| `KillSwitchScope` | `416` | `UINT8` | `1` | THIS_SESSION | This Session | KillSwitchAck, KillSwitchRequest |
| `KillSwitchScope` | `416` | `UINT8` | `2` | DESIGNATED_SESSION | Designated Session | KillSwitchAck, KillSwitchRequest |
| `KillSwitchScope` | `416` | `UINT8` | `3` | ALL_SESSIONS_EXCLUDING_REQUESTING_SESSION | All Sessions Excluding Requesting Session | KillSwitchAck, KillSwitchRequest |
| `KillSwitchScope` | `416` | `UINT8` | `4` | ALL_SESSIONS_INCLUDING_REQUESTING_SESSION | All Sessions Including Requesting Session | KillSwitchAck, KillSwitchRequest |

## Messages

| MsgType | Name | Category | Fields | Components |
|---:|---|---|---|---|
| `9` | `LookupRequest` | `app` | - | - |
| `10` | `LookupResponse` | `app` | LookupStatus, LookupRejectReason, IPAddress1, PortNumber1, IPAddress2, PortNumber2 | - |
| `11` | `ThrottleRequest` | `app` | UserRequestID, UserRequestType | - |
| `12` | `ThrottleResponse` | `app` | UserRequestID, UserRequestType, ThrottleAction, ThrottleType, ThrottleNoMessages, ThrottleTimeInterval, ThrottleTimeUnit | - |
| `21` | `NewOrderSingle` | `app` | ClientOrderID, TransactionTime, SecurityID, Side, OrderType, OrderQty, OrderPrice, BCANField, TimeInForce, SMPID, ATID, PositionEffect, GiveUpParticipant, GiveUpInformation, OrderAttributeFlags, ExpireDate, ClearingAccount, CustomerInformation, AHTIndicator, CancelHintValue | - |
| `22` | `OrderAmendRequest` | `app` | ClientOrderID, TransactionTime, SecurityID, Side, OriginalClientOrderID, OrderQty, OrderPrice, TimeInForce, SMPID, PositionEffect, GiveUpParticipant, GiveUpInformation, OrderAttributeFlags, ExpireDate, ClearingAccount, CustomerInformation, CancelHintValue | - |
| `23` | `OrderCancelRequest` | `app` | ClientOrderID, TransactionTime, SecurityID, Side, OriginalClientOrderID | - |
| `24` | `OrderRejected` | `app` | ClientOrderID, TransactionTime, SecurityID, Side, OrderQty, OrderPrice, OrderRejectReason, QuoteEntryID | - |
| `25` | `OrderAmendRejected` | `app` | ClientOrderID, TransactionTime, OrderStatus, AmendRejectReason, OriginalClientOrderID, OrderID | - |
| `26` | `OrderCancelRejected` | `app` | ClientOrderID, TransactionTime, OrderStatus, CancelRejectReason, OriginalClientOrderID, QuoteEntryID, OrderID, SecurityID, Side | - |
| `27` | `OrderAccepted` | `app` | ClientOrderID, TransactionTime, SecurityID, Side, OrderType, OrderQty, OrderPrice, OrderID, ExecutionID, OriginatingSessionID, TimeInForce, QuoteEntryID, SMPID, ATID, PositionEffect, GiveUpParticipant, GiveUpInformation, OrderAttributeFlags, ExpireDate, ClearingAccount, CustomerInformation, AHTIndicator, CancelHintValue, QuoteAttributeFlags | - |
| `28` | `OrderAmended` | `app` | ClientOrderID, TransactionTime, OriginalClientOrderID, SecurityID, Side, OrderType, OrderQty, OrderPrice, OrderID, ExecutionID, OrderStatus, LeavesQty, CumulativeQty, OriginatingSessionID, TimeInForce, SMPID, ATID, PositionEffect, GiveUpParticipant, GiveUpInformation, OrderAttributeFlags, ExpireDate, ClearingAccount, CustomerInformation, AHTIndicator, CancelHintValue | - |
| `29` | `OrderCancelled` | `app` | ClientOrderID, TransactionTime, SecurityID, Side, OrderID, ExecutionID, CumulativeQty, OrderCancelReason, OriginatingSessionID, OriginalClientOrderID, QuoteEntryID | - |
| `30` | `OrderRestated` | `app` | ClientOrderID, TransactionTime, SecurityID, Side, OrderType, OrderQty, OrderPrice, OrderID, ExecutionID, OrderStatus, LeavesQty, CumulativeQty, ExecRestatementReason, OriginatingSessionID, TimeInForce, SMPID, ATID, PositionEffect, GiveUpParticipant, GiveUpInformation, OrderAttributeFlags, ExpireDate, ClearingAccount, CustomerInformation, AHTIndicator, CancelHintValue | - |
| `31` | `OrderExecuted` | `app` | ClientOrderID, TransactionTime, SecurityID, Side, OrderType, OrderQty, OrderPrice, OrderID, ExecutionID, OrderStatus, LeavesQty, CumulativeQty, ExecutionQty, ExecutionPrice, TradeID, TradeDate, TradeType, TradeSubType, MatchType, OriginatingSessionID, QuoteEntryID, TradeConfirmationIndicator, AggressorIndicator, TimeInForce, ATID, PositionEffect, GiveUpParticipant, GiveUpInformation, ExpireDate, ClearingAccount, CustomerInformation | OrderExecutedLegsGrp |
| `32` | `OrderDoneforDay` | `app` | ClientOrderID, TransactionTime, SecurityID, Side, OrderQty, OrderPrice, OrderID, ExecutionID, OrderStatus, LeavesQty, CumulativeQty, OriginatingSessionID | - |
| `81` | `MassOrderCancelRequest` | `app` | ClientOrderID, TransactionTime, MassOrderCancelScope, MassOrderCancelRequestType, MarketSegment, UnderlyingID, InstrumentType, InstrumentClass, SecurityID, Side, ClearingAccount, CancelHintMode, ValueToBeCancelledFrom, ValueToBeCancelledTo, BitsToBeCancelled | - |
| `82` | `MassOrderCancelReport` | `app` | ClientOrderID, TransactionTime, MassOrderCancelScope, MassOrderCancelResponse, TotalNumberOfMEsInvolved, MEID, MassOrderCancelRejectedReason, MarketSegment, UnderlyingID, InstrumentType, InstrumentClass, SecurityID, Side, ClearingAccount, CancelHintMode, ValueToBeCancelledFrom, ValueToBeCancelledTo, BitsToBeCancelled | - |
| `157` | `TradeCancelled` | `app` | TradeID, TransactionTime, SecurityID, Side, ExecutionID, ExecutionQty, ExecutionPrice, TradeCancelReason, OriginatingSessionID, TradeConfirmationIndicator | - |
| `158` | `TradePartiallyCancelled` | `app` | TradeID, TransactionTime, SecurityID, Side, ExecutionID, ExecutionQty, ExecutionPrice, TradeCancelReason, OriginatingSessionID, TradeConfirmationIndicator | - |
| `83` | `OboSingelOrderCancelRequest` | `app` | ClientOrderID, TransactionTime, SecurityID, Side, OrderID | - |
| `84` | `OboSingelOrderCancelAck` | `app` | ClientOrderID, TransactionTime, OrderID, OBOCancelStatus, OBOSingleOrderCancelRejectedReason | - |
| `85` | `OboMassOrderCancelRequest` | `app` | ClientOrderID, TransactionTime, MassOrderCancelScope, MassOrderCancelRequestType, SessionCancellationScope, OwningSessionID, MarketSegment, UnderlyingID, InstrumentType, InstrumentClass, SecurityID, Side, OwningClearingAccount, CancelHintMode, ValueToBeCancelledFrom, ValueToBeCancelledTo, BitsToBeCancelled | - |
| `86` | `OboMassOrderCancelReport` | `app` | ClientOrderID, TransactionTime, MassOrderCancelScope, MassOrderCancelResponse, TotalNumberOfMEsInvolved, MEID, SessionCancellationScope, OwningSessionID, MassOrderCancelRejectedReason, MarketSegment, UnderlyingID, InstrumentType, InstrumentClass, SecurityID, Side, OwningClearingAccount, CancelHintMode, ValueToBeCancelledFrom, ValueToBeCancelledTo, BitsToBeCancelled | - |
| `51` | `MassQuote` | `app` | QuoteID, TransactionTime, BCANField, SMPID, ATID, GiveUpParticipant, GiveUpInformation, ClearingAccount, CustomerInformation, NoQuoteEntries | QuoteEntryRequestBodyFieldsLegsGrp |
| `52` | `MassQuoteAck` | `app` | QuoteID, TransactionTime, QuoteRejectReason | QuoteEntryAckBodyFieldsAckLegsGrp |
| `53` | `SingleQuote` | `app` | QuoteID, TransactionTime, SecurityID, QuoteEntryID, BidPrice, BidQty, OfferPrice, OfferQty, BCANField, SMPID, ATID, GiveUpParticipant, GiveUpInformation, ClearingAccount, CustomerInformation, BidQuoteAttributeFlags, OfferQuoteAttributeFlags, BidCancelHintValue, OfferCancelHintValue | - |
| `54` | `SingleQuoteAck` | `app` | QuoteID, TransactionTime, QuoteRejectReason | - |
| `71` | `QuoteRequest` | `app` | QuoteRequestID, TransactionTime, SecurityID, Side, Qty | - |
| `72` | `QuoteRequestAck` | `app` | QuoteRequestID, TransactionTime, SecurityID, QuoteRequestStatus, Side, Qty, QuoteRequestRejectReason | - |
| `73` | `PublicQuoteRequest` | `app` | SecurityID, TransactionTime, Side, Qty, QuoteRequestOriginatorEPID | - |
| `95` | `KillSwitchRequest` | `app` | KillSwitchRequestID, TransactionTime, KillSwitchScope, KillSwitchAction, TargetSessionID | - |
| `96` | `KillSwitchAck` | `app` | KillSwitchRequestID, TransactionTime, KillSwitchScope, KillSwitchAction, KillSwitchStatus, TargetSessionID, KillSwitchRejectReason | - |
| `101` | `TwoPartyBlockTradeRequest` | `app` | TradeReportID, TransactionTime, AggregatedTrade, BuyerBCANField, SellerBCANField, TradeConclusionDateTime, EnablePriceWarning, SpecialIndicator, BuyerATID, SellerATID, NoBlockTradeLegs | TwoPartyBlockTradeLegBodyFieldsLegsGrp |
| `102` | `TwoPartyBlockTradeAck` | `app` | TradeReportID, TransactionTime, AggregatedTrade, BlockTradeStatus, TradeConclusionDateTime, SpecialIndicator, BuyerATID, SellerATID, TradeRejectReason, PriceWarningFailedLeg, NoBlockTradeLegs | TwoPartyBlockTradeLegBodyFieldsLegsGrp |
| `105` | `OnePartyBlockTradeRequest` | `app` | TradeReportID, TransactionTime, AggregatedTrade, BCANField, TradeConclusionDateTime, CounterpartyEPID, EnablePriceWarning, SpecialIndicator, ATID, NoBlockTradeLegs | OnePartyBlockTradeLegBodyFieldsLegsGrp |
| `106` | `OnePartyBlockTradeAck` | `app` | TradeReportID, TransactionTime, AggregatedTrade, BlockTradeStatus, TradeConclusionDateTime, CounterpartyEPID, SpecialIndicator, ATID, BlockTradeReportID, TradeRejectReason, PriceWarningFailedLeg, NoBlockTradeLegs | OnePartyBlockTradeLegBodyFieldsLegsGrp |
| `107` | `OnePartyBlockTradeConfirmed` | `app` | TradeReportID, TransactionTime, AggregatedTrade, BlockTradeReportID, TradeConclusionDateTime, CounterpartyEPID, SpecialIndicator, ATID, NoBlockTradeLegs | OnePartyBlockTradeLegBodyFieldsLegsGrp |
| `108` | `OnePartyBlockTradeSubmissionNotification` | `app` | BlockTradeReportID, TransactionTime, CounterpartyEPID, NoBlockTradeLegs | BasicBlockTradeLegBodyFieldsLegsGrp |
| `109` | `OnePartyBlockTradeCancelRequest` | `app` | TradeReportID, TransactionTime, BlockTradeReportID | - |
| `110` | `OnePartyBlockTradeCancelAck` | `app` | TradeReportID, TransactionTime, BlockTradeReportID, BlockTradeStatus, TradeReportRefID, TradeRejectReason | - |
| `111` | `OnePartyBlockTradeCancellationNotification` | `app` | BlockTradeReportID, TransactionTime, PendingTradeCancelReason | - |
| `112` | `OnePartyBlockTradeDeclineRequest` | `app` | TradeReportID, TransactionTime, BlockTradeReportID, DeclineReasonText | - |
| `113` | `OnePartyBlockTradeDeclineAck` | `app` | TradeReportID, TransactionTime, BlockTradeReportID, BlockTradeStatus, TradeRejectReason | - |
| `114` | `BlockTradeLegMatched` | `app` | TradeReportID, TransactionTime, AggregatedTrade, BlockTradeLegSecurityID, BlockTradeLegSide, BlockTradeLegExecutionQty, BlockTradeLegExecutionPrice, TradeID, TradeDate, TradeType, BlockTradeType, ExecutionID, OriginatingSessionID, TradeConclusionDateTime, CounterpartyEPID, BlockTradeReportID, SpecialIndicator, ATID, PositionEffect, GiveUpParticipant, GiveUpInformation, ClearingAccount, CustomerInformation, TradeConfirmationIndicator, NoLegs | LegsBodyFieldsLegsGrp |
| `115` | `OnePartyBlockTradeConfirmationNotification` | `app` | BlockTradeReportID, TransactionTime | - |
| `151` | `ErrorTradeClaimRequest` | `app` | TradeReportID, TransactionTime, TradeID, SecurityID, Side, ExecutionQty, ExecutionPrice, ClaimTime | - |
| `152` | `ErrorTradeClaimAck` | `app` | TradeReportID, TransactionTime, TradeID, SecurityID, Side, ExecutionQty, ExecutionPrice, ClaimTime, ErrorTradeClaimStatus, ErrorTradeClaimRejectReason, ErrorTradeClaimID | - |
| `153` | `ErrorTradeClaimNotification` | `app` | ErrorTradeClaimID, TransactionTime, TradeID, SecurityID, Side, ExecutionQty, ExecutionPrice, ClaimTime | - |
| `154` | `ErrorTradeClaimContraSideConsentRequest` | `app` | TradeReportID, TransactionTime, ErrorTradeClaimID, TradeID, SecurityID, ExecutionQty, ExecutionPrice, ResponseAction, DeclineReasonText | - |
| `155` | `ErrorTradeClaimContraSideConsentAck` | `app` | TradeReportID, TransactionTime, ErrorTradeClaimID, TradeID, SecurityID, ExecutionQty, ExecutionPrice, ResponseAction, ErrorTradeClaimStatus, ErrorTradeClaimRejectReason | - |
| `156` | `ErrorTradeClaimStatusReport` | `app` | ErrorTradeClaimID, TransactionTime, TradeID, SecurityID, Side, ExecutionQty, ExecutionPrice, ErrorTradeClaimStatus, ClaimTime, ErrorTradeClaimRejectReason | - |
| `157` | `TradeCancelled` | `app` | TradeID, TransactionTime, SecurityID, Side, ExecutionID, ExecutionQty, ExecutionPrice, TradeCancelReason, TradeConfirmationIndicator | - |
| `160` | `ExchangeOnBehalfTrade` | `app` | TransactionTime, SecurityID, Side, ExecutionID, ExecutionQty, ExecutionPrice, TradeID, TradeType, OriginatingSessionID, TradeConfirmationIndicator, PositionEffect, ClearingAccount, CustomerInformation, ATID | - |
| `165` | `TradeAdjusted` | `app` | TradeID, TransactionTime, SecurityID, Side, ExecutionID, ExecutionQty, ExecutionPrice, OriginatingSessionID, TradeConfirmationIndicator, NoLegs | LegsBodyFieldsLegsGrp |
| `166` | `News` | `app` | NewsID, OriginationTime, MessagePriority, Headline, NewsContent | - |
| `171` | `SecurityDefinitionRequest` | `app` | SecurityRequestID, TransactionTime, NoLegs | SecurityDefinitionLegBodyFieldsLegsGrp |
| `172` | `SecurityDefinition` | `app` | SecurityRequestID, TransactionTime, SecurityResponseID, SecurityResponseType, SecurityRejectReason, SecurityID, NoSecurityDefinitionLegs | SecurityDefinitionLegBodyFieldsLegsGrp |
| `181` | `MmpParametersUpdateRequest` | `app` | MMPRequestID, TransactionTime, UnderlyingID, IncludeFutures, QuantityProtection, DeltaProtection, ExposureTimeLimitInterval, FrozenTime | - |
| `182` | `MmpParametersEnquiry` | `app` | MMPRequestID, TransactionTime, UnderlyingID | - |
| `183` | `MmpParametersAck` | `app` | MMPRequestID, TransactionTime, MMPParametersResponseType, UnderlyingID, MMPParametersStatus, IncludeFutures, QuantityProtection, DeltaProtection, ExposureTimeLimitInterval, FrozenTime, MMPParametersRejectReason | - |
| `184` | `MmpTriggered` | `app` | UnderlyingID, TransactionTime | - |
| `185` | `MmpReleaseRequest` | `app` | MMPRequestID, TransactionTime, MMPReleaseType, UnderlyingID | - |
| `186` | `MmpReleaseAck` | `app` | MMPRequestID, TransactionTime, MMPReleaseType, UnderlyingID, MMPReleaseStatus, MMPReleaseRejectReason | - |

## Header and Trailer

- Header: Length, MessageID, MsgSeqNum, CompID, TargetCompID, BeginString, PossDupFlag, PossResend
- Trailer: SignatureLength, Signature, CheckSum

## Related Dictionaries

The following optional dictionaries were indexed alongside the application dictionary:

- `/home/weipeng/hkcode/wabi-fix-4.7.5.9.9.2/etc/FIXODP.xml` (SHA-256 `a7760b92f5f21ecab8b169e4fa01e37f5b20c2f2382e82f786ada1de1c508fa7`; 99 enum values)
