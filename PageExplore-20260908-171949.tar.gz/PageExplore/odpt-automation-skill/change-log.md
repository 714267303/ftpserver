# Change Log - ODP-T Project Maintenance Skill

This document records changes to the skill files, project logic, conversion rules, and maintenance processes.

## [2026-09-08] Generic Admin Flow Correctness Preflight

### Changed
- Added a deterministic page contract that parses all 96 entries from
  `pageExplore/sitemap.md` and their page profiles. Before an Admin Feature is
  generated, it checks route/profile/label, exact sidebar parent and child,
  per-browser navigation state, Search/table/detail page ownership, and
  profile-backed DataTable fields.
- Uniquely provable menu/profile mistakes are normalized with an audit record.
  Valid-but-ambiguous conflicts, missing navigation, unknown pages, and wrong
  page fields stop before Cucumber instead of being guessed by repair.
- New MCP results must contain a completed Playwright observation of the
  manifest's declared route. Mentioning the route only in a tool input is not
  browser evidence.
- Added `source_coverage`, mapping each Admin YAML TestStep to its implementing
  flow steps and requiring every flow step to be covered. Update intent also
  checks for search, detail open, mutation/submission, effective date,
  deferred approval, and requested postcondition operations.
- Browser-free semantic repair may consult the checked-in human Admin Feature
  corpus as read-only corroboration. PageExplore, Step_Index, and current YAML
  data remain authoritative.
- Missing business behavior is classified as an evidence gap, not a repair
  opportunity. Offline repair cannot add navigation, search, detail, mutation,
  submission, checker, effective-date, or requested verification behavior; a
  fresh rollback-validation MCP run is required.

## [2026-09-08] Cross-Day Hybrid Execution Flow

### Changed
- Hybrid YAML with one next-trading-day batch boundary now produces three
  Features: `<case>.admin.feature`, `<case>-Day1.feature`, and
  `<case>-Day2.feature`. Day1 and Day2 are no longer emitted as one Scenario.
- The batch writes a stateful `<case>.execution-flow.json` declaring `admin ->
  day1 -> night_batch -> day2`, validates the FIX dump hand-off, and rejects a
  generated Gherkin replacement for night batch.
- A real run stops after Day1 with an explicit waiting status and exit code 3.
  `--run-execution-flow ... --complete-gate night_batch` resumes only Day2,
  and the acknowledgement is accepted only for a flow already waiting at that
  gate. Dry-run and preflight modes can validate all Features without changing
  the real gate state.
- Ruby exceptions originating in user/custom step definitions are classified
  as `custom_step_implementation`. Automatic Feature repair is withheld and
  user-owned `.rb` files remain read-only; the generated Feature is not changed
  merely to bypass implementation errors.

## [2026-09-08] Standalone Admin Validation Before Hybrid Continuation

### Changed
- Hybrid conversion now produces `<case>.admin.feature` first and verifies its
  complete Background, ordered steps, and DataTables against the MCP semantic
  flow. It no longer merges Admin operations into the Binary Feature before
  execution or repair.
- The standalone Admin Feature is run and repaired independently. If a repair
  drifts from the MCP flow, the batch rebuilds only that Admin artifact and
  retests it once before any non-Admin work is allowed.
- Admin flow promotion uses only the standalone Admin run report. A later
  Binary, Batch, Trading GUI, or Clearing failure cannot demote already-proven
  Admin experience.
- Hybrid non-Admin behavior is generated into an independent `<case>.feature`
  only after Admin validation. Its generation and repair receive no Admin flow
  evidence, and deterministic guards reject leaked Admin steps or tags.
- Older catalog entries that contain only a deferred approval (or otherwise
  lack a complete standalone Admin path) are ignored even if they were marked
  reusable by the former combined pipeline.

## [2026-09-08] Admin Manifest Handoff Recovery

### Fixed
- The Admin MCP prompt now reads the catalog schema first, includes the exact
  `page`/`steps`/`evidence`/`reuse` JSON skeleton, requires `steps[].text` and
  required DataTables, and explicitly rejects legacy `page_route`, `uat_step`,
  and `mcp_execution=completed` shapes.
- The batch runner deterministically normalizes recoverable MCP output:
  `page_route` becomes `page.route`, an exact route can supply its unique
  PageExplore profile and label, missing descriptive/catalog fields receive
  safe defaults, and `uat_step` becomes `text`. Every rewrite records source
  and result hashes plus the changed fields in the exploration report.
- A structurally recovered candidate is checked against the runtime
  `Step_Index` before promotion. Natural-language browser summaries, unknown
  operations, and steps missing required Cucumber DataTables cannot pass as
  executable UAT steps.
- When browser evidence and rollback already passed but only the semantic
  manifest is invalid, the runner performs at most one short browser-free
  OpenCode repair. Playwright/MCP, shell, network, dotenv reads, and business
  actions are denied; failure preserves the evidence and never reruns MCP.
- `admin_feature_converter.py` now supports
  `--validate-only --semantic-strict`, detects missing DataTables, and matches
  trusted Step_Index alternations such as effective-record card variants.
- The Admin catalog builder now enforces non-empty page profiles, step text,
  valid MCP execution enums, table types, and reuse keyword arrays so manual
  catalog refresh cannot admit the same malformed handoff shape.

## [2026-09-07] Reversible Admin MCP Approval Boundary

### Changed
- Missing-flow Playwright MCP exploration now submits the maker request,
  validates the pending countersign path, and has the checker Reject it so the
  original active state is retained. Non-countersign forms Cancel before save.
- Approval required by YAML remains in the semantic manifest with
  `mcp_execution=deferred_to_feature`; the generated Feature owns the actual
  approval and must pass before the flow becomes reusable.
- Exploration reports must declare rollback-validation mode, maker submission,
  cleanup action/completion, restored state, zero final approvals, and matching
  validated/deferred-step counts. The batch checks the transcript for Reject or
  Cancel cleanup and rejects any Playwright final-Approve action.
- Runtime dotenv files can provide checker cleanup credentials through
  `ODP_CHECKER_USERNAME`/`ODP_CHECKER_PASSWORD`; missing keys fail preflight
  before MCP starts. `ODP_USERNAME`/`ODP_PASSWORD` remain the maker login.
- A missing or null model-generated `flow_id` is recovered deterministically
  from case ID and page route after checking any supplied hash against the
  original candidate. A non-empty malformed ID still fails validation.
- Reject/Cancel cleanup is rejected from both manifest Background and scenario
  steps; generated Features retain only the deferred Approve operation.
- Final summaries label this stage as `ADMIN-FAIL` and use full pipeline wall
  time, including MCP exploration and Feature execution.

## [2026-09-07] Assisted Excel-to-YAML Fidelity Gate Removed

### Changed
- Removed the deterministic per-step JSON-to-YAML Test Data fidelity gate.
  Assisted conversion no longer fails solely because the model reformatted,
  moved, omitted, or substituted a value after producing a YAML artifact.
- The parsed JSON remains the authoritative model input, and Admin exploration
  still treats explicit YAML Test Data as authoritative over conflicting
  aliases in preconditions or step prose.

## [2026-09-07] Admin Project Read Fallback and Compact Batch Logs

### Changed
- Admin exploration now reads the selected runtime dotenv file before browser
  navigation and uses the actual ODP login values only as Playwright field
  inputs. It no longer sends literal dotenv key names and assumes that
  Playwright MCP `--secrets` will substitute them; `--secrets` remains enabled
  to redact matching values in browser-tool responses.
- Snapshot refs are now observation-only handles. Ref-based click/type/fill/
  select/hover/drag tools are denied in the Admin model environment, while raw
  Playwright locator code is explicitly allowed for UI interaction. The agent
  refreshes snapshots after state changes and uses stable role/name/label/id
  locators or reviewed Grid snippets. Direct backend calls, fetch/XHR
  overrides, and `qaGridApi.setRowData` remain prohibited.
- When the Admin agent exits without `exploration-report.json`, the batch
  runner now synthesizes a deterministic failed report from redacted transcript
  metadata and the last sanitized tool error. This fallback cannot pass
  validation and does not create or promote an Admin flow.
- Admin exploration now has read access to the complete runtime project,
  including the configured dotenv file. Excel/YAML model stages remain unable
  to read credential files, and Admin writes remain scoped to the isolated
  evidence directory.
- A discovered or explicitly selected runtime dotenv path now replaces any
  stale `--secrets` option embedded in a reusable Playwright MCP command or
  existing OpenCode MCP entry, so ProjectA/.env cannot be silently ignored.
- Login values loaded for the fallback are registered with the batch redactor
  before OpenCode output or transcripts are written. Usernames, passwords,
  cookies, and tokens remain forbidden in terminal logs, reports, and flow
  manifests.
- Batch output is compact by default: stage flow, direct model prompt,
  periodic progress, and status. `--verbose-model-output` restores full
  redacted child/model events for troubleshooting.
- Failed Admin reports now surface their first concrete failure reason in the
  batch error and per-case result instead of reporting only `status="failed"`.

## [2026-09-06] Admin MCP URL and Credential Boundary

### Fixed
- Admin exploration now resolves the non-secret ODP browser URL in the batch
  parent (`--odp-url`, exported `ODP_URL`, or the runtime `.env`) and passes it
  directly to the model. The model no longer needs to probe DNS or read
  protected configuration/log files to discover the site.
- The Playwright MCP secrets lookup shares the same runtime `.env` discovery
  paths and requires a readable, non-symlink file before passing it as
  `--secrets`; credentials remain outside the OpenCode file-tool policy.
- The exploration prompt treats snapshot references as ephemeral and requires
  a fresh snapshot/retry after stale references, while always writing both
  hand-off artifacts on failure.
- Login placeholders are selected from dotenv key names so the documented
  `ODP_USERNAME`/`ODP_PASSWORD` file works directly; legacy `SECRET_ODP_*`
  aliases remain supported without exposing secret values to OpenCode.
- A stale/placeholder process `ODP_URL` no longer masks a valid dotenv value.
  Portable installs now always inspect `ProjectA/.env` when the script lives
  below `ProjectA/PageExplore/tools`, accept a UTF-8 BOM on the first dotenv
  key, and report the status of every checked path without printing secrets.
- Legacy host-only values such as `10.161.65.56` or `host:8443` are accepted
  and normalized to HTTPS, which avoids rejecting older runtime `.env` files.
- The two observed ODP landing-page forms with the exact `login_mode=both`
  query are normalized back to the base URL, so copying the browser's login
  address into `.env` no longer creates a false URL preflight failure.
- Excel/YAML prompts now point directly to local `SKILL.md`/rules files instead
  of invoking filesystem paths as named OpenCode skills; unregistered skill
  aliases no longer cause a wasted model retry.

## [2026-09-06] Conversion Output Error Classification

### Fixed
- Narrowed `tools/batch_transform_tc.rb` permission detection to explicit
  permission/access denials. Recoverable OpenCode `Read`, `Grep`, or `Glob`
  errors no longer mark a successfully written YAML artifact as an
  Excel-to-YAML permission failure.
- Clarified in conversion and Admin prompts that restored ODP documents must
  be resolved through `restored_path`; the source-relative index `path` is not
  necessarily present in the delivery bundle.

## [2026-09-05] Seven-Stage Admin/Hybrid Batch Orchestration

### Added
- `tools/batch_transform_tc.rb` now owns the required
  `2 -> 3 -> 1 -> 4 -> 5 -> 6 -> 7` lifecycle for Admin/Hybrid generation
  repair: Excel/YAML conversion, channel classification, missing-flow
  Playwright MCP exploration, Feature generation, initial run, conditional
  repair/retest, and validated flow promotion.
- Added automatic offline Playwright MCP discovery, isolated evidence output,
  explicit Node/CLI/browser overrides, headed VNC operation by default, and an
  explicit `--playwright-mcp-headless` mode.
- Added transactional Admin-flow promotion and quarantine. A new flow cannot
  be reused until the generated Feature report passes and the catalog refresh
  succeeds.

### Fixed
- `tools/find_admin_flow.py` now resolves its default index relative to the
  PageExplore checkout, so it works when called from the runtime project root.
- Custom flow directories can rebuild their own catalog index, and manifest or
  Binary-base symlinks are excluded from automatic selection.

## [2026-09-04] Playwright MCP HTTPS Configuration

### Added
- Added the `PLAYWRIGHT_MCP_IGNORE_HTTPS_ERRORS` installer switch (default
  `1`) and passed it consistently to the generated OpenCode MCP command and
  `--verify-only` path.
- Preserved that non-sensitive switch in the restricted environment used by
  batch diagnosis and Feature repair, defaulting the wrapper environment to
  `1` when it is not set.
- Aligned the standalone Python `web-playwright` runner to the same default;
  `PW_IGNORE_HTTPS_ERRORS=false` restores certificate verification there.
- Documented the OpenCode `mcp.playwright.command`, the existing-config merge
  behavior, and the boundary between browser and provider TLS verification.

## [2026-09-04] Runtime Data Gates and Current-Feature Browser Evidence

### Added
- Added runtime-data preflight modes for generated and existing Features. A
  repair now blocks before model editing when required files, literal values,
  or symbolic runtime aliases are unresolved; evidence-only and explicit
  reviewed override modes remain available.
- Added Cucumber summary and first-failure classification to distinguish an
  executed runtime lookup from formatter output for skipped steps.
- Added `{bindings}` replay-adapter input and a SHA256 handshake for the current
  `{feature}` and private bindings. Only a passing verified/safe replay that
  acknowledges current inputs is authoritative repair evidence.
- Added repeatable `--cucumber-arg` forwarding through the batch entry point
  for explicitly tagged, independently structured Scenarios.

### Changed
- Scenario Outline example variables are excluded from literal-placeholder
  preflight failures.
- Unverified Playwright flows are blocked by default; an explicit exploratory
  override remains non-authoritative.
- Runtime data lookup, credential/session, and environment/browser failures now
  stop model repair as `blocked_runtime`. A lookup divergence can proceed only
  with authoritative replay evidence for the current Feature inputs.

## [2026-09-03] Generation Repair and Playwright-Assisted Comparison

### Added
- Added generation-time `--repair-generated` and trailing no-value `--repair`
  modes. Each newly generated Feature is run through Cucumber and enters the
  audited repair/rerun loop only when it fails; a passing rerun ends that case.
- Added optional reviewed Playwright flow comparison and a project-owned replay
  adapter contract. The runner records static semantic divergence, replay step
  status, first browser failure, redacted logs, and sanitized adapter reports.
- Added `off`, `before_feature`, `on_failure`, and `each_attempt` replay modes;
  Playwright and Cucumber remain serialized by default because Admin actions may
  mutate shared ODP state.
- Added disposable repair staging worktrees containing the Skill, PageExplore,
  and ODP business references. Only the staged Feature is editable and only
  that file is atomically promoted after hash/path auditing.

### Changed
- Existing-Feature batch repair now forwards Playwright flow/replay options to
  `run_feature_debug.rb`.
- Repair worktrees inherit the tester project's `opencode.json(c)` through
  `OPENCODE_CONFIG`, while inline permissions deny external reads and restrict
  edits to the staged Feature. This preserves the configured internal provider
  endpoint without exposing runtime project files to the model.
- The tester delivery archive is now a portable `PageExplore/` bundle: runtime
  Features, resources, and raw UAT snapshots are excluded; the target project
  supplies its own runtime checkout beside the bundle.

## [2026-09-03] ODP Business Documents and Model Selection

### Added
- Restored the 27 Functional Specifications embedded in `uat/odp_doc.md`
  under the sibling `odp-docs/` knowledge root, with source-line/hash indexes
  and the repeatable `tools/restore_odp_docs.py` builder.
- Added a consistent OpenCode model selector to both conversion and Feature
  runner entry points. The default is the configured internal Ollama model
  `ollama/DeepSeek-V4-Flash-INT8`; `--model provider/model` and
  `OPENCODE_MODEL` select another installed model.

### Changed
- Generation, diagnosis, and repair prompts now use the ODP document index to
  locate business rules while keeping runtime UAT steps authoritative for
  executable syntax.
- Restored `project-summary.md` as the canonical compact project summary and
  filename/session naming reference; it is linked from `INDEX.md`.
- Fixed OpenCode edit authorization for copied tester projects without a Git
  worktree. Repair now recognizes the canonical, project-relative, and
  root-relative forms of the one authorized Feature path while retaining the
  single-file write boundary.
- Switched the default model to the configured internal
  `ollama/DeepSeek-V4-Flash-INT8` model and made repair-only runs print the
  effective model, so provider and connectivity errors are distinguishable.

## [2026-09-03] PageExplore Knowledge Boundary

### Changed
- Moved the sitemap, Grid operation guide, Selenium reference, all page
  profiles, qaGrid contracts/observations, and their source evidence under the
  independent `pageExplore/` knowledge root.
- Removed qaGrid and page-exploration knowledge files from
  `odpt-automation-skill/`; the Skill now consumes PageExplore instead of
  owning a duplicate copy.
- Updated page/Grid index builders, Feature diagnosis, and batch transform to
  use the PageExplore paths. `PAGEEXPLORE_ROOT` can point consumers and
  maintenance scripts at an independently mounted knowledge base.
- Made generated page and qaGrid index paths relative to the PageExplore root,
  so index content remains stable when the knowledge base is mounted at a
  different absolute path.
- Standardized the OpenCode/Codex entry file as `SKILL.md` with discovery
  metadata; all internal links now use the canonical filename.

## [2026-09-02] Audited Feature Repair

### Added
- Added explicit `--repair FEATURE` execution mode to the Feature runner and
  batch entry point. After a failed run, opencode is restricted to the target
  Feature, edits are hash/path checked, and the Feature is rerun until it
  passes (with optional `--repair-attempts N` limit). `--debug-feature` remains
  read-only diagnosis.

### Repair experience and FIX dump hand-off
- Replaced the skill's Binary/Hybrid persistence examples with the canonical
  `Save FIX dumpfile` / `Load FIX dumpfile` contract. The load step refreshes
  Scenario-local references after merging the global maps.
- Added `repair_experience/` with a deterministic builder, quarantine-style
  `inbox/` candidates, and reviewed semantic lessons for the one-user-per-
  Admin-browser rule. Repair candidates are redacted and review-gated; the
  runner does not load inbox entries as guidance, and only lessons marked
  `status=verified` plus `safe_to_reuse=true` can provide automatic positive
  guidance.
- The Admin converter now flags a multi-user `Login Trading Admin with:` table
  as `MULTI_USER_LOGIN_REQUIRES_SEPARATE_BROWSER_SESSIONS` instead of silently
  emitting that anti-pattern.
- Batch conversion now supplies path-scoped opencode permissions for external
  Excel/YAML/Feature directories and fails closed when a successful-looking
  command reports a permission error or produces no artifact.

## [2026-09-01] Admin/Hybrid Conversion and UI Indexes

### Added
- PageExplore `qaGrid/` with `Grid_API_Core_Index.md` and generated
  `qaGridApi_Index.json/.md` for the
  shared Admin/Trading `qaGridApi` contract and redacted observations.
- `Step_Index.json/.md` generated from `uat/uat_step.txt`, with explicit
  runtime authority and external `wabi-web` resolution status.
- `Admin_GUI/Feature_Flow_Index.md` and `Admin_GUI/Feature_Converter.md` for
  repeated-flow routing and Playwright MCP evidence handoff.
- `Admin_GUI/flow_catalog/` plus `tools/build_admin_flow_catalog.py` for
  persisted semantic Playwright flows and replay/reuse status.
- `tools/build_grid_api_index.py`, `tools/build_step_index.py`,
  `tools/update_page_grid_profiles.py`, `tools/build_pages_index.py`, and
  `tools/admin_feature_converter.py` for repeatable maintenance.
- `FIXODPMSG_Index.json/.md` generated from `etc/FIXODPMSG.xml`, including
  all 142 application enum values and the optional transport dictionary.
- `Error_Code_Index.json/.md` plus the hand-off source snapshot under
  `sources/`, covering 30 user-supplied categories and 570 entries while
  retaining the existing SME-approved CSV provenance.
- `Feature_Run_and_Debug.md` and `tools/run_feature_debug.rb` for opt-in
  execution of generated or manually edited Features, redacted reports, and
  read-only opencode diagnosis.

### Changed
- Added `gridApi` metadata to all `hasGrid: true` page profiles; the SMP ID
  List detail sub-table retains its observed key/schema status.
- Updated PageExplore `sitemap.md`, `GRID_OPERATION_GUIDE.md`, Admin/Trading
  indexes, and
  the main skill workflow with runtime key-resolution and evidence gates.
- Extended `tools/batch_transform_tc.rb` with optional Admin manifest,
  channel, deterministic converter, and Hybrid base Feature integration while
  preserving the original three positional arguments.
- Added `pageExplore/pages/INDEX.json`/`INDEX.md`, generated from the
  PageExplore snapshot,
  and indexed the supplemental Admin `qaGridApi` capture in
  `pageExplore/evidence/qaGrid/odp_admin_gui_grid_api_additional.log`.
- Added category-scoped error-code lookup and XML enum-index rebuild commands
  to the Binary Interface navigation.
- Added `--run-generated`/`--debug-generated` to the batch transform, plus
  direct `--run-feature`/`--debug-feature` modes for an existing Feature.
- Added opt-in `--binary-debug` (or `FEATURE_BINARY_DEBUG=1`) forwarding of
  `LOGLEVEL=DEBUG`, `WABI_FIX_DEBUG=1`, and `WABI_TIMING=1` to Feature runs;
  generated Features remain unchanged and can be rerun after manual edits.
- Added an explicit `@REVIEW` execution gate and persisted flow lifecycle
  guidance so observed Playwright evidence cannot be mistaken for a verified
  runnable Feature.
- Disabled batch no-output retries for Feature execution and tightened the
  generated-file freshness and multi-tag `@REVIEW` checks.
- Added FIX-field-aware and user-selectable category-scoped error matching in
  run reports (`--error-category` / `FEATURE_ERROR_CATEGORIES`), and made
  conversion failures return non-zero from the batch entry point.
- Added exact `field=value` FIX enum resolution from both application and
  transport dictionaries to run reports and read-only diagnosis prompts.
- Redacted batch command/output transcripts and replaced credentials in the
  persisted Admin flow examples with environment-style placeholders.
- Removed the obsolete auto-permission flag from the opencode diagnosis
  default; diagnosis now starts in `--pure` mode without automatic approval.
- Hardened run output handling: structural and table-style secret redaction is
  applied after complete output capture, diagnosis receives an environment
  allowlist, output aliases cannot overwrite Features, generated trees use
  private permissions, and unverified Admin flows require an explicit opt-in.
- Hardened batch conversion execution: removed automatic/dangerous opencode
  permission flags, isolated conversion environment variables, bounded
  non-blocking output capture, failed closed on private-directory permission
  errors, and refused stale assisted-transform Features.

---

## [2026-08-10] ODP4B.3.4.5.2 YAML to Feature Conversion

### Converted Files
- `features/test_case/OrderBookAndExecution/ODP4B/AI/ODP4B.3.4.5.2_validate_if_the_system_can_correctly_calculate_the_AR_based_on_the_specific_parameter_input_for_different_CA_type_Bonus_Issue_of_Shares-Day1.feature`
- `features/test_case/OrderBookAndExecution/ODP4B/AI/ODP4B.3.4.5.2_validate_if_the_system_can_correctly_calculate_the_AR_based_on_the_specific_parameter_input_for_different_CA_type_Bonus_Issue_of_Shares-Day2.feature`

### Updated Files
- `resource/dataSet-ODP4B.csv`

## [2026-08-08] v6.0 - Transform Accuracy Enhancements

### Changed Content
- Fixed section numbering in `conversion-rules.md`
- Completed combo instrument dataset mapping
- Added TradeType and TradeSubType value reference
- Added BCANField and mandatory defaults documentation
- Clarified ID3 vs PART2_OF_ID_1 naming duality
- Added missing Admin GUI WebSocket step definitions

## [2026-08-08] v5.0 - Source Format Migration: Excel → YAML

### Changed Content
- Updated all skill documentation to reflect YAML as the primary source format for test case conversion
- Added cross-reference to `odp-tc-excel-yaml-skill`

## [2026-08-08] v4.0 - Admin_GUI Split into 16 Functional Files

### Changed Content
- Split `Admin_GUI_Transform_Rules.md` into 16 functional rule files + index
- Improved lazy-loading for Admin GUI transforms

## [2026-08-08] v3.0 - Major Skill Restructure

### Changed Content
- Created `INDEX.md`
- Split Trading GUI rules into page-specific files
- Added Trade History Aggregated rules
- Standardized dates and references

## [2026-07-29] v2.0 - ODP17.10.2.2 Full Rewrite & Conversion Rules Enhancement

### Changed Content
- Rewrote ODP17.10.2.2 and ODP17.5.2.3.5 feature patterns
- Added end-to-end step verification process

## [2026-07-28] v1.0 - Initial Skill Creation

### Changed Content
- Created skill documentation structure

## How to Record Future Changes

Record an entry whenever feature files, datasets, conversion rules, skill files, or project structure change.
