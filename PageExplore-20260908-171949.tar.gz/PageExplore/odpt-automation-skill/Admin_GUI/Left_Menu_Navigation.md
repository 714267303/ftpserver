# Left Menu Navigation Rules

## Keywords
Select Trading Admin Left Menu, menu path, Parent Menu, Child Menu, 73-item menu table

### Standard Menu Selection

```gherkin
* Select Trading Admin Left Menu "<Parent Menu>><Child Menu>"
```

### Complete Left Menu Hierarchy (Extracted from Project Feature Files)

| # | Parent Menu | Menu Item | Page/Window Name |
|---|---|---|---|
| 1 | Countersign | Countersign Request | Countersign Request |
| 2 | Inst. Hierarchy | Maintain Exchange | Maintain Exchange |
| 3 | Inst. Hierarchy | Maintain Market | Maintain Market |
| 4 | Inst. Hierarchy | Maintain Inst. Group | Maintain Inst. Group |
| 5 | Inst. Hierarchy | Maintain Inst. Type | Maintain Inst. Type |
| 6 | Inst. Hierarchy | Maintain Underlying | Maintain Underlying |
| 7 | Inst. Hierarchy | Maintain Inst. Class | Maintain Inst. Class |
| 8 | Inst. Hierarchy | Maintain Instrument | Maintain Instrument |
| 9 | Inst. Hierarchy | Maintain Inst. Name Standard | Maintain Inst. Name Standard |
| 10 | Inst. Hierarchy | Maintain Access Group By Type | Maintain Access Group By Type |
| 11 | Auto Inst. Generation | Instrument Generation | Instrument Generation |
| 12 | Auto Inst. Generation | Maintain Cycle Blocks | Maintain Cycle Blocks |
| 13 | Auto Inst. Generation | Maintain Last Trading Date Calendar | Maintain Last Trading Date Calendar |
| 14 | Auto Inst. Generation | Maintain Last Trading Date Formula | Maintain Last Trading Date Formula |
| 15 | Auto Inst. Generation | Maintain Regional Holiday Calendar | Maintain Regional Holiday Calendar |
| 16 | Auto Inst. Generation | Maintain Strike Price Range | Maintain Strike Price Range |
| 17 | Auto Inst. Generation | Maintain Strike Price Reference | Maintain Strike Price Reference |
| 18 | Auto Inst. Generation | Maintain Strike Price Table | Maintain Strike Price Table |
| 19 | Combo Hierarchy | Maintain Auto Generation Rule | Maintain Auto Generation Rule |
| 20 | Combo Hierarchy | Maintain Combo | Maintain Combo |
| 21 | Combo Hierarchy | Maintain Combo Class | Maintain Combo Class |
| 22 | Combo Hierarchy | Maintain Combo Group | Maintain Combo Group |
| 23 | Combo Hierarchy | Maintain Combo Name Standard | Maintain Combo Name Standard |
| 24 | Combo Hierarchy | Maintain Combo Type | Maintain Combo Type |
| 25 | Combo Hierarchy | Maintain Cycle Blocks | Maintain Cycle Blocks |
| 26 | Combo Hierarchy | Maintain Last Trading Date Calendar | Maintain Last Trading Date Calendar |
| 27 | Combo Hierarchy | Maintain Last Trading Date Formula | Maintain Last Trading Date Formula |
| 28 | Combo Hierarchy | Maintain Regional Holiday Calendar | Maintain Regional Holiday Calendar |
| 29 | Participant | Maintain Exchange Participant | Maintain Exchange Participant |
| 30 | Participant | Maintain Sponsoring Participant | Maintain Sponsoring Participant |
| 31 | Participant | Maintain Direct Order Flow Session | Maintain Direct Order Flow Session |
| 32 | Participant | Maintain Direct Drop Copy Session | Maintain Direct Drop Copy Session |
| 33 | Participant | Maintain Drop Copy Group | Maintain Drop Copy Group |
| 34 | Participant | Maintain Trading Rights | Maintain Trading Rights |
| 35 | Participant | Maintain Participant User Role | Maintain Participant User Role |
| 36 | Participant | Maintain MMP Parameter | Maintain MMP Parameter |
| 37 | Participant | Maintain SMP ID List | Maintain SMP ID List |
| 38 | Participant | Maintain Company | Maintain Company |
| 39 | Participant | Maintain Self Admin Portal User | Maintain Self Admin Portal User |
| 40 | Participant | Maintain Legal IP Address | Maintain Legal IP Address |
| 41 | Participant | Maintain Trading GUI User | Maintain Trading GUI User |
| 42 | Timetable | Maintain Trading Timetable | Maintain Trading Timetable |
| 43 | Timetable | Maintain Trading State | Maintain Trading State |
| 44 | Timetable | Maintain Non-Trading Days | Maintain Non-Trading Days |
| 45 | Timetable | Control Trading Timetable | Control Trading Timetable |
| 46 | Price Supervision | Maintain Price Tick | Maintain Price Tick |
| 47 | Price Supervision | Maintain Price Tick Limit Rule | Maintain Price Tick Limit Rule |
| 48 | Price Supervision | Maintain Inst. Class Price Tick Limit | Maintain Inst. Class Price Tick Limit |
| 49 | Price Supervision | Maintain Combo Class Price Tick Limit | Maintain Combo Class Price Tick Limit |
| 50 | Price Supervision | Maintain Price Limit Parameters | Maintain Price Limit Parameters |
| 51 | Price Supervision | Maintain Price Limit | Maintain Price Limit |
| 52 | Price Supervision | Maintain Reference Price Source | Maintain Reference Price Source |
| 53 | Price Supervision | Maintain Reference Price Calculation Rule | Maintain Reference Price Calculation Rule |
| 54 | Price Supervision | Maintain Futures Group | Maintain Futures Group |
| 55 | Price Supervision | Maintain VCM | Maintain VCM |
| 56 | Price Supervision | Maintain VCM Parameters | Maintain VCM Parameters |
| 57 | Price Supervision | Control & Monitor Price Limit | Control & Monitor Price Limit |
| 58 | Price Supervision | Control & Monitor VCM | Control & Monitor VCM |
| 59 | Block Trade | Maintain Block Trade Group | Maintain Block Trade Group |
| 60 | Block Trade | Maintain Block Trade MVT | Maintain Block Trade MVT |
| 61 | Error Trade | Maintain Inst. Type Error Trade Parameters | Maintain Inst. Type Error Trade Parameters |
| 62 | Error Trade | Maintain Combo Type Error Trade Parameters | Maintain Combo Type Error Trade Parameters |
| 63 | SMP | Maintain SMP ID | Maintain SMP ID |
| 64 | Control & Monitoring | Control Settlement Values | Control Settlement Values |
| 65 | Control & Monitoring | Control Underlying Price | Control Underlying Price |
| 66 | System | Maintain Contingency Switch | Maintain Contingency Switch |
| 67 | System | Maintain Global Parameters | Maintain Global Parameters |
| 68 | User Maintenance | Maintain UI User Role | Maintain UI User Role |
| 69 | TMC | Maintain TMC Strategy | Maintain TMC Strategy |
| 70 | TMC | Maintain TMC Strategy List | Maintain TMC Strategy List |
| 71 | TMC | Control TMC | Control TMC |
| 72 | Product Setup | Bulk Import from File | Bulk Import from File |
| 73 | Product Setup | Maintain Instrument | Maintain Instrument |

### Usage Example

```gherkin
* Select Trading Admin Left Menu "Countersign>Countersign Request"
* Select Trading Admin Left Menu "Inst. Hierarchy>Maintain Instrument"
* Select Trading Admin Left Menu "Participant>Maintain Exchange Participant"
* Select Trading Admin Left Menu "Price Supervision>Control & Monitor Price Limit"
```

**Key Points:**
- The menu path uses `>` as separator between parent and child menu items
- Always wait 2 seconds after menu navigation: `* Wait 2 seconds`
- Take a screenshot after navigation: `* Screenshot`
- The page title matches the window name

### Tree View

```
Inst. Hierarchy
├── Maintain Exchange
├── Maintain Market
├── Maintain Inst. Group
├── Maintain Inst. Type
├── Maintain Underlying
├── Maintain Inst. Class
└── Maintain Instrument

Combo ── Maintain Combo Type, Maintain Combo Class, Maintain Combo, Maintain Combo Name Standard

Participant ── Maintain Exchange Participant, Maintain Sponsoring Participant,
               Maintain Direct Order/Drop Copy Session, Maintain Trading Rights,
               Maintain Participant User Role, Maintain MMP Parameter, Maintain SMP ID List,
               Maintain Company, Maintain Self Admin Portal User, Maintain Legal IP Address,
               Maintain Trading GUI User, Maintain UI User Role

Countersign ── Countersign Request

Price Supervision ── Price Tick, Price Tick Limit Rule, Inst. Class Price Tick Limit,
                     Maintain Reference Price Source, Price Limit, Price Limit Parameters,
                     Control & Monitor Price Limit, Control & Monitor VCM, VCM Parameters, Futures Group

Timetable ── Maintain Trading Timetable, Maintain Trading State, Maintain Non-Trading Days, Control Trading Timetable

Block Trade ── Maintain Block Trade Group, Maintain Block Trade MVT

Error Trade ── Maintain Inst. Type Error Trade Parameters, Maintain Combo Type Error Trade Parameters

SMP ID List ── Maintain SMP ID

Control & Monitoring ── Control Settlement Values, Control Underlying Price

System ── Maintain Contingency Switch, Maintain Global Parameters

User Maintenance ── Maintain UI User Role

TMC ── Maintain TMC Strategy, Maintain TMC Strategy List, Control TMC

Product Setup ── Bulk Import from File, Maintain Instrument
```

## Revision History

| Date | Author | Description |
|---|---|---|
| 2026-08-08 | AI Assistant | Extracted from Admin_GUI_Transform_Rules.md Rules 4, 15 |
