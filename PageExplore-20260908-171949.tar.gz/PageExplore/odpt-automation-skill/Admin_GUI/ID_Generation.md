# ID Generation Rules

## Keywords
Assign, Generate ID, [RI1-255], [RS2], Generate series info, Time.now.strftime, Generate in range, Unique field value, Replace value, Get value by index, Get value by row

### Basic Assign

```gherkin
* Assign ("Exchange-" + Time.now.strftime("%Y%m%d%H%M%S") + ".csv") to file_name
* Assign ("new_Exchange_id1" + ", " + "new_Exchange_code1") to Identifier1
* Assign ((Time.now + 86400).strftime("%d-%b-%Y")) to exp_effective_date
```

### Generate ID from Existing Data

```gherkin
# Step 1: Export existing data to CSV
* Admin GUI "Maintain Exchange" page export csv save to "file_name" and read to "arr_existing_Exchange"
* Click button "Close" in Trading Admin

# Step 2: Generate unique ID based on existing data
* Generate ID info base on "arr_existing_Exchange":
    | Exchange Code                  | Exchange ID              |
    | [RI1-255] : new_Exchange_code1 | [RS2] : new_Exchange_id1 |
```

### ID Generation Syntax

| Pattern | Meaning | Example |
|---|---|---|
| `[RI1-255]` | Random string, 1-255 chars | generates a random exchange code |
| `[RS2]` | Random string, 2 chars | generates a random 2-char ID |
| `T_[RS3]` | Prefix + random string | generates `T_ABC` |

### Generate Series Info (for Instrument IDs)

```gherkin
* Generate series info and save to :
    | Series                        | Name              | Month                   | Year                   | Last Trading Date    | Last Trading Time    |
    | #{expected_hash["Series"]}    | instrument_id1    | instrument_id1_month   | instrument_id1_year    | instrument_id1_ltd   | instrument_id1_ltt   |
```

### Generate Unique Value in Range

Generate a unique numeric value within a specified range that doesn't exist in existing table data:

```gherkin
* Generate "Market Code" from "Maintain Market" in range "1-255" and save to "new_market_code"
```

**Key Points:**
- Scans current page table data for conflicts
- Saves result to `@bigmap` with the specified key

### Set Unique Field Value from Exported Data

Generate a unique value for a field based on exported CSV data, supporting number ranges and dropdown options:

```gherkin
* Set the value of field "Strike Price [number:1-99999(2)]" from file "none" unique in existing records of page "Instrument Detail" which base on field "Inst. Class ID" which value is "MarketID1" and file "arr_existing_Inst. Type" and store as variable with Description "none" and variable without Description "StrikePrice1"
```

**Key Points:**
- `field1` supports numeric range syntax: `"[number:min-max(decimals)]"`
- Filters existing records by `field2_value`
- For dropdown fields, reads available options from `baseFile_set`

### Replace Value in Bigmap Variable

Perform string replacement within a bigmap variable:

```gherkin
* Replace the value of target_key from old_value to new_value
```

### Get Value from Exported Data by Index

Extract a specific value from exported CSV data by column name and 1-based row index:

```gherkin
* Get value "Underlying ID" index 8 from file "arr_existing_Underlying" to "underlying_id1"
```

### Get Value from Exported Data (with Sub-Table Support)

Extract a value by field name and row number, with optional sub-table parsing:

```gherkin
* Get value "name" row 1 from file "current_info" to "cur_name"
* Get sub table value "Action" row 1 from file "update_approve" to "sub_action_value"
```

## Revision History

| Date | Author | Description |
|---|---|---|
| 2026-08-08 | AI Assistant | Extracted from Admin_GUI_Transform_Rules.md Rule 5 |
| 2026-08-08 | AI Assistant | Added generate in range, unique field value, replace value, get value by index/row |
