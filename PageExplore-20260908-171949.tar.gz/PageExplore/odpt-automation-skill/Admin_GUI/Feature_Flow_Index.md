# Admin GUI Feature Flow Index

## Scope

This index records repeated Admin GUI workflows found in the actual feature corpus
at `uat/uat_admin_feature.txt`. It is intended to help a transformer choose
existing UAT steps and to identify possible future composite steps.

The entries below are corpus observations. `observed` means that the pattern is
present in the feature corpus; it does not mean that the flow has been executed
successfully against the current environment. Values, IDs, page names, and table
contents remain case-specific parameters.

## Provenance

| Field | Value |
|---|---|
| Source | `uat/uat_admin_feature.txt` |
| Source SHA-256 | `d640a93fc332e8f8c23f5d52ff97b1c515428df0cedffb47f2523ef6e770a13c` |
| Generated | 2026-09-01 |
| Source line references | Lines in the concatenated corpus, not lines in the original feature file |
| Existing atomic step catalog | `Admin_GUI/Step_Definition_Reference.md` |
| Existing implementation | `features/customized_steps/admin_gui_steps.rb`, `admin_gui_ws_class_steps.rb` |

## Corpus Snapshot

| Measure | Count |
|---|---:|
| `<FILE:...>` markers | 1,756 |
| Unique file paths | 1,756 |
| Files containing at least one `Scenario:` | 1,754 |
| Parsed scenarios | 1,772 |
| Raw executable `*` step lines | 146,744 |
| Normalized whole-scenario signatures repeated at least twice | 187 groups / 780 scenarios |

Feature tags in the corpus are mixed: `Binary` 1,721 files, `AdminGUI` 19,
`UAT` 7, `WS` 6, two files without `@FEATURE`, and one file with the legacy
`ODP14b.4.9.1.1.4_Pre` tag. The directory or tag alone is therefore not a
reliable workflow classifier.

## Counting Rules

1. A scenario is the text from `Scenario:` up to the next `<FILE:...>` marker.
2. A family count means that one scenario contains the listed operation shapes;
   it does not require those operations to be adjacent.
3. Literal quoted values and numeric literals were abstracted for normalized
   signatures. `Wait` and `Screenshot` were omitted only for signature matching;
   they are still valid evidence in the source feature.
4. A source example such as `uat/uat_admin_feature.txt:6809` points to the
   scenario line in the concatenated corpus.

## Observed Flow Families

### `ADMIN_SESSION_BOOTSTRAP`

**Coverage:** 1,672 scenarios / 1,657 files.

```gherkin
* Open browser
* Login Trading Admin with:
    | User ID | User Password |
    | ...     | ...            |
* Clear Alert If Exist
* Save current browser to "<browser_session>"
```

Common optional steps are `Wait` and `Screenshot`. Reuse the existing steps from
`General_Navigation.md`; no new step is needed for this sequence.

**Evidence:** `uat/uat_admin_feature.txt:20`.

### Session Bootstrap Safety Boundary

The bootstrap shape above is reusable only when the login table contains one
distinct user (same-user rows are limited to an explicit expected-login-error
retry).  A historical scenario that puts maker and checker users in the same
`Login Trading Admin with:` table is an unsafe variant: the first login
navigates away from the login form, so the second user can fail with a missing
login field or a timeout, and saving the current browser twice creates aliases
instead of two sessions.  Do not promote that variant from this corpus index.

Record the finding in the sibling
[`repair_experience/`](../repair_experience/README.md) catalog, split the flow
into one `Open browser` -> one-user `Login Trading Admin with:` -> `Save current
browser` sequence per user, and replay it from a clean target runtime before
marking the lesson `verified` and `safe_to_reuse=true`.

### `ADMIN_GRID_SEARCH_ASSERT`

**Coverage:** 972 scenarios / 965 files contain both operations.

```gherkin
* Select Trading Admin Left Menu "<menu_path>"
* Search in Trading Admin "<page>" page with:
    | <filter> | <value> |
* Check table "<table>" contains visible rows with:
    | <column> | <expected> |
```

The assertion can instead be `contains rows`, `rows count`, or `match rows
count`. Map the exact assertion to `Table_Operations.md` instead of weakening
the expected result.

**Evidence:** `uat/uat_admin_feature.txt:20` and
`uat/uat_admin_feature.txt:3817`.

### `DETAIL_CREATE`

The standard create flow has two effective-date variants.

| Variant | Coverage | Start step |
|---|---:|---|
| `as soon as possible` | 246 scenarios / 246 files | `Click button "New Record > New record for as soon as possible" in Trading Admin` |
| `tomorrow` | 118 scenarios / 118 files | `Click button "New Record > New record for tomorrow" in Trading Admin` |

```gherkin
* Click button "New Record > New record for <effective>" in Trading Admin
* Set Trading Admin "<detail_page>" info as:
    | <field> | <value> |
* Click button "Confirm" in Trading Admin detail info page "<detail_page>"
* Check the confirm message "Proceed your action?" in Trading Admin detail info page "<detail_page>" confirm window
* Click button "Confirm" in Trading Admin detail info page "<detail_page>" confirm window
* Check the confirm message "Your request has been sent." in Trading Admin detail info page "<detail_page>" confirm window
* Click button "Close" in Trading Admin detail info page "<detail_page>" confirm window
```

Use `Effective_Type_Selection.md`, `Form_Data_Operations.md`, and
`Buttons_and_Dialogs.md` for expansion. The effective type and detail table are
parameters, not separate flow implementations.

**Evidence:** ASAP `uat/uat_admin_feature.txt:502`; tomorrow
`uat/uat_admin_feature.txt:6809`.

### `DETAIL_UPDATE_EFFECTIVE`

**Coverage:** 261 scenarios / 261 files contain the update core.

```gherkin
* Search in Trading Admin "<page>" page with:
    | <filter> | <value> |
* Double click table "<page>" column "<key_column>" with:
    | <key_column> | <key> |
* Select effective type "Update for <effective>" in detail info page "<detail_page>" "<card>" card
* Set Trading Admin "<detail_page>" info as:
    | <field> | <new_value> |
* Confirm the detail request and verify "Your request has been sent."
```

Some scenarios use `Update effective asap`, omit the set table for a no-change
branch, or add sub-table edits. Keep those branches explicit. This is a
composition of existing search, table, effective-type, form, and dialog steps.

**Evidence:** `uat/uat_admin_feature.txt:5678`.

### `DETAIL_DELETE_EFFECTIVE`

**Coverage:** 220 scenarios / 220 files contain the delete core.

```gherkin
* Search in Trading Admin "<page>" page with:
    | <filter> | <value> |
* Double click table "<page>" column "<key_column>" with:
    | <key_column> | <key> |
* Select effective type "Delete for <effective>" in detail info page "<detail_page>" "<card>" card
* Confirm the detail request and verify "Your request has been sent."
```

The post-submit check may assert pending, approved, scheduled, rejected, or
delete-history state. That result is case-specific and must not be hidden by a
generic composite step.

**Evidence:** `uat/uat_admin_feature.txt:416` and
`uat/uat_admin_feature.txt:3817`.

### `COUNTERSIGN_APPROVE_DETAIL`

**Coverage:** 683 scenarios / 683 files contain the detail approval core.

```gherkin
* Select Trading Admin Left Menu "Countersign>Countersign Request"
* Search in Trading Admin "Countersign Request" page with:
    | Function Name | Requester | Req Status [List] |
    | <function>    | <maker>   | Pending            |
* Set table "Countersign Request" sort by column "Req ID" type "Des"
* Double click table "Countersign Request" column "Req Action" with:
    | <request key fields> |
* Click button "Approve" in Trading Admin detail info page "Countersign Request Detail"
* Click button "Confirm" in Trading Admin detail info page "Countersign Request Detail" confirm window
* Check the confirm message "Your action has been sent." in Trading Admin detail info page "Countersign Request Detail" confirm window
* Click button "Close" in Trading Admin detail info page "Countersign Request Detail" confirm window
```

`Assign` of the effective date, detail scrolling, request-detail assertions,
and post-approval list checks are common optional parts. Existing rules:
`Countersign_Approval.md`, `Table_Operations.md`, and `Buttons_and_Dialogs.md`.

**Evidence:** `uat/uat_admin_feature.txt:3817`.

### `COUNTERSIGN_REJECT_DETAIL`

**Coverage:** 166 scenarios / 166 files contain the detail rejection core.

It uses the same request selection and detail checks as approval, replacing the
action with:

```gherkin
* Click button "Reject" in Trading Admin detail info page "Countersign Request Detail"
* Click button "Confirm" in Trading Admin detail info page "Countersign Request Detail" confirm window
* Check the confirm message "Your action has been sent." in Trading Admin detail info page "Countersign Request Detail" confirm window
* Click button "Close" in Trading Admin detail info page "Countersign Request Detail" confirm window
```

The expected final `Req Status` and `Exec Status` must remain case-specific.

**Evidence:** `uat/uat_admin_feature.txt:5678`.

### `COUNTERSIGN_APPROVE_SELECTED`

**Coverage:** 156 scenarios / 155 files contain multi-select approval.

```gherkin
* Search in Trading Admin "Countersign Request" page with:
    | <filter> | <value> |
* Set table "Countersign Request" sort by column "Req ID" type "Des"
* Select table "Countersign Request" rows with:
    | <request key fields> |
* Click button "More Actions > Approve selected Countersign Request" in Trading Admin
* Click button "Confirm" in Trading Admin
* Click button "Close" in Trading Admin
```

This is distinct from detail approval because it has one global confirmation and
does not open `Countersign Request Detail`. Reuse `Table_Operations.md` and
`Countersign_Approval.md`.

**Evidence:** `uat/uat_admin_feature.txt:20`.

### `DETAIL_SUBTABLE_ADD`

**Coverage:** 373 scenarios / 372 files contain `Add Table Item`.

```gherkin
* Scroll detail page "<detail_page>" to "Bottom"
* Add Table Item in "<detail_page>" info popup page with:
    | <subtable field> | <value> |
* Check table "<subtable>" contains rows with:
    | <field> | <expected> |
```

Repeated variants add multiple rows, modify auto-sort rows, or check a subtable
error before submitting. Keep row order and validation assertions visible.

**Evidence:** `uat/uat_admin_feature.txt:3196`.

### `EXPORT_ID_PREP`

**Coverage:** 689 scenarios / 688 files contain both export and ID/series
generation operations. This is a broad containment count, not an adjacency
claim.

```gherkin
* Assign ("<page>-" + Time.now.strftime("<timestamp>") + ".csv") to file_name
* Admin GUI "<page>" page export csv save to "file_name" and read to "<data_key>"
* Get value "<field>" from file "<data_key>" to "<variable>"
* Generate ID info base on "<data_key>":
    | <unique field> |
    | [RI...] : <variable> |
```

Instrument setup may use `Generate series info and save to :` instead. These
steps belong to `Export_File_Operations.md` and `ID_Generation.md`.

**Evidence:** `uat/uat_admin_feature.txt:502` and
`uat/uat_admin_feature.txt:5193`.

### `WS_CREATE_APPROVE`

WebSocket setup is a repeated operation cluster rather than one universal
scenario shape.

| Evidence | Count |
|---|---:|
| `CONNECT WS with:` step | 100 occurrences / 100 files |
| Scenarios containing both `CONNECT WS` and `CLOSE CONNECT` | 63 / 63 files |
| `filterkey ... and approve ...` composite step | 389 occurrences |
| `Create Standard Combo with user ...` composite step | 26 occurrences |

Typical sequence:

```gherkin
* CONNECT WS with:
    | User ID | User Password |
    | <maker> | <password>     |
* Get "<cache>" page "<page_id>" save "<data_key>" keys "<keys>" headers "<headers>" with user "<user>" password "<password>"
* Generate ID info base on "<data_key>":
    | <field> |
    | [RI...] : <variable> |
* add new <entity> with user "<maker>":
    | <field> | <value> |
* filterkey "<page>" with user "<maker>" password "<password>" and approve "<keys>" with user "<checker>"
* CLOSE CONNECT with:
    | User ID | User Password |
    | <user>  | <password>     |
```

The existing implementation is in `admin_gui_ws_class_steps.rb`; use
`WebSocket_Operations.md`. Do not infer that every WS flow uses the same page
cache or approval keys.

**Evidence:** `uat/uat_admin_feature.txt:18005`, `:287554`, and `:298382`.

### `TRADING_STATE_WS`

Trading-state commands are present but much less frequent: `set the trading
state` appears once and `move the trading state` three times in the corpus.
They are indexed for routing, not classified as a high-confidence repeated
family yet.

```gherkin
* set the trading state with maker "<maker>" approve "<checker>":
    | <trading session> | <target state> |
```

Use `WebSocket_Operations.md` and retain the state machine assertions from the
case. Evidence: `uat/uat_admin_feature.txt:304892` and `:304384`.

## Cross-Cutting Variants

The file naming convention itself shows multi-day presetting workflows:

| File suffix observed | File markers |
|---|---:|
| `.Presetting` | 318 |
| `Day1` | 191 |
| `Day2` | 177 |
| `clear` | 65 |

These are lifecycle variants, not interchangeable steps. `Bigmap_Presetting.md`
should be loaded when a case spans presetting, day transition, and cleanup.
The corpus contains historical `Load/Save bigmap file` spellings; when using
those examples for a new Binary or Hybrid Feature, normalize them to the
canonical `Load/Save FIX dumpfile` steps documented in
`Binary_Interface/Dumpfile_Operations.md`.

## Existing Composite Steps: Availability vs Evidence

The UAT implementation already contains these higher-level steps:

| Step | Implementation | Corpus occurrences | Index status |
|---|---|---:|---|
| `Create instrument series if not exists :` | `admin_gui_steps.rb:1058` | 0 | `available_not_observed` |
| `Create Combo if not exists :` | `admin_gui_steps.rb:1151` | 0 | `available_not_observed` |
| `Approve if updated with :` | `admin_gui_steps.rb:1261` | 0 | `available_not_observed` |
| `Create Standard Combo with user "<user>":` | `admin_gui_ws_class_steps.rb:837` | 26 | `observed` |
| `filterkey ... and approve ...` | `admin_gui_ws_class_steps.rb:326` | 389 | `observed` |

An implementation existing in `uat/uat_step.txt` or a Ruby file is not evidence
that the real feature corpus uses it. Keep the two states separate when
planning a Playwright-explored flow or a generated feature.

## Extraction Decision

The corpus has enough repetition to justify this index. It does not justify
blindly adding a new Ruby step for every repeated text block:

1. Generic create, update, delete, search, dialog, and countersign operations
   already have parameterized atomic steps.
2. A composite step is a candidate only when its boundary, parameters, error
   behavior, and side effects are stable across cases and it has been runtime
   verified.
3. The safest immediate reuse unit is the flow ID in this document plus the
   existing atomic UAT steps. Keep case-specific tables and expected statuses in
   the generated feature.
4. Promote a flow from `observed` to `verified` only after Playwright/MCP or the
   target UAT runner has executed it successfully and the evidence is recorded.

## Maintenance

This index is derived from the corpus snapshot above. When
`uat/uat_admin_feature.txt` changes, recompute the counts and SHA-256 before
using the index for transformation. Do not hand-edit a count without updating
the provenance row and the affected evidence references.
