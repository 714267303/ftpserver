# WebSocket Operations Rules

## Keywords
CONNECT WS, CLOSE CONNECT, add new, update, get page data, move trading state, set trading state, Presetting, @FEATURE=WS

### Feature-level WS Pattern

```gherkin
@FEATURE=WS
Feature: ODP Admin GUI
Background:
	* Load value from admin_gui_value
	* Load value from dataSet-trading-state-value
	* Load parameters from csv dataSet-trading-state
```

### Connect WS

```gherkin
* CONNECT WS with:
    | User ID         | User Password            |
    | admin_gui_user1 | admin_gui_user1_password |
    | admin_gui_user2 | admin_gui_user2_password |
```

### Disconnect WS

```gherkin
* CLOSE CONNECT with:
    | User ID         |
    | admin_gui_user1 |
    | admin_gui_user2 |
```

### Add New Record via WS

```gherkin
* add new timetable with user "admin_gui_user1":
    | ID            | Name      | Description |
    | NEW_TIMETABLE | Test Name | Test Desc   |
```

With specific effective type:

```gherkin
* add new inst with user "admin_gui_user2" by "tomorrow":
    | Inst. ID  | Inst. Class ID | Status [List] |
    | HSI_TEST  | HSIFUT          | A - Active    |
```

Supported entities for WS `add new`:
- `Maintain PTRM GUI User`, `Maintain Trading GUI User`, `Request External EIDP User`
- `timetable`, `market`, `Type`, `underlying`, `price`, `priceLimit`
- `option_class`, `future_class`, `inst`, `combo Type`, `combo class`, `combo`
- `Maintain Inst. Name Standard`, `Maintain Combo Name Standard`
- `Maintain Block Trade Group`, `Maintain Block Trade MVT`

### Update Record via WS

```gherkin
* update "Control Underlying Price" with ws user "admin_gui_user1" by "asap":
    | s:underlyingId | s:currency | s:date | s:source | s:sourceSymbolCode | s:price | s:status |
    | test_underlying| HKD        | 20260408 | MANUAL | TEST_SYMBOL        | 20000   | Active   |
```

### Get Page Data via WS

```gherkin
* Get "Maintain Inst. Type" page "instTypeSearchTable" save "arr_existing_trading_inst_type" keys "instTypeId,recordStatus,requestStatus" headers "Inst. Type ID,Record Status,Request Status" with user "admin_gui_user1" password "admin_gui_user1_password"
```

### Move Trading State via WS

```gherkin
* move the trading state with maker "admin_gui_user1" approve "admin_gui_user2":
    | Level | ID              | Target Trading State | Trading Session      | Action By       | Approve By      |
    |       | market_level_id | market_level_state   | market_level_session | admin_gui_user1 | admin_gui_user2 |
    | TYPE  | type_level_id   | type_level_state     | type_level_session   | admin_gui_user1 | admin_gui_user2 |
    | CLASS | class_level_id  | class_level_state    | class_level_session  | admin_gui_user1 | admin_gui_user2 |
```

### Set Trading State via WS

```gherkin
* set the trading state with maker "admin_gui_user1" approve "admin_gui_user2":
    | Level | ID              | Target Trading State | Trading Session      | Action By       | Approve By      |
    |       | market_level_id | market_level_state   | market_level_session | admin_gui_user1 | admin_gui_user2 |
```

### Batch Create via WS

```gherkin
* create "<page>" to max number record "<N>" by user "<user>" and ID column "<col>" with:
    | Field1 | Field2 |
    | val1   | val2   |
```

### Create Standard Combo via WS

Creates standard combo instruments with leg pairs from a template:

```gherkin
* Create Standard Combo with user "admin_gui_user2":
    | Combo Class ID | Status     | leg1        | leg2       | Clone From |
    | ASITS01        | A - Active | HSI_cm1_fut | HSI_sm_fut | HSI        |
```

### Regional Calendar via WS

```gherkin
* add "<number>" regional calendar with user "admin_gui_user1":
    | Regional Calendar ID | Name     | Normal Trading Days |
    | 4446                 | 4446TEST | 31                  |
```

### Add Trading State via WS Control Timetable

Adds a new trading state sequence via Control Trading Timetable Detail:

```gherkin
* add the trading state with maker "admin_gui_user1" approve "admin_gui_user2":
    | Level | ID              | Target Trading State | Trading Session | Action By       | Approve By      |
    |       | HHI             | PREOPEN              | AFTERNOON       | admin_gui_user1 | admin_gui_user2 |
    | TYPE  | HHI>HHIF        | PREOPEN              | AFTERNOON       | admin_gui_user1 | admin_gui_user2 |
    | CLASS | HHI>HHIF>MCHFUT | PREOPEN              | AFTERNOON       | admin_gui_user1 | admin_gui_user2 |
```

### Remove Trading State via WS

Removes a trading state sequence via Control Trading Timetable Detail:

```gherkin
* remove the trading state with maker "admin_gui_user1" approve "admin_gui_user2":
    | Level | ID              | Target Trading State | Trading Session | Action By       | Approve By      |
    |       | HHI             | PREOPEN              | AFTERNOON       | admin_gui_user1 | admin_gui_user2 |
```

### Exchange Participant Subtable via WS

Updates the instrument type subtable for a specific exchange participant:

```gherkin
* Update Exchange Participant Detail "MSBBB" Subtable with user "admin_gui_user1":
    | Inst. Type ID | Order Size Limit | Block Trade Size Limit | Default Account |
    | HSIF          | 9999             | 9999                   | acc1            |
* filterkey "Maintain Exchange Participant" with user "admin_gui_user1" password "admin_gui_user1_password" and approve "MSBBB" with user "admin_gui_user2"
```

### Access Group By Type - Instr/Subtable via WS

```gherkin
* Update Access Group By Type Detail "1" Inst. Type ID Subtable with user "admin_gui_user1":
    | Inst. Type ID |
    | HHIF          |
    | HSIF          |
* filterkey "Maintain Access Group By Type" with user "admin_gui_user1" password "admin_gui_user1_password" and approve "MSBBB" with user "admin_gui_user2"
```

### Access Group By Type - Combo/Subtable via WS

```gherkin
* Update Access Group By Type Detail "1" Combo Type ID Subtable with user "admin_gui_user1":
    | Combo Type ID |
    | HHI01         |
    | HHI02         |
* filterkey "Maintain Access Group By Type" with user "admin_gui_user1" password "admin_gui_user1_password" and approve "MSBBB" with user "admin_gui_user2"
```

### Add All Instr Type to Exchange Participant via WS

Populates Exchange Participant subtable from exported instrument type list:

```gherkin
* Get "Maintain Inst. Type" page "instTypeSearchTable" save "arr_existing_trading_inst_type" keys "instTypeId,recordStatus,requestStatus" headers "Inst. Type ID,Record Status,Request Status" with user "admin_gui_user1" password "admin_gui_user1_password"
* Add all "arr_existing_trading_inst_type" Instr Type to Exchange Participant Detail "MSBBB" Subtable with user "admin_gui_user1":
    | Order Size Limit | Block Trade Size Limit | Default Account |
    | 10000            | 10000                  | acc1            |
```

### Add All Combo Type to Access Group via WS

Populates Access Group subtable from exported combo type list:

```gherkin
* Add all "arr_existing_combo_type" Combo Type to Access Group By Type Detail "1" Combo Type ID Subtable with user "admin_gui_user1"
```

### Activate Account (EIDP Flow) via WS

End-to-end account activation with EIDP login, OCR captcha, email verification, and OTP:

```gherkin
* Activate account with:
    | eidp_user_id  | url             | env_no | email_url      | email_account      | email_account_pwd      | password |
    | 10026_BNP1009 | trading_gui_url | env_no | eidp_email_url | eidp_email_account | eidp_email_account_pwd | 123456   |
```

### Test Subscribe View (Debug) via WS

Used for testing WebSocket subscription views of multiple pages:

```gherkin
* Test subscribe view with user "admin_gui_user1"
```

### EXPORT Data via WS

Exports page data to a CSV array variable:

```gherkin
* EXPORT "Market" save "arr_existing_market"
```

### Supported WS Entity Mapping

The following is the complete list of entities supported by WS step implementations in `admin_gui_ws_class_steps.rb`:

| Step Type | Entity Names | Ruby Step Regex |
|---|---|---|
| `add new` | `Maintain PTRM GUI User`, `Maintain Trading GUI User`, `Request External EIDP User`, `timetable`, `market`, `Type`, `underlying`, `price`, `priceLimit`, `option_class`, `future_class`, `inst`, `combo Type`, `combo class`, `combo`, `Maintain Inst. Name Standard`, `Maintain Combo Name Standard`, `Maintain Block Trade Group`, `Maintain Block Trade MVT` | `add new (...)` regex match |
| `update` | Any page name with `filter_map-<page>` defined in `admin_gui_value.csv` | `update "(...)" with ws user` |
| `get page` | Any page with registered `subscribe_view` | `Get "(...)" page` |
| Trading State | set, add, remove, move | `set/add/remove/move the trading state with maker` |
| `filterkey` + approve | Any page needing maker-checker | `filterkey "(...)" with user` |
| `Create Standard Combo` | Combo from template | `Create Standard Combo with user` |
| Regional Calendar | `add "(...)" regional calendar` | `add "(...)" regional calendar with user` |
| `add newran timetable` | Custom timetable from JSON template | `add newran timetable with user` |

## Revision History

| Date | Author | Description |
|---|---|---|
| 2026-08-08 | AI Assistant | Extracted from Admin_GUI_Transform_Rules.md Rule 11 |
| 2026-08-08 | AI Assistant | Added all missing step definitions: Create Standard Combo, Regional Calendar, Set/Add/Remove Trading State, Exchange Participant Subtable, Access Group By Type, Add All Instr/Combo Type, Activate Account, Test Subscribe View, EXPORT, Supported WS Entity Mapping table |
