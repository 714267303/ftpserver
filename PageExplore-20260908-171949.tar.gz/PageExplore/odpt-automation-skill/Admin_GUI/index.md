# Admin GUI Rules Index

This index maps Admin GUI functionality to their corresponding rule files for lazy-loading during test case transformations.

## Usage Instructions

When transforming an Admin GUI test case:
1. **Load this index file first** (`Admin_GUI/index.md`)
2. **Load the PageExplore Grid API contract** (`${PAGEEXPLORE_ROOT}/qaGrid/Grid_API_Core_Index.md`) for any `hasGrid: true` page
3. **Load the executable UAT step index** (`../Step_Index.md`) before selecting a step
4. **Use `${PAGEEXPLORE_ROOT}/pages/INDEX.md`** to resolve the page route/profile, then load only that page profile
5. **Consult the observed flow index** (`Admin_GUI/Feature_Flow_Index.md`) when the case contains a repeated create, update, delete, countersign, sub-table, export, or WebSocket sequence
6. **Consult the PageExplore Admin observation index** (`${PAGEEXPLORE_ROOT}/qaGrid/Admin_GUI/Grid_API_Observation_Index.md`) when a case requires canvas-grid discovery, detail sub-table fields, or `qaGridApi` evidence
7. **Consult the repair-experience index** (`../repair_experience/INDEX.md`) for prior Feature repair findings; inbox and reviewed entries are quarantine evidence, not executable guidance
8. **Identify the Admin GUI functionality** based on:
   - Test case source file references
   - Page names in test steps (e.g., "Maintain Exchange", "Countersign Request")
   - Action names (e.g., "Generate ID", "Export CSV", "Add new record via WS")
   - Field names (e.g., "Price Tick ID", "MMP Parameter", "Trading State")
9. **Load only the corresponding functional rule file(s)**
10. **Do NOT load all Admin GUI rule files by default**
11. **If multiple functions are involved**, load only the required rule files
12. **If the function cannot be determined**, use this index, the observed flow index, the Grid API observation index, and the repair-experience index to select the best candidate or ask for clarification

## Function-to-Rule File Mapping

| Function | Keywords/Indicators | Rule File |
|---|---|---|
| **Background Setup** | Feature header, Background, Load value, dataSet, @FEATURE=Binary/WS/AdminGUI | `Background_Setup.md` |
| **General Navigation** | Login, browser, Save current browser, Switch browser, Clear Alert, Open browser, Screenshot, Wait | `General_Navigation.md` |
| **Left Menu Navigation** | Select Trading Admin Left Menu, menu path, Parent Menu, Child Menu, 73-item menu table | `Left_Menu_Navigation.md` |
| **ID Generation** | Assign, Generate ID, [RI1-255], [RS2], Generate series info, Time.now.strftime, Generate in range, Unique field value, Replace value, Get value by index/row | `ID_Generation.md` |
| **Form Data Operations** | Search in, Set/Check/Save Trading Admin, ComboBox, List, Key, Inh, Time, MuiCheckbox, Button/Input status check, Field error message, Field validity check, Dropdown list check | `Form_Data_Operations.md` |
| **Table Operations** | Check table contains visible rows, Double click table, Select table, Set table sort, canvastable fields, Table Name Convention | `Table_Operations.md` |
| **Detail Page Operations** | Sub-table, Add Table Item, Modify Table Item, Modify Auto-sort, Modify Table Admin GUI, Scroll, Scroll Sub Page, Go to Edit reference, Click arrow, Click card, Wait for loading, Change page size, Sub-table error | `Detail_Page_Operations.md` |
| **Buttons and Dialogs** | Click button, Confirm, Cancel, Close, New Record, More Actions, confirm message, Set Trading Admin format | `Buttons_and_Dialogs.md` |
| **Countersign Approval** | Countersign Request, Approve, Pending, Requester, Approver, admin_gui_user1/user2, Req Status, Exec Status, Record Status, Approve if updated, Create instrument series, Create Combo, Delete Block Trade | `Countersign_Approval.md` |
| **WebSocket Operations** | CONNECT WS, CLOSE CONNECT, add new, update, get page data, move trading state, set trading state, Presetting, @FEATURE=WS | `WebSocket_Operations.md` |
| **Effective Type Selection** | Update for tomorrow, Update effective asap, Delete for tomorrow, New record for tomorrow, New record effective asap, Current Record card, Effective button status, Effective type options | `Effective_Type_Selection.md` |
| **Export/Import File Operations** | Export CSV, export csv save to, Import file, Save field from export, Admin GUI page export, file operations | `Export_File_Operations.md` |
| **FIX Dumpfile Presetting** | Save FIX dumpfile, Load FIX dumpfile, Presetting, Day1, Day2, multi-file workflow | `Bigmap_Presetting.md` |
| **Step Definition Reference** | Complete step catalog, field suffixes, variable naming, Common Variable Naming, Advanced Operations | `Step_Definition_Reference.md` |
| **MMP Parameter** | MMP, Market Maker Protection, Maintain MMP Parameter, underlying_code, Include Futures, Quantity Protection, Delta Protection, Frozen Time | `MMP_Parameter.md` |
| **Price Tick** | Price Tick, Maintain Price Tick, Tick Size, Price Tick Detail, Order/Quotes, link to Instrument Class | `Price_Tick.md` |
| **Observed Feature Flows** | Repeated workflows mined from `uat/uat_admin_feature.txt`; corpus evidence, canonical composition, and extraction status | `Feature_Flow_Index.md` |
| **Grid API Observations** | Real `qaGridApi` calls, dynamic key patterns, column definitions, row schemas, and Playwright safety notes | `${PAGEEXPLORE_ROOT}/qaGrid/Admin_GUI/Grid_API_Observation_Index.md` |
| **Playwright → Feature conversion** | Reviewed flow manifest, evidence gates, standalone Admin validation, and deterministic converter commands | `Feature_Converter.md` |
| **Reusable Playwright flows** | Persisted, reviewed semantic Admin flows with evidence pointers and replay status | `flow_catalog/INDEX.md` |
| **Feature execution and diagnosis** | Run generated or manually edited Admin/Hybrid Features; inspect redacted reports and indexed error-code matches | `../Feature_Run_and_Debug.md` |

## Lazy-Loading Strategy

For any Admin GUI transform task:
1. **Load** `Admin_GUI/index.md` first
2. **Load** `${PAGEEXPLORE_ROOT}/qaGrid/Grid_API_Core_Index.md` and `../Step_Index.md`
3. **If the flow came from Playwright MCP**, load `Feature_Converter.md` and
   keep the raw recording as evidence rather than as a step source
4. **Search `flow_catalog/INDEX.md`** for a matching verified reusable flow before exploring again; treat observed/inferred entries as references only
5. **Search `../repair_experience/INDEX.md`** for known repair findings; reuse only entries marked `status=verified` and `safe_to_reuse=true`
6. **If a Feature already exists**, use `../Feature_Run_and_Debug.md` and run it through `tools/run_feature_debug.rb`; do not regenerate it just to execute it
7. **Identify the Admin GUI function** based on the transform request, source file, page name, or field names
8. **Load only the corresponding functional rule file(s)** from the mapping above
9. **Load the page profile** from `${PAGEEXPLORE_ROOT}/pages/` and follow its `gridApi` block
10. **Do NOT load all Admin GUI rule files by default** - this improves performance and reduces context window usage
11. **If multiple functions are involved**, load only the required rule files
12. **If the function cannot be determined**, use the Keywords/Indicators column in the mapping table, the repair-experience index, and the observed-flow indexes to select the best candidate or ask for clarification

## Example Usage

**Example 1: Maintaining Exchange Participant**
- Test case mentions: "Maintain Exchange Participant", "New Record", "Confirm"
- Match keywords: Select Trading Admin Left Menu (Left Menu Navigation), Set Trading Admin (Form Data), Click button Confirm (Buttons and Dialogs), Countersign (Countersign Approval)
- Load: `Admin_GUI/Left_Menu_Navigation.md`, `Admin_GUI/Form_Data_Operations.md`, `Admin_GUI/Buttons_and_Dialogs.md`, `Admin_GUI/Countersign_Approval.md`

**Example 2: WebSocket Presetting**
- Test case mentions: "add new timetable", "CONNECT WS", "@FEATURE=WS"
- Match keywords: CONNECT WS, add new, Presetting
- Load: `Admin_GUI/WebSocket_Operations.md`

**Example 3: Price Tick Creation**
- Test case mentions: "Maintain Price Tick", "Tick Size", "Generate ID"
- Match keywords: Price Tick, Tick Size, Price Tick Detail
- Load: `Admin_GUI/Price_Tick.md`

**Example 4: MMP Parameter Update**
- Test case mentions: "Maintain MMP Parameter", "underlying", "Include Futures"
- Match keywords: MMP, Market Maker Protection
- Load: `Admin_GUI/MMP_Parameter.md`

## Original File

The original combined `Admin_GUI_Transform_Rules.md` has been split into the 16 functional files listed above for improved lazy-loading and maintainability.

## Revision History

| Date | Author | Description |
|---|---|---|
| 2026-09-01 | AI Assistant | Added `Grid_API_Observation_Index.md` and persisted the three SMP ID List sub-table `qaGridApi` records |
| 2026-09-01 | AI Assistant | Added corpus-derived `Feature_Flow_Index.md` with repeated workflow evidence and extraction status |
| 2026-09-01 | AI Assistant | Linked shared Grid API and executable UAT step indexes; added converter routing prerequisites |
| 2026-09-01 | AI Assistant | Added `flow_catalog/` for persisted Playwright MCP Admin flows and replay status |
| 2026-09-01 | AI Assistant | Linked Feature execution/diagnosis wrapper and existing-Feature replay workflow |
| 2026-08-08 | AI Assistant | Created index file and split Admin_GUI_Transform_Rules.md into 16 functional rule files |
