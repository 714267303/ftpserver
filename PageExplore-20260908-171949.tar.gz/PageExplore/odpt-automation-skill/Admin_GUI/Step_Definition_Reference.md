# Step Definition Reference Rules

## Keywords
Complete step catalog, field suffixes, variable naming, Common Variable Naming, Advanced Operations

### Complete Step List by Category

| Category | Step Pattern | Example |
|---|---|---|
| **Browser** | `* Open browser` | Open new browser window |
| **Browser** | `* Save current browser to <session_name>` | `browser_admin_gui_user1` |
| **Browser** | `* Switch browser to <session_name> and maximize` | Switch between browser sessions |
| **Browser** | `* Close the browser` | Close current browser |
| **Login** | `* Login Trading Admin with:` | Admin GUI user login |
| **Navigation** | `* Select Trading Admin Left Menu "<path>"` | Navigate to any Admin GUI page |
| **Navigation** | `* Select effective type "<type>" in detail info page "<page>" "<card>" card` | Change effective type |
| **Navigation** | `* Scroll detail page "<page>" to "<pos>"` | Scroll to Bottom/Top/Mid |
| **Assign** | `* Assign ("<value>") to <variable>` | Store computed value |
| **Assign** | `* Generate ID info base on "<existing_data>":` | Generate unique IDs |
| **Assign** | `* Generate series info and save to :` | Generate instrument series info |
| **ID Gen** | `[RI1-255] : <var>` | Random string 1-255 chars |
| **ID Gen** | `[RS2] : <var>` | Random string 2 chars |
| **ID Gen** | `T_[RS3] : <var>` | Prefix + random string 3 chars |
| **Input** | `* Set Trading Admin "<page>" info as:` | Fill in detail page fields |
| **Input** | `* Save Trading Admin "<page>" info as:` | Read and store field values |
| **Search** | `* Search in Trading Admin "<page>" page with:` | Filter/search in admin table |
| **Check** | `* Check Trading Admin "<page>" info as:` | Verify displayed detail info |
| **Check** | `* Check Trading Admin "<page>" fields status as:` | Verify enable/disable status |
| **Table** | `* Check table "<name>" contains visible rows with:` | Verify rows in table |
| **Table** | `* Check table "<name>" contains rows with:` | Verify rows in sub-detail tables |
| **Table** | `* Check table "<name>" match rows count is "<N>" with:` | Verify row count |
| **Table** | `* Double click table "<name>" column "<col>" with:` | Open record via double-click |
| **Table** | `* Set table "<name>" sort by column "<col>" type "<Des\|Asc>"` | Set sort order |
| **Table** | `* Select table "<name>" rows with:` | Select multiple rows |
| **Table** | `* Check canvastable fields "<name>" with:` | Verify column headers exist |
| **Table** | `* Check canvastable fields "<name>" NOT display with:` | Verify column headers absent |
| **Sub-table** | `* Add Table Item in "<page>" info popup page with:` | Add row to detail sub-table |
| **Sub-table** | `* Modify Auto-sort Table Item in "<page>" info popup page with:` | Modify existing sub-table row |
| **Button** | `* Click button "<button>" in Trading Admin` | Global button click |
| **Button** | `* Click button "<button>" in Trading Admin detail info page "<page>"` | Detail page button |
| **Confirm** | `* Check the confirm message "<msg>" in Trading Admin detail info page "<page>" confirm window` | Verify confirmation dialog |
| **Export** | `* Admin GUI "<page>" page export csv save to "<file>" and read to "<var>"` | Export table to CSV |
| **FIX dump** | `* Save FIX dumpfile <name>` | Persist FIX maps and history messages |
| **FIX dump** | `* Load FIX dumpfile <name>` | Restore FIX maps and refresh references |
| **WS** | `* CONNECT WS with:` | Connect WebSocket connections |
| **WS** | `* CLOSE CONNECT with:` | Close WebSocket connections |
| **WS** | `* add new <entity> with user "<user>":` | Create record via WS |
| **WS** | `* add new <entity> with user "<user>" by "<eff_type>":` | Create with effective type via WS |
| **WS** | `* update "<entity>" with ws user "<user>":` | Update record via WS |
| **WS** | `* move the trading state with maker "<user>" approve "<user>":` | Move trading state via WS |
| **WS** | `* set the trading state with maker "<user>" approve "<user>":` | Set trading state via WS |
| **General** | `* Screenshot` | Capture screenshot |
| **General** | `* Clear Alert If Exist` | Dismiss browser alert |
| **General** | `* Wait <N> seconds` | Pause execution |

### Step Patterns for Advanced Operations

| Category | Operation | Step Pattern |
|---|---|---|
| **Workflow** | Create instrument series | `* Create instrument series if not exists :` |
| **Workflow** | Create combo | `* Create Combo if not exists :` |
| **Workflow** | Approve after update | `* Approve if updated with :` |
| **Workflow** | Delete Block Trade | `* Delete Block Trade Group "<ids>"` / `* Delete Block Trade MVT "<ids>"` |
| **Data** | Get value from export by index | `* Get value "<field>" index <N> from file "<data_key>" to "<var>"` |
| **Data** | Get value from export by row (with sub-table) | `* Get( sub table)? value "<field>" row <N> from file "<data_key>" to "<var>"` |
| **Data** | Save field from export | `* Save "<field>" from export data "<data_key>" and save to "<var>"` |
| **Data** | Generate in range | `* Generate "<col>" from "<page>" in range "<min-max>" and save to "<var>"` |
| **Data** | Unique field value | `* Set the value of field "<f1>" from file "<f2>" unique in existing records...` |
| **Data** | Replace value in bigmap | `* Replace the value of <key> from <old> to <new>` |
| **Import** | Import CSV file | `* Import file "<path>" in Trading Admin detail info page "<page>"` |
| **UI** | Change page size | `* Change "<page>" page "<width\|height>" size to "<N>"` |
| **UI** | Click card | `* Click card "<card>" in Trading Admin detail info page "<page>"` |
| **UI** | Click Admin button | `* Click the AdminGUI_Popup_Confirm_Btn` |
| **UI** | Click arrow to adjust | `* Click "up\|down" arrow to adjust "<field>"` |
| **UI** | Go to Edit reference | `* Go to Edit reference from "<field>" on Trading Admin detail info page "<page>"` |
| **UI** | Wait for loading | `* Wait for Trading Admin detail info page "<page>" loading with timeout "<seconds>"` |
| **Table** | Sort order check | `* Check table "<name>" sort by column "<col>" type "<Des\|Asc>" Data type "<int\|string>"` |
| **Table** | Select active instruments | `* Select the (total number\|list) of active instruments form the "<data_key>" where "<field>" is "<value>" and save to "<var>"` |
| **Table** | Modify Table Item popup | `* Modify Table Item in "<page>" info popup page with:` |
| **Table** | Modify Table inline | `* Modify Table in Admin GUI "<page>" page with:` |
| **Table** | Trigger Generation | `* Trigger Generation in Trading Admin "<page>" page with:` |
| **Sub-table** | Check sub-table error | `* Check massage "<msg>" display in detail info page "<page>" sub table "<sub>"` |
| **Scroll** | Scroll sub page | `* Scroll detail page sub page "<sub>" to "<position>"` |
| **Scroll** | Scroll sub table | `* Scroll "<page>" Detail page sub table "<sub>" to "<position>"` |
| **Button** | Button status check | `* Check button "<btn>" in Trading Admin detail info page "<page>" status is "<enable\|disable>"` |
| **Button** | Text input status check | `* Check text input "<field>" in Trading Admin detail info page "<page>" status is "<enable\|disable>"` |
| **Confirm** | Confirm message (search page) | `* Check the confirm message "<msg>" in Trading Admin search page confirm window` |
| **Confirm** | Confirm message (popup info page) | `* Check the confirm message "<msg>" in Trading Admin popup confirm window info page "<page>" confirm window` |
| **Confirm** | Popup confirm button | `* Click button "<btn>" in Trading Admin popup confirm window` |
| **Form** | Field validity check | `* Check Trading Admin detail info page "<page>" field "<field>" validity with:` |
| **Form** | Field error message | `* Check field "<field>" display error massage "<msg>" in detail info page "<page>"` |
| **Form** | Dropdown list check | `* Check Dropdown List "<Page>>Field" in Trading Admin with:` |
| **Effective** | Effective button status | `* Check effective "<btn>" botton status is "<disable\|enable>" in detail info page "<page>" "<card>" card` |
| **Effective** | Effective type options | `* Check effective type options "<opts>" in detail info page "<page>" "<card>" card` |

### Admin GUI Field Suffix Reference

| Suffix | Meaning | Example in Step |
|---|---|---|
| `[ComboBox]` | Dropdown with typeahead search | `Exchange ID [ComboBox]` |
| `[List]` | Single-select list | `Status [List]` |
| `[Key]` | Row matching key column | `Identifier [Key]` |
| `[Inh]` | Inherited from parent | `Normal Day Timetable ID [Inh] [ComboBox]` |
| `[Time]` | Time picker | `Start Time [Time]` |
| `[MuiCheckbox]` | Material UI checkbox group | `Normal Trading Days [MuiCheckbox]` |
| `[Key Up]` | Press key after input | `Exchange ID [Key Up]` |

### Variable Reference Syntax

| Syntax | Meaning | Example |
|---|---|---|
| `variable_name` | Reference a stored variable | `new_Exchange_id1` |
| `Identifier1` | Variable for countersign identifier | `Identifier1` → `new_Exchange_id1, new_Exchange_code1` |
| `exp_effective_date` | Expected effective date | `exp_effective_date` → `28-Jul-2026` |
| `file_name` | Dynamic file name | `file_name` → `exchange-202607281730.csv` |

### Common Variable Naming

| Variable Pattern | Purpose | Example |
|---|---|---|
| `new_<entity>_id<N>` | Newly created record ID | `new_Exchange_id1` |
| `new_<entity>_code<N>` | Newly created record code | `new_Exchange_code1` |
| `Identifier<N>` | Countersign identifier | `Identifier1` |
| `file_name` | Export CSV filename | `file_name` |
| `arr_existing_<entity>` | Array of existing records | `arr_existing_Exchange` |
| `exp_effective_date` | Expected effective date | `exp_effective_date` |
| `instrument_id<N>` | Instrument ID | `instrument_id1` |

## Revision History

| Date | Author | Description |
|---|---|---|
| 2026-08-08 | AI Assistant | Extracted from Admin_GUI_Transform_Rules.md Rule 16 |
| 2026-08-08 | AI Assistant | Replaced flat Advanced Operations table with comprehensive categorical catalog covering all 35 step patterns from admin_gui_steps.rb |
