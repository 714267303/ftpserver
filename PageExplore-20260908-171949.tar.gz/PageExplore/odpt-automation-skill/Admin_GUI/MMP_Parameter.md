# MMP Parameter Rules

## Keywords
MMP, Market Maker Protection, Maintain MMP Parameter, underlying_code, Include Futures, Quantity Protection, Delta Protection, Frozen Time

### Overview

MMP (Market Maker Protection) parameters are updated via Admin GUI with a Maker-Checker approval workflow. The underlying value is typically stored in the dataset CSV (e.g., `resource/dataSet-ODP11.csv`) and must be extracted to get the underlying code.

### Complete MMP Parameter Update Workflow

```gherkin
# ===== Step 1: Login Approver FIRST (browser 2) =====
* Open browser
* Login Trading Admin with:
    | User ID         | User Password            |
    | admin_gui_user2 | admin_gui_user2_password |
* Wait 1 seconds
* Clear Alert If Exist
* Save current browser to browser_admin_gui_user2

# ===== Step 2: Login Maker (browser 1) =====
* Open browser
* Login Trading Admin with:
    | User ID         | User Password            |
    | admin_gui_user1 | admin_gui_user1_password |
* Wait 1 seconds
* Clear Alert If Exist
* Save current browser to browser_admin_gui_user1
* Screenshot
* Select Trading Admin Left Menu "Participant>Maintain MMP Parameter"
* Wait 1 seconds
* Screenshot

# ===== Step 3: Extract underlying code from dataset =====
* Assign ("underlying"[0, 3]) to underlying_code
* Search in Trading Admin "Maintain Maintain MMP Parameter" page with:
    | Exchange Part. ID | Underlying ID   |
    | part1             | underlying_code |
* Wait 1 seconds

# ===== Step 4: Select the target record =====
* Double click table "Maintain MMP Parameter" column "Underlying ID" with:
    | Underlying ID [Key] |
    | underlying          |
* Wait 1 seconds

# ===== Step 5: Select Effective Type =====
* Select effective type "Update for as soon as possible" in detail info page "MMP Parameter Detail" "Current Record" card
* Wait 2 seconds

# ===== Step 6: Modify MMP Parameters =====
* Set Trading Admin "MMP Parameter Detail" info as:
    | Include Futures? [List] | Quantity Protection | Delta Protection | Exposure Time Limit Interval | Frozen Time |
    | Y - Yes                 | 20                  | 20               | 30                           | 10          |
* Screenshot

# ===== Step 7: Confirm the modification =====
* Click button "Confirm" in Trading Admin detail info page "MMP Parameter Detail"
* Check the confirm message "Proceed your action?" in Trading Admin detail info page "MMP Parameter Detail" confirm window
* Wait 1 seconds
* Click button "Confirm" in Trading Admin detail info page "MMP Parameter Detail" confirm window
* Wait 1 seconds

# ===== Step 8: Approve if updated =====
* Assign ("part1" + " " + "underlying_code") to identifier
* Approve if updated with :
    | Current Page         | Approver Browser        | Function Name          | Identifier | Requester       | Req Status |
    | MMP Parameter Detail | browser_admin_gui_user2 | Maintain MMP Parameter | identifier | admin_gui_user1 | Pending    |

# ===== Step 9: Switch back to maker =====
* Switch browser to "browser_admin_gui_user1" and maximize
```

### Key Points

| Aspect | Rule |
|---|---|
| **Underlying extraction** | Dataset value → extract first 3 chars via `Assign ("underlying"[0, 3]) to underlying_code` |
| **Exchange Part. ID** | Use `part1` (resolved variable) |
| **Approver login order** | Login **approver FIRST** (browser_admin_gui_user2), then **maker** (browser_admin_gui_user1) |
| **`Approve if updated` step** | Only for **modify** operations, NOT for create. Handles both: confirm success OR confirm failure |
| **Identifier format** | `"part1" + " " + "underlying_code"` → e.g., `BNP3001 PSI` |
| **Search page name** | `"Maintain Maintain MMP Parameter"` (note: "Maintain" appears twice) |
| **Detail page name** | `"MMP Parameter Detail"` |
| **Table name** | `"Maintain MMP Parameter"` |
| **Effective type** | `"Update for as soon as possible"` for immediate effect |

### Typical MMP Parameter Options

| Field | Values | Description |
|---|---|---|
| `Include Futures? [List]` | `Y - Yes`, `N - No` | Whether to include futures in MMP calculation |
| `Quantity Protection` | Integer | Max quantity without triggering MMP |
| `Delta Protection` | Integer | Max delta without triggering MMP |
| `Exposure Time Limit Interval` | Integer (seconds) | Time window for exposure calculation |
| `Frozen Time` | Integer (seconds) | Duration to freeze quoting after MMP trigger |

### When to Use This Pattern

- Test case precondition requires setting/modifying MMP parameters for a participant
- Test case involves Market Maker Protection (MMP) triggering scenarios (ODP11.x)
- Precondition mentions "MMP" or "Maintain MMP Parameter"

## Revision History

| Date | Author | Description |
|---|---|---|
| 2026-07-31 | Ken Huang | Initial version - Admin GUI MMP Parameter rules |
| 2026-08-08 | AI Assistant | Extracted from Admin_GUI_Transform_Rules.md Rule 17 |
