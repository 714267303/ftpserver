# Price Tick Rules

## Keywords
Price Tick, Maintain Price Tick, Tick Size, Price Tick Detail, Order/Quotes, link to Instrument Class

### Overview

Price Tick configuration is managed through Admin GUI under the "Price Supervision" menu. Price Tick defines the minimum price increment for trading instruments and must be linked to Instrument Classes.

### Feature Header Pattern for Price Tick

```gherkin
@FEATURE=Binary
Feature: ODP Admin GUI
Background:
	* Load value from admin_gui_value
	* Load value from dataSet-ODP2-value
	* Load object description from odp-web-object
```

### Price Tick Left Menu Path

```gherkin
* Select Trading Admin Left Menu "Price Supervision>Maintain Price Tick"
```

### Complete Price Tick Creation Workflow

```gherkin
# ===== Step 1: Export existing Price Tick data =====
* Assign ("price_ticks-" + Time.now.strftime("%Y%m%d%H%M%S") + ".csv") to file_name
* Admin GUI "Maintain Price Tick" page export csv save to "file_name" and read to "arr_existing_price_ticks"
* Click button "Close" in Trading Admin

# ===== Step 2: Generate Price Tick ID =====
* Generate ID info base on "arr_existing_price_ticks":
    | Price Tick ID          | Name                     |
    | [RI3] : new_price_tick_id1 | T_[RS3] : new_price_tick_name1 |

# ===== Step 3: Create new Price Tick record =====
* Click button "New Record" in Trading Admin
* Wait 2 seconds

# ===== Step 4: Fill Price Tick Detail form =====
* Set Trading Admin "Price Tick Detail" info as:
    | Price Tick ID     | Name                 | Description | Decimals | Default Lower Limit | Default Upper Limit | Block Trade Follow Order? [List] |
    | new_price_tick_id1 | new_price_tick_name1 | Automation  | 0        | 1                   | 45685               | Y - Yes                          |
* Screenshot

# ===== Step 5: Add Tick Size items for Order/Quotes =====
* Click the AdminGUI_PriceTick_Order/Quote_Add
* Wait 1 seconds
* Add Table Item in "Price Tick Order/Quotes" info popup page with:
    | Tick Size |
    | 1         |
* Screenshot

# ===== Step 6: Confirm =====
* Click button "Confirm" in Trading Admin detail info page "Price Tick Detail"
* Check the confirm message "Proceed your action?" in Trading Admin detail info page "Price Tick Detail" confirm window
* Wait 1 seconds
* Click button "Confirm" in Trading Admin detail info page "Price Tick Detail" confirm window
* Wait 1 seconds
* Check the confirm message "Your request has been sent." in Trading Admin detail info page "Price Tick Detail" confirm window
* Click button "Close" in Trading Admin detail info page "Price Tick Detail" confirm window

# ===== Step 7: Verify pending request =====
* Search in Trading Admin "Maintain Price Tick" page with:
    | Name                 |
    | new_price_tick_name1 |
* Check table "Maintain Price Tick" contains visible rows with:
    | Record Status | Req Action | Record Status | Name [Key]           | Decimals | Default Lower Limit | Default Upper Limit |
    | P             | Add        | P             | new_price_tick_name1 | 0        | 1                   | 45685               |

# ===== Step 8-9: Countersign approval workflow =====
* Assign ((Time.now + 86400).strftime("%d-%b-%Y")) to exp_effective_date
* Assign ("new_price_tick_id1" + " - " + "new_price_tick_name1") to identifier
* ... (follow Countersign approval pattern from Countersign_Approval.md) ...

# ===== Step 10: Verify approved =====
* Switch browser to "browser_admin_gui_user1" and maximize
* Check table "Maintain Price Tick" contains visible rows with:
    | Req Status | Req Action | Record Status | Name [Key]           |
    | A          | Add        | A             | new_price_tick_name1 |
```

### Link Price Tick to Instrument Class

```gherkin
* Select Trading Admin Left Menu "Inst. Hierarchy>Maintain Inst. Class"
* Search in Trading Admin "Maintain Inst. Class" page with:
    | Inst. Class ID |
    | HSDCALL        |
* Double click table "Maintain Inst. Class" column "Req Action" with:
    | Req Status | Req Action | Record Status | Inst. Class ID [Key] |
    |            |            | E             | HSDCALL              |
* Select effective type "Update for tomorrow" in detail info page "Inst. Class Detail" "Current Record" card
* Assign ("new_price_tick_id1" + " - " + "new_price_tick_name1") to new_price_tick_id_option
* Set Trading Admin "Inst. Class Detail" info as:
    | Price Tick ID [ComboBox] |
    | new_price_tick_id_option |
```

### Price Tick Fields

| Field | Type | Description |
|---|---|---|
| Price Tick ID | Key | Unique identifier |
| Name | Text | Name of the Price Tick |
| Description | Text | Description |
| Decimals | Number | Number of decimal places |
| Default Lower Limit | Number | Default lower price limit |
| Default Upper Limit | Number | Default upper price limit |
| Block Trade Follow Order? | List | Y - Yes / N - No |

### Price Tick Sub-Tables

| Sub-Table | Description |
|---|---|
| Price Tick Order/Quotes | Tick Size for regular orders and quotes |
| Price Tick Order Band | Price Tick ID, Price To, Tick Size |
| Price Tick Block Trade Band | Tick Size for block trades |

### Price Tick ID Generation

```gherkin
* Generate ID info base on "arr_existing_price_ticks":
    | Price Tick ID          | Name                     |
    | [RI3] : new_price_tick_id1 | T_[RS3] : new_price_tick_name1 |
```

**Key Points:**
- Price Tick ID: `[RI3]` generates 3-character random ID
- Price Tick Name: `T_[RS3]` generates prefix `T_` + 3-char random string
- Countersign identifier: `"new_price_tick_id1" + " - " + "new_price_tick_name1"`

### When to Use This Pattern

- Test case requires creating Price Tick records
- Test case involves linking Price Tick to Instrument Classes
- Precondition mentions "Price Tick" or "Maintain Price Tick"

## Revision History

| Date | Author | Description |
|---|---|---|
| 2026-08-05 | Ken Huang | Initial version - Price Tick Maintenance rules |
| 2026-08-08 | AI Assistant | Extracted from Admin_GUI_Transform_Rules.md Rule 18 |
