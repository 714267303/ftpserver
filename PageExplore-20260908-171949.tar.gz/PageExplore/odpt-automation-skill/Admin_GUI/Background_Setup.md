# Background Setup Rules

## Keywords
Feature header, Background, Load value, dataSet, @FEATURE=Binary, @FEATURE=WS, @FEATURE=AdminGUI

### Standard Feature Header

```gherkin
@FEATURE=Binary
Feature: ODP Admin GUI
    Create Date: <YYYY-MM-DD>
    Last Update: <YYYY-MM-DD>
    Author Name: AI Assistant
    Background:
        * Load value from admin_gui_value
        * Load value from dataSet-<ODPXX>-value
```

### Required Background Loads for Admin GUI

| Load Command | Purpose | Notes |
|---|---|---|
| `admin_gui_value` | Admin GUI user credentials, field mappings, canvas_id_mapping | Always required |
| `dataSet-ODPXX-value` | Test data values for the specific ODP domain | Always required |
| `dataSet-ODPXX` | Parameter data like `instrument_id1` | Required when using instrument/ID parameters |
| `dataSet-trading-state-value` | Trading state test values | Required for trading state features |
| `dataSet-trading-state` | Trading state parameter data | Required for trading state features |

### Feature Tag Patterns

| Tag | When to Use | Example |
|---|---|---|
| `@FEATURE=Binary` | Binary interface testing (default for most Admin GUI features) | Most 4.x tests |
| `@FEATURE=AdminGUI` | Pure Admin GUI testing | Some 4.14 Participant tests |
| `@FEATURE=WS` | WebSocket API testing | Presetting features, Trading State |

### Standard Feature Header Patterns

#### Pattern A: Binary Feature (Most Common - 4.2 Hierarchy, 4.8, 4.9, 4.10, 4.14, 4.15)

```gherkin
@FEATURE=Binary
Feature: ODP Admin GUI
Create Date: 2025-01-02
Last Update: 2025-01-02
Author Name: AI Assistant

Background:
	* Load value from admin_gui_value
	* Load value from dataSet-ODP14a-value
```

#### Pattern B: WS Feature (Presetting, Trading State)

```gherkin
@FEATURE=WS
Feature: ODP Admin GUI
Create Date: 2026-04-01
Last Update: 2026-04-01
Author Name: AI Assistant
Background:
	* Load value from admin_gui_value
	* Load value from dataSet-trading-state-value
	* Load parameters from csv dataSet-trading-state
```

#### Pattern C: AdminGUI Tag (Participant Management)

```gherkin
@FEATURE=AdminGUI
Feature: ODP Admin GUI
Create Date: 2025-01-02
Last Update: 2025-01-02
Author Name: AI Assistant

Background:
	* Load value from admin_gui_value
	* Load value from dataSet-ODP14a-value
```

#### Pattern D: CreateProduct / WS with FIX Dumpfile

```gherkin
@FEATURE=WS
Feature: ODP Admin GUI
Create Date: 2026-04-08
Last Update: 2026-04-08
Author Name: AI Assistant
Background:
	* Load value from admin_gui_value
	* Load value from dataSet-Presetting-CreateProduct-value
	* Load FIX dumpfile ODP14a.4.2.2.7.Presetting
```

## Revision History

| Date | Author | Description |
|---|---|---|
| 2026-08-08 | AI Assistant | Extracted from Admin_GUI_Transform_Rules.md Rules 1-2 |
