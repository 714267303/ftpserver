@FEATURE=Binary
@CASE=ODP10.1.6
Feature: Binary order flow

Scenario: Place orders
	* Set ISODP true
	* ODPBroker1 send:
		| MyRef | MessageID | SecurityID | Side | OrderQty |
		| O1    | 21         | instrument1 | 1    | 10       |
