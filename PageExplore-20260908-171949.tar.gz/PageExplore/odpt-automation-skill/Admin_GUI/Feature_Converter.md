# Admin GUI Feature Converter

## Purpose

`tools/admin_feature_converter.py` turns a reviewed Admin-flow manifest into
the Ruby/Cucumber Gherkin used by this project.  It is deliberately a
semantic conversion boundary:

```text
rollback-validation Playwright evidence -> reviewed flow manifest -> UAT step validation -> Feature execution
```

The converter does **not** translate arbitrary Playwright locators or browser
JavaScript into executable steps.  A locator, screenshot, network trace, or
`qaGridApi` call is evidence used to write the manifest; the generated Feature
must use a step already implemented by the UAT runtime.

The converter supports two explicit output modes. The integrated batch uses
the standalone mode for both Admin and Hybrid manifests so Admin behavior can
be compared, run, and repaired independently:

| Channel | Input | Output |
|---|---|---|
| `admin` | Admin setup manifest | Stand-alone Admin GUI Feature |
| `hybrid` (batch default) | Hybrid Admin manifest + `--standalone-admin` | Independent `<case>.admin.feature`; non-Admin continuation is generated later |
| `hybrid` (manual legacy composition) | Admin setup manifest + `--base-feature` | One combined Feature; not used by the batch validation/repair pipeline |

The runtime remains Ruby/Cucumber (`wabi-fix` plus the local UAT steps).  Do
not mix Python Behave/Web Playwright steps into a Ruby Feature unless a
separate, explicitly approved paired-runtime plan is being used.

## Evidence Contract

The manifest records provenance but does not promote evidence automatically.
Use one of these statuses:

| Status | Meaning | Converter behavior |
|---|---|---|
| `verified` | Rollback-validation Playwright pass succeeded, cleanup was proven, and every emitted action maps to an executable UAT step | Generates normally |
| `observed` | Captured once, or the mapping is not yet replayed | Generates a draft with `@REVIEW` |
| `inferred` | Derived from naming/documentation only | Generates a draft with `@REVIEW` |

An Admin flow should be promoted to `verified` only after:

1. The route and page profile were identified from
   `${PAGEEXPLORE_ROOT}/sitemap.md` and `${PAGEEXPLORE_ROOT}/pages/`.
2. A fresh Playwright MCP validation pass submitted and then Rejected the
   maker request (or Cancelled before save), proving that no pending or active
   change remained. MCP did not execute final Approve.
3. Any Grid key was discovered at runtime using the pattern in
   [`${PAGEEXPLORE_ROOT}/qaGrid/Grid_API_Core_Index.md`](../../pageExplore/qaGrid/Grid_API_Core_Index.md), never copied with a
   UUID from a log.
4. The relevant `getColumnDefs()` and a redacted row shape were recorded when
   a table was involved.
5. Every action was mapped to a signature in [`Step_Index.json`](../Step_Index.json).
   A required final approval is included as
   `mcp_execution=deferred_to_feature`, and the resulting Feature executed and
   passed before reuse was enabled.

### Session and persistence safeguards

`Login Trading Admin with:` is a one-session operation. A manifest table must
contain only one distinct user (repeated rows are reserved for an explicit
expected-login-error retry). For maker/checker workflows, emit one complete
sequence per user:

```gherkin
* Open browser
* Login Trading Admin with:
    | User ID         | User Password            |
    | admin_gui_user1 | admin_gui_user1_password |
* Save current browser to browser_admin_gui_user1

* Open browser
* Login Trading Admin with:
    | User ID         | User Password            |
    | admin_gui_user2 | admin_gui_user2_password |
* Save current browser to browser_admin_gui_user2
```

The converter adds `MULTI_USER_LOGIN_REQUIRES_SEPARATE_BROWSER_SESSIONS` to
the review report when more than one distinct user appears in a login table.
Resolve that reason before strict conversion. For Binary/Hybrid lifecycle
state, use `Save FIX dumpfile <name>` and `Load FIX dumpfile <name>`; the
contract is documented in `Binary_Interface/Dumpfile_Operations.md`.

The three records in
`${PAGEEXPLORE_ROOT}/evidence/qaGrid/odp_admin_gui_grid_api.log` are useful evidence for
the SMP ID List detail sub-table.  They do not by themselves make the flow
verified.  In particular, a `setRowData()` record must never become a generated
mutation step; use the normal Add/Modify table UI step.

## Manifest Schema (v1)

The converter accepts JSON with this shape:

```json
{
  "schema_version": 1,
  "flow_id": "admin.odp10.1.6.smp_id_list.v1",
  "case_id": "ODP10.1.6",
  "name": "Configure Admin state before binary order flow",
  "channel": "hybrid",
  "evidence_status": "verified",
  "page": {
    "label": "Maintain SMP ID List",
    "route": "/UI/uiSmpIdListSearchTable",
    "profile": "pageExplore/pages/uiSmpIdListSearchTable.md"
  },
  "tags": ["@FEATURE=Binary"],
  "background": [
    "Load value from admin_gui_value"
  ],
  "steps": [
    "Open browser",
    {
      "text": "Login Trading Admin with:",
      "table": [
        ["User ID", "User Password"],
        ["admin_gui_user1", "admin_gui_user1_password"]
      ]
    },
    "Clear Alert If Exist",
    "Save current browser to browser_admin_gui_user1",
    "Select Trading Admin Left Menu \"Participant>Maintain SMP ID List\"",
    {
      "text": "Search in Trading Admin \"Maintain SMP ID List\" page with:",
      "table": [
        ["SMP ID List ID"],
        ["smp_id_list1"]
      ]
    },
    {
      "text": "Check table \"Maintain SMP ID List\" contains visible rows with:",
      "table": [
        ["SMP ID List ID", "Record Status"],
        ["smp_id_list1", "A"]
      ]
    }
  ],
  "source_coverage": [
    {
      "yaml_step_index": 1,
      "flow_step_indices": [1, 2, 3, 4, 5, 6, 7],
      "intent": ["navigation", "search", "verify"]
    }
  ],
  "evidence": {
    "playwright_run": "outputs/admin/ODP10.1.6/run-001",
    "grid_trace": "outputs/admin/ODP10.1.6/trace.jsonl",
    "grid_summary": "outputs/admin/ODP10.1.6/api-summary.json"
  },
  "reuse": {
    "keywords": ["SMP ID List", "Maintain SMP ID List"],
    "safe_to_reuse": false
  },
  "review": []
}
```

### Required and optional fields

| Field | Required | Notes |
|---|---|---|
| `schema_version` | yes | Must be `1` |
| `flow_id` | yes for catalog/batch | Stable ID matching the catalog schema |
| `case_id` | yes | Stable case identifier, not a UUID |
| `name` | yes for catalog/batch | Human-readable flow name |
| `channel` | yes | `admin` or `hybrid` |
| `evidence_status` | yes | `verified`, `observed`, or `inferred` |
| `background` | no | Steps emitted under Gherkin `Background` |
| `steps` | yes | Non-empty array of strings or `{text, table, mcp_execution}` objects |
| `source_coverage` | yes in batch | Every 1-based Admin YAML TestSteps entry maps to non-empty 1-based flow step indexes; every flow step must be covered |
| `page` | yes for catalog/batch | Object containing exact `/UI/` route and PageExplore profile |
| `evidence` | yes for catalog/batch | Object with paths/IDs for traceability; do not put secrets here |
| `reuse` | yes for catalog/batch | Includes `keywords` and boolean `safe_to_reuse` |
| `review` | no | Human review notes; each note forces `@REVIEW` |

Tables may be arrays of arrays or arrays of objects.  Object tables derive the
header order from first appearance of each key.  Password/secret/token cells
that are literal values are replaced with `<REVIEW_SECRET>`; use environment
or value-file placeholders such as `admin_gui_user1_password` instead.
`mcp_execution` is optional for ordinary steps. Set it to
`deferred_to_feature` on final approval steps: the converter still emits the
step, while the field records that MCP validated its Step_Index mapping without
clicking the live approval action. `validated_read_only` may annotate an
ordinary step that MCP inspected without mutation.

## Step Source Priority

When converting Admin manifests or repairing generated Features, prefer
executable steps in this order:

1. Current project `features/customized_steps/**/*.rb`.
2. `Step_Index.json` generated from the same runtime/customized steps.
3. Existing verified Feature examples and verified Admin flow manifests.
4. Skill rules, ODP documents, and PageExplore profiles as guidance only.
5. Emit `@REVIEW` when no executable step can be proven.

The converter searches `Step_Index.json` before using its conservative prefix
fallback. When a populated index is present, a prefix alone cannot make an
unmatched action executable. The prefix fallback is only for degraded mode
when the index is unavailable, and that mode adds
`STEP_INDEX_UNAVAILABLE:PREFIX_FALLBACK_IS_NON_AUTHORITATIVE` to the review
report. `step_matches` records the matched signature, runtime source, line,
authority, and `match_source` for every background/scenario step.

## Step Mapping

The converter checks the normalized text against `Step_Index.json` and a
conservative Admin vocabulary.  These are the usual mappings:

| Exploration intent | Existing UAT step family |
|---|---|
| Open/login/session | `Open browser`, `Login Trading Admin with:`, `Save current browser to ...` |
| Menu/route | `Select Trading Admin Left Menu "..."` |
| Search/filter | `Search in Trading Admin "..." page with:` and Apply button steps |
| Form edit/save | `Set Trading Admin "..." info as:`, `Save Trading Admin "..." info as:` |
| Row detail | `Double click table "..." column "..." with:` |
| Grid assertion | `Check table "..." contains visible rows with:`, `Check table "..." rows count ...` |
| Sub-table add/update | `Add Table Item in "..." info popup page with:`, `Modify Table Item in ...` |
| Effective date | `Select effective type "..." in detail info page ...` |
| Countersign | Prefer the shortest applicable maintained operation such as `Approve if updated with :`; mark final approval `mcp_execution=deferred_to_feature` and execute it only in the Feature |
| Grid scroll/selection | Existing `Scroll`, `Select table`, and table-operation steps |
| WebSocket presetting | `CONNECT WS with:`, `add new ...`, `update ...`, `CLOSE CONNECT ...` |
| Evidence only | `Screenshot`, `Wait`, `Get value`, and comments; keep business assertions in UAT steps |

When a new reusable action is genuinely needed, add it to the UAT source
first, regenerate `Step_Index.json`, and then use it in a manifest.  Do not
hide an unimplemented action behind a converter prefix.

## Playwright MCP Handoff

The exploration-to-feature handoff is intentionally a two-pass process.

### Pass 1: Validate and capture

Use `${PAGEEXPLORE_ROOT}/sitemap.md` before navigation, the relevant page profile before page work,
and the Grid indexes for canvas tables.  Capture, in a run directory:

```text
run-001/
  trace.jsonl             # actions, screenshots, route and errors
  api-summary.json        # redacted qaGridApi method/key/field summary
  screenshots/            # optional visual evidence
  notes.md                # business intent and review decisions
```

The raw recording may contain locators, dynamic UUIDs, timestamps, or secrets.
It is evidence, not a Feature source.  Normalize it into the manifest by
choosing an existing UAT signature and supplying its table arguments.
For maker/checker cases this pass submits the maker request, validates the
pending countersign request, then uses checker Reject as mandatory cleanup.
For cases without countersign it Cancels before persistent save. Never click
Approve. Reject/Cancel is evidence-only and must not be emitted into the
manifest; required Approve remains a deferred semantic step executed by the
generated Feature.

The integrated batch validates the handoff before catalog persistence. It can
mechanically recover common shape mistakes (`page_route` to `page.route`,
`uat_step` to `text`, and missing profile/catalog defaults when the exact route
has one unique profile). Before Feature generation it builds a contract for all
pages directly from `sitemap.md` and their profiles. The declared page route,
profile, label, sidebar parent/child, current browser page, Search/table/detail
page names, and DataTable fields must agree. A uniquely provable bad menu is
corrected with an audit record; an ambiguous conflict or missing navigation is
blocked. The transcript must contain a completed Playwright result that
observed the declared route, not merely a locator script that mentioned it.

The `source_coverage` map separately proves that no Admin source TestStep or
flow step was silently dropped. Existing human-authored examples such as
`uat/uat_admin_feature.txt` may corroborate normal ordering and wording during
repair, but are read-only evidence and never override sitemap, the page
profile, or Step_Index. None of these checks treats a rewrite as proof that
browser prose is executable. If validation still finds unknown wording, a
missing DataTable, incomplete source coverage, or a page-contract error, the
batch starts at most one browser-free semantic repair pass. That pass cannot
use Playwright, credentials, shell, network, or business actions, so a
completed and rolled-back MCP run is never repeated just to repair JSON.
An actual behavior/evidence gap—missing navigation, search, detail open,
mutation, submission, checker session, effective-date handling, or requested
postcondition—is not repairable offline. The candidate is discarded and a
fresh rollback-validation MCP run is required; documentation is never used to
invent an action that the captured flow omitted.

### Pass 2: Convert and review

```bash
python3 tools/admin_feature_converter.py \
  --flow outputs/admin/ODP10.1.6/admin-flow.json \
  --page-explore-root pageExplore \
  --standalone-admin \
  --output features/test_case/10007/ODP10.1.6.admin.feature \
  --report outputs/admin/ODP10.1.6/conversion-report.json \
  --step-index odpt-automation-skill/Step_Index.json
```

Verify that an existing standalone Admin Feature still has exactly the same
Background, ordered steps, and DataTables as the MCP semantic flow:

```bash
python3 tools/admin_feature_converter.py \
  --flow outputs/admin/ODP10.1.6/admin-flow.json \
  --page-explore-root pageExplore \
  --standalone-admin \
  --verify-feature features/test_case/10007/ODP10.1.6.admin.feature \
  --step-index odpt-automation-skill/Step_Index.json \
  --semantic-strict
```

Manual legacy composition remains available, but the batch does not use this
form for Admin validation or repair:

```bash
python3 tools/admin_feature_converter.py \
  --flow outputs/admin/ODP10.1.6/admin-flow.json \
  --page-explore-root pageExplore \
  --base-feature features/test_case/10007/ODP10.1.6.binary.feature \
  --output features/test_case/10007/ODP10.1.6.feature \
  --report outputs/admin/ODP10.1.6/conversion-report.json \
  --strict
```

`--strict` is for a reviewed flow.  It exits non-zero if the manifest has an
unknown step, non-`verified` evidence, or a review note.  Without `--strict`,
the output remains useful as a draft but receives `@REVIEW` and the report
lists every reason.

To check Step_Index executability without rendering a Feature or requiring the
pre-promotion evidence status to be `verified`:

```bash
python3 tools/admin_feature_converter.py \
  --flow outputs/admin/ODP10.1.6/admin-flow.json \
  --step-index odpt-automation-skill/Step_Index.json \
  --validate-only --semantic-strict
```

This also fails when a matched runtime step requires a Cucumber DataTable but
the manifest omitted it (for example `Approve if updated with :`), or when the
menu/page/profile/field state machine is inconsistent. To apply only uniquely
provable PageExplore corrections to an isolated candidate before validation:

```bash
python3 tools/admin_feature_converter.py \
  --flow outputs/admin/ODP10.1.6/admin-flow.json \
  --page-explore-root pageExplore \
  --normalize-page-contract
```

This command never guesses an ambiguous page; unresolved issues return a
non-zero result and remain visible in its JSON output.

The raw recorder shortcut is available for triage:

```bash
python3 tools/admin_feature_converter.py \
  --recording-flow outputs/admin/ODP10.1.6/recording.flow.json \
  --case-id ODP10.1.6 \
  --output /tmp/ODP10.1.6.review.feature \
  --report /tmp/ODP10.1.6.review.json
```

This intentionally emits a review draft rather than guessing UAT steps.

## Reusing A Playwright-Explored Flow

Persist reviewed flows in [`flow_catalog/INDEX.md`](flow_catalog/INDEX.md).
The catalog manifest is the stable input to this converter; the raw trace and
screenshots remain in the referenced run directory. Search the catalog by
route, keywords, or `flow_id` before starting a new exploration. Only a flow
marked `evidence_status: verified` and `reuse.safe_to_reuse: true` is eligible
for unattended strict conversion. `observed` and `inferred` entries are useful
templates, but require a fresh clean replay and review first.

Refresh the catalog after adding or promoting a flow:

```bash
python3 tools/build_admin_flow_catalog.py
python3 tools/build_admin_flow_catalog.py --check
```

The persisted manifest must contain semantic UAT steps, page profile and
redacted Grid evidence. Do not copy Playwright locators, `window.qaGridApi`
JavaScript, dynamic dialog UUIDs, passwords, or raw `setRowData` calls into the
manifest or generated Feature.

## Manual Legacy Hybrid Composition Contract

This section documents only the explicit manual `--base-feature` compatibility
mode. The batch pipeline does not use it: batch Hybrid conversion validates a
standalone Admin Feature and separate non-Admin lifecycle Feature(s). A
next-trading-day case uses Day1/Day2 plus the execution-flow JSON documented
in `../conversion-rules.md`. When a caller
deliberately selects the legacy mode, `channel=hybrid` composes the Admin setup
into the same Feature as the Binary base. The converter inserts setup before
`* Set ISODP true` when that marker exists; otherwise it inserts immediately
after the Scenario declaration.
The resulting order is:

```text
Admin login/session
  -> Admin navigation/search/form/table/countersign
  -> optional close or browser switch
  -> Set ISODP true
  -> Binary send/expect steps
```

The Binary body remains owned by the existing Binary transformation rules.
The Admin manifest owns only setup and its assertions.  If the setup creates
data needed by Binary, use stable value/dataset placeholders and record the
dependency in `evidence` or a short comment; never carry a dynamic Grid UUID
or transaction ID into the Feature.

## Failure and Review Contract

The converter fails hard for malformed JSON, unsupported channel/schema,
missing steps, missing base Feature, or invalid table structure.  It does not
silently drop an unknown action.  Non-fatal review reasons are written to the
report and rendered as comments, for example:

```text
@REVIEW
# REVIEW: UNKNOWN_STEP:4:Click a locator that has no UAT mapping
# REVIEW: EVIDENCE_STATUS:observed
```

Before committing a generated Feature:

1. Resolve every `@REVIEW` reason.
2. Run the Ruby/Cucumber dry run available in the target checkout.
3. Replay the Admin setup and confirm the expected Grid/form assertions.
4. Preserve the manifest, report, and evidence paths next to the generated
   artifact or in the approved run store.

## Maintenance

When UAT step definitions change, regenerate `Step_Index.json` from
`uat/uat_step.txt` (or the runtime Ruby sources) with
`tools/build_step_index.py`.  When a new Grid observation is captured,
regenerate `${PAGEEXPLORE_ROOT}/qaGrid/qaGridApi_Index.json`/`.md` with
`tools/build_grid_api_index.py`, then promote only the relevant page profile
from `inferred`/`observed` to `verified` after replay.

## Revision History

| Date | Change |
|---|---|
| 2026-09-05 | Prioritized runtime/customized Step_Index matches, made prefix-only matches non-authoritative, and added per-step source traceability |
| 2026-09-01 | Added manifest schema, Playwright MCP handoff, hybrid composition, evidence gates, and converter commands |
