# Detail Page Operations Rules

## Keywords
Sub-table, Add Table Item, Modify Table Item, Modify Auto-sort Table Item, Modify Table Admin GUI, Scroll detail page, Scroll sub page, Go to Edit reference, Click arrow, Click card, Wait for loading, Change page size, Check sub-table error

### Add Sub-table Item (Detail Page Popup)

Used for adding rows to sub-tables on detail pages (e.g., Exchange Participant > Inst. Type Limits, Timetable > Trading Sessions):

```gherkin
* Scroll detail page "<Detail Page>" to "Bottom"

* Click button "Add" in Trading Admin detail info page "<Detail Page>"
* Wait 1 seconds
* Add Table Item in "<Detail Page>" info popup page with:
    | Inst. Type ID [ComboBox] | Order Size Limit | Block Trade Size Limit | Default Account |
    | 134F - 134 FUTURES       | 1000             | 1000                   | Account1        |
* Screenshot
```

### Modify Auto-sort Table Item

```gherkin
* Modify Auto-sort Table Item in "<Detail Page>" info popup page with:
    | Start Time [Key] | Trading Session [List] | Start Logical Day Ind [List] | Trading State ID [ComboBox] | Start Time [Time] |
    | 09:00:00         | 2 - Afternoon          | 1 - T+1                      | 14 - OPEN_PL                | 17:00:00          |
```

### Scroll Operations

```gherkin
* Scroll detail page "<Detail Page>" to "Bottom"
* Scroll detail page "<Detail Page>" to "Top"
* Scroll detail page "<Detail Page>" to "Mid"
```

**Supported positions:** `Bottom`, `Top`, `Mid`, `Left`, `Right`, `MidX`, `75 Percent`, `75 PercentX`

### Modify Table Item in Popup

Modify existing rows in a popup sub-table:

```gherkin
* Modify Table Item in "Combo Leg" info popup page with:
    | Operation [List] | Ratio | Leg Instrument ID [ComboBox] |
    | B - Buy          | 1     | instrument_id1               |
```

### Modify Table in Admin GUI Page

Modify table rows inline on admin GUI pages (e.g., Control & Monitor Price Limit):

```gherkin
* Modify Table in Admin GUI "Control & Monitor Price Limit" page with:
    | ID:Inst. ID [Key]     | Static Price Limits:Ref Price |
    | instrument_id1        | 10000                         |
```

**Key Points:**
- Uses `CanvasTable` with mode `"admin_gui"` instead of `"popup"`

### Scroll Sub Page

Scroll a named sub-section within a detail page:

```gherkin
* Scroll detail page sub page "Static Price Limit" to "Bottom"
```

### Scroll Detail Page Sub Table

Scroll a nested sub-table within a detail page:

```gherkin
* Scroll "Price Limit Parameters" Detail page sub table "Trading Halt Inst. Class ID" to "Bottom"
```

**Key Points:**
- Supports custom xpath via `@object_hash` key pattern: `AdminGUI_<pageName>_<subName>Table`

### Check Sub-Table Error Message

Check error messages displayed on sub-tables:

```gherkin
* Check massage "Date: is a mandatory field" display in detail info page "Non-Trading Days" sub table "Non-Trading Days Item"
```

### Go to Edit Reference (External Link)

Navigate to a linked reference entity via the external link icon next to a field:

```gherkin
* Go to Edit reference from "Price Tick ID" on Trading Admin detail info page "Inst. Class Detail"
```

### Click Arrow to Adjust Number

Increment/decrement number input fields using spinner arrows:

```gherkin
* Click "up" arrow to adjust "Price Quotation Factor"
* Click "down" arrow to adjust "Price Quotation Factor"
```

### Click Card in Detail Page

Click on a card grid item within a detail page:

```gherkin
* Click card "Update Record" in Trading Admin detail info page "TMC Strategy List Detail"
```

### Wait for Detail Page Loading

Explicitly wait for a detail page to finish loading:

```gherkin
* Wait for Trading Admin detail info page "Exchange Detail" loading with timeout "30"
```

**Key Points:**
- Timeout is in seconds
- Waits for loading spinner to disappear or "please hold on." message to resolve

### Change Page Size

Resize a detail page width or height via JavaScript:

```gherkin
* Change "Exchange Participant Detail" page "width" size to "1800"
```

**Key Points:**
- Type: `width` or `height`
- Size: pixel value

## Revision History

| Date | Author | Description |
|---|---|---|
| 2026-08-08 | AI Assistant | Extracted from Admin_GUI_Transform_Rules.md Rule 8 |
| 2026-08-08 | AI Assistant | Added Modify Table Item/Modify Table/Scroll Sub Page/Goto Reference/Click Arrow/Click Card/Wait Loading/Change Size/Sub-Table Error |
