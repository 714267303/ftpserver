# Form Data Operations Rules

## Keywords
Search in, Set/Check/Save Trading Admin, ComboBox, List, Key, Inh, Time, MuiCheckbox, Button status, Text input status, Field error message, Field validity, Dropdown list check

### Search in a Page (Filter Table)

```gherkin
* Search in Trading Admin "Maintain Exchange" page with:
    | Exchange ID      |
    | new_Exchange_id1 |
* Wait 1 seconds
* Screenshot
```

**Key Points:**
- The table name matches the page title
- Multiple search fields can be combined
- Search uses an AND condition

### Set Detail Info (Create/Update Record Fields)

```gherkin
* Set Trading Admin "Exchange Detail" info as:
    | Exchange ID      | Exchange Code      | Description         | Short Name       |
    | new_Exchange_id1 | new_Exchange_code1 | test for automation | new_Exchange_id1 |
* Screenshot
```

### Set Detail Info with ComboBox / List Fields

```gherkin
* Set Trading Admin "Exchange Participant Detail" info as:
    | Exchange Part. ID     | Exchange ID [ComboBox] | Company ID [ComboBox] | Suspended? [List] | Description |
    | new_exchange_part_id1 | HK - HKFE              | 1 - ODP_HSBC          | N - No            | HSBC        |
```

### Save Detail Info (Read/Verify Fields)

```gherkin
* Save Trading Admin "<Detail Page>" info as:
    | Field1 | Field2 |
    | var1   | var2   |
```

### Check Detail Info (Verify Displayed Values)

```gherkin
* Check Trading Admin "Countersign Request Detail" info as:
    | Requester       | Identifier  | Function Name                 | Request Action | Request Status | Execution Status | Effective Date     |
    | admin_gui_user1 | Identifier1 | Maintain Exchange Participant | Add            | Pending        | Pending          | exp_effective_date |
```

### Check Fields Status (Enable/Disable)

```gherkin
* Check Trading Admin "<Detail Page>" fields status as:
    | Trading Timetable ID |
    | disable              |
```

### Set Sort Order on Table

```gherkin
* Set table "<Table Name>" sort by column "<Column>" type "<Des|Asc>"
```

### Field Naming Conventions

| Suffix | Meaning | Example |
|---|---|---|
| `[ComboBox]` | Dropdown selection field | `Exchange ID [ComboBox]` |
| `[List]` | Single-select list | `Status [List]` |
| `[Key]` | Key column for row matching | `Exchange ID [Key]` |
| `[Inh]` | Inherited value (from parent) | `Normal Day Timetable ID [Inh] [ComboBox]` |
| `[Time]` | Time input field | `Start Time [Time]` |
| `[MuiCheckbox]` | Material UI checkbox | `Normal Trading Days [MuiCheckbox]` |

### Check Button Status in Detail Page

Verify whether a button in a detail page is enabled or disabled:

```gherkin
* Check button "Confirm" in Trading Admin detail info page "Exchange Detail" status is "disable"
* Check button "Close" in Trading Admin detail info page "Exchange Detail" status is "enable"
```

**Key Points:**
- Status values: `"enable"` or `"disable"` (string, not boolean)
- Supports `Close` button via special xpath
- Also supports button lookup via `@object_acc` mapping for custom locators

### Check Text Input Status in Detail Page

Verify whether a text input field in a detail page is enabled or disabled:

```gherkin
* Check text input "Price Limit ID" in Trading Admin detail info page "Price Limit Detail" status is "disable"
```

### Check Field Error Message

Validate the inline error message displayed on a specific field in a detail page:

```gherkin
* Check field "Exchange ID" display error massage "UI1002 - This is a mandatory field" in detail info page "Exchange Detail"
```

### Check Field Validity (Input Rules)

Validate field input restrictions (character support, length limits, etc.) with multiple test values:

```gherkin
* Check Trading Admin detail info page "Exchange Detail" field "Exchange ID" validity with:
    | Input         | Value After Input | Error                                         |
    | HK            | HK                |                                               |
    | H_1           | H_                |                                               |
    | :             | :                 | UI1023 - Input contains unsupported character |
```

### Check Dropdown List Options

Verify the available options in a dropdown field:

```gherkin
* Check Dropdown List "Market Detail>Index?" in Trading Admin with:
    | Value   |
    | Y - Yes |
    | N - No  |
```

**Key Points:**
- The field path uses `>` separator: `"<Page Name>>Field Name"`
- Options are listed as individual rows in the `Value` column

## Revision History

| Date | Author | Description |
|---|---|---|
| 2026-08-08 | AI Assistant | Extracted from Admin_GUI_Transform_Rules.md Rule 6 |
| 2026-08-08 | AI Assistant | Added button/input status check, field error, field validity, dropdown list |
