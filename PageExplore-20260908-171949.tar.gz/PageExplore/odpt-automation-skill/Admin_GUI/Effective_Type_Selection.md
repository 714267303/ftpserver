# Effective Type Selection Rules

## Keywords
Update for tomorrow, Update effective asap, Delete for tomorrow, New record for tomorrow, NEW record effective asap, Current Record card, Check effective button status, Check effective type options

### For Detail Page Records

```gherkin
# Tomorrow effective
* Select effective type "Update for tomorrow" in detail info page "<Detail Page>" "Current Record" card

# ASAP effective
* Select effective type "Update effective asap" in detail info page "<Detail Page>" "Current Record" card

# Scheduled today effective
* Select effective type "Update for scheduled today" in detail info page "<Detail Page>" "Current Record" card

# Delete for tomorrow
* Select effective type "Delete for tomorrow" in detail info page "<Detail Page>" "Current Record" card

# Delete effective asap
* Select effective type "Delete effective asap" in detail info page "<Detail Page>" "Current Record" card

# Delete for scheduled today
* Select effective type "Delete for scheduled today" in detail info page "<Detail Page>" "Current Record" card
```

### From New Record Button

```gherkin
* Click button "New Record > New record for tomorrow" in Trading Admin
* Click button "New Record > New record effective asap" in Trading Admin
```

**Key Points:**
- `for tomorrow` = effective next business day
- `asap` = effective immediately
- For updates, you modify the "Current Record" card
- For new records, use the "New Record" button dropdown

### Check Effective Settings Button Status

Verify whether the settings button on an effective type card is enabled or disabled:

```gherkin
* Check effective "settings" botton status is "disable" in detail info page "Exchange Detail" "Current Record" card
* Check effective "settings" botton status is "enable" in detail info page "Exchange Detail" "Update Record" card
```

**Key Points:**
- Card types: `"Current Record"` (1st settings button) or `"Update Record"` (2nd settings button)
- Status values: `"disable"` or `"enable"` (string)

### Check Effective Type Options

Verify available options in the settings dropdown for an effective type card:

```gherkin
* Check effective type options "Withdraw changes" in detail info page "Exchange Participant Detail" "Update Record" card
```

**Key Points:**
- Multiple options are separated by semicolons in the expected value, e.g., `"Option 1;Option 2;Option 3"`
- Clicks the settings icon, reads all `<li>` elements, joins with `;`, then compares

## Revision History

| Date | Author | Description |
|---|---|---|
| 2026-08-08 | AI Assistant | Extracted from Admin_GUI_Transform_Rules.md Rule 12 |
| 2026-08-08 | AI Assistant | Added check effective button status and options verification |
