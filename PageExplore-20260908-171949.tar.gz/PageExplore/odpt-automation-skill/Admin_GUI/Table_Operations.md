# Table Operations Rules

## Keywords
Check table contains visible rows, Double click table, Select table, Set table sort, canvastable fields, Table Name Convention, Check sort order, Select active instruments, Trigger Generation

### Check Table Contains Visible Rows

```gherkin
* Check table "Maintain Exchange" contains visible rows with:
    | Record Status | Req Action | Record Status | Exchange ID [Key] | Exchange Code      | Description         | Short Name       |
    | P             | Add        | P             | new_Exchange_id1  | new_Exchange_code1 | test for automation | new_Exchange_id1 |
```

### Check Table Contains Rows (Sub-detail tables)

```gherkin
* Check table "<Table Name>" contains rows with:
    | Action | Record Type     | Attribute     | Value               | From | To |
    | Add    | (PERM) Exchange | Exchange ID   | new_Exchange_id1    |      |    |
```

### Check Table Row Count

```gherkin
* Check table "<Table Name>" match rows count is "<N>" with:
    | Action |
    | Add    |
```

### Double Click Table Row

```gherkin
* Double click table "Countersign Request" column "Req Action" with:
    | Req Status | Req Action | Exec Status [Key] | Identifier [Key] | Function Name     | Requester       | Effective Date     |
    | P          | Add        | Pending           | Identifier1      | Maintain Exchange | admin_gui_user1 | exp_effective_date |
```

### Double Click Table Row (Simple Match)

```gherkin
* Double click table "Maintain Exchange" column "Exchange ID" with:
    | Exchange ID [Key] |
    | new_Exchange_id1  |
```

### Select Multiple Table Rows

```gherkin
* Select table "Countersign Request" rows with:
    | Identifier |
    | Identifier1 |
```

### Set Table Sort Order

```gherkin
* Set table "Countersign Request" sort by column "Req ID" type "Des"
```

### Check CanvasTable Fields

```gherkin
* Check canvastable fields "<Table Name>" with:
    | Field |
    | PART  |
    | ID    |

* Check canvastable fields "<Table Name>" NOT display with:
    | Column  |
    | STRIKE  |

* Check canvastable fields "<Table Name>" display with:
    | Column  |
    | STRIKE  |

* Check canvastable multi-level fields "<Table Name>" with:
    | Group         | Column |
    | INSTRUMENT    | ID     |
    | MARKET        | BID    |
```

### Check Table Sort Order

Verify that a table column is sorted in ascending or descending order:

```gherkin
* Check table "Maintain Block Trade Group" sort by column "Block Trade Group ID" type "Asc" Data type "int"
* Check table "Maintain Block Trade Group" sort by column "Name" type "Asc" Data type "string"
* Check table "Maintain Block Trade Group" sort by column "Block Trade Group ID" type "Des" Data type "int"
```

**Key Points:**
- `Data type`: `"int"` (numeric comparison with normalization) or `"string"` (lexicographic comparison)

### Select Active Instruments from Data

Count or collect active instruments from an exported data array:

```gherkin
* Select the total number of active instruments form the "all_instrument_data" where "Inst. Class ID" is "HSICALL,HSIPUT" and save to "hsi_t"
* Select the list of active instruments form the "all_instrument_data" where "Inst. Class ID" is "HSICALL" and save to "hsi_call_list"
```

**Key Points:**
- Returns either `total number` (count) or `list` (array of matching rows)
- Filters by field/value pairs, checking effective date and active status

### Trigger Generation on Page

Trigger auto-generation on admin GUI pages (e.g., Instrument Generation):

```gherkin
* Trigger Generation in Trading Admin "Instrument Generation" page with:
    | Preset [List] | Market | Instrument Class | Instrument Type |
    | All Futures   | JSI    | JSIFUT           | JSIF            |
```

### Table Name Convention

| Admin GUI Page | Table Name (used in steps) |
|---|---|
| Exchange Management | `Maintain Exchange` |
| Market Management | `Maintain Market` |
| Inst. Group | `Maintain Inst. Group` |
| Inst. Type | `Maintain Inst. Type` |
| Underlying | `Maintain Underlying` |
| Inst. Class | `Maintain Inst. Class` |
| Instrument | `Maintain Instrument` |
| Inst. Name Standard | `Maintain Inst. Name Standard` |
| Access Group by Type | `Maintain Access Group by Type` |
| Combo Type | `Maintain Combo Type` |
| Combo Class | `Maintain Combo Class` |
| Combo | `Maintain Combo` |
| Combo Name Standard | `Maintain Combo Name Standard` |
| Exchange Participant | `Maintain Exchange Participant` |
| Drop Copy Group | `Maintain Drop Copy Group` |
| Direct Drop Copy Session | `Maintain Direct Drop Copy Session` |
| Direct Order Flow Session | `Maintain Direct Order Flow Session` |
| Trading Rights | `Maintain Trading Rights` |
| Participant User Role | `Maintain Participant User Role` |
| Sponsoring Participant | `Maintain Sponsoring Participant` |
| Company | `Maintain Company` |
| Self Admin Portal User | `Self Admin Portal User` |
| Trading GUI User | `Maintain Trading GUI User` |
| UI User Role | `Maintain UI User Role` |
| Price Tick | `Maintain Price Tick` |
| Price Tick Limit | `Maintain Price Tick Limit` |
| Inst. Class Price Tick Limit | `Maintain Inst. Class Price Tick Limit` |
| Reference Price Source | `Maintain Reference Price Source` |
| Price Limit | `Maintain Price Limit` |
| Price Limit Parameters | `Maintain Price Limit Parameters` |
| Control & Monitor Price Limit | `Control & Monitor Price Limit` |
| Control & Monitor VCM | `Control & Monitor VCM` |
| VCM Parameters | `Maintain VCM Parameters` |
| Trading Timetable | `Maintain Trading Timetable` |
| Trading State | `Maintain Trading State` |
| Non-Trading Days | `Maintain Non-Trading Days` |
| Block Trade Group | `Maintain Block Trade Group` |
| Block Trade MVT | `Maintain Block Trade MVT` |
| Regional Holiday Calendar | `Maintain Regional Holiday Calendar` |
| Last Trading Date Calendar | `Maintain Last Trading Date Calendar` |
| SMP ID List | `Maintain SMP ID List` |
| Countersign Request | `Countersign Request` |
| Countersign Request Detail | `Countersign Request Detail` |

## Revision History

| Date | Author | Description |
|---|---|---|
| 2026-08-08 | AI Assistant | Extracted from Admin_GUI_Transform_Rules.md Rule 7 |
| 2026-08-08 | AI Assistant | Added check sort order, select active instruments, trigger generation |
