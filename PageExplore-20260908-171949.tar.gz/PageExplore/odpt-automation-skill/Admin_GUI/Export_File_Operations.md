# Export File Operations Rules

## Keywords
Export CSV, export csv save to, Admin GUI page export, file operations, Import file, Save field from export

### Export and Read CSV

```gherkin
* Assign ("exchange_participants-" + Time.now.strftime("%Y%m%d%H%M%S") + ".csv") to file_name
* Admin GUI "Maintain Exchange Participant" page export csv save to "file_name" and read to "arr_existing_exchange_participants"
* Click button "Close" in Trading Admin
```

### Export with Filter

```gherkin
* Admin GUI "<page>" page export csv save to "<file>" and read to "<var>" with:
    | Field1 |
    | val1   |
```

### Import CSV File into Detail Page

Import a CSV file into an Admin GUI detail page:

```gherkin
* Import file "./resource/import/AdminGUI/ODP14a/Exchange-ODP14a.4.2.1.24.csv" in Trading Admin detail info page "Exchange Detail"
```

**Key Points:**
- File path is resolved via `getMapVal()` and `File::expand_path()`

### Save Field from Export Data

Extract all values of a specific column from exported CSV data into a new variable:

```gherkin
* Save "Strike Price" from export data "arr_hsi_spot_call" and save to "hsic_strike_price"
```

**Key Points:**
- Reads the column identified by the field name header from the exported data array
- Stores the resulting array (all row values for that column) in bigmap

### Save FIX Dumpfile

```gherkin
* Save FIX dumpfile ODP14a.4.2.1.1
```

### Load FIX Dumpfile (Presetting)

```gherkin
# In Background:
Background:
	* Load value from admin_gui_value
	* Load value from dataSet-ODP14a-value
	* Load FIX dumpfile ODP14a.4.2.2.7.Presetting
```

These steps persist WABI/FIX references.  An exported GUI array may remain in
the in-memory `@bigmap`, but it is not a substitute for a FIX dumpfile when a
later step uses `MyRef` or `ResponseRef`.

## Revision History

| Date | Author | Description |
|---|---|---|
| 2026-08-08 | AI Assistant | Extracted from Admin_GUI_Transform_Rules.md Rule 13 |
| 2026-08-08 | AI Assistant | Added Import CSV file, Save field from export data |
