# Countersign Approval Rules

## Keywords
Countersign Request, Approve, Pending, Requester, Approver, admin_gui_user1/user2, Req Status, Exec Status, Record Status, Approve if updated, Create instrument series, Create Combo, Delete Block Trade

### Standard Dual-User Workflow

The Admin GUI uses a **requester-approver** workflow where:
1. **Requester (admin_gui_user1)**: Creates/modifies records and submits requests
2. **Approver (admin_gui_user2)**: Reviews and approves/rejects the requests

### Integrated MCP Rollback Boundary

The missing-flow Playwright MCP stage submits the maker request, verifies the
pending request through the checker countersign path, then clicks `Reject` and
confirms cleanup. It must verify that no Pending request or changed active
record remains, and it must never click `Approve`. The Reject is exploration
evidence only and is omitted from the semantic manifest. Keep the applicable
Approve step in the manifest with `mcp_execution=deferred_to_feature`; the
generated Feature executes the standard approval pattern below. Both proven
MCP cleanup and a passing Feature report are required for flow promotion.

### Step-by-Step Countersign Pattern

```gherkin
# =========== Step 1: Requester navigates and searches ===========
* Switch browser to "browser_admin_gui_user2" and maximize
* Select Trading Admin Left Menu "Countersign>Countersign Request"
* Wait 2 seconds

* Search in Trading Admin "Countersign Request" page with:
    | Function Name                 | Req Status [List] |
    | Maintain Exchange Participant | Pending           |
* Set table "Countersign Request" sort by column "Req ID" type "Des"
* Wait 1 seconds

# =========== Step 2: Set expected effective date ===========
* Assign ((Time.now + 86400).strftime("%d-%b-%Y")) to exp_effective_date

# =========== Step 3: Open the request (double-click) ===========
* Double click table "Countersign Request" column "Req Action" with:
    | Req Status | Req Action | Exec Status [Key] | Identifier [Key] | Function Name                 | Requester       | Effective Date     |
    | P          | Add        | Pending           | Identifier1      | Maintain Exchange Participant | admin_gui_user1 | exp_effective_date |
* Wait 1 seconds

# =========== Step 4: Verify the request details ===========
* Check Trading Admin "Countersign Request Detail" info as:
    | Requester       | Identifier  | Function Name                 | Request Action | Request Status | Execution Status | Effective Date     |
    | admin_gui_user1 | Identifier1 | Maintain Exchange Participant | Add            | Pending        | Pending          | exp_effective_date |
* Screenshot

# =========== Step 5: Verify the attribute changes ===========
* Scroll detail page "Countersign Request Detail" to "Bottom"
* Check table "Countersign Request Detail" contains rows with:
    | Action | Record Type                      | Attribute                           | Value                 | From | To |
    | Add    | (PERM) Exchange Participant      | Exchange Participant ID             | new_exchange_part_id1 |      |    |

# =========== Step 6: Approve the request ===========
* Click button "Approve" in Trading Admin detail info page "Countersign Request Detail"
* Wait 1 seconds
* Click button "Confirm" in Trading Admin detail info page "Countersign Request Detail" confirm window
* Wait 1 seconds
* Check the confirm message "Your action has been sent." in Trading Admin detail info page "Countersign Request Detail" confirm window
* Screenshot
* Click button "Close" in Trading Admin detail info page "Countersign Request Detail" confirm window

# =========== Step 7: Verify approved status ===========
* Search in Trading Admin "Countersign Request" page with:
    | Req Status [List] |
    | Approved          |
* Wait 1 seconds
* Check table "Countersign Request" contains visible rows with:
    | Req Status | Req Action | Exec Status [Key] | Identifier [Key] | Function Name                 | Requester       | Effective Date     |
    | A          | Add        | Scheduled         | Identifier1      | Maintain Exchange Participant | admin_gui_user1 | exp_effective_date |
* Screenshot

# =========== Step 8: Switch back to requester and verify ===========
* Switch browser to "browser_admin_gui_user1" and maximize
* Check table "Maintain Exchange Participant" contains visible rows with:
    | Req Status | Req Action | Record Status | Exchange Part. ID     | Exchange ID | Company ID   | Suspended? | Description |
    | A          | Add        | A             | new_exchange_part_id1 | HK - HKFE   | 1 - ODP_HSBC | N - No     | HSBC        |
* Screenshot
```

### Countersign Request Detail Attributes

| Column | Description |
|---|---|
| `Action` | Type of change: `Add`, `Update`, `Delete`, `No Change` |
| `Record Type` | The PERM type: e.g., `(PERM) Exchange`, `(PERM) Exchange Participant` |
| `Attribute` | The field name being changed |
| `Value` | For Add: the new value; For Update: empty |
| `From` | For Update: the original value |
| `To` | For Update: the new value |

### Countersign Status Codes

| Status | Meaning | Description |
|---|---|---|
| `P` | Pending | Request created, awaiting approval |
| `A` | Approved | Approved by countersign user |
| `R` | Rejected | Rejected by countersign user |

### Record Status After Countersign

| Status | Meaning |
|---|---|
| `P` | Pending (before approval) |
| `A` | Active/Approved (after approval) |
| `E` | Existing (before modification) |
| `S` | Scheduled (future effective) |

### Approve if Updated (Conditional Approval)

After making changes to a detail page, conditionally approve based on whether changes were detected. Handles both detail pages and search/list pages:

```gherkin
* Approve if updated with :
    | Current Page                        | Approver Browser        | Function Name                         | Identifier | Requester       | Req Status |
    | Inst. Class Price Tick Limit Detail | browser_admin_gui_user2 | Maintain Inst. Class Price Tick Limit | CUAPUT     | admin_gui_user1 | Pending    |
```

**Key Points:**
- For **detail pages**: clicks Confirm, checks "No changes detected" vs "Your request has been sent.", then cancels or proceeds to approval
- For **search/list pages** (Control & Monitor Price Limit, Control Settlement Values): checks inline message, clicks Close
- The `Identifier` field is used to match the correct countersign request

### Create Instrument Series if Not Exists

Compound workflow step that checks if instruments exist and creates them with full countersign approval if needed:

```gherkin
* Create instrument series if not exists :
    | Series             | Inst. Class ID | Status     | Strike Price | ISIN | SEDOL | Last Trading Date | Last Trading Time | Price Quotation Factor | Contract Size | Traded? |
    | HSI_sm_fut         | HSIFUT         | A - Active | 0            |      |       |                   |                   | 50                     | 1             | Y - Yes |
    | HSI_20000_sm_call  | HSICALL        | A - Active | 20000        |      |       |                   |                   | 50                     | 1             | Y - Yes |
```

**Key Points:**
- Generates series code, searches for existing instrument, creates if missing
- Requires both `browser_admin_gui_user1` (requester) and `browser_admin_gui_user2` (approver) browsers to be open
- Internally calls: Generate series -> Search -> Click New Record -> Set info -> Confirm -> Countersign -> Approve

### Create Combo if Not Exists

Compound workflow step that creates combos with legs and full countersign approval:

```gherkin
* Create Combo if not exists :
    | Combo Class ID | Status     | Last Trading Date | leg1        | leg2       |
    | HSITS01        | A - Active |                   | HSI_cm1_fut | HSI_sm_fut |
```

**Key Points:**
- Generates series codes for each leg, creates combo with Buy/Sell legs
- Computed `combo_id` from second leg instrument ID + last 2 chars of first leg

### Delete Block Trade Group / Block Trade MVT

Compound deletion workflow for Block Trade entities:

```gherkin
* Delete Block Trade Group "new_id1,new_id2"
* Delete Block Trade MVT "new_id1"
```

**Key Points:**
- Accepts comma-separated IDs or a single ID
- For each ID: search -> double-click -> select delete -> save -> confirm
- Opens approver browser and approves all deletion requests via bulk approval

## Revision History

| Date | Author | Description |
|---|---|---|
| 2026-08-08 | AI Assistant | Extracted from Admin_GUI_Transform_Rules.md Rule 10 |
| 2026-08-08 | AI Assistant | Added conditional approve, create instrument/combo, delete block trade |
