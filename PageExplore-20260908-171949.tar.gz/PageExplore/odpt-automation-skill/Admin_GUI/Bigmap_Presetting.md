# FIX Dumpfile Presetting Rules

## Keywords
Save FIX dumpfile, Load FIX dumpfile, Presetting, Day1, Day2, dumpfile save/load, multi-file workflow

For Binary and Hybrid Features, persistence means the WABI/FIX state dump,
not the legacy GUI `@bigmap` YAML snapshot.  Read
[`../Binary_Interface/Dumpfile_Operations.md`](../Binary_Interface/Dumpfile_Operations.md)
for the executable contract.

### File Naming Convention

| Suffix | Purpose | Example |
|---|---|---|
| `.Presetting` | Pre-test setup data | `ODP14a.4.2.2.7.Presetting.feature` |
| `-Day1` | Day 1 test execution | `ODP14a.4.14.1.1-Day1.feature` |
| `-Day2` | Day 2 test execution (after effective date) | `ODP14a.4.14.1.1-Day2.feature` |
| `.feature` | Single-day / combined test | `ODP14a.4.2.1.1.feature` |
| `-clear` | Cleanup / teardown | `ODP14a.4.2.1.1-clear.feature` |

For a generated Hybrid lifecycle, `<case>.execution-flow.json` lists these
files in executable order. It is orchestration metadata rather than a Feature.
The next-day transition is represented as an `external_gate` between Day1 and
Day2; it must be completed outside Cucumber and explicitly acknowledged before
Day2 can run.

### Typical Multi-File Test Structure

**Presetting file** (creates base data):
```gherkin
@FEATURE=WS
Feature: Presetting
Background:
	* Load value from admin_gui_value
	* Load value from dataSet-ODP14a-value

Scenario: Presetting
	* CONNECT WS with:
		| User ID         | User Password            |
		| admin_gui_user1 | admin_gui_user1_password |
		| admin_gui_user2 | admin_gui_user2_password |

	* add new timetable with user "admin_gui_user1":
		| ID              | Name                 | Description                   |
		| TIMETABLE_ID_01 | Timetable Name Test   | Description for test timetable|

	* add new inst with user "admin_gui_user2" by "tomorrow":
		| Instrument ID | Instrument Class ID | Status [List] |
		| HSI_TEST       | HSIFUT              | A - Active    |

	* Save FIX dumpfile ODP14a.4.2.2.7.Presetting
```

**Day1 file** (test execution - create pending request):
```gherkin
@FEATURE=Binary
Feature: ODP Admin GUI
Background:
	* Load value from admin_gui_value
	* Load value from dataSet-ODP14a-value
	* Load FIX dumpfile ODP14a.4.2.2.7.Presetting

@CASE=ODP14a.4.2.2.7-Day1
Scenario: <Description>
	# ... standard Admin GUI operations (login, navigate, create, countersign, etc.) ...
	* Save FIX dumpfile ODP14a.4.2.2.7-Day1
```

**Day2 file** (verify effect after effective date):
```gherkin
@FEATURE=Binary
Feature: ODP Admin GUI
Background:
	* Load value from admin_gui_value
	* Load value from dataSet-ODP14a-value
	* Load FIX dumpfile ODP14a.4.2.2.7-Day1

@CASE=ODP14a.4.2.2.7-Day2
Scenario: <Description>
	# ... verify the changes are effective ...
```

### FIX Dumpfile Save/Load Rules

- FIX dumpfiles store `@fixmap`, order-reference mappings, and history messages
  that need to persist across test executions.
- Always use `* Save FIX dumpfile <name>` at the end of a Binary/Hybrid scenario
  when the next lifecycle Feature needs its FIX references.
- Use `* Load FIX dumpfile <name>` in the next Feature's Background.  The load
  step refreshes Scenario-local references before the next step runs.
- Dumpfile naming follows the pattern: `<ODP Case Name>[-Day1|-Day2][.Presetting]`.
- Do not combine multiple Admin users in one login table; each saved browser
  session must have its own `Open browser` and one-user `Login` step.

## Revision History

| Date | Author | Description |
|---|---|---|
| 2026-08-08 | AI Assistant | Extracted from Admin_GUI_Transform_Rules.md Rule 14 |
