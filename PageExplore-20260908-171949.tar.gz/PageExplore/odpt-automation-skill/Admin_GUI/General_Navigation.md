# General Navigation Rules

## Keywords
Login, browser, Save current browser, Switch browser, Clear Alert, Open browser, Screenshot

### Standard Dual User Login (Requester + Approver)

The most common pattern involves two browser sessions:
- **admin_gui_user1**: The requester (creates/modifies records)
- **admin_gui_user2**: The approver (countersigns/approves requests)

The login step is session-scoped: a table may exercise one user (including
multiple rows for an explicit expected-login-error retry), but it must not
establish multiple distinct user sessions. A table containing both users is an
anti-pattern: after the first login the browser is on the application page, so
the second iteration can no longer find the login form. It can surface as a
missing `#loginid` element or a timeout. Always repeat the complete `Open
browser` → one-user `Login` → `Save current browser` sequence for the second
user.

```gherkin
# --- Browser 1: Requester ---
* Open browser
* Login Trading Admin with:
    | User ID         | User Password            |
    | admin_gui_user1 | admin_gui_user1_password |
* Wait 1 seconds
* Clear Alert If Exist
* Save current browser to browser_admin_gui_user1
* Screenshot
```

```gherkin
# --- Browser 2: Approver ---
* Open browser
* Login Trading Admin with:
    | User ID         | User Password            |
    | admin_gui_user2 | admin_gui_user2_password |
* Wait 1 seconds
* Clear Alert If Exist
* Save current browser to browser_admin_gui_user2
* Screenshot
```

### Switch Between Browser Sessions

```gherkin
* Switch browser to "browser_admin_gui_user1" and maximize
* Switch browser to "browser_admin_gui_user2" and maximize
```

### Single User Pattern (Simple browse/view operations)

```gherkin
* Open browser
* Login Trading Admin with:
    | User ID         | User Password            |
    | admin_gui_user1 | admin_gui_user1_password |
* Wait 1 seconds
* Clear Alert If Exist
* Save current browser to browser_admin_gui_user1
* Screenshot
```

### Login Flow Pattern (Post-Login Wait)

```gherkin
* Login Trading Admin with:
    | User ID         | User Password            |
    | admin_gui_user1 | admin_gui_user1_password |
* Wait 1 seconds
* Clear Alert If Exist
* Wait 2 seconds
```

**Key Points:**
- `User ID` and `User Password` are resolved from `admin_gui_value.csv`
- `admin_gui_user1` = requester, `admin_gui_user2` = approver
- Always use `* Clear Alert If Exist` after login to dismiss popups
- `* Save current browser to browser_<user>` is used to track browser sessions
- `* Switch browser to "browser_<user>" and maximize` switches between sessions

## Revision History

| Date | Author | Description |
|---|---|---|
| 2026-08-08 | AI Assistant | Extracted from Admin_GUI_Transform_Rules.md Rule 3 |
