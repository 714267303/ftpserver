# Buttons and Dialogs Rules

## Keywords
Click button, Confirm, Cancel, Close, New Record, More Actions, confirm message, Set Trading Admin format, Popup confirm, Search page confirm, Subtitle message

### Click Button

```gherkin
* Click button "Confirm" in Trading Admin detail info page "Exchange Detail"
* Click button "Close" in Trading Admin detail info page "Exchange Detail" confirm window
* Click button "Cancel" in Trading Admin
* Click button "Close" in Trading Admin
```

### "Set Trading Admin" Table Format (CRITICAL)

The `Set Trading Admin` step must have **all field names in the FIRST row** and **all corresponding values in the SECOND row**. Do NOT use field-value pairs.

```gherkin
# CORRECT format:
* Set Trading Admin "Instrument Detail" info as:
    | Security ID   | Instrument Type   | First Trading Date    | First Trading Time    |
    | instrument_id1| Future            | Day2                  | 09:00                 |

# CORRECT - for combo instruments:
* Set Trading Admin "Instrument Detail" info as:
    | Security ID   | Instrument Type   | First Trading Date    | Combo Leg                    | First Trading Time |
    | combo_id1     | Combo             | Day2                  | instrument_id1,instrument_id2 | 09:00              |
```

### Global Buttons (Outside Detail Pages)

```gherkin
* Click button "Close" in Trading Admin
* Click button "Confirm" in Trading Admin
* Click button "Cancel" in Trading Admin
```

### New Record Button

```gherkin
# Tomorrow effective:
* Click button "New Record > New record for tomorrow" in Trading Admin

# ASAP effective:
* Click button "New Record > New record effective asap" in Trading Admin

# Simple new record (page default effective type):
* Click button "New Record" in Trading Admin
```

### More Actions Button

```gherkin
* Click button "More Actions > Approve selected Countersign Request" in Trading Admin
```

### Confirmation Dialog Flow (Standard - New/Create Record SUCCESS)

```gherkin
* Click button "Confirm" in Trading Admin detail info page "<Detail Page>"
* Check the confirm message "Proceed your action?" in Trading Admin detail info page "<Detail Page>" confirm window
* Wait 1 seconds
* Click button "Confirm" in Trading Admin detail info page "<Detail Page>" confirm window
* Wait 1 seconds
* Check the confirm message "Your request has been sent." in Trading Admin detail info page "<Detail Page>" confirm window
* Screenshot
* Click button "Close" in Trading Admin detail info page "<Detail Page>" confirm window
```

### Confirmation Dialog Flow (Error / Validation Failure)

When a record submission fails with an error message:

```gherkin
* Click button "Confirm" in Trading Admin detail info page "Price Limit Parameters Detail"
* Check the confirm message "Error\nErrorCode: 14200, ErrorMsg: Validate error: [field is mandatory for value]" in Trading Admin detail info page "Price Limit Parameters Detail" confirm window
* Screenshot
* Click button "Close" in Trading Admin detail info page "Price Limit Parameters Detail" confirm window
* Click button "Cancel" in Trading Admin detail info page "Price Limit Parameters Detail"
* Click button "Confirm" in Trading Admin popup confirm window
```

### Approval Confirmation Dialog Flow (Countersign Approve)

```gherkin
* Click button "Approve" in Trading Admin detail info page "Countersign Request Detail"
* Wait 1 seconds
* Click button "Confirm" in Trading Admin detail info page "Countersign Request Detail" confirm window
* Wait 1 seconds
* Check the confirm message "Your action has been sent." in Trading Admin detail info page "Countersign Request Detail" confirm window
* Screenshot
* Click button "Close" in Trading Admin detail info page "Countersign Request Detail" confirm window
```

### Click Button in Generic Popup Confirm Window

Used for popup confirm windows not tied to a specific detail page (e.g., "You are editing fields, confirm to close?"):

```gherkin
* Click button "Confirm" in Trading Admin popup confirm window
* Click button "Close" in Trading Admin popup confirm window
```

### Check Confirm Message in Popup Info Page

Used for popup confirm windows associated with an info page (different xpath than detail page confirm):

```gherkin
* Check the confirm message "You are editing fields, confirm to close?" in Trading Admin popup confirm window info page "Combo Group Detail" confirm window
```

### Check Confirm Message in Search Page

Used for confirm messages on search/list pages (e.g., Control & Monitor Price Limit, Control Settlement Values):

```gherkin
* Check the confirm message "Proceed your action?" in Trading Admin search page confirm window
```

### Check Subtitle Message in Detail Page

Used for inline warning/subtitle messages within detail pages:

```gherkin
* Check the subtitle message "Record is updated by others, please re-open the record detail to take the latest version." in Trading Admin detail info page "Exchange Detail"
```

## Revision History

| Date | Author | Description |
|---|---|---|
| 2026-08-08 | AI Assistant | Extracted from Admin_GUI_Transform_Rules.md Rule 9 |
| 2026-08-08 | AI Assistant | Added popup confirm, search page confirm, subtitle message sections |
