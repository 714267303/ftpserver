# Admin GUI Flow Catalog

This directory stores reusable Admin GUI workflows discovered through
Playwright MCP. It is a semantic handoff layer between rollback-validated
browser exploration and the Ruby/Cucumber UAT runtime.

## What is persisted

Each file in `flows/` is a reviewed JSON manifest containing:

- stable `flow_id`, case and page route/profile;
- executable UAT step text and optional Gherkin tables;
- redacted `qaGridApi` observations (method names, key patterns, field names);
- pointers to the raw Playwright run, trace, screenshots, and logs;
- replay/reuse status and known variants.

Raw locators, browser JavaScript, dynamic UUIDs, credentials, and row values do
not belong in this catalog. Keep those in an isolated evidence directory such
as `outputs/admin/<case>/run-001/` with restricted access.

## Lifecycle

```text
batch Step 2: Excel -> YAML
  -> Step 3: classify Admin/Hybrid channel
  -> Step 1: reuse flow or Playwright MCP rollback-validation pass
  -> outputs/admin/<case>/run-###/ (trace + screenshots + notes)
  -> flow_catalog/flows/<flow-id>.json (semantic, safe_to_reuse=false)
  -> build_admin_flow_catalog.py (index and validation)
  -> Step 4: admin_feature_converter.py --standalone-admin
  -> exact flow/Feature step and DataTable comparison
  -> Step 5A: standalone Admin Cucumber run/repair
  -> Step 6: validate Admin report and set safe_to_reuse=true
  -> Step 7 (Hybrid only): independently generate non-Admin lifecycle Feature(s)
  -> write <case>.execution-flow.json; run in order and stop at external gates
```

`observed` and `inferred` flows are useful references but must not be selected
by automatic conversion. During missing-flow discovery, Playwright submits a
maker request and has the checker Reject it as cleanup; without countersign it
Cancels before persistent save. It never executes Approve. Reject/Cancel is not
part of manifest steps. Required Approve stays in the manifest as a semantic
Step_Index operation marked `mcp_execution=deferred_to_feature`. A flow becomes
reusable only after cleanup is proven and the standalone Admin Feature executes
that operation and passes. Binary/batch/Trading GUI failures do not alter this
Admin promotion decision because those behaviors live in a separate Feature.
Case-specific values remain placeholders and belong in the case manifest/dataset.

The batch validates this handoff before copying it into `flows/`. Recoverable
shape mistakes from an MCP agent are normalized with a SHA-256 audit trail,
including `page_route` -> `page.route`, `uat_step` -> `text`, and an exact
route's unique PageExplore profile. A generic PageExplore contract derived
from all sitemap entries then verifies sidebar menu, route, profile, page name,
saved-browser page state, and profile fields before Feature generation. It can
repair only a uniquely proven mismatch; ambiguity and missing navigation fail.
The completed Playwright transcript must independently contain the declared
route in tool output. `source_coverage` must map every Admin YAML TestStep to
flow steps and cover every flow step, preventing partial manifests from being
promoted. Natural-language steps and missing DataTables still fail Step_Index
validation. In that situation the batch makes one browser-free semantic-repair
attempt with Playwright, shell, network, and dotenv access disabled; it never
repeats the completed MCP rollback merely to repair the JSON artifact.

The batch treats promotion as a transaction. A newly explored flow starts as
verified validation evidence but is not reusable. Feature generation, execution,
repair, report validation, or catalog-refresh failure keeps
`reuse.safe_to_reuse=false`; failed transactions are marked `observed` with a
redacted review reason. Only a successful Step 6 makes the flow selectable by
a later batch.

Failure findings and unsafe shapes do not belong in this positive-flow catalog.
Record them in the sibling
[`repair_experience/`](../../repair_experience/README.md) catalog instead:
repair candidates stay quarantined in `inbox/`, and only a separately reviewed
and verified lesson can influence later repair guidance.

## Commands

```bash
python3 tools/build_admin_flow_catalog.py
python3 tools/build_admin_flow_catalog.py --check
python3 tools/find_admin_flow.py "SMP ID List"

python3 tools/admin_feature_converter.py \
  --flow odpt-automation-skill/Admin_GUI/flow_catalog/flows/<flow-id>.json \
  --output /tmp/<case>.admin.feature \
  --report /tmp/<case>.conversion.json \
  --step-index odpt-automation-skill/Step_Index.json
```

The generated `INDEX.json` is for scripts; `INDEX.md` is the lazy-loading
catalog for the skill. Both are deterministic and should be refreshed whenever
a flow manifest changes.
