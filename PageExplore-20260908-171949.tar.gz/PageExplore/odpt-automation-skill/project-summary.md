# ODP-T Project Summary

## Project Overview

**ODP-T** (Order Drop Processing - Trading) is an automated testing framework
for the HKEX ODP trading system. It validates behavior through Binary (FIX)
messages, Admin GUI configuration, Trading GUI operations, and Clearing
Interface verification.

**Framework:** Cucumber (Gherkin) + Ruby + WABI  
**Domain:** HKEX Derivatives Trading - Error Trade, Order Management, Block
Trade, Market Making, Clearing

## Current Project Status

| Component | Status | Notes |
|---|---|---|
| Feature Files | Active | Under `features/test_case/` |
| Custom Step Definitions | Active | `features/customized_steps/` |
| Dataset Configurations | Active | `resource/dataSet-ODP*.csv` |
| Automation Plans | Active | `automation/plan/` |
| FIX Proxy | Configured | `for_fixdproxy/` |
| Clearing Integration | Configured | `for_clearing/` |
| Transform Rules | Active | Organized by common and domain-specific rule files |
| ODP Business Specifications | Indexed | `odp-docs/INDEX.md` and `odp-docs/INDEX.json` |
| PageExplore Knowledge Base | Indexed | `pageExplore/` contains website and qaGrid knowledge |
| UAT Step Index | Generated | Runtime step definitions remain authoritative |
| FIX Enum Index | Generated | `FIXODPMSG_Index.json` and `.md` |
| Error-Code Index | Generated | Category-scoped meanings with provenance |
| Admin Feature Converter | Active | Converts reviewed Playwright flows to Admin/Hybrid Features |
| Admin Flow Catalog | Active | Reusable semantic flows under `Admin_GUI/flow_catalog/` |
| Feature Runner | Active | `tools/run_feature_debug.rb` executes and diagnoses Features |
| OpenCode Model | Configurable | Defaults to `ollama/DeepSeek-V4-Flash-INT8` (internal Ollama endpoint) |

## Transform Rule Files

| File | Description |
|---|---|
| `INDEX.md` | Master skill index |
| `SKILL.md` | Main workflow, authority, and safety rules |
| `project-summary.md` | Compact project status and naming conventions |
| `conversion-rules.md` | Common rules shared by all domains |
| `Binary_Interface/INDEX.md` | Binary FIX interface rules |
| `Admin_GUI/index.md` | Admin GUI rules |
| `Trading_GUI/index.md` | Trading GUI rules |
| `Clearing_Interface_Transform_Rules.md` | Clearing interface rules |
| `Feature_Run_and_Debug.md` | Feature execution, reports, diagnosis, and repair |
| `execution-flow.schema.json` | Ordered Hybrid Feature lifecycle and external-gate state |

## Naming Conventions

### Feature File Names

Use the existing ODP case name as the Feature filename stem. Preserve the
lifecycle suffix when the test is split across files:

| Suffix | Purpose | Example |
|---|---|---|
| `.Presetting` | Pre-test setup data | `ODP14a.4.2.2.7.Presetting.feature` |
| `-Day1` | Day 1 execution | `ODP14a.4.14.1.1-Day1.feature` |
| `-Day2` | Execution after the effective date | `ODP14a.4.14.1.1-Day2.feature` |
| `-clear` | Cleanup or teardown | `ODP14a.4.2.1.1-clear.feature` |
| `.feature` | Single-day or combined test | `ODP14a.4.2.1.1.feature` |

Cross-day Hybrid generation also writes `<case>.execution-flow.json`. This is
not a Feature; it declares `admin -> day1 -> night_batch -> day2` and records
which stages passed or are waiting.

The `@CASE` value should match the case stem when the source case provides one.
Do not add timestamps, random identifiers, or undocumented abbreviations to a
Feature filename.

### Binary Session Naming

Use `PART{participant number}_OF_ID_{ID number}`.

- The same participant prefix uses the same `PART{N}` with different ID numbers.
- A different participant prefix uses a different `PART{N}`.
- The clearing session is `CLEARING_ACCOUNT1`.

### GUI User Naming

| User Type | Naming Pattern |
|---|---|
| External Trading GUI | `trading_gui_user{sequence}` |
| Internal Trading GUI | `trd_gui_inter_user{sequence}` |
| Admin GUI | `admin_gui_user{sequence}` |

Each distinct Admin GUI user must have a separate `Open browser` and one-user
`Login Trading Admin` step before saving the browser session. Multiple rows in
one login table are only for same-user retry or validation flows.

### MyRef Naming

Use `<CaseID>-<RoleAbbrev>-<Operation>-<Sequence>[-Qualifier]` and keep response
references deterministic, normally with a `-R` suffix.

## Known Issues and Constraints

- Some Feature files use `Feature: ODP Admin GUI` for Binary or Error Trade
  tests; preserve this project convention when matching an existing case.
- `ID3` can mean `PART2_OF_ID_1` or `PART1_OF_ID_3`; decide from the user ID
  prefix and the source case.
- Error Trade tests may intentionally include long waits for time-limit checks.
- The exploration checkout may not contain the installed
  `/usr/local/share/gems/gems/wabi-web-*`; resolve the runtime gem in the target
  UAT checkout before marking a flow runnable.
- qaGrid observations are evidence only. Do not copy dynamic UUIDs, row values,
  or `setRowData()` calls into generated Features.
- Feature execution is opt-in. A wrapper report is not a substitute for a run
  in the target UAT checkout with its required gems and endpoints.

## Recommended Workflow

1. Select the relevant ODP Functional Specification from `../odp-docs/INDEX.md`.
2. Select executable rules and existing step patterns from `SKILL.md`,
   `conversion-rules.md`, and the domain indexes.
3. Generate or edit the Feature while preserving the source case name and
   lifecycle suffix.
4. Run the affected Feature with `tools/run_feature_debug.rb` in the target
   UAT checkout.
5. Record only reviewed, generalized repair lessons in
   `repair_experience/lessons/`.

## Skill File Maintenance

When a new pattern is discovered, update the narrowest canonical source:

| Work Area | Update |
|---|---|
| Common/shared rules | `conversion-rules.md` |
| Binary FIX message patterns | `Binary_Interface/<specific-file>.md` |
| Admin GUI operations | `Admin_GUI/<function-file>.md` |
| Trading GUI operations | `Trading_GUI/<page-file>.md` |
| Clearing verification | `Clearing_Interface_Transform_Rules.md` |
| Project status and naming | `project-summary.md`, `SKILL.md`, or `INDEX.md` |
| Grid contract and observations | `../pageExplore/qaGrid/` |
| UAT vocabulary | `Step_Index.*` and `tools/build_step_index.py` |
| Playwright-to-Feature handoff | `Admin_GUI/Feature_Converter.md` |
| Persisted Playwright flows | `Admin_GUI/flow_catalog/` |
| Page profile routing | `../pageExplore/pages/` |
| FIX and error meanings | `FIXODPMSG_Index.*`, `Error_Code_Index.*` |
| Feature execution, diagnosis, and repair | `Feature_Run_and_Debug.md`, `tools/run_feature_debug.rb` |
