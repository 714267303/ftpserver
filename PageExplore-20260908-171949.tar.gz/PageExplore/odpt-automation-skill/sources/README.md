# Indexed Source Snapshots

Files in this directory are input snapshots for generated indexes. They are
kept separate from executable transformation rules so a later service-
description update can be compared without silently changing a rule.

## Error code hand-off

`error_code_index_user_supplied_20260901.json` is the JSON `Error Code Index`
provided in the 2026-09-01 hand-off. It contains 30 categories and 570 source
entries, including the `Logout Text`, `Reject Reason (Internal UI)`, `Kill
Switch Reason`, and `Technical Reason` tables. The rows are preserved exactly;
the generated index adds stable category IDs, split lookup values for composite
codes, and provenance metadata.

Regenerate the machine-readable and Markdown projections with:

```bash
python3 tools/build_error_code_index.py
```

The generator also accepts a replacement or additional source via
`--json PATH` (repeatable), or JSON on standard input with `--json -`. The
checked-in SME-approved CSV and this hand-off JSON are included by default;
use `--csv-only` when a CSV-only projection is required. A code is never a
global key; resolve it as `CATEGORY_ID:CODE`.
