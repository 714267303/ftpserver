# Clearing Interface Transform Rules: Excel Test Case to Feature File

## Overview

This document defines the rules for transforming Excel/YAML test cases involving **Clearing Interface** FIX protocol `TradeCaptureReport` messages into Cucumber feature files.

The Clearing Interface is a separate FIX session that connects the ODP-T trading system to the HKEX Central Clearing system. After trades are executed, cancelled, or adjusted, the clearing interface receives `TradeCaptureReport` messages.

## Source Documents

- ODP-PT Interface FIX Specification: `ai/FS/ODP-TR - ODP-PT Interface FIX Specification (v0.0.3b) (20260527).pdf`
- Existing Feature Files: `features/test_case/Clearing_receive_verify/`, `features/test_case/Error_Cancel_Adj_Trade/ODP17.41.2.feature`, `features/test_case/Error_Cancel_Adj_Trade/ODP17.42.feature`
- Clearing FIX Proxy Config: `for_clearing/resource/hkex.cfg`
- FIX Templates: `features/templates.csv`

---

## Rule 1: Clearing Interface Overview

| Session Name | Purpose |
|---|---|
| `CLEARING_ACCOUNT1` | Primary clearing FIX session connecting ODP-T to HKEX Clearing |

| Template Name | FIX MsgType | Purpose |
|---|---|---|
| `Logon_Clearing` | `35=A` | Clearing session logon |
| `LogonResponse_Clearing` | `35=A` | Clearing session logon response |
| `TradeCaptureReport` | `35=AE` | Trade report sent to clearing |
| `Logout_Clearing` | `35=5` | Clearing session logout |

## Rule 2: Clearing Session Management

```gherkin
* Set ISODP false
* CLEARING_ACCOUNT1 send:
    | MyRef | Template        |
    | L0013 | Logout_Clearing |
* Wait 1 seconds
* CLEARING_ACCOUNT1 send:
    | MyRef | Template       |
    | L1003 | Logon_Clearing |
* CLEARING_ACCOUNT1 expect:
    | MyRef | Template               |
    | L1003 | LogonResponse_Clearing |
```

## Rule 3: Clearing Background Setup

```gherkin
@FEATURE=Binary
Feature: ODP Admin GUI
    Create Date: <YYYY/MM/DD>
    Last Update: <YYYY/MM/DD>
    Author Name: AI Assistant
    Background:
        * Load value from admin_gui_value
        * Load value from trading_gui_value
        * Load value from dataSet-ODP17-value
        * Load object description from odp-web-object
        * Load parameters from csv dataSet-ODP17
```

## Rule 4: FIX Group Setup for Clearing Messages

Before expecting `TradeCaptureReport`, define all referenced FIX groups:

```gherkin
* Set FIX Group <GroupName>:
    | Name  | Field1 | Field2 |
    | row1  | val1   | val2   |
```

## Rule 5: NoPartyIDs Setup Pattern

```gherkin
* Set FIX Group NoPartyIDs:
    | Name   | PartyID | PartyIDSource | PartyRole |
    | party1 | part1   | D             | 1         |
    | party2 | part2   | D             | 1         |
```

## Rule 6: NoSides Setup Pattern

```gherkin
* Set FIX Group NoSides:
    | Name  | Side | NoPartyIDs[1] |
    | side1 | 1    | party1        |
    | side2 | 2    | party2        |
```

## Rule 7: NoPartySubIDs Setup Pattern

```gherkin
* Set FIX Group NoPartySubIDs:
    | Name | PartySubID | PartySubIDType |
    | sub1 | 1610       | 4001           |
    | sub2 | 330        | 4001           |
```

## Rule 8: NoOrderAttributes Setup Pattern

```gherkin
* Set FIX Group NoOrderAttributes:
    | Name  | OrderAttributeType | OrderAttributeValue |
    | attr1 | 1011               | ATID1               |
    | attr2 | 1011               | ATID2               |
```

## Rule 9: TradeCaptureReport Message Template

```gherkin
* CLEARING_ACCOUNT1 expect:
    | MyRef | Template           | <Field1> |
    | NONE  | TradeCaptureReport | <val1>   |
```

## Rule 10: TradeCaptureReport Field Mapping

### Trade Cancellation

| Feature Header | Mapping Rule | Example |
|---|---|---|
| MyRef | Always `NONE` | `NONE` |
| Template | Always `TradeCaptureReport` | `TradeCaptureReport` |
| TradeReportTransType | `1`=Cancelled | `1` |
| TradeID | Executed trade ID | `<TradeRef>-M-R.TradeID` |
| ExecType | `L`=TradeCancel | `L` |
| SecurityID | Instrument ID | `instrument_id1` |
| SecurityIDSource | Exchange Symbol | `8` |
| SecurityExchange | HKEX Futures Exchange | `XHKF` |
| ApplID | Application ID | `1` |
| NoSides[1] | side1 group | `side1` |
| NoSides[2] | side2 group | `side2` |

### New Trade

| Feature Header | Mapping Rule | Example |
|---|---|---|
| TradeReportTransType | `0`=New | `0` |
| TrdType | Regular Trade | `0` |
| TrdSubType | Standard Order Book Trade | `1011` |
| MatchType | Order Book Match | `4` |
| ExecType | Fill | `F` |

## Rule 11: ISODP Mode Switching for Clearing

| ISODP State | When to Use |
|---|---|
| `true` | Binary trading operations |
| `false` | Clearing session management and TradeCaptureReport verification |

## Rule 12: End-to-End Clearing Verification Flow

1. Execute trade via Binary or GUI.
2. Complete cancellation/adjustment workflow if applicable.
3. Set `ISODP false`.
4. Define `NoPartyIDs` and `NoSides`.
5. Expect `TradeCaptureReport` on `CLEARING_ACCOUNT1`.

## Rule 13: Complete Step-by-Step Pattern

```gherkin
* Set ISODP false
* Set FIX Group NoPartyIDs:
    | Name   | PartyID | PartyIDSource | PartyRole |
    | party1 | part1   | D             | 1         |
    | party2 | part2   | D             | 1         |
* Set FIX Group NoSides:
    | Name  | Side | NoPartyIDs[1] |
    | side1 | 1    | party1        |
    | side2 | 2    | party2        |
* CLEARING_ACCOUNT1 expect:
    | MyRef | Template           | TradeReportTransType | TradeID                | ExecType | SecurityID     | SecurityIDSource | SecurityExchange | ApplID | NoSides[1] | NoSides[2] |
    | NONE  | TradeCaptureReport | 1                    | <TradeRef>-M-R.TradeID | L        | instrument_id1 | 8                | XHKF             | 1      | side1      | side2      |
```

## Revision History

| Date | Author | Changes |
|---|---|---|
| 2026-07-31 | Ken Huang | Initial version - Clearing Interface transform rules derived from ODP17.41.2, ODP17.42, TryClearing feature files and ODP-PT Interface FIX Specification |
| 2026-08-08 | AI Assistant | Cross-referenced ISODP mode documentation now in conversion-rules.md Section 8 |
