# Binary Interface: MassQuote (MsgType 51-52) Rules

## Overview

This file defines the transformation rules for MassQuote (51) and MassQuoteAck (52) messages.

---

## 1. QuoteEntryRequestBodyFieldsLegs Group Definition

### 8.13 QuoteEntryRequestBodyFieldsLegs

Before sending a MassQuote, define the quote entry legs group:

```gherkin
* Set FIX Group QuoteEntryRequestBodyFieldsLegs:
    | Name     | QuoteSecurityID | BidSize | BidPrice | OfferSize | OfferPrice | QuoteEntryID | CancelOnMMPTriggered |
    | entry1   | instrument_id1  | 10      | 10050    | 10        | 10060      | 1            |  lockingValue         |
    | entry2   | instrument_id1  | 10      | 10030    | 10        | 10080      | 2            |  lockingValue         |
```

### Group Field Reference

| Field | Mapping Rule |
|---|---|
| `Name` | Row identifier used in `QuoteEntryRequestBodyFieldsLegs[N]` column references |
| `QuoteSecurityID` | `instrument_id<N>` from dataset |
| `BidSize` | Bid quantity (integer) |
| `BidPrice` | Bid price (integer/Decimal) |
| `OfferSize` | Offer quantity (integer) |
| `OfferPrice` | Offer price (integer/Decimal) |
| `QuoteEntryID` | Unique entry ID (integer, sequential) |
| `CancelOnMMPTriggered` | `0`=No (default), `1`=Yes (cancel on MMP trigger) |

---

## 2. MassQuote (51) - Send Fields

### 8.14 MassQuote (51) - Send Fields

| # | Template Field | Feature Header | Mapping Rule |
|---|---|---|---|
| 1 | QuoteID | MyRef | `<CaseID>-<Role>-MQ-<Seq>` |
| 2 | TransactionTime | (auto) | Not in table |
| 3 | QuoteAttributeFlags | QuoteAttributeFlags | Optional flags |
| 4 | EntriesToProcess | EntriesToProcess | Process mode: Values may include `quote (new)`, `amend`, `cancel` |
| 5 | NoQuoteEntries | NoQuoteEntries | Number of quote entries (integer) |
| 6 | QuoteEntryRequestBodyFieldsLegs[1] | QuoteEntryRequestBodyFieldsLegs[1] | Reference to entry1's Name |
| 7 | QuoteEntryRequestBodyFieldsLegs[2] | QuoteEntryRequestBodyFieldsLegs[2] | Reference to entry2's Name |

### 8.14 MassQuote (51) - Send Table Format Example

```gherkin
* Set FIX Group QuoteEntryRequestBodyFieldsLegs:
    | Name   | QuoteSecurityID | BidSize | BidPrice | OfferSize | OfferPrice | QuoteEntryID | CancelOnMMPTriggered |
    | entry1 | instrument_id1  | 1       | 10       | 1         | 20         | 1            | 0                    |
    | entry2 | instrument_id2  | 1       | 10       | 1         | 20         | 2            | 0                    |
* <PART_SESSION> send:
    | MyRef                    | Template  | EntriesToProcess | NoQuoteEntries | QuoteEntryRequestBodyFieldsLegs[1] | QuoteEntryRequestBodyFieldsLegs[2] |
    | <CaseID>-<Role>-MQ-01   | MassQuote | quote (new)      | 2              | entry1                            | entry2                             |
```

---

## 3. MassQuote Response Patterns

### 8.16 Quote Response Patterns

Each successful quote entry side results in an OrderAccepted (27) message:

| No. of Entries | Entries x Sides | Total Accept Responses |
|---|---|---|
| 1 | 1 x 2 (bid + offer) | 2 responses |
| 2 | 2 x 2 (bid + offer) | 4 responses |
| N | N x 2 | 2N responses |

Each response row references the MassQuote's `QuoteID` as its `ClientOrderID`.

### MassQuoteAck (52) - Expect Fields

When some/all quote entries are rejected, MassQuoteAck may be received:

```gherkin
* <PART_SESSION> expect:
    | MyRef                    | Template     | ResponseRef                  | QuoteID              | EntriesToProcess | NoQuoteEntries |
    | <CaseID>-<Role>-MQ-01   | MassQuoteAck | <CaseID>-<Role>-MQ-01-Ack-R | <CaseID>-<Role>-MQ-01.QuoteID | quote (new)      | 2              |
```

---

## 4. FS Mandatory Fields (Rule 13.6)

### 13.6 MassQuote (51) - Mandatory Field Reference

| # | Template Field | Feature Header | Mandatory | Default |
|---|---|---|---|---|
| 1 | QuoteID | MyRef | **Yes (M)** | `<CaseID>-<Role>-MQ-<Seq>` |
| 2 | TransactionTime | (auto) | **Yes (M)** | Auto; NOT in table |
| 3 | EntriesToProcess | EntriesToProcess | **Yes (M)** | `quote (new)` |
| 4 | NoQuoteEntries | NoQuoteEntries | **Yes (M)** | Number of entries |
| 5 | QuoteEntryRequestBodyFieldsLegs[*] | group references | **Yes (M)** | Leg group references |

---

## 5. Variable Naming Convention

| Usage | Example MyRef |
|---|---|
| MassQuote send | `<CaseID>-ID1-MQ-01` |
| OrderAccepted ref (leg1-bid) | `<CaseID>-ID1-MQ-leg1-B-R` |
| OrderAccepted ref (leg1-offer) | `<CaseID>-ID1-MQ-leg1-S-R` |
| OrderCancelled ref (MMP, leg1-bid) | `<CaseID>-ID1-MQ-leg1-B-CX-R` |
| OrderCancelled ref (MMP, leg1-offer) | `<CaseID>-ID1-MQ-leg1-S-CX-R` |
| MassQuoteAck ref | `<CaseID>-ID1-MQ-01-Ack-R` |

---

## Revision History

| Date | Version | Author | Description |
|---|---|---|---|
| 2026-08-02 | 1.0 | AI Assistant | Extracted from Binary_Interface_Transform_Rules.md |
