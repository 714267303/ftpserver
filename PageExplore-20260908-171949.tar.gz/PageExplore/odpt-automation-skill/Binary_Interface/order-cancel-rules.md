# Binary Interface: OrderCancelRequest (MsgType 23), OrderCancelled (MsgType 2) & OrderCancelRejected (MsgType 26) Rules

## Overview

This file defines the transformation rules for order cancellation messages: **OrderCancelRequest (23)**, **OrderCancelled (2)**, and **OrderCancelRejected (26)**. It also covers MMP-triggered cancellations with reason code 2119.

---

## 1. OrderCancelRequest (23) - Send Fields

### Field Mapping

| # | Template Field | Feature Header | Type | Mapping Rule |
|---|---|---|---|---|
| 1 | ClientOrderID | ClientOrderID | UINT64 | Original order's ClientOrderID |
| 2 | TransactionTime | (auto) | UINT64 | Not included; auto-generated |
| 3 | OrderID | OrderID | UINT64 | `<OrderAcceptedResponseRef>.OrderID` |
| 4 | SecurityID | SecurityID | TEXT | Same as original order |
| 5 | Side | Side | UINT8 | Same as original order |
| 6 | OriginalClientOrderID | OriginalClientOrderID | UINT64 | Alternative to OrderID; original order's ClientOrderID |

### Send Table Format Example

```gherkin
* <PART_SESSION> send:
    | MyRef                         | Template    | ClientOrderID                          | OrderID                             | SecurityID     | Side |
    | <CaseID>-<Role>-CO-01         | CancelOrder | <CaseID>-<Role>-CO-01.ClientOrderID    | <CaseID>-<Role>-SO-01-R.OrderID     | instrument_id1 | 1    |
```

---

## 2. OrderCancelled (2) - Expect Fields

### Field Mapping

| # | Template Field | Feature Header | Type | Mapping Rule |
|---|---|---|---|---|
| 1 | ClientOrderID | MyRef | UINT64 | Same as CancelRequest ClientOrderID |
| 2 | TransactionTime | (auto) | UINT64 | Not included; auto-generated |
| 3 | SecurityID | SecurityID | TEXT | Same as original |
| 4 | Side | Side | UINT8 | Same as original |
| 5 | OrderType | OrderType | UINT8 | `2`=Limit |
| 6 | OrderQty | OrderQty | INT32 | Original order qty |
| 7 | OrderPrice | OrderPrice | INT64 | Original order price |
| 8 | OrderID | OrderID | UINT64 | `<MyRef>-R.OrderID` |
| 9 | OrderStatus | OrderStatus | UINT8 | `4`=Cancelled |
| 10 | LeavesQty | LeavesQty | INT32 | Remaining qty after cancel (`0` if fully cancelled) |
| 11 | CumulativeQty | CumulativeQty | INT32 | Total filled before cancel |
| 12 | OrderCancelReason | OrderCancelReason | UINT16 | Cancel reason code |
| 13 | OriginatingSessionID | OriginatingSessionID | TEXT | Optional; session that initiated the cancel |
| 14 | OriginalClientOrderID | OriginalClientOrderID | UINT64 | Optional; original order's ClientOrderID |
| 15 | QuoteEntryID | QuoteEntryID | UINT16 | Optional; present for quote-originated orders |

### Expect Table Format Example

```gherkin
* <PART_SESSION> expect:
    | MyRef                       | ResponseRef                 | Template       | ClientOrderID                          | SecurityID     | Side | OrderType | OrderQty | OrderPrice | OrderID                       | OrderStatus | LeavesQty | CumulativeQty | OrderCancelReason |
    | <CaseID>-<Role>-CO-01       | <CaseID>-<Role>-CO-01-R    | OrderCancelled | <CaseID>-<Role>-CO-01.ClientOrderID    | instrument_id1 | 1    | 2         | 100      | 20000      | <CaseID>-<Role>-CO-01-R.OrderID | 4           | 0         | 0             | 0                 |
```

### Extended Example (with OriginatingSessionID, OriginalClientOrderID, QuoteEntryID)

```gherkin
* <PART_SESSION> expect:
    | MyRef           | Template       | ClientOrderID           | SecurityID     | Side | OrderID                 | CumulativeQty | OrderCancelReason | OriginatingSessionID | OriginalClientOrderID         | QuoteEntryID |
    | <CaseID>-MC-01  | OrderCancelled | <CaseID>-MC-01.ClientOrderID | instrument_id1 | 1    | <Ref>.OrderID           | 0             | 2501              | <SESSION>.COMPID    | <CaseID>-SO-01.ClientOrderID  | <notexist>   |
```

---

## 3. OrderCancelRejected (26) - Expect Fields

### Overview

OrderCancelRejected is sent when a CancelOrder request cannot be processed. Common reasons include:
- The order has already been filled/cancelled
- The order is in pending state
- The CancelOrder request references a non-existent order

### Field Mapping

| # | Template Field | Feature Table Header | Type | Mapping Rule |
|---|---|---|---|---|
| 1 | ClientOrderID | MyRef | UINT64 | Same as CancelOrder ClientOrderID |
| 2 | TransactionTime | (auto) | UINT64 | Not included; auto-generated |
| 3 | OrderStatus | OrderStatus | UINT8 | Current order status at time of reject |
| 4 | CancelRejectReason | CancelRejectReason | UINT8 | Rejection reason code |
| 5 | OriginalClientOrderID | OriginalClientOrderID | UINT64 | Original order's ClientOrderID |
| 6 | OrderID | OrderID | UINT64 | Optional; system OrderID if available |

### CancelRejectReason Codes

| Code | Description |
|---|---|
| `0` | Broker / Exchange Option |
| `1` | Unknown Order |
| `2` | Too Late to Cancel |
| `3` | Order Already in Pending Cancel or Pending Replace Status |
| `4` | Order Already Cancelled |
| `5` | Order Already Filled |
| `6` | Invalid OrderID |
| `99` | Other |

### Expect Table Format Example

```gherkin
* <PART_SESSION> expect:
    | MyRef                         | Template            | ClientOrderID                            | OrderStatus | CancelRejectReason | OriginalClientOrderID              |
    | <CaseID>-<Role>-CO-01         | OrderCancelRejected | <CaseID>-<Role>-CO-01.ClientOrderID      | 4           | 1                  | <CaseID>-<Role>-SO-01.ClientOrderID |
```

### Cancel Non-existent Order Pattern

```gherkin
* <PART_SESSION> send:
    | MyRef                         | Template    | SecurityID     | Side | OriginalClientOrderID |
    | <CaseID>-<Role>-CO-01         | CancelOrder | instrument_id1 | 1    | 3543831727918040143   |

* <PART_SESSION> expect:
    | MyRef                         | Template            | ClientOrderID                      | OrderStatus | CancelRejectReason | OriginalClientOrderID |
    | <CaseID>-<Role>-CO-01         | OrderCancelRejected | <CaseID>-<Role>-CO-01.ClientOrderID | 8           | 1                  | 3543831727918040143   |
```

---

## 4. MMP-Specific Cancel Pattern (Quote Cancel with Reason 2119)

When MMP is triggered and a quote entry has `CancelOnMMPTriggered=1`, the system cancels that quote entry's orders, resulting in OrderCancelled messages with `OrderCancelReason=2119`:

```gherkin
* <PART_SESSION> expect:
    | MyRef                       | ResponseRef                     | Template        | ClientOrderID                 | SecurityID     | Side | OrderType | OrderQty | OrderPrice | OrderID                               | OrderStatus | LeavesQty | CumulativeQty | OrderCancelReason |
    | <CaseID>-<Role>-MQ-01       | <CaseID>-<Role>-MQ-leg1-B-CX-R | OrderCancelled  | <CaseID>-<Role>-MQ-01.QuoteID | instrument_id1 | 1    | 2         | 1        | 10         | <CaseID>-<Role>-MQ-leg1-B-R.OrderID  | 4           | 0         | 0             | 2119               |
    | <CaseID>-<Role>-MQ-01       | <CaseID>-<Role>-MQ-leg1-S-CX-R | OrderCancelled  | <CaseID>-<Role>-MQ-01.QuoteID | instrument_id1 | 2    | 2         | 1        | 10         | <CaseID>-<Role>-MQ-leg1-S-R.OrderID  | 4           | 0         | 0             | 2119               |
```

**ResponseRef Naming for MMP Cancelled:**
- `<CaseID>-<Role>-MQ-leg<N>-{B|S}-CX-R` (CX = Cancel, indicating it was the MMP-cancelled state)

---

## 5. Cancel Reason Code Reference

### OrderCancelReason Codes

| OrderCancelReason | Description |
|---|---|
| `0` | User-initiated cancel (no specific reason) |
| `2501` | Cancelled due to mass quote cancel (81) |
| `2502` | Cancelled due to quote amend |
| `2503` | Cancelled due to quote cancel |
| `2105` | CanceledByGiveUpFirm |
| `2119` | Cancelled on MMP triggered |

### CancelRejectReason Codes

| CancelRejectReason | Description |
|---|---|
| `0` | Broker / Exchange Option |
| `1` | Unknown Order |
| `2` | Too Late to Cancel |
| `3` | Order Already in Pending Cancel or Pending Replace Status |
| `4` | Order Already Cancelled |
| `5` | Order Already Filled |
| `6` | Invalid OrderID |
| `99` | Other |

---

## 6. Variable Naming Convention

| Operation | MyRef Pattern |
|---|---|
| Standard Cancel | `<CaseID>-<Role>-CO-<Seq>` |
| Cancel from quote | `<CaseID>-<Role>-CQ-<Seq>` |
| Cancel on fill | `<CaseID>-<Role>-COF-<Seq>` |
| OrderCancelRejected | Same as CancelOrder MyRef |

---

## 7. FS Mandatory Fields (Rule 13.5)

### 13.5 OrderCancelRequest (23) - Mandatory Field Reference

| # | Template Field | Feature Header | Mandatory | Default |
|---|---|---|---|---|
| 1 | TransactionTime | (auto) | **Yes (M)** | Auto by system; NOT in table |
| 2 | ClientOrderID | ClientOrderID | **Yes (M)** | Original order's ClientOrderID |
| 3 | OrderID | OrderID | **Yes (M)** | `<OrderAcceptedResponseRef>.OrderID` |
| 4 | SecurityID | SecurityID | **Yes (M)** | Same as original order |
| 5 | Side | Side | **Yes (M)** | Same as original order |

### 13.5a OrderCancelled (2) - Mandatory Field Reference

| # | Template Field | Feature Header | Mandatory | Default |
|---|---|---|---|---|
| 1 | ClientOrderID | MyRef | **Yes (M)** | Same as CancelRequest ClientOrderID |
| 2 | TransactionTime | (auto) | **Yes (M)** | Auto by system; NOT in table |
| 3 | SecurityID | SecurityID | **Yes (M)** | Same as original |
| 4 | Side | Side | **Yes (M)** | Same as original |
| 5 | OrderType | OrderType | **Yes (M)** | `2`=Limit |
| 6 | OrderQty | OrderQty | **Yes (M)** | Original order qty |
| 7 | OrderPrice | OrderPrice | **Yes (M)** | Original order price |
| 8 | OrderID | OrderID | **Yes (M)** | `<MyRef>-R.OrderID` |
| 9 | OrderStatus | OrderStatus | **Yes (M)** | `4`=Cancelled |
| 10 | LeavesQty | LeavesQty | **Yes (M)** | `0` if fully cancelled |
| 11 | CumulativeQty | CumulativeQty | **Yes (M)** | Total filled before cancel |
| 12 | OrderCancelReason | OrderCancelReason | **Yes (M)** | Cancel reason code |

### 13.5b OrderCancelRejected (26) - Mandatory Field Reference

| # | Template Field | Feature Header | Mandatory | Default |
|---|---|---|---|---|
| 1 | ClientOrderID | MyRef | **Yes (M)** | Same as CancelOrder ClientOrderID |
| 2 | TransactionTime | (auto) | **Yes (M)** | Auto by system; NOT in table |
| 3 | OrderStatus | OrderStatus | **Yes (M)** | Current status at reject |
| 4 | CancelRejectReason | CancelRejectReason | **Yes (M)** | Rejection reason code |
| 5 | OriginalClientOrderID | OriginalClientOrderID | **Yes (M)** | Original order's ClientOrderID |

---

## Revision History

| Date | Version | Author | Description |
|---|---|---|---|
| 2026-08-02 | 1.0 | AI Assistant | Extracted from Binary_Interface_Transform_Rules.md; added OrderCancelRejected (26) |
