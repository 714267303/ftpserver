# Binary Interface: Order Lifecycle Rules (MsgType 30, 32)

## Overview

This file defines the transformation rules for order lifecycle messages: **OrderRestated (30)** and **OrderDoneforDay (32)**.

---

## 1. OrderRestated (30) - Expect Fields

### Overview

OrderRestated (30) is sent when an order is restated due to administrative actions like:
- Instrument modification (e.g., corporate action adjustment)
- Market state change affecting the order
- System restart/order recovery

### Field Mapping

| # | Template Field | Feature Table Header | Type | Mapping Rule |
|---|---|---|---|---|
| 1 | ClientOrderID | MyRef | UINT64 | Reference matching original order |
| 2 | TransactionTime | (auto) | UINT64 | Not included; auto-generated |
| 3 | SecurityID | SecurityID | TEXT | Same as original order |
| 4 | Side | Side | UINT8 | Same as original order |
| 5 | OrderType | OrderType | UINT8 | `2`=Limit |
| 6 | OrderQty | OrderQty | INT32 | Current order quantity |
| 7 | OrderPrice | OrderPrice | INT64 | Current order price |
| 8 | OrderID | OrderID | UINT64 | System OrderID |
| 9 | OrderStatus | OrderStatus | UINT8 | Status after restatement |
| 10 | LeavesQty | LeavesQty | INT32 | Remaining quantity |
| 11 | CumulativeQty | CumulativeQty | INT32 | Filled quantity |
| 12 | ExecRestatementReason | ExecRestatementReason | UINT8 | Reason for restatement |
| 13 | OriginatingSessionID | OriginatingSessionID | TEXT | Optional |
| 14 | TimeInForce | TimeInForce | UINT8 | Optional |
| 15 | SMPID | SMPID | UINT64 | Optional |
| 16 | ATID | ATID | TEXT | Optional |
| 17 | PositionEffect | PositionEffect | TEXT | Optional |
| 18 | GiveUpParticipant | GiveUpParticipant | TEXT | Optional |
| 19 | ClearingAccount | ClearingAccount | TEXT | Optional |
| 20 | CustomerInformation | CustomerInformation | TEXT | Optional |
| 21 | AHTIndicator | AHTIndicator | UINT8 | Optional |
| 22 | CancelHintValue | CancelHintValue | UINT8 | Optional |

### ExecRestatementReason Codes

| Code | Description |
|---|---|
| `0` | GT Corporate action / GT renewal |
| `101` | Order reactivated |
| `102` | Order restated on system restart |
| `103` | Instrument modification |

### Expect Table Format Example

```gherkin
* <PART_SESSION> expect:
    | MyRef                | Template      | SecurityID     | Side | OrderType | OrderQty | OrderPrice | ExecRestatementReason |
    | <CaseID>-<Role>-RS-01 | OrderRestated | instrument_id1 | 1    | 2         | 100      | 20000      | 102                   |
```

---

## 2. OrderDoneforDay (32) - Expect Fields

### Overview

OrderDoneforDay (32) is sent when a Day order (TimeInForce=0) expires at the end of the trading day without being fully filled. It indicates the remaining portion of the order is no longer active for the current trading session.

### Field Mapping

| # | Template Field | Feature Table Header | Type | Mapping Rule |
|---|---|---|---|---|
| 1 | ClientOrderID | MyRef | UINT64 | Reference matching original order |
| 2 | TransactionTime | (auto) | UINT64 | Not included; auto-generated |
| 3 | SecurityID | SecurityID | TEXT | Same as original order |
| 4 | Side | Side | UINT8 | Same as original order |
| 5 | OrderID | OrderID | UINT64 | System OrderID |
| 6 | LeavesQty | LeavesQty | INT32 | Remaining (unfilled) quantity |
| 7 | CumulativeQty | CumulativeQty | INT32 | Filled quantity |
| 8 | OrderDoneforDayReason | OrderDoneforDayReason | UINT8 | Reason code |
| 9 | OriginatingSessionID | OriginatingSessionID | TEXT | Optional |

### OrderDoneforDayReason Codes

| Code | Description |
|---|---|
| `0` | End of trading day |
| `1` | Market closed |

### Expect Table Format Example

```gherkin
* <PART_SESSION> expect:
    | MyRef                | Template      | SecurityID     | Side | OrderDoneforDayReason |
    | <CaseID>-<Role>-DD-01 | OrderDone     | instrument_id1 | 1    | 0                     |
```

---

## 3. Variable Naming Convention

| Operation | MyRef Pattern |
|---|---|
| OrderRestated | `<CaseID>-<Role>-RS-<Seq>` |
| OrderDoneforDay | `<CaseID>-<Role>-DD-<Seq>` |

---

## 4. FS Mandatory Fields

### OrderRestated (30) - Mandatory Field Reference

| # | Template Field | Feature Header | Mandatory | Default |
|---|---|---|---|
| 1 | ClientOrderID | MyRef | **Yes (M)** | Same as original order's ClientOrderID |
| 2 | TransactionTime | (auto) | **Yes (M)** | Auto by system; NOT in table |
| 3 | SecurityID | SecurityID | **Yes (M)** | |
| 4 | Side | Side | **Yes (M)** | |
| 5 | OrderType | OrderType | **Yes (M)** | `2`=Limit |
| 6 | OrderQty | OrderQty | **Yes (M)** | |
| 7 | OrderPrice | OrderPrice | **Yes (M)** | |
| 8 | OrderID | OrderID | **Yes (M)** | |
| 9 | LeavesQty | LeavesQty | **Yes (M)** | |
| 10 | CumulativeQty | CumulativeQty | **Yes (M)** | |
| 11 | ExecRestatementReason | ExecRestatementReason | **Yes (M)** | |

### OrderDoneforDay (32) - Mandatory Field Reference

| # | Template Field | Feature Header | Mandatory | Default |
|---|---|---|---|
| 1 | ClientOrderID | MyRef | **Yes (M)** | |
| 2 | TransactionTime | (auto) | **Yes (M)** | Auto by system; NOT in table |
| 3 | SecurityID | SecurityID | **Yes (M)** | |
| 4 | Side | Side | **Yes (M)** | |
| 5 | OrderID | OrderID | **Yes (M)** | |
| 6 | LeavesQty | LeavesQty | **Yes (M)** | |
| 7 | CumulativeQty | CumulativeQty | **Yes (M)** | |
| 8 | OrderDoneforDayReason | OrderDoneforDayReason | **Yes (M)** | |

---

## Revision History

| Date | Version | Author | Description |
|---|---|---|---|
| 2026-08-02 | 1.0 | AI Assistant | Created rule file for OrderRestated (30), OrderDoneforDay (32) |
