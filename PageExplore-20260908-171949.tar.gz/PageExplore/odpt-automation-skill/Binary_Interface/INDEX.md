# Binary Interface Transform Rules - Index

## Overview
This directory contains detailed transformation rules for all Binary Interface message types used in ODP test automation. Each file covers one or more related message types as listed below.

## File Listing

| # | File Name | MsgTypes Covered | Description |
|---|---|---|---|
| 1 | [general-rules.md](./general-rules.md) | (n/a) | General field mappings, conventions, variable naming, ResponseRef, OrderID patterns |
| 2 | [new-order-rules.md](./new-order-rules.md) | 21, 22(S) | NewOrder, NewOrderFromWholesale; Send table format, optional fields |
| 3 | [order-accepted-rules.md](./order-accepted-rules.md) | 27, 151(S), 153(X) | OrderAccepted field mapping, OrderStatus details, common patterns |
| 4 | [order-executed-rules.md](./order-executed-rules.md) | 31 | OrderExecuted: field mapping, TradeID & ExecutionID patterns |
| 5 | [order-cancel-rules.md](./order-cancel-rules.md) | 23, 2, 26 | CancelOrder (send), OrderCancelled (expect), OrderCancelRejected (expect) |
| 6 | [order-amend-rules.md](./order-amend-rules.md) | 22, 25, 28 | OrderAmendRequest (send), OrderAmended (expect), AmendRejected (expect) |
| 7 | [order-rejected-rules.md](./order-rejected-rules.md) | 24 | OrderRejected: field mapping, reject reason codes, pairing rules |
| 8 | [order-lifecycle-rules.md](./order-lifecycle-rules.md) | 30, 32 | OrderRestated, OrderDoneforDay |
| 9 | [mass-cancel-rules.md](./mass-cancel-rules.md) | 81-86 | MassOrderCancel, MassOrderCancelReport, OBO Single/Mass Cancel & Ack |
| 10 | [mass-quote-rules.md](./mass-quote-rules.md) | 35, 36, 37 | MassQuote (send), MassQuoteAck (expect), QuoteCancel (send) |
| 11 | [single-quote-rules.md](./single-quote-rules.md) | 38, 39, 40 | SingleQuote (send), SingleQuoteAck (expect), QuoteResponse (expect) |
| 12 | [error-trade-claim-rules.md](./error-trade-claim-rules.md) | 151-156 | ErrorTradeClaimRequest/Ack/Notification/Consent/Reject |
| 13 | [trade-adjusted-rules.md](./trade-adjusted-rules.md) | 165 | TradeAdjusted: field mapping, adjustment reason codes |
| 14 | [trade-status-rules.md](./trade-status-rules.md) | 157, 158, 160 | TradeCancelled, TradePartiallyCancelled, ExchangeOnBehalfTrade |
| 15 | [block-trade-rules.md](./block-trade-rules.md) | (BlockTrade) | Block trade submission rules |
| 16 | [mmp-rules.md](./mmp-rules.md) | 181-186 | MMPTriggered, MmpParametersEnquiry/Ack, MMPReleaseRequest/Ack |
| 17 | [other-messages-rules.md](./other-messages-rules.md) | (various) | Miscellaneous message types not covered above |

## Quick Reference by MsgType

| MsgType | Name | Direction | Category | Rule File |
|---|---|---|---|---|
| 2 | OrderCancelled | Expect | Cancel | cancel-rules.md |
| 21 | NewOrder | Send | Order | new-order-rules.md |
| 22 | OrderAmendRequest | Send | Amend | amend-rules.md |
| 23 | CancelOrder | Send | Cancel | cancel-rules.md |
| 24 | OrderRejected | Expect | Order | order-rejected-rules.md |
| 25 | AmendRejected | Expect | Amend | amend-rules.md |
| 26 | OrderCancelRejected | Expect | Cancel | cancel-rules.md |
| 27 | OrderAccepted | Expect | Order | order-accepted-rules.md |
| 28 | OrderAmended | Expect | Amend | amend-rules.md |
| 30 | OrderRestated | Expect | Lifecycle | order-lifecycle-rules.md |
| 31 | OrderExecuted | Expect | Order | order-executed-rules.md |
| 32 | OrderDoneforDay | Expect | Lifecycle | order-lifecycle-rules.md |
| 35 | MassQuote | Send | Quote | mass-quote-rules.md |
| 36 | MassQuoteAck | Expect | Quote | mass-quote-rules.md |
| 37 | QuoteCancel | Send | Quote | mass-quote-rules.md |
| 81 | MassOrderCancel | Send | Cancel | mass-cancel-rules.md |
| 82 | MassOrderCancelReport | Expect | Cancel | mass-cancel-rules.md |
| 83 | OBOSingleOrderCancel | Send | Cancel | mass-cancel-rules.md |
| 84 | OBOSingleOrderCancelAck | Expect | Cancel | mass-cancel-rules.md |
| 85 | OBOMassOrderCancel | Send | Cancel | mass-cancel-rules.md |
| 86 | OBOMassOrderCancelReport | Expect | Cancel | mass-cancel-rules.md |
| 151 | ErrorTradeClaimRequest | Send | ErrorTrade | error-trade-claim-rules.md |
| 152 | ErrorTradeClaimAck | Expect | ErrorTrade | error-trade-claim-rules.md |
| 153 | ErrorTradeClaimNotification | Expect | ErrorTrade | error-trade-claim-rules.md |
| 157 | TradeCancelled | Expect | TradeStatus | trade-status-rules.md |
| 158 | TradePartiallyCancelled | Expect | TradeStatus | trade-status-rules.md |
| 160 | ExchangeOnBehalfTrade | Expect | TradeStatus | trade-status-rules.md |
| 165 | TradeAdjusted | Expect | TradeStatus | trade-adjusted-rules.md |
| 181 | MMPTriggered | Expect | MMP | mmp-rules.md |
| 182 | MmpParametersEnquiry | Send | MMP | mmp-rules.md |
| 183 | MmpParametersAck | Expect | MMP | mmp-rules.md |
| 185 | MMPReleaseRequest | Send | MMP | mmp-rules.md |
| 186 | MMPReleaseAck | Expect | MMP | mmp-rules.md |
| - | BlockTradeCreate | Send | BlockTrade | block-trade-rules.md |
| - | BlockTradeResponse | Expect | BlockTrade | block-trade-rules.md |

## Notes
- Message templates are referenced from the `features/templates.csv` file
- Common CSV data is referenced from `resource/dataSet-ODP*.csv` files
- Variable naming patterns follow the conventions in [general-rules.md](./general-rules.md)
- Wire message and enum meanings are indexed from the live dictionary in [`../FIXODPMSG_Index.md`](../FIXODPMSG_Index.md) (regenerate with `python3 tools/build_fix_message_index.py --input ../etc/FIXODPMSG.xml --transport ../etc/FIXODP.xml`).
- Reject/status descriptions are indexed separately in [`../Error_Code_Index.md`](../Error_Code_Index.md). Resolve by `CATEGORY_ID:CODE`; the same numeric code can have different meanings across response categories.
- The expanded hand-off source is [`../sources/error_code_index_user_supplied_20260901.json`](../sources/error_code_index_user_supplied_20260901.json). Regenerate both formats with `python3 tools/build_error_code_index.py --json odpt-automation-skill/sources/error_code_index_user_supplied_20260901.json`.
