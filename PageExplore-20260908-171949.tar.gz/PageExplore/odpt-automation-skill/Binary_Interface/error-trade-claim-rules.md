# Binary Interface: Error Trade Claim Rules (MsgType 151-156)

## Overview

This file defines the transformation rules for error trade claim messages: **ErrorTradeClaimRequest (151)**, **ErrorTradeClaimAck (152)**, **ErrorTradeClaimNotification (153)**, **ContraSideConsent (154-155)**, and **ErrorTradeClaimStatusReport (156)**.

---

## 1. ErrorTradeClaimRequest (151) - Send Fields

### 8.9 ErrorTradeClaimRequest (151) - Send Fields

| # | Template Field | Feature Header | Mapping Rule |
|---|---|---|---|
| 1 | ClientErrorTradeClaimID | MyRef | Unique reference: `<CaseID>-<Role>-EC-<Seq>` |
| 2 | TransactionTime | (auto) | Not in table |
| 3 | SecurityID | SecurityID | Same as original trade |
| 4 | Side | Side | Same as original trade |
| 5 | ExecutionQty | ExecutionQty | Trade qty to claim |
| 6 | ExecutionPrice | ExecutionPrice | Trade price to claim |
| 7 | TradeID | TradeID | `<OrderExecuted-M-R>.TradeID` (counterparty's matched trade ID) |
| 8 | TradeConclusionDateTime | (not used) | Pre-saved via `Save Trade Conclusion Date Time` |

### 8.10 ErrorTradeClaimRequest (151) - Send Table Format Example

```gherkin
## Step <N>: <User> report error trade via Error Trade Claim Request(151)
* Save Trade Conclusion Date Time to "claim_time<N>"
* <PART_SESSION> send:
    | MyRef                         | Template                | TradeID                          | SecurityID     | Side | ExecutionQty | ExecutionPrice |
    | <CaseID>-<Role>-EC-<Seq>      | ErrorTradeClaimRequest  | <CaseID>-<Role>-SO-<Seq>-R.TradeID | instrument_id1 | <N>  | <Qty>        | <Price>        |
```

---

## 2. ErrorTradeClaimAck (152) - Expect Fields

### 8.10 ErrorTradeClaimAck (152) - Expect Fields

| # | Template Field | Feature Header | Mapping Rule |
|---|---|---|---|
| 1 | ClientErrorTradeClaimID | ClientErrorTradeClaimID | `<MyRef>.ClientErrorTradeClaimID` |
| 2 | TransactionTime | (auto) | Not in table |
| 3 | SecurityID | SecurityID | Same as request |
| 4 | Side | Side | Same as request |
| 5 | ExecutionQty | ExecutionQty | Same as request |
| 6 | ExecutionPrice | ExecutionPrice | Same as request |
| 7 | TradeID | TradeID | `<ErrorClaimSendRef>.TradeID` |
| 8 | ErrorTradeClaimID | ErrorTradeClaimID | `<assign>` to capture for later use |
| 9 | ErrorTradeClaimStatus | ErrorTradeClaimStatus | `0`=Request Received (accepted), `1`=Request Rejected |
| 10 | ErrorTradeClaimRejectReason | ErrorTradeClaimRejectReason | `<notexist>` if accepted; error code if rejected |

### ErrorTradeClaimAck (152) - Expect Table Format Example

```gherkin
* <PART_SESSION> expect:
    | MyRef                         | Template              | ResponseRef           | ClientErrorTradeClaimID                | TradeID                          | SecurityID     | Side | ExecutionQty | ExecutionPrice | ErrorTradeClaimID | ErrorTradeClaimStatus | ErrorTradeClaimRejectReason |
    | <CaseID>-<Role>-EC-<Seq>      | ErrorTradeClaimAck    | <CaseID>-<Role>-EC-<Seq>-R | <CaseID>-<Role>-EC-<Seq>.ClientErrorTradeClaimID | <CaseID>-<Role>-SO-<Seq>-R.TradeID | instrument_id1 | <N>  | <Qty>        | <Price>        | <assign>         | 0                     | <notexist>                |
```

---

## 3. Counterparty Notification (153)

### ErrorTradeClaimNotification (153)

When a claim is submitted, the counterparty receives an ErrorTradeClaimNotification:

```gherkin
* <PART2_SESSION> expect:
    | MyRef                         | Template                       | ResponseRef           | ClientErrorTradeClaimID                | TradeID                          | SecurityID     | Side | ExecutionQty | ExecutionPrice | ErrorTradeClaimID | ErrorTradeClaimStatus | ErrorTradeClaimRejectReason |
    | <CaseID>-<Role>-<Seq>         | ErrorTradeClaimNotification     | <CaseID>-<Role>-<Seq>-R | <CaseID>-<Role>-EC-<Seq>.ClientErrorTradeClaimID | <CaseID>-<Role>-SO-<Seq>-R.TradeID | instrument_id1 | <N>  | <Qty>        | <Price>        | <assign>         | 0                     | <notexist>                |
```

---

## 4. ContraSideConsent (154-156)

### ContraSideConsent Flow

1. **ContraSideConsentRequest (154)** - Counterparty sends consent or decline
2. **ContraSideConsentAck (155)** - System acknowledges
3. **ErrorTradeClaimStatusReport (156)** - Status update

---

## 5. FS Mandatory Fields (Rule 13.4)

### 13.4 ErrorTradeClaimRequest (151) - Mandatory Field Reference

| # | Template Field | Feature Header | Mandatory | Default |
|---|---|---|---|---|
| 1 | ClientErrorTradeClaimID | MyRef | **Yes (M)** | `<CaseID>-<Role>-EC-<Seq>` |
| 2 | TransactionTime | (auto) | **Yes (M)** | Auto; NOT in table |
| 3 | SecurityID | SecurityID | **Yes (M)** | Same as original trade |
| 4 | Side | Side | **Yes (M)** | Same as original trade |
| 5 | ExecutionQty | ExecutionQty | **Yes (M)** | From trade data |
| 6 | ExecutionPrice | ExecutionPrice | **Yes (M)** | From trade data |
| 7 | TradeID | TradeID | **Yes (M)** | Counterparty's matched TradeID |

### 13.4a ErrorTradeClaimAck (152) - Mandatory Field Reference

| # | Template Field | Feature Header | Mandatory | Default |
|---|---|---|---|---|
| 1 | ClientErrorTradeClaimID | ClientErrorTradeClaimID | **Yes (M)** | `<MyRef>.ClientErrorTradeClaimID` |
| 2 | TransactionTime | (auto) | **Yes (M)** | Auto; NOT in table |
| 3 | SecurityID | SecurityID | **Yes (M)** | Same as request |
| 4 | Side | Side | **Yes (M)** | Same as request |
| 5 | ExecutionQty | ExecutionQty | **Yes (M)** | Same as request |
| 6 | ExecutionPrice | ExecutionPrice | **Yes (M)** | Same as request |
| 7 | TradeID | TradeID | **Yes (M)** | From request |
| 8 | ErrorTradeClaimID | ErrorTradeClaimID | **Yes (M)** | `<assign>` to capture |
| 9 | ErrorTradeClaimStatus | ErrorTradeClaimStatus | **Yes (M)** | `0`=Accepted, `1`=Rejected |
| 10 | ErrorTradeClaimRejectReason | ErrorTradeClaimRejectReason | No (O) | `<notexist>` if accepted; error code if rejected |

---

## Revision History

| Date | Version | Author | Description |
|---|---|---|---|
| 2026-08-02 | 1.0 | AI Assistant | Extracted from Binary_Interface_Transform_Rules.md as part of rule file split |
