# Binary Interface: TradeAdjusted (MsgType 165) Rules

## Overview

This file defines the transformation rules for **TradeAdjusted (165)** message type - received when a trade is adjusted after an error trade claim is accepted.

---

## 1. TradeAdjusted (165) - Expect Fields

### 8.22 TradeAdjusted (165) - Expect Fields

When an error trade claim is accepted and processed, the system sends TradeAdjusted messages to both parties.

### Single Instrument Pattern

For non-combo instruments, TradeAdjusted contains standard execution fields.

### Combo Instrument Pattern (with TradeAdjustedLegs)

When the adjusted trade involves a combo instrument, the TradeAdjusted response includes leg-level adjustment details. Similar to OrderExecutedLegs, the feature file must:

1. **Define leg details** using `Set FIX Group TradeAdjustedLegs`
2. **Reference the leg group** using `TradeAdjustedLegs[*]` columns

```gherkin
* Set FIX Group TradeAdjustedLegs:
    | Name | LegSecurityID  | LegSide | LegQty | LegExecutionPrice | LegExecutionQty | 
    | leg1 | instrument_id3 | 1       | 100    | 20000             | 100             | 
    | leg2 | instrument_id2 | 2       | 100    | 19980             | 100             | 
```

---

## 2. TradeAdjusted Flow

The typical flow for trade adjustment:

1. ErrorTradeClaimRequest → ErrorTradeClaimAck (accepted)
2. ErrorTradeClaimNotification to counterparty
3. ContraSideConsentRequest → ContraSideConsentAck
4. **TradeAdjusted (expect)** - Both parties receive trade adjustment
5. TradeCancelled (expect) - Original trade is cancelled

---

## Revision History

| Date | Version | Author | Description |
|---|---|---|---|
| 2026-08-02 | 1.0 | AI Assistant | Extracted from Binary_Interface_Transform_Rules.md |
