# Binary Interface: MMP Rules (MsgType 181-186)

## Overview

This file defines the transformation rules for Market Maker Protection (MMP) messages: **MMPTriggered (181)**, **MmpParametersEnquiry (182)**, **MmpParametersAck (183)**, **MMPReleaseRequest (185)**, and **MMPReleaseAck (186)**.

---

## 1. MMPTriggered (181) - Expect Fields

### Field Mapping

When MMP is triggered due to exceeding Quantity or Delta protection limits, the system sends MMPTriggered to the participant:

```gherkin
* <PART_SESSION> expect:
    | MyRef                    | ResponseRef                    | Template      | SecurityID     |
    | <CaseID>-<Role>-MMP-01  | <CaseID>-<Role>-MMP-01-R      | MMPTriggered  | instrument_id1 |
```

---

## 2. MMP Trigger Flow

The MMP trigger typically follows this flow:

1. **MassQuote (send)** - Submit quotes for an instrument
2. **OrderAccepted (expect)** - Quote sides are accepted (2N responses)
3. **(Optional) More quotes that cause MMP breach**
4. **MMPTriggered (expect)** - System notifies that MMP is triggered
5. **OrderCancelled (expect)** - Quote legs with `CancelOnMMPTriggered=1` are cancelled (reason=2119)
6. **(Optional) MMP Reset** - Wait for MMP reset period or send MMP release request

---

## 3. MmpParametersEnquiry (182) - Send Fields

### Field Mapping

| # | Template Field | Feature Table Header | Type | Mapping Rule |
|---|---|---|---|---|
| 1 | ClientOrderID | ClientOrderID | UINT64 | Unique reference: `<CaseID>-<Role>-MMPC-<Seq>` |
| 2 | TransactionTime | (auto) | UINT64 | Not included; auto-generated |
| 3 | SecurityID | SecurityID | TEXT | Instrument to query; optional |

### Send Table Format Example

```gherkin
* <PART_SESSION> send:
    | MyRef                   | Template           | SecurityID     |
    | <CaseID>-<Role>-MMPC-01 | MmpParametersEnquiry | instrument_id1 |
```

---

## 4. MmpParametersAck (183) - Expect Fields

### Field Mapping

| # | Template Field | Feature Table Header | Type | Mapping Rule |
|---|---|---|---|---|
| 1 | ClientOrderID | MyRef | UINT64 | Echo of enquiry ClientOrderID |
| 2 | TransactionTime | (auto) | UINT64 | Not included; auto-generated |
| 3 | SecurityID | SecurityID | TEXT | Instrument |
| 4 | MMPStatus | MMPStatus | UINT8 | Status of MMP parameters |
| 5 | MMPQuantityLimit | MMPQuantityLimit | INT32 | Aggregate quantity limit |
| 6 | MMPDeltaLimit | MMPDeltaLimit | INT64 | Delta limit value |
| 7 | MMPResetPeriod | MMPResetPeriod | INT32 | Reset period in seconds |
| 8 | MMPStatusPeriod | MMPStatusPeriod | INT32 | Status monitoring period |

### MMPStatus Codes

| Code | Description |
|---|---|
| `0` | Not defined |
| `1` | Active |
| `2` | Triggered |

### Expect Table Format Example

```gherkin
* <PART_SESSION> expect:
    | MyRef                   | ResponseRef                   | Template       | ClientOrderID                          | SecurityID     | MMPStatus | MMPQuantityLimit |
    | <CaseID>-<Role>-MMPC-01 | <CaseID>-<Role>-MMPC-01-R     | MmpParametersAck | <CaseID>-<Role>-MMPC-01.ClientOrderID | instrument_id1 | 1         | 10000            |
```

---

## 5. MMPReleaseRequest (185) - Send Fields

### Field Mapping

| # | Template Field | Feature Table Header | Type | Mapping Rule |
|---|---|---|---|---|
| 1 | ClientOrderID | ClientOrderID | UINT64 | Unique reference: `<CaseID>-<Role>-MMPR-<Seq>` |
| 2 | TransactionTime | (auto) | UINT64 | Not included; auto-generated |
| 3 | SecurityID | SecurityID | TEXT | Instrument to release MMP for |
| 4 | MMPEnquiryInstruction | MMPEnquiryInstruction | UINT8 | Release instruction type |

### MMPEnquiryInstruction Codes

| Code | Description |
|---|---|
| `0` | Enquiry (no action) |
| `1` | Send (trigger release/enquiry) |

### Send Table Format Example

```gherkin
* <PART_SESSION> send:
    | MyRef                   | Template          | SecurityID     | MMPEnquiryInstruction |
    | <CaseID>-<Role>-MMPR-01 | MMPReleaseRequest | instrument_id1 | 1                     |
```

---

## 6. MMPReleaseAck (186) - Expect Fields

### Field Mapping

| # | Template Field | Feature Table Header | Type | Mapping Rule |
|---|---|---|---|---|
| 1 | ClientOrderID | MyRef | UINT64 | Echo of release request ClientOrderID |
| 2 | TransactionTime | (auto) | UINT64 | Not included; auto-generated |
| 3 | SecurityID | SecurityID | TEXT | Instrument |
| 4 | MMPStatus | MMPStatus | UINT8 | Status after release |
| 5 | ResponseRef | ResponseRef | TEXT | Reference to the release request |

### Expect Table Format Example

```gherkin
* <PART_SESSION> expect:
    | MyRef                   | ResponseRef                   | Template       | ClientOrderID                          | SecurityID     | MMPStatus |
    | <CaseID>-<Role>-MMPR-01 | <CaseID>-<Role>-MMPR-01-R     | MMPReleaseAck  | <CaseID>-<Role>-MMPR-01.ClientOrderID | instrument_id1 | 1         |
```

---

## 7. MMP Reset Flow

After MMP is triggered, the participant may need to reset it:

```
1. (Optional) Wait for auto-reset period to expire
2. MmpParametersEnquiry (182) - Query current MMP status
3. MmpParametersAck (183) - System responds with status
4. MMPReleaseRequest (185) - Request MMP release
5. MMPReleaseAck (186) - System confirms release
6. (Continue trading)
```

---

## 8. ResponseRef Naming Convention for MMP

| Scenario | ResponseRef Pattern |
|---|---|
| MMPTriggered notification | `<CaseID>-<Role>-MMP-<Seq>-R` |
| MmpParametersAck | `<CaseID>-<Role>-MMPC-<Seq>-R` |
| MMPReleaseAck | `<CaseID>-<Role>-MMPR-<Seq>-R` |
| OrderCancelled (MMP trigger) | `<CaseID>-<Role>-MQ-leg<N>-{B|S}-CX-R` |

---

## 9. Variable Naming Convention

| Operation | MyRef Pattern |
|---|---|
| MMPTriggered expect | `<CaseID>-<Role>-MMP-<Seq>` |
| MmpParametersEnquiry send | `<CaseID>-<Role>-MMPC-<Seq>` |
| MMPReleaseRequest send | `<CaseID>-<Role>-MMPR-<Seq>` |

---

## 10. MMP Cancel Reasons

| Code | Description |
|---|---|
| `2119` | Cancelled on MMP triggered |

---

## Revision History

| Date | Version | Author | Description |
|---|---|---|---|
| 2026-08-02 | 1.0 | AI Assistant | Extracted from Binary_Interface_Transform_Rules.md; added MMPParameters, MMPRelease rules |
