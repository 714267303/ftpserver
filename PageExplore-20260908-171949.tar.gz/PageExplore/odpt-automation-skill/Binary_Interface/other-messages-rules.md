# Binary Interface: Other Messages Rules

## Overview

This file defines transformation rules for less common message types: SecurityDefinition (171-172), News (166), KillSwitch (95-96), QuoteRequest (71-72), and PublicQuoteRequest (73).

---

## 1. SecurityDefinition Request/Response (171-172)

### SecurityDefinitionRequest (171) - Send

Used to request instrument definitions:

```gherkin
* <PART_SESSION> send:
    | MyRef                                  | Template                        | SecurityDefinition | SecurityType |
    | <CaseID>-<Role>-SecDef-01              | SecurityDefinitionRequest       | instrument_id1    | FUT          |
```

### SecurityDefinition (172) - Expect

Response with instrument definition details:

```gherkin
* <PART_SESSION> expect:
    | MyRef                                  | Template                        | SecurityDefinition | SecurityType |
    | <CaseID>-<Role>-SecDef-01              | SecurityDefinition              | instrument_id1    | FUT          |
```

---

## 2. News (166)

The News message may be received as a broadcast:

```gherkin
* <PART_SESSION> expect:
    | MyRef                    | Template | Headline |
    | <CaseID>-<Role>-News-01  | News     | <value>  |
```

---

## 3. KillSwitch (95-96)

### KillSwitchRequest (95) - Send

Used to activate/deactivate kill switch:

```gherkin
* <PART_SESSION> send:
    | MyRef                    | Template           | KillSwitchAction |
    | <CaseID>-<Role>-KS-01   | KillSwitchRequest  | 1                |
```

### KillSwitchAck (96) - Expect

```gherkin
* <PART_SESSION> expect:
    | MyRef                    | Template       | ResponseRef                  | KillSwitchAction |
    | <CaseID>-<Role>-KS-01   | KillSwitchAck | <CaseID>-<Role>-KS-01-R      | 1                |
```

---

## 4. QuoteRequest (71-72)

### QuoteRequest (71) - Send

Used by market makers to request quotes:

```gherkin
* <PART_SESSION> send:
    | MyRef                    | Template      | SecurityID     | Side | OrderQty | OrderPrice |
    | <CaseID>-<Role>-QR-01   | QuoteRequest  | instrument_id1 | 1    | 100      | 20000      |
```

### QuoteRequestAck (72) - Expect

```gherkin
* <PART_SESSION> expect:
    | MyRef                    | Template       | ResponseRef                  | QuoteRequestID |
    | <CaseID>-<Role>-QR-01   | QuoteRequestAck | <CaseID>-<Role>-QR-01-R      | <MyRef>.QuoteRequestID |
```

---

## 5. PublicQuoteRequest (73)

### PublicQuoteRequest (73) - Send

```gherkin
* <PART_SESSION> send:
    | MyRef                          | Template              | SecurityID     | Side | OrderQty |
    | <CaseID>-<Role>-PubQR-01       | PublicQuoteRequest    | instrument_id1 | 1    | 100      |
```

---

## 6. Variable Naming Convention

| Operation | MyRef Pattern |
|---|---|
| Security Definition | `<CaseID>-<Role>-SecDef-<Seq>` |
| News | `<CaseID>-<Role>-News-<Seq>` |
| KillSwitch | `<CaseID>-<Role>-KS-<Seq>` |
| QuoteRequest | `<CaseID>-<Role>-QR-<Seq>` |
| PublicQuoteRequest | `<CaseID>-<Role>-PubQR-<Seq>` |

---

## Revision History

| Date | Version | Author | Description |
|---|---|---|---|
| 2026-08-02 | 1.0 | AI Assistant | Extracted from Binary_Interface_Transform_Rules.md |
