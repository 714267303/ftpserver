# Binary Interface: Block Trade Rules (MsgType 101-114)

## Overview

This file defines the transformation rules for block trade messages: TwoPartyBlockTrade (101-102), OnePartyBlockTrade (105-114), and related notifications.

---

## 1. OnePartyBlockTradeLeg Group Definition

### 8.11 OnePartyBlockTradeLegBodyFieldsLegs

Before sending a block trade request, define the leg group:

```gherkin
* Set FIX Group OnePartyBlockTradeLegBodyFieldsLegs:
    | Name                  | BlockTradeLegSecurityID | BlockTradeLegSide | BlockTradeLegPrice | BlockTradeLegQty |
    | <CaseID>-<Role>-leg<N> | instrument_id<N>        | <1 or 2>          | <Price>            | <Qty>            |
```

---

## 2. OnePartyBlockTradeRequest (105) - Send Fields

### 8.12 OnePartyBlockTradeRequest (105) - Send Fields

| # | Template Field | Feature Header | Mapping Rule |
|---|---|---|---|
| 1 | ClientTradeReportID | MyRef | `<CaseID>-<Role>-1P-<Seq>` |
| 2 | TransactionTime | (auto) | Not in table |
| 3 | AggregatedTrade | AggregatedTrade | `0`=Non-aggregated, `1`=Aggregated |
| 4 | BCANField | BCANField | **Yes (M)** Required field; default `ABC123.123` if not specified |
| 5 | CounterpartyEPID | CounterpartyEPID | Counterparty session (e.g., `part2`) |
| 6 | TradeConclusionDateTime | TradeConclusionDateTime | Pre-saved timestamp variable |
| 7 | EnablePriceWarning | EnablePriceWarning | `0`=Disabled |
| 8 | NoBlockTradeLegs | NoBlockTradeLegs | Number of legs (integer) |
| 9 | OnePartyBlockTradeLegBodyFieldsLegs[1] | OnePartyBlockTradeLegBodyFieldsLegs[1] | Reference to leg group name |
| 10 | OnePartyBlockTradeLegBodyFieldsLegs[2] | (additional leg columns) | Reference to additional legs |

### OnePartyBlockTradeRequest (105) - Send Table Format Example

```gherkin
## Step <N>: <User> submit block trade via One-partyBlockTradeRequest(105)
* Assign (Time.now.to_i * 1000000000) to trade_conclusion_date_time
* Set FIX Group OnePartyBlockTradeLegBodyFieldsLegs:
    | Name                  | BlockTradeLegSecurityID | BlockTradeLegSide | BlockTradeLegPrice | BlockTradeLegQty |
    | <CaseID>-<Role>-leg1   | instrument_id1          | 1                 | 20000              | 100              |
* <PART_SESSION> send:
    | MyRef                 | Template                   | AggregatedTrade | BCANField  | CounterpartyEPID | TradeConclusionDateTime    | EnablePriceWarning | NoBlockTradeLegs | OnePartyBlockTradeLegBodyFieldsLegs[1] |
    | <CaseID>-<Role>-1P-01 | One-partyBlockTradeRequest | 0               | ABC123.123 | part2            | trade_conclusion_date_time | 0                  | 1                | <CaseID>-<Role>-leg1                    |
```

---

## 3. OnePartyBlockTradeAck (106) - Expect Fields

| # | Template Field | Feature Header | Mapping Rule |
|---|---|---|---|
| 1 | ClientTradeReportID | ClientTradeReportID | `<MyRef>.ClientTradeReportID` |
| 2 | TransactionTime | (auto) | Not in table |
| 3 | AggregatedTrade | AggregatedTrade | Same as request |
| 4 | CounterpartyEPID | CounterpartyEPID | Same as request |
| 5 | BlockTradeStatus | BlockTradeStatus | `0`=Trade Pending, `1`=Completed, `2`=Cancelled, `3`=Declined |
| 6 | TradeReportID | TradeReportID | `<MyRef>.TradeReportID` |
| 7 | TradeRejectReason | TradeRejectReason | `<notexist>` if accepted |

### OnePartyBlockTradeAck (106) - Expect Table Format

```gherkin
* <PART_SESSION> expect:
    | MyRef                 | Template               | ResponseRef           | AggregatedTrade | CounterpartyEPID | BlockTradeStatus | TradeReportID                        | TradeRejectReason |
    | <CaseID>-<Role>-1P-01 | One-partyBlockTradeAck | <CaseID>-<Role>-1P-01-R | 0               | part2            | 0                | <CaseID>-<Role>-1P-01.TradeReportID | <notexist>        |
```

---

## 4. Additional Block Trade Messages

### OnePartyBlockTradeSubmissionNotification (108)
Received by the counterparty when a block trade is submitted:

```gherkin
* <PART2_SESSION> expect:
    | MyRef                       | Template                                | ResponseRef           | BlockTradeStatus | TradeReportID |
    | <CaseID>-<Role>-1P-01-Notify | One-partyBlockTradeSubmissionNotification | <CaseID>-<Role>-1P-01-Notify-R | 0                | ...           |
```

### OnePartyBlockTradeConfirmed (107)
Received by the submitter when the counterparty confirms or the trade completes:

```gherkin
* <PART_SESSION> expect:
    | MyRef                 | Template                        | ResponseRef           | BlockTradeStatus | TradeReportID |
    | <CaseID>-<Role>-1P-01-Cfm | One-partyBlockTradeConfirmed    | ...                   | 1                | ...           |
```

### BlockTradeLegMatched (114)
Received when a block trade leg is matched:

```gherkin
* <PART_SESSION> expect:
    | BlockTradeLegMatched |
```

---

## 5. BlockTradeLegMatched (114) - TradeType Values

The `BlockTradeLegMatched` message includes the `TradeType` field. Use the following values:

| TradeType | Description | Usage |
|---|---|---|
| `0` | Regular Trade | Standard block trade (most common) |
| `1` | Block Trade | Aggregated block trade |
| `2` | Aggregate Trade | Multi-leg aggregated trade |

**Default**: `0` (Regular Trade) for standard one-party and two-party block trades.

Also includes `BlockTradeType` field:

| BlockTradeType | Description |
|---|---|
| `0` | Regular Block Trade |
| `1` | Aggregated Block Trade |

**Default**: `0` (Regular Block Trade) unless the test case specifies aggregation.

## 6. Block Trade Flow Summary

```
1. Assign trade_conclusion_date_time
2. Set FIX Group OnePartyBlockTradeLegBodyFieldsLegs
3. PART1 send: One-partyBlockTradeRequest (105)
4. PART1 expect: One-partyBlockTradeAck (106) → BlockTradeStatus=0
5. PART2 expect: One-partyBlockTradeSubmissionNotification (108)
6. PART1 expect: One-partyBlockTradeConfirmed (107) → BlockTradeStatus=1
7. (Optional) PART1 expect: BlockTradeLegMatched (114)
```

---

## Revision History

| Date | Version | Author | Description |
|---|---|---|---|
| 2026-08-02 | 1.0 | AI Assistant | Extracted from Binary_Interface_Transform_Rules.md as part of rule file split |
| 2026-08-08 | 1.1 | AI Assistant | Added Section 5 (TradeType/BlockTradeType values for BlockTradeLegMatched), renumbered flow summary |
