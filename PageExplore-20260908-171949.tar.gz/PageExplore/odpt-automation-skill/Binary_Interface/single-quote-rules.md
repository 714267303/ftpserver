# Binary Interface: SingleQuote (MsgType 53-54) Rules

## Overview

This file defines the transformation rules for SingleQuote (53) and SingleQuoteAck (54) messages.

---

## 1. SingleQuote (53) - Send Fields

### 8.21 SingleQuote (53) - Send Fields

| # | Template Field | Feature Header | Mapping Rule |
|---|---|---|---|
| 1 | QuoteID | MyRef | `<CaseID>-<Role>-SQ-<Seq>` |
| 2 | TransactionTime | (auto) | Not in table |
| 3 | SecurityID | SecurityID | `instrument_id1` from dataset |
| 4 | BidSize | BidSize | Bid quantity |
| 5 | BidPrice | BidPrice | Bid price |
| 6 | OfferSize | OfferSize | Offer quantity |
| 7 | OfferPrice | OfferPrice | Offer price |

### 8.21 SingleQuote (53) - Send Table Format Example

```gherkin
* <PART_SESSION> send:
    | MyRef                    | Template    | SecurityID     | BidSize | BidPrice | OfferSize | OfferPrice |
    | <CaseID>-<Role>-SQ-01   | SingleQuote | instrument_id1 | 10      | 10050    | 10        | 10060      |
```

---

## 2. SingleQuote Response Patterns

Each single quote generates **2 OrderAccepted responses** (one for bid, one for offer) referencing the QuoteID:

```gherkin
* <PART_SESSION> expect:
    | MyRef                    | ResponseRef                    | Template      | ClientOrderID                | SecurityID     | Side | OrderType | OrderQty | OrderPrice | QuoteEntryID |
    | <CaseID>-<Role>-SQ-01   | <CaseID>-<Role>-SQ-01-Bid-R   | OrderAccepted | <CaseID>-<Role>-SQ-01.QuoteID | instrument_id1 | 1    | 2         | 10       | 10050      | 1            |
    | <CaseID>-<Role>-SQ-01   | <CaseID>-<Role>-SQ-01-Offer-R | OrderAccepted | <CaseID>-<Role>-SQ-01.QuoteID | instrument_id1 | 2    | 2         | 10       | 10060      | 1            |
```

If the single quote request is rejected, the system may respond with SingleQuoteAck:

```gherkin
* <PART_SESSION> expect:
    | MyRef                    | Template      | ResponseRef                    | QuoteID                        |
    | <CaseID>-<Role>-SQ-01   | SingleQuoteAck | <CaseID>-<Role>-SQ-01-Ack-R   | <CaseID>-<Role>-SQ-01.QuoteID  |
```

---

## 3. Variable Naming Convention

| Usage | Example MyRef |
|---|---|
| SingleQuote send | `<CaseID>-ID1-SQ-01` |
| OrderAccepted ref (bid) | `<CaseID>-ID1-SQ-01-Bid-R` |
| OrderAccepted ref (offer) | `<CaseID>-ID1-SQ-01-Offer-R` |
| SingleQuoteAck ref | `<CaseID>-ID1-SQ-01-Ack-R` |

---

## Revision History

| Date | Version | Author | Description |
|---|---|---|---|
| 2026-08-02 | 1.0 | AI Assistant | Extracted from Binary_Interface_Transform_Rules.md |
