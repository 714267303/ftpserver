# Binary Interface: OrderAccepted (MsgType 27) Rules

## Overview

This file defines the transformation rules for **OrderAccepted (27)** message type - the response received when a new order or quote entry side is accepted by the system.

---

## 1. Standard OrderAccepted Expect Fields

### 8.3 OrderAccepted (27) - Expect Fields

| # | Template Field | Feature Header | Mapping Rule |
|---|---|---|---|
| 1 | ClientOrderID | ClientOrderID | `<MyRef>.ClientOrderID` |
| 2 | TransactionTime | TransactionTime | Auto (not in table) |
| 3 | SecurityID | SecurityID | Same as send |
| 4 | Side | Side | Same as send |
| 5 | OrderType | OrderType | Same as send |
| 6 | OrderQty | OrderQty | Same as send |
| 7 | OrderPrice | OrderPrice | Same as send |
| 8 | OrderID | OrderID | `<MyRef>-R.OrderID` (auto-assigned) |
| 9 | ExecutionID | ExecutionID | Not typically checked |
| - | ClearingAccount | ClearingAccount | Same as send |

### 8.4 OrderAccepted (27) - Expect Table Format Example

```gherkin
* PART1_OF_ID_1 expect:
    | MyRef                         | ResponseRef                     | Template      | ClientOrderID                         | SecurityID     | Side | OrderType | OrderQty | OrderPrice |
    | <CaseID>-ID1-SO-01            | <CaseID>-ID1-SO-01-R            | OrderAccepted | <CaseID>-ID1-SO-01.ClientOrderID      | instrument_id1 | 1    | 2         | 100      | 20000      |
```

---

## 2. OrderAccepted as Quote Response (from MassQuote)

### 8.17 OrderAccepted (27) - Quote Response Fields (from MassQuote)

When responding to a successful quote entry side from MassQuote(51):

| # | Template Field | Feature Header | Mapping Rule |
|---|---|---|---|
| 1 | ClientOrderID | ClientOrderID | `<MyRef>.QuoteID` (the MyRef of the MassQuote send row) |
| 2 | TransactionTime | TransactionTime | Auto (not in table) |
| 3 | SecurityID | SecurityID | Same as quote entry's SecurityID |
| 4 | Side | Side | `1`=Buy(bid), `2`=Sell(offer) |
| 5 | OrderType | OrderType | `2`=Limit (quotes are always limit orders) |
| 6 | OrderQty | OrderQty | Same as quote entry's BidQty or OfferQty |
| 7 | OrderPrice | OrderPrice | Same as quote entry's BidPrice or OfferPrice |
| 8 | QuoteEntryID | QuoteEntryID | Same as quote entry's QuoteEntryID |
| 9 | QuoteAttributeFlags | QuoteAttributeFlags | Optional: Present if CancelOnMMPTriggered=1 |
| 10 | OrderID | OrderID | `<ResponseRef>.OrderID` (system assigned) |
| 11 | ExecutionID | ExecutionID | Not typically checked |

**Important:** Unlike regular NewOrder responses where `ClientOrderID` refers to a unique MyRef, for MassQuote responses the `ClientOrderID` carries the **QuoteID** (the MyRef of the MassQuote message). This means **multiple response rows can share the same MyRef** value in the expect table.

### 8.18 OrderAccepted (27) - Quote Response Expect Table Format Example

```gherkin
* <PART_SESSION> expect:
    | MyRef                       | ResponseRef                   | Template      | ClientOrderID                 | SecurityID     | Side | OrderType | OrderQty | OrderPrice | QuoteEntryID |
    | <CaseID>-<Role>-MQ-01       | <CaseID>-<Role>-MQ-leg1-B-R  | OrderAccepted | <CaseID>-<Role>-MQ-01.QuoteID | instrument_id1 | 1    | 2         | 1        | 10         | 1            |
    | <CaseID>-<Role>-MQ-01       | <CaseID>-<Role>-MQ-leg1-S-R  | OrderAccepted | <CaseID>-<Role>-MQ-01.QuoteID | instrument_id1 | 2    | 2         | 1        | 20         | 1            |
    | <CaseID>-<Role>-MQ-01       | <CaseID>-<Role>-MQ-leg2-B-R  | OrderAccepted | <CaseID>-<Role>-MQ-01.QuoteID | instrument_id2 | 1    | 2         | 1        | 10         | 2            |
```

**ResponseRef Naming Convention for MassQuote Responses:**
| Suffix | Meaning |
|---|---|
| `<CaseID>-<Role>-MQ-leg<N>-B-R` | Bid side accept response for leg `<N>` |
| `<CaseID>-<Role>-MQ-leg<N>-S-R` | Offer side accept response for leg `<N>` |

---

## 3. FS Mandatory Fields (Rule 13.2)

### 13.2 OrderAccepted (27) - Mandatory Field Reference

| # | Template Field | Feature Header | Mandatory | Default Value (if not in Excel) |
|---|---|---|---|---|
| 1 | ClientOrderID | ClientOrderID | **Yes (M)** | `<MyRef>.ClientOrderID` |
| 2 | TransactionTime | (auto-generated) | **Yes (M)** | Auto by system; NOT in table |
| 3 | SecurityID | SecurityID | **Yes (M)** | Same as send |
| 4 | Side | Side | **Yes (M)** | Same as send |
| 5 | OrderType | OrderType | **Yes (M)** | Same as send (`2` = Limit) |
| 6 | OrderQty | OrderQty | **Yes (M)** | Same as send |
| 7 | OrderPrice | OrderPrice | **Yes (M)** | Same as send |
| 8 | OrderID | OrderID | **Yes (M)** | `<MyRef>-R.OrderID` |
| 9 | ExecutionID | ExecutionID | No (O) | Not typically checked |
| - | ClearingAccount | ClearingAccount | No (O) | Only include if specified |

---

## 4. Variable Naming Convention

For standard orders, use `-R` suffix for OrderAccepted response refs.
For MassQuote-related OrderAccepted responses, use `-MQ-leg<N>-{B|S}-R` naming.

---

## Revision History

| Date | Version | Author | Description |
|---|---|---|---|
| 2026-08-02 | 1.0 | AI Assistant | Extracted from Binary_Interface_Transform_Rules.md as part of rule file split |
