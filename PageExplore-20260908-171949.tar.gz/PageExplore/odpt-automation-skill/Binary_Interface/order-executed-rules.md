# Binary Interface: OrderExecuted (MsgType 31) Rules

## Overview

This file defines the transformation rules for **OrderExecuted (31)** message type - received when an order is filled or executed.

---

## 1. Standard OrderExecuted Expect Fields

### 8.5 OrderExecuted (31) - Expect Fields (Single Instrument / Non-Combo)

| # | Template Field | Feature Header | Mapping Rule |
|---|---|---|---|
| 1 | ClientOrderID | ClientOrderID | `<MyRef>.ClientOrderID` |
| 2 | TransactionTime | TransactionTime | Auto (not in table) |
| 3 | SecurityID | SecurityID | Same as order |
| 4 | Side | Side | Same as order |
| 5 | OrderType | OrderType | Same as order |
| 6 | OrderQty | OrderQty | Same as order |
| 7 | OrderPrice | OrderPrice | Same as order |
| 8 | OrderID | OrderID | `<MyRef>-R.OrderID` |
| 9 | OrderStatus | OrderStatus | `2`=Filled, `1`=PartiallyFilled |
| 10 | LeavesQty | LeavesQty | Remaining qty (`0` if fully filled) |
| 11 | CumulativeQty | CumulativeQty | Total filled qty |
| 12 | ExecutionQty | ExecutionQty | This execution qty |
| 13 | ExecutionPrice | ExecutionPrice | This execution price |
| 14 | TradeID | TradeID | no need to check this field, ignore this field |
| 15 | TradeDate | TradeDate | `<today>` (saved date variable) |
| 16 | TradeType | TradeType | `0`=Regular |
| 17 | TradeSubType | TradeSubType | `1`=Standard order book |
| 18 | MatchType | MatchType | `4`=Order book match |
| 19 | TradeConfirmationIndicator | TradeConfirmationIndicator | `P`=Provisional, `C`=Confirmed, `<notexist>` if expect `P`, if test case no mention check this fiedl then no need to check this field in expected table |
| 20 | AggressorIndicator | AggressorIndicator | `0`=Not aggressor |
| 21 | TimeInForce | TimeInForce | `<notexist>` if expect `0` |

### 8.6 OrderExecuted (31) - Expect Table Format Example

```gherkin
* Save the next "0" "day" date to "today" with format "%Y%m%d"
* PART1_OF_ID_1 expect:
    | MyRef                       | ResponseRef                 | Template      | ClientOrderID                       | SecurityID     | Side | OrderType | OrderQty | OrderPrice | OrderID                         | OrderStatus | LeavesQty | CumulativeQty | ExecutionQty | ExecutionPrice | TradeID                         | TradeDate | TradeType | TradeSubType | MatchType |   AggressorIndicator | TimeInForce |
    | <CaseID>-ID1-SO-01          | <CaseID>-ID1-SO-01-M-R      | OrderExecuted | <CaseID>-ID1-SO-01.ClientOrderID    | instrument_id1 | 1    | 2         | 100      | 20000      | <CaseID>-ID1-SO-01-R.OrderID   | 2           | 0         | 100           | 100          | 20000          | <CaseID>-ID1-SO-01-R.TradeID  | today     | 0          | 1         | 4          |   0                  | 0           |
```

---

## 2. Combo Instrument Pattern (OrderExecuted with Legs)

### 8.7a OrderExecuted (31) - Combo Instrument Pattern (with OrderExecutedLegs)

When the test involves a **combo instrument** (e.g., HSIU7/Z7 calendar spread), the OrderExecuted response includes leg-level execution details. The feature file must:

1. **Define leg details first** using `Set FIX Group OrderExecutedLegs`
2. **Reference the leg group** using `OrderExecutedLegs[*]` columns in the expect table

#### Step 1: Define Leg Groups

```gherkin
* Set FIX Group OrderExecutedLegs:
    | Name | LegSecurityID  | LegSide | LegQty | LegExecutionPrice | LegExecutionQty |
    | leg1 | instrument_id3 | 1       | 100    | 20000             | 100             |
    | leg2 | instrument_id2 | 2       | 100    | 19980             | 100             |
```

| Group Field | Maps To | Description |
|---|---|---|
| `Name` | Row identifier | Used in `OrderExecutedLegs[N]` column references |
| `LegSecurityID` | `instrument_id3` or `instrument_id2` | The leg instrument from dataset (leg2/leg1) |
| `LegSide` | 1=Buy, 2=Sell | Side of the leg (opposite to combo side) |
| `LegQty` | Integer | Quantity of the leg |
| `LegExecutionPrice` | Integer/Decimal | Execution price of the leg |
| `LegExecutionQty` | Integer | Executed quantity |

**Important Design Rules:**
- **`leg1` = instrument_id3** (back month leg, e.g., HSIZ7 = {HSI_f_dis2})
- **`leg2` = instrument_id2** (front month leg, e.g., HSIU7 = {HSI_f_dis1})
- The execution price for a combo trade differs per leg (e.g., leg1=20000, leg2=19980)
- LegSide is **opposite to** the combo instrument side (e.g., if the combo is Side=1(Buy), leg1 might be Side=1(Buy) and leg2 might be Side=2(Sell) for a calendar spread)

#### Step 2: Add OrderExecutedLegs Columns to Expect Table

After defining the group, add `OrderExecutedLegs[N]` columns to the expect table:

```gherkin
* PART1_OF_ID_1 expect:
    | ... | OrderExecutedLegs[1] | OrderExecutedLegs[2] | ...
    | ... | leg1                 | leg2                 | ...
```

The `leg1` and `leg2` values in the expect table row reference the named entries from the `Set FIX Group OrderExecutedLegs` block.

#### Full Example

```gherkin
## Step 3: Orders matched - Trade executed, both parties receive Order Executed(31)
        * Save the next "0" "day" date to "today" with format "%Y%m%d"
        * Set FIX Group OrderExecutedLegs:
            | Name | LegSecurityID  | LegSide | LegQty | LegExecutionPrice | LegExecutionQty |
            | leg1 | instrument_id3 | 1       | 100    | 20000             | 100             |
            | leg2 | instrument_id2 | 2       | 100    | 19980             | 100             |
        * PART1_OF_ID_1 expect:
            | MyRef                  | ResponseRef               | Template      | ... | SecurityID     | Side | ... | TradeDate | TradeType | TradeSubType | MatchType | ... | OrderExecutedLegs[1] | OrderExecutedLegs[2] |
            | <CaseID>-ID1-SO-01     | <CaseID>-ID1-SO-01-M-R    | OrderExecuted | ... | instrument_id1 | 1    | ... | today     | 0          | 1          | 4         | ... | leg1                 | leg2                 |
```

### DataSet CSV Combo Header Convention (8.7c)

When a case uses combo (requiring legs), the dataset CSV header must include all 3 columns:

```csv
case_id,instrument_id1,instrument_id2,instrument_id3
ODP17.45.2.2,{HSI1/2},{HSI_f_dis1},{HSI_f_dis2}
```

Where:
- `instrument_id1` = combo instrument reference (e.g., `{HSI1/2}` = HSIU7/Z7)
- `instrument_id2` = leg 1 (front month) reference (e.g., `{HSI_f_dis1}` = HSIU7)
- `instrument_id3` = leg 2 (back month) reference (e.g., `{HSI_f_dis2}` = HSIZ7)

For single-instrument cases (no combo), the header and data use only `instrument_id1`.

---

## 3. FS Mandatory Fields (Rule 13.3)

### 13.3 OrderExecuted (31) - Mandatory Field Reference

| # | Template Field | Feature Header | Mandatory | Default Value (if not in Excel) |
|---|---|---|---|---|
| 1 | ClientOrderID | ClientOrderID | **Yes (M)** | `<MyRef>.ClientOrderID` |
| 2 | TransactionTime | (auto-generated) | **Yes (M)** | Auto by system; NOT in table |
| 3 | SecurityID | SecurityID | **Yes (M)** | Same as order |
| 4 | Side | Side | **Yes (M)** | Same as order |
| 5 | OrderType | OrderType | **Yes (M)** | Same as order (`2` = Limit) |
| 6 | OrderQty | OrderQty | **Yes (M)** | Same as order |
| 7 | OrderPrice | OrderPrice | **Yes (M)** | Same as order |
| 8 | OrderID | OrderID | **Yes (M)** | `<MyRef>-R.OrderID` |
| 9 | OrderStatus | OrderStatus | **Yes (M)** | `2`=Filled, `1`=PartiallyFilled |
| 10 | LeavesQty | LeavesQty | **Yes (M)** | `0` if fully filled |
| 11 | CumulativeQty | CumulativeQty | **Yes (M)** | From execution |
| 12 | ExecutionQty | ExecutionQty | **Yes (M)** | From execution |
| 13 | ExecutionPrice | ExecutionPrice | **Yes (M)** | From execution |
| 14 | TradeID | TradeID | No (O) | Not typically checked per existing convention |
| 15 | TradeDate | TradeDate | **Yes (M)** | `today` (saved date variable) |
| 16 | TradeType | TradeType | **Yes (M)** | `0`=Regular |
| 17 | TradeSubType | TradeSubType | **Yes (M)** | `1`=Standard order book |
| 18 | MatchType | MatchType | **Yes (M)** | `4`=Order book match |
| 19 | TradeConfirmationIndicator | TradeConfirmationIndicator | **Yes (M)** | `P`=Provisional, `C`=Confirmed |
| 20 | AggressorIndicator | AggressorIndicator | **Yes (M)** | `0`=Not aggressor |
| 21 | TimeInForce | TimeInForce | No (O) | `<notexist>` if expect `0` |

---

## 4. Reference Price Fields in Trading GUI "Error Trade Request View"

### 8.15 Reference Price Fields

When verifying the Error Trade Request View on the Trading GUI (DT OPS team view), the following reference price fields may display "N/A" when no prior trade or order exists for the instrument:

| # | Trading GUI Column | Feature Header | Value When No Prior Trade | Mapping Rule |
|---|---|---|---|---|
| 1 | Trade ID | TRADE ID | Trade ID from execution | `<OrderExecutedResponseRef>.TradeID` |
| 2 | Instrument | INSTRUMENT | Instrument ID | `instrument_id1` (resolved from dataset) |
| 3 | Traded Price | TRADED PRICE | Trade price | From execution (e.g., `20000`) |
| 4 | Traded Quantity | TRADED QTY | Trade qty | From execution (e.g., `100`) |
| 5 | Claimant EP | CLAIMANT EP | Claimant participant | `<PART_SESSION>` e.g., `PART1_OF_ID_1` |
| 6 | Claim Time | CLAIM TIME | Same as claim timestamp | Reference saved `<claim_time><N>` variable |
| 7 | Time Validation | TIME VALIDATION | Pass / Fail | `Pass` if within prescribed time limit |
| 8 | Last Traded Price | LAST TRADED PRICE | `N/A` when no prior trade | `N/A` |
| 9 | Reference Price | REFERENCE PRICE | Previous day settlement price | Numeric value (e.g., `20100`) |
| 10 | Best Bid/Offer | BEST BID/OFFER | `N/A` when no orders in book | `N/A` |
| 11 | Deviation | DEVIATION | Price difference | Calculated value (e.g., `100`) |
| 12 | Potential Loss | POTENTIAL LOSS | Loss amount | Calculated value (e.g., `500000`) |
| 13 | Current Status | CURRENT STATUS | Current claim status | `New` |
| 14 | Decided By | DECIDED BY | Empty initially | (leave blank) |
| 15 | Contra-EP Response | CONTRA-EP RESPONSE | Empty initially | (leave blank) |
| 16 | Clearing Status | CLEARING STATUS | `N/A` initially | `N/A` |

---

## Revision History

| Date | Version | Author | Description |
|---|---|---|---|
| 2026-08-02 | 1.0 | AI Assistant | Extracted from Binary_Interface_Transform_Rules.md as part of rule file split |
