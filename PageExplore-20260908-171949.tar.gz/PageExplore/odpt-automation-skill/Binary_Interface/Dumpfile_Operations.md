# FIX Dumpfile Operations

## Purpose

`Save FIX dumpfile` and `Load FIX dumpfile` persist the WABI/FIX state needed
when a Binary scenario is split into presetting, Day1, and Day2 Features.  They
are the canonical persistence steps for Binary and Hybrid Features.  Do not
emit the legacy GUI `Save/Load bigmap file` steps for a FIX state hand-off.

## Canonical steps

```ruby
Given(/^Save FIX dumpfile (.*?)$/) do |name |
  WabiFix::Dump.dump(@fixmap, "fixmap_#{name}") if @fixmap
  WabiFix::Dump.dump(@order_table_map, "order_table_map_#{name}") if @order_table_map
  WabiFix::Dump.dump(@history_messages, "history_messages_#{name}") if @history_messages
end

Given(/^Load FIX dumpfile (.*?)$/) do |name |
  WabiFix::Dump.merge!(@fixmap, "fixmap_#{name}") if @fixmap
  WabiFix::Dump.merge!($order_table_map, "order_table_map_#{name}") if $order_table_map
  WabiFix::Dump.merge!($history_messages, "history_messages_#{name}") if $history_messages

  # Before hooks copy the global references into the current Scenario, but a
  # dump is normally loaded by a step after those hooks have already run.
  # Refresh the Scenario-local maps now so the very next step can use MyRef
  # and ResponseRef values restored from the dump.
  load_global_ref
end
```

The executable WABI implementation lives in `lib/wabi-fix/cucumber_steps.rb`.
The code block above is kept in the skill as the contract used during
conversion and review.  `WabiFix::Dump` writes three namespaced dump files so
that FIX variables, response references, and history messages are restored
together.

## Gherkin examples

```gherkin
* Save FIX dumpfile ODP14a.4.2.2.7.Presetting
```

```gherkin
Background:
    * Load value from admin_gui_value
    * Load value from dataSet-ODP14a-value
    * Load FIX dumpfile ODP14a.4.2.2.7.Presetting
```

Use a distinct name for each lifecycle boundary, for example
`<case>.Presetting`, `<case>-Day1`, and `<case>-Day2`.  The name is passed to
the runtime unchanged; do not add a path traversal component or a secret.

## Scope boundary

GUI-only `@bigmap` values (such as an exported Admin table held for a later
GUI assertion) are a separate runtime concern.  If such a value is genuinely
needed, document it in the Admin flow and verify the target GUI runtime before
using it.  It must not be substituted for the FIX dumpfile when a later step
references `MyRef` or `ResponseRef`.

The historical `uat/uat_admin_feature.txt` corpus still contains old
`Save/Load bigmap file` examples. That file is evidence of legacy cases, not
the current generation contract; do not copy those names into new Binary or
Hybrid Features.
