# Binary Interface: Order Amend Rules (MsgType 22, 25, 28)

## Overview

This file defines the transformation rules for order amendment messages: **OrderAmendRequest (22)**, **OrderAmended (28)**, and **AmendRejected (25)**.

---

## 1. OrderAmendRequest (22) - Send Fields

### Field Mapping

| # | Template Field | Feature Table Header | Type | Mapping Rule |
|---|---|---|---|---|
| 1 | ClientOrderID | ClientOrderID | UINT64 | Unique reference: `<CaseID>-<Role>-AO-<Seq>` |
| 2 | TransactionTime | (auto) | UINT64 | Not included; auto-generated |
| 3 | SecurityID | SecurityID | TEXT | Same as original order |
| 4 | Side | Side | UINT8 | Same as original order |
| 5 | OriginalClientOrderID | OriginalClientOrderID | UINT64 | Original order's ClientOrderID: `<CaseID>-<Role>-SO-<Seq>.ClientOrderID` |
| 6 | OrderQty | OrderQty | INT32 | New quantity (must be filled) |
| 7 | OrderPrice | OrderPrice | INT64 | New price (must be filled) |
| 8 | TimeInForce | TimeInForce | UINT8 | Optional; include if changing |
| 9 | SMPID | SMPID | UINT64 | Optional |
| 10 | PositionEffect | PositionEffect | TEXT | Optional |
| 11 | GiveUpParticipant | GiveUpParticipant | TEXT | Optional |
| 12 | GiveUpInformation | GiveUpInformation | TEXT | Optional |
| 13 | OrderAttributeFlags | OrderAttributeFlags | UINT32 | Optional |
| 14 | ExpireDate | ExpireDate | UINT32 | Optional |
| 15 | ClearingAccount | ClearingAccount | TEXT | Optional |
| 16 | CustomerInformation | CustomerInformation | TEXT | Optional |
| 17 | CancelHintValue | CancelHintValue | UINT8 | Optional |

### Send Table Format Example

```gherkin
* <PART_SESSION> send:
    | MyRef                         | Template   | SecurityID     | Side | OriginalClientOrderID                    | OrderQty | OrderPrice |
    | <CaseID>-<Role>-AO-01         | AmendOrder | instrument_id1 | 1    | <CaseID>-<Role>-SO-01.ClientOrderID      | 80       | 21000      |
```

---

## 2. OrderAmended (28) - Expect Fields

### Field Mapping

| # | Template Field | Feature Header | Type | Mapping Rule |
|---|---|---|---|---|
| 1 | ClientOrderID | MyRef | UINT64 | Same as AmendOrder ClientOrderID |
| 2 | TransactionTime | (auto) | UINT64 | Not included; auto-generated |
| 3 | OriginalClientOrderID | OriginalClientOrderID | UINT64 | Echo of original order's ClientOrderID |
| 4 | SecurityID | SecurityID | TEXT | Same as original |
| 5 | Side | Side | UINT8 | Same as original |
| 6 | OrderType | OrderType | UINT8 | `2`=Limit |
| 7 | OrderQty | OrderQty | INT32 | New order quantity |
| 8 | OrderPrice | OrderPrice | INT64 | New order price |
| 9 | OrderID | OrderID | UINT64 | Order's system ID |
| 10 | ExecutionID | ExecutionID | UINT64 | Amend execution ID |
| 11 | OrderStatus | OrderStatus | UINT8 | Order status after amend |
| 12 | LeavesQty | LeavesQty | INT32 | Remaining qty after amend |
| 13 | CumulativeQty | CumulativeQty | INT32 | Total filled before/after amend |
| 14 | TimeInForce | TimeInForce | UINT8 | Optional |
| 15 | SMPID | SMPID | UINT64 | Optional |
| 16 | ATID | ATID | TEXT | Optional |
| 17 | PositionEffect | PositionEffect | TEXT | Optional |
| 18 | GiveUpParticipant | GiveUpParticipant | TEXT | Optional |
| 19 | GiveUpInformation | GiveUpInformation | TEXT | Optional |
| 20 | OrderAttributeFlags | OrderAttributeFlags | UINT32 | Optional |
| 21 | ExpireDate | ExpireDate | UINT32 | Optional |
| 22 | ClearingAccount | ClearingAccount | TEXT | Optional |
| 23 | CustomerInformation | CustomerInformation | TEXT | Optional |
| 24 | AHTIndicator | AHTIndicator | UINT8 | Optional |
| 25 | CancelHintValue | CancelHintValue | UINT8 | Optional |
| 26 | OriginatingSessionID | OriginatingSessionID | TEXT | Optional |

### Expect Table Format Example

```gherkin
* <PART_SESSION> expect:
    | MyRef                         | ResponseRef                 | Template      | ClientOrderID                    | OriginalClientOrderID              | SecurityID     | Side | OrderType | OrderQty | OrderPrice | OrderID                         | OrderStatus | LeavesQty | CumulativeQty |
    | <CaseID>-<Role>-AO-01         | <CaseID>-<Role>-AO-01-R     | OrderAmended  | <CaseID>-<Role>-AO-01.ClientOrderID | <CaseID>-<Role>-SO-01.ClientOrderID | instrument_id1 | 1    | 2         | 80       | 21000      | <CaseID>-<Role>-AO-01-R.OrderID | 1           | 0         | 0             |
```

---

## 3. AmendRejected (25) - Expect Fields

### Field Mapping

| # | Template Field | Feature Table Header | Type | Mapping Rule |
|---|---|---|---|---|
| 1 | ClientOrderID | MyRef | UINT64 | Same as AmendOrder ClientOrderID |
| 2 | TransactionTime | (auto) | UINT64 | Not included; auto-generated |
| 3 | OrderStatus | OrderStatus | UINT8 | Current order status |
| 4 | AmendRejectReason | AmendRejectReason | UINT8 | Rejection reason code |
| 5 | OriginalClientOrderID | OriginalClientOrderID | UINT64 | Original order's ClientOrderID |
| 6 | OrderID | OrderID | UINT64 | Optional; if available |

### Amend Reject Reason Codes

| AmendRejectReason | Description |
|---|---|
| `0` | Success (used in some negative test patterns) |
| `1` | Unknown order |
| `2` | Unknown client |
| `3` | Order already in pending cancel state |
| `4` | Order already in pending replace state |
| `5` | Order already cancelled/replaced |
| `6` | Order already filled |
| `7` | Invalid price |
| `8` | Invalid quantity |
| `9` | Other |

### Expect Table Format Example

```gherkin
* <PART_SESSION> expect:
    | MyRef                         | Template      | ClientOrderID                      | OrderStatus | AmendRejectReason | OriginalClientOrderID              |
    | <CaseID>-<Role>-AO-01         | AmendRejected | <CaseID>-<Role>-AO-01.ClientOrderID | 6           | 3                 | <CaseID>-<Role>-SO-01.ClientOrderID |
```

---

## 4. Variable Naming Convention

| Operation | MyRef Pattern |
|---|---|
| AmendOrder send | `<CaseID>-<Role>-AO-<Seq>` |
| OrderAmended expect (success) | `<CaseID>-<Role>-AO-<Seq>` (same MyRef) |
| AmendRejected expect (failure) | `<CaseID>-<Role>-AO-<Seq>` (same MyRef) |

---

## 5. Amend Chain Pattern (Concurrent Cancel + Amend)

When testing concurrent Cancel + Amend (Order Chain):

```gherkin
* Set Order Chain Start
* <PART_SESSION> send group requests:
    | MyRef                         | Template    | SecurityID     | Side | OriginalClientOrderID              |
    | <CaseID>-<Role>-CO-01         | CancelOrder | instrument_id1 | 1    | <CaseID>-<Role>-SO-01.ClientOrderID |

* <PART_SESSION> send group requests:
    | MyRef                         | Template   | SecurityID     | Side | OriginalClientOrderID              | OrderQty | OrderPrice |
    | <CaseID>-<Role>-AO-01         | AmendOrder | instrument_id1 | 1    | <CaseID>-<Role>-SO-01.ClientOrderID | 80       | 21000      |

* Set Order Chain End
* <PART_SESSION> expect:
    | MyRef                         | Template       | ClientOrderID                      | SecurityID     | Side | OrderID                         | CumulativeQty | OrderCancelReason |
    | <CaseID>-<Role>-CO-01         | OrderCancelled | <CaseID>-<Role>-CO-01.ClientOrderID | instrument_id1 | 1    | <CaseID>-<Role>-SO-01-R.OrderID | 0             | 2500              |

* <PART_SESSION> expect:
    | MyRef                         | Template      | ClientOrderID                      | OrderStatus | AmendRejectReason | OriginalClientOrderID              |
    | <CaseID>-<Role>-AO-01         | AmendRejected | <CaseID>-<Role>-AO-01.ClientOrderID | 6           | 3                 | <CaseID>-<Role>-SO-01.ClientOrderID |
```

---

## 6. FS Mandatory Fields (Rule 13.2, 13.8, 13.9)

### 13.2 OrderAmendRequest (22) - Mandatory Field Reference

| # | Template Field | Feature Header | Mandatory | Default |
|---|---|---|---|---|
| 1 | ClientOrderID | ClientOrderID | **Yes (M)** | `<CaseID>-<Role>-AO-<Seq>` |
| 2 | TransactionTime | (auto) | **Yes (M)** | Auto by system; NOT in table |
| 3 | SecurityID | SecurityID | **Yes (M)** | |
| 4 | Side | Side | **Yes (M)** | |
| 5 | OriginalClientOrderID | OriginalClientOrderID | **Yes (M)** | Original order's ClientOrderID |
| 6 | OrderQty | OrderQty | **Yes (M)** | New quantity |
| 7 | OrderPrice | OrderPrice | **Yes (M)** | New price |

### 13.8 OrderAmended (28) - Mandatory Field Reference

| # | Template Field | Feature Header | Mandatory | Default |
|---|---|---|---|---|
| 1 | ClientOrderID | MyRef | **Yes (M)** | Same as AmendOrder ClientOrderID |
| 2 | TransactionTime | (auto) | **Yes (M)** | Auto by system; NOT in table |
| 3 | OriginalClientOrderID | OriginalClientOrderID | **Yes (M)** | |
| 4 | SecurityID | SecurityID | **Yes (M)** | |
| 5 | Side | Side | **Yes (M)** | |
| 6 | OrderType | OrderType | **Yes (M)** | `2`=Limit |
| 7 | OrderQty | OrderQty | **Yes (M)** | |
| 8 | OrderPrice | OrderPrice | **Yes (M)** | |
| 9 | OrderID | OrderID | **Yes (M)** | |
| 10 | ExecutionID | ExecutionID | **Yes (M)** | |
| 11 | OrderStatus | OrderStatus | **Yes (M)** | |
| 12 | LeavesQty | LeavesQty | **Yes (M)** | |
| 13 | CumulativeQty | CumulativeQty | **Yes (M)** | |

### 13.9 AmendRejected (25) - Mandatory Field Reference

| # | Template Field | Feature Header | Mandatory | Default |
|---|---|---|---|---|
| 1 | ClientOrderID | MyRef | **Yes (M)** | Same as AmendOrder ClientOrderID |
| 2 | TransactionTime | (auto) | **Yes (M)** | Auto by system; NOT in table |
| 3 | OrderStatus | OrderStatus | **Yes (M)** | |
| 4 | AmendRejectReason | AmendRejectReason | **Yes (M)** | |
| 5 | OriginalClientOrderID | OriginalClientOrderID | **Yes (M)** | |

---

## Revision History

| Date | Version | Author | Description |
|---|---|---|---|
| 2026-08-02 | 1.0 | AI Assistant | Created rule file for OrderAmendRequest (22), OrderAmended (28), AmendRejected (25) |
