# Binary Interface: Trade Status & Exection Report Rules (MsgType 157, 158, 160)

## Overview

This file defines the transformation rules for trade status and special execution report messages:
- **TradeCancelled (157)** - Notification that a previously reported trade has been cancelled
- **TradePartiallyCancelled (158)** - Notification that part of a trade has been cancelled
- **ExchangeOnBehalfTrade (160)** - Exchange initiated on-behalf trade execution report

---

## 1. TradeCancelled (157) - Expect Fields

### Overview

TradeCancelled is sent when a previously executed trade is fully cancelled (e.g., due to error trade cancellation). This is a notification message sent to all affected parties.

### Field Mapping

| # | Template Field | Feature Table Header | Type | Mapping Rule |
|---|---|---|---|---|
| 1 | TransactionTime | (auto) | UINT64 | Not included; auto-generated |
| 2 | SecurityID | SecurityID | TEXT | Security of the cancelled trade |
| 3 | Side | Side | UINT8 | Side of the cancelled trade |
| 4 | OrderType | OrderType | UINT8 | `2`=Limit |
| 5 | OrderQty | OrderQty | INT32 | Original trade quantity |
| 6 | OrderPrice | OrderPrice | INT64 | Original trade price |
| 7 | OrderID | OrderID | UINT64 | System OrderID |
| 8 | ExecutionID | ExecutionID | UINT64 | Original trade's execution ID |
| 9 | OrderStatus | OrderStatus | UINT8 | `4`=Cancelled |
| 10 | LeavesQty | LeavesQty | INT32 | Remaining qty (0 if fully cancelled) |
| 11 | CumulativeQty | CumulativeQty | INT32 | Total filled (including cancelled trade) |
| 12 | TradeCancelReason | TradeCancelReason | UINT8 | Reason for trade cancellation |
| 13 | OriginatingSessionID | OriginatingSessionID | TEXT | Optional |
| 14 | TradeID | TradeID | UINT64 | Trade ID being cancelled |
| 15 | TradeMatchID | TradeMatchID | UINT32 | Match ID of the cancelled trade |
| 16 | OrigTradeID | OrigTradeID | UINT64 | Optional; original trade ID |
| 17 | OrigTradeMatchID | OrigTradeMatchID | UINT32 | Optional; original match ID |

### TradeCancelReason Codes

| Code | Description |
|---|---|
| `0` | User requested cancel |
| `1` | System initiated cancel |
| `2` | Error trade |
| `3` | Exchange initiated cancel |

### Expect Table Format Example

```gherkin
* <PART_SESSION> expect:
    | MyRef                | Template       | SecurityID     | Side | ExecutionID                     | TradeCancelReason |
    | <CaseID>-<Role>-TC-01 | TradeCancelled | instrument_id1 | 1    | <CaseID>-<Role>-EX-01-R.ExecutionID | 2                 |
```

---

## 2. TradePartiallyCancelled (158) - Expect Fields

### Overview

TradePartiallyCancelled is sent when only part of a previously executed trade is cancelled.

### Field Mapping

| # | Template Field | Feature Table Header | Type | Mapping Rule |
|---|---|---|---|---|
| 1 | TransactionTime | (auto) | UINT64 | Not included; auto-generated |
| 2 | SecurityID | SecurityID | TEXT | Security of the partially cancelled trade |
| 3 | Side | Side | UINT8 | Side of the trade |
| 4 | OrderQty | OrderQty | INT32 | Original trade quantity |
| 5 | OrderPrice | OrderPrice | INT64 | Trade price |
| 6 | OrderID | OrderID | UINT64 | System OrderID |
| 7 | ExecutionID | ExecutionID | UINT64 | Trade execution ID |
| 8 | OrderStatus | OrderStatus | UINT8 | Order status after partial cancel |
| 9 | LeavesQty | LeavesQty | INT32 | Remaining qty |
| 10 | CumulativeQty | CumulativeQty | INT32 | Total filled |
| 11 | TradeCancelReason | TradeCancelReason | UINT8 | Reason for cancellation |
| 12 | TradeID | TradeID | UINT64 | Trade ID being cancelled |
| 13 | TradeMatchID | TradeMatchID | UINT32 | Match ID of the cancelled trade |
| 14 | OrigTradeID | OrigTradeID | UINT64 | Optional; original trade ID |
| 15 | OrigTradeMatchID | OrigTradeMatchID | UINT32 | Optional; original match ID |

### Expect Table Format Example

```gherkin
* <PART_SESSION> expect:
    | MyRef                | Template               | SecurityID     | Side | TradeID      | TradeCancelReason |
    | <CaseID>-<Role>-TPC-1 | TradePartiallyCancelled | instrument_id1 | 1    | <CaseID>-<Role>-EX-01-R.TradeID | 2 |
```

---

## 3. ExchangeOnBehalfTrade (160) - Expect Fields

### Overview

ExchangeOnBehalfTrade (160) is an execution report sent when an exchange or system executes a trade on behalf of a participant. This is used in scenarios like Force Execution (FE), AHT Ref, or other exchange-initiated trades.

### Field Mapping

| # | Template Field | Feature Table Header | Type | Mapping Rule |
|---|---|---|---|---|
| 1 | ClientOrderID | MyRef | UINT64 | Contains the matching original order reference |
| 2 | TransactionTime | (auto) | UINT64 | Not included; auto-generated |
| 3 | SecurityID | SecurityID | TEXT | Security being traded |
| 4 | Side | Side | UINT8 | Side of the trade |
| 5 | OrderType | OrderType | UINT8 | `2`=Limit |
| 6 | OrderQty | OrderQty | INT32 | Quantity executed |
| 7 | OrderPrice | OrderPrice | INT64 | Price executed |
| 8 | OrderID | OrderID | UINT64 | System OrderID generated by the exchange |
| 9 | ExecutionID | ExecutionID | UINT64 | Exchange-generated execution ID |
| 10 | OrderStatus | OrderStatus | UINT8 | Status after execution |
| 11 | LeavesQty | LeavesQty | INT32 | Remaining quantity |
| 12 | CumulativeQty | CumulativeQty | INT32 | Total quantity filled |
| 13 | OriginatingSessionID | OriginatingSessionID | TEXT | Session on whose behalf the trade is executed |
| 14 | TradeID | TradeID | UINT64 | Trade ID |
| 15 | TradeMatchID | TradeMatchID | UINT32 | Match ID of the trade |
| 16 | OrigTradeID | OrigTradeID | UINT64 | Optional; original trade ID |
| 17 | OrigTradeMatchID | OrigTradeMatchID | UINT32 | Optional; original match ID |
| 18 | TimeInForce | TimeInForce | UINT8 | Optional |
| 19 | PositionEffect | PositionEffect | TEXT | Optional |
| 20 | GiveUpParticipant | GiveUpParticipant | TEXT | Optional |
| 21 | GiveUpInformation | GiveUpInformation | TEXT | Optional |
| 22 | OrderAttributeFlags | OrderAttributeFlags | UINT32 | Optional |
| 23 | ExpireDate | ExpireDate | UINT32 | Optional |
| 24 | ClearingAccount | ClearingAccount | TEXT | Optional |
| 25 | CustomerInformation | CustomerInformation | TEXT | Optional |
| 26 | AHTIndicator | AHTIndicator | UINT8 | Optional; commonly used for AHT ref trades |
| 27 | CancelHintValue | CancelHintValue | UINT8 | Optional |

### OrderStatus Values

| Code | Description |
|---|---|
| `0` | New |
| `1` | Partially filled |
| `2` | Filled |
| `4` | Cancelled |
| `6` | Pending Cancel |
| `7` | Pending Replace |

### Expect Table Format Example

```gherkin
* <PART_SESSION> expect:
    | MyRef                | Template                | SecurityID     | Side | OrderType | OrderQty | OrderPrice | OriginatingSessionID | AHTIndicator |
    | <CaseID>-<Role>-FE-01 | ExchangeOnBehalfTrade | instrument_id1 | 1    | 2         | 100      | 10000      | ID2.COMPID           | 1            |
```

---

## 4. Variable Naming Convention

| Operation | MyRef Pattern |
|---|---|
| TradeCancelled | `<CaseID>-<Role>-TC-<Seq>` |
| TradePartiallyCancelled | `<CaseID>-<Role>-TPC-<Seq>` |
| ExchangeOnBehalfTrade | `<CaseID>-<Role>-FE-<Seq>` |
| ExchangeOnBehalfTrade (AHT) | `<CaseID>-<Role>-AHT-<Seq>` |

---

## 5. Common Flow Patterns

### Error Trade Cancel Flow

```
1. OrderExecuted (31) - Trade occurs
2. ErrorTradeClaimRequest (151) - Counterparty submits claim
3. ErrorTradeClaimAck (152) - System acknowledges
4. ErrorTradeClaimNotification (153) - Claimant notified
5. <consent/approval steps>
6. TradeCancelled (157) - Trade fully cancelled
7. TradeAdjusted (165) - If adjusted instead of cancelled
```

### AHT Force Execution Flow

```
1. ExchangeOnBehalfTrade (160) - Exchange forces a trade
2. OrderExecuted (31) - Corresponding execution for the other side
```

---

## 6. FS Mandatory Fields

### TradeCancelled (157) - Mandatory Field Reference

| # | Template Field | Feature Header | Mandatory |
|---|---|---|---|
| 1 | SecurityID | SecurityID | **Yes (M)** |
| 2 | Side | Side | **Yes (M)** |
| 3 | OrderQty | OrderQty | **Yes (M)** |
| 4 | OrderPrice | OrderPrice | **Yes (M)** |
| 5 | ExecutionID | ExecutionID | **Yes (M)** |
| 6 | LeavesQty | LeavesQty | **Yes (M)** |
| 7 | CumulativeQty | CumulativeQty | **Yes (M)** |
| 8 | TradeCancelReason | TradeCancelReason | **Yes (M)** |

### ExchangeOnBehalfTrade (160) - Mandatory Field Reference

| # | Template Field | Feature Header | Mandatory |
|---|---|---|---|
| 1 | SecurityID | SecurityID | **Yes (M)** |
| 2 | Side | Side | **Yes (M)** |
| 3 | OrderType | OrderType | **Yes (M)** |
| 4 | OrderQty | OrderQty | **Yes (M)** |
| 5 | OrderPrice | OrderPrice | **Yes (M)** |
| 6 | ExecutionID | ExecutionID | **Yes (M)** |
| 7 | LeavesQty | LeavesQty | **Yes (M)** |
| 8 | CumulativeQty | CumulativeQty | **Yes (M)** |
| 9 | OriginatingSessionID | OriginatingSessionID | **Yes (M)** |

---

## Revision History

| Date | Version | Author | Description |
|---|---|---|---|
| 2026-08-02 | 1.0 | AI Assistant | Created rule file for TradeCancelled (157), TradePartiallyCancelled (158), ExchangeOnBehalfTrade (160) |
