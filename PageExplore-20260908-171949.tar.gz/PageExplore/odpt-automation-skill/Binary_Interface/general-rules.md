# Binary Interface General Rules

This file contains the general rules from the original `Binary_Interface_Transform_Rules.md` that apply across all message types. These cover feature file structure, session mapping, variable naming, special values, date/time handling, Admin GUI setup, data file configuration, common pitfalls, and templates.

---

## Table of Contents

1. [Feature File Structure](#1-feature-file-structure)
2. [Header / Metadata Mapping](#2-header--metadata-mapping)
3. [Precondition Setup](#3-precondition-setup)
4. [Session / Participant Mapping](#4-session--participant-mapping)
5. [Variable Naming Convention](#5-variable-naming-convention)
6. [Special Values and Assertions](#6-special-values-and-assertions)
7. [Date/Time Handling](#7-datetime-handling)
8. [Admin GUI Setup Steps](#8-admin-gui-setup-steps)
9. [Data File Configuration](#9-data-file-configuration)
10. [Common Pitfalls and Best Practices](#10-common-pitfalls-and-best-practices)
11. [Feature File Complete Template](#11-feature-file-complete-template)
12. [Step-by-Step Transformation Pattern](#12-step-by-step-transformation-pattern)
13. [Binary Message Template Mapping Reference](#13-binary-message-template-mapping-reference)
14. [FS Mandatory Fields Overview](#14-fs-mandatory-fields-overview)

---

## 1. Feature File Structure

### Standard Header Template

```gherkin
@FEATURE=Binary
Feature: ODP Admin GUI
    Create Date: <YYYY/MM/DD>
    Last Update: <YYYY/MM/DD>
    Author Name: AI Assistant
    Background:
        * Load value from admin_gui_value
        * Load value from trading_gui_value
        * Load value from <dataSet-ODPXX-value>
        * Load object description from odp-web-object
        * Load parameters from csv <dataSet-ODPXX>

    @KEY=ODP-T<JIRA_Key>
    @CASE=<TestCase_ID>
    Scenario: <Test Case Name>
        ============================================================================
        Objective: <Objective text from Excel>
        ============================================================================

        * Set ISODP true
        * Wait 1 seconds
        ...
```

### Background Loading Rules

| Test Domain | Value DataSet | Parameter DataSet |
|---|---|---|
| Order Management (ODP3.x) | `dataSet-ODP3-value` | `dataSet-ODP3` |
| Error Trade / Cancel Adj Trade (ODP17.x) | `dataSet-ODP17-value` | `dataSet-ODP17` |
| Other Binary tests | Select based on test component | Select based on test component |

### Tags Convention

- `@FEATURE=Binary` - Always present for Binary interface tests
- `@KEY=ODP-T<number>` - JIRA ticket key from Excel
- `@CASE=<case_id>` - Test case ID (e.g., `ODP17.11.2`)
- Additional tags if needed: `@<Label1> @<Label2>` (split by comma from Excel Labels column)

---

## 2. Header / Metadata Mapping

| Excel Field | Feature File Location | Rule |
|---|---|---|
| Key (e.g. `ODP-T16238`) | Tag `@KEY=ODP-T16238` | Added before Scenario |
| Name (e.g. `ODP17.6.1.1_...`) | Scenario line | Used for scenario name |
| Objective | Comment block after Scenario line | Wrapped in `===` lines |
| Precondition | Steps in Scenario body | Transformed into setup steps |
| Folder | Path reference | Use for output directory |
| Priority | Not directly used | - |
| Component | Not directly used | - |
| Labels | Tag `@Label` | e.g. `@Error.Trade @Batch-3` |
| Owner / Checker | Not directly used | - |

---

## 3. Precondition Setup

### Participant Login

From Excel precondition column, identify participant users and map to login step:

```gherkin
* Login "<PART_SESSION>", retrying up to "10" times, type: "OrderDrop"
```

### Admin GUI Preset Steps

If precondition mentions Admin GUI settings (e.g., "Maintain Instrument Type Error Trade Parameters"), create Admin GUI preset steps:

```gherkin
* Go to "<menu_path>" page
* Click "<button>"
* Fill "<field>" with "<value>"
...
```

---

## 4. Session / Participant Mapping (Binary Interface)

Binary session mapping follows the convention: `PART{participant no}_OF_ID_{ID no}`.

### 4.1 User Name Parsing Rule

The user name in test cases follows the format: `{participant}{sign}`.

- **participant**: The firm/counterparty identifier (letters prefix)
- **sign**: The user/session identifier (numerical suffix)

**Example**: `MSMAA111` → participant = `MSMAA`, sign = `111`

### 4.2 Determining Participant Number

| Rule | Example | Transform Result |
|---|---|---|
| Same participant prefix + different sign | `MSMAA111`, `MSMAA112` | Same participant → `PART1_OF_ID_1` (first), `PART1_OF_ID_2` (second) |
| Different participant prefix | `MSMAA111`, `CCLBB222` | Different participants → `PART1_OF_ID_1` (first), `PART2_OF_ID_1` (second) |
| Same participant + multiple sessions | `MSMAA111`, `MSMAA333`, `MSMAA444` | All same participant → `PART1_OF_ID_1`, `PART1_OF_ID_2`, `PART1_OF_ID_3` |

### 4.3 Standard Session Naming Reference

Each feature session name maps to a fixed FIX connection (CompID) configured in `features/sessions.csv`:

| Feature Session | CompID (from sessions.csv) | User ID Example (from users.csv) | Purpose |
|---|---|---|---|
| `PART1_OF_ID_1` | BNP3001 | MSMAA111 | First participant's primary session (Claimant, Party A) |
| `PART1_OF_ID_2` | BNP3002 | MSMAA333 | First participant's secondary session (Nominated CompID) |
| `PART1_OF_ID_3` | BNP3513 | MSMAA444 | First participant's third session (non-eligible CompID) |
| `PART2_OF_ID_1` | BCA0107 | CCLBB222 | Second participant's primary session (Counterparty, Party B) |
| `PART3_OF_ID_1` | CTDMM0637 | DRWKK555 | Third participant's primary session |
| `CLEARING_ACCOUNT1` | ODP-PT1 | — | Clearing session (separate FIX connection) |

---

## 5. Variable Naming Convention

### ID Format

```
<TestCaseID>-<RoleAbbreviation>-<OperationSequence>-<OptionalQualifier>
```

### Complete Examples

| Usage | Example MyRef |
|---|---|
| Order NewOrder send | `ODP17.11.2-ID1-SO-01` |
| OrderAccepted expect ref | `ODP17.11.2-ID1-SO-01-R` |
| OrderExecuted expect ref | `ODP17.11.2-ID1-SO-01-M-R` |
| ErrorClaimRequest send | `ODP17.11.2-ID1-EC-01` |
| ErrorClaimAck expect ref | `ODP17.11.2-ID1-EC-01-R` |

### Reference Patterns for Expect Tables

| Expression | Meaning |
|---|---|
| `ODP17.11.2-ID1-SO-01.ClientOrderID` | Reference the ClientOrderID from the send table |
| `ODP17.11.2-ID1-SO-01-R.OrderID` | Reference the OrderID from the response |
| `ODP17.11.2-ID1-SO-01-R.TradeID` | Reference the TradeID from the executed trade |

### Operation Abbreviations

| Abbreviation | Operation |
|---|---|
| `SO` | Single Order (NewOrder) |
| `EC` | Error Claim |
| `1P` | One-party Block Trade |
| `CX` | Cancel |
| `SQ` | Single Quote |
| `MQ` | Mass Quote |

---

## 6. Special Values and Assertions

| Keyword | Description | Example |
|---|---|---|
| `<notexist>` | Assert field is NOT present in response | `ErrorTradeClaimRejectReason: <notexist>` |
| `<assign>` | Capture field value for later use | `ErrorTradeClaimID: <assign>` |
| `@anyValue` | Accept any non-empty value | `ClientOrderID: @anyValue` |

### Common Mappings

| Field | Value | Description |
|---|---|---|
| Side | `1` | Buy side |
| Side | `2` | Sell side |
| OrderType | `2` | Limit order |
| TimeInForce | `0` | Day order |
| OrderStatus | `2` | Filled |
| TradeType | `0` | Regular trade |
| TradeSubType | `1` | Standard order book trade |
| MatchType | `4` | Order book match |
| TradeConfirmationIndicator | `P` | Provisional trade confirmation |
| TradeConfirmationIndicator | `C` | Confirmed trade |

---

## 7. Date/Time Handling

### Save Trade Conclusion Date Time

```gherkin
* Save Trade Conclusion Date Time to "<variable_name>"
```

### Save Date

```gherkin
* Save the next "0" "day" date to "today" with format "%Y%m%d"
```

### Wait / Delay

```gherkin
* Wait <seconds> seconds
```

---

## 8. Admin GUI Setup Steps

For test preconditions that require Admin GUI configuration, include steps before Binary `Set ISODP true`.

```gherkin
* Open browser
* Login ODP Admin GUI with:
    | User ID            | User Password               |
    | admin_gui_user1    | admin_gui_user1_password    |
* Wait 1 seconds
* Clear Alert If Exist
```

---

## 9. Data File Configuration

Each test case category has a corresponding dataset CSV file that maps `case_id` to instrument variables.

### Combo Instrument Dataset Mapping

| Column | Maps To | Example Value | Description |
|---|---|---|---|
| `instrument_id1` | Combo instrument itself | `{HSI1/2}` | The calendar spread combo |
| `instrument_id2` | Leg 1 (front month) | `{HSI_f_dis1}` | The front month leg |
| `instrument_id3` | Leg 2 (back month) | `{HSI_f_dis2}` | The back month leg |

---

## 10. Common Pitfalls and Best Practices

### Best Practices

1. Always use `* Set ISODP true` at the start.
2. Use `* Wait 1 seconds` after `Set ISODP true`.
3. Use `## Step N` comments to separate logical steps.
4. Pre-save Trade Conclusion Date Time before block trade and error trade claim flows.
5. Pre-save `today` before expecting `OrderExecuted`.
6. Define FIX Group entries before the send/expect block that references them.
7. Add new test case rows to the appropriate dataset CSV.

### Common Pitfalls

1. Missing `ResponseRef` column in expect tables.
2. Incorrect Side values (1=Buy, 2=Sell).
3. Wrong template name casing.
4. Missing `TradeConclusionDateTime` for block trade requests.
5. Mismatched participant session mapping.

---

## 11. Feature File Complete Template

```gherkin
@FEATURE=Binary
Feature: ODP Admin GUI
    Create Date: <YYYY/MM/DD>
    Last Update: <YYYY/MM/DD>
    Author Name: AI Assistant
    Background:
        * Load value from admin_gui_value
        * Load value from trading_gui_value
        * Load value from dataSet-ODP<XX>-value
        * Load object description from odp-web-object
        * Load parameters from csv dataSet-ODP<XX>

    @KEY=ODP-T<JIRA_Key>
    @CASE=<TestCase_ID>
    Scenario: <Test Case Name>
        ============================================================================
        Objective: <Objective text>
        ============================================================================

        * Set ISODP true
        * Wait 1 seconds
```

---

## 12. Step-by-Step Transformation Pattern

Each Binary interface step has a **send** action and a corresponding **expect** response action.

| Excel Step Description | Feature Step Pattern |
|---|---|
| "User <X> place <buy/sell> order via msg New Order Single Request (21)" | `* PART<X>_OF_ID_<Y> send:` with `Template=NewOrder` |
| "User <X> shall received Order Accepted (27)" | `* PART<X>_OF_ID_<Y> expect:` with `Template=OrderAccepted` |
| "User <X> and <Y> received msg Order Executed (31)" | `* PART<X>_OF_ID_<Y> expect:` and `* PART<Y>_OF_ID_<Z> expect:` with `Template=OrderExecuted` |
| "User <X> report error trade via msg Error Trade Claim Request(151)" | `* PART<X>_OF_ID_<Y> send:` with `Template=ErrorTradeClaimRequest` |
| "User <X> cancel order via msg Order Cancel Request (23)" | `* PART<X>_OF_ID_<Y> send:` with `Template=OrderCancelRequest` |

---

## 13. Binary Message Template Mapping Reference

| MsgType | Template Name | Category | Send/Expect | Notes |
|---|---|---|---|---|
| 21 | `NewOrder` | Orders | Both | Standard new order request |
| 22 | `OrderAmendRequest` | Orders | Send | Amend existing order |
| 23 | `OrderCancelRequest` | Orders | Send | Cancel order |
| 24 | `OrderRejected` | Orders | Expect | Order rejected response |
| 25 | `OrderAmendRejected` | Orders | Expect | Amend rejected response |
| 26 | `OrderCancelRejected` | Orders | Expect | Cancel rejected response |
| 27 | `OrderAccepted` | Orders | Expect | Order accepted response |
| 28 | `OrderAmended` | Orders | Expect | Order amended response |
| 30 | `OrderRestated` | Orders | Expect | Order restated |
| 31 | `OrderExecuted` | Orders | Expect | Order filled/executed |
| 32 | `OrderDoneforDay` | Orders | Expect | Order done for day |
| 51 | `MassQuote` | Quotes | Both | Mass quote |
| 52 | `MassQuoteAck` | Quotes | Expect | Mass quote ack |
| 53 | `SingleQuote` | Quotes | Both | Single quote |
| 101-114 | Block Trade templates | Block Trade | Both | One/two-party block trade |
| 151-156 | Error Trade Claim templates | Error Trade | Both | Error trade claim flow |
| 157 | `TradeCancelled` | Trade | Expect | Trade cancelled |
| 160 | `ExchangeOnBehalfTrade` | Trade | Expect | Exchange on-behalf trade |
| 165 | `TradeAdjusted` | Trade | Expect | Trade adjusted |
| 181-186 | `Mmp*` | MMP | Both | Market Maker Protection |

---

## 14. FS Mandatory Fields Overview

If a field is **mandatory** according to the FS binary specification, it **MUST** be included in the feature file's send/expect table, even if not explicitly mentioned in the source test case.

| Field | Messages | Default Value (if not specified) |
|---|---|---|
| **BCANField** | NewOrder (21), OnePartyBlockTradeRequest (105) | `ABC123.123` |
| OrderType | NewOrder (21) | `2` (Limit) |
| TimeInForce | NewOrder (21) | `0` (Day) |

## C. Binary Execute → Trading GUI Verification Mapping

| Binary OrderExecuted Field | Trading GUI Table Column | Mapping |
|---|---|---|
| `SecurityID` | `ID` / `Instrument` | Direct mapping |
| `Side=1` | `BOUGHT` / `QUANTITIES:BOUGHT` | Buy side trades appear in BOUGHT column |
| `Side=2` | `SOLD` / `QUANTITIES:SOLD` | Sell side trades appear in SOLD column |
| `ExecutionQty` | `BOUGHT` or `SOLD` qty | Quantity appears on the appropriate side |
| `ExecutionPrice` | `TRADED:PRICE` / `PRICE` | Execution price displayed in price column |

## D. Admin GUI Setup for Binary Participants

When a test case requires Admin GUI configuration before Binary behavior,
generate and validate that setup as a standalone `<case>.admin.feature` first.
Keep the Binary/Batch/Trading GUI/Clearing continuation in a separate
`<case>.feature`; do not insert Admin steps before its `Set ISODP true` step.
When a batch TestStep advances to the next trading day, split that continuation
into `<case>-Day1.feature` and `<case>-Day2.feature`, persist FIX state under
`<case>-Day1`, and declare `admin -> day1 -> night_batch -> day2` in
`<case>.execution-flow.json`. Night batch is an external gate and must not be
represented by a Gherkin `Wait`. Use Admin GUI rules (`Admin_GUI/index.md`) for
the standalone artifact.

## Revision History

| Date | Version | Author | Description |
|---|---|---|---|
| 2026-08-02 | 1.0 | AI Assistant | Extracted general rules from Binary_Interface_Transform_Rules.md as part of rule file split |
| 2026-08-08 | 1.1 | AI Assistant | Added Section C (Binary Execute → Trading GUI Verification Mapping) |
| 2026-08-08 | 1.2 | AI Assistant | Completed Section D (Admin GUI Setup for Binary Participants). Clarified BCANField defaults in context |
| 2026-09-08 | 1.3 | AI Assistant | Split Hybrid Admin validation from the non-Admin continuation |
| 2026-09-08 | 1.4 | AI Assistant | Added cross-day Day1/Day2 Features and an external-gate execution flow |
