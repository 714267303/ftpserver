# Binary Interface: OrderRejected (MsgType 24) Rules

## Overview

This file defines the transformation rules for **OrderRejected (24)** message type - the response sent when a NewOrder is rejected by the system.

---

## 1. OrderRejected (24) - Expect Fields

### Field Mapping

| # | Template Field | Feature Table Header | Type | Mapping Rule |
|---|---|---|---|---|
| 1 | ClientOrderID | MyRef | UINT64 | Same as NewOrder MyRef |
| 2 | TransactionTime | (auto) | UINT64 | Not included; auto-generated |
| 3 | SecurityID | SecurityID | TEXT | Same as NewOrder |
| 4 | Side | Side | UINT8 | Same as NewOrder |
| 5 | OrderQty | OrderQty | INT32 | Same as NewOrder |
| 6 | OrderPrice | OrderPrice | INT64 | Same as NewOrder |
| 7 | OrderRejectReason | OrderRejectReason | UINT16 | Rejection reason code |
| 8 | QuoteEntryID | QuoteEntryID | UINT16 | Optional; present when order from quote |

### Reject Reason Codes (FIX 10337 Reference)

| OrdRejReason Code | Description |
|---|---|
| `0` | Broker / Exchange Option |
| `1` | Unknown Symbol |
| `2` | Exchange Closed |
| `3` | Order Exceeds Limit |
| `4` | Too Late to Enter |
| `5` | Unknown Order |
| `6` | Duplicate Order (e.g., ClOrdID) |
| `7` | Duplicate of a Verbally Communicated Order |
| `8` | Stale Order |
| `9` | Trade Along Required |
| `10` | Invalid Investor ID |
| `11` | Unsupported Order Characteristic |
| `12` | Surveillence Option |
| `13` | Incorrect Quantity |
| `14` | Incorrect Allocated Quantity |
| `15` | Unknown Account(s) |
| `16` | Price Exceeds Current Price |
| `17` | Invalid Price Increment |
| `18` | Reference Price Not Available |
| `19` | Notional Value Exceeds Threshold |
| `20` | Risk Limit Breached |
| `99` | Other |
| `101` | Duplicate ClOrdID |
| `102` | Unexpected Order |
| `103` | Price exceeds current price band |
| `2020` | Account Frozen |
| `2021` | Instrument Not Allowed |

---

## 2. Expect Table Format

### Standard OrderRejected (24)

```gherkin
* <PART_SESSION> expect:
    | MyRef                | Template      | SecurityID     | Side | OrderQty | OrderPrice  | OrderRejectReason |
    | <CaseID>-<Role>-SO-01 | OrderRejected | instrument_id1 | 1    | 100      | 20000       | 1                 |
```

### OrderRejected with QuoteEntryID (from quote flow)

```gherkin
* <PART_SESSION> expect:
    | MyRef                | Template      | SecurityID     | Side | OrderQty | OrderPrice  | OrderRejectReason | QuoteEntryID |
    | <CaseID>-<Role>-SO-01 | OrderRejected | instrument_id1 | 1    | 100      | 20000       | 2020              | 1            |
```

---

## 3. Common OrderRejectReason Patterns

| Context | Typical Reason Code |
|---|---|
| Bad/unknown SecurityID | `1` |
| Duplicate ClOrdID | `6` or `101` |
| Account frozen | `2020` |
| Instrument not allowed | `2021` |
| Market in closed state | `2` |
| Order quantity exceeds limit | `3` |
| Price exceeds limit | `16` or `103` |

---

## 4. Variable Naming Convention

| Operation | MyRef Pattern |
|---|---|
| Standard rejection | `<CaseID>-<Role>-SO-<Seq>` (same as NewOrder MyRef since it's response) |
| OrderRejected from quote | `<CaseID>-<Role>-MQ-<Seq>` |

---

## 5. FS Mandatory Fields (Rule 13.7)

### 13.7 OrderRejected (24) - Mandatory Field Reference

| # | Template Field | Feature Header | Mandatory | Default |
|---|---|---|---|---|
| 1 | ClientOrderID | MyRef | **Yes (M)** | Same as NewOrder MyRef |
| 2 | TransactionTime | (auto) | **Yes (M)** | Auto by system; NOT in table |
| 3 | SecurityID | SecurityID | **Yes (M)** | Same as NewOrder |
| 4 | Side | Side | **Yes (M)** | Same as NewOrder |
| 5 | OrderQty | OrderQty | **Yes (M)** | Same as NewOrder |
| 6 | OrderPrice | OrderPrice | **Yes (M)** | Same as NewOrder |
| 7 | OrderRejectReason | OrderRejectReason | **Yes (M)** | Rejection reason code |
| 8 | QuoteEntryID | QuoteEntryID | No (N) | Present for quote-originated orders |

---

## 6. Pairing Rules

OrderRejected is **always** paired with a preceding NewOrder (21). The rejection occurs **instead** of an OrderAccepted (27). Therefore, in a test case:

- If an order is expected to be rejected, use `OrderRejected` instead of `OrderAccepted`
- The MyRef should match the NewOrder's MyRef since it's the response to the same order
- The original NewOrder's fields (SecurityID, Side, OrderQty, OrderPrice) are echoed back in OrderRejected

---

## Revision History

| Date | Version | Author | Description |
|---|---|---|---|
| 2026-08-02 | 1.0 | AI Assistant | Created rule file for OrderRejected (24) |
