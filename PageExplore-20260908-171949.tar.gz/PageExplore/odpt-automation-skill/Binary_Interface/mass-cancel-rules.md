# Binary Interface: Mass Cancel & OBO Cancel Rules (MsgType 81-86)

## Overview

This file defines the transformation rules for mass order cancel and on-behalf-of (OBO) cancel messages:
- **MassOrderCancel (81)** - Cancel all orders by scope
- **MassOrderCancelReport (82)** - Response to MassOrderCancel
- **OBOSingleOrderCancel (83)** - Cancel a specific order on behalf of another session
- **OBOSingleOrderCancelAck (84)** - Acknowledgement of OBO single cancel
- **OBOMassOrderCancel (85)** - Cancel all orders on behalf of another session
- **OBOMassOrderCancelReport (86)** - Response to OBO mass cancel

---

## 1. MassOrderCancel (81) - Send Fields

### Field Mapping

| # | Template Field | Feature Table Header | Type | Mapping Rule |
|---|---|---|---|---|
| 1 | ClientOrderID | ClientOrderID | UINT64 | Unique reference: `<CaseID>-<Role>-MC-<Seq>` |
| 2 | TransactionTime | (auto) | UINT64 | Not included; auto-generated |
| 3 | MassOrderCancelScope | MassOrderCancelScope | UINT8 | Scope of cancel operation |
| 4 | MassOrderCancelRequestType | MassOrderCancelRequestType | UINT8 | Cancel request type |
| 5 | OriginatingSessionID | OriginatingSessionID | TEXT | Optional; for OBO operations |

### MassOrderCancelScope Codes

| Code | Description |
|---|---|
| `1` | Cancel all orders |
| `2` | Cancel all orders for a specific instrument |
| `3` | Cancel all orders for a specific side |
| `4` | Cancel all orders for a specific participant |
| `5` | Cancel all orders for a specific quote entry |
| `7` | Cancel all orders for all quotes (quote cancel) |

### MassOrderCancelRequestType Codes

| Code | Description |
|---|---|
| `7` | All orders |
| (Others TBD based on specific system configuration) |

### Send Table Format Example

```gherkin
* <PART_SESSION> send:
    | MyRef           | Template        | MassOrderCancelScope | MassOrderCancelRequestType |
    | <CaseID>-MC-01   | MassOrderCancel | 2                    | 7                          |
```

---

## 2. MassOrderCancelReport (82) - Expect Fields

### Field Mapping

| # | Template Field | Feature Table Header | Type | Mapping Rule |
|---|---|---|---|---|
| 1 | ClientOrderID | MyRef | UINT64 | Same as MassOrderCancel ClientOrderID |
| 2 | TransactionTime | (auto) | UINT64 | Not included; auto-generated |
| 3 | MassOrderCancelScope | MassOrderCancelScope | UINT8 | Echo of request scope |
| 4 | MassOrderCancelResponse | MassOrderCancelResponse | UINT8 | Response status |
| 5 | TotalNumberOfMEsInvolved | TotalNumberOfMEsInvolved | UINT32 | Number of MEs affected |
| 6 | MEID | MEID | UINT32 | Market Entity ID |

### MassOrderCancelResponse Codes

| Code | Description |
|---|---|
| `0` | Accepted |
| `1` | Rejected |
| `2` | Partially Accepted |
| `7` | All orders cancelled |
| `8` | Instrument not found |

### Expect Table Format Example

```gherkin
* <PART_SESSION> expect:
    | MyRef           | Template              | ClientOrderID           | MassOrderCancelScope | MassOrderCancelResponse | TotalNumberOfMEsInvolved | MEID |
    | <CaseID>-MC-01   | MassOrderCancelReport | <CaseID>-MC-01.ClientOrderID | 2                    | 7                       | 1                        | 1    |
```

### Full Cancel Flow Example (MassOrderCancel + OrderCancelled responses)

```gherkin
# Step: Mass Cancel Request
* <PART_SESSION> send:
    | MyRef           | Template        | MassOrderCancelScope | MassOrderCancelRequestType |
    | <CaseID>-MC-01   | MassOrderCancel | 1                    | 7                          |

# Step: Each order is cancelled individually
* <PART_SESSION> expect:
    | MyRef           | Template       | ClientOrderID           | SecurityID     | Side | OrderID                       | CumulativeQty | OrderCancelReason | OriginatingSessionID | OriginalClientOrderID           | QuoteEntryID |
    | <CaseID>-MC-01   | OrderCancelled | <CaseID>-MC-01.ClientOrderID | instrument_id1 | 1    | <Ref>.OrderID                 | 0             | 2501              | <PART_SESSION>.COMPID | <CaseID>-SO-01.ClientOrderID    | <notexist>   |
    | <CaseID>-MC-01   | OrderCancelled | <CaseID>-MC-01.ClientOrderID | instrument_id2 | 2    | <Ref>.OrderID                 | 0             | 2501              | <PART_SESSION>.COMPID | <CaseID>-SO-02.ClientOrderID    | <notexist>   |

# Step: Mass cancel report
* <PART_SESSION> expect:
    | MyRef           | Template              | ClientOrderID           | MassOrderCancelScope | MassOrderCancelResponse | TotalNumberOfMEsInvolved | MEID |
    | <CaseID>-MC-01   | MassOrderCancelReport | <CaseID>-MC-01.ClientOrderID | 1                    | 7                       | 1                        | 1    |
```

---

## 3. OBOSingleOrderCancel (83) - Send Fields

### Field Mapping

| # | Template Field | Feature Table Header | Type | Mapping Rule |
|---|---|---|---|---|
| 1 | ClientOrderID | ClientOrderID | UINT64 | Unique reference: `<CaseID>-<Role>-OBO-CX-<Seq>` |
| 2 | TransactionTime | (auto) | UINT64 | Not included; auto-generated |
| 3 | SecurityID | SecurityID | TEXT | Security being cancelled |
| 4 | Side | Side | UINT8 | Side of the order |
| 5 | OriginalClientOrderID | OriginalClientOrderID | UINT64 | Original order's ClientOrderID |
| 6 | OriginatingSessionID | OriginatingSessionID | TEXT | Session ID being acted on behalf of |

### Send Table Format Example

```gherkin
* <PART_SESSION> send:
    | MyRef                    | Template             | SecurityID     | Side | OriginalClientOrderID              | OriginatingSessionID |
    | <CaseID>-ID1-OBO-CX-01   | OBOSingleOrderCancel | instrument_id1 | 1    | <CaseID>-ID1-SO-01.ClientOrderID   | <PART_SESSION>.COMPID |
```

---

## 4. OBOSingleOrderCancelAck (84) - Expect Fields

### Field Mapping

| # | Template Field | Feature Table Header | Type | Mapping Rule |
|---|---|---|---|---|
| 1 | ClientOrderID | MyRef | UINT64 | Same as OBOSingleOrderCancel ClientOrderID |
| 2 | TransactionTime | (auto) | UINT64 | Not included; auto-generated |
| 3 | OriginatingSessionID | OriginatingSessionID | TEXT | Session ID being acted on behalf of |
| 4 | Status | Status | UINT8 | Status of the OBO operation |

### Expect Table Format Example

```gherkin
* <PART_SESSION> expect:
    | MyRef                    | Template                | ClientOrderID                        | OriginatingSessionID       | Status |
    | <CaseID>-ID1-OBO-CX-01   | OBOSingleOrderCancelAck | <CaseID>-ID1-OBO-CX-01.ClientOrderID | <PART_SESSION>.COMPID      | 0      |
```

---

## 5. OBOMassOrderCancel (85) - Send Fields

### Field Mapping

| # | Template Field | Feature Table Header | Type | Mapping Rule |
|---|---|---|---|---|
| 1 | ClientOrderID | ClientOrderID | UINT64 | Unique reference: `<CaseID>-<Role>-OBO-MC-<Seq>` |
| 2 | TransactionTime | (auto) | UINT64 | Not included; auto-generated |
| 3 | MassOrderCancelScope | MassOrderCancelScope | UINT8 | Scope of cancel operation |
| 4 | MassOrderCancelRequestType | MassOrderCancelRequestType | UINT8 | Cancel request type |
| 5 | OriginatingSessionID | OriginatingSessionID | TEXT | Session ID being acted on behalf of |
| 6 | SecurityID | SecurityID | TEXT | Optional; specific instrument |

### Send Table Format Example

```gherkin
* <PART_SESSION> send:
    | MyRef                    | Template           | MassOrderCancelScope | MassOrderCancelRequestType | OriginatingSessionID   | SecurityID     |
    | <CaseID>-ID1-OBO-MC-01   | OBOMassOrderCancel | 2                    | 7                          | ID2.COMPID             | instrument_id1 |
```

---

## 6. OBOMassOrderCancelReport (86) - Expect Fields

### Field Mapping

| # | Template Field | Feature Table Header | Type | Mapping Rule |
|---|---|---|---|---|
| 1 | ClientOrderID | MyRef | UINT64 | Same as OBOMassOrderCancel ClientOrderID |
| 2 | TransactionTime | (auto) | UINT64 | Not included; auto-generated |
| 3 | MassOrderCancelScope | MassOrderCancelScope | UINT8 | Echo of request scope |
| 4 | MassOrderCancelResponse | MassOrderCancelResponse | UINT8 | Response status |
| 5 | TotalNumberOfMEsInvolved | TotalNumberOfMEsInvolved | UINT32 | Number of MEs affected |
| 6 | MEID | MEID | UINT32 | Market Entity ID |
| 7 | SessionCancellationScope | SessionCancellationScope | UINT8 | Scope of session cancellation |
| 8 | SecurityID | SecurityID | TEXT | Optional; specific instrument |

### SessionCancellationScope Codes

| Code | Description |
|---|---|
| `1` | All sessions |
| `2` | Specific session |
| `3` | All sessions with filter |

### Expect Table Format Example

```gherkin
* <PART_SESSION> expect:
    | MyRef                    | Template                 | ClientOrderID                      | MassOrderCancelScope | MassOrderCancelResponse | TotalNumberOfMEsInvolved | MEID | SessionCancellationScope | SecurityID     |
    | <CaseID>-ID1-OBO-MC-01   | OBOMassOrderCancelReport | <CaseID>-ID1-OBO-MC-01.ClientOrderID | 2                    | 1                       | 1                        | 1    | 2                        | instrument_id1 |
```

---

## 7. Variable Naming Convention

| Operation | MyRef Pattern |
|---|---|
| MassOrderCancel | `<CaseID>-<Role>-MC-<Seq>` |
| OBOSingleOrderCancel | `<CaseID>-<Role>-OBO-CX-<Seq>` |
| OBOMassOrderCancel | `<CaseID>-<Role>-OBO-MC-<Seq>` |

---

## 8. Common Flow: Mass Cancel with OrderCancelled Responses

When MassOrderCancel is sent, each affected order produces an OrderCancelled message BEFORE the MassOrderCancelReport. The OrderCancelled responses use `OrderCancelReason=2501` (mass quote cancel) or `OrderCancelReason=2502` (cancel due to amend).

```gherkin
# Expected order of responses:
# 1. OrderCancelled (for each affected order) - OrderCancelReason=2501
# 2. Mass cancel report - confirms the mass cancel
```

---

## 9. OrderCancelReason Codes for Mass Cancel

| Code | Description |
|---|---|
| `2501` | Cancelled due to mass quote cancel (81) |
| `2502` | Cancelled due to quote amend |
| `2503` | Cancelled due to quote cancel |
| `2105` | CanceledByGiveUpFirm |

---

## 10. FS Mandatory Fields

### MassOrderCancel (81) - Mandatory Field Reference

| # | Template Field | Feature Header | Mandatory |
|---|---|---|---|
| 1 | ClientOrderID | ClientOrderID | **Yes (M)** |
| 2 | TransactionTime | (auto) | **Yes (M)** |
| 3 | MassOrderCancelScope | MassOrderCancelScope | **Yes (M)** |
| 4 | MassOrderCancelRequestType | MassOrderCancelRequestType | **Yes (M)** |

### MassOrderCancelReport (82) - Mandatory Field Reference

| # | Template Field | Feature Header | Mandatory |
|---|---|---|---|
| 1 | ClientOrderID | MyRef | **Yes (M)** |
| 2 | TransactionTime | (auto) | **Yes (M)** |
| 3 | MassOrderCancelScope | MassOrderCancelScope | **Yes (M)** |
| 4 | MassOrderCancelResponse | MassOrderCancelResponse | **Yes (M)** |
| 5 | TotalNumberOfMEsInvolved | TotalNumberOfMEsInvolved | **Yes (M)** |
| 6 | MEID | MEID | **Yes (M)** |

### OBOMassOrderCancel (85) - Mandatory Field Reference

| # | Template Field | Feature Header | Mandatory |
|---|---|---|---|
| 1 | ClientOrderID | ClientOrderID | **Yes (M)** |
| 2 | TransactionTime | (auto) | **Yes (M)** |
| 3 | MassOrderCancelScope | MassOrderCancelScope | **Yes (M)** |
| 4 | MassOrderCancelRequestType | MassOrderCancelRequestType | **Yes (M)** |
| 5 | OriginatingSessionID | OriginatingSessionID | **Yes (M)** |

### OBOMassOrderCancelReport (86) - Mandatory Field Reference

| # | Template Field | Feature Header | Mandatory |
|---|---|---|---|
| 1 | ClientOrderID | MyRef | **Yes (M)** |
| 2 | TransactionTime | (auto) | **Yes (M)** |
| 3 | MassOrderCancelScope | MassOrderCancelScope | **Yes (M)** |
| 4 | MassOrderCancelResponse | MassOrderCancelResponse | **Yes (M)** |
| 5 | TotalNumberOfMEsInvolved | TotalNumberOfMEsInvolved | **Yes (M)** |
| 6 | MEID | MEID | **Yes (M)** |
| 7 | SessionCancellationScope | SessionCancellationScope | **Yes (M)** |

---

## Revision History

| Date | Version | Author | Description |
|---|---|---|---|
| 2026-08-02 | 1.0 | AI Assistant | Created rule file for Mass Cancel (81-82) and OBO Cancel (83-86) |
