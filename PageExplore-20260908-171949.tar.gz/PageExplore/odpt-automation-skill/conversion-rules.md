# ODP-T Conversion Rules - Common Rules

This document defines the **common/shared transformation rules** for converting YAML test cases into Cucumber feature files in the ODP-T project. Domain-specific rules are located in `Binary_Interface/`, `Admin_GUI/`, `Trading_GUI/`, and `Clearing_Interface_Transform_Rules.md`.

## Table of Contents

1. Feature File Structure Rules
2. Session / Participant Mapping Rules
3. Variable Naming Convention
4. File Organization Rules
5. Formatting Rules
6. Dataset CSV Configuration Rules
7. End-to-End Step Verification Process
8. ISODP Mode Switching
9. Presetting / Day1 / Day2 Multi-File Workflow
10. TradeType and TradeSubType Values
11. BCANField and Mandatory Defaults

## 1. Feature File Structure Rules

### 1.1 Standard Header

```gherkin
@FEATURE=Binary
Feature: ODP Admin GUI
    Create Date: <YYYY/MM/DD>
    Last Update: <YYYY/MM/DD>
    Author Name: AI Assistant
    Background:
        * Load value from admin_gui_value
        * Load value from trading_gui_value
        * Load value from <dataSet-ODPXX-value>
        * Load object description from odp-web-object
        * Load parameters from csv <dataSet-ODPXX>
```

### 1.2 Tags Convention

- `@FEATURE=<Type>` - Selected per feature tag decision table
- `@KEY=ODP-T<number>` - JIRA ticket key from YAML `Key`
- `@CASE=<TestCase_ID>` - Test case ID extracted from YAML `Name`
- Additional tags: split YAML `Labels` field by comma and prefix each with `@`

### 1.3 YAML Metadata Mapping

| YAML Field | Feature File Location | Rule |
|---|---|---|
| `Key` | `@KEY=` tag | Added before Scenario |
| `Name` | `@CASE=` and Scenario | Extract case ID prefix |
| `Objective` | Comment block after Scenario | Wrapped in `===` lines |
| `Precondition` | Scenario steps | Transformed into setup steps |
| `Folder` | Output directory | Determines domain directory |
| `Labels` | Tags | Split by comma |

### 1.5 @FEATURE Tag Decision Table

| Test Case Characteristics | @FEATURE Tag |
|---|---|
| Binary/FIX messages present | `@FEATURE=Binary` |
| Admin GUI only | `@FEATURE=AdminGUI` |
| WebSocket operations only | `@FEATURE=WS` |
| Clearing verification only | `@FEATURE=Binary` |

## 2. Session / Participant & User Mapping Rules

Binary session mapping follows `PART{participant no}_OF_ID_{ID no}`.

| Rule | Example | Transform Result |
|---|---|---|
| Same participant prefix + different sign | `MSMAA111`, `MSMAA112` | `PART1_OF_ID_1`, `PART1_OF_ID_2` |
| Different participant prefix | `MSMAA111`, `CCLBB222` | `PART1_OF_ID_1`, `PART2_OF_ID_1` |
| Same participant + multiple sessions | `MSMAA111`, `MSMAA333`, `MSMAA444` | `PART1_OF_ID_1`, `PART1_OF_ID_2`, `PART1_OF_ID_3` |

### 2.1 GUI User and Browser Session Naming

Use stable, role-oriented aliases for GUI users and their browser sessions:

| User role | User alias | Browser alias |
|---|---|---|
| Admin requester/maker | `admin_gui_user1` | `browser_admin_gui_user1` |
| Admin approver/checker | `admin_gui_user2` | `browser_admin_gui_user2` |
| External Trading GUI | `trading_gui_user{N}` | `browser_trading_gui_user{N}` |
| Internal Trading GUI | `trd_gui_inter_user{N}` | `browser_trd_gui_inter_user{N}` |

Each `Login Trading Admin with:` table is session-scoped and must contain one
distinct user. A maker and checker therefore require separate
`Open browser` -> one-user `Login` -> `Save current browser` sequences. Multiple
rows for the same user are allowed only when they explicitly model an expected
login error followed by a retry. Never save one browser instance under two
different user aliases.

When a case uses a Binary session alias such as `ID3`, resolve it from the
participant prefix and the session mapping; do not assume that the number alone
means `PART1_OF_ID_3` rather than `PART2_OF_ID_1`.

## 3. Variable Naming Convention

Format:

```
<TestCaseID>-<RoleAbbreviation>-<OperationSequence>-<OptionalQualifier>
```

Examples: `ODP17.3.3.3-ID1-SO-01`, `ODP17.3.3.3-ID1-SO-01-R`, `ODP17.3.3.3-ID1-EC-01`.

## 4. File Organization Rules

Output path:

```
features/test_case/<Domain>/<TestCaseID>.feature
```

## 5. Formatting Rules

- Use tabs for indentation in feature files
- Use `## Step N` comments to number major steps
- Preserve table readability

## 6. Dataset CSV Configuration Rules

Instrument mappings:

- Future: `HSIN6`, `HSIQ6`, `HSIU6` → `{HSI_f_dis1}`, `{HSI_f_dis2}`, `{HSI_f_dis3}`
- Option: `HKB70.00A6`, `HKB70.00M6` → `{HKB[70.00]_c_dis1}`, `{HKB[70.00]_p_dis1}`
- Combo: `HSIN6/Q6`, `HSIQ6/U6` → `{HSI1/2}`, `{HSI1/3}`

## 7. End-to-End Step Verification Process

Before declaring a feature file complete:

1. Read the source YAML file completely.
2. Count all entries in `TestSteps`.
3. Ensure every YAML step maps to one or more `## Step N` feature sections.
4. Verify step description, test data, and expected result coverage.
5. Check dataset mappings, FS mappings, GUI verification, Clearing verification, and Day1/Day2 split where relevant.

### 7.1 Executable Step Source Priority

When choosing Gherkin wording, use executable project steps in this order:

1. Current project `features/customized_steps/**/*.rb`.
2. `Step_Index.json` generated from the same runtime/customized steps.
3. Existing verified Feature examples and verified Admin flow manifests.
4. Skill rule files, ODP documents, and PageExplore profiles as guidance.
5. Emit `@REVIEW` when no executable step can be proven.

Do not invent Playwright locators, browser JavaScript, dynamic UUIDs,
`qaGridApi` mutation calls, or unimplemented Gherkin steps as a replacement for
a missing custom step.

## 8. ISODP Mode Switching

| ISODP State | Interface Used | When to Set |
|---|---|---|
| `true` | Binary Trading | Before sending orders and expecting trades |
| `false` | Clearing | Before clearing FIX groups and TradeCaptureReport verification |

## 9. Presetting / Day1 / Day2 Multi-File Workflow

Use `.Presetting`, `-Day1`, `-Day2`, `.feature`, and `-clear` suffixes to split workflows with next-day effective configuration. For Binary and Hybrid state hand-off, use `Save FIX dumpfile` and `Load FIX dumpfile`; do not emit the legacy GUI `Save/Load bigmap file` steps.

For a Hybrid source containing one `Execution Channel: batch` TestStep whose
text advances to the next business/trading day, generate these artifacts:

```text
<case>.admin.feature
<case>-Day1.feature
<case>-Day2.feature
<case>.execution-flow.json
```

The JSON order is `admin -> day1 -> night_batch -> day2`. The `night_batch`
entry is an external gate and is not a Feature. Never replace it with `Wait`,
`@REVIEW`, shell code, or an invented Cucumber step. End Day1 with
`Save FIX dumpfile <case>-Day1` and load the same dump in the Day2 Background.
The execution runner must stop at the gate and may resume Day2 only after an
explicit acknowledgement recorded against an already-waiting flow.

## 10. TradeType and TradeSubType Values

| TradeType | Description |
|---|---|
| `0` | Regular Trade |
| `1` | Block Trade |
| `2` | Aggregate Trade |
| `5` | Error Trade Adjustment |

| TradeSubType | Description |
|---|---|
| `1` | Standard Trade |
| `1011` | Standard Order Book Trade |

## 11. BCANField and Mandatory Defaults

| Field | Messages | Default Value |
|---|---|---|
| `BCANField` | NewOrder (21), OnePartyBlockTradeRequest (105) | `ABC123.123` |
| `OrderType` | NewOrder (21) | `2` |
| `TimeInForce` | NewOrder (21) | `0` |
| `AggregatedTrade` | OnePartyBlockTradeRequest (105) | `0` |
| `EnablePriceWarning` | OnePartyBlockTradeRequest (105) | `0` |

## Revision History

| Date | Author | Changes |
|---|---|---|
| 2026-08-08 | AI Assistant | v6.0 common conversion rules |
