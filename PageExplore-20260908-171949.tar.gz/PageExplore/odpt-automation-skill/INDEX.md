# ODP-T Automation Skill - Index

## Overview
This directory contains the skill documentation for the ODP-T (Order Drop Processing - Trading) automation testing project. It provides structured rules and workflows for AI agents and developers to maintain, extend, and troubleshoot the framework. Business requirements are indexed separately under [`../odp-docs/INDEX.md`](../odp-docs/INDEX.md).

**Framework:** Cucumber (Gherkin) + Ruby + WABI  
**Domain:** HKEX Derivatives Trading

---

## Quick Navigation

### Core Skill Files
| File | Purpose |
|---|---|
| [`SKILL.md`](./SKILL.md) | Main skill definition, workflows, execution rules |
| [`project-summary.md`](./project-summary.md) | Project status, Feature filename, session, and variable naming conventions |
| [`conversion-rules.md`](./conversion-rules.md) | Common/shared rules for all domains |
| [`execution-flow.schema.json`](./execution-flow.schema.json) | Machine-readable Hybrid Feature order, state, and external-gate contract |
| [`change-log.md`](./change-log.md) | Version history and change tracking |
| [`../odp-tc-excel-yaml-skill/SKILL.md`](../odp-tc-excel-yaml-skill/SKILL.md) | Excel → YAML conversion rules for test case parsing |
| [`FIXODPMSG_Index.md`](./FIXODPMSG_Index.md) | Generated FIXODPMSG message, field, and enum-value index |
| [`FIXODPMSG_Index.json`](./FIXODPMSG_Index.json) | Machine-readable FIXODPMSG index with optional transport dictionary |
| [`Error_Code_Index.md`](./Error_Code_Index.md) | Generated reject/status reason index with category-scoped lookups |
| [`Error_Code_Index.json`](./Error_Code_Index.json) | Machine-readable reject/status reason index and provenance |
| [`Step_Index.md`](./Step_Index.md) | Unified executable UAT vocabulary and source/authority mapping |
| [`Admin_GUI/Feature_Converter.md`](./Admin_GUI/Feature_Converter.md) | Playwright exploration artifact → Admin/Hybrid Feature conversion contract |
| [`Feature_Run_and_Debug.md`](./Feature_Run_and_Debug.md) | Opt-in Feature execution, redacted reports, and opencode diagnosis |
| [`repair_experience/INDEX.md`](./repair_experience/INDEX.md) | Review-gated repair findings and reusable anti-pattern lessons |
| [`../pageExplore/README.md`](../pageExplore/README.md) | Independent website exploration knowledge base |
| [`../pageExplore/pages/INDEX.md`](../pageExplore/pages/INDEX.md) | Generated Admin page routing/profile index |
| [`../pageExplore/qaGrid/Grid_API_Core_Index.md`](../pageExplore/qaGrid/Grid_API_Core_Index.md) | Shared qaGrid contract and safety policy |
| [`../pageExplore/qaGrid/qaGridApi_Index.json`](../pageExplore/qaGrid/qaGridApi_Index.json) | Machine-readable Grid observation index |
| [`../odp-docs/INDEX.md`](../odp-docs/INDEX.md) | Restored ODP Functional Specifications and provenance |
| [`sources/README.md`](./sources/README.md) | Provenance for supplied error-code hand-off snapshots |

### Domain-Specific Rule Files
| Domain | Rule File | Description |
|---|---|---|
| **Binary Interface** | [`Binary_Interface/INDEX.md`](./Binary_Interface/INDEX.md) | FIX protocol message transformation rules (18 files) |
| **Admin GUI** | [`Admin_GUI/index.md`](./Admin_GUI/index.md) | Admin web UI: 16 functional rule files |
| **Trading GUI** | [`Trading_GUI/index.md`](./Trading_GUI/index.md) | Trading web UI: 12 page-specific rule files |
| **Clearing Interface** | [`Clearing_Interface_Transform_Rules.md`](./Clearing_Interface_Transform_Rules.md) | Clearing FIX: TradeCaptureReport, session management |

### PageExplore and executable-vocabulary indexes

| Index | Use |
|---|---|
| [`Admin_GUI/Feature_Flow_Index.md`](./Admin_GUI/Feature_Flow_Index.md) | Repeated Admin flows mined from real Features |
| [`Admin_GUI/flow_catalog/INDEX.md`](./Admin_GUI/flow_catalog/INDEX.md) | Persisted Playwright MCP Admin flows and replay/reuse status (`tools/find_admin_flow.py`) |
| [`repair_experience/INDEX.md`](./repair_experience/INDEX.md) | Repair candidates, reviewed lessons, and reuse status |
| [`../pageExplore/qaGrid/Admin_GUI/Grid_API_Observation_Index.md`](../pageExplore/qaGrid/Admin_GUI/Grid_API_Observation_Index.md) | Admin-specific qaGrid keys and schemas |
| [`../pageExplore/qaGrid/Trading_GUI/Grid_API_Observation_Index.md`](../pageExplore/qaGrid/Trading_GUI/Grid_API_Observation_Index.md) | Trading-specific qaGrid keys and schemas |
| [`Step_Index.md`](./Step_Index.md) | Step definitions from UAT sources and runtime libraries |
| [`../pageExplore/qaGrid/qaGridApi_Index.md`](../pageExplore/qaGrid/qaGridApi_Index.md) | Regenerable aggregate evidence for both UI channels |
| [`Feature_Run_and_Debug.md`](./Feature_Run_and_Debug.md) | Run a generated or manually edited Feature and diagnose a failed run |

---

## How to Use This Skill

### For New Feature File Creation
1. Read the source YAML/Excel test case from `ai/TC/`
2. Follow the workflow in [`SKILL.md`](./SKILL.md) Section "A. New Feature File Creation"
3. Load only the required rule files based on the test case domain
4. Generate the feature file under `features/test_case/<Domain>/`

### Rule Selection Guide
| Test case involves... | Load these rules |
|---|---|
| FIX message send/expect | `Binary_Interface/INDEX.md` → specific message rule; use [`FIXODPMSG_Index.md`](./FIXODPMSG_Index.md) for wire enums and [`Error_Code_Index.md`](./Error_Code_Index.md) for reject/status meanings |
| Admin GUI web operations | `Admin_GUI/index.md` → specific function rule |
| Trading GUI web operations | `Trading_GUI/index.md` → specific page rule |
| Admin GUI setup discovered with Playwright | `Admin_GUI/index.md` → `Feature_Converter.md` → page, Grid, and Step indexes |
| Reuse a previously replayed Admin flow | `Admin_GUI/flow_catalog/INDEX.md` → flow manifest → `Feature_Converter.md` |
| Reuse a repaired pattern | `repair_experience/INDEX.md` → verified lesson → current-run verification |
| Admin setup followed by Binary | `Admin_GUI/Feature_Converter.md` + Binary rules; create and validate an independent Admin Feature first, then a separate non-Admin continuation and execution-flow JSON |
| Next-day/night-batch lifecycle | `conversion-rules.md` + `Binary_Interface/Dumpfile_Operations.md` + `execution-flow.schema.json` |
| Run or diagnose an existing Feature | `Feature_Run_and_Debug.md` → `tools/run_feature_debug.rb` |
| Select business requirements | `../odp-docs/INDEX.md` → relevant restored Functional Specification |
| Clearing message verification | `Clearing_Interface_Transform_Rules.md` |
| Feature file structure, tags, naming | `conversion-rules.md` |

---

## Versioning

| Version | Date | Description |
|---|---|---|
| v6.0 | 2026-08-08 | Transform accuracy fixes: section numbering, TradeType values, BCANField defaults, ID3 clarification, combo dataset mapping, WS step definitions completed |
| v5.0 | 2026-08-08 | Source format migration: Excel → YAML. Updated all references, added odp-tc-excel-yaml-skill cross-link |
| v4.0 | 2026-08-08 | Split Admin_GUI_Transform_Rules.md into 16 functional files |
| v3.0 | 2026-08-08 | Major restructure: fixed all references, split Trading GUI, added Trade History Aggregated, standardized format |
| v2.0 | 2026-07-29 | ODP17 full rewrite, conversion rules enhancement |
| v1.0 | 2026-07-28 | Initial skill creation |

## Date Format Convention
All dates in this skill use **YYYY-MM-DD** format (ISO 8601).

OpenCode defaults to the configured internal model
`ollama/DeepSeek-V4-Flash-INT8`. Use
`--model provider/model` or `OPENCODE_MODEL` to select a model listed by
`opencode models`; an explicit `--model`/`-m` in a custom command takes
precedence.

## Revision History

| Date | Author | Description |
|---|---|---|
| 2026-08-08 | AI Assistant | v6.0 - Added version entry, applied transform accuracy enhancements |
| 2026-08-08 | AI Assistant | v5.0 - Added odp-tc-excel-yaml-skill cross-reference, version table |
| 2026-08-08 | AI Assistant | Updated file structure for Admin_GUI/ split (v4.0) |
| 2026-08-08 | AI Assistant | Created index file during v3.0 restructure |
| 2026-09-01 | AI Assistant | Added shared Grid API, Trading observation, Step, and Admin converter routing indexes |
| 2026-09-02 | AI Assistant | Added audited Feature repair, FIX dumpfile hand-off, and review-gated repair experience catalog |
| 2026-09-01 | AI Assistant | Added opt-in Feature execution/diagnosis, supplied error-code provenance, and persisted Admin flow lifecycle guidance |
