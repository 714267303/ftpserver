# Repair Experience Catalog

This directory is a review-gated knowledge base for recurring Feature repair
findings.  It complements the Playwright Admin flow catalog:

```text
Feature run/repair
  -> repair_experience/inbox/*.json       (automatic, candidate only)
  -> repair_experience/lessons/*.json     (reviewed semantic lesson)
  -> verified + safe_to_reuse=true        (eligible for positive guidance)
```

The runner records metadata, hashes, statuses, and redacted error observations
only.  It does not copy the complete Feature, passwords, cookies, raw browser
traces, or unrestricted model output into this catalog.  The per-case
`run_reports/*.json` and `.repair.md` files remain the detailed audit record.

## Trust levels

| Status | Meaning | Automatic use |
|---|---|---|
| `candidate` | Produced by a repair run or awaiting review | Human review only; not automatic guidance |
| `reviewed` | A human has checked the wording and evidence | Not positive guidance until replayed |
| `verified` | Replayed from a clean state and the resulting Feature passed | Positive guidance only when `safe_to_reuse=true` |
| `rejected` | The proposed lesson was incorrect or too specific | Never use |

An entry must satisfy both `status=verified` and
`reuse.safe_to_reuse=true` before it can drive an automatic repair or
conversion.  Candidates are retained for human review and are not loaded as
automatic repair guidance; after promotion, the agent must still independently
verify the current Feature and runtime evidence.

## Catalog commands

```bash
python3 tools/build_repair_experience_catalog.py
python3 tools/build_repair_experience_catalog.py --check
```

Promote a candidate only after a clean replay, a review of the exact failure,
and removal of case-specific values.  Keep lessons short and semantic:
describe the symptom, the unsafe shape, the preferred UAT-step shape, and the
evidence needed to validate it.  Never put a password, token, cookie, UUID, or
raw locator in a lesson.

## Current entries

`inbox/admin_login_one_user_per_browser_candidate.json` records the dual Admin
login finding from an ODP10.2.5a run.  It remains the quarantined case-level
candidate and is never automatic guidance.

`lessons/admin_login_one_user_per_browser_reviewed.json` is the generalized
semantic version of the same finding.  It is marked `reviewed` for traceability
and matches `Admin_GUI/General_Navigation.md`, but remains
`safe_to_reuse=false` until a clean target-runtime replay passes.

The positive Playwright flow catalog and this repair catalog are intentionally
separate.  `Admin_GUI/flow_catalog/` records successful, reusable browser
flows; `repair_experience/inbox/` records failed or unsafe shapes.  A finding
must not be copied into the flow catalog merely because a model described it,
and an inbox candidate is never injected into a repair prompt automatically.
