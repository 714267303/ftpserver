# ODP-T Repair Experience Catalog

This index is generated from redacted candidates in `inbox/` and
semantic lessons in `lessons/`.  It is a review queue, not an
unrestricted prompt transcript.

Machine-readable index: [`INDEX.json`](INDEX.json)

## Trust policy

Only `status=verified` together with `reuse.safe_to_reuse=true` may
provide positive automatic repair guidance.  Candidate entries are
retained for human review and are not loaded as automatic repair
guidance.

| Metric | Count |
|---|---:|
| Lesson files | 2 |
| Indexed lessons | 2 |
| Inbox candidates | 1 |
| Candidate | 1 |
| Reviewed | 1 |
| Verified | 0 |
| Rejected | 0 |
| Safe to reuse | 0 |
| Catalog errors | 0 |

## Lessons

| Lesson ID | Status | Bucket | Scope | Reuse | Manifest |
|---|---|---|---|---|---|
| `repair.review.dual_admin_login.20260902` | `candidate` | `inbox` | admin_gui, hybrid | review | [admin_login_one_user_per_browser_candidate.json](inbox/admin_login_one_user_per_browser_candidate.json) |
| `admin.login.one_user_per_browser.v1` | `reviewed` | `lessons` | admin_gui, hybrid | review | [admin_login_one_user_per_browser_reviewed.json](lessons/admin_login_one_user_per_browser_reviewed.json) |

## Lifecycle

1. Run a Feature with `tools/run_feature_debug.rb --repair`; the
   runner writes a redacted candidate to `inbox/`.
2. Review the failure and remove case-specific values, credentials,
   locators, UUIDs, and raw transcripts.
3. Move the generalized lesson to `lessons/`, replay it from a clean
   state, and set `status=verified` and `safe_to_reuse=true` only
   after the resulting Feature passes.
4. Run this builder with `--check` in CI or before packaging.
