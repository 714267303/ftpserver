# Error Trade Request View Rules

## Keywords
Error, Trade, Request, View, Claim, Request, Details, Accept, Reject

## Step Patterns

### Login as Internal User
```gherkin
* Login ODP Trading GUI Internal User with:
    | User ID             | User Password                |
    | trd_gui_inter_user1 | trd_gui_inter_user1_password |
* Wait 1 seconds
* Clear Alert If Exist
* Wait 2 seconds
```

### Navigate to Error Trade Request View
```gherkin
* Select left menu "Trades>Error Trade Request View" in Trading GUI
* Wait 2 seconds
* Set table "Error Trade Request View" sort by column "Trade ID" type "Des"
```

### Verify Record Appears (Accepted Claim)
```gherkin
* Check table "Error Trade Request View" contains rows in Trading GUI with:
    | Trade ID                        |
    | <OrderReference>.TradeID              |
```

### Verify No Record Appears (Rejected Claim)
```gherkin
* Check table "Error Trade Request View" rows not contain in Trading GUI with:
    | Trade ID                        |
    | <OrderReference>.TradeID              |
```

### Table Columns
| Column | Type | Description |
|---|---|---|
| Claim Time | DateTime | Submission time (DD-MM-YYYY HH:MM:SS) |
| Direction | Alphanumeric | Claimant / Contra-Side (External only) |
| Claimant Comp ID | Alphanumeric | Comp ID of claimant EP |
| Claimant Trader ID | Alphanumeric | Trader ID of claimant EP |
| Contra-side Comp ID | Alphanumeric | Comp ID of contra-side EP |
| Contra-side Trader ID | Alphanumeric | Trader ID of contra-side EP |
| Claim ID | Alphanumeric | Unique Error Trade Request View ID |
| Status | Alphanumeric | New / Accepted / Rejected / Processed as LET / Processed |
| Consent Reply | Alphanumeric | Counterparty Consented/Declined/Received |

### Double Click Row
```gherkin
* Double click Trading GUI table "Error Trade Request View" column "Trade ID" with:
    | Trade ID [Key]               |
    | <OrderReference>.TradeID |
```

### Accept/Reject Claim
```gherkin
* Input value "Error Trade Details>Reference Price" is "19000" in Trading GUI
* Click button "Error Trade Details>Accept" in Trading GUI
* Wait 2 seconds
```

## Revision History

| Date | Author | Description |
|---|---|---|
| 2026-08-04 | AI Assistant | Extracted from Trading_GUI_Transform_Rules.md |
