# Exchange On Behalf Trade Rules

## Keywords
Exchange, On Behalf, Trade, Comp ID, Trader ID, Buy Side, Sell Side, Position Effect, Customer Information, BCAN

## Step Patterns

### Navigate to Exchange On Behalf Trade
```gherkin
* Select left menu "Trades>Exchange On Behalf Trade" in Trading GUI
* Wait 2 seconds
```

### Place Exchange On Behalf Trade
```gherkin
* Place Exchange On Behalf Trade in Trading GUI with:
    | Instrument ID | Price | Quantity | Buy Side Comp ID          | Buy Side Trader ID        | Buy Side Customer | Buy Side Position Effect | Buy Side Customer Information | Buy Side BCAN | Sell Side Comp ID         | Sell Side Trader ID       | Sell Side Customer | Sell Side Position Effect | Sell Side Customer Information | Sell Side BCAN | Last Traded Price | Last Traded Quantity | High Price | Low Price | Open Price | Volume | Action | Result Message                                           |
    | instrument_id1 | 20000 | 10       | trading_gui_user1_comp_id | trading_gui_user1_comp_id | Open                     | testB                         | ABC123.123    | trading_gui_user2_comp_id | trading_gui_user2_comp_id | H                  | Close                     | testS                          | ABC123.123     | N - No            | N - No               | N - No     | N - No    | N - No     | N - No | Submit | Your Exchange On Behalf Trade request has been accepted. |
```

### Countersign Request for Exchange On Behalf Trade
```gherkin
* Select left menu "Countersign>Countersign Request" in Trading GUI
* Wait 2 seconds
* Set "Countersign Request" value and click "Apply" in Trading GUI with:
    | Function Name            | Requestor           | Req Status |
    | Exchange On Behalf Trade | trd_gui_inter_user1 | Pending    |
* Wait 3 seconds
* Set table "Internal Trading GUI Countersign Request" sort by column "Received At" type "Des"
* Wait 2 seconds
* Screenshot
* Select table "Internal Trading GUI Countersign Request" rows with:
    | Identifier     |
    | instrument_id1 |
* Screenshot
* Click button "Countersign Request>More Actions" in Trading GUI
* Click button "Countersign Request>More Actions>Approve selected Countersign Request" in Trading GUI
* Click button "Countersign Request>CONFIRM" in Trading GUI
* Check the confirm message "Your action have been sent." of "Countersign Request" in Trading GUI
* Click button "Countersign Request>CLOSE" in Trading GUI
```

## Key Points
- Exchange On Behalf Trade requires **two users**: maker and checker
- Maker user makes the trade request
- Checker user approves via Countersign Request
- Form has 25+ fields including buy-side and sell-side information
- Supports Position Effect (Open, Close, N - No)
- Supports BCAN input for both sides
- After maker submit, checker user performs countersign approval

## Revision History
| Date | Author | Description |
|---|---|---|
| 2026-08-04 | AI Assistant | Extracted from ODP17.OnBehalfTrade-Template.feature |
