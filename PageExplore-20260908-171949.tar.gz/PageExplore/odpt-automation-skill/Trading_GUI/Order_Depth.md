# Order Depth Rules

## Keywords
Order, Depth, Refresh

## Step Patterns

### Navigate to Order Depth
```gherkin
* Select left menu "Market Data>Order Depth" in Trading GUI
* Wait 2 seconds
```

### Refresh Order Depth
```gherkin
* Set "Order Depth" value and click "Refresh" in Trading GUI with:
    | ID             |
    | instrument_id1 |
* Wait 2 seconds
```

### Verify Order Depth
```gherkin
* Check table "Order Depth" contains visible rows with:
    | ID             | BID | ASK |
    | instrument_id1 | 10  | 20  |
```

## Revision History

| Date | Author | Description |
|---|---|---|
| 2026-08-04 | AI Assistant | Extracted from Trading_GUI_Transform_Rules.md |
