# Enter Trade Report Rules

## Keywords
Enter, Trade, Report, Block, BCAN, Instrument

## Step Patterns

### Navigate to Enter Trade Report
```gherkin
* Click button "Enter Trade Report>Add" in Trading GUI
```

### Add Block Trade
```gherkin
* Add Block Trade on Enter Trade Report Internal with:
    | ID             | Price  | Quantity | Buyer Customer Information |
    | instrument_id1 | price1 | 100      | TStamp1                    |
```

**Key Points:**
- ID is instrument ID from dataSet-ODP16 (e.g., instrument_id1, instrument_id2)
- Price is block trade price (can be dynamic)
- Quantity is trade quantity
- Buyer Customer Information is timestamp or customer info

### Place Block Trade
```gherkin
* Place Block Trade on Enter Trade Report page with:
    | Buyer BCAN  | Seller BCAN | Result Message                                  |
    | bcanvalue | bcanvalue | Your new block trade request has been accepted. |
```

### Dynamic Price Assignment
```gherkin
* Assign ("1500." + (Time.now.strftime("%L")[-1].to_s)) to price1
* Assign ("55" + (Time.now.strftime("%L")[-1].to_s) + ".25") to price2
```

## Revision History

| Date | Author | Description |
|---|---|---|
| 2026-08-04 | AI Assistant | Extracted from Trading_GUI_Transform_Rules.md |
