# Market Message Rules

## Keywords
Market, Message, Message Type, Message Body, Send, Broadcast

## Step Patterns

### Navigate to Market Message
```gherkin
* Select left menu "Markets>Market Message" in Trading GUI
* Wait 2 seconds
```

### Send Market Message
```gherkin
* Set "Market Message" value and click "Apply" in Trading GUI with:
    | Message Type | Message Body              |
    | Broadcast    | This is a test message.   |
```

**Form Fields:**
| Field | Type | Description |
|---|---|---|
| Message Type | ComboBox | Type of market message (e.g., `Broadcast`, `Error Trade Alert`) |
| Message Body | TextInput | The message content to broadcast |
| Apply | Button | Send/apply the message |

### Verify Message in Grid
```gherkin
* Check table "Market Message" contains data in Trading GUI with:
    | Subject           | Content                      |
    | Error Trade Alert | ERROR_TRADINGTIMETABLE_MSG_1 |
```

**Key Points:**
- Uses `contains data` (not `contains rows`) because Market Message grid has specific data presentation
- `Subject` column corresponds to message type
- `Content` column corresponds to message body

### Select Message from Grid
```gherkin
* Select table "Market Message" data row with:
    | Subject           | Content                      |
    | Error Trade Alert | ERROR_TRADINGTIMETABLE_MSG_1 |
```

### Variable Replacement for Message Content
```gherkin
* Replace the value of ERROR_TRADINGTIMETABLE_MSG_1 from ToBeReplaced1 to instrument_id1
* Replace the value of ERROR_TRADINGTIMETABLE_MSG_1 from ToBeReplaced2 to 20000
```

## Revision History

| Date | Author | Description |
|---|---|---|
| 2026-08-04 | AI Assistant | Extracted from Trading_GUI_Transform_Rules.md |
