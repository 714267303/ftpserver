# Trade History Aggregated Rules

## Keywords
Trade, History, Aggregated, BOUGHT, SOLD, NET, QUANTITIES, TRADED, PRICE, AVERAGE PRICE, Aggregated checkbox, CompId, Trader, TOTAL, auto-update

## Overview
The Trade History Aggregated window displays trade data with aggregated groupings by instrument and price. It supports two display modes:
- **Non-aggregated (default)**: Shows each individual trade record
- **Aggregated**: Groups trades by instrument + price, with a TOTAL row per instrument showing combined quantities and average prices

## Step Patterns

### Navigate to Trade History Aggregated
```gherkin
* Select 1 times left menu "Trades>Trade History Aggregated" in Trading GUI
* Wait 5 seconds
```

### Close Opened All Tabs (Common Pre-Step)
```gherkin
* Close opened all tabs in Trading GUI
* Wait 1 seconds
```

### Set Filter and Apply (Non-Aggregated Mode)
```gherkin
* Set "Trade History Aggregated" value and click "Apply" in Trading GUI with:
    | ID             |
    | instrument_id1 |
* Wait 5 seconds
```

### Set Filter with CompId and Aggregated
```gherkin
* Set "Trade History Aggregated" value and click "Apply" in Trading GUI with:
    | ID             | CompId        | Aggregated |
    | instrument_id1 | PART1_OF_ID_1 | Y          |
* Wait 5 seconds
```

### Set Filter with Trader and Aggregated
```gherkin
* Set "Trade History Aggregated" value and click "Apply" in Trading GUI with:
    | Trader         | Aggregated |
    | PART1_OF_ID_1 | Y          |
* Wait 5 seconds
```

### Set Aggregated Only
```gherkin
* Set "Trade History Aggregated" value and click "Apply" in Trading GUI with:
    | Aggregated |
    | Y          |
* Wait 5 seconds
```

### Verify Non-Aggregated Table Data
```gherkin
* Check table "Trade History Aggregated" contains rows in Trading GUI with:
    | ID [Key]       | QUANTITIES:BOUGHT | QUANTITIES:SOLD | QUANTITIES:NET | TRADED:PRICE | AVERAGE PRICE:BOUGHT | AVERAGE PRICE:SOLD | AVERAGE PRICE:NET |
    | instrument_id1 | 1                 |                 | 1              | 100          | 100                  |                    | 100               |
* Screenshot
```

### Verify Aggregated Table Data (with TOTAL row)
```gherkin
* Assign ("instrument_id1" + " TOTAL") to instrument_id1_total
* Check table "Trade History Aggregated" contains rows in Trading GUI with:
    | ID [Key]             | QUANTITIES:BOUGHT | QUANTITIES:SOLD | QUANTITIES:NET | TRADED:PRICE [Key] | AVERAGE PRICE:BOUGHT | AVERAGE PRICE:SOLD | AVERAGE PRICE:NET |
    | instrument_id1_total | 1                 |                 | 1              |                    | 100                  |                    | 100               |
    | instrument_id1       | 1                 |                 | 1              | 100                |                      |                    |                   |
* Screenshot
```

### Verify Multiple Price Levels in Aggregated View
```gherkin
* Check table "Trade History Aggregated" contains rows in Trading GUI with:
    | ID [Key]             | QUANTITIES:BOUGHT | QUANTITIES:SOLD | QUANTITIES:NET | TRADED:PRICE [Key] | AVERAGE PRICE:BOUGHT | AVERAGE PRICE:SOLD | AVERAGE PRICE:NET |
    | instrument_id2_total | 5                 |                 | 5              |                    | 100                  |                    | 100               |
    | instrument_id2       | 3                 |                 | 3              | 100                |                      |                    |                   |
    | instrument_id2       | 2                 |                 | 2              | 101                |                      |                    |                   |
* Screenshot
```

### Save Quantities for Later Comparison
```gherkin
* Check table "Trade History Aggregated" contains rows in Trading GUI with:
    | ID [Key]             | QUANTITIES:BOUGHT [Save] | QUANTITIES:SOLD [Save] | QUANTITIES:NET [Save] | TRADED:PRICE [Key] | AVERAGE PRICE:BOUGHT | AVERAGE PRICE:SOLD | AVERAGE PRICE:NET |
    | instrument_id1_total | qty_b_id1_total          | qty_s_id1_total        | qty_n_id1_total       |                    | 100                  |                    | 100               |
    | instrument_id1       | qty_b_id1                | qty_s_id1              | qty_n_id1             | 100                |                      |                    |                   |
* Assign ("qty_b_id1_total".to_i + 1) to new_qty_b_id1_total
* Assign ("qty_n_id1_total".to_i + 1) to new_qty_n_id1_total
```

### Auto-Update Verification (No Refresh Needed)
After placing a new trade via Binary, verify the table auto-updates:
```gherkin
* Check table "Trade History Aggregated" contains rows in Trading GUI with:
    | ID [Key]             | QUANTITIES:BOUGHT | QUANTITIES:SOLD | QUANTITIES:NET | TRADED:PRICE | AVERAGE PRICE:BOUGHT | AVERAGE PRICE:SOLD | AVERAGE PRICE:NET |
    | instrument_id1       | 1                 |                 | 1              | 100          | 100                  |                    | 100               |
* Screenshot
```

### Export CSV
```gherkin
* Assign ("TradeHistoryAggregated-" + Time.now.strftime("%Y%m%-d%H%M%S") + ".csv") to file_name
* Trading GUI "Trade History Aggregated" page export csv save to "file_name" and read to "Trade_History_Aggregated"
```

### Verify Window Exists
```gherkin
* Verify window is exist in Trading GUI
    | window                   |
    | Trade History Aggregated |
```

## Table Column Reference

| Column | Aggregated Mode | Non-Aggregated Mode | Description |
|---|---|---|---|
| `ID [Key]` | instrument_id / instrument_id TOTAL | instrument_id | Instrument identifier |
| `QUANTITIES:BOUGHT` | Combined bought qty | Individual trade bought qty | Bought quantity |
| `QUANTITIES:SOLD` | Combined sold qty | Individual trade sold qty | Sold quantity |
| `QUANTITIES:NET` | Combined net qty | Individual trade net qty | Net quantity (BOUGHT - SOLD) |
| `TRADED:PRICE [Key]` | Empty for TOTAL row | Trade price | Execution price |
| `AVERAGE PRICE:BOUGHT` | Combined avg buy price | Single trade avg buy price | Average bought price |
| `AVERAGE PRICE:SOLD` | Combined avg sell price | Single trade avg sell price | Average sold price |
| `AVERAGE PRICE:NET` | Combined avg net price | Single trade avg net price | Average net price |

## Filter Field Reference

| Field | Step Column Name | Type | Description |
|---|---|---|---|
| ID | `ID` | TextInput | Filter by instrument ID |
| CompId | `CompId` | TextInput | Filter by trading participant (e.g., `PART1_OF_ID_1`) |
| Trader | `Trader` | TextInput | Filter by trader user ID |
| Aggregated | `Aggregated` | Checkbox | `Y` = aggregate, unchecked = individual records |

## TOTAL Row Behavior
- In Aggregated mode, each instrument has a TOTAL row with ID = `<instrument_id> TOTAL`
- TOTAL row shows combined quantities across all price levels
- TOTAL row has TRADED:PRICE empty, but AVERAGE PRICE columns populated
- Individual price-level rows appear below the TOTAL row
- Use `Assign ("instrument_id1" + " TOTAL") to instrument_id1_total` to construct the ID

## Auto-Update Feature
- The Trade History Aggregated window auto-updates when new trades are executed via Binary
- No need to re-apply filter or refresh the page
- Works in both Aggregated and Non-Aggregated modes

### Sort Column (Ascending/Descending)
```gherkin
* Set table "Trade History Aggregated" sort by column "TRADED:PRICE" type "Asc"
* Wait 1 seconds
* Check table "Trade History Aggregated" sort by column "TRADED:PRICE" type "Asc" Data type "int"
* Set table "Trade History Aggregated" sort by column "TRADED:PRICE" type "Des"
* Wait 1 seconds
* Check table "Trade History Aggregated" sort by column "TRADED:PRICE" type "Des" Data type "int"
```

### Column-Level Filter (Range)
```gherkin
* Click filter icon on "QUANTITIES:NET" column in "Trade History Aggregated"
* Wait 2 seconds
* Filter table "Trade History Aggregated" with conditions:
    | QUANTITIES:NET | Range | -10:10000 |
* Wait 2 seconds
```

### Reset Column-Level Filter (Reset All / Reset filters)
```gherkin
* Click filter reset all on "QUANTITIES:NET" column in "Trade History Aggregated"
* Wait 2 seconds
```

### Hide Columns via Column List
```gherkin
* Un-tick the checkbox of these fields via API on "Trade History Aggregated"
    | Column           |
    | QUANTITIES:BOUGHT |
    | QUANTITIES:SOLD   |
* Wait 2 seconds
* Check canvastable fields "Trade History Aggregated" NOT display with:
    | Column           |
    | QUANTITIES:BOUGHT |
    | QUANTITIES:SOLD   |
```

### Show Columns via Column List
```gherkin
* Tick the checkbox of these fields via API on "Trade History Aggregated"
    | Column           |
    | QUANTITIES:BOUGHT |
    | QUANTITIES:SOLD   |
* Wait 2 seconds
* Check canvastable fields "Trade History Aggregated" display with:
    | Column           |
    | QUANTITIES:BOUGHT |
    | QUANTITIES:SOLD   |
```

## Revision History

| Date | Author | Description |
|---|---|---|
| 2026-08-08 | AI Assistant | Created from analysis of ODP13.6.10.1-43 feature files |
| 2026-08-21 | AI Assistant | Added Sort Column, Column-Level Filter (Range), Filter Reset, and Column Visibility (hide/show) patterns for Trade History Aggregated table (ODP13.6.10.41) |
