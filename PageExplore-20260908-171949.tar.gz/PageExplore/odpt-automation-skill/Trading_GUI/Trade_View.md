# Trade View Rules

## Keywords
Trade, View, Instrument, ID, Price, Qty, Book, External

## Step Patterns

### Navigate to Trade View
```gherkin
* Select left menu "Trades>Trade View" in Trading GUI
* Wait 2 seconds
```

### Verify Trade Record
```gherkin
* Check table "Trade View" contains rows in Trading GUI with:
    | Trade ID | Instrument | Traded Price | Traded Quantity | Status |
    | <TradeID> | instrument_id1 | 20000 | 100 | New |
```

### Price Information Filter
```gherkin
* Import Trading GUI workspace "TradingGUI_Workspace"
* Set "Price Information" value and click "Apply" in Trading GUI with:
    | ID             |
    | instrument_id1 |
* Wait 2 seconds
* Check table "Price Information" contains visible rows with:
    | ID             | B QTY | BID | ASK | A QTY |
    | instrument_id1 | 5     | 10  | 20  | 6     |
```

## Revision History

| Date | Author | Description |
|---|---|---|
| 2026-08-04 | AI Assistant | Extracted from Trading_GUI_Transform_Rules.md |
