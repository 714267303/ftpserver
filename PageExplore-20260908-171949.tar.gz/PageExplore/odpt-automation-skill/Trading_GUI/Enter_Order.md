# Enter Order Rules

## Keywords
Enter, Order, Buy, Sell, Price, Quantity, Limit, Market, Clear

## Step Patterns

### Navigate to Enter Order
```gherkin
* Select left menu "Trades>Enter Order" in Trading GUI
* Wait 2 seconds
```

### Place Orders
```gherkin
* Place Orders on Enter Order page with:
    | Side | Price  | Quantity | Type        |
    | Buy  | 20000  | 100      | Limit Order |
* Wait 1 seconds
* Screenshot
```

### Change Order
```gherkin
* Change order in Trading GUI with:
    | Price | Side | Result Message                                 |
    | 20100 | Buy  | Confirm the amendment with losing order priority.|
```

### Clear Order
```gherkin
* Click button "Enter Order>Clear" in Trading GUI
* Wait 1 seconds
```

### Verify Order Fields
```gherkin
* Check value "Enter Order>Side" is "Buy" in Trading GUI
* Check value "Enter Order>Price" is "20000" in Trading GUI
* Check value "Enter Order>Quantity" is "100" in Trading GUI
```

## Revision History

| Date | Author | Description |
|---|---|---|
| 2026-08-04 | AI Assistant | Extracted from Trading_GUI_Transform_Rules.md |
