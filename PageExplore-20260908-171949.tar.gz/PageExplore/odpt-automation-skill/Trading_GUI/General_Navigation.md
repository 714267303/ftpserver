# General Navigation Rules

## Keywords
Login, Menu, Wait, Screenshot, Alert, Scroll, Switch browser

## Step Patterns

### Login
```gherkin
* Open browser
* Login ODP Trading GUI with:
    | User ID       | User Password          |
    | trd_gui_user1 | trd_gui_user1_password |
* Wait 1 seconds
* Clear Alert If Exist
* Wait 1 seconds
```

### Internal Login
```gherkin
* Open browser
* Login ODP Trading GUI Internal User with:
    | User ID             | User Password                |
    | trd_gui_inter_user1 | trd_gui_inter_user1_password |
* Wait 1 seconds
* Clear Alert If Exist
* Wait 2 seconds
```

### Save Browser
```gherkin
* Save current browser to browser_trading_gui_user1
* Save current browser to browser_trd_gui_inter_user1
```

### Close All Tabs
```gherkin
* Close opened all tabs in Trading GUI
* Wait 1 seconds
```
**Key Points:**
- Commonly used after login to close default workspace tabs
- Ensures clean state before opening specific windows
- Followed by `* Wait 1 seconds` to allow UI to settle

### Switch Browser
```gherkin
* Switch browser to "browser_trading_gui_user1" and maximize
* Switch browser to "browser_trd_gui_inter_user1" and maximize
```

### Select Menu
```gherkin
* Select left menu "Trades>Trade View" in Trading GUI
* Select left menu "Trades>Trade History" in Trading GUI
* Select left menu "Trades>Enter Order" in Trading GUI
* Select left menu "Trades>Error Trade Request View" in Trading GUI
* Select left menu "Trades>Trade Cancellation Request" in Trading GUI
* Select left menu "Trades>Ticker" in Trading GUI
* Select left menu "Countersign>Countersign Request" in Trading GUI
* Select left menu "Markets>Market Message" in Trading GUI
* Select left menu "Market Data>Price Information" in Trading GUI
* Select left menu "Market Data>Order Depth" in Trading GUI
* Wait 2 seconds
```

### Reopen Page
```gherkin
* Close exist page "Trade View" in Trading GUI
* Reopen page "Trades>Trade View" in Trading GUI
```

### Select N Times
```gherkin
* Select 2 times left menu "Trades>Trade View" in Trading GUI
```

### Screenshot
```gherkin
* Screenshot
```

### Wait
```gherkin
* Wait 1 seconds
* Wait 2 seconds
* Wait 3 seconds
```

### Clear Alert
```gherkin
* Clear Alert If Exist
```

### Import Workspace
```gherkin
* Import Trading GUI workspace "./resource/import/TradingGUI_Workspace/ODP5-PriceInfoAndOrderDepth.json"
* Import Trading GUI workspace "TradingGUI_Workspace"
* Wait 2 seconds
```

### Scroll
```gherkin
* Scroll page "Price Information" to "Top" in Trading GUI
* Scroll page "Price Information" to "Bottom" in Trading GUI
* Scroll page "Price Information" to "Mid" in Trading GUI
* Scroll page "Price Information" to "50 Percent" in Trading GUI
```

### Check Confirm
 ```gherkin
 * Check the confirm message "Your new order request has been accepted." of "Enter Order" in Trading GUI
 * Check uniquely only message "Your new order request has been accepted." in Trading GUI
 ```

 ### Table Search
 ```gherkin
 * Search table "Local Inactive Orders" by field "Instrument ID" with value "HSIJ5" in Trading GUI
 * Clear search table "Local Inactive Orders" field "Instrument ID" in Trading GUI
 ```
 **Key Points:**
 - Used to filter table rows by a search field above the data table (FS10014a_S0608_01101)
 - Search supports partial matching (e.g., "HSI" matches "HSIJ5", "HSIK5", HSI call option)
 - Clear search resets the filter to show all rows
 - Verify result with `Check table contains N rows`

 ### Activate Order (Local Inactive Orders)
  ```gherkin
  * Select row "2" of table "Local Inactive Orders" in Trading GUI
  * Click button "Local Inactive Orders>Activate Order" in Trading GUI
  * Wait 1 seconds
  * Check uniquely only message "Confirm activate of selected order(s)." in Trading GUI
  * Dialog OK
  * Wait 1 seconds
  ```
  **Key Points:**
  - Available as shortcut button on the Local Inactive Orders window (disabled when no selection)
  - Also accessible via `More Actions > Activate Order` menu
  - Triggers confirmation dialog: "Confirm activate of selected order(s.)" (FS10014a_S0608_0180)
  - On confirmation, order is removed from Local Inactive Orders and added to Order Book and Order History (FS10014a_S0608_0171)
  - Use `Dialog Close` to cancel the activation

  ## Revision History

  | Date | Author | Description |
  |---|---|---|
  | 2026-08-04 | AI Assistant | Extracted from Trading_GUI_Transform_Rules.md |
  | 2026-08-08 | AI Assistant | Added "Close All Tabs" step (missing undocumented pattern) |
  | 2026-08-20 | AI Assistant | Added "Table Search" step (Local Inactive Orders Instrument ID search, FS10014a_S0608_01101) |
  | 2026-08-20 | AI Assistant | Added "Activate Order" step (Local Inactive Orders activation, FS10014a_S0608_0171, FS10014a_S0608_0180) |
  | 2026-08-21 | AI Assistant | Added "Trades>Ticker" menu navigation pattern |
