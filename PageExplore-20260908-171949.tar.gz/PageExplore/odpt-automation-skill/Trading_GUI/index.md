# Trading GUI Rules Index

This index maps Trading GUI pages to their corresponding rule files for lazy-loading during test case transformations.

## Usage Instructions

When transforming a Trading GUI test case:
1. **Load this index file first** (`Trading_GUI/index.md`)
2. **Load** `${PAGEEXPLORE_ROOT}/qaGrid/Grid_API_Core_Index.md` and `../Step_Index.md` for any
   canvas-grid or executable-step mapping
3. **Consult** `${PAGEEXPLORE_ROOT}/qaGrid/Trading_GUI/Grid_API_Observation_Index.md`
   and `${PAGEEXPLORE_ROOT}/qaGrid/qaGridApi_Index.md` when a page needs observed
   key/schema evidence
4. **Identify the Trading GUI page** based on:
   - Test case source file references
   - Page names in test steps (e.g., "Error Trade Request View", "Market Message")
   - Action names (e.g., "Add Block Trade", "Send Market Message")
   - Field names (e.g., "Reference Price", "Message Body", "Countersign Request")
5. **Load only the corresponding page-specific rule file(s)**
6. **Do NOT load all Trading GUI rule files by default**
7. **If multiple pages are involved**, load only the required page rule files
8. **If the page cannot be determined**, use this index to select the best candidate or ask for clarification

## Page-to-Rule File Mapping

| Trading GUI Page | Keywords/Indicators | Rule File |
|---|---|---|
| **Error Trade Request View** | Error, Trade, Request, View, Claim, Request, Details, Accept, Reject, Reference Price, Deviation, Potential Loss, Claimant EP, Contra-side, Error Trade Details | `Error_Trade_Request_View.md` |
| **Market Message** | Market, Message, Message Type, Message Body, Send, Broadcast, Subject, Content | `Market_Message.md` |
| **Countersign Request** | Countersign, Request, Approve, Pending, Req Status, Requestor, More Actions, CONFIRM | `Countersign_Request.md` |
| **Enter Trade Report** | Enter, Trade, Report, Block, BCAN, Instrument, T PRC, DEAL SRC | `Enter_Trade_Report.md` |
| **Trade View** | Trade, View, ID, Price, Qty, Book, External, BOUGHT, SOLD | `Trade_View.md` |
| **Trade History** | History, Trade, ID, Status, Date, Action, ACTION, PART, TR TYPE, COMPID | `Trade_History.md` |
| **Trade History Aggregated** | History, Aggregated, BOUGHT, SOLD, NET, QUANTITIES, TRADED, Price, AVERAGE PRICE, TOTAL, Aggregated checkbox, CompId, Trader, auto-update | `Trade_History_Aggregated.md` |
| **Price Information** | Price, Information, BID, ASK, QTY, Implied, B QTY, A QTY | `Price_Information.md` |
| **Order Depth** | Order, Depth, Refresh | `Order_Depth.md` |
| **Enter Order** | Enter, Order, Buy, Sell, Price, Quantity, Clear | `Enter_Order.md` |
| **Exchange On Behalf Trade** | Exchange, On Behalf, Trade, Comp ID, Trader ID, Buy Side, Sell Side, Position Effect, Customer Information, BCAN | `Exchange_On_Behalf_Trade.md` |
| **General Navigation** | Login, Menu, Wait, Screenshot, Alert, Scroll, browser, Internal User, external | `General_Navigation.md` |

## Lazy-Loading Strategy

For any Trading GUI transform task:
1. **Load** `Trading_GUI/index.md` first
2. **Load** `${PAGEEXPLORE_ROOT}/qaGrid/Grid_API_Core_Index.md` and `../Step_Index.md`
3. **Identify the Trading GUI page** based on the transform request, source file, page name, or field names
4. **Load only the corresponding page-specific rule file(s)** from the mapping above
5. **Do NOT load all Trading GUI rule files by default** - this improves performance and reduces context window usage
6. **If multiple pages are involved**, load only the required page rule files
7. **If the page cannot be determined**, use the Keywords/Indicators column in the mapping table to select the best candidate or ask for clarification

## Revision History

| Date | Author | Description |
|---|---|---|
| 2026-08-04 | AI Assistant | Created index file and split Trading_GUI_Transform_Rules.md into page-specific rule files |
| 2026-08-04 | AI Assistant | Added Exchange_On_Behalf_Trade.md page-specific rule file |
| 2026-08-08 | AI Assistant | Fixed all path references (removed incorrect `rules/` segment). Added Trade_History_Aggregated.md. Deleted old combined Trading_GUI_Transform_Rules.md. |
| 2026-09-01 | AI Assistant | Linked shared Grid API, UAT Step, and generated observation indexes |
