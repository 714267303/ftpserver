# Countersign Request Rules

## Keywords
Countersign, Request, Approve, Pending

## Step Patterns

### Login as Internal User
```gherkin
* Login ODP Trading GUI Internal User with:
    | User ID             | User Password                |
    | trd_gui_inter_user1 | trd_gui_inter_user1_password |
* Wait 1 seconds
* Clear Alert If Exist
* Wait 2 seconds
```

### Navigate to Countersign Request
```gherkin
* Select left menu "Countersign>Countersign Request" in Trading GUI
* Wait 2 seconds
```

### Filter Requests
```gherkin
* Set "Countersign Request" value and click "Apply" in Trading GUI with:
    | Req Status | Requestor       |
    | Pending    | PART1_OF_ID_1   |
```

### Sort by Received At
```gherkin
* Set table "Internal Trading GUI Countersign Request" sort by column "Received At" type "Des"
```

### Select a Request
```gherkin
* Select table "Internal Trading GUI Countersign Request" rows with:
    | Function Name [Key] | Requestor       |
    | Cancel Order        | PART1_OF_ID_1   |
```

### Click Approve Option
```gherkin
* Click button "Countersign Request>More Actions" in Trading GUI
* Click button "Countersign Request>More Actions>Approve selected Countersign Request" in Trading GUI
```

### Confirm Approval
```gherkin
* Check the confirm message "All Current Countersign selected items will be approved." of "Countersign Request" in Trading GUI
* Wait 1 seconds
* Click button "Countersign Request>CONFIRM" in Trading GUI
* Wait 2 seconds
```

## Revision History

| Date | Author | Description |
|---|---|---|
| 2026-08-04 | AI Assistant | Extracted from Trading_GUI_Transform_Rules.md |
