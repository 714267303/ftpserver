# Trade History Rules

## Keywords
Trade, History, ID, Status, Action, Buy, Sell, Sort, Filter, MATCH ID, TIME, T PRC, PART, MKT, STATE, CUST, COMPID

## Step Patterns

### Navigate to Trade History
```gherkin
* Select left menu "Trades>Trade History" in Trading GUI
* Wait 2 seconds
```

### Verify Trade History
```gherkin
* Check table "Trade History" contains rows in Trading GUI with:
    | ACTION | PART  | ID             | TRADE ID | BOUGHT | SOLD | R QTY | T PRC  | RP   | TR TYPE | COMPID        | DEAL SRC |
    | New    | part1 | instrument_id1 | trade_id1-1     | 100    |      |       | price1 | Open | New     | trd_gui_user1 | EMP 1 BR |
    | New    | part1 | instrument_id1 | trade_id1-2     |        | 100  |       | price1 | Open | New     | trd_gui_user1 | EMP 1 BR |
```

### Verify Equal
```gherkin
* Verify each row values are equal in table:
    | Value       | Value       |
    | trade_id1-1 | trade_id1-2 |
```

### Sort Column (Ascending/Descending)
```gherkin
* Set table "Trade History" sort by column "TIME" type "Asc"
* Wait 1 seconds
* Check table "Trade History" sort by column "TIME" type "Asc" Data type "string"
* Set table "Trade History" sort by column "TIME" type "Des"
* Wait 1 seconds
* Check table "Trade History" sort by column "TIME" type "Des" Data type "string"
```

**Key Points:**
- Column name must match exactly as displayed in the Trade History table header
- Available columns: TIME, T PRC, PART, MKT, ID, TRADE ID, COMPID, DEAL SRC, ACTION
- String columns (ID, PART, MKT, TRADE ID, COMPID, DEAL SRC, ACTION): Data type "string"
- Numeric columns (T PRC, R QTY, BOUGHT, SOLD): Data type "int"
- TIME column is a timestamp displayed as string: Data type "string"
- Click column header once = Ascending ("Asc"), click again = Descending ("Des")

### Column-Level Filter (Range)
```gherkin
* Click filter icon on "T PRC" column in "Trade History"
* Wait 2 seconds
* Filter table "Trade History" with conditions:
    | T PRC  | Range | 20000:20050 |
* Wait 2 seconds
* Check table "Trade History" contains filtered values:
    | T PRC  |
    | 20000  |
    | 20001  |
    | 20002  |
```

### Column-Level Filter (Equals)
```gherkin
* Click filter icon on "MATCH ID" column in "Trade History"
* Wait 2 seconds
* Filter table "Trade History" with conditions:
    | MATCH ID | Equals | match_id1 |
* Wait 2 seconds
* Check table "Trade History" contains filtered values:
    | MATCH ID |
    | match_id1 |
```

### Column-Level Filter (Contains)
```gherkin
* Click filter icon on "MKT" column in "Trade History"
* Wait 2 seconds
* Filter table "Trade History" with conditions:
    | MKT | Contains | SO |
* Wait 2 seconds
```

### Reset Column-Level Filter (Reset All)
```gherkin
* Click filter reset all on "T PRC" column in "Trade History"
* Wait 2 seconds
```

### Reset Table Filters (Global)
```gherkin
* Click button "Trade History>Reset filters" in Trading GUI
* Wait 2 seconds
```

### Hide Columns via Column List
```gherkin
* Un-tick the checkbox of these fields via API on "Trade History"
    | Column   |
    | MATCH ID |
    | STATE    |
    | T PRC    |
* Wait 2 seconds
* Check canvastable fields "Trade History" NOT display with:
    | Column   |
    | MATCH ID |
    | STATE    |
    | T PRC    |
```

### Show Columns via Column List
```gherkin
* Tick the checkbox of these fields via API on "Trade History"
    | Column   |
    | MATCH ID |
    | STATE    |
    | T PRC    |
* Wait 2 seconds
* Check canvastable fields "Trade History" display with:
    | Column   |
    | MATCH ID |
    | STATE    |
    | T PRC    |
```

**Key Points (Column Visibility):**
- Trade History columns can be shown/hidden via the column list icon in the filter panel
- Columns visible in External Trading GUI: ACTION, PART, ID, TRADE ID, BOUGHT, SOLD, R QTY, T PRC, RP, TR TYPE, COMPID, DEAL SRC
- Additional columns available in Internal Trading GUI: MATCH ID, STATE, CUST, GUP, G ACC, INFO, MKT, ORDER NO, C PART, ATID

### Verify Filtered Values
```gherkin
* Check table "Trade History" contains filtered values:
    | Column |
    | value1 |
    | value2 |
```

## Revision History

| Date | Author | Description |
|---|---|---|
| 2026-08-04 | AI Assistant | Extracted from Trading_GUI_Transform_Rules.md |
| 2026-08-21 | AI Assistant | Added Sort Column, Column-Level Filter (Range/Equals/Contains), Filter Reset patterns, Column Visibility (hide/show), and Verify Filtered Values patterns for Trade History table (ODP13.6.9.41) |
