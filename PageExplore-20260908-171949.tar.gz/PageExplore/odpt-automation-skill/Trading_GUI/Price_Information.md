# Price Information Rules

## Keywords
Price, Information, BID, ASK, QTY, B QTY, A QTY, Implied

## Step Patterns

### Navigate to Price Information
```gherkin
* Select left menu "Market Data>Price Information" in Trading GUI
* Wait 2 seconds
```

### Set Price Information Filter
```gherkin
* Set "Price Information" value and click "Apply" in Trading GUI with:
    | ID             |
    | instrument_id1 |
* Wait 2 seconds
```

### Verify Price Information
```gherkin
* Check table "Price Information" contains visible rows with:
    | ID             | B QTY | BID | ASK | A QTY |
    | instrument_id1 | 5     | 10  | 20  | 6     |
* Screenshot
```

### Implied Order Waiting
```gherkin
* Check table "Price Information" and wait "3" seconds for Implied with:
    | ID             | B QTY | BID | ASK | A QTY |
    | instrument_id1 |       |     |     |       |
```

### Import Workspace
```gherkin
* Import Trading GUI workspace "ODP5-PriceInfoAndOrderDepth.json"
* Wait 2 seconds
```

## Revision History

| Date | Author | Description |
|---|---|---|
| 2026-08-04 | AI Assistant | Extracted from Trading_GUI_Transform_Rules.md |
