# ODP Functional Specifications

This directory is the restored ODP business-document knowledge base. The
source snapshot is maintained as `uat/odp_doc.md` in the maintainer checkout;
it is intentionally not included in the tester delivery bundle. The
reproducible restore command, for maintainers working from the source root, is:

```bash
python3 tools/restore_odp_docs.py --source uat/odp_doc.md --output odp-docs
```

Use [`INDEX.md`](INDEX.md) to locate a relevant Functional Specification and
[`INDEX.json`](INDEX.json) for tooling. Restored documents live below
`files/markdown/` and preserve the paths embedded in the source snapshot.

These documents describe business intent and expected system behavior. Feature
generation and repair must still use the runtime Ruby step definitions,
`Step_Index`, FIX dictionaries, and PageExplore observations as the authorities
for executable syntax and current UI behavior. Do not copy credentials,
dynamic identifiers, raw browser locators, or `qaGridApi.setRowData()` calls
from evidence into a Feature.

For a case involving a specific business area, select the corresponding FS
from the index and read only the relevant sections. The index records source
line ranges and SHA-256 hashes so a generated Feature can retain document
provenance without embedding the entire source bundle in an agent prompt.
