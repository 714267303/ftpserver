TITLE:

**FUNCTIONAL SPECIFICATION**

***ODP-T***

***FS10013 Market Operation Admin GUI***

AUTHOR: *IT/Markets Systems* DATE: *24 Jul 2026*

LAST REVIEW: *Derivatives Trading Business Operations*  DATE: *28 Feb 2025*

**CONTENTS**

[1. Document Control 6](#_Toc235611307)

[1.1. Change History 6](#_Toc235611308)

[1.2. Document Cross-referenced 16](#_Toc235611309)

[1.3. Abbreviation 16](#_Toc235611310)

[1.4. Distribution List 16](#_Toc235611311)

[2. Introduction 18](#_Toc235611312)

[3. Screen Design 18](#_Toc235611313)

[3.1. Data Type 18](#_Toc235611314)

[3.1.1. UI Widget Mapping by Data Type 20](#_Toc235611315)

[3.2. Content Assistant 21](#_Toc235611316)

[3.3. Application Layout 21](#_Toc235611317)

[3.4. GUI Notification 22](#_Toc235611318)

[3.5. User Workspace 24](#_Toc235611319)

[3.6. Record Status 24](#_Toc235611320)

[3.6.1. Case 1 – No Planned Changes 24](#_Toc235611321)

[3.6.2. Case 2 – Add New Record 24](#_Toc235611322)

[3.6.3. Case 3 – Update record 26](#_Toc235611323)

[3.6.4. Case 4 – Delete Record 27](#_Toc235611324)

[3.7. Type of Functions 28](#_Toc235611325)

[3.7.1. Permanent Function 28](#_Toc235611326)

[3.7.2. Temporary Function 29](#_Toc235611327)

[3.7.3. Exchange User Function 29](#_Toc235611328)

[3.7.4. Common Utility of function 29](#_Toc235611329)

[3.8. Request Status 29](#_Toc235611330)

[3.9. Request Action 30](#_Toc235611331)

[3.10. Current Record and Request Record 31](#_Toc235611332)

[3.10.1. Current Record 31](#_Toc235611333)

[3.10.2. Create a New Record 32](#_Toc235611334)

[3.10.3. Request a Change 33](#_Toc235611335)

[3.10.4. Change Request Indicator 34](#_Toc235611336)

[3.10.5. Amend a Change Request 35](#_Toc235611337)

[3.10.6. Request Record 36](#_Toc235611338)

[~~3.10.7.~~ [Revoked] ~~Resubmit a Rejected / Withdrawn Change Request~~ 38](#_Toc235611339)

[3.10.8. Effective Date of the Change Request (Permanent Functions) 39](#_Toc235611340)

[3.10.9. Effective Date of the Change Request (Temporary Functions) 39](#_Toc235611341)

[3.10.10. Record Dependencies 40](#_Toc235611342)

[3.10.11. Effective of the Change Request (As soon as possible / Today) 43](#_Toc235611343)

[3.11. Authorization Flow 44](#_Toc235611344)

[3.11.1. Countersign Request 45](#_Toc235611345)

[3.11.2. Countersign Request Detail Screen 47](#_Toc235611346)

[3.12. User Preferences 57](#_Toc235611347)

[3.13. Inheritance Attribute 57](#_Toc235611348)

[3.14. Permissions 58](#_Toc235611349)

[3.15. Screen 59](#_Toc235611350)

[3.15.1. Search Screen 59](#_Toc235611351)

[3.15.2. Detail Screen 60](#_Toc235611352)

[3.15.3. Control Screen 62](#_Toc235611353)

[3.15.4. Monitoring Screen 62](#_Toc235611354)

[3.15.5. System Time and Client Local Time 62](#_Toc235611355)

[4. Admin Functions 63](#_Toc235611356)

[4.1. Common 63](#_Toc235611357)

[4.1.1. Function Type 63](#_Toc235611358)

[4.1.2. Bulk Amend by UI Select (TBC) 76](#_Toc235611359)

[4.1.3. Bulk Import from File (TBC) 76](#_Toc235611360)

[4.1.4. Change History 77](#_Toc235611361)

[4.1.5. Common Attributes 78](#_Toc235611362)

[4.1.6. Common Permission Behaviour 84](#_Toc235611363)

[4.1.7. Common Actions 84](#_Toc235611364)

[4.1.8. Common Validation 85](#_Toc235611365)

[4.1.9. IPv4 Validation 85](#_Toc235611366)

[4.1.10. Common Notification 85](#_Toc235611367)

[4.2. Instrument Hierarchy 86](#_Toc235611368)

[4.2.1. Maintain Exchange 87](#_Toc235611369)

[4.2.2. Maintain Market 88](#_Toc235611370)

[4.2.3. Maintain Instrument Group 91](#_Toc235611371)

[4.2.4. Maintain Instrument Type 94](#_Toc235611372)

[4.2.5. Maintain Underlying 97](#_Toc235611373)

[4.2.6. Maintain Instrument Class 101](#_Toc235611374)

[4.2.7. Maintain Instrument 107](#_Toc235611375)

[4.2.8. Maintain Instrument Name Standard 113](#_Toc235611376)

[4.2.9. Maintain Access Group By Type 116](#_Toc235611377)

[4.3. Combo Hierarchy 118](#_Toc235611378)

[4.3.1. Maintain Combo Group 119](#_Toc235611379)

[4.3.2. Maintain Combo Type 121](#_Toc235611380)

[4.3.3. Maintain Combo Class 125](#_Toc235611381)

[4.3.4. Maintain Combo 130](#_Toc235611382)

[4.3.5. Maintain Combo Name Standard 137](#_Toc235611383)

[4.4. Auto Instrument Generation 141](#_Toc235611384)

[4.4.1. Maintain Auto Generation Rule 141](#_Toc235611385)

[4.4.2. Maintain Cycle Blocks 145](#_Toc235611386)

[4.4.3. Maintain Last Trading Date Formula 150](#_Toc235611387)

[4.4.4. Maintain Regional Holiday Calendar 155](#_Toc235611388)

[4.4.5. Maintain Last Trading Date Calendar 159](#_Toc235611389)

[4.4.6. Maintain Lifecycle Time Rule 165](#_Toc235611390)

[4.4.7. Maintain Last Trading Time DST Adjustment 168](#_Toc235611391)

[4.4.8. Maintain Strike Price Range 170](#_Toc235611392)

[4.4.9. Maintain Strike Price Table 172](#_Toc235611393)

[4.4.10. Maintain Strike Price Reference 175](#_Toc235611394)

[4.4.11. Instrument Generation 177](#_Toc235611395)

[4.4.12. Regional Calendar Upload 181](#_Toc235611396)

[4.5. Auto Combo Generation **#FS10013\_S0405\_00100** 184](#_Toc235611397)

[4.5.1. Maintain Auto Combo Generation Rule Group 184](#_Toc235611398)

[4.5.2. Combo Generation 194](#_Toc235611399)

[4.6. SMP 198](#_Toc235611400)

[4.6.1. Maintain SMP ID 198](#_Toc235611401)

[4.6.2. Review SMP Request (PDF form from ECP) 201](#_Toc235611402)

[4.6.3. ID Generation 205](#_Toc235611403)

[4.7. TMC 206](#_Toc235611404)

[4.7.1. Maintain TMC Strategy List 206](#_Toc235611405)

[4.7.2. Maintain TMC Strategy 208](#_Toc235611406)

[4.7.3. Control TMC 213](#_Toc235611407)

[4.8. Price Supervision 216](#_Toc235611408)

[4.8.1. Maintain Price Tick 216](#_Toc235611409)

[4.8.2. Maintain Price Tick Limit Rule 219](#_Toc235611410)

[4.8.3. Maintain Instrument Class Price Tick Limit 220](#_Toc235611411)

[4.8.4. Maintain Combo Class Price Tick Limit 222](#_Toc235611412)

[4.8.5. Maintain Price Limit 224](#_Toc235611413)

[4.8.6. Maintain Price Limit Parameters 226](#_Toc235611414)

[4.8.7. Maintain Reference Price Source 231](#_Toc235611415)

[4.8.8. Maintain Reference Price Calculation Rule 233](#_Toc235611416)

[4.8.9. Maintain VCM 235](#_Toc235611417)

[4.8.10. Maintain VCM Parameters 237](#_Toc235611418)

[4.8.11. Maintain Futures Group 239](#_Toc235611419)

[4.8.12. Control & Monitor Price Limit 241](#_Toc235611420)

[4.8.13. Control & Monitor VCM 244](#_Toc235611421)

[4.8.14. Control & Monitor Instrument Trading Halt 247](#_Toc235611422)

[4.8.15. Control Contingency Trigger of Inst. Class Price Tick Limit Calculation 248](#_Toc235611423)

[4.8.16. Control Contingency Trigger of AHT Reference Price Calculation 249](#_Toc235611424)

[4.8.17. Control Contingency Trigger of Combo Class Price Tick Limit Calculation 250](#_Toc235611425)

[4.9. Block Trade 252](#_Toc235611426)

[4.9.1. Maintain Block Trade Group 252](#_Toc235611427)

[4.9.2. Maintain Block Trade MVT 253](#_Toc235611428)

[4.10. Error Trade 255](#_Toc235611429)

[4.10.1. Maintain Combo Type Error Trade Parameters 255](#_Toc235611430)

[4.10.2. Maintain Instrument Type Error Trade Parameters 256](#_Toc235611431)

[4.11. Report Generation and Processing 258](#_Toc235611432)

[4.11.1. Maintain Report 258](#_Toc235611433)

[~~4.11.2.~~ [Revoked] ~~(Maintain Weekly Quotation Report,~~ merged to Maintain Report~~)~~ 259](#_Toc235611434)

[4.11.3. Maintain Report Group List 260](#_Toc235611435)

[4.11.4. Control Daily Market Report (DMR) 264](#_Toc235611436)

[4.11.5. Control Admin Report 265](#_Toc235611437)

[4.12. Market Messages 267](#_Toc235611438)

[4.12.1. Maintain Message Template 267](#_Toc235611439)

[4.12.2. Maintain Automatic Event Message 269](#_Toc235611440)

[4.12.3. Send Manual Market Announcement 272](#_Toc235611441)

[4.13. Capital Adjustment 273](#_Toc235611442)

[4.13.1. Control Capital Adjustment 274](#_Toc235611443)

[4.14. Participant 281](#_Toc235611444)

[4.14.1. Maintain Exchange Participant 281](#_Toc235611445)

[4.14.2. Maintain Drop Copy Group 284](#_Toc235611446)

[4.14.3. Maintain Direct Drop Copy Session 286](#_Toc235611447)

[4.14.4. Maintain Direct Order Flow Session 290](#_Toc235611448)

[4.14.5. Maintain Legal IP Address 294](#_Toc235611449)

[4.14.6. Maintain PTRM GUI User 295](#_Toc235611450)

[4.14.7. Maintain Trading GUI User 299](#_Toc235611451)

[4.14.8. Maintain Sponsoring Participant 303](#_Toc235611452)

[4.14.9. Maintain Trading Rights 305](#_Toc235611453)

[4.14.10. Maintain Participant User Role 307](#_Toc235611454)

[4.14.11. Maintain SMP ID List 310](#_Toc235611455)

[4.14.12. Maintain MMP Parameter 312](#_Toc235611456)

[4.14.13. Control Block/Unblock Participant Per Product 313](#_Toc235611457)

[4.14.14. Maintain Company 315](#_Toc235611458)

[4.14.15. Maintain Self Admin Portal User 316](#_Toc235611459)

[4.14.16. Request External IDP User 318](#_Toc235611460)

[4.15. Timetable 321](#_Toc235611461)

[4.15.1. Maintain Trading Timetable 321](#_Toc235611462)

[4.15.2. Maintain Trading State 324](#_Toc235611463)

[4.15.3. Maintain Non-Trading Days 329](#_Toc235611464)

[4.15.4. Maintain Special Trading Days 331](#_Toc235611465)

[4.15.5. Control Trading Timetable 332](#_Toc235611466)

[~~4.15.6.~~ ~~Control Trading Pause~~ (Merged to Control Trading Timetable) 336](#_Toc235611467)

[4.15.7. ~~Control Early Close~~ (Merged to Control Trading Timetable) 338](#_Toc235611468)

[4.16. System 339](#_Toc235611469)

[4.16.1. Maintain Global Parameters 339](#_Toc235611470)

[4.16.2. Maintain Contingency Switch 347](#_Toc235611471)

[4.16.3. View Password Policy 348](#_Toc235611472)

[4.17. Control & Monitoring 350](#_Toc235611473)

[4.17.1. Monitor Historical Order Book 350](#_Toc235611474)

[4.17.2. Monitor Quote Request 352](#_Toc235611475)

[4.17.3. Monitor OLS Record 354](#_Toc235611476)

[4.17.4. Monitor Event and Alert 355](#_Toc235611477)

[4.17.5. Monitor Order Flow Gateway 358](#_Toc235611478)

[4.17.6. Monitor Drop Copy Gateway 363](#_Toc235611479)

[4.17.7. Monitor Lookup Server Statistic 366](#_Toc235611480)

[4.17.8. Order Flow Client Enquiry 367](#_Toc235611481)

[4.17.9. Drop Copy Client Enquiry 371](#_Toc235611482)

[4.17.10. Control & Monitor Order Flow Client 373](#_Toc235611483)

[4.17.11. Control & Monitor Drop Copy Client 381](#_Toc235611484)

[4.17.12. Control & Monitor Trading GUI Client 385](#_Toc235611485)

[4.17.13. Control & Monitor PTRM GUI Client 387](#_Toc235611486)

[4.17.14. Control Settlement Values 390](#_Toc235611487)

[4.17.15. Control Underlying Price 392](#_Toc235611488)

[4.18. User Maintenance 394](#_Toc235611489)

[4.18.1. Maintain Exchange User 394](#_Toc235611490)

[4.18.2. Maintain UI User Role 398](#_Toc235611491)

[4.18.3. Maintain System Preference 400](#_Toc235611492)

[4.18.4. Request Internal IDP User 406](#_Toc235611493)

[5. Appendix 408](#_Toc235611494)

[5.1. Irrelevant BRD Items 408](#_Toc235611495)

[5.2. Security Requirement 412](#_Toc235611496)

[5.3. Housekeeping at Migration 412](#_Toc235611497)

[5.4. Maxima Limit 412](#_Toc235611498)

[5.5. Validation Rule 415](#_Toc235611499)

[5.6. Short Name Full Name Mapping 415](#_Toc235611500)

[5.7. Template 415](#_Toc235611501)

# Document Control

## Change History

|  |  |  |  |
| --- | --- | --- | --- |
| Version  Number | Issue Date | Author | Abstract |
| 0.1 | 21 Jul 2023 | IT/Markets Systems | Initial Version |
| 0.1.1 | 22 Jul 2024 | IT/Markets Systems | Update according to RDB v0.0.1 |
| 0.2 | 5 Aug 2024 | IT/Markets Systems | Update according to RDB v0.0.2 |
| 0.3 | 8 Nov 2024 | IT/Markets Systems | Update according to RDB v0.0.3 |
| 0.4 | 13 Dec 2024 | IT/Markets Systems | Update according to RDB v0.0.4 |
| 0.4.1 | 17 Jan 2025 | IT/Markets Systems | Update according to RDB v0.0.4.1 |
| 0.5 | 23 Jan 2025 | IT/Markets Systems | Update according to RDB v0.0.5.0 |
| 0.5.1b | 7 Feb 2025 | IT/Markets Systems | Update according to RDB v0.0.5.1b |
| 1.0 | 21 Mar 2025 | IT/Markets Systems | Update according to RDB v0.0.6 |
| 1.0.1 | 11 Apr 2025 | IT/Markets Systems | Update according to RDB v0.0.7 |
| 1.0.2 | 23 May 2025 | IT/Markets Systems | Update according to RDB v0.0.8 and v0.0.9 |
| 1.0.3 | 30 May 2025 | IT/Markets Systems | Update according to RDB v0.0.10 |
| 1.0.4 | 20 Jun 2025 | IT/Markets Systems | Update according to RDB v0.0.12 |
| 1.0.5 | 25 Jul 2025 | IT/Markets Systems | * Revoke 4.11.4 Control Daily Market Report (DMR) * Update according to RDB v0.0.13a |
| 1.0.6 | 8 Sep 2025 | IT/Markets Systems | * Revoke 3.10.7 Resubmit a Rejected / Withdrawn Change Request * Add 5.6 * Add “Manual Stop VCM” to 4.8.13 * Update 4.14 * Update MIN price value in 3.1 * Update according to RDB v0.0.13e |
| 1.0.7 | 30 Sep 2025 | IT/Markets Systems | * Revoke revoked 4.11.4 Control Daily Market Report (DMR) * Rename 4.18.1 from Maintain Admin GUI User to Maintain Exchange GUI User * Update description and diagram of 4.15.5 Control Trading Timetable * Update 4.10 field names * Add OTP Delivery Method to 4.14.16 & 4.18.4 * Update validation rule to v1.0.7 * Update 4.4.3 Maintain Last Trading Date Formula |
| 1.0.8 | 27 Oct 2025 | IT/Markets Systems | * Update according to RDB v0.0.13h * Update IDP related field charset * Remove import in detail pages * Update 4.3.5 Maintain Combo Name Standard * Update 4.4.3 Maintain Last Trading Date Formula * Update 4.5.1 Maintain Auto Combo Generation Rule Group * Update 4.7.1 Maintain TMC Strategy List * Update 4.9.2 Maintain Block Trade MVT * Update 4.12 Market Messages * Update 4.14.14 Maintain Company * Rename function name for 4.14.16 & 4.18.4 * Update 4.15.5 Control Trading Timetable |
| 1.0.9 | 7 Nov 2025 | IT/Markets Systems | Update   * 4.2.7 Maintain Instrument * 4.2.8 Maintain Instrument Name Standard * 4.3.4 Maintain Combo * 4.3.5 Maintain Combo Name Standard * 4.4.1 Maintain Auto Generation Rule * 4.4.2 Maintain Cycle Blocks * 4.4.3 Maintain Last Trading Date Formula * 4.7.2 Maintain TMC Strategy * 4.9.2 Maintain Block Trade MVT * 4.14.4 Maintain Direct Order Flow Session * 4.14.6 Maintain PTRM GUI User * 4.14.7 Maintain Trading GUI User * 4.14.12 Maintain MMP Parameter * 4.14.14 Maintain Company * 4.14.15 Maintain Self Admin Portal User * 4.17.14 Control Settlement Values * 4.18.1 Maintain Exchange GUI User * 4.18.3 Maintain System Preference |
| 1.0.10 | 28 Nov 2025 | IT/Markets Systems | Update   * 4.4.3 Maintain Last Trading Date Formula * 4.4.9 Maintain Strike Price Table * 4.4.10 Maintain Strike Price Reference * 4.8.12 Control & Monitor Price Limit * 4.14.6 Maintain PTRM GUI User * 4.14.7 Maintain Trading GUI User * 4.14.15 Maintain Self Admin Portal User * 4.14.16 Request External EIDP User * 4.15.3 Maintain Non-Trading Days * 4.16.1 Maintain Global Parameters * 4.18.1 Maintain Exchange User * 4.18.4 Request Internal EIDP User |
| 1.0.11 | 17 Dec 2025 | IT/Markets Systems | Update   * according to RDB v0.0.14a * 4.1.5 Common Attributes * 4.2.5 Maintain Underlying * 4.2.6 Maintain Instrument Class * 4.8.6 Maintain Price Limit Parameters * 4.12.1 Maintain Message Template * 4.12.2 Maintain Automatic Event Message * 4.14.1 Maintain Exchange Participant * 4.14.16 Request External EIDP User * 4.15.5 Control Trading Timetable * 4.15.6 Control Trading Pause * 4.15.7 Control Early Close * 4.16.1 Maintain Global Parameters * 4.17.14 Control Settlement Values * 4.17.15 Control Underlying Price * 4.18.4 Request Internal EIDP User |
| 1.0.12 | 30 Dec 2025 | IT/Markets Systems | Update   * 3.1 Data Type * 4.1.5 Common Attribute * 4.2.7 Maintain Instrument * 4.8.13 Control & Monitor VCM * 4.12.2 Maintain Automatic Event Message * 4.14.3 Maintain Direct Drop Copy Session * 4.15.6 Control Trading Pause * 4.15.7 Control Early Close |
| 1.0.13 | 16 Jan 2026 | IT/Markets Systems | Update   * 3.1 Data Type * 4.2.1 Maintain Exchange * 4.2.2 Maintain Market * 4.2.3 Maintain Instrument Group * 4.2.5 Maintain Underlying * 4.4.1 Maintain Auto Generation Rule * 4.4.11 Instrument Generation * 4.5.2 Combo Generation * 4.6.1 Maintain SMP ID * 4.8.16 Control Contingency Trigger of AHT Reference Price Calculation * 4.11.4 Control Daily Market Report (DMR) * 4.14.16 Request External EIDP User * 4.18.4 Request Internal EIDP User |
| 1.0.15 | 23 Jan 2026 | IT/Markets Systems | Update   * 4.1.1 Function Type * 4.15.5 Control Trading Timetable   Delete (Confirmed with DT on 19-Jan-2026)   * 4.15.6 Control Trading Pause * 4.15.7 Control Early Close |
| 1.0.16 | 30 Jan 2026 | IT/Markets Systems | Update   * 3.1 Data Type * 4.4.11 Instrument Generation * 4.5.2 Combo Generation * 4.14.14 Maintain Company * 4.17.15 Control Underlying Price |
| 1.0.17 | 13 Mar 2026 | IT/Markets Systems | Update   * according to RDB v0.0.14c * 3.10.10 Record Dependencies * 4.1.3 Bulk Import from File * 4.1.5 Common Attributes * 4.2 Instrument Hierarchy * 4.2.2 Maintain Market * 4.2.3 Maintain Instrument Group * 4.2.5 Maintain Underlying * 4.2.7 Maintain Instrument * 4.3.4 Maintain Combo * 4.4 Auto Instrument Generation * 4.6.1 Maintain SMP ID * 4.7.3 Control TMC * 4.8.12 Control & Monitor Price Limit * 4.10.1 Maintain Combo Type Error Trade Parameters * 4.10.2 Maintain Instrument Type Error Trade Parameters * 4.11.1 Maintain Report * 4.11.3 Maintain Report Inst. Group List * 4.12.1 Maintain Message Template * 4.12.3 Send Manual Market Announcement * 4.13.1 Control Capital Adjustment * 4.14.9 Maintain Trading Rights * 4.15.5 Control Trading Timetable * 4.16.1 Maintain Global Parameters * 4.17.15 Control Underlying Price |
| 1.0.18 | 20 Mar 2026 | IT/Markets Systems | Add   * 4.11.5 Control Admin Report   Update   * according to RDB v0.0.14d * 4.1.1 Function Type * 4.8.6 Maintain Price Limit Parameters * 4.8.10 Maintain VCM Parameters * 4.8.12 Control & Monitor Price Limit * 4.11.4 Control Daily Market Report (DMR) * 5.4 Maxima Limit |
| 1.0.19 | 25 Mar 2026 | IT/Markets Systems | Update   * 4.1.5 Common Attributes * 4.4.11 Instrument Generation * 4.5.2 Combo Generation * 4.8.12 Control & Monitor Price Limit * 4.8.13 Control & Monitor VCM * 4.12.3 Send Manual Market Announcement * 4.13.1 Control Capital Adjustment * 4.15.5 Control Trading Timetable * 4.18.3 Maintain System Preference |
| 1.0.20 | 27 Mar 2026 | IT/Markets Systems | Update   * 4.1.5 Common Attributes * 4.8.6 Maintain Price Limit Parameters * 4.8.10 Maintain VCM Parameters * 4.8.12 Control & Monitor Price Limit * 4.8.13 Control & Monitor VCM * 4.12.3 Send Manual Market Announcement |
| 1.0.21 | 20 Apr 2026 | IT/Markets Systems | Update   * according to RDB v0.0.15a * 4.1.5 Common Attributes * 4.2.5 Maintain Underlying * 4.2.9 Maintain Access Group By Type * 4.3.2 Maintain Combo Type * 4.3.3 Maintain Combo Class * 4.5.1 Maintain Auto Combo Generation Rule Group * 4.8.12 Control & Monitor Price Limit * 4.14.3 Maintain Drop Copy Session * 4.14.4 Maintain Direct Order Flow Session * 4.14.6 Maintain PTRM GUI User * 4.14.7 Maintain Trading GUI User * 4.16.1 Maintain Global Parameters |
| 1.0.22 | 28 Apr 2026 | IT/Markets Systems | Add   * 5.7 Template   Update   * according to RDB v0.0.15b & c * 4.1.1 Function Type * 4.3.2 Maintain Combo Type * 4.4.1 Maintain Auto Generation Rule * 4.11.1 Maintain Report * 4.13.1 Control Capital Adjustment * 4.14.4 Maintain Direct Order Flow Session * 4.14.7 Maintain Trading GUI User * 4.15.5 Control Trading Timetable * 4.16.1 Maintain Global Parameters * 5.5 Validation Rule |
| 1.0.23 | 29 Apr 2026 | IT/Markets Systems | Update   * 4.1.1 Function Type * 4.5.1 Maintain Auto Combo Generation Rule Group * 4.11.1 Maintain Report * 4.17.14 Control Settlement Values |
| 1.0.25 | 30 Apr 2026 | IT/Markets Systems | Update   * 4.1.1 Function Type * 5.5 Validation Rule |
| 1.0.26 | 19 May 2026 | IT/Markets Systems | Update   * 4.1.1 Function Type * 4.1.5 Common Attributes * 4.3.4 Maintain Combo * 4.7.2 Maintain TMC Strategy * 4.8.16 Control Contingency Trigger of AHT Reference Price Calculation * 4.11.4 Control Daily Market Report (DMR) * 4.11.5 Control Admin Report * 4.14.1 Maintain Exchange Participant * 4.14.3 Maintain Direct Drop Copy Session * 4.14.6 Maintain PTRM GUI User * 4.14.7 Maintain Trading GUI User * 4.14.13 Control Block/Unblock Participant Per Product * 4.14.15 Maintain Self Admin Portal User * 4.14.16 Request External EIDP User * 4.15.5 Control Trading Timetable * 4.18.1 Maintain Exchange User |
| 1.0.27 | 22 May 2026 | IT/Markets Systems | Update:   * according to RDB v0.0.15d & e * 4.1.1 Function Type * 4.2.6 Maintain Instrument Class * 4.4.1 Maintain Auto Generation Rule * 4.4.4 Maintain Regional Holiday Calendar * 4.14.15 Maintain Self Admin Portal User * 4.16.1 Maintain Global Parameters * 5.5 Validation Rule |
| 1.0.28 | 28 May 2026 | IT/Markets Systems | Update:   * according to RDB v0.0.15f * 3.2 Content Assistant * 4.1.5 Common Attributes * 4.14.3 Maintain Direct Drop Copy Session * 4.14.4 Maintain Direct Order Flow Session * 5.5 Validation Rule |
| 1.0.29 | 9 Jun 2026 | IT/Markets Systems | Update:   * according to RDB v0.0.15g, h & i * 4.1.1 Function Type * 4.1.5 Common Attributes * 4.11.1 Maintain Report * 4.14.6 Maintain PTRM GUI User * 4.14.7 Maintain Trading GUI User * 4.14.15 Maintain Self Admin Portal User * 4.14.16 Request External IDP User * 4.18.1 Maintain Exchange User * 4.18.4 Request Internal IDP User * 5.5 Validation Rule |
| 1.0.30 | 18 Jun 2026 | IT/Markets Systems | Update:   * 4.4.2 Maintain Cycle Blocks * 5.5 Validation Rule |
| 1.0.31 | 25 Jun 2026 | IT/Markets Systems | Update:   * according to RDB v0.0.15j * 4.1.4 Change History * 4.2.6 Maintain Instrument Class * 4.2.7 Maintain Instrument * 4.14.10 Maintain Participant User Role * 4.15.2 Maintain Trading State * 4.16.1 Maintain Global Parameters * 4.16.2 Maintain Contingency Switch * 5.5 Validation Rule |
| 1.0.32 | 9 Jul 2026 | IT/Markets Systems | Update:   * according to RDB v0.0.16 and v0.0.16a * 4.1.1 Function Type * 4.1.5 Common Attributes * 4.2.5 Maintain Underlying * 4.2.6 Maintain Instrument Class * 4.2.7 Maintain Instrument * 4.3.3 Maintain Combo Class * 4.6.2 Review SMP Request (PDF form from ECP) * 4.8.6 Maintain Price Limit Parameters * 4.8.13 Control & Monitor VCM * 4.8.16 Control Contingency Trigger of AHT Reference Price Calculation * 4.11.1 Maintain Report * 4.11.3 Maintain Report Group List * 4.11.4 Control Daily Market Report (DMR) * 4.11.5 Control Admin Report * 4.12.3 Send Manual Market Announcement * 4.17.8 Order Flow Client Enquiry * 4.17.9 Drop Copy Client Enquiry * 4.17.10 Control & Monitor Order Flow Client * 4.17.11 Control & Monitor Drop Copy Client * 4.17.12 Control & Monitor Trading GUI Client * 4.17.13 Control & Monitor PTRM GUI Client * 5.5 Validation Rule |
| 1.0.33 | 16 Jul 2026 | IT/Markets Systems | Update:   * 3.15.2 Detail Screen * 4.1.1 Function Type * 4.11.3 Maintain Report Group List * 5.5 Validation Rule |
| 1.0.35 | 24 Jul 2026 | IT/Markets Systems | Add:   * 4.8.17 Control Contingency Trigger of Combo Class Price Tick Limit Calculation   Update:   * 3.15.1 Search Screen * 3.15.2 Detail Screen * 4.1.5 Common Attributes * 4.8.15 Control Contingency Trigger of Inst. Class Price Tick Limit Calculation * 4.11.4 Control Daily Market Report (DMR) * 4.17.10 Control & Monitor Order Flow Client * 4.17.12 Control & Monitor Trading GUI Client * 5.5 Validation Rule |

## Document Cross-referenced

|  |  |  |
| --- | --- | --- |
| # | Document | Version |
| 1 | 0050 BRS\_PDMPA functions in ODP | v1.4 2025 02 13 |
| 2 | FS10001 – Trading Timetable | IT20260109 |
| 3 | FS10004 – Price Supervision | 2026404 |
| 4 | FS10006 – Block Trade | 20260608 |
| 5 | FS10007 – Self Match Prevention | 20260618 |
| 6 | FS10008 – Market Maker Protection | IT20260109 |
| 7 | FS10010 – Product Structure | 20260112 |
| 8 | FS10011 – Participant Structure | IT20260615 |
| 9 | FS10017A – Reports Generation for Dynamic Data and Processing | IT250618 |
| 10 | FS10017B – Reports Generation for Static Data and Processing | IT250318 |
| 11 | FS10019 – Market Message | v1.4 20260130 |
| 12 | FS10023 – Instrument and Combo Generation | 20250617 |

## Abbreviation

|  |  |
| --- | --- |
| AHT | After Hours Trading |
| CA | Capital Adjustment |
| COP | Calculated Opening Price |
| EP | Exchange Participant |
| GTC | Good Till Cancel |
| GTD | Good Till Date |
| ID | Identifier |
| ISO | International Organization for Standardization |
| MAP | Market Admin Proxy, aka MAA (Market Admin Adaptor) |
| MMP | Market Maker Protection |
| MVT | Minimum Volume Thresholds |
| ODP-T | Orion Derivatives Platform – Trading |
| OLS | Order Logging Server |
| TMC | Tailor Made Combo |
| VCM | Volatility Control Mechanism |

## Distribution List

|  |  |  |
| --- | --- | --- |
| # | Name | Role |
|  |  |  |
|  |  |  |

# Introduction

**#FS10013\_S0200\_00100**

The section provides an overview of the OTP-D Market Operations Graphical User Interface (also referred to as System Admin GUI) for HKEX internal.

**#FS10013\_S0200\_00200**

The System Admin GUI is a web-interface based application, which facilitates all Product, Participant and Trading functionality configuration and management of market operations activities.

# Screen Design

## Data Type

**#FS10013\_S0301\_00109**

The table below describes the internal Data Type used in the definition of logical entity attributes in the Data Dctionary.

| # | Data Type | Length | Description |
| --- | --- | --- | --- |
|  | Char | 1 | One character input and the following are allowed:   * A-Z * a-z * 0-9 * &~#$%^()\_+-=[]\{};:,./ * Space |
|  | Boolean | 1 | Y – Yes/True or N – No/False |
|  | Numeric | As defined | Any digit from 0 to 9, the following length are allowed:   * 3, possible value from 0 to 254 (255 = Null) * 4, possible value from -127 to 127 (-128 = Null) * 5, possible value from 0 to 65534 (65535 = Null) * 6, possible value from -32767 to 32767 (-32768 = Null) * 10, possible value from 0 to 232 - 2 (232 - 1= Null) * 11, possible value from -231 + 1to 231 - 1 (-231 = Null) * 20, possible value from 0 to 264 – 2 (264- 1 = Null) * 20, possible value from - 263 + 1 to 263 - 1 (-263 = Null) |
|  | Alphanumeric | As defined | Multiple characters input and the following are allowed:   * A-Z * a-z * 0-9 * &~#$%^()\_+-=[]\{};:,./ * Space   Remarks: ID field will support:   * A-Z * 0-9 * ./\_   Remarks: Input of all ID fields, all Code fields, Short Name field, Name field will convert to Upper Cases by system automatically by default. |
|  | Decimal | As defined | Any digit from 0 to 9.  With implicit decimals, the number of decimal places is separately and explicitly defined.  For example, if the size 5 and number of decimal places applicable to this field is 2 then the value can be 999.99.  Range of value is from 0 to 999,999,999,999,999,999. |
|  | Price | 19  (Additionally, plus 1 if include “- “or “.”) | Any digit from 0 to 9, “- “and “.”  Signed number and support up to 6 decimal places by default and configurable per instrument type/class  It should consider decimal place setup by product class level for display purpose and input validation. It can be 0 – 6 decimal places, for example HIS shows 18000 without decimal place  Minimum value = -9,223,372,036,854,775,807  Maximum value = 9,223,372,036,854,775,807 |
|  | Quantity | 9 | Any digit from 0 to 9.  Range of value is from 0 to 999,999,999. |
|  | Percentage | 9 | Any digit from 0 to 9.  Support up to 4 decimal places, depends on function |
|  | Date | 11 | In universal time (UTC) and UI displays as DD-MMM-YYYY format |
|  | Time | 8 | In universal time (UTC) and UI displays as HH:MM:SS format |

**#FS10013\_S0301\_00200**

Note the following:

1. Local Hong Kong time is used and displayed to client, while communication between Server and GUI is in Coordinated Universal Time (UTC) time
2. For Price and Percentage, size and number of decimal places are implicit
3. In the user interface, data conversion will be done on behalf of the user. For example:

**Decimal (Explicit Decimal Places)**

A1. User types in Call Price – 1.23, it is converted into “Call Price” – 123 & “Decimals in Call Price” – 2 and sent to the backend.

A2. User types in Call Price – 1.234567980123, it is not allowed in the UI and is rejected.

A3. User types in Call Price – 123456798012345678.9, it is not allowed in the UI and is rejected.

**Percentage (Max 4 decimal places)**

B1. User types in IOMP Tolerance % - 4.56, it is converted into “IOMP Tolerance %” – 45600 and sent to the backend. During screen enquiry or report generation, it will show “4.5600”.

B2. User types in IOMP Tolerance % - 4.56890123, it is not allowed in the UI and is rejected.

B3. User types in IOMP Tolerance % - 45689012.3, it is not allowed in the UI and is rejected.

B4. User enters 99.9 to represent 99.9% for IOMP Tolerance %.

B5. User enters 999 to represent 999% for IOMP Tolerance %.

**Price (Max 6 decimal places)**

C1. User types in Minimum Price – 3.45, it is converted into “Minimum Price” – 3450000 and sent to the backend. During screen enquiry / report generation, it will show “3.450000”.

C2. User types in Minimum Price – 3.45234234, it is not allowed in the UI and is rejected.

C3. User types in Minimum Price – 345234123234567890.1, it is not allowed in the UI and is rejected.

### UI Widget Mapping by Data Type

**#FS10013\_S0301\_00300**

The following session list out the general mapping of Data Type and UI Widget for display and update purpose, however they can be different in some specific functions which the user requirement may require a special display behaviour.

| # | Data Type | UI Widget | Description |
| --- | --- | --- | --- |
|  | Char | Text Input | Simple input text field to allow single character |
|  | Boolean | Dropdown | Either dropdown (Default) or checkbox or radio button to support the following:  Y – Yes/True or N – No/False |
|  | Numeric | Text Input | Simple input text field to allow any digit from 0 to 9 |
|  | Alphanumeric | Text Input | Simple input text field to allow multiple character(s). |
|  | Decimal | Text Input | Simple input text field to allow any digit from 0 to 9.  With implicit decimals, the number of decimal places is separately and explicitly defined.  For example, if the size 5 and number of decimal places applicable to this field is 2 then the value can be 999.99.  Range of value is from 0 to 999,999,999,999,999,999. |
|  | Price | Spinner | An input text field with an upward and a downward arrow button and shows the next value when it is pressed. The next value is configurable, it can be based on a pre-defined delta portion.  This input text field allows any digit from 0 to 9.  Signed number and support up to 6 decimal places. |
|  | Quantity | Spinner or Text Input | Simple input text field to allow any digit from 0 to 9.  Range of value is from 0 to 999,999,999. |
|  | Percentage | Text Input | Simple input text field to allow any digit from 0 to 9.  With implicit decimals, the number of decimal places is separately and explicitly defined.  For example, if the size 5 and number of decimal places applicable to this field is 2 then the value can be 999.99.  Support up to 4 decimal places |
|  | Date | Date selection Drop Down or  Text Input (Read-only) | Simple input text field to display date formatted value. (Default as DD-MMM-YYYY) And it is allowed to select date value in drop down |
|  | Time | Time Selection Drop Down or  Text Input (Read-only) | Simple input text field to display time formatted value. (Default as HH:MM:SS) And it is allowed to select time value in drop down.  For read-only display field, it can be supported up to 9 nano-of-second (e.g. HH:MM:SS.nnnnnnnnn) if needed based on requirement and GUI shows HH:MM:SS as default |

## Content Assistant

**#FS10013\_S0302\_00101**

Content assist is used to list out those matched values based on a partially entered text from input box. It performs an implicit query to backend server and displays the corresponding result into a dropdown menu (but limited to 10 items at a time). User can either select the desired value or navigate around these values by mouse or arrow up/down key.

Entered text followed by question mark (?) matches zero or one occurrence in the result. And entered text followed by star (\*) matches zero or more occurrence. Placing an exclamation mark (!) before the text indicates that the specified pattern must not be matched. Additionally, separating entries with a comma (,) denotes the next target value to be matched.

By default it lists out all **Pending**, **Approved** and **Active** items of the system without considering user permission, backend processes take the responsibility to perform the validation. But it depends on that requirement of each screen, listed items could be adjusted.

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

## Application Layout

**#FS10013\_S0303\_00100**

The following session describe the application layout of Trading UI which consists of 4 major components: Header Bar, Side Bar, Footer Bar and Content Area.

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

4

3

2

1

| Callout | Remarks |
| --- | --- |
| 1 | Header bar displays the application name, user profile menu and Workspace Menu. User can select available workspace in Workspace Menu and select available user actions in user profile menu. |
| 2 | Side bar displays the available function of current user in a system workspace, corresponding function is opened in Content Area after clicking on a menu item. |
| 3 | Footer bar displays the copyright information, privacy policy, disclaimer and help to user |
| 4 | Content area displays those opened function to user |

## GUI Notification

**#FS10013\_S0304\_00100**

The purpose of GUI Notification is to give/ask for a feedback or show status update to user after an event happened.

Depending on the nature of a notification, important notification message is logged into the system internally while low priority message as well as a in progress notification message or etc, they are not persisted and cannot be recovered to GUI.

**#FS10013\_S0304\_00200**

The following describes various type of notification message in Admin GUI:

**System Notification** shows at the top of Content Area

![](data:image/png;base64...)

**User Notification** shows at the bottom of Content Area

![](data:image/png;base64...)

**View Notification** shows notification message at the bottom of a targeted function view. Several notification levels are available to notify user for different purpose.

Information notification message

![A blue rectangular object with a white border  Description automatically generated](data:image/png;base64...)

Confirmation notification message

![A blue rectangular object with a white border  Description automatically generated](data:image/png;base64...)

Progress notification message

![A close-up of a blue box  Description automatically generated](data:image/png;base64...)

Warning notification message

![A yellow rectangular object with a white border  Description automatically generated](data:image/png;base64...)

Success notification message

![A close-up of a blue rectangle  Description automatically generated](data:image/png;base64...)

Error notification message

![A pink rectangular object with a white border  Description automatically generated](data:image/png;base64...)

## User Workspace

**#FS10013\_S0305\_00100**

Internal user can only manage the colour theme and font size in the application, and these setting persist into user profile individually. And user has a flexibility to decide if he/she wants to save this information during user logout.

## Record Status

**#FS10013\_S0306\_00101**

There are seven record status available in the system as follow:

| **#** | **Record Status** | **Description** |
| --- | --- | --- |
|  | New | Newly create record before submitting for approval.  (Only available in the Request Record Card in the Detail Page during data input.) |
|  | Pending | Newly create record in pending state. |
|  | Approved | Record is approved and it will become effective based on the target effective date or time. |
|  | Active | Record is effective in the system. |

The record status can be found in the Search Page and Detail Page. Here is the illustration of the record status under different cases:

* + 1. Case 1 – No Planned Changes

**#FS10013\_S0306\_00200**

This section includes the scenarios when there are no planned changes.

**Search Page**

**#FS10013\_S0306\_00301**

In the search page, the current image’s record status is shown in the **Status** column. The record status should be either **Active**. And the Change Request Indicator is **No Plan**.

![](data:image/png;base64...)

**Detail Page**

**#FS10013\_S0306\_00401**

In the detail page, the Current Record’s status should be either **Active** or **Deleted**.

And the Request Record’s status is **No Plan**.

| **#** | **Scenario** | **Status of Current Record** | **Status of Request Record** |
| --- | --- | --- | --- |
| 1 | Active record without any planned change. | Active | No Plan |

* + 1. Case 2 – Add New Record

**#FS10013\_S0306\_00500**

This section includes the scenarios related to Add New Record action.

When adding new record, there is no active record available in the system, so the display in Search Page and Detail Page is a bit different.

**Search Page**

**#FS10013\_S0306\_00601**

As the Current Record doesn’t exist in the system, so the Search Page will display the content of Request Record instead of the Current Record. And the **Status** column reflects the record status of the Request Record.

At the same time, the Change Request Indicator show the status of the planned change.

Once the request had been approved and effective, Current Record’s status will be displayed in the **Status** column. And Change Request Indicator will become **No Plan**.

If there is any failure during Approve/Reject, the Change Request Indicator will become **Failed**.

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

**Detail Page**

**#FS10013\_S0306\_00701**

As the current record doesn’t exist in the system, so the Current Record’s status is **No Record**. And the Request Record’s status will be updated throughout the Approval process.

Once the new record had been approved and effective, the Current Record’s status will become **Active** and Request Record’s status will become **No Plan**.

| **#** | **Scenario** | **Status of Current Record** | **Status of Request Record** |
| --- | --- | --- | --- |
| 1 | Inputting a new record but haven’t submitted for approval yet.  *(This scenario is only applicable to Detail Page)* | No Record | New |
| 2 | New record pending for approval. | No Record | Pending |
| 3 | New record had been approved but not effective yet. | No Record | Approved |
| 4 | New record request is approved and effective. | Active | No Plan |
| 5 | New record had been rejected by Approver.  *(The record will be removed once it’s rejected by Approver)* | N/A | N/A |
| 6 | New record request failed to Approve/Reject. | No Record | Failed 1 |
| 7 | New record *(Approved but not effective yet)* with a Withdraw request pending for approval. | No Record | Approved |
| 8 | New record with a withdraw request approved.  *(The record will be removed once it’s withdraw request is approved by Approver)* | N/A | N/A |
| 9 | New record with a withdraw request rejected.  *(Before the new record is effective.)* | No Record | Approved |
| 10 | New record with a withdraw request failed to Approve/Reject. | No Record | Failed 2 |

Remark 1: If a new record request is failed to approve/reject, there will be no change to the system. Users can retry the approve/reject again if necessary.

Remark 2: If the withdraw request failed to approve, the corresponding to-be-withdraw approved change will remain in the system. Users can retry to approve again if necessary.

* + 1. Case 3 – Update record

**#FS10013\_S0306\_00800**

This section includes the scenarios related to Update Record action.

As update should be performed on an Active record, so the Current Image should be always Active.

**Search Page**

**#FS10013\_S0306\_00901**

In the search page, the Current Record’s record status is shown in the **Status** column. As update can be performed on Active record only, so the Status column should remain **Active**.

At the same time, the Change Request Indicator reflects the status of the planned change.

Once the new record had been approved and effective, the Change Request Indicator will be displayed as **No Plan**.

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

**Detail Page**

**#FS10013\_S0306\_01000**

In the detail page, as update can be performed on Active record only, so Current Record’s status should remain “Active”.

And the Request Record’s will be updated throughout the Approval process.

Once the new record had been approved and effective, the Request Record’s status will become **No Plan**.

**#FS10013\_S0306\_01101**

| **#** | **Scenario** | **Status of Current Record** | **Status of Request Record** |
| --- | --- | --- | --- |
| 1 | Inputting an update of an Active record but haven’t submitted for approval yet.  *(This scenario is only applicable to Detail Page)* | Active | New |
| 2 | Active record with an update pending for approval. | Active | Pending |
| 3 | Active record with an approved update but not effective yet. | Active | Approved |
| 4 | Update record request is approved and effective. | Active | No Plan |
| 5 | Update request rejected by Approver.  *(Record had been restored once the change is rejected by Approver)* | Active | No Plan |
| 6 | Active record with an update request failed to Approve/Reject. | Active | Failed 1 |
| 7 | Active record with a Withdraw request *(on an approved but update is not effective yet)* pending for approval. | Active | Approved |
| 8 | Update request had been withdrawn.  *(Record had been restored once the withdraw request is approved by Approver)* | Active | No Plan |
| 9 | Active record with a withdraw request rejected.  *(Before the update is effective.)* | Active | Approved |
| 10 | Active record with a withdraw request failed to Approve/Reject. | Active | Failed 2 |

Remark 1: If an update record request is failed to approve/reject, there will be no change to the system. Users can retry the approve/reject again if necessary.

Remark 2: If the withdraw request failed to approve, the corresponding to-be-withdraw approved change will remain in the system. Users can retry to approve again if necessary.

* + 1. Case 4 – Delete Record

**#FS10013\_S0306\_01200**

This section includes the scenarios related to Delete Record action.

As delete should be performed on an Active record, so the Current Image should remain **Active** until the request had been approved and effective.

**Search Page**

**#FS10013\_S0306\_01301**

In the search page, the current image’s record status is shown in the **Status** column. As update can be performed on Active record only, so the Status column should remain **Active** until the request had been approved and effective.

At the same time, the Change Request Indicator reflects the status of the planned change.

Once the request had been approved and effective, the Change Request Indicator will be displayed as **No Plan** and the Status will become **Deleted**.

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

**Detail Page**

**#FS10013\_S0306\_01401**

In the detail page, as update can be performed on Active record only, so Current Record’s status should remain **Active** until the request had been approved and effective.

And the Request Record’s will be updated throughout the Approval process.

Once the new record had been approved and effective, the Request Record will be displayed as **No Plan** and Current Record will become **Deleted**.

| **#** | **Scenario** | **Status of Current Record** | **Status of Request Record** |
| --- | --- | --- | --- |
| 1 | Scheduling a delete of an Active record but haven’t submitted for approval yet.  *(This scenario is only applicable to Detail Page)* | Active | New |
| 2 | Active record with a delete pending for approval. | Active | Pending |
| 3 | Active record with an approved delete request but not effective yet. | Active | Approved |
| 4 | Delete record request is approved and effective.  *(Record will be delete immediately once it’s approved by Approver)* | N/A | N/A |
| 5 | Delete request rejected by Approver.  *(Record had been restored once the delete request is rejected by Approver)* | Active | No Plan |
| 6 | Active record with a delete request failed to Approve/Reject. | Active | Failed 1 |
| 7 | Active record with a withdraw request *(on an approved but deletion is not effective yet)* pending for approval. | Active | Approved |
| 8 | Delete request had been withdrawn.  *(Record had been restored once the withdraw request is approved by Approver)* | Active | No Plan |
| 9 | Active record with a withdraw request rejected.  *(Before the deletion is effective.)* | Active | Approved |
| 10 | Active record with a withdraw request failed to Approve/Reject. | Active | Failed 2 |

Remark 1: If a delete record request is failed to approve/reject, there will be no change to the system. Users can retry the approve/reject again if necessary.

Remark 2: If the withdraw request failed to approve, the corresponding to-be-withdraw approved change will remain in the system. Users can retry to approve again if necessary.

* 1. Type of Functions

**#FS10013\_S0307\_00100**
There are three types of UI functions in Admin GUI as follows:

### Permanent Function

**#FS10013\_S0307\_00200**

Permanent function represents a change request of a function which could be effective as soon as possible, effective at a scheduled time of today or effective in tomorrow, these data are stored in a separate Admin Database and Trading Database.

Approved update to the database is persisted to both Admin Database and Trading Database if it is effective as soon as possible / from today and remain effective till further update in future.

On the other hand, approved update is persisted into Admin Database only if it is effective from tomorrow and remain effective till further update in future. System housekeeping jobs at the end of day prepare essential reference data and administrative data to Trading Database based upon the Admin Database.

And approved update can be withdrawn before effective via a new change request. If the approved update is already effective, it will no longer allowed to withdraw.

* + 1. Temporary Function

**#FS10013\_S0307\_00300**
Temporary function represents a change request of a function which could be effective as soon as possible, it is effective and accessible in the Trading Database after approved.

Those changes are reverted to their original values (or overwritten) in the Administration Database at the end of day through the batch processing / housekeeping.

### Exchange User Function

**#FS10013\_S0307\_00400**

Through Exchange User Functions, Market Operation users can apply updates to the Admin User Database. Changes on the exchange user and user roles are applied & persisted as soon as possible once the changes are approved. Data is stored in the Admin User Database.

Apart from data related functions, Market Operation users may also make use of Exchange User function to disseminate notification to the Market, approve a change request or etc.

### Common Utility of function

**#FS10013\_S0307\_00500**

| **#** | **Name** | **Description** |
| --- | --- | --- |
| 1 | Export Data | Provide export data to csv file from table |
| 2 | Import Data | Provide import csv file to table |
| 3 | Copy Detail | Provide copy record detail to Clipboard |
| 4 | Search Filter | User can narrow down search result by selecting pre-defined filter criteria and value |

## Request Status

**#FS10013\_S0308\_00100**

Whenever a change in the system requires 4-eye Change Confirmation, an countersign request will be created.

The status of the countersign request can be transit as below:

![A diagram of a process  Description automatically generated](data:image/png;base64...)

**#FS10013\_S0308\_00201**

| **#** | **Request Status** | **Description** |
| --- | --- | --- |
| 1 | Pending | When Requester submit the change for approval, the request will become PENDING status. |
| 2 | Approved | Once the request had been approved by Approver, it will become APPROVED. |
| 3 | Rejected | If the request had been rejected by Approver, it will become REJECTED. |
| 4 | Failed | If the Approver tries to approve/reject the request, but the execution failed due to error, the request will become FAILED. |

## Request Action

**#FS10013\_S0309\_00100**

The following actions are available to change the records in the system.

| **#** | **Request Action** | **Description** |
| --- | --- | --- |
| 1 | Add | This action is to create new records into the system.  Requester can request an “Add” action by clicking the New Record button in the Search pages.  **Applies to Maintain functions.** |
| 2 | Update | This action is to update the attribute of an existing record in the system.  It can be performed on Active records only.  Requester can request a “Update” action by scheduling a change on an active current record in the Detail pages.  **Applies to Maintain functions.** |
| 3 | Delete | This action is to delete an existing record from the system.  It can be performed on Active records only.  Requester can request a “Delete” action by scheduling a delete on an active current record in the Detail pages.  **Applies to Maintain functions.** |
| 4 | Withdraw | This action is to withdraw an approved change.  Approved changes can be withdrawn only when they’re not effective yet.  Users with “Write” permission are allowed to withdraw an approved change.  **Applies to Maintain functions.** |
| 5 | Execute | This action is to execute a control request. E.g. Send Market Message, trigger Trading Time table to next state and etc  **Applies to Control functions.** |

The availability of Request Action depends on user’s permission and the nature of the functions.

## Current Record and Request Record

**#FS10013\_S0310\_00101**

In the Record Detail Screen, there are two cards at the top of the screen. They represent the Current effective image and the Change Request image of this record respectively.

The Current Record in the left-hand side represents the record that is currently effective in the System.

The Request Record in the right-hand side represents the change request of the record. Including a request which is pending approval / approved, etc.

User can toggle between Current and Request Record by clicking on the cards. And the content of the Record Detail Screen will be refreshed accordingly.

![A screenshot of a phone  Description automatically generated](data:image/png;base64...)

* + 1. Current Record

**#FS10013\_S0310\_00200**

The Current Record represents the record that is currently effective in the System.

Changes with Update as soon as possible or Update by scheduled time will be reflected in Current Record once it’s approved and effective.

A Current Record card contains the following information:

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

**#FS10013\_S0310\_00301**

| **#** | **Field** | **Description** |
| --- | --- | --- |
| **Card Header** | | |
| 1 | Title | Current Record. Indicate that it’s representing the current record that is currently effective in the system. |
| 2 | Status | Status of the Current Record.  **No plan –** There is no current record in the system.  **Active –** The current record is active. |
| 3 | Menu | Menu includes the choices for requesting a change.  For detail, please refer to “**Request a Change**” section.  The menu will be enabled only if   1. Current Record is in **Active** status and Request Record is in **No plan** status. 2. And, User have Write Permission.   If the menu is disabled, the Menu will mark as grey and no popup menu available. |
| **Card Body** | | |
| 4 | Approved by | The approver who approved the change of the current record. |
| 5 | Last updated date | Last update date of the current record. |
| 6 | Effective date | The effective date of the record. |
| 7 | Effective until | The effective end date of the record.  For permanent records, Effective until is **Forever**.  For temporary records, the Effective until should be today. And there will be an icon “![](data:image/png;base64...)” to indicate that the record will be effective **Today only**. |

* + 1. Create a New Record

**#FS10013\_S0310\_00400**

User with write permission can create/clone a new record by selecting the desired request type from the menu of the Search Page.

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

These are the possible types of requests for Permanent Functions:

**#FS10013\_S0310\_00500**

| **#** | **Request Type** | **Description** |
| --- | --- | --- |
| 1 | New record for Tomorrow | Request to create a new record to be effective from Tomorrow. |
| 2 | New record for as soon as possible | Request to create a new record and effective as soon as possible. |
| 3 | New record for scheduled today | Request to create a new record to be effective from a specific time Today. |
| 4 | Clone record for Tomorrow | Request to create a new record by clone from an existing record and effective since Tomorrow. |
| 5 | Clone record for as soon as possible | Request to create a new record by clone from an existing record and effective as soon as possible. |
| 6 | Clone record for scheduled today | Request to create a new record by clone from an existing record and effective since a specific time Today. |

These are the possible types of requests for Temporary Functions:

**#FS10013\_S0310\_00600**

| **#** | **Request Type** | **Description** |
| --- | --- | --- |
| 1 | New Record | Request to create a new record and effective as soon as possible. |
| 2 | Clone Record | Request to create a new record by clone from an existing record and effective as soon as possible. |

* + 1. Request a Change

**#FS10013\_S0310\_00700**

User with write permission can schedule a change by selecting the desired request type from the menu of the Current Record. Changes can be requested on Active records only. No changes are allowed on Deleted records.

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

These are the possible types of requests for Permanent Functions:

**#FS10013\_S0310\_00800**

| **#** | **Request Type** | **Description** |
| --- | --- | --- |
| 1 | Update for Tomorrow | Request an update to be effective since Tomorrow. |
| 2 | Update for as soon as possible | Request an update and effective as soon as possible. |
| 3 | Update for scheduled today | Request an update to be effective since a specific time Today. |
| 4 | Delete for Tomorrow | Request a deletion to be effective since Tomorrow. |
| 5 | Delete for as soon as possible | Request a deletion and effective as soon as possible. |

These are the possible types of requests for Temporary Functions:

**#FS10013\_S0310\_00900**

| **#** | **Request Type** | **Description** |
| --- | --- | --- |
| 1 | Update for as soon as possible | Request an update and effective as soon as possible. |
| 2 | Delete for as soon as possible | Request a deletion and effective as soon as possible. |

If the record already has a change request pending for approval or approved but not effective yet, then the system will prohibit user from requesting another change.

The menu at Current Record Card will be disabled.

![A screenshot of a screenshot of a phone  Description automatically generated](data:image/png;base64...)

Users should reject the pending change request or withdraw the approved change before submitting another change.

* + 1. Change Request Indicator

**#FS10013\_S0310\_01000**

In the Search Screen of each function, there is a column indicate whether the record has any planned change.

Here is the possible value of the indicator:

**#FS10013\_S0310\_01101**

| **#** | **Change Request Indicator** | **Description** |
| --- | --- | --- |
| 1 | ![](data:image/png;base64...) | There are no planned changes. |
| 2 | ![](data:image/png;base64...) | There is a change pending Approver’s approval.  Or a withdraw request pending Approver’s approval. |
| 3 | ![](data:image/png;base64...) | There is an approved change. But it’s not effective yet. |
| 4 | ![](data:image/png;base64...) | There is a withdraw request rejected by Approver.  Or the change/withdraw request failed to approve/reject. |

* + 1. Amend a Change Request

**#FS10013\_S0310\_01200**

**Reject a Pending change**

**#FS10013\_S0310\_01301**

To amend a pending change, Requester or Approver should reject the pending change in the **Countersign Request Search/Detail Screen** and resubmit a new change for approval.

**Withdraw an Approved but not effective change**

**#FS10013\_S0310\_01402**

To amend a planned change (approved but not effective yet), User should submit a withdraw request to withdraw the planned change. Once the withdraw request is approved, then users can resubmit the change request for approval again.

The withdraw request can be initiated from an approved request as below:

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

It can only be triggered on a request which is approved but not yet effective yet. For example, a change scheduled to be effective tomorrow, or a change scheduled to be effective later today.

Users can also submit the withdraw request via Search Pages (Including Countersign Request Search Page). They can select one or more approved records in Search Pages and submit withdraw request in one click.

Once the withdraw request is approved, the record will be restored with the content before change.

* + 1. Request Record

**#FS10013\_S0310\_01500**

When SOD, Request Record and Current Record are identical. And the status of Request Record is **No Plan**.

Once a change request is submitted, the change will be reflected in the Request Record.

A Request Record card contains the following information:

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

**#FS10013\_S0310\_01601**

| **#** | **Field** | **Description** |
| --- | --- | --- |
| **Card Header** | | |
| 1 | Title | Indicate the Request Action.  **New Record** – Add a new record.  **Update Record** – Update an existing record.  **Delete Record** – Delete an existing record. |
| 2 | Status | Status of the request Record.  **No Plan** – No planned change.  **New** – Input of new change.  **Pending** – Request is pending for approval.  **Approved** – *(If approval required)* Request had been approved by Approver but not effective yet. *(If approval is not required)*Request had been accepted by system but not effective yet. |
| ~~3~~ | ~~Menu~~ | ~~Menu includes the choices for clone and edit a Rejected/Withdrawn changes.~~  ~~For detail, please refer to “~~**~~Resubmit a Rejected / Withdrawn Change Request~~**~~” section.~~ |
| **Card Body** | | |
| 4 | Updated by  Approved by  Rejected by | This field will be updated according to the status of the Request Record.  **New / Pending status:**  This field will be displayed as **Updated by**. Indicate the user who made/submitted the request.  **Approved status:**  This field will be displayed as **Approved by.** Indicate the user who approved the change request. |
| 5 | Last updated date | Last update date of the request record. This field will be updated whenever there is change to the status of the record. |
| 6 | Effective date | Effective Date Time of the request.  If the request is to execute as soon as possible, the effective date will be today.  If the request is to execute at a schedule time, the effective date will be a specific time today with “DD-MMM-YYYY HH:MM:SS” format.  If the request is to executed at tomorrow, the effective date will be tomorrow. |
| 7 | Effective until | The effective end date of the record.  For permanent records, Effective until is **Forever**.  For temporary records, the Effective until should be today with “DD-MMM-YYYY” format. |

And the status of the Request Record should transit according to the following Matrix.

**#FS10013\_S0310\_01701**

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
| To  From | No Plan | New | Pending | Approved |
| No Plan |  | Requester start to request for a new change.  *(Before Submit)* |  |  |
| New |  |  | Requester submitted the change for approval. |  |
| Pending | Approver rejected the change. |  |  | Approver approved the change. |
| Approved | The approved change is effective.  Or  The approved change had been withdrawn. |  |  |  |

**#FS10013\_S0310\_01800**

Users can click on the Current Record Card / Request Record Card to view the content before and after the change. When Users click on the Request Record Card, the changed value will be highlighted for easy reference.

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

* + 1. [Revoked] ~~Resubmit a Rejected / Withdrawn Change Request~~

**~~#FS10013\_S0310\_019010~~**

As confirmed with DT, once a change had been Rejected / Withdrawn, the corresponding record will be restored back to the original content. It’s used to prevent the problem that a unique value being occupied by rejected/withdrawn records.

As a result, the feature mentioned in this section is no longer valid.

~~If a change request had been rejected or withdrawn, requester can clone the request record for resubmission by selecting Clone and Edit in the menu of the Request Record Card.~~

~~![A screenshot of a message  Description automatically generated](data:image/png;base64...)~~

~~It will start a new change based on the values inside the Rejected/Withdrawn change request. Requester can amend the values as required and submit the change for approval again.~~

~~These are the possible types of request for Permanent Functions:~~

**~~#FS10013\_S0310\_02000~~**

| **~~#~~** | **~~Request Type~~** | **~~Description~~** |
| --- | --- | --- |
|  | ~~Clone and edit for Tomorrow~~ | ~~Clone the change and target to effective since tomorrow.~~ |
|  | ~~Clone and edit for as soon as possible~~ | ~~Clone the change and target to effective as soon as possible.~~ |
|  | ~~Clone and edit for scheduled today~~ | ~~Clone the change and target to effective since a specific time Today.~~ |

~~These are the possible types of request for Temporary Functions:~~

**~~#FS10013\_S0310\_02100~~**

| **~~#~~** | **~~Request Type~~** | **~~Description~~** |
| --- | --- | --- |
|  | ~~Clone and edit for as soon as possible~~ | ~~Clone the change and target to effective as soon as possible.~~ |

~~Note that only applicable to changes with Action Type equals to~~ **~~Add~~** ~~or~~ **~~Update~~**~~.~~

* + 1. Effective Date of the Change Request (Permanent Functions)

**#FS10013\_S0310\_02200**

For Permanent Functions, once the change is effective, it will remain effective till further update in the future. These are the effective dates according to the type of the request.

**Effective as soon as possible**

**#FS10013\_S0310\_02300**

Once Requester submitted the change to system and Approver had approved the change (if approval is required), the change will be effective as soon as possible and remain effective till further update in future.

This behaviour applies to the following schedule type:

1. New record for as soon as possible
2. Update for as soon as possible
3. Delete for as soon as possible

**Effective from today**

**#FS10013\_S0310\_02400**

Once Requester submitted the change to system and Approver had approved the change (if approval is required), the change will be scheduled in the system at a specific time within today. It will be effective once the scheduled time reached and remain effective till further update in future.

This behaviour applies to the following schedule type:

1. New record for scheduled today
2. Update for scheduled today

**Effective tomorrow**

**#FS10013\_S0310\_02500**

Once Requester submitted the change to system and Approver had approved the change (if approval is required), the change will be scheduled in the system. It will be effective since the SOD of the next trading date and remain effective till further update in future.

This behaviour applies to the following schedule type:

1. New record for tomorrow
2. Update for tomorrow
3. Delete for tomorrow
   * 1. Effective Date of the Change Request (Temporary Functions)

**#FS10013\_S0310\_02600**

For Temporary Functions, only as soon as possible changes are allowed. The changes are only effective today and remain effective till EOD. It will be reverted in next trading date.

**Effective as soon as possible**

**#FS10013\_S0310\_02700**

Once Requester submitted the change to system and Approver had approved the change (if approval is required), the change will be effective as soon as possible and remain effective till EOD.

1. New record
2. Update for as soon as possible
3. Delete for as soon as possible
   * 1. Record Dependencies

**#FS10013\_S0310\_02800**

In some scenarios, one record can have dependencies with other records. There will be restrictions on the action could be performed on the records based on the status of the Parent/Child Records.

**New Record (Submit)**

**#FS10013\_S0310\_02902**

The New Record Request of **Child Record** can reference the **Parent Record** or not is depending on the status of the **Parent Record**.

| **Record Status of Parent Record** | **Record Status of Child Record** | **Action** | **Allow** | **Reason** |
| --- | --- | --- | --- | --- |
| Pending |  | New *Child* | Yes | The Parent Record’s status is allowed to select in Child Record’s detail page.  **\* Only when the effective time of Parent Record is before the effective time the new Child Record.** |
| Approved |  | New *Child* | Yes | The Parent Record’s status is allowed to select in Child Record’s detail page.  **\* Only when the effective time of Parent Record is before the effective time the new Child Record.** |
| Approved  *(Pending Withdraw)* |  | New *Child* | Yes | The Parent Record’s status is allowed to select in Child Record’s detail page. |
| Active |  | New *Child* | Yes | The Parent Record’s status is allowed to select in Child Record’s detail page. |
| Active *(Pending Delete)* |  | New *Child* | Yes | As there is the Delete request in Parent Record is still in pending status only. |
| Active  *(Approved Delete)* |  | New *Child* | **No** | As there is an approved Delete request in Parent Record. |

**New Record (Approve/Reject)**

**#FS10013\_S0310\_03001**

The Approve/Reject of New Record Request is depending on the status of the **Parent Record** and **Child Record**.

| **Record Status of Parent Record** | **Record Status of Child Record** | **Action** | **Allow** | **Reason** |
| --- | --- | --- | --- | --- |
| Pending | Pending | Approve *Parent* | Yes | No conflict with Child Record. |
| Pending | Pending | Reject *Parent* | **No** | As there is a pending create Child Record depends on this Parent record. |
| Pending | Pending | Approve *Child* | **No** | As the Parent Record is not approved yet. |
| Approved | Pending | Approve *Child* | Yes | No conflict with Parent Record. |
| Active | Pending | Approve *Child* | Yes | No conflict with Parent Record. |
| Pending | Pending | Reject *Child* | Yes | No conflict with Parent Record. |
| Approved | Pending | Reject *Child* | Yes | No conflict with Parent Record. |
| Active | Pending | Reject *Child* | Yes | No conflict with Parent Record. |

**New Record (Withdraw)**

**#FS10013\_S0310\_03101**

The withdraw of an Approved New Record Request is allowed depends on the new Record Request status of both **Parent Record** and **Child Record**.

| **Record Status of Parent Record** | **Record Status of Child Record** | **Action** | **Allow** | **Reason** |
| --- | --- | --- | --- | --- |
| Approved | Pending | Withdraw *Parent* | **No** | As there is a Child Record depending on the Parent Record. |
| Approved | Approved | Withdraw *Parent* | **No** | As there is a Child Record depending on the Parent Record. |
| Approved | Approved  *(Pending Withdraw)* | Withdraw *Parent* | **No** | As there is a Child Record depending on the Parent Record. |
| Approved | Active  *(Pending Change)* | Withdraw *Parent* | **No** | As there is a pending change of Child Record depending on the Parent Record. |
| Approved | Active  *(Approved Change)* | Withdraw *Parent* | **No** | As there is an approved change of Child Record depending on the Parent Record. |
| Approved | Approved | Withdraw *Child* | Yes | No conflict with Parent Record. |

**Change Record (Submit)**

**#FS10013\_S0310\_03202**

Change Record Request can be submitted depends on the Record status of the **Parent Record** and **Child Record**.

| **Record Status of Parent Record** | **Record Status of Child Record** | **Action** | **Allow** | **Reason** |
| --- | --- | --- | --- | --- |
| Pending | Active | Update *Child* | Yes | The Parent Record’s status is allowed to select in Child Record’s detail page.  **\* Only when the effective time of Parent Record is before the effective time the update of Child Record.** |
| Approved | Active | Update *Child* | Yes | The Parent Record’s status is allowed to select in Child Record’s detail page.  **\* Only when the effective time of Parent Record is before the effective time the update of Child Record.** |
| Approved  *(Pending Withdraw)* | Active | Update *Child* | **No** | As there is a pending withdraw of the create request in Parent Record. |
| Active | Active | Update *Child* | Yes | The Parent Record’s status is allowed to select in Child Record’s detail page. |
| Active *(Pending Delete)* | Active | Update *Child* | Yes | As there is the Delete request in Parent Record is still in pending status only. |
| Active  *(Approved Delete)* | Active | Update *Child* | **No** | As there is an approved Delete request in Parent Record. |

**Delete Record (Submit)**

**#FS10013\_S0310\_03302**

Delete Record Request can be submitted depends on the Record status of the **Parent Record** and **Child Record**.

| **Record Status of Parent Record** | **Record Status of Child Record** | **Action** | **Allow** | **Reason** |
| --- | --- | --- | --- | --- |
| Active | Pending | Delete *Parent* | **No** | As there is a Child Record depending on the Parent Record. |
| Active | Approved | Delete *Parent* | **No** | As there is a Child Record depending on the Parent Record. |
| Active | Approved  *(Pending Withdraw)* | Delete *Parent* | **No** | As there is a Child Record depending on the Parent Record. |
| Active | Active | Delete *Parent* | **No** | As there is a Child Record depending on the Parent Record. |
| Active | Active  *(Pending Delete)* | Delete *Parent* | Yes | There is no conflict with Child Record.  Users need to approve the Pending delete of Child Record first, then approve the Parent Record. There is validation to prevent the approve in reverse sequence. |
| Active | Active  *(Approved Delete)* | Delete *Parent* | Yes | There is no conflict with Child Record. |
| Active | Active  *(Pending Update)* | Delete *Parent* | **No** | As there is a pending update of Child Record depending on the Parent Record. |
| Active | Active  *(Approved Update)* | Delete *Parent* | **No** | As there is an approved update of Child Record depending on the Parent Record. |
| Active | Active | Delete *Child* | Yes | There is no conflict with Parent Record. |

**Delete Record (Withdraw)**

**#FS10013\_S0310\_03400**

The withdraw of an Approved Delete Record Request is allowed depends on the Record Request status of both **Parent Record** and **Child Record**.

| **Record Status of Parent Record** | **Record Status of Child Record** | **Action** | **Allow** | **Reason** |
| --- | --- | --- | --- | --- |
| Active | Active  *(Approved Delete)* | Withdraw *Child* | Yes | There is no conflict with Parent Record. |
| Active  *(Approved Delete)* | Active  *(Approved Delete)* | Withdraw *Child* | **No** | As Parent Record has an Approved Delete. |
| Active  *(Approved Delete)* | Active  *(Approved Delete)* | Withdraw *Parent* | Yes | There is no conflict with Child Record. |

* + 1. Effective of the Change Request (As soon as possible / Today)

**#FS10013\_S0310\_03501**

**Restriction for change request that scheduled today**

There are some restrictions when schedule a change request for today:

* 1. Maker can only schedule a change to execute at least 1 minute after current time.
  2. Maker can submit withdraw request to withdraw an approved change request which is scheduled to execute at least 1 minute after the current time.
  3. Checker can only approve a change request that is scheduled to execute at least 1 minute after the current time.
  4. Checker can only approve a withdraw request if the target approved request is scheduled to execute at least 1 minute after the current time.

**Pending change request with scheduled time passed**

If a pending change request is still not approved at or after the scheduled time, system will reject the change request automatically.

**Effective of As soon as possible / Today changes**

For Change Requests which scheduled to be effective As soon as possible / Today, system will execute the change at the scheduled time once the request had been approved by checker.

***Change executed successfully at scheduled time***

The following fields in the Countersign Request will be updated:

1. **Exec Status** field will become **Executed**.
2. **Update At** field will be updated as the time of the execution.

***Change failed to execute at scheduled time***

The following fields in the Countersign Request will be updated:

* 1. Both the **Request Status** and **Exec Status** field will become **Failed**.
  2. **Update At** field will be updated as the time of the execution.

For change that effective as soon as possible, Checker can approve the Countersign Request again to re-execute the change.

But for the change that effective Today, if the execution failed, Checker can no longer approve the Countersign Request as the scheduled time had been passed.

(For scheduled today) When system execute the change at scheduled time, if there is pending withdraw request associated with this change request, system will reject the pending withdraw request automatically.

* 1. Authorization Flow

**#FS10013\_S0311\_00102**

For request operations that are effective as soon as possible (For Exchange User functions & Temporary functions), or effective today with a scheduled time / tomorrow (Permanent functions), a standard authorisation flow is adopted.

After Market Operation user complete their changes in edit/create/delete, user can press the “Submit” button to submit the request. According to the level of authorization required, it has following behaviours:

* No Authorization Required

Requester can submit a change and apply it to the system directly.

* 4-eye Change Confirmation Required (Requester / Approver)

A change request will be submitted as pending state and wait for approver to review and provide the approval. Requester and Approver must be different person.

Before the approval is made, Requester can check the current state of the request and reject it if it is no longer valid.

If Approver or Requester rejects the change, the change will be discarded.

**#FS10013\_S0311\_00200**

It should be noted that as part of the end of day housekeeping job, remaining pending requests are discarded and a report will be generated along with the request detail. And pending change request with a scheduled time of today / as soon as possible will be rejected by system if it cannot be approved before the scheduled time.

* + 1. Countersign Request

**#FS10013\_S0311\_00300**

The screen allows user to view request of today and search change request by Function Name, Requester, Status, etc. The search screen will display all the change request in the system. User can further view the detail of the Request if they have the write/approve permission of the corresponding Function.

**Screen Layout**

**#FS10013\_S0311\_00401**

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

**Attributes**

**#FS10013\_S0311\_00503**

| **Screen Label** | **Type** | **Length** | **Remarks** |
| --- | --- | --- | --- |
| Req Status | Alphanumeric | 10 | Status of countersign request.  Ref: [Common Attributes](#_Common_Attributes) - TX Status |
| Req Action | Alphanumeric | 8 | Request Action to be performed.  Ref: [Common Attributes](#_Common_Attributes) - TX Action |
| Exec Status | Alphanumeric | 10 | Execution Status of the Request.  Ref: [Common Attributes](#_Common_Attributes) - Execution Status |
| Req ID | Numeric | 10 | A unique identifier for the change request to be uthorized. |
| Identifier | Alphanumeric | 100 | ID and Unique values of the master record which involved in the change. |
| Received At | Date and Time | 20 | Request submit time in DD-MMM-YYYY HH:MM:SS. |
| Approved At | Date and Time | 20 | The time when Checker approved the request in DD-MMM-YYYY HH:MM:SS. |
| Function Name | Alphanumeric | 80 | Function name that the request is going to perform the change on. |
| Requester | Alphanumeric | 120 | Name of requester. |
| Effective Date | Date | 11 | The date that the request will be effective in DD-MMM-YYYY. |
| Scheduled Time | Time | 8 | Scheduled time in HH:MM:SS. |

**Validation**

**#FS10013\_S0311\_00600**

Approve Countersign Request:

1. All type of Requests:
   1. Make sure that the Approver is not the same as Requester.
   2. Make sure that the Approver have the rights to approve the Request.
   3. Make sure that the Request is in Pending / Failed status.
   4. For Add/Update Requests, make sure that the dependent records are Approved or Active.
   5. For Delete Requests, make sure that no Pending/Approved/Active records are depending on this record.
   6. For Withdraw Requests (New Record), make sure that no Pending/Approved records are depending on this record.
2. Additional validation for New record / Update for scheduled today
   1. Make sure that the current System Time is still at least 1 minutes ahead of the scheduled time.
   2. Make sure that the Time gap between Client Device’s Time and System Time is less than 5 minutes.
      (If there is a 1 to 5 minutes time gap between Client Device’s Time and System Time, a confirmation dialog will be prompted. User can proceed the approval if he/she clicks the confirm button in the dialog.)
3. Additional validation for Record with Dependencies

Reject Countersign Request:

**#FS10013\_S0311\_00700**

* All type of Requests:
  1. Make sure the user is an Approver or the original Requester or the Request.
  2. If user is an Approver (Not the original Requester), make sure that the Approver has the rights to reject the Request.
  3. Make sure that the Request is in Pending / Failed status.
  4. For Add Request, make sure that there are no Pending Records depending on this Record.

Withdraw Countersign Request:

**#FS10013\_S0311\_00750**

* All type of Requests:
  1. Make sure the user has rights to submit withdraw request.
  2. Make sure that the Request is in Approved status, and it’s not executed yet.
  3. Make sure that the Request do not have pending/approved withdraw request.

**Available Actions**

**#FS10013\_S0311\_00802**

| **Action** | **Description** |
| --- | --- |
| Screen Open | Trigger a query to display all request of today |
| Search | Trigger a query based on selected request type and status |
| Double Click a row | Same as above |
| Withdrawn only | Toggle to show withdrawn requests or valid requests by select the Withdrawn only checkbox. (User need to click Apply button to execute the toggle.) |
| Approve selected Countersign Request | Approve the selected requests. User can approve one or more request at a time.  Item will be disabled if any one of the selected requests is not applicable to approve. |
| Approve all Pending Countersign Request | Approve all the Pending requests in one go. (Except the Pending requests raised by the user).  Users can reduce the scope by applying the filter. |
| Export Summary | Export the summaries of all Countersign Requests as a CSV file based on the filtering criteria. |
| Export Detail | Export the detail all Countersign Request as a CSV file based on the filtering criteria. |
| Reject selected Countersign Request | Reject the selected requests. User can approve one or more request at a time.  Item will be disabled if any one of the selected requests is not applicable to reject. |
| Reject all Pending Countersign Request | Reject all the Pending requests in one go.  Users can reduce the scope by applying the filter. |
| Withdraw selected Countersign Request | Withdraw the selected requests. User can withdraw one or more approved requests at a time.  Item will be disabled if any one of the selected requests is not applicable to withdraw. |
| Withdraw all Approved Countersign Request | Withdraw all the Approved requests in one go. (Not applicable to Executed requests or requests which has Pending/Approved withdraw.)  Users can reduce the scope by applying the filter. |

* + 1. Countersign Request Detail Screen

**#FS10013\_S0311\_00900**

This screen allows user to view the detail of a request and performs approve/reject if he/she is authorized to do.

Requesters are allowed to reject their own Countersign Request.

Approvers are allowed to Approve/Reject the Countersign Request if they have the approval permission of the corresponding Request Type. And Approver should be a different person from the Requester of the Countersign Request.

Change Detail is available only when User have Read rights of the corresponding Function.

**Screen Layout**

**#FS10013\_S0311\_01000**

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

**Attributes**

**#FS10013\_S0311\_01102**

Generate Information Section display the general information of the request. This section should be common to all requests.

| **Column** | **Type** | **Length** | **Remarks** |
| --- | --- | --- | --- |
| **Request Identity** | | | |
| Request ID | Numeric | 10 | A unique identifier for the change request to be authorized. |
| Received At | Date and Time | 20 | Request submit date and time in YYYY-MMM-DD HH:MM:SS |
| Requester | Alphanumeric | 120 | Name of the User who raise the request. |
| Identifier | Alphanumeric | 100 | ID and Unique values of the master record which involved in the change. |
| **Request Detail** | | | |
| Function Name | Alphanumeric | 80 | Function name that the request is going to perform the change on. |
| Open Detail | Button | NA | Open the Detail page of the record to be change in this Request. |
| Request Action | Alphanumeric | 10 | Request Action to be performed.  Ref: [Common Attributes](#_Common_Attributes)  - TX Action |
| Request Status | Alphanumeric | 10 | Status of countersign request.  Ref: [Common Attributes](#_Common_Attributes)  - TX Status  Field will be highlighted for the Request Status below:  **Approved (Highlighted in green)**  **Rejected (Highlighted in red)** |
| Execution Status | Alphanumeric | 10 | Execution Status of the Request.  Ref: [Common Attributes](#_Common_Attributes)  - Execution Status |
| Update At | Date and Time | 20 | The time that the request status is updated in DD-MMM-YYYY HH:MM:SS.. |
| Effective Date | Date | 11 | The date that the request will be effective in DD-MMM-YYYY. |
| Scheduled Time | Time | 8 | Scheduled time in HH:MM:SS. |
| **Approve / Reject Detail** | | | |
| Approver | Alphanumeric | 120 | Name of the User who approve the request. |
| Approved At | Date and Time | 20 | Approval time in DD-MMM-YYYY HH:MM:SS. |
| Rejecter | Alphanumeric | 120 | Name of the User who rejected the request. |
| Rejected At | Date and Time | 20 | Rejection time in DD-MMM-YYYY HH:MM:SS. |
| Failed Reason | Alphanumeric | 200 | Reason of failure if Request status if Failed. |

Changes Detail Section displays the details of the Action.
**(For Maintain Functions)**

| **Column** | **Type** | **Length** | **Remarks** |
| --- | --- | --- | --- |
| **Change Detail** | | | |
| Action | Alphanumeric | 10 | Action to be performed on the Attribute.  **Add –** Add new value to the Attribute  **Update –** Update the value of the Attribute  **No change –** No change to the Attribute  **Delete –** Record to be deleted  **Withdraw –** Value to withdraw |
| Record Type | Alphanumeric | 30 | Underlying Record Type of the Record involved in this change. |
| Attribute | Alphanumeric | 120 | Attributes of the Record.  If there are more than one record with the same Record Type, a prefix “**Record X –** “will be added to the Attribute in order to distinguish between records. |
| Value | Alphanumeric | 1024 | The value of the Attribute. The meaning of the field depends on the **Action**:  **When Action is “Add”:**  Value to be inserted to DB  **When Action is “Delete”:**  Record ID of the record to be delete  **When Action is “Withdraw”:**  Value to be withdraw  **When Action is “No Change”:**  Show the current value in DB  **\* This field is empty when Action is “Update”.** |
| From | Alphanumeric | 1024 | The value of the Attribute before the change.  Display the existing value in Database.  **\* This field only applicable when Action is “Update”** |
| To | Alphanumeric | 1024 | The value of the Attribute after the change.  **\* This field only applicable when Action is “Update”** |

Changes Detail Section displays the details of the Action.
**(For Control Functions)**

| **Column** | **Type** | **Length** | **Remarks** |
| --- | --- | --- | --- |
| **Change Detail** | | | |
| Attribute | Alphanumeric | 120 | Attributes of the Record.  If the attribute is a list, a suffix “ > **X**” will be added to distinguish the items in the list. If there is multiple layers of Attributes, the layers will be listed and separated by ‘-’. (e.g. A – B – C) |
| Value | Alphanumeric | 1024 | The value of the Attribute. |

**Examples**

**#FS10013\_S0311\_01200**

Add New Record

When creating a new Record, the action of all the attributes should be **Add**. **From** column should be empty and **To** column shows the target values to be insert to database.

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

Update a Record

When updating a Record, the unchanged field of the Record will be displayed as **No Change** for user to identify which record is being updated.

And the action of the attribution being changed is showing as **Update**. The existing value and target value are displayed in the **From** and **To** column respectively.

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

Delete a Record

When delete a Record, the key field of the Record to be deleted will be displayed as **Delete** for user to identify which record is being deleted.

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

Withdraw a change request

When withdrawing a change request, the Action of the attributes are all **Withdraw**.

The original Request’s action will show up on the Changes Detail table. And follow with the original Request’s change detail to indicate the detail to be withdrawn.

Here is the sample:

1. Withdraw an “Add” request

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

1. Withdraw an “Update” request

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

1. Withdraw a “Delete” request

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

Execute Control

When execute a Control, the detail of the Control action will be displayed.

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

**Validation**

**#FS10013\_S0311\_01300**

Please refer to the Validation in the “Countersign Request” section.

**Available Actions**

**#FS10013\_S0311\_01400**

| **Action** | **Description** |
| --- | --- |
| Screen Open | Display request detail to screen. |
| Export | Export request detail in CSV file. |
| Approve | Approve the Countersign Request. |
| Reject | Reject the Countersign Request. |

## User Preferences

**#FS10013\_S0312\_00100**

Re-order/Resize column in search page will not be saved as user preferences.

## Inheritance Attribute

**#FS10013\_S0313\_00100**

For those attributes which can be inherited from the upper level based upon product hierarchy, there is a checkbox beside the input field to indicate the current inherited status.

For example, “Contract size” of Instrument Record could inherit from Instrument Class level

When the checkbox is checked, it represents that the attribute inherits from upper level, and the input box is not editable in stage:

![](data:image/png;base64...)

When the checkbox is un-checked, it represents that the user would like to override the inherited value from upper level and provide a value to this specific record:

![](data:image/png;base64...)

When creating new records, inheritable fields will inherit from the upper level by **default**. Users are allowed to adjust the value when required by unchecking the checkbox.

The following product hierarchies are defined in the system:

Exchange

Market

Instrument Type

Instrument Class

Instrument

Exchange

Market

Combo Type

Combo Class

Combo

## Permissions

**#FS10013\_S0314\_00100**

There are three different types of permission in the GUI:

1. Read-only

Users with read-only permission can perform search and view the result from Search Screen & Detail Screen.

1. Read + Write

Apart from performing search and view the result from Search Screen & Detail Screen, Users can submit new/update/delete request for second user approval. It is also allowed to reject his own submitted request if required from Countersign Request Screen.

1. Read + Write + Approve

Apart from submitting change request and view the result, users are allowed to approve / reject a request for other users.

## Screen

### Search Screen

**#FS10013\_S0315\_00101**

Search screen is used to provide a place for user to list out those records based on search criteria field (In case insensitive), which supports:

1. Exact match, target keyword exactly matches the result
2. Partial match, target keyword partially matches the result base on the following arguments
   1. question mark (?) to match zero or one occurrence
   2. and star (\*) to match zero or more occurrence.
3. Numeric value range search
4. Date and Date time range search

For example, if user inputs “ABC\*”, entries with ABC, ABCx, ABC123 should show up in the search results. When user inputs “A?C”, entries with ABC should show instead.

When multiple search criteria are specified, they are considered as **AND** condition. To find records that meet multiple values of the same criteria, it is allowed to key in “,” to select as **OR** condition up to 5 maximum values per criteria.

![](data:image/png;base64...)

Search can be enabled by entering Enter key.

Filter by label indicates the current filtering criteria of the search, and those results are displayed in the underneath table along with pagination bar by default and scroll bar for Timetable and Auto Generation functions.

Apart from filter by search criteria, user is allowed to perform value filter by using table column operation menu ![](data:image/png;base64...) > filter

*\*Please noted that More Filters is replaced by table column operation menu filter feature*

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

Search

Export to CSV is available under More Actions drop down to export the well formatted result to file.

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

### Detail Screen

**#FS10013\_S0315\_00205**

Detail screen is used to display the detail of a selected record along with the current record status and future planned status at the top of this screen. User can plan a New/Update/Delete record this screen, export the detail to file in raw data format, show the record history (**#FS10013\_S0315\_00210** TBC record retention 3 years?) etc. User can open up to 5 detail record screens at a time.

User can check the history of a record from detail screen by Show History Action

**#FS10013\_S0315\_00300**

Once a change is submitted and accepted by the system, a modification notification message will be prompted to those users who has opened the same record regardless of if he/she is reading or editing the detail.

When that happen, the detail screen will reset to Read-only mode and confirm button will be disabled. It is suggested to close and reopen the record again.

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

**#FS10013\_S0315\_00400**

For mandatory field, validation message in red colour shows underneath the input box if value is not provided.

For user input field, background colour highlights as light orange if value is not provided.

![](data:image/png;base64...)

**#FS10013\_S0315\_00501**

Mandatory Field is indicated by a red star. Field with connected subitem is indicated with an arrow icon at the right corner, clicking on the icon will pop up a new dialog for more detail.

Background colour shows in grey colour if it is in Read-only stage.

![](data:image/png;base64...)

Tooltip description is optional and can be displayed if it is available when mouse over.

![](data:image/png;base64...)

All leading and trailing whitespace in input fields will be automatically trimmed.

### Control Screen

**#FS10013\_S0315\_00600**

Control screen is used to send command to matching engine.

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

### Monitoring Screen

**#FS10013\_S0315\_00700**

Monitoring Screen is used to monitor data.

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

### System Time and Client Local Time

**#FS10013\_S0315\_00800**

The Hong Kong Local Time UTC/GMT +8 Hours is used as the system time for UI display, communication and processing.

Selection of date/time in GUI screen relies on Client Local PC time to provide an accurate current time of Hong Kong and user can further adjust the time to target date or time when required, for example user can target a scheduled event at 16:30 PM Hong Kong Local Time in a GUI drop down while the client UK local time is 9:30 AM.

In case of the Client Time is far away from our expected system time, a user notification is prompted to highlight the gap between client time and system time right after a successful user login. Client should follow up with their local admin to resolve it and login again.

The following system notification setting is defined:

| Absolute (Client UTC Time – Server UTC Time) | System Notification Level |
| --- | --- |
| More than 1 minute | INFO |
| More than 2 minutes | WARNING |
| More than 5 minutes | ERROR |

# Admin Functions

**#FS10013\_S0400\_00100**

## Common

### Function Type

**#FS10013\_S0401\_00101**

Perm: changes will be carried forward to Tomorrow

Temp: effective intraday, changes will be reverted in SOD of Tomorrow

For functions support Perm ONLY, the supported operation will be Tomorrow ONLY.

| Combination | Function Type | Supported Operation |
| --- | --- | --- |
| Tomorrow ONLY | Perm | Tomorrow |
| Perm + Temp | Perm | Tomorrow |
| Intraday (Scheduled Time of Today) + Tomorrow |
| Intraday (ASAP) + Tomorrow |
| Temp | ASAP |

The Intraday column in below table:

**#FS10013\_S0401\_00217**

1. Y: Support Scheduled Time of Today and ASAP
2. ASAP: ASAP ONLY

| Function Group | Function | Perm | | | Temp |
| --- | --- | --- | --- | --- | --- |
| Tomorrow | Intraday | |
| Creation | Modification |
| Instrument | Maintain Exchange | Y | N | N | N |
| Maintain Market | Y | N | N | N |
| Maintain Instrument Group | Y | N | N | N |
| Maintain Instrument Type | Y | N | N | N |
| Maintain Underlying | Y | N | Y  Supported Fields:   * Status * MMP Enabled? * Minimum MMP Quantity | N |
| Maintain Instrument Class | Y | N | Y  Supported Fields:   * Auto Generation? * Auto Instrument Generation Rule ID * Furthest Expiry Date * Cycle Block Frozen Date | N |
| Maintain Instrument | Y | Y | Y  Supported Fields:   * Status * First Trading Date * First Trading Time * Effective Last Trading Date * Last Trading Time | N |
| Maintain Instrument Name Standard | Y | Y | Y | N |
| Maintain Access Group By Type | Y | N | N | N |
| Combo | Maintain Combo Group | Y | N | N | N |
| Maintain Combo Type | Y | N | N | N |
| Maintain Combo Class | Y | N | N | N |
| Maintain Combo | Y | N | Y  Supported Fields:   * Status * First Trading Date * First Trading Time * Effective Last Trading Date * Last Trading Time | N |
| Maintain Combo Name Standard | Y | Y (non-TMC only) | Y (non-TMC only) | N |
| **#FS10013\_S0401\_00301**  Auto Instrument Generation | Maintain Auto Generation Rule | Y | Y | Y | N |
| Maintain Cycle Blocks | Y | Y | Y | N |
| Maintain Last Trading Date Formula | Y | Y | Y | N |
| Maintain Regional Holiday Calendar | Y | Y | Y | N |
| Maintain Last Trading Date Calendar | Y | Y | Y | N |
| Maintain Lifecycle Time Rule | Y | Y | Y | N |
| Maintain Last Trading Time DST Adjustment | Y | Y | Y | N |
| Maintain Strike Price Range | Y | Y | Y | N |
| Maintain Strike Price Table | Y | Y | Y | N |
| Maintain Strike Price Reference | Y | Y | Y | N |
| Instrument Generation | Y | N | N | N |
| Regional Calendar Upload | Y | Y | Y | N |
| **#FS10013\_S0401\_00400**  Auto Combo Generation | Maintain Auto Generation Rule for Combo | Y | Y | Y | N |
| Combo Generation | Y | N | N | N |
| **#FS10013\_S0401\_00501**  SMP | Maintain SMP ID | Y | Y | Y  Supported Field:   * Status | N |
| Review SMP Request | Y | N | N | N |
| TMC | Maintain TMC Strategy List | Y | N | N | N |
| Maintain TMC Strategy | Y | N | N | N |
| Control TMC | N/A | N/A | N/A | Y |
| Price Supervision | Maintain Price Tick | Y | N | N | N |
| Maintain Price Tick Limit Rule | Y | N | Y  Supported Fields:   * Deviation Tick * Deviation Percentage * Exception Deviation Tick * Exception Deviation Percentage | N |
| Maintain Instrument Class Price Tick Limit | Y | N/A (system created) | Y  Supported Fields:   * Price Tick Upper Limit * Price Tick Lower Limit * Price Tick Reference Price * Next Day Price Tick Upper Limit * Next Day Price Tick Lower Limit * Next Day Price Tick Reference Price | N |
| Maintain Combo Class Price Tick Limit | Y | N/A (system created) | Y  Supported Fields:   * Price Tick Upper Limit * Price Tick Lower Limit * Price Tick Reference Price * Next Day Price Tick Upper Limit * Next Day Price Tick Lower Limit * Next Day Price Tick Reference Price | N |
| Maintain Price Limit | Y | N | N | N |
| Maintain Price Limit Parameters | Y | N | N | N |
| Maintain Reference Price Source | Y | N | N | N |
| Maintain Reference Price Calculation Rule | Y | N | N | N |
| Maintain VCM | Y | N | N | N |
| Maintain VCM Parameters | Y | N | N | N |
| Maintain Futures Group | Y | N | N | N |
| Control & Monitor Price Limit | N/A | N/A | N/A | Y |
| Control & Monitor VCM | N/A | N/A | N/A | Y |
| Control & Monitor Instrument Trading Halt | N/A | N/A | N/A | Y |
| Control Contingency Trigger of Price Tick Limit Calculation | N/A | N/A | N/A | Y |
| Control Contingency Trigger of AHT Reference Price Calculation | N/A | N/A | N/A | Y |
| Block Trade | Maintain Block Trade Group | Y | N | N | N |
| Maintain Block Trade MVT | Y | N | N | N |
| Error Trade | Maintain Combo Type Error Trade Parameters | Y | N/A (system created) | N | N |
| Maintain Instrument Type Error Trade Parameters | Y | N/A (system created) | N | N |
| Report Generation and Processing | Maintain Report | Y | N | N | N |
| Maintain Report Group List | Y | N | N | N |
| Control Daily Market Report (DMR) | N/A | N/A | N/A | N/A |
| Control Admin Report | N/A | N/A | N/A | N/A |
| Market Messages | Maintain Message Template | Y | Y | Y  Supported Fields:   * Message Priority * Subject * Content | N |
| Maintain Automatic Event Message | Y | N | Y  Supported Fields:   * Template for Market Data Channel * Template for Trading GUI Channel * Template for Binary Channel * Template for Email Channel * Recipient for Email Channel 1 * Recipient for Email Channel 2 * Recipient for Email Channel 3 * Recipient for Email Channel 4 * Recipient for Email Channel 5 | N |
| Send Manual Market Announcement | N/A | N/A | N/A | N/A |
| Capital Adjustment | Control Capital Adjustment | Y | Y (Create CA Event) | Y (Delete CA Event) | N/A |
| **#FS10013\_S0401\_00600**  Participant | Maintain Exchange Participant | Y | N | Y  Supported Field:   * Suspended? | N |
| Maintain Drop Copy Group | Y | N | N | N |
| Maintain Direct Drop Copy Session | Y | N | Y  Supported Fields:   * Blocked? * Locked? * Password * Legal IP Addresses ID | N |
| Maintain Direct Order Flow Session | Y | N | Y  Supported Fields:   * Blocked? * Locked? * Password * Legal IP Addresses ID | N |
| Maintain Legal IP Address | Y | N | Y  Supported Field:   * IP Address | N |
| Maintain PTRM GUI User | Y | N | Y  Supported Fields:   * Suspended? * Blocked? * Blocked Reason * Legal Browser IP Addresses ID | N |
| Maintain Trading GUI User | Y | N | Y  Supported Fields:   * Suspended? * Blocked? * Blocked Reason * Legal Browser IP Addresses ID | N |
| Maintain Sponsoring Participant | Y | N | Y  Supported Field:   * Suspended? | N |
| Maintain Trading Rights | Y | N | N | N |
| Maintain Participant User Role | Y | N | N | N |
| Maintain SMP ID List | Y | N | Y  Supported Fields:   * SMP ID * Status | N |
| Maintain MMP Parameter | Y | Y | Y  Supported Fields:   * Include Futures? * Quantity Protection * Delta Protection * Exposure Time Limit Interval * Frozen Time | N |
| Control Block/Unblock Participant Per Product | N/A | N/A | N/A | Y |
| Maintain Company | Y | N | N | N |
| Maintain Self Admin Portal User | Y | N | Y  Supported Fields:   * Suspended? * Legal Browser IP Addresses ID | N |
| Request External IDP User | N/A | Y | N | N/A |
| Timetable | Maintain Trading Timetable | Y | N | N | N |
| Maintain Trading State | Y | N | N | N |
| Maintain Non-Trading Days | Y | N | N | N |
| Maintain Special Trading Days | Y | N | N | N |
| Control Trading Timetable | N/A | N/A | N/A | Y |
| System | Maintain Global Parameters | Y | N | N | N |
| Maintain Contingency Switch | Y | N | ASAP  Supported Fields (allowed to disable only):   * Static Price Limit Enabled? * Dynamic Price Limit Enabled? * VCM Enabled? * SMP Enabled? * Implied Enabled? * PTRM Enabled? | N |
| View Password Policy | N/A | N/A | N/A | N/A |
| Control & Monitoring | Monitor Historical Order Book | N/A | N/A | N/A | N/A |
| Monitor Quote Request | N/A | N/A | N/A | N/A |
| Monitor OLS Record | N/A | N/A | N/A | N/A |
| Monitor Event and Alert | N/A | N/A | N/A | N/A |
| Monitor Order Flow Gateway | N/A | N/A | N/A | N/A |
| Monitor Drop Copy Gateway | N/A | N/A | N/A | N/A |
| Monitor Lookup Server Statistic | N/A | N/A | N/A | N/A |
| Order Flow Client Enquiry | N/A | N/A | N/A | N/A |
| Drop Copy Client Enquiry | N/A | N/A | N/A | N/A |
| Control & Monitor Order Flow Client | N/A | N/A | N/A | N/A |
| Control & Monitor Drop Copy Client | N/A | N/A | N/A | N/A |
| Control & Monitor Trading GUI Client | N/A | N/A | N/A | N/A |
| Control & Monitor PTRM GUI Client | N/A | N/A | N/A | N/A |
| Control Settlement Values | N/A | N/A | N/A | Y |
| Control Underlying Price | N/A | N/A | N/A | Y |
| User Maintenance | Maintain Exchange User | Y | N | Y  Supported Field:   * Locked? | N |
| Maintain UI User Role | Y | N | N | N |
| Maintain System Preference | Y | N | N | N |
| Request Internal IDP User | N/A | Y | N | N/A |

### Bulk Amend by UI Select (TBC)

**#FS10013\_S0401\_00700**

**Description**

Support to select up to 100 (TBC, configurable) records to open a detail page to bulk amend in UI.

### Bulk Import from File (TBC)

**#FS10013\_S0401\_00800**

**Description**

**#FS10013\_S0401\_00900**

**Bulk Upload** is used to upload specified records in bulk.

**UI Layout**

**#FS10013\_S0401\_01000**

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

**View Page Attributes**

**#FS10013\_S0401\_01102**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Import Type | Alphanumeric | 32 | M | - | Allowed Import Type:   * Underlying * Inst. Type * Inst. Class * Instrument * Combo Type * Combo Class * Combo * Access Group by Type * Special Trading Days * Non-Trading Days * MMP * Price Tick * Instrument Class Price Tick Limit * Combo Class Price Tick Limit * SMP Token * SMP Token List? * PTRM User? * Trading User? * Admin User? * User Type? * Order Flow Session * Legal IP Address List |
| Activation Type | Alphanumeric | 20 | M | - | Read-only field.  The value is from upload file and can be:   * Tomorrow * Schedule today * As soon as possible |
| Schedule Time | Time | 8 | O | - | Read-only field.  The value is from upload file and only available when Activation Type is Schedule today |
| File Name | Alphanumeric | 120 | M | - | Read-only field.  Show uploaded file name |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0401\_01200**

**Actions**

**#FS10013\_S0401\_01300**

| Action | Description |
| --- | --- |
| Import | Open a dialog to select a file to import |
| Reset | Reset all fields |
| Export | Export all Records from page table to CSV file |
| Confirm | Confirm the change and submit to backend, disabled with Read-only permission and view mode |
| Cancel | Cancel all changes, disabled with Read-only permission and view mode |

**Validation (Ref:** [**Common Validation**](#_Common_Validation)**,** [**IPv4 Validation**](#_IPv4_Validation), [**Validation Rule**](#_Validation_Rule_(TBC))**)**

**#FS10013\_S0401\_01401**

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0401\_01500**

### Change History

**#FS10013\_S0401\_01600**

Change History dialog can be opened from Detail screen per record individually and displayed for up to 7 years and maximum 10K latest history only.

**UI Layout**

**#FS10013\_S0401\_01700**

Display columns are based on the function fields. Example: Maintain Inst. Type

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

**Attributes**

| Column | Type | Remarks |
| --- | --- | --- |
| Created By | Alphanumeric | Creator, will be filled when Create |
| Created At | Date + Time | Create Time, will be filled when Create |
| Modified By | Alphanumeric | Modifier, will be filled when Create/Update/Delete |
| Modified At | Date + Time | Modify Time, will be filled when Create/Update/Delete |
| Authorized By | Alphanumeric | Authorizer, will be filled when Approve/Reject |
| Authorized At | Date + Time | Authorize Time, will be filled when Approve/Reject |

### Common Attributes

**#FS10013\_S0401\_01819**

| Attribute | Type | Length | Domain Value |
| --- | --- | --- | --- |
| Action | Char | 1 | 1 - Read  2 - Read / Write  9 - Read / Write / Approve |
| Admin Report Type | Alphanumeric | 2 | RR - Record Report  CR - Change Report  ER - Error Report  WR - Withdraw Report |
| Blocked Reason | Numeric | 1 | 0 - NA  1 - Blocked by Admin  2 - Blocked For Test |
| Boolean Char | Char | 1 | Y - Yes  N - No |
| CA Event Type | Char | 1 | R - Right Issue  B - Bonus Issue of Shares  W - Bonus Issue of Warrants  C - Share Consolidation  S - Share Sub-division  M - Merger (Shares and Cash)  G - Merger (Shares Only)  E - Spin-Off (E-Day)  F - Spin-Off (F-Day; with Entitlement)  D - Other Cash Distribution (Special Dividend)  X - Other CA Events |
| Client Status | Numeric | 3 | 1 - Normal  2 - Blocked  3 - Loadgen |
| Connection Status | Numeric | 3 | 0 - Not connected  1 - Logged-on  2 - Disconnected |
| Contract Month Option | Char | 1 | S - Spot  N - Non-Spot  B - Both |
| Cycle Unit | Char | 1 | Cycle Unit used in Auto Generation.  M - Monthly  W - Weekly  D - Daily |
| Data Source | Numeric | 1 | 0 - N/A  1 - OMD-C  2 - OMD-I |
| IDP User Type | Alphanumeric | 16 | - USER  - API |
| Execution Status | Char | 1 | P - (Pending) Pending Approval  S - (Scheduled) The Request had been approved but scheduled time not reached yet  E - (Executed) The Request had been approved and executed  F - (Failed) The Request failed to execute  R - (Rejected) The Request had been rejected  W – (Withdrawn) The approved Request had been withdrawn |
| Expiration Frequency | Char | 1 | M - Monthly  W - Weekly |
| Function Interface | Alphanumeric | 2 | 01 - UI  02 - API |
| Function Type | Char | 1 | 1 - Internal  2 - External |
| Gateway Service Type | Char | 1 | P - Order Flow - PSG  O - Order Flow - CGW D - Drop Copy R - PTRM |
| Gateway Session Usage | Char | 1 | D - Direct Access U - UI Access |
| Group Type | Char | 1 | O - Options  F - Forward  U - Futures  A - FRA  C - Cash  P - Payment  E - Exchange rate  S - Interest rate swap |
| Hierarchy Level | Alphanumeric | 6 | Market  Type  Class |
| Interface Protocol | Char | 1 | B - Binary F - FIX |
| Limit Deviation Unit | Char | 1 | A - Absolute Value  T - Number of Ticks  P - Percentage |
| Locked Reason | Char | 1 | Blank - N/A E - Password Expired R - Password Retry attempts exceeded I - Inactivity |
| Logical Day Ind | Numeric | 2 | -1 - T-1 0 - T 1 - T+1 |
| Market Type | Char | 1 | S - Stock F - Fixed Income U - Currency E - Power/energy C - Commodity P - Payment I - Index G - General |
| Message Priority | Char | 1 | N - Normal  I - Important  C - Critical |
| Month Selection | Numeric | 2 | 1 = All  2 = Even  3 = Odd  4 = Quarterly  5 = Half-yearly  6 = Yearly  14 = Quarterly (Skip Spot/Spot-Next Month) |
| Name Standard Type | Char | 1 | O - Options  U - Futures C - Combo |
| Options Style | Char | 1 | A - American E - European S - Asian B - Bermudan I - Knock-in O - Knock-out N - Binary R - Ratchet |
| Options Type | Char | 1 | C - Call P - Put |
| Options Variant | Char | 1 | N - Normal C - Cap F - Floor |
| OTP Delivery Method | Numeric | 1 | 1 - Email  2 - Authenticator |
| Participant User Type | Char | 1 | D - Direct Access (Trading) T - Trading GUI E - PTRM GUI (Trading Unit) C - PTRM GUI (Risk Limit Manager) |
| Password Expiry and Inactivity Handling | Numeric | 1 | 0 - No Action 1 - Lock Account 2 - Force Change Password |
| Password Policy Type | Char | 1 | I - Internal E - External S - System (development use ONLY) |
| Price Data Option | Numeric | 1 | 1 - Last traded price 2 - Previous day’s settlement price 3 - Reference price of the nearest earlier contract month 4 - Spot month last traded price + Previous day’s rollover spread 5 - Spot month last traded price + Expired spot month spread 6 - Last traded price of corresponding instrument 7 - Spot month last traded price + Previous day’s rollover spread of corresponding instrument |
| Price Source | Numeric | 1 | 1 - Opening Price 2 - Prev Trading Session Last Traded Price 3 - Calculated Price |
| Product Level | Char | 1 | M - Market T - Instrument Type t - Combo Type C - Instrument Class c - Combo Class |
| Product Type | Alphanumeric | 10 | Instrument  Combo |
| Report Group | Char | 1 | D - Daily Market Report  W - Weekly Quotation Report  M - Inst. Maintenance Report Type  S - SMP Participant Exclusion List |
| Report Type | Numeric | 2 | 1 - Day Reports - Futures with AHT  2 - Day Reports - Index Options with AHT  3 - Day Reports - TMC with AHT  4 - Night Reports - Futures with AHT  5 - Night Reports - Index Options with AHT  6 - Night Reports - TMC with AHT  7 - Stock Futures Reports  8 - Index Futures Reports  9 - Stock Options Reports  10 - Index & Currency Options Reports  11 - Flexible Index Options Reports  12 - TMC Reports  13 - Weekly Quotation Report  14 - HKFE Options Inst. Maintenance Report  15 - SEHK Options Inst. Maintenance Report  16 - SMP Participant Exclusion List |
| Scope | Numeric | 1 | 0 - All  1 - Reference Futures Only |
| Side Char | Char | 1 | B - Buy S - Sell |
| SMP ID Status | Char | 1 | A - Active  D - Deleted  S - Suspended |
| SMP Instruction | Char | 1 | A - Cancel aggressive  P - Cancel passive |
| Status | Char | 1 | A - Active  S - Suspended |
| Supported Event | Numeric | 2 | 1 - Change of Trading State  2 - Alert before Trading State Change  3 - Change of Underlying State  4 - Change of Instrument/Combo  5 - Quote Request  6 - Trigger VCM  7 - End of VCM  8 - Trigger Trading Halt  9 - Trigger AHT Price Limit  10 - Alert of AHT Price Limit  11 - Error Trade  12 - Trigger Trading Halt During No Resumption Period  13 - Trading Resumption  14 - Trading Halt Remaining in Effect |
| Timetable Type | Char | 1 | F - Full Day Timetable  H - Half Day Timetable |
| TMC Expiration Period | Char | 1 | 1 - 1 Day  2 - 1 Week  3 - 2 Weeks  4 - 4 Weeks |
| TMC Strategy Leg Condition | Numeric | 1 | 0 - Any  1 - Equal to Leg n  2 - Higher than Leg n  3 - Lower than Leg n  4 - Not equal to Leg n  5 - 2x Leg n |
| Trader Type | Char | 1 | 1 - Normal Broker  2 - Special Participant (SP)  3 - Liquidity Provider (LP)  4 - Security Market Maker (SMM)  5 - Kill Button (KB) |
| Trading Day Option | Char | 1 | 1 - Normal 2 - Last Trading Day 3 - Last Trading Day + 1 |
| Trading Day Type | Char | 1 | N - Non-Trading Day T - Trading Day |
| Trading Session ID | Numeric | 1 | 1 - Morning 2 - Afternoon 3 - Day  4 - AHT |
| Trading State Type | Numeric | 1 | Business Trading State Type:  1 - PREMKTACT 2 - PREOPEN 3 - PREOPENALLOC  4 - OPENALLOC  5 - UNCROSS  6 - OPEN  7 - PAUSE  Technical Trading State Type:  0 - SOD  8 - INTERVENTION  9 - DAYEND |
| Transition Mode | Numeric | 1 | 0 - Automatic 1 - Manual |
| Tx Action | Char | 1 | A - (Add) Add a new Record  U - (Update) Update a Record  D - (Delete) Delete a Record  W - (Withdraw) Withdraw a planned change  E - (Execute) Execute a Control |
| Tx Source | Char | 1 | A - Admin UI  T - Trading UI |
| Tx Status | Char | 1 | P - (Pending) Pending Approval  A - (Approved) Approved  R - (Rejected) Rejected  F - (Failed) (Failed during approve) |
| UI Role Type | Char | 1 | 1 - Admin  2 - Non-Admin |
| UI User Type | Char | 1 | 1 - Admin  2 - Non-Admin |
| Underlying Type | Char | 1 | S - Stock C - Currency I - Fixed Income E - Power/Energy A - Commodity M - Metal |
| Update Type | Char | 1 | E - External Source  M - Manual |

### Common Permission Behaviour

**#FS10013\_S0401\_01900**

| User | Permission | Description |
| --- | --- | --- |
| Read-only | Read | All attributes are Read-only |
| Maker | Read + Write | User can submit changes, reject changes created by the maker, and withdraw all approved changes which have not taken effect |
| Checker | Read + Write + Approval | User can review change request, approve and reject |

### Common Actions

**#FS10013\_S0401\_02002**

Perm:

| Action | Description |
| --- | --- |
| Screen Open | Trigger a query to display all records |
| Apply | Trigger a query of records based on input filters |
| Reset Filters | Reset all filters to default: All |
| New Record | New Tomorrow Change: create new record for Tomorrow |
| New Scheduled Change: create new record for Scheduled time of Today and Tomorrow |
| New ASAP Change: create new record for ASAP and Tomorrow |
| Update Record | Update Tomorrow Change: update record for Tomorrow |
| Update Scheduled Change: update record for Scheduled time of Today and Tomorrow |
| Update ASAP Change: update record for ASAP and Tomorrow |
| Delete Record | Delete Tomorrow Change: delete record for Tomorrow |
| Delete Scheduled Change: delete record for Scheduled time of Today and Tomorrow |
| Delete ASAP Change: delete record for ASAP and Tomorrow |
| Withdraw Selected | Withdraw selected record which Records Status is Approved and without Pending withdraw request |
| Export | Search Page: Export all Records up to 60,000 records to CSV file |
| Detail Page: Export Current Record details |
| Detail Page Export Table: Export current table |
| Show History | Show all history of current record |
| Confirm | Confirm the change and submit to backend, disabled with Read-only permission and view mode |
| Cancel | Cancel all changes, disabled with Read-only permission and view mode |

Temp:

| Action | Description |
| --- | --- |
| Screen Open | Trigger a query to display all records |
| Apply | Trigger a query of records based on input filters |
| Reset Filters | Reset all filters to default: All |
| New Record | New ASAP Change: create new record ASAP |
| Update Record | Update ASAP Change: update record ASAP |
| Delete Record | Delete ASAP Change: delete record ASAP |
| Export | Search Page: Export all Records up to 60,000 records to CSV file |
| Detail Page: Export Current Record details |
| Detail Page Export Table: Export current table |
| Show History | Show all history of current record |
| Confirm | Confirm the change and submit to backend, disabled with Read-only permission and view mode |
| Cancel | Cancel all changes, disabled with Read-only permission and view mode |

### Common Validation

**#FS10013\_S0401\_02101**

| Event | Validation Rule | Validation Message |
| --- | --- | --- |
| New Request | Unique identifier must be unique | Duplicated identifier |
| Update Request | Unique identifier cannot be updated | Unique identifier cannot be updated |
| New/Update Request | Any mandatory field is empty | This is a mandatory field |
| Invalid value input | Invalid input |
| Functions should be checked against Appendix 5.4 Maxima Limit if any new record add | Exceed the maximum {column name} |
| Exceed the maximum value of XXX |
| Exceed the minimum value of XXX |
| Delete | No active record depending on the record | Another record depends on current record |

### IPv4 Validation

**#FS10013\_S0401\_02200**

| Event | Validation Rule | Validation Message |
| --- | --- | --- |
| Add/Update IPv4 Address | An address is valid if and only if it is in the form "X.X.X.X", where each X is a number from 0 to 255 | Invalid IP Address |

### Common Notification

**#FS10013\_S0401\_02300**

| Event | Notification |
| --- | --- |
| New Request | Pop up a notification to indicate that a new record has been created |
| Update/Delete Request | Pop up concurrent notification if any concurrent update/delete occurred |
| Concurrent Modification | When concurrent modification is detected to an opened record, a notification will show at the top of record detail screen. |

## Instrument Hierarchy

**#FS10013\_S0402\_00010**

This function is used to create, search, update and delete Instrument related items in Instrument structure.

**#FS10013\_S0402\_00021**

Exchange

Instrument Group

Market

Instrument Type

Underlying

Instrument Class

Instrument

Figure 1 Instrument Hierarchy

Instrument Hierarchy Levels

The following table describes the various Instrument structure levels:

| Level | Description |
| --- | --- |
| Exchange | The identity code of Exchange. E.g., HK |
| Market | Market defines timetables to specify when and where a certain Market is available for trading. One of its properties is Exchange. e.g. HK HSI |
| Instrument Group | The top level of another view of Instrument structure. Its properties define the kind of Instrument to trade, e.g. Futures, American Style Call Options. |
| Instrument Type | Defines what Market and what kind of product to trade by assigning a Market and an Instrument Group as properties, e.g. HK HSI Futures, HK HSI Call Options. |
| Underlying | Specifies the underlying stock, index that the instruments will be based on, e.g. HSI |
| Instrument Class | Defines what Underlying will be used for certain Instrument Types. E.g. HK HSI Call Options (American Style) |
| Instrument | The products to be trade. It is based on an Instrument Class with additional details such as time interval, during which the product will be available for trading, e.g. HSI250110 38600.00 C |

### Maintain Exchange

**#FS10013\_S0402\_00100**

**Description**

**#FS10013\_S0402\_00200**

**Exchange** is used to define exchange and linked exchanges if any. Preloaded in the system is the actual exchange that is the responsible one for all the traded instruments.

It is always set as HK.

**UI Layout**

**#FS10013\_S0402\_00301**

Search Page

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290)) ![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

**Attributes**

**#FS10013\_S0402\_00405**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Exchange ID | Alphanumeric | 2 | M | - | The ID of the Exchange. E.g. HK |
| Description | Alphanumeric | 40 | O | - | Description of the Exchange. |
| Exchange Code | Numeric | 3 | M | - | A unique number to the Exchange.  Range: [1, 254] |
| Short Name | Alphanumeric | 15 | O | - | A unique short name of the Exchange |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0402\_00500**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0402\_00600**

| Action | Description |
| --- | --- |
| - | - |

**Validation (Ref:** [**Common Validation**](#_Common_Validation), [**Validation Rule**](#_Validation_Rule_(TBC))**)**

**#FS10013\_S0402\_00701**

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0402\_00800**

### Maintain Market

**#FS10013\_S0402\_00900**

**Description**

**#FS10013\_S0402\_01000**

**Market** is usedto define the market types, for example, Stock, Index, Currency, etc. It also defines the trading days, trading timetable and block trade parameters.

Trading days, trading timetable and block trade parameters can be defined in **Instrument Type** and **Instrument Class** level as well, those definitions will override those defined in **Market** Level.

**Screen Layout**

**#FS10013\_S0402\_01105**

Search Page

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

**Attributes**

**#FS10013\_S0402\_01208**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Market ID | Alphanumeric | 5 | M | - | The ID of the Market |
| Description | Alphanumeric | 40 | O | - | Description of the Market |
| Market Code | Numeric | 3 | M | - | A unique number to the Market.  Range: [1, 254] |
| Exchange ID | Alphanumeric | 2 | M | - | Read-only in update  The ID of the Exchange to which you want to connect the market. |
| MIC | Alphanumeric | 8 | O | - | The Market Identifier Code for the market. MIC is a unique code according to the ISO 10383 standard. |
| Market Type | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Market Type  The type of products to connect to the market |
| Index? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  ‘Y’ if the Market is an index market, an index of the above-specified type. |
| Dummy? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  ‘Y’ if the Market is a dummy market |
| Traded? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  ‘Y’ - instruments under the market are visible to EP and active for trading.  ‘N’ - instruments are not visible to EP and not available for trading. |
| Normal Trading Days | Numeric | 3 | M | - | The days of the week are normal trading days.  Bitmask to represent available trading days  1 - Mon  10 - Tue  100 - Wed  1000 - Thu  10000 - Fri  100000 - Sat  1000000 - Sun  For Mon to Sun, value - 127 |
| Non-Trading Days ID | Numeric | 5 | O | - | The Non-Trading Days ID for the market |
| Special Trading Days ID | Numeric | 5 | O | - | The Special Trading Days ID for the market |
| Normal Day Timetable ID | Numeric | 5 | M | - | The Normal Day Timetable ID for the market |
| Block Trade MVT ID | Numeric | 5 | O | - | Block Trade MVT ID |
| Priority Number | Numeric | 4 | M | - | A lower value indicates higher priority for the ordering of auction matching.  Range: [1, 1000] |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0402\_01300**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0402\_01400**

| Action | Description |
| --- | --- |
| - | - |

**Validation (Ref:** [**Common Validation**](#_Common_Validation), [**Validation Rule**](#_Validation_Rule_(TBC))**)**

**#FS10013\_S0402\_01501**

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0402\_01600**

### Maintain Instrument Group

**#FS10013\_S0402\_01701**

**Description**

**Instrument Group** is used to define different instruments, e.g. futures, call option, put option, etc.

**Screen Layout**

**#FS10013\_S0402\_01801**

Search Page

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

**Attributes**

**#FS10013\_S0402\_01906**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Instrument Group ID | Alphanumeric | 3 | M | - | The ID of the Instrument Group |
| Description | Alphanumeric | 40 | O | - | Description of this Instrument Group |
| Short Name | Alphanumeric | 15 | M | - | A unique short name for the Instrument Group |
| Instrument Group Code | Numeric | 3 | M | - | A unique number for the Instrument Group.  Range: [1, 254]  The number cannot exist in Combo Group Code. |
| Group Type | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Group Type |
| Physical Delivery? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| Maturity? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  ‘Y’ if the Instrument Group is used for Forward or Futures instruments with maturity.  Maturity decides whether the Instrument has an expiration date or not, i.e. whether the Instrument will expire.  Only informational. |
| Options Type | Char | 1 | O | - | Ref: [Common Attributes](#_Common_Attributes) - Options Type  For options specify if this is a Call or a Put option group. |
| Options Style | Char | 1 | O | - | Ref: [Common Attributes](#_Common_Attributes) - Options Style  For options specify the style of the group. |
| Options Variant | Char | 1 | O | - | Ref: [Common Attributes](#_Common_Attributes) - Options Variant  This attribute is available only when Group Type is Options.  The variant of the options specifies the condition on turnover.   * C - Cap: a limit of max turnover. Deep ITM (in-the-money) options are settled to the cap level * F - Floor: a limit of min turnover. ITM (in-the-money) options are settled at least the floor level. * N - Normal: neither Cap nor Floor limit apply |
| Futures Styled Options? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  For options specify if the group is futures styled.  When ‘Y’, the premium is paid MTM (mark-to-market) each day. Otherwise, it is paid when the trade is executed. |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0402\_02000**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0402\_02100**

| Action | Description |
| --- | --- |
| - | - |

**Validation (Ref:** [**Comm****on Validation**](#_Common_Validation), [**Validation Rule**](#_Validation_Rule_(TBC))**)**

**#FS10013\_S0402\_02201**

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0402\_02300**

### Maintain Instrument Type

**#FS10013\_S0402\_02400**

**Description**

**#FS10013\_S0402\_02500**

**Instrument Type** is created by connecting a **Market** to an **Instrument Group**. An example of an **Instrument Type** is the HKEX Stock Call option.

Always start by defining an **Instrument Type** for the spot, as the derivatives depend on this information.

**Screen Layout**

**#FS10013\_S0402\_02604**

Search Page

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

**Attributes**

**#FS10013\_S0402\_02708**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Instrument Type ID | Alphanumeric | 8 | M | - | The ID of the Instrument Type |
| Description | Alphanumeric | 40 | O | - | Description of this Instrument Type |
| Market ID | Alphanumeric | 5 | M | - | Read-only in update  The ID of the Market that the Instrument Type will be connected to |
| Instrument Group ID | Alphanumeric | 3 | M | - | Read-only in update  The ID of Instrument Group that the Instrument Type will be connected to |
| Traded? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  Specify whether the Instrument Type is tradable or not.  It overrides the Traded attribute from upper levels when their values are ‘Y’.  When the Traded attribute in any one of the upper levels is ‘N’, this value has no effect, instruments under this Instrument Type are not visible to EP and not available for trading. |
| Special Trading Days ID | Numeric | 5 | M | - | Special Trading Days ID that should be connected to  0 means inherit from Market |
| Normal Day Timetable ID | Numeric | 5 | M | - | Normal Day Timetable ID will be connected to  0 means inherit from Market |
| Block Trade Eligible? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  Block trade is eligible or not |
| Identify In Quote Request? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  Identify In Quote Request or not |
| Default Order Size Limit | Quantity | 9 | M | 0 | Default Order Size Limit when granting trading rights to an EP. It overrides the value in Global Param.  4,294,967,295 means inherit from Global Param |
| Default Block Trade Size Limit | Quantity | 9 | M | 0 | Default Block Trade Size Limit when granting trading rights to an EP. It overrides the value in Global Param.  4,294,967,295 means inherit from Global Param |
| Maximum Order Size Limit by EP | Quantity | 9 | M | - | Maximum Order Size Limit by EP  4,294,967,295 means inherit from Global Param |
| Maximum Block Trade Size Limit by EP | Quantity | 9 | M | - | Maximum Block Trade Size Limit by EP  4,294,967,295 means inherit from Global Param |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0402\_02800**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0402\_02900**

| Action | Description |
| --- | --- |
| - | - |

**Validation (Ref:** [**Common Validation**](#_Common_Validation), [**Validation Rule**](#_Validation_Rule_(TBC))**)**

**#FS10013\_S0402\_03001**

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0402\_03100**

### Maintain Underlying

**#FS10013\_S0402\_03200**

**Description**

**#FS10013\_S0402\_03300**

**Underlying** is used to define the underlying of the instruments to be registered.

**Screen Layout**

**#FS10013\_S0402\_03403**

Search Page

![](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))

![](data:image/png;base64...)

**Attributes**

**#FS10013\_S0402\_03513**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Underlying ID | Alphanumeric | 6 | M | - | The ID of the Underlying |
| Description | Alphanumeric | 40 | O | - | Description of the Underlying |
| Underlying Code | Numeric | 5 | M | - | A unique number to the Underlying.  Range: [1, 65534] |
| ME Partition ID | Numeric | 5 | M | - | ME Partition ID |
| Status | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Status |
| Underlying Type | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Underlying Type |
| Index? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| Underlying Issuer | Alphanumeric | 6 | M | - | The issuer company short name for the underlying.  This attribute is used for choosing associated Instrument for Capital Adjustment. |
| MMP Enabled? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  ‘Y’ if MMP (Market Maker Protection) is enabled, else ‘N’ |
| Minimum MMP Quantity | Quantity | 9 | O | 0 | The minimum quantity for the Underlying the quantity protection and delta protection in **Market Maker Protection** must exceed. |
| Price Decimals | Numeric | 5 | M | - | The decimal places of price stored in the system for this underlying. |
| Currency | Alphanumeric | 3 | M | - | The currency that the price of the underlying is based on. |
| CA Created? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  Indicate the underlying is created by CA process.  A CA created underlying with all Instrument / Combo passed last trading date is subject to be reused.  Reuse of CA created underlying is described in FS10003 - Capital Adjustment - Phase 1 - New Underlying. |
| CA Spin-off In Progress? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  Indicates the state of spin-off Capital Adjustment. Details in FS10003. |
| CA Reuse Cool-off Date | - | - | - | - | Read-only field.  Used for CA created underlying only. The field is empty for manually created underlying.  When the underlying is CA Created and all relevant instruments are passed the last trading date, a day end batch job will mark the cool-off date based on the CA re-use cool-off period. CA process will not reuse this underlying on or before this date.  CA Re-use Cool-off Period is described in FS10003 - Capital Adjustment - Phase 1 - New Underlying. |
| CA Priority | Numeric | 5 | M | 0 | CA Priority  Read Only. Assigned by System during CA. |
| Data Source | Numeric | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Data Source |
| Data Source Symbol Code | Numeric | 5 | O | - | Applicable if Data Source = 1 or 2  For Data Source = 1(OMD-C):  Range: [1, 99999]  For Data Source = 2(OMD-I):  ASCII characters with max length = 11 |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0402\_03600**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0402\_03700**

| Action | Description |
| --- | --- |
| - | - |

**Validation (Ref:** [**Common Validation**](#_Common_Validation), [**Validation Rule**](#_Validation_Rule_(TBC))**)**

**#FS10013\_S0402\_03801**

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0402\_03900**

### Maintain Instrument Class

**#FS10013\_S0402\_04000**

**Description**

**#FS10013\_S0402\_04103**

An **Instrument Class** is created by connecting an **Instrument Type** to an **Underlying**. An example of an **Instrument Class** is HSI Call Options.

**Instrument Class Price Tick Limit** will be created/deleted together with **Instrument Class** creation/deletion.

**Screen Layout**

**#FS10013\_S0402\_04209**

Search Page

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))

![](data:image/png;base64...)![](data:image/png;base64...)

**Attributes**

**#FS10013\_S0402\_04314**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Instrument Class ID | Alphanumeric | 14 | M | - | The ID of the Instrument Class |
| Description | Alphanumeric | 40 | O | - | Description of the Instrument Class, for example, HSI Call Options |
| Instrument Type ID | Alphanumeric | 8 | M | - | Read-only in update  The ID of the Instrument Type that the Instrument Class should be connected to |
| Underlying ID | Alphanumeric | 6 | M | - | Read-only in update  The ID of the Underlying that the Instrument Class should be connected to |
| Traded? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  It overrides the Traded attribute from upper levels when their values are ‘Y’.  When the Traded attribute in any one of the upper levels is ‘N’, this value has no effect, instruments under this Instrument Class are not visible to EP and not available for trading. |
| Currency | Alphanumeric | 3 | M | - | The ID of the currency for the order book prices. |
| Settlement Currency | Alphanumeric | 3 | M | - | The ID of the settlement currency for the order book prices |
| Price Tick ID | Numeric | 5 | M | - | The ID of the Price Tick |
| Price Tick Limit ID | Numeric | 5 | O | - | The ID of the Price Tick Limit |
| Auto Price Tick Limit Update? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  ‘Y’ to enable auto price tick limit update, else disable |
| Corresponding Instrument Class For Price Tick | Alphanumeric | 14 | O | - | A reference to another Instrument Class representing the Corresponding Instrument Class for Price Tick Limit calculation |
| Price Limit ID | Numeric | 5 | O | - | The ID of Price Limit |
| VCM ID | Numeric | 5 | O | - | The VCM Rules for the Instrument Class |
| AHT Reference Price Futures Group ID | Numeric | 5 | O | - | The AHT Reference Price Futures Group ID |
| Corresponding Instrument Class For AHT Reference Price | Alphanumeric | 14 | O | - | A reference to another Instrument Class representing the Corresponding Instrument Class For AHT Reference Price calculation |
| Price Quotation Factor | Numeric | 10 | M | - | The contract multiplies to an underlying index in price value of instruments under this Instrument Class.  E.g. 50 for HK$50 per index point.  ~~The value is for reference data to EP and downstream systems.~~  ~~Capital Adjustment may modify the value.~~ |
| Contract Size | Numeric | 10 | M | - | The number of units of the underlying value that concerns one unit of the instrument.  ~~The Contract size is multiplied by the quantity of a trade to receive the total number of underlying in the trade.~~  *~~Example:~~*  ~~Buying 10 call options with contract size 50 will give you the right to buy 10 \* 50 - 500 of the underlying value.~~ |
| Decimals For Contract Size & PQF | Numeric | 2 | M | - | Number of decimals used in the Contract Size and Price Quotation Factor |
| Decimals For Strike Price | Numeric | 2 | M | - | Number of decimals used in Strike Price |
| Special Trading Days ID | Numeric | 5 | M | - | Special Trading Days ID that should be connected to the Instrument Class. ~~In Special Trading Days~~~~dates when trading session should differ from normal days are specified.~~  ~~This is optional and overrides any Special Trading Days connected on Instrument Type or Market level.~~  *~~Note:~~*  ~~If Normal days is specified any Exception days must also be specified for the instrument class.~~  0 means inherit from Instrument Type |
| Normal Day Timetable ID | Numeric | 5 | M | - | Normal Day Timetable ID that should be connected to the Instrument Class for days when the market closes at normal time  ~~This is optional and overrides any Trading Session connected to Instrument Type or Market level.~~  0 means inherit from Instrument Type |
| Block Trade Eligible? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  ‘Y’ if Block Trade Eligible, else ‘N’  It overrides the value in upper level.  <space> means inherit from Instrument Type |
| Block Trade MVT ID | Numeric | 5 | O | - | Applicable if Block Trade Eligible? = Y.  It overrides the value in upper level.  0 means inherit from Market |
| Block Trade Static Price Limit? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  ‘Y’ if Block Trade Static Price Limit, else ‘N’ |
| Lot Size | Quantity | 9 | M | - | The round lot size (number of contracts) in order entry quantity for Instruments under this Instrument Class. |
| Name Standard ID | Numeric | 10 | M | - | Name Standard ID |
| Automatic Generation? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  It can be changed to ‘Y’ if its Group Type is   * O - Options or * U - Futures   and Auto Instrument Generation Rule ID is filled out |
| Auto Instrument Generation Rule ID | Numeric | 10 | O | - | Auto Instrument Generation Rule ID |
| Last CA Effective Date | - | - | - | - | Read-only field.  It indicates the effective date of the last CA Phase 2 process.  This attribute is used to identify an Instrument Class went through CA Phase 2, the Instruments for next trading date are already generated. Auto generation will be skipped. Details in FS10003 Capital Adjustment section. |
| Cycle Block Frozen Date | Date | 11 | O | - | Cycle Block Frozen Date  Instrument Generation will stop generating new Instruments of cycles after this date. |
| Furthest Expiry Date | Date | 11 | O | - | Furthest Expiry Date  The latest available date that an Effective Last Trading Date can be assigned to an Instrument. (User can bypass this by confirm the warning prompt) |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0402\_04400**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0402\_04500**

| Action | Description |
| --- | --- |
| - | - |

**Validation (Ref:** [**Common Valid****ation**](#_Common_Validation), [**Validation Rule**](#_Validation_Rule_(TBC))**)**

**#FS10013\_S0402\_04601**

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0402\_04700**

### Maintain Instrument

**#FS10013\_S0402\_04800**

**Description**

**#FS10013\_S0402\_04900**

**Instrument** is the product that is open for trading and clearing.

**Screen Layout**

**#FS10013\_S0402\_05005**

Search Page

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))

![](data:image/png;base64...)

![](data:image/png;base64...)

**Attributes**

**#FS10013\_S0402\_05117**

| Column | Type | Length | M/O | Default | Remarks | |
| --- | --- | --- | --- | --- | --- | --- |
| Instrument ID | Alphanumeric | 32 | O | - | If input Instrument ID violates the Instrument Name Standard, a warning message will pop up.  If it is empty when creating an Instrument, the system will generate the ID automatically using the defined Instrument Name Standard connected to the actual class to which you will connect the Instrument.  The current active Instrument Name Standard will be used.  The ID cannot exist in Combo ID.  **Supported Characters:**   * A-Z * 0-9 * ./\_- | |
| Instrument Class ID | Alphanumeric | 14 | M | - | Instrument Class ID the Instrument should be connected to | |
| Strike Price | Price | 19  (Additionally, plus 1 if include “- “or “.”) | M | - | The strike price of the options instrument.  For non-options, the price should be 0.  The assignment of value by automatic generation.  It is a component of legacy Instrument ID. |
| Traded? | Char | 1 | M | Y | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  Specify if the Instrument is tradable or not.  It overrides the Traded attribute from upper levels when their values are ‘Y’.  When the Traded attribute in any one of the upper levels is ‘N’, this value has no effect, this instrument is not visible to EP and not available for trading.  Unless specified explicitly, new instruments are having value ‘Y’. i.e. Visible to market and available for trading. | |
| Effective Date | Date | 11 | M | - | Read-only field.  The date that this instrument is effective in the system.  If the instrument creation is immediately effective and the current calendar date is a trading date, the value will be the current date. Otherwise, it will be the next trading date. |
| Status | Char | 1 | M | A | Ref: [Common Attributes](#_Common_Attributes) - Status  Unless specified explicitly, new instruments are having value Active. | |
| Effective Status | - | - | - | - | Read-only field.  For an instrument to be effectively allowed for trading, it must be Active in both:   * + Instrument Status and,   + Underlying Status   Either one of the above statuses is S - Suspended, this field will be S - Suspended | |
| First Trading Date | Date | 11 | O | - | The first day the instrument can be traded. | |
| First Trading Time | Numeric | 6 | O | - | The beginning of the first trading date the instrument can be traded.  UI format: hh:mm:ss  When empty, the instrument starts trading according to the trading timetable. | |
| Last Trading Date | Date | 11 | M | - | The final day the instrument can be traded.  It replaced Expiration Date as a component of legacy Instrument ID. | |
| Effective Last Trading Date | Date | 11 | M | - | As the Last Trading Date is a component of legacy Instrument ID, and Last Trading Date should not be amended due to Last Trading Date changes.  This attribute will be used for the Last Trading Date reference for both EP, downstream systems and trading system instrument operation.  Unless specified explicitly, new instruments have the Effective Last Trading Date, the same as Last Trading Date. To adjust to the final day the instrument can be traded, this attribute should be changed. | |
| Last Trading Time | Numeric | 6 | O | - | The final time on the last trading date the instrument can be traded.  UI format: hh:mm:ss  When empty, the instrument ends trading according to the trading timetable. | |
| Modifier | Numeric | 2 | M | - | Read-only field.  It is a component of legacy Instrument ID.  New instruments are having value 0. Capital Adjustment on the instrument will have the value increased by 1. | |
| Price Quotation Factor | Numeric | 10 | O | - | The contract multiplies to the underlying index in price value of the instrument.  New Instruments have value copied from Instrument Class.  The value is for reference data to EP and downstream system. Capital Adjustment may modify the value detailed in FS10003.  4,294,967,295 means inherit from Instrument Class | |
| Contract Size | Numeric | 10 | O | - | The Contract Size for the Instrument, set automatically if the Instrument is created from an issue where the Contract Size of the new Instrument is changed compared to the old Instrument.  It is also set automatically if Keep on Instrument  Level/Contract size and Price Quotation Factoris selected for the Instrument Class.  4,294,967,295 means inherit from Instrument Class | |
| ISIN | Alphanumeric | 12 | O | - | ISIN of the Instrument. A 12-character alphanumeric code.  The field will be left blank when the instrument is created by automatic generation. | |
| SEDOL | Alphanumeric | 7 | O | - | SEDOL of the Instrument. A seven-character alphanumeric code.  The field will be left blank when the instrument is created by automatic generation. | |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0402\_05200**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0402\_05300**

| Action | Description |
| --- | --- |
| - | - |

**Validation (Ref:** [**Common Validation**](#_Common_Validation), [**Validation Rule**](#_Validation_Rule_(TBC))**)**

**#FS10013\_S0402\_05401**

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0402\_05500**

### Maintain Instrument Name Standard

**#FS10013\_S0402\_05600**

**Description**

**#FS10013\_S0402\_05700**

**Instrument Name Standard** is used to define name standard for instruments.

**Screen Layout**

**#FS10013\_S0402\_05802**

Search Page

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

**Attributes**

**#FS10013\_S0402\_05903**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Instrument Name Standard ID | Numeric | 10 | M | - | The ID of the Instrument Name Standard ID |
| Name | Alphanumeric | 12 | M | - | The name of the Instrument Name Standard ID |
| Description | Alphanumeric | 40 | O | - | Description |
| Type | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Name Standard Type  Can be Futures/Options only |
| Name Standard Items | - | - | - | - | Name Standard Items |

**Name Standard Item Attributes**

**#FS10013\_S0402\_06003**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Category | Numeric | 1 | M | - | Category of Name Standard item.  1 - Underlying  2 - Last Trading Date  3 - Free Text  4 - Short name instrument group  5 - Contract size  6 - Strike price integer part (only for Options Type)  7 - Strike price decimal part (only for Options Type) |
| Number of Characters | Numeric | 2 | O | - | Number of Characters.  **Applicable to the following Category:**  1 - Underlying  4 - Short name instrument group  6 - Strike price integer part (only for Options Type)  7 - Strike price decimal part (only for Options Type |
| Name Standard Date Format | Numeric | 1 | O | - | Name Standard Date Format.  1 - Year (YYYY)  2 - Year (YY)  3 - Year (Y)  4 - Month code  5 - Month number (NN)  6 - Month name (MMM)  7 - Date (DD)  8 - Week number (WW)  9 - Week Year (yyyy)  10 - Week Year (yy)  11 - Week Year (y)  **Applicable to the following Category:**  2 - Last Trading Date |
| Free Text | Alphanumeric | 32 | O | - | Free Text  **Applicable to the following Category:**  3 - Free Text  Supported Characters:   * A-Z * 0-9 * ./\_ |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0402\_06100**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0402\_06200**

| Action | Description |
| --- | --- |
| - | - |

**Validation (Ref:** [**Common Validation**](#_Common_Validation)**)**

**#FS10013\_S0402\_06301**

| Event | Validation Rule | Validation Message |
| --- | --- | --- |
| Add | The Maximum number of rows is 32. | The maximum number of rows in Inst. Name Standard Item table had been reached. |
| Remove | The minimum number of rows is 1. | Please input at least 1 row to the Inst. Name Standard Item table. |
| Confirm | The minimum number of rows is 1. | Please input at least 1 row to the Inst. Name Standard Item table. |

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0402\_06400**

### Maintain Access Group By Type

**#FS10013\_S0402\_06501**

**Description**

**#FS10013\_S0402\_06601**

**Access Group By Type** is used to define a grouping which includes **Instrument Type** and **Combo Type**.

**Screen Layout**

**#FS10013\_S0402\_06700**

Search Page

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

**Attributes**

**#FS10013\_S0402\_06803**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Access Group By Type ID | Numeric | 5 | M | - | A unique ID for Access Group Type |
| Name | Alphanumeric | 12 | M | - | A unique name of the Access Group Type |
| Description | Alphanumeric | 40 | O | - | Description of the Access Group Type |
| Instrument Type ID | Alphanumeric | 8 | O | - | List of Instrument Type ID |
| Combo Type ID | Alphanumeric | 8 | O | - | List of Combo Type ID |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0402\_06900**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0402\_07000**

| Action | Description |
| --- | --- |
| - | - |

**Validation (Ref:** [**Common Validation**](#_Common_Validation), [**Validation Rule**](#_Validation_Rule_(TBC))**)**

**#FS10013\_S0402\_07101**

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0402\_07200**

## Combo Hierarchy

**#FS10013\_S0403\_00100**

Exchange

Combo Group

Market

Combo Type

Underlying

Combo Class

Combo

### Maintain Combo Group

**#FS10013\_S0403\_00200**

The Combo Group is a classification of combo to trade.

In this deferred function, user can create a new Combo Group or edit/delete an existing Combo Group from Administration Database.

**Screen Layout**

**#FS10013\_S0403\_00301**

Search Page

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

**Attributes
#FS10013\_S0403\_00403**

| **Column** | **Type** | **Length** | **M/O** | **Default** | **Remarks** |
| --- | --- | --- | --- | --- | --- |
| **Identity** | | | | | |
| Combo Group ID | Alphanumeric  **Text Input** | 3 | M | - | A unique ID representing the combo group. |
| Combo Group Code | Numeric  **Text Input** | 3 | M | - | A unique number for the Combo Group within the range 1-255.  The number cannot exist in the Instrument Group Code. |
| Short Name | Alphanumeric  **Text Input** | 15 | M | - | A unique short name of the combo group.  It is used to name combo instruments in Automatic Instrument Generation for Combo - Instrument Name Standard. |
| Description | Alphanumeric  **Text Input** | 40 | O | - | Description of the instrument group. The attribute is optional and informational only. |
| Tailor Made Only? | Boolean  **Dropdown** | 1 | M | - | A true/false attribute. When the value is true, it indicates combo instruments under this combo group are TMC only. Otherwise, only standard combo is allowed. |
| Time Spread Level | Numeric  **Text Input** | 3 | O | - | A number representing the time spread level of Combo under this Combo Group. The time spread level must be unique when defined.  It is used for selecting Combo Class in Automatic Instrument Generation for Combo. |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0403\_00500**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0403\_00600**

| Action | Description |
| --- | --- |
| - | - |

**Validation (Ref:** [**Common Validation**](#_Common_Validation)**)**

**#FS10013\_S0403\_00700**

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0403\_00800**

### Maintain Combo Type

**#FS10013\_S0403\_00900**

The Combo Type is an entity that groups a Market and a Combo Group.

In this deferred function, user can create a new Combo Type or edit/delete an existing Combo Type from Administration Database.

**Screen Layout**

**#FS10013\_S0403\_01004**

Search Page

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

Detail Page

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

**Attributes**

**#FS10013\_S0403\_01110**

| **Column** | **Type** | **Length** | **M/O** | **Default** | **Remarks** |
| --- | --- | --- | --- | --- | --- |
| **Identity** | | | | | |
| Combo Type ID | Alphanumeric  **Text Input** | 8 | M | - | A unique ID representing the combo type. |
| Market ID | Alphanumeric  **Text Input**  **(With Content Assist)** | 5 | M | - | The ID of the market this combo type belongs to and is non-editable in edit mode. |
| Combo Group ID | Alphanumeric  **Text Input**  **(With Content Assist)** | 3 | M | - | The ID of the Combo Group this combo type belongs to and is non-editable in edit mode. |
| Description | Alphanumeric  **Text Input** | 40 | O | - | Description of the combo type. The attribute is optional and informational only. |
| **General** | | | | | |
| Allow Different Price Quotation Factor? | Boolean  **Dropdown** | 1 | M | - | When the value is true, it indicates combos under the Combo Type allow leg instruments with different price quotation factor. Otherwise, the leg instruments in the combo must have the same price quotation factor. |
| Allow GTC And GTD Order? | Boolean  **Dropdown** | 1 | M | - | When true, order time validity GTC and GTD are allowed for combos under this Combo Type. Otherwise, GTC and GTD orders are rejected. |
| **Calendar** | | | | | |
| Special Trading Days ID | Numeric  **Text Input**  **(With Content Assist)** | 5 | M | - | The ID of Special Trading Days configuration overrides those from first leg.  0 means inherit from the first leg. |
| Normal Day Timetable ID | Numeric  **Text Input**  **(With Content Assist)** | 5 | M | - | The ID of Normal Day Timetable configuration overrides those from first leg.  0 means inherit from the first leg. |
| **TMC** | | | | | |
| TMC Strategy List ID | Numeric  **Text Input**  **(With Content Assist)** | 5 | O | - | The ID of the TMC Strategy List for combo instrument under this combo type.  There is a system defined Strategy list “0 – No restriction” indicate no restriction.  **The attribute is available and mandatory only when the Combo Group is for Tailor made only.** |
| TMC Allow Cross Market? | Boolean  **Dropdown** | 1 | M | - | A true/false attribute indicates TMC leg instruments allowed in different Market.  **The attribute is available and mandatory only when the Combo Group is for Tailor made only.** |
| TMC Max Ratio | Numeric  **Text Input** | 5 | O | - | The max ratio allowed amongst all TMC combo legs for combos under this Combo Type.  Max allowed value is 10000.  **The attribute is available and mandatory only when the Combo Group is for Tailor made only.** |
| TMC Max Ratio Difference | Numeric  **Text Input** | 5 | O | - | The max ratio difference allowed between TMC combo legs for combos under this Combo Type.  Max allowed value is 10000.  **The attribute is available and mandatory only when the Combo Group is for Tailor made only.** |
| TMC Number Retention Days | Numeric  **Text Input** | 5 | O | - | The number of retention days until the TMC number can be reused.  **The attribute is available and mandatory only when the Combo Group is for Tailor made only.** |
| TMC Expiration Period | Numeric | 1 | O | - | Ref: [Common Attributes](#_Common_Attributes) - TMC Expiration Period  **The attribute is available and mandatory only when the Combo Group is for Tailor made only.** |
| **Trading Parameters** | | | | | |
| Block Trade Eligible? | Boolean  **Dropdown** | 1 | M | - | Indicates instruments under this Combo Type are eligible for block trade. |
| Name Standard ID | Numeric  **Text Input** | 10 | O | - | A reference to Name Standard configuration for combos under this Combo Type. |
| Identify In Quote Request? | Boolean  **Dropdown** | 1 | M | - | When true, Quote Requests for Combo under this Combo Type forwarded to market will include EP ID of the request sender. Otherwise, the information is not available to the market. |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0403\_01200**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0403\_01300**

| Action | Description |
| --- | --- |
| - | - |

**Validation (Ref:** [**Common Validation**](#_Common_Validation)**)**

**#FS10013\_S0403\_01400**

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0403\_01500**

### Maintain Combo Class

**#FS10013\_S0403\_01604**

The Combo Class defines instruments of a specific combo type on an underlying by associating a combo type and an underlying entity.

In this deferred function, user can create a new Combo Class or edit/delete an existing Combo Class from Administration Database.

**Combo Class Price Tick Limit** will be created/deleted together with **Combo Class** creation/deletion.

**Screen Layout**

**#FS10013\_S0403\_01705**

Search Page

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

**Attributes**

**#FS10013\_S0403\_01808**

| **Column** | **Type** | **Length** | **M/O** | **Default** | **Remarks** |
| --- | --- | --- | --- | --- | --- |
| **Identity** | | | | | |
| Combo Class ID | Alphanumeric  **Text Input** | 14 | M | - | A unique ID representing the combo class. |
| Underlying ID | Alphanumeric  **Text Input**  **(With Content Assist)** | 6 | M | - | The ID of the Underlying for Leg 1 and is non-editable in edit mode.  Leg 1 is defined by the first leg after sorting by the name (alphabetical) of Instrument Class Name. |
| Combo Type ID | Alphanumeric  **Text Input**  **(With Content Assist)** | 8 | M | - | The ID of the Combo Type this Combo Class belongs to and is non-editable in edit mode. |
| Description | Alphanumeric  **Text Input** | 40 | O | - | Description of the combo class. The attribute is optional and informational only. |
| **General** | | | | | |
| Implied? | Boolean  **Dropdown** | 1 | M | - | To enable or disable imply order generation. |
| **Calendar** | | | | | |
| Special Trading Days ID | Numeric  **Text Input**  **(With Content Assist)** | 5 | M | - | The ID of Special Trading Days configuration overrides those from first leg.  0 means inherit from Combo Type |
| Normal Day Timetable ID | Numeric  **Text Input**  **(With Content Assist)** | 5 | M | - | The ID of Normal Day Timetable configuration overrides those from first leg.  0 means inherit from Combo Type |
| **Price** | | | | | |
| Currency | Char  **Text Input** | 3 | M | - | The ISO 4217 currency code.  This attribute is for informational only and will be included in reference data to EP. |
| Auto Price Tick Limit Update? | Boolean  **Dropdown** | 1 | M | - | To enable/disable the Auto Price Tick Limit update. |
| Price Tick Limit ID | Numeric  **Text Input**  **(With Content Assist)** | 5 | O | - | The ID of Price Tick Limit configuration that assigns to instruments under this Combo Class. |
| Price Tick ID | Numeric  **Text Input**  **(With Content Assist)** | 5 | M | - | The ID of Price Tick configuration that assigns to combos under this Combo Class for minimum price fluctuation. |
| **Auto Generation** | | | | | |
| Auto generation? | Boolean  **Dropdown** | 1 | M | - | To enable/disable combo automatic generation for this combo class.  It can be changed to ‘Y’ when updating Combo Class if  below fields in Maintain Auto Generation Rule for Combo are filled:   * Unit * Pre-launch Days * One-off Pre-launch |
| **Trading Parameters** | | | | | |
| Lot Size | Quantity  **Text Input** | 9 | M | - | The lot size (number of contracts) for combo under this combo class. |
| Block Trade Minimum Volume Thresholds | Quantity  **Text Input** | 9 | O | - | The minimum volume thresholds for Block Trade. It overrides the value in upper levels.  **It is only available when Block Trade Eligible? is true.** |
| Traded? | Boolean  **Dropdown** | 1 | M | - | It overrides the Traded attribute from upper levels when their values are true.  When the Traded attribute in any one of the upper levels is false, this value has no effect, Combo under this Combo Class are not visible to EP and not available for trading. |
| Block Trade Eligible? | Boolean  **Dropdown** | 1 | M | - | Indicates Combo under this Combo Class are eligible for block trade. It overrides the one from the upper level.  <space> means inherit from Combo Type |
| Name Standard ID | Numeric  **Text Input** | 10 | M | - | A reference to Name Standard configuration for combos under this Combo Class.  It overrides the value in upper levels.  0 means inherit from Combo Type. |
| **TMC** | | | | | |
| TMC Expiration Period | Numeric | 1 | O | - | Ref: [Common Attributes](#_Common_Attributes) - TMC Expiration Period  It overrides the value in upper levels.  **The attribute is available and mandatory only when the Combo Group is for Tailor made only.**  0 means inherit from Combo Type |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0403\_01900**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0403\_02000**

| Action | Description |
| --- | --- |
| - | - |

**Validation (Ref:** [**Common Validation**](#_Common_Validation)**)**

**#FS10013\_S0403\_02100**

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0403\_02200**

### Maintain Combo

**#FS10013\_S0403\_02300**

The Combo defines the exact contract spec of a tradable instrument. It inherits attributes from the parent Instrument Class with additional attributes listed in table below.

In this deferred function, user can generate new Combo or edit/delete an existing Combo from Administration Database.

**Screen Layout**

**#FS10013\_S0403\_02405**

Search Page

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))

![](data:image/png;base64...)

**Attributes**

**#FS10013\_S0403\_02510**

| **Column** | **Type** | **Length** | **M/O** | **Default** | **Remarks** |
| --- | --- | --- | --- | --- | --- |
| **Identity** | | | | | |
| Combo ID | Alphanumeric  **Text Input** | 32 | O | - | A unique ID representing the combo instrument.  If this field is left empty the system will generate the name automatically using the defined Combo Name Standard connected to the actual combo class/type to which you will connect the Combo.  The current active Combo Name Standard will be used.  **Read-only for TMC.**  **Supported Characters:**   * A-Z * a-z * 0-9 * ./\_- |
| Combo Class ID | Alphanumeric  **Text Input**  **(With Content Assist)** | 14 | M | - | The ID of the Combo Class this Combo belongs to and is non-editable in edit mode  **Read-only for TMC.** |
| **General** | | | | | |
| Status | Char  **Dropdown** | 1 | M | A | The Combo status, valid values are:  A = Active The combo is available for trading.  S = Suspended The combo is suspended from trading.  D = Delisted The TMC had been delisted. (Only applicable to TMC and it’s read only. TMC can only delist via Control TMC function.)  For a combo to be effectively allowed for trading, it must be Active in both:   1. Combo Statue (this attribute) and, 2. Instrument Status on all legs.   Unless specified explicitly, new combos are having value Active. |
| Effective Status  (Not exist in RDB) | Char  **Dropdown** | - | - | - | This field shows the effective status by combining the Combo Status and Instrument Status on all legs.  The value determination follows the below rules sequentially:  1. Combo is delisted: Delisted.  2. Either one is suspended: Suspended.  3. Active.  **This is a display-only / read-only field.** |
| Effective Date | Date  **Date** | - | - | - | The date that this combo is effective in the system.  **If the combo creation is immediately effective and the current calendar date is a trading date, the value will be the current date. Otherwise, it will be the next trading date.**  **Read-only. This field is filled by System.** |
| Tailor Made Only? | Char  **Dropdown** | - | - | - | **Read-only**. This field is the copy of the Tailor Made Only? Field from the linked Combo Group in the hierarchy. |
| **Dates** | | | | | |
| Last Trading Date | Date  **Date** | 11 | M | - | The final day the instrument can be traded.  The last trading date and time must be earlier than or equal to the earliest last trading date and time in any one of the legs.  Auto generated Combos are having value assigned.  **Read-only for TMC.** |
| Effective Last Trading Date | Date  **Date** | 11 | M | - | As the Last Trading Date is a component of legacy combo ID, and ID should not be amended due to Last Trading Date changes.  This attribute will be used for Last Trading Date reference for both EP, downstream systems and trading system instrument operation.  Unless specified explicitly, new combos have the Effective Last Trading Date same as Last Trading Date. To adjust the final day the combo can be traded, this attribute should be changed.  **Read-only for TMC.** |
| Last Trading Time | Time  **Time Selection Drop Down** | 8 | O | - | The final time on the last trading date the combo can be traded.  The last trading date and time must be earlier than or equal to the earliest last trading date and time in any one of the legs.  Auto generated Combos are having value assigned.  **Read-only for TMC.** |
| First Trading Date | Date  **Date** | 11 | O | - | The first day the instrument can be traded.  The first trading date and time must be later than or equal to the latest first trading date and time in any one of the legs.  Auto generated Combos are having value assigned.  **Read-only for TMC.** |
| First Trading Time | Time  **Time Selection Drop Down** | 8 | O | - | The beginning time on the first trading date the combo can be traded.  The first trading date and time must be later than or equal to the latest first trading date and time in any one of the legs.  This attribute is optional. When empty, the combo starts trading according to the trading timetable.  Auto generated Combos are having value assigned.  **Read-only for TMC.** |
| **Modified Values** | | | | | |
| Modifier | Numeric | 5 | M | 0 | It is a component of legacy Instrument ID.  New instruments are having value 0. Capital Adjustment on the instrument will have the value increased by 1.  **Read-only** |
| **Combo Leg** | | | | | |
| Number of Legs | Numeric  **Text Input** | 5 | M | - | Number of Legs.  **Not Editable  (Calculated by System)** |
| **Combo Leg** | | | | | |
| Leg Number | Numeric  **Dropdown** | 5 | M | - | Specify the leg number.  Leg Number from 1 to 4.  Leg number must be in a sequence of 1, 2, 3, 4.  **Read-only for TMC.** |
| Operation | Char  **Dropdown** | 1 | M | - | The operation of the Leg.  Ref: [Common Attributes](#_Common_Attributes)  - Side Char  The valid values are:   1. B – Buy the leg instrument when buying the Combo. 2. S – Sell the leg instrument when buying the Combo.   **Read-only for TMC.** |
| Ratio | Numeric  **Text Input** | 5 | M | - | The ratio of the Leg.  Valid Values:  1 to 10000  **Read-only for TMC.** |
| Leg Instrument ID | Alphanumeric  **Text Input**  **(With Content Assist)** | 32 | M | - | The ID of instrument for the Leg.  **Read-only for TMC.** |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0403\_02600**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0403\_02700**

| Action | Description |
| --- | --- |
| - | - |

**Validation (Ref:** [**Common Va****lidation**](#_Common_Validation)**)**

**#FS10013\_S0403\_02800**

| Event | Validation Rule | Validation Message |
| --- | --- | --- |
| Update Request | TMC in scheduleed status is not allowed to change to other status. | Cannot change the status of a Delisted TMC. |
| Status of normal Combos could not be Delisted. | Cannot set Combo status to Delisted. |

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0403\_02900**

### Maintain Combo Name Standard

**#FS10013\_S0403\_03000**

**Description**

**#FS10013\_S0403\_03100**
The name standard ensures that each Combo instrument has a unique name by combining various properties.

This function is used to create/update/delete Combo Name Standard.

**UI Layout**

**#FS10013\_S0403\_03202**

Search Page

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

**Attributes**

**#FS10013\_S0403\_03301**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Combo Name Standard ID | Numeric | 10 | M | - | The ID of the Combo Name Standard ID |
| Name | Alphanumeric | 12 | M | - | The name of the Combo Name Standard ID |
| Description | Alphanumeric | 40 | O | - | Description |
| Type | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Name Standard Type  Can be Combo only |
| Name Standard Items | - | - | - | - | Name Standard Items |

**General Table Attributes**

**#FS10013\_S0403\_03405**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Category | Numeric | 1 | M | - | Category of Name Standard item.  1 - Underlying  2 - Last Trading Date  3 - Free Text  4 - Short Name Instrument Group  5 - Contract Size  6 - Strike Price Integer Part *(only for Options Type)*  7 - Strike Price Decimal Part *(only for Options Type)*  8 - Short Name Strategy  9 - Short Name Combo Group |
| Number of Characters | Numeric | 1 | O | - | Number of Characters.  **Applicable to the following Category:**  1 – Underlying  4 - Short name instrument group  6 - Strike price integer part  7 - Strike price decimal part  8 - Short name strategy  9 - Short name combo group |
| Name Standard Date Format | Numeric | 1 | O | - | Name Standard Date Format.  1 - Year (YYYY)  2 - Year (YY)  3 - Year (Y)  4 - Month code  5 - Month number (NN)  6 - Month name (MMM)  7 - Date (DD)  8 - Week number (WW)  9 - Week Year (yyyy)  10 - Week Year (yy)  11 - Week Year (y)  **Applicable to the following Category:**  2 - Last Trading Date |
| Free Text | Alphanumeric | 32 | O | - | Free Text  **Applicable to the following Category:**  3 - Free Text  Supported Characters:   * A-Z * 0-9 * ./\_ |
| Leg Number | Numeric | 1 | O | - | Reference Leg Number.  Not required for Free Text, Short name combo group and Short name strategy. For other Categories, this field is Mandatory.  Allow 1 – 4 only. |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0403\_03500**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0403\_03600**

| Action | Description |
| --- | --- |
| Add | Add a row to the Table. |
| Delete | Delete the selected row from the Table. |
| Up | Move the selected row up by one row.  (Only one row at a time, System will reassign the position.) |
| Down | Move the selected row down by one row.  (Only one row at a time, System will reassign the position.) |

**Validation (Ref:** [**Common Validation**](#_Common_Validation)**)**

**#FS10013\_S0403\_03701**

| Event | Validation Rule | Validation Message |
| --- | --- | --- |
| Add | The Maximum number of rows is 32. | The maximum number of rows in Combo Name Standard Item table had been reached. |
| Remove | The minimum number of rows is 1. | Please input at least 1 row to the Combo Name Standard Item table. |
| Confirm | The minimum number of rows is 1. | Please input at least 1 row to the Combo Name Standard Item table. |

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0403\_03800**

## Auto Instrument Generation

**#FS10013\_S0404\_00100**

### Maintain Auto Generation Rule

**#FS10013\_S0404\_00200**

**Description**

**#FS10013\_S0404\_00303**

Automatic Instrument Generation creates Instruments based on configuration rules which describe the contract attributes.

This function is used to create/update/delete the Auto Instrument Generation Rule.

**UI Layout**

**#FS10013\_S0404\_00404**

Search Page

![](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Current_Record_and))

![](data:image/png;base64...)

**Attributes**

**#FS10013\_S0404\_00510**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| **Identity** | | | | | |
| Auto Instrument Generation Rule ID | Numeric  **Text Input** | 10 | M | - | The unique ID of the Auto Instrument Generation Rule. Not editable. |
| Description | Alphanumeric  **Text Input** | 40 | O | - | Description of the Auto Instrument Generation Rule |
| **General** | | | | | |
| Until Days to Last Trading | Numeric  **Text Input** | 2 | M | 0 | Define a period in trading days before the contract’s last trading date which the generation should be skipped.  Valid Values:  For Monthly: 0 – 31  For Weekly: 0 – 7  For Daily: 0 |
| Unit | Char  **Dropdown** | 1 | M | - | Define the type of contract cycle.  Ref: [Common Attributes](#_Common_Attributes)  - Cycle Unit |
| Type | Char  **Dropdown** | 1 | M | - | Type is either Futures or Options.  Valid Value:  O - Options  U - Futures |
| Pre-launch Days | Numeric  **Dropdown** | 2 | M | 0 | Define number of business days the contract starts trading after it is created and visible in the market.  Valid Values:  For Monthly: 0 – 31  For Weekly: 0 – 7  For Daily: 0 |
| One-off Pre-launch FTD | Date  **Dropdown** | 1 | O | - | The “One-off Pre-launch First Trading Date (One-off Pre-launch FTD)” attribute inside the generation rule will be used to compare against the First Trading Date. The pre-launch duration would be from the date defined in One-off Pre-launch FTD, till the date defined in First Trading Date, where One-off Pre-launch FTD must be either earlier or of the same date and not later than the First Trading Date. |
| Last Trading Date Group | Alphanumeric  **Text Input** | 32 | M | Same as the name of Instrument Class | Last Trading Date Group is a label in Auto Generation Rule. Instrument Classes with auto-generation rule having same label are in the same group, so that contracts in the same group and same last trading date are considered duplicated, only contracts with highest priority value described in the next section will be created.  By default, the label is same as the name of Instrument Class.  This field should be auto converted to Capital Letters. |
| Last Trading Date Group Priority | Numeric  **Dropdown** | 1 | M | 0 | Last Trading Date Group Priority is a number from 0 to 9, where lower value means higher priority.  Valid Value:  0 – 9 |
| Strike Price Group | Alphanumeric  **Text Input** | 32 | O | - | Strike Price Group is a label in Auto Generation Rule so that the same label with the same last trading date will have the same strike prices.  By default, the label is same as the name of Instrument Class if the type is Option.  This field should be auto converted to Capital Letters. |
| Last Trading Date Formula ID | Numeric  **Text Input (with Content Assist)** | 10 | O | - | The unique ID of Last Trading Date Formula.  **Not applicable to Daily Cycle.**  It’s mutually exclusive with **Last Trading Date Calendar ID**. |
| Last Trading Date Calendar ID | Numeric  **Text Input**  **(with Content Assist)** | 10 | O | - | The unique ID of Last Trading Date Calendar.  **Not applicable to Daily Cycle.**  It’s mutually exclusive with **Last Trading Date Formula ID**. |
| Lifecycle Time Rule ID | Numeric  **Text Input**  **(with Content Assist)** | 10 | M | - | The unique ID of Lifecycle Time Rule. |
| Cycle Blocks ID | Numeric  **Text Input**  **(with Content Assist)** | 10 | M | - | The unique ID of Cycle Blocks. |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0404\_00600**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0404\_00700**

| Action | Description |
| --- | --- |
| - | - |

**Validation**

**#FS10013\_S0404\_00800**

| Event | Validation Rule | Validation Message |
| --- | --- | --- |
| Confirm | Either Last Trading Date Formula ID or Last Trading Date Calendar ID should be defined. | Please enter Last Trading Date Formula or Last Trading Date Calendar. |
| Confirm should be blocked if Type of the Instrument Class is not Options/Futures. | Auto Generation Rule is applicable to Options and Futures. |
| Update Request | Unique identifier cannot be updated | Unique identifier cannot be updated |
| Any mandatory field is empty | Invalid Input |
| Invalid value input | Invalid Input |
| Either Last Trading Date Formula ID or Last Trading Date Calendar ID should be defined. | Please enter Last Trading Date Formula or Last Trading Date Calendar. |

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0404\_00900**

### Maintain Cycle Blocks

**#FS10013\_S0404\_01000**

**Description**

**#FS10013\_S0404\_01100**

Cycle Blocks contains one or multiple Block Details, up to a maximum of 10. Each Block Details mainly consists of a cycle list definition, which defines the contract month, week or day to generate contract.

This function is used to create/update/delete Cycle Blocks.

**UI Layout**

**#FS10013\_S0404\_01203**

Search Page

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

Popup Dialog

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

**Attributes**

**#FS10013\_S0404\_01301**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| **Identity** | | | | | |
| Cycle Blocks ID | Numeric  **Text Input** | 10 | M | - | The unique ID of the Cycle Blocks. |
| Name | Alphanumeric  **Text Input** | 12 | M | - | A unique name of the Cycle Blocks. |
| Description | Alphanumeric  **Text Input** | 40 | O | - | Description of the Cycle Blocks. |
| **General** | | | | | |
| Unit | Char  **Dropdown** | 1 | M | - | Same definition as Unit in Auto Generation Rule.  Ref: [Common Attributes](#_Common_Attributes)  - Cycle Unit |
| Type | Char  **Dropdown** | 1 | M | - | Type is either Futures or Options.  Valid Value:  O - Options  U - Futures |

**Cycle Blocks Table Attributes**

**#FS10013\_S0404\_01400**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Block | Numeric | 2 | - | - | **Read-only**  The Block Number assigned by System. |
| Cycle | Alphanumeric | 10 | - | - | **Read-only**  The cycle based on the input from the Cycle Blocks Popup Dialog. |
| Strike Price Range ID | Numeric | 10 | - | - | **Read-only**  The ID of Strike Price Range. |
| Strike Price Reference ID | Numeric | 10 | - | - | **Read-only**  The ID of Strike Price Reference. |

**Cycle Blocks Popup Dialog Attributes**

**#FS10013\_S0404\_01502**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Block | Numeric  **Text Input** | 2 | M | - | **Read-only**  The Block Number assigned by System.  (Maximum number of block is 10.) |
| Strike Price Range ID | Numeric  **Text Input (with Content Assist)** | 10 | O | - | The ID of Strike Price Range.  **Applicable only when type is Options.** |
| Strike Price Reference ID | Numeric  **Text Input (with Content Assist)** | 10 | O | - | The ID of Strike Price Reference.  **Applicable only when type is Options.** |
| **Cycle** | | | | | |
| Cycle Item | Alphanumeric  **Text Input** | 10 | M | - | Number of month/week/day to reference.  Valid Values:  **Unit = Month**  Ref + 1 ~ Ref +36  Ref + 1q ~ Ref + 40q  Ref + 1h ~ Ref + 20h  Ref + 1y ~ Ref + 10y  **Unit = Week**  Ref + 1 ~ Ref + 53  **Unit = Daily**  Ref + 1 ~ Ref + 31  Ref + 1c ~ Ref + 31c  Ref + 1wl ~ Ref + 52wl |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0404\_01600**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0404\_01700**

| Action | Description |
| --- | --- |
| Add | **Cycle Blocks**: Open Popup Dialog to add a Cycle Block to the Cycle Blocks List.  **Popup Dialog:** Add a row to the Cycle |
| Delete | **Cycle Blocks**: Delete the selected Cycle Block from the Cycle Blocks List.  **Popup Dialog:** Delete a row from the Cycle |
| Edit | **Cycle Blocks:** Open Popup Dialog to edit the selected Cycle Block. (Only able to edit one Cycle Block at a time). |

**Validation (Ref:** [**Common Validation**](#_Common_Validation)**)**

**#FS10013\_S0404\_01800**

| Event | Validation Rule | Validation Message |
| --- | --- | --- |
| Add Cycle Block | The Maximum number of Cycle Blocks is 10. | The maximum number of cycle blocks had been reached. |
| Delete Cycle Block | Minimum number of Cycle Block is 1. | Please add at least one Cycle Block. |
| Add Row to Cycle | The Maximum number of Row in Cycle is 36. | The maximum number of rows in Cycle had been reached. |
| Delete Row from Cycle | Minimum number of Row in Cycle is 1. | Please add at least one row in Cycle. |
| Confirm | Minimum number of Cycle Block is 1. | Please add at least one Cycle Block. |
| Minimum number of Row in Cycle is 1. | Please add at least one row in Cycle. |

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0404\_01900**

### Maintain Last Trading Date Formula

**#FS10013\_S0404\_02000**

**Description**

**#FS10013\_S0404\_02100**

Last Trading Date Formula is used to calculate the month or week by using formula the contract last available for trading. It is referred from Auto Generation Rule, and validation is in place to ensure matches with the Unit in Cycle Class.

Daily cycle is not supported.

This function is used to create/update/delete Last Trading Date Formula.

**UI Layout**

**#FS10013\_S0404\_02202**

Search Page

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

**Attributes**

**#FS10013\_S0404\_02302**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| **Identity** | | | | | |
| Last Trading Date Formula ID | Numeric  **Text Input** | 10 | M | - | The unique ID of the Last Trading Date Formula. |
| Name | Alphanumeric  **Text Input** | 12 | M | - | A unique name of the Last Trading Date Formula. |
| Description | Alphanumeric  **Text Input** | 40 | O | - | Description of the Last Trading Date Formula. |
| **General** | | | | | |
| Unit | Char  **Dropdown** | 1 | M | - | The Unit of this formula.  To use the formula in Auto Generation Rule, the formula Unit must be same as the Auto Generation Rule Unit.  Ref: [Common Attributes](#_Common_Attributes)  - Cycle Unit  **Daily is not supported** |

**Rules Table Attributes**

**#FS10013\_S0404\_02406**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Rule Type | Numeric  **Dropdown** | 1 | M | - | The type of rule.  Valid Values: **Day Anchoring Rules:**  1 = Monthly Trade Day Rule  2 = Monthly Calendar Day Rule  3 = Monthly Weekday Rule  4 = Weekday Rule  5 = Weekly Trade Day Rule  **Day Adjustment Rules**  6 = Delta Trade Day Rule  7 = Delta Trade Day on Holiday Rule  8 = Delta Calendar Day Rule  **Calendar Rule**  9 = Using Regional Calendar |
| Month Delta | Numeric  **Dropdown** | 2 | O | - | The number of months move forward from the current calendar month.  Valid Values:  0 – 11  Applicable to **1. Monthly Trade Day Rule** and **2. Monthly Calendar Day Rule.** |
| Day | Numeric  **Dropdown** | 1 | O | - | Day.  Valid Values:  **1. Monthly Trade Day Rule:**  1 = The first trading day of the month  2 = The last trading day of the month  **2. Monthly Calendar Day Rule:**  3 = First day of the month  4 = Last day of the month  **5. Weekly Trade Day Rule:**  5 = The first trading day of the week  6 = The last trading day of the week |
| Delta Days | Numeric  **Dropdown** | 3 | O | - | **6. Delta Trade Day Rule** The number of trading days to move from the calculating date.  **7. Delta Trade Day on Holiday Rule**  The number of trading days to move from the calculating date when the calculating date is on holiday.  **8. Delta Calendar Day Rule**  The number of calendar days to move from the calculating date.  Valid Values:  -31 ~ +31 |
| Weekday | Numeric  **Dropdown** | 1 | O | - | The weekday.  Valid Values:  1 = Monday  2 = Tuesday  3 = Wednesday  4 = Thursday  5 = Friday  6 = Saturday  7 = Sunday  Applicable to **3. Monthly Weekday Rule** and **4. Weekday Rule** only. |
| Occurrence in Month | Numeric  **Dropdown** | 1 | O | - | The number of weeks from either the beginning or the end of the Month.  Valid Values:  1st, 2nd, 3rd, 4th, 5th  Applicable to **3. Monthly Weekday Rule** only |
| From Month End? | Boolean  **Dropdown** | 1 | M | N | A Yes / No attribute. When Yes, the “Week in Month” is counted from the end of Month.  Applicable to **3. Monthly Weekday Rule** only. |
| Regional Calendar ID | Numeric  **Text Input (with Content Assist)** | 5 | O | - | The name of the Regional Calendar configuration. The configuration contains both normal trading weekdays and holidays definition.  Applicable to **9. Using Regional Calendar** only. |
| Include Product Calendar? | Boolean  **Dropdown** | 1 | M | N | Specify whether using Product Calendar or not.  Applicable to **9. Using Regional Calendar** only. |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0404\_02500**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0404\_02601**

| Action | Description |
| --- | --- |
| Add | Add a row to the Rules table. |
| Delete | Delete the selected rows from the Rules table. |
| Up | Move the selected rows up. |
| Down | Move the selected rows down. |

**Validation (Ref:** [**Common Validation**](#_Common_Validation)**)**

**#FS10013\_S0404\_02702**

| Event | Validation Rule | Validation Message |
| --- | --- | --- |
| Add | The Maximum number of rules is 20. | The maximum number of rules had been reached. |
| Confirm | The minimum number of rules is 1. | Please input at least 1 rule to the Rules List. |
| Only one Day Anchoring Rule allowed and it must be the first rule. | Only one Day Anchoring Rule allowed and it must be the first rule. |

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0404\_02800**

### Maintain Regional Holiday Calendar

**#FS10013\_S0404\_02900**

**Description**

**#FS10013\_S0404\_03000**

The Regional Calendar configuration defines trading date for a specific regional.

This function is used to create/update/delete Regional Calendar.

**UI Layout**

**#FS10013\_S0404\_03102**

Search Page

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))

![](data:image/png;base64...)

**Attributes**

**#FS10013\_S0404\_03200**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| **Identity** | | | | | |
| Regional Calendar ID | Numeric  **Text Input** | 5 | M | - | The unique ID of the Regional Calendar. |
| Name | Alphanumeric  **Text Input** | 12 | M | - | A unique name of the Regional Calendar. |
| Description | Alphanumeric  **Text Input** | 40 | O | - | Description of the Regional Calendar. |
| **General** | | | | | |
| Normal Trading Days | Numeric  **Bitmask week days** | 3 | M | - | Specify the weekdays of trading days.  Bitmask to represent available trading days  1 - Mon  10 - Tue  100 - Wed  1000 - Thu  10000 - Fri  100000 - Sat  1000000 - Sun  For Mon to Sun, value - 127 |

**Centre Table Attributes**

**#FS10013\_S0404\_03302**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Regional Calendar Type | Char  **Text Input** | 1 | M | - | Type of Regional Calendar.  Valid Values:  E – Exchange Trading  F – Financial Centers |
| ISO Code | Alphanumeric  **Text Input** | 8 | M | - | ISO Code.  If Regional Calendar Type is E – Exchange Trading, then ISO Code should be ISO MIC Code.  If Regional Calendar Type is F – Financial Centers, then ISO Code should be ISO Currency Code |

**Holidays Table Attributes**

**#FS10013\_S0404\_03402**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Holiday | Date | 11 | M | - | Specify the Holiday.  **Editable only when Action is manual.** |

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
| Regional Calendar Type | Char | - | - | - | **Read Only**  Type of Regional Calendar of the Holiday from the selected Regional Calendar |
| ISO Code | Alphanumeric | - | - | - | **Read Only**  ISO Code of the Holiday from the selected Regional Calendar |

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
| Import? | Boolean  **Dropdown** | 1 | M | No | **Read Only**  A Yes/No flag to indicate whether the holiday is imported from upload file.  **When manually add record to the Holidays table, Import? flag must be N – No.** |
| Manual? | Boolean  **Dropdown** | 1 | M | Yes | **Read Only**  A Yes/No flag to indicate whether this record is manually input.  **When manually add record to the Holidays table, Manual? flag must be Y - Yes.** |
| Ignore? | Boolean  **Dropdown** | 1 | M | No | A Yes/No flag to indicate whether the imported record should be ignored or not.  **Can change to Y-Yes only when Import? is Y-Yes.** |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0404\_03500**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0404\_03600**

| Action | Description |
| --- | --- |
| Add  (MIC Code Table) | Add a row to the MIC Codes table. |
| Delete  (MIC Code Table) | Delete a row from the MIC Codes table. |
| Add  (Holidays) | Add a row to the Holidays table.  The Action for the newly added row is **manual**. |
| Delete  (Holidays) | Delete a selected row from the Holidays table.  **Only able to delete record when Action is manual.** |
| Ignore  (Holidays) | Ignore a selected row in the Holidays table.  **Only able to ignore record when Action is upload.** |
| Resume  (Holidays) | Resume a selected row in the Holidays table.  **Only able to resume record when Action is ignore.** |

**Validation (Ref:** [**Common Validation**](#_Common_Validation)**)**

**#FS10013\_S0404\_03700**

| Event | Validation Rule | Validation Message |
| --- | --- | --- |
|  |  |  |

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0404\_03800**

### Maintain Last Trading Date Calendar

**#FS10013\_S0404\_03900**

**Description**

**#FS10013\_S0404\_04000**

Last Trading Date Calendar provides another way to define last trading date by manual assignment. It is alternative to Last Trading Date Formula and no calculation is involved. It can be used for cases where the contract term is not supported by Last Trading Date Formula.

Daily cycle is not supported.

This function is used to create/update/delete Last Trading Date Calendar.

**UI Layout**

**#FS10013\_S0404\_04101**

Search Page

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

Detail Page – Monthly (Record Status ref: [Current Record and Request Record](#_Toc178859290))

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

Detail Page - Weekly (Record Status ref: [Current Record and Request Record](#_Current_Record_and))

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

Popup Dialog – Weekly

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

**Attributes**

**#FS10013\_S0404\_04201**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| **Identity** | | | | | |
| Last Trading Date Calendar ID | Numeric  **Text Input** | 10 | M | - | The unique ID of the Last Trading Date Calendar. |
| Name | Alphanumeric  **Text Input** | 12 | M | - | A unique name of the Last Trading Date Calendar |
| Description | Alphanumeric  **Text Input** | 40 | O | - | Description of the Last Trading Date Calendar. |
| **General** | | | | | |
| Unit | Char  **Dropdown** | 1 | M | - | Define the type of contract cycle.  Ref: [Common Attributes](#_Common_Attributes)  - Cycle Unit  (Not include Daily) |

**Last Trading Date Attributes (Monthly)**

**#FS10013\_S0404\_04301**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Year | Numeric  **Text Input** | 4 | M | - | Year that the row representing. |
| Jan – Dec | Numeric  **Text Input** | 2 | O | - | Define the Last Trading Date of that month in the corresponding Year. |

**Last Trading Date Attributes (Weekly)**

**#FS10013\_S0404\_04400**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Year | Numeric | N/A | - | - | **Read-only.**  Year that the row representing.  **Input via Popup dialog.** |
| Default Weekday | Alphanumeric | N/A | - | - | **Read-only.**  Define the default weekday of the Last Trading Date.  **Input via Popup dialog.**  (Display with the same row as Year.) |
| Specific Weekdays | Alphanumeric | N/A | - | - | **Read-only.**  Define the weekday of a specific week.  **Input via Popup dialog.**  (Multiple rows are allowed. Starting from the next row after Year row.) |

**Popup Dialog Attributes**

**#FS10013\_S0404\_04501**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Year | Numeric  **Text Input** | 4 | M | - | Year that the row representing. |
| Default Weekday | Numeric  **Dropdown** | 1 | M | - | Define the default weekday of the Last Trading Date.  Valid Values  1 = Monday  2 = Tuesday  3 = Wednesday  4 = Thursday  5 = Friday  6 = Saturday  7= Sunday |
| **Specific Weekdays** | | | | | |
| Week | Numeric  **Text Input** | 2 | M | - | Specific Week Number |
| Weekday | Numeric  **Dropdown** | 1 | M | - | Weekday of the Specific Week.  1 = Monday  2 = Tuesday  3 = Wednesday  4 = Thursday  5 = Friday  6 = Saturday  7= Sunday |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0404\_04600**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0404\_04700**

| Action | Description |
| --- | --- |
| Add | **Monthly Table:** Add a new row to the Monthly Table  **Weekly Table:** Bring up the Popup Dialog for a new block in Weekly Table.  **Popup Dialog:** Add a row in the Specific Weekdays Table. |
| Delete | **Monthly Table:** Add the selected rows from the Monthly Table  **Weekly Table:** Delete the selected blocks from the Weekly Table.  **Popup Dialog:** Delete the selected rows from the Specific Weekdays Table. |
| Edit | **Weekly Table:** Bring up Popup Dialog for edit the selected block in Weekly Table. (Only one block can be edit at a time) |

**Validation (Ref:** [**Common Validation**](#_Common_Validation)**)**

**#FS10013\_S0404\_04800**

| Event | Validation Rule | Validation Message |
| --- | --- | --- |
|  |  |  |

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0404\_04900**

### Maintain Lifecycle Time Rule

**#FS10013\_S0404\_05000**

**Description**

**#FS10013\_S0404\_05100**

The Lifecycle Time Rule defines the time moment the order book started trading on the First trading date and time moment the order book stopped trading on the Last trading date.

This function is used to create/update/delete Lifecycle Time Rule.

**UI Layout**

**#FS10013\_S0404\_05202**

Search Page

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

**Attributes**

**#FS10013\_S0404\_05301**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| **Identity** | | | | | |
| Lifecycle Time Rule ID | Numeric  **Text Input** | 10 | M | - | The unique ID of the Lifecycle Time Rule. |
| Name | Alphanumeric  **Text Input** | 12 | M | - | A unique name of the Lifecycle Time Rule. |
| Description | Alphanumeric  **Text Input** | 40 | O | - | Description of the Lifecycle Time Rule. |
| **General** | | | | | |
| First Trading Time | Numeric  **Time Picker** | 6 | O | - | It defines the time moment (inclusive) on first trading date the order book started trading.  When it is empty, it means to start trading according to trading timetable just like the other days.  **Note that the time is based on Hong Kong Time Zone.**  **The time format is in HH:mm:ss, e.g. 16:00:00.  If the time belongs to next Calendar Day, Hour can be defined after 24. (e.g. 25:00:00 means 01:00:00 of next Calendar Day)** |
| Normal Day Last Trading Time | Numeric  **Time Picker** | 6 | M | - | It defines the time (exclusive) on last trading date the order book stopped trading when it is a normal trading day in product timetable.  **Note that the time is based on Hong Kong Time Zone.**  **Time format is the same as First Trading Time.** |
| Normal Day DST Adjustment? | Boolean  **Dropdown** | 1 | M | False | A true / false attribute. When true, DST adjustment applies to Normal Day Last Trading Time. Otherwise, DST Adjustment does not apply. |
| Half Day Last Trading Time | Numeric  **Time Picker** | 6 | M | - | It defines the time (exclusive) on last trading date the order book stopped trading when it is a half trading day in product timetable.  **Note that the time is based on Hong Kong Time Zone.**  **Time format is the same as First Trading Time.** |
| Half Day DST Adjustment? | Boolean  **Dropdown** | 1 | M | False | A true / false attribute. When true, DST adjustment applies to Half Trading Day Last Trading Time. Otherwise, DST Adjustment does not apply. |
| DST Adjustment ID | Numeric  **Text Input**  **(with Content Assist)** | 10 | O | - | The ID of the Last Trading Time Offset. |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0404\_05400**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0404\_05500**

| Action | Description |
| --- | --- |
| - | - |

**Validation (Ref:** [**Common Validation**](#_Common_Validation)**)**

**#FS10013\_S0404\_05600**

| Event | Validation Rule | Validation Message |
| --- | --- | --- |
|  |  |  |

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

### Maintain Last Trading Time DST Adjustment

**#FS10013\_S0404\_05702**

**Description**

**#FS10013\_S0404\_05802**

Last Trading Time DST adjustment defines day ranges per year to adjust Last Trading Time on Last Trading Date due to DST (Daylight Saving Time) adjustment.

This function is used to create/update/delete Last Trading Time Offset.

**UI Layout**

**#FS10013\_S0404\_05901**

Search Page

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

**Attributes**

**#FS10013\_S0404\_06001**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| **Identity** | | | | | |
| DST Adjustment ID | Numeric  **Text Input** | 10 | M | - | The unique ID of the DST Adjustment. |
| Name | Alphanumeric  **Text Input** | 12 | M | - | A unique name of the DST Adjustment. |
| Description | Alphanumeric  **Text Input** | 40 | O | - | Description of the DST Adjustment . |
| **General** | | | | | |
| Adjustment in Minutes | Numeric  **Text Input** | 5 | M | 0 | Adjustment in Minutes defines the number of minutes plus or minus to the Last Trading Time.  Valid Values:  Integer -ve, 0, +ve |

**Date Ranges Table Attributes**

**#FS10013\_S0404\_06101**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Year | Numeric  **Text Input** | 4 | M | - | Year. |
| From | Date  **Date Picker** | 10 | M | - | Start date of DST adjustment. |
| To | Date  **Date Picker** | 10 | M | - | End date of DST adjustment |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0404\_06200**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0404\_06300**

| Action | Description |
| --- | --- |
| - | - |

**Validation (Ref:** [**Common Validation**](#_Common_Validation)**)**

**#FS10013\_S0404\_06400**

| Event | Validation Rule | Validation Message |
| --- | --- | --- |
| Add | Maximum number of records in Date Ranges table is 30. | Maximum number of Date Ranges had been reached. |
| Delete | Minimum number of records in Date Ranges table is 1. | Please input at least 1 Date Range. |
| Confirm | To Date must be after From Date. | To Date must be after From Date. |

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0404\_06500**

### Maintain Strike Price Range

**#FS10013\_S0404\_06600**

**Description**

**#FS10013\_S0404\_06700**

The Strike Price Range is specific to options contracts. It defines a strike price range from a reference price for the contract or order book generation. It is referred from Cycle Block(s) in Auto Generation Rule.

This function is used to create/update/delete Strike Price Range.

**UI Layout**

**#FS10013\_S0404\_06801**

Search Page

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

**Attributes**

**#FS10013\_S0404\_06901**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| **Identity** | | | | | |
| Strike Price Range ID | Numeric  **Text Input** | 10 | M | - | The unique ID of the Strike Price Range. |
| Name | Alphanumeric  **Text Input** | 12 | M | - | A unique name of the Strike Price Range. |
| Description | Alphanumeric  **Text Input** | 40 | O | - | Description of the Strike Price Range. |
| **General** | | | | | |
| Method | Char  **Dropdown** | 1 | M | - | The Method to define the price range.  Valid Values:  P = Percentage  S = Steps |
| Strike Price Table ID | Numeric  **Text Input (with Content Assist)** | 10 | M | - | The ID of the Strike Price Table related to this Strike Price Range. |
| Up Range Percentage | Percentage  **Text Input** | 8 | O | - | The upper range percentage.  Valid Values:  0 – 1000  **Applicable when Method is P – Percentage.** |
| Up Range Step | Numeric  **Text Input** | 3 | O | - | The upper range step.  Valid Values:  0 – 500  **Applicable when Method is S - Steps.** |
| Down Range Percentage | Percentage  **Text Input** | 8 | O | - | The down range percentage.  Valid Values:  0 – 1000  **Applicable when Method is P – Percentage.** |
| Down Range Step | Numeric  **Text Input** | 3 | M | - | The down range step.  Valid Values:  0 – 500  **Applicable when Method is S - Steps.** |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0404\_07000**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0404\_07100**

| Action | Description |
| --- | --- |
| - | - |

**Validation (Ref:** [**Common Validation**](#_Common_Validation)**)**

**#FS10013\_S0404\_07200**

| Event | Validation Rule | Validation Message |
| --- | --- | --- |
|  |  |  |

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0404\_07300**

### Maintain Strike Price Table

**#FS10013\_S0404\_07400**

**Description**

**#FS10013\_S0404\_07500**

Strike Price Table together with Percentage or Steps configuration are used for Strike Price calculation.

The Strike Price Table defines price interval per price range for options strike price like the concept of Tick Size table.

This function is used to create/update/delete Strike Price Table.

**UI Layout**

**#FS10013\_S0404\_07601**

Search Page

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

**Attributes**

**#FS10013\_S0404\_07702**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| **Identity** | | | | | |
| Strike Price Table ID | Numeric  **Text Input** | 10 | M | - | The unique ID of the Strike Price Table. |
| Name | Alphanumeric  **Text Input** | 12 | M | - | A unique name of the Strike Price Range. |
| Description | Alphanumeric  **Text Input** | 40 | O | - | Description of the Strike Price Table. |
| **General** | | | | | |
| Decimals | Numeric  **Dropdown** | 2 | M | 0 | Number of decimals in Strike Price. |

**Interval List Attributes**

**#FS10013\_S0404\_07803**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Below Price | Price  **Text Input** | 20 | M | - | The upper range price.  Valid Values:  Below Price < Max Price in Global Parameter  (Negative value is allowed)  **System will sort the records in ascending order of Below Price automatically.**  **The Below Price field of the last record must be empty. System will filled it as 263 - 1 when stored in Database. When display, system will convert 263 – 1 back to empty.** |
| Intervals | Price  **Text Input** | 20 | M | - | The price delta between 2 strike prices.  Valid Values:  0 < Below Price < Max Price in Global Parameter |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0404\_07900**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0404\_08000**

| Action | Description |
| --- | --- |
| Add | Add a row to the Interval List. |
| Delete | Delete a row from the Interval List. |

**Validation (Ref:** [**Common Validation**](#_Common_Validation)**)**

**#FS10013\_S0404\_08101**

| Event | Validation Rule | Validation Message |
| --- | --- | --- |
| Add | The Maximum number of items in Interval List is 16. | The maximum number of Intervals had been reached. |
| Delete | The minimum number of Interval is 1. | Please input at least 1 Interval to the Interval List. |
| Confirm | The last record’s Below Price must be empty. | Below Price of the last row must be empty. |

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0404\_08200**

### Maintain Strike Price Reference

**#FS10013\_S0404\_08300**

**Description**

**#FS10013\_S0404\_08400**

The Strike Price Reference is specific to options contracts and referred from Cycle Block(s) in Auto Generation Rule. It defines the reference price for Strike Price Range calculation.

This function is used to create/update/delete Strike Price Reference.

**UI Layout**

**#FS10013\_S0404\_08501**

Search Page

![A close-up of a computer screen  AI-generated content may be incorrect.](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

**Attributes**

**#FS10013\_S0404\_08603**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| **Identity** | | | | | |
| Strike Price Reference ID | Numeric  **Text Input** | 10 | M | - | The unique ID of the Strike Price Reference. |
| Name | Alphanumeric  **Text Input** | 12 | M | - | A unique name of the Strike Price Reference. |
| Description | Alphanumeric  **Text Input** | 40 | O | - | Description of the Strike Price Reference. |
| **General** | | | | | |
| Source Type | Char  **Dropdown** | 1 | M | - | The Source Type of the Strike Price Reference.  Valid Values:  I = Instrument Class  U = Underlying |
| Instrument Class ID | Alphanumeric  **Text Input (with Content Assist)** | 14 | O | - | Source of the Strike Price Reference -Instrument Class.  **Applicable and Mandatory when Source Type is I -Instrument Class** |
| Underlying ID | Alphanumeric  **Text Input (with Content Assist)** | 6 | O | - | Source of the Strike Price Reference – Underlying.  **Applicable and Mandatory when Source Type is U - Underlying** |
| Price Type | Numeric  **Dropdown** | 1 | M | - | The Price Type of the Strike Price Reference.  Valid Values:  1 = Settlement Price  2 = Last Traded Price of current Trading Date |
| Delta Days | Numeric  **Text Input** | 2 | M | 0 | The value is for selecting the spot contract at SOD.  Valid Values:  0 – 31  **This is only available for Instrument Class Source Type.** |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0404\_08700**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0404\_08800**

| Action | Description |
| --- | --- |
| - | - |

**Validation (Ref:** [**Common Validation**](#_Common_Validation)**)**

**#FS10013\_S0404\_08900**

| Event | Validation Rule | Validation Message |
| --- | --- | --- |
| Confirm | Delta Days are missing when Source Type is Instrument Class. | Please specify the Delta Days. |
| Source and Source Type not match. | Please specify a valid Source with the matching Source Type. |

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0404\_09000**

### Instrument Generation

**#FS10013\_S0404\_09100**

**Description**

**#FS10013\_S0404\_09200**

This function is used to generate Instrument for the next Trading Day.

**UI Layout**

**#FS10013\_S0404\_09302**

Detail Page

![](data:image/png;base64...)

**Attributes**

**#FS10013\_S0404\_09401**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| **Parameters** | | | | | |
| Preset | Numeric  **Dropdown** | 1 | M | - | The pre-defined preset for narrow down the scope of Market / Instrument Type / Instrument Class.  The preset values are defined in Maintain System Preference. |
| Market | Alphanumeric  **Text Input with Content Assist** | 5 | O | - | The ID of Market to generate the Combo. |
| Instrument Type ID | Alphanumeric  **Text Input with Content Assist** | 8 | O | - | The ID of the Instrument Type to generate the Instrument. |
| Instrument Class | Alphanumeric  **Text Input with Content Assist** | 14 | O | - | The ID of the Instrument Class to generate the Instrument. |

**Generated Instruments Table Attributes**

**#FS10013\_S0404\_09503**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| **Action** | | | | | |
| Action | Alphanumeric | - | - | - | **Read-only.**  Indicate the Action to be performed on the record  **Possible Values:**  **New –** New Instrument to Create  **Update (LTD)** – Update LTD of existing Instrument  **Update (LTT)** – Update LTT of existing Instrument  **Update (LTD & LTT)** – Update LTD & LTT of existing Instrument  **Supplement –** New Instrument due to supplement of Strike Price  **Ignore (LTD GRP)** – Skip due to LTD Group logic  **Ignore (Until Date to LTD) –** Skip due to Until Date to LTD logic  **Ignore (Exist)** – Skip due to Instrument already exist  **Ignore (Pending Approve)** – Skip due to same Instrument exist in Pending Approve Status  **Ignore (Approved)** – Skip due to same Instrument exist in Approved Status  **Ignore (Error)** – Skip due to error occur during generation/submission |
| Submission | Alphanumeric | - | - | - | **Read-only.**  Indicate the status of Submission.  **Possible Values:**  Submitted  Failed |
| **Identity** | | | | | |
| Instrument ID | Alphanumeric | 32 | - | - | **Read-only.**  The unique ID of the Instrument. |
| Instrument Class ID | Alphanumeric | 14 | - | - | **Read-only.**  The ID of the Combo Class that this Combo belongs to. |
| **General** | | | | | |
| Generation Reference Price | Numeric | 20 | - | - | **Read-only.**  The Strike Price Reference used during instrument generation. Applicable to Options only. |
| Strike Price | Numeric | 20 | - | - | **Read-only.**  The strike price of the options instrument. The attribute is available only when the upper-level instrument group is defined as options.  The assignment of value by automatic generation.  It is a component of legacy Instrument ID. |
| Effective Date | Date | 11 | - | - | **Read-only.**  The date that this instrument is effective in the system. |
| **First Trading Date** | | | | | |
| First Trading Date | Date | 11 | - | - | **Read-only.**  The first day the instrument can be traded. |
| First Trading Time | Time | 5 | - | - | **Read-only.**  The beginning time on the first trading date the instrument can be traded. |
| **Last Trading Date** | | | | | |
| Last Trading Date | Date | 11 | - | - | **Read-only.**  The final day the instrument can be traded. |
| Last Trading Time | Time | 5 | - | - | **Read-only.**  The final time on the last trading date the combo can be traded. |
| **Existing Instrument** | | | | | |
| Instrument ID | Alphanumeric | 32 | - | - | **Read-only.**  The corresponding existing Instrument ID in the System.  Value exist only when Action is **Update, Ignore (Exist), Ignore (Pending Approve), Ignore (Approved)** |
| **Remark** | | | | | |
| Remark | Alphanumeric | - | - | - | **Read-only.**  Remark will be filled if there is error related to the instrument |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0404\_09600**

**Actions**

**#FS10013\_S0404\_09700**

| Action | Description |
| --- | --- |
| Screen Open | Trigger a query to display all records |
| Generate | Clear the Generated Instruments Table and generate the Instrument based on the selected Market / Instrument Type / Instrument Class.  **Only generate instrument when Auto Generation is enabled in the Instrument Class.**  **If the Instrument Class is processed by CA earlier in the same day, auto generation is skipped.**  **If the generated Instrument already exists in the system, that Instrument will be excluded from the ‘Generated Instruments Table’.** |
| Delete | Delete the selected instrument. |
| Export | Export all Records from Generated Instruments Table to CSV file |
| Confirm | Confirm the change and submit to backend, disabled with Read-only permission and view mode |
| Cancel | Cancel all changes, disabled with Read-only permission and view mode |

**Validation**

**#FS10013\_S0404\_09800**

| Event | Validation Rule | Validation Message |
| --- | --- | --- |
| Generate | Either Market / Instrument Type / Instrument Class. should selected | Please specify at least one field from Market / Instrument Type / Instrument Class. |
| Confirm | The Generated Instruments Table should not be empty. | Please generate instruments. |

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0404\_09900**

### Regional Calendar Upload

**#FS10013\_S0404\_10000**

**Description**

**#FS10013\_S0404\_10100**

The Regional Calendar configuration defines trading date for a specific regional.

This function is used to upload Regional Calendar. The total number of records in the upload file is limited to TBC records per file.

**UI Layout**

**#FS10013\_S0404\_10200**

Detail Page

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

**Regional Calendar File Attributes**

**#FS10013\_S0404\_10300**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| File Name | Alphanumeric | - | - | - | The file name of the Calendar file.  **Read-only, filled by system when user selected a file via upload button.** |
| MIC Code | Alphanumeric | 8 | - | - | The ISO Market Identifier Code. |
| Event Date | Numeric | 8 | - | - | Date of the record in YYYYMMDD format. |

**Trading Calendar and Holiday Schedule Attributes**

**#FS10013\_S0404\_10400**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Instrument Class | Alphanumeric  **Text Input with Content Assist** | 14 | O | - | Select an Instrument to check. |
| Year | Numeric  **Dropdown** | 4 | O | - | Select a Year to check. |

**Last Trading Day Checklist Attributes**

**#FS10013\_S0404\_10500**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Action Date | Date  **Date Picker** | 11 | O | - | Select an action date to check. |
| **Futures** | | | | | |
| Instrument ID | Alphanumeric | 32 | O | - | The ID of the Instrument. |
| Last Trading Date | Alphanumeric | 11 | O | - | Last Trading Date of the Instrument. |
| **Options** | | | | | |
| Instrument ID | Alphanumeric | 32 | O | - | The ID of the Instrument. |
| Last Trading Date | Alphanumeric | 11 | O | - | Last Trading Date of the Instrument. |
| **Combos** | | | | | |
| Combo ID | Alphanumeric | 32 | O | - | A unique ID representing the combo instrument. |
| Combo Class ID | Alphanumeric | 14 | O | - | A unique ID representing the combo class. |
| Last Trading Date | Alphanumeric | 11 | O | - | Last Trading Date of the Instrument. |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0404\_10600**

**Actions**

**#FS10013\_S0404\_10700**

| Action | Description |
| --- | --- |
| Upload | Select and Upload a Calendar File. |
| Reset | Clear the uploaded Calendar File and reset all the selection and tables in the page. |
| Preview | Generate the data for preview.  **This action will be disabled if no Calendar File is uploaded.** |
| Confirm | Confirm the change and submit to backend, disabled with Read-only permission and view mode.  **Once submitted, it will be split to multiple Countersign Requests. The records will be grouped by MIC Code. Each Request contains the records of a particular MIC Code.** |
| Cancel | Cancel all changes, disabled with Read-only permission and view mode |

**Validation**

**#FS10013\_S0404\_10800**

| Event | Validation Rule | Validation Message |
| --- | --- | --- |
| New Request | Valid Regional Calendar File has been selected. | Please select a valid Regional Calendar File. |

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0404\_10900**

## Auto Combo Generation **#FS10013\_S0405\_00100**

### Maintain Auto Combo Generation Rule Group

**#FS10013\_S0405\_00201**

**Description**

**#FS10013\_S0405\_00304**

Automatic Combo Generation creates Combos based on configuration rules which describe leg contracts. Combo Rule Group contains a list of user defined rules. The rules in the group will be executed sequentially and each of them will select combo leg contracts to form a single or multiple combo contracts.

This function is used to add, update or delete the Auto Combo Generation Rule Group.

**UI Layout**

**#FS10013\_S0405\_00402**

Search Page

![](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

Popup Dialog (Rule - Manual Link)

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

Popup Dialog (Rule - Multiple Link)

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

Popup Dialog (Rule - Banker Link)

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

**Attributes**

**#FS10013\_S0405\_00502**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| **Identity** | | | | | |
| Auto Combo Generation Rule Group ID | Numeric  **Text Input** | 5 | M | - | The unique ID of the Auto Combo Generation Rule Group. |
| Name | Alphanumeric  **Text Input** | 12 | M | - | A unique name of the Auto Combo Generation Rule Group |
| Description | Alphanumeric  **Text Input** | 40 | O | - | Description of the Auto Combo Generation Rule Group |
| **General** | | | | | |
| Until Days to Last Trading | Numeric  **Text Input** | 2 | O | - | Define a period in trading days before the contract’s last trading date which the generation should be skipped.  Valid Values:  0 – 31 |
| Unit | Char  **Dropdown** | 1 | M | - | Define the type of contract cycle.  Ref: [Common Attributes](#_Common_Attributes)  - Cycle Unit  **Only M – Monthly is allowed** |
| Pre-launch Days | Numeric  **Dropdown** | 2 | O | - | Define number of business days the contract starts trading after it is created and visible in the market.  Valid Values:  0 – 31 |
| One-off Pre-launch | Boolean  **Dropdown** | 1 | M | False | One-off Pre-launch is a true / false attribute. When enabled, it restricts processing of Pre-launch Days feature only once.  The attribute can be enabled, only when Pre-launch Days is greater than “0” which enabled the pre-launch feature. |
| Enabled? | Boolean  **Dropdown** | 1 | M | False | Indicate whether the Auto Combo Generation Rule Group is enabled or not. |
| **Combo Rules** | | | | | |
| Auto Combo Generation Rule ID | Numeric | 10 | - | - | **Read-only.**  The unique ID of the Auto Combo Generation Rule. |
| Auto Combo Generation Rule Type | Numeric | 1 | - | - | **Read-only.**  The type of Auto Combo Generation Rule.  Valid Values:  1 = Manual Link Rule  2 = Multiple Link Rule  3 = Banker Link Rule |

**Popup Dialog Attributes (Common)**

**#FS10013\_S0405\_00601**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Auto Combo Generation Rule Type | Numeric  **Dropdown** | 1 | M | - | Type of the Auto Combo Generation Rule.  Valid Values:  1 = Manual Link Rule  2 = Multiple Link Rule  3 = Banker Link Rule |
| Name | Alphanumeric  **Text Input** | 12 | M | - | A unique name of the Auto Combo Generation Rule. |
| Description | Alphanumeric  **Text Input** | 40 | M | - | Description of the Auto Combo Generation Rule. |
| Unit | Char | 1 | - | - | **Read-only**.  Unit of the corresponding Auto Combo Generation Rule Group  Ref: [Common Attributes](#_Common_Attributes)  - Cycle Unit  **Only M – Monthly is allowed** |

**Popup Dialog Attributes (Rule - Manual Link)**

**#FS10013\_S0405\_00702**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| **General** | | | | | |
| Manual Link ID | Numeric  **Text Input** | 10 | M | - | **Read-only**  The unique ID of the Manual Link Rule generated by System. |
| Combo Class ID | Alphanumeric  **Text Input** | 14 | M | - | A unique ID representing the combo class. |
| **Leg Instruments** | | | | | |
| Leg Number | Numeric  **Text Input** | 1 | M | - | **Read-only**  Leg Number  Valid Values:  1 – 4  **Assigned by System.** |
| Inst. Class | Alphanumeric  **Text Input (with Content Assist)** | 14 | M | - | Instrument Class of leg contracts. |
| Contracts from Spot | Numeric  **Dropdown** | 2 | M | - | Contracts from Spot define the number of existing contracts from current month ordered by last trading date. By default, it is counting all existing contracts.  Valid Values:  0 – 30 |
| Month Selection | Numeric  **Dropdown** | 1 | M | - | The Month/Week Selection controls what contract to count. It is by default with value “All Month” / “All Week”  Ref: [Common Attributes](#_Common_Attributes)  - Month Selection |
| Operation | Char  **Dropdown** | 1 | M | - | Operation to the leg contract when buy the combo instrument.  Ref: [Common Attributes](#_Common_Attributes)  - Side Char |
| Ratio | Numeric  **Text Input** | 5 | M | - | The Ratio attribute allows value of positive number. The ratio of X on a leg contract means buying or selling 1 quantity of the combo instrument will result in buying or selling X quantity of leg contracts.  Valid Values:  +ve Integer from 1 to 10000 |

**Popup Dialog Attributes (Rule - Multiple Link)**

**#FS10013\_S0405\_00802**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| **General** | | | | | |
| Multiple Link ID | Numeric  **Text Input** | 10 | M | - | **Read-only**  The unique ID of the Multiple Link Rule generated by System. |
| Inst. Class ID | Alphanumeric  **Text Input (with Content Assist)** | 14 | M | - | Instrument Class of leg contracts. |
| Leg Contracts | Numeric  **Dropdown** | 2 | O | - | The number of contracts selected that nearest to the current month ordered by last trading date under the Instrument Class.  Valid Values:  2 – 30  Empty  (Empty means selecting all available contracts.) |
| Month Selection | Numeric  **Dropdown** | 2 | M | - | The Month Selection defines which existing contracts to select.  Ref: [Common Attributes](#_Common_Attributes)  - Month Selection |
| Min Time Spread | Numeric  **Text Input** | 5 | M | - | Minimum Time Spread. Time Spread is used to locate the Combo Group for the generated Combo. |

**Popup Dialog Attributes (Rule - Banker Link)**

**#FS10013\_S0405\_00901**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| **General** | | | | | |
| Banker Link ID | Numeric  **Text Input** | 10 | M | - | **Read-only**  The unique ID of the Banker Link Rule generated by System. |
| Inst. Class ID | Alphanumeric  **Text Input (with Content Assist)** | 14 | M | - | Instrument Class of leg contracts. |
| **Banker Contract(s)** | | | | | |
| Banker Selection Type | Char  **Dropdown** | 1 | M | - | Selection Type defines how to choose the Banker Contract(s).  Valid Values:  R – Relative  A – Absolute |
| Banker Month | Numeric  **Dropdown** | 2 | O | - | The Month parameter selects contracts in specific Month.  Valid Values:  1 = JAN  2 = FEB  3 = MAR  4 = APR  5 = MAY  6 = JUN  7 = JUL  8 = AUG  9 = SEP  10 = OCT  11 = NOV  12 = DEC  Appliable to **Selection Type - Absolute** only. |
| Banker Contracts from Spot | Numeric  **Dropdown** | 2 | O | - | Contracts from Spot define the number of existing contracts from current month ordered by last trading date. By default, it is counting all existing contracts.  Valid Values:  0 – 30  Appliable to **Selection Type - Relative** only. |
| Banker Month Selection | Numeric  **Dropdown** | 1 | O | 1 - All | The Month Selection controls what contract to count. It is by default with value “All”  Ref: [Common Attributes](#_Common_Attributes)  - Month Selection  Appliable to **Selection Type - Relative** only. |
| **Leg Contract(s)** | | | | | |
| Leg Contracts | Numeric  **Text Input** | 2 | M | - | The number of nearest contracts ordered by last trading date, from “Leg From Reference”.  Valid Values:  2 – 30  Empty  (Empty value means selecting all available contracts) |
| Leg From Reference | Char  **Dropdown** | 1 | M | - | The From Reference allows either Spot or Banker.  Valid Values:  S – Spot  B – Banker |
| Leg Month Selection | Numeric  **Dropdown** | 2 | M | - | The Month Selection defines which existing contracts to select.  Ref: [Common Attributes](#_Common_Attributes)  - Month Selection |
| Min Time Spread | Numeric  **Text Input** | 5 | M | - | Minimum Time Spread. Time Spread is used to locate the Combo Group for the generated Combo. |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0405\_01000**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0405\_01101**

| Action | Description |
| --- | --- |
| - | - |

**Validation ~~(Ref:~~** [**~~Common Validation~~**](#_Common_Validation)**~~)~~**

**#FS10013\_S0405\_01200**

| Event | Validation Rule | Validation Message |
| --- | --- | --- |
| Update Request | Unique identifier cannot be updated | Unique identifier cannot be updated |
| Any mandatory field is empty | Invalid Input |
| Invalid value input | Invalid Input |

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0405\_01300**

### Combo Generation

**#FS10013\_S0405\_01400**

**Description**

**#FS10013\_S0405\_01500**
This function is used to generate Combo for the next Trading Day.

**UI Layout**

**#FS10013\_S0405\_01602**

Detail Page

![](data:image/png;base64...)

**Attributes**

**#FS10013\_S0405\_01701**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| **Parameters** | | | | | |
| Preset | Numeric  **Dropdown** | 1 | M | - | The pre-defined preset for narrow down the scope of Market / Combo Type / Combo Class.  The preset values are defined in Maintain System Preference. |
| Market | Alphanumeric  **Text Input with Content Assist** | 5 | O | - | The ID of Market to generate the Combo. |
| Instrument Type | Alphanumeric  **Text Input with Content Assist** | 8 | O | - | The ID of the Instrument Type to generate Combo. Based on the Instrument Type of Combo’s leg. |
| Instrument Class | Alphanumeric  **Text Input with Content Assist** | 14 | O | - | The ID of the Combo Class to generate Combo.  Based on the Instrument Class of Combo’s leg. |
| Auto Combo Generation Rule Group | Numeric  **Text Input** | 5 | O | - | Auto Combo Generation Rule Group for generate Combo. |

**Generated Combos Table Attributes**

**#FS10013\_S0405\_01802**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| **Action** | | | | | |
| Action | Alphanumeric | - | - | - | **Read-only.**  Indicate the Action to be performed on the record  **Possible Values:**  **New –** New Combo to Create  **Update (LTD)** – Update LTD of existing Combo  **Update (LTT)** – Update LTT of existing Combo  **Update (LTD & LTT)** – Update LTD & LTT of existing Combo  **Ignore (Exist) –**  Skip due to Combo already exist (Based on Combo ID)  **Ignore (Until Date to LTD) –** Skip due to Until Date to LTD logic  **Ignore (Pending Approve)** – Skip due to same Combo exist in Pending Approve Status  **Ignore (Approved)** – Skip due to same Combo exist in Approved Status  **Ignore (Exist Leg)** – Skip due to Combo already exist (Based on Combo Legs)  **Replace TMC –** Delete the TMC and replace with the Standard Combo  **Ignore (Auto Gen Disabled)** – Skip due to Combo Class’s Auto Gen is disabled |
| Submission | Alphanumeric | - | - | - | **Read-only.**  Indicate the status of Submission.  **Possible Values:**  Submitted  Failed |
| **Identity** | | | | | |
| Combo ID | Alphanumeric | 32 | M | - | **Read-only.**  The unique ID of the Combo. |
| Combo Class ID | Alphanumeric | 14 | M | - | **Read-only.**  The ID of the Combo Class that this Combo belongs to. |
| **General** | | | | | |
| Effective Date | Date | 11 | M | - | **Read-only.**  The date that this combo is effective in the system. |
| **First Trading Date** | | | | | |
| First Trading Date | Date | 11 | O | - | **Read-only.**  The first day the instrument can be traded. |
| First Trading Time | Time | 5 | O | - | **Read-only.**  The beginning time on the first trading date the combo can be traded. |
| **Last Trading Date** | | | | | |
| Last Trading Date | Date | 11 | O | - | **Read-only.**  The final day the instrument can be traded. |
| Last Trading Time | Time | 5 | O | - | **Read-only.**  The final time on the last trading date the combo can be traded. |
| **Leg 1 - 4** | | | | | |
| Operation | Char | 1 | M | - | **Read-only.**  The operation of the Leg. Valid Values:  B – Buy  S – Sell |
| Ratio | Numeric | 5 | M | - | **Read-only.**  The ratio of the Leg. |
| Instrument ID | Alphanumeric | 32 | M | - | **Read-only.**  The ID of instrument for the Leg. |
| **Existing Combo** | | | | | |
| Combo ID | Alphanumeric | 32 | - | - | **Read-only.**  The corresponding existing Instrument ID in the System.  Value exist only when Action is **Update, Ignore (Exist), Ignore (Pending Approve), Ignore (Approved), Ignore (Exist Legs), Replace TMC** |
| **Remark** | | | | | |
| Remark | Alphanumeric | - | - | - | **Read-only.**  Remark will be filled if there is error related to the instrument |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0405\_01900**

**Actions**

**#FS10013\_S0405\_02000**

| Action | Description |
| --- | --- |
| Screen Open | Trigger a query to display all records |
| Generate | Clear the Generated Combos Table and generate the Combos based on the selected Market / Combo Type / Combo Class.  **Only generate combo when Auto Generation is enabled in the Combo Class.**  **If the generated Combo already exists in the system, that Combo will be excluded from the ‘Generated Combos Table’** |
| Delete | Delete the selected combo. |
| Export | Export all Records from Generated Combos Table to CSV file |
| Confirm | Confirm the change and submit to backend, disabled with Read-only permission and view mode |
| Cancel | Cancel all changes, disabled with Read-only permission and view mode |

**Validation**

**#FS10013\_S0405\_02100**

| Event | Validation Rule | Validation Message |
| --- | --- | --- |
| Generate | Either Market / Combo Type / Combo Class. | Please specify at least one field from Market / Combo Type / Combo Class. |
| Confirm | The Generated Combo Table should not be empty. | Please generate combos. |

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0405\_02200**

## SMP

**#FS10013\_S0406\_00100**

### Maintain SMP ID

**#FS10013\_S0406\_00200**

**Description**

**#FS10013\_S0406\_00300**

This function is used to create, update and delete an SMP ID. SMP is a feature for market participants to prevent inadvertent self-trades at exchange level. With the feature enabled, matching engine will not allow self-orders to match against each other.

**UI Layout**

**#FS10013\_S0406\_00402**

Search Page

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

**Attributes**

**#FS10013\_S0406\_00503**

| Column | Type | Length | | M/O | | Default | | Remarks | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| **Identity** | | | | | | | | | |
| SMP ID | Numeric  **Text Input** | 9 | | M | | - | | A unique SMP ID Generated by System, for detail please refer to ID Generation Section.  **Generated by System. Not Editable.** | |
| Description | Alphanumeric  **Text Input** | 40 | | O | | - | | Description of the SMP ID. | |
| Status | Char  **Dropdown** | 1 | | M | | - | | Status of the SMP ID.  Ref: [Common Attributes](#_Common_Attributes)  - SMP ID Status | |
| Status Last Update Date | Date | 11 | | M | | - | | Indicate the last update date of the Status. System will assign the date automatically once the Status is changed.  **Read Only** | |
| **General** | | | | | | | | | |
| Creation Reference Number | Numeric | | 4 | | M | | - | | Creation Reference Number.  0 - 9999 |
| Owner ID | Alphanumeric  **Text Input (with Content Assist)** | 5 | | M | | - | | The ID of the Exchange Participant who own this SMP ID. (The one who submitted the SMP ID Creation Request.)  **Not Editable once the SMP ID is created.** | |
| Cancellation Method | Char  **Dropdown** | 1 | | M | | - | | SMP Cancellation Method.  Ref: [Common Attributes](#_Common_Attributes)  - SMP Instruction | |

**SMP ID Sharing Attributes**

**#FS10013\_S0406\_00601**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Exchange Participant ID | Alphanumeric  **Text Input** | 5 | M | - | The Exchange Participant ID that the SMP ID Shared to.  (Look up the Exchange Participant whose SMP ID List containing this SMP ID)  **Read-only** |
| Status | Char  **Text Input** | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Status  SMP ID Status  **Read-only** |

Note that SMP ID Sharing section is available in Current Record only.

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0406\_00700**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0406\_00800**

| Action | Description |
| --- | --- |
| - | - |

**Validation (Ref:** [**Common Validation**](#_Common_Validation)**)**

**#FS10013\_S0406\_00900**

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0406\_01000**

### Review SMP Request (PDF form from ECP)

**#FS10013\_S0406\_01100**

**Description**

**#FS10013\_S0406\_01200**
This function is used to review, reject or submit for approval of the SMP Maintenance Request submitted by Exchange Participants via ECP. System downloads the PDF forms from ECP and parse the data to database for further review and process.

**UI Layout**

**#FS10013\_S0406\_01301**

Search Page

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))

![](data:image/png;base64...)

**Attributes**

**#FS10013\_S0406\_01400**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| **Identity** | | | | | |
| SMP Request ID | Numeric | 10 | M | - | **Read-only.**  A unique ID generated by System for reference only.  **Generated by System.** |
| Submit Date Time | Date and Time | 20 | M | - | **Read-only.**  Submission Date and Time of the form |
| Uploader | Alphanumeric | 5 | M | - | **Read-only.**  The ID of the Exchange Participant who uploaded this form. |
| Request Status | Char | 1 | M | - | **Read-only.**  Status of the Request.  Assigned by System.  Valid Value:  N – Wait for App. from EP  R – Ready to Submit  S – Pending Approval  J – Rejected  P – Pending Reject  F – Completed  I – Addl. EP Form Received |
| SMP ID | Numeric | 9 | M | - | **Read-only.**  A unique SMP ID Generated by System, for detail please refer to ID Generation Section.  **For Create SMP ID Request, SMP ID will be generated only when the request had been approved.** |
| **General** | | | | | |
| Last Update Date Time | Date and Time | 20 | M | - | **Read-only.**  Date time of the last status update of this SMP Request. |
| Participant ID | Alphanumeric | 5 | M | - | **Read-only.**  The ID of the Exchange Participant who initiate this request.  **It’s supposed to be the same as uploader.** |
| Consent Status | Char | 1 | O | - | **Read-only.**  Indicate whether the “Application of the use of existing SMP ID” from related Participant had been received or not.  P – Pending  I – Received  (Only available when Action = S) |
| SMP Consent ID | Numeric | 10 | O | - | **Read-only.**  Indicate the Request ID of the “Application of the use of existing SMP ID” from related Participant.  (Only available when Action = S) |
| Rejection Code | Alphanumeric | 10 | O | - | **Read-only.**  When user rejects a SMP request, it can select the rejection code from the available list to set or override the Rejection Code field. |
| **Request Detail** | | | | | |
| Type | Char | 1 | M | - | **Read-only.**  Request Form submitted from:  R – Primary Participant  C – Related Participant |
| Action | Char | 1 | O | - | **Read-only.**  Action of the SMP Maintenance.  Valid Value:  C – Creation of SMP ID  T – Termination of SMP ID  S – Sharing of SMP ID  R – Removal of SMP ID Sharing  U – Change of SMP Instruction |
| Primary Participant ID | Alphanumeric | 5 | O | - | **Read-only.**  The ID of the Exchange Participant who own this SMP ID. |
| Related Participant ID | Alphanumeric | 5 | O | - | **Read-only.**  The ID of the Exchange Participant who share this SMP ID. |
| SMP Instruction | Char | 1 | O | - | **Read-only.**  SMP Cancellation Method.  Ref: [Common Attributes](#_Common_Attributes)  - SMP Instruction |
| Creation Reference Number | Numeric | 4 | O | - | **Read-only.**  The Creation Reference Number defined by Primary Participant for keep track of the SMP ID Creation Request status.  (Only available when Action = C) |
| PDF File Name | Alphanumeric | 128 | M | - | **Read-only.**  PDF file name of the SMP Maintenance Form. |
| Last Error Code | Alphanumeric | 10 | O | - | **Read-only.**  In case the SMP Maintenance Workflow failed to execute, the corresponding error code will be assigned to this field. |
| Manual Reject Reason | Alphanumeric  **Dropdown** | 10 | O | - | User can manually select a Reject Reason when rejecting a SMP Request.  **Available when the Status is N / R.** |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0406\_01500**

**Actions**

**#FS10013\_S0406\_01600**

| Action | Description |
| --- | --- |
| Screen Open | Trigger a query to display all records |
| Apply | Trigger a query of records based on input filters |
| Reset Filters | Reset all filters to default: All |
| Export | Export all Records from GUI current page table to CSV file |
| Confirm | Confirm the change and submit to backend, disabled with Read-only permission and view mode |
| Reject | Reject the change and submit to backend, disabled with Read-only permission and view mode |
| Cancel | Back to the Search page |

**Validation**

**#FS10013\_S0406\_01700**

| Event | Validation Rule | Validation Message |
| --- | --- | --- |
| Confirm | The Submission Status must be R – Ready to Submit | Invalid Status. Status must be Ready to Submit. |
| Reject | The Submission Status must be R – Ready to Submit | Invalid Status. Status must be Ready to Submit. |

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0406\_01800**

### ID Generation

**#FS10013\_S0406\_01900**

**Description**

**#FS10013\_S0406\_02000**

System should generate the SMP ID under the following two scenarios:

1. Checker Approved a New SMP ID Record submitted by Exchange User.
2. Checker Approved a SMP ID creation Request submitted by Exchange Participant via ECP.

And two SMP ID formats are available in the System. (5 Alphanumeric Character / 9 Numeric Digit). System should generate the SMP ID based on the SMP ID Format configured in the System Preference.

**Generation Logic**

**#FS10013\_S0406\_02101**

5 Characters ID Format

The SMP ID must conform to the following rules:

1. SMP ID is always a 5-character token, 1 digit checksum + 4 alphanumeric characters.
2. SMP ID includes uppercase alphabets (excluding A E I O U) and digits (excluding 0).
3. SMP ID must include at least 1 digit and at least 1 alphabet.
4. The first character is always a digit (Check digit).
5. The 4 alphanumeric characters starts from 111B (due to rule #2 and #3) and accumulate in the sequence of 1-9B-Z.

Check digit is calculated with the following logic:

weighted\_sum = (ASCII value of the 1st character x 2

+ ASCII value of the 2nd x 5

+ ASCII value of the 3rd x 2

+ ASCII value of the 4th x 5)

check digit (literal) = (weighted\_sum % 9) + 1

9 Digits ID Format

The first 8 digits is a sequence number starting from 21,001,000 and the last digit is a check digit calculated using Damm algorithm.

## TMC

### Maintain TMC Strategy List

**#FS10013\_S0407\_00100**

**Description**

**#FS10013\_S0407\_00201**
This function is used to create, update and delete Strategy List. Strategy List is used to define several Strategies that are used to restrict TMC combo creation.

There should be one default Strategy List: 0 – No Restriction Strategy. It’s used to indicate that there is no restriction strategy for the TMC.

**UI Layout**

**#FS10013\_S0407\_00303**

Search Page

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

**Attributes**

**#FS10013\_S0407\_00401**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| **Identity** | | | | | |
| Strategy List ID | Numeric  **Text Input** | 5 | M | - | The unique ID of the Strategy list. |
| Name | Alphanumeric  **Text Input** | 12 | M | - | Name of the Strategy List |
| Description | Alphanumeric  **Text Input** | 40 | O | - | Description of the Strategy list. |

**Strategies Attributes (Up to 200 Strategies allowed)**

**#FS10013\_S0407\_00501**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Position | Numeric | 5 | - | - | **Read only.**  It’s generated by system based on the position of the record in the table. |
| Strategy | Numeric  **Text Input (with Content Assist)** | 5 | M | - | The unique ID of the Strategy. |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0407\_00600**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0407\_00701**

| Action | Description |
| --- | --- |
| Add | Add a Strategy to the Strategy List |
| Delete | Remove a Strategy from the Strategy List |
| Open | View the detail page of the Strategy |
| Up | Move the selected Strategy up by one row.  (Only one row at a time.) |
| Down | Move the selected Strategy down by one row.  (Only one row at a time.) |

**Validation (Ref:** [**Common Validation**](#_Common_Validation)**)**

**#FS10013\_S0407\_00800**

| Event | Validation Rule | Validation Message |
| --- | --- | --- |
| Add Strategy | Maximum number of Strategy is 200. | The Maximum number of Strategy reached. |
| Delete Strategy | Minium number of Strategy is 1. | At least one Strategy is required. |
| Confirm | Minium number of Strategy is 1. | Please add at least one Strategy to the Strategy List. |

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0407\_00900**

### Maintain TMC Strategy

**#FS10013\_S0407\_01000**

**Description**

**#FS10013\_S0407\_01100**

A pre-defined strategy restricts the type of strategy that can be created as TMC for trading.

**UI Layout**

**#FS10013\_S0407\_01202**

Search Page

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))

![](data:image/png;base64...)

**Attributes**

**#FS10013\_S0407\_01302**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| **Identity** | | | | | |
| Strategy ID | Numeric  **Text Input** | 5 | M | - | A unique ID of the strategy. |
| Name | Alphanumeric  **Text Input** | 12 | M | - | Name of the strategy. |
| Description | Alphanumeric  **Text Input** | 40 | O | - | Description of the strategy. |
| Short Name | Alphanumeric  **Text Input** | 15 | O | - | A short name to be used optionally for TMC instrument name. |
| **General** | | | | | |
| Allow Reversed? | Boolean  **Dropdown** | 1 | M | False | A Yes / No option, to allow reverse of existing combination. |
| Number of Legs | Numeric  **Text Input** | 1 | M | 0 | **Read-only.**  Number of TMC Strategy Leg. Filled by system. |

**Legs Table Attributes**

**#FS10013\_S0407\_01401**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Leg Number | Numeric  **Text Input** | 1 | M | - | A sequential number which acts as an identifier of the leg entry.  **Read-only. Assigned by System from 1-4 in sequence.** |
| Operation | Char  **Dropdown** | 1 | M | - | Specify the leg that should be bought or sold when buying the combo.  Ref: [Common Attributes](#_Common_Attributes)  - Side Char |
| **Ratio Parameter** | | | | | |
| Ratio Relative? | Char  **Dropdown** | 1 | M | - | Specify whether the Ratio Parameter is Relative or Exact. (Yes means Relative)  Ref: [Common Attributes](#_Common_Attributes)  - Boolean Char |
| Reference Leg | Numeric  **Dropdown** | 1 | O | - | The Leg which this parameter referred to when the condition is set to relative.  Valid values:  1 – 4  **Mandatory when Ratio Relative = Y** |
| Condition | Numeric  **Dropdown** | 1 | M | 0 | When condition is Exact, the parameter defines the exact ratio of the leg.  When condition is Relative, the parameter defines the relationship to the reference leg.  Ref: [Common Attributes](#_Common_Attributes)  - TMC Strategy Leg Condition  **Mandatory when Ratio Relative = Y.** |
| Ratio Exact | Numeric  **Dropdown** | 1 | O | 0 | Defines the exact ratio of the leg.  Valid values:  1 – 4  **Mandatory when Ratio Relative = N** |
| **Strike Price Parameter** | | | | | |
| Reference Leg | Numeric  **Dropdown** | 1 | O | - | The Leg which this parameter refers to.  Valid values:  1 – 4 |
| Condition | Numeric  **Dropdown** | 1 | M | 0 | The strike price condition relative to reference leg.  Valid values:  0 - Any  1 - Equal to Leg n  2 - Higher than Leg n  3 - Lower than Leg n  4 - Not equal to Leg n |
| **Last Trading Date Parameter** | | | | | |
| Reference Leg | Numeric  **Dropdown** | 1 | O | - | The Leg which this parameter refers to.  Valid values:  1 – 4 |
| Condition | Numeric  **Dropdown** | 1 | M | 0 | The last trading date condition relative to reference leg.  Valid values:  0 - Any  1 - Equal to Leg n  2 - Higher than Leg n  3 - Lower than Leg n  4 - Not equal to Leg n |
| **Instrument Groups** | | | | | |
| Group 1 | Alphanumeric  **Text Input**  **(With Content Assist)** | 3 | O | - | Specify the instrument group allowed for the TMC.  When all the TMC legs matches Group 1 definition, the TMC matches the Instrument Groups attribute. |
| Group 2 | Alphanumeric  **Text Input**  **(With Content Assist)** | 3 | O | - | Specify the instrument group allowed for the TMC.  When all the TMC legs matches Group 2 definition, the TMC matches the Instrument Groups attribute. |
| Group 3 | Alphanumeric  **Text Input**  **(With Content Assist)** | 3 | O | - | Specify the instrument group allowed for the TMC.  When all the TMC legs matches Group 3 definition, the TMC matches the Instrument Groups attribute. |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0407\_01500**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0407\_01600**

| Action | Description |
| --- | --- |
| Add | Add a leg to the Strategy. |
| Delete | Delete a leg from the Strategy. |
| Up | Move the selected leg up by one row.  (Only one row at a time, System will reassign the leg number.) |
| Down | Move the selected leg down by one row.  (Only one row at a time, System will reassign the leg number.) |

**Validation (Ref:** [**Common Validation**](#_Common_Validation)**)**

**#FS10013\_S0407\_01700**

| Event | Validation Rule | Validation Message |
| --- | --- | --- |
| Add Leg | Maximum number of Legs are 4. | The maximum number of legs in the Strategy had been reached. |
| Delete Leg | Minium number of Legs are 2. | Please add at least two legs to the Strategy. |
| Confirm | Minium number of Legs are 2. | Please add at least two legs to the Strategy. |

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0407\_01800**

### Control TMC

**#FS10013\_S0407\_01900**

TMC function allows market participants to define combination for trading on the same day through trading session or trading UI.

In this deferred function, user can delist a TMC in case of emergency.

**Screen Layout**

**#FS10013\_S0407\_02001**

Search Page

![](data:image/png;base64...)

**Attributes**

**#FS10013\_S0407\_02100**

| **Column** | **Type** | **Length** | **M/O** | **Default** | **Remarks** |
| --- | --- | --- | --- | --- | --- |
| **Identity** | | | | | |
| TMC ID | Alphanumeric | 32 | M | - | A unique ID representing the TMC. |
| Combo Class ID | Alphanumeric | 14 | M | - | The ID of the Combo Class this Combo belongs to. |
| **General** | | | | | |
| Status | Char | 1 | M | A | The Combo status, valid values are:   1. Active – The combo is available for trading. 2. Suspended – The combo is suspended from trading. 3. Delisted – The TMC had been delisted. (Only applicable to TMC) |
| Effective Date | Date | 11 | O | - | The date that this combo is effective in the system. |
| **Dates** | | | | | |
| Last Trading Date | Date | 11 | O | - | The final day the instrument can be traded.  The last trading date and time must be earlier than or equal to the earliest last trading date and time in any one of the legs. |
| Effective Last Trading Date | Date | 11 | O | - | As the Last Trading Date is a component of legacy combo ID, and ID should not be amended due to Last Trading Date changes.  This attribute will be used for Last Trading Date reference for both EP, downstream systems and trading system instrument operation. |
| Last Trading Time | Time | 5 | O | - | The final time on the last trading date the combo can be traded.  The last trading date and time must be earlier than or equal to the earliest last trading date and time in any one of the legs. |
| First Trading Date | Date | 11 | O | - | The first day the instrument can be traded.  The first trading date and time must be later than or equal to the latest first trading date and time in any one of the legs. |
| First Trading Time | Time | 5 | O | - | The beginning time on the first trading date the combo can be traded.  The first trading date and time must be later than or equal to the latest first trading date and time in any one of the legs.  This attribute is optional. When empty, the instrument starts trading according to the trading timetable. |
| **(Leg 1 - 4)** | | | | | |
| Operation | Char | 1 | M | - | The operation of the Leg.  Ref: [Common Attributes](#_Common_Attributes)  - Side Char  The valid values are:   1. Buy – Buy the leg instrument when buying the Combo. 2. Sell – Sell the leg instrument when buying the Combo. |
| Ratio | Numeric | 5 | M | - | The ratio of the Leg. |
| Instrument ID | Alphanumeric | 32 | M | - | The ID of instrument for the Leg. |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0407\_02200**

**Actions**

**#FS10013\_S0407\_02301**

| Action | Description |
| --- | --- |
| Screen Open | Trigger a query to display all records |
| Apply | Trigger a query of records based on input filters |
| Reset Filters | Reset all filters to default: All |
| Delist | Delist an Active TMC. (All the Orders for the TMC must be manually cancelled before delist the TMC.)  Once the TMC is delisted, it’s status will be checked to Delisted. The delisted TMC will remains searchable in Maintain Combo function. |
| Export | Export all Records from GUI current page table to CSV file |

**Validation**

**#FS10013\_S0407\_02400**

| Event | Validation Rule | Validation Message |
| --- | --- | --- |
| Delist | TMC should be in Active / Suspended status. | The TMC is not allowed to delist. |

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0407\_02500**

## Price Supervision

**#FS10013\_S0408\_00100**

### Maintain Price Tick

**#FS10013\_S0408\_00200**

**Description**

**#FS10013\_S0408\_00300**

**Price Tick** is used to define the lowest and the highest allowable prices, the decimal place allowed and valid price interval (i.e. tick size) per price range allowed for a product.

**UI Layout**

**#FS10013\_S0408\_00402**

Search Page

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...) ![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

**Attributes**

**#FS10013\_S0408\_00507**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Price Tick ID | Numeric | 5 | M | - | The ID of the Price Tick |
| Name | Alphanumeric | 12 | M | - | A unique name of the Price Tick |
| Description | Alphanumeric | 40 | O | - | Description of the Price Tick |
| Decimals | Numeric | 2 | M | - | Decimal place allowed, implied decimal place in price format.  Will be used in orders, quotes and block trades too. |
| Default Lower Limit | Price | 19  (Additionally, plus 1 if include “- “or “.”) | M | - | Default Lower Limit |
| Default Upper Limit | Price | 19  (Additionally, plus 1 if include “- “or “.”) | M | - | Default Upper Limit |
| Orders/Quotes Prick Tick Band | - | - | - | - | List of Price Tick Band of Order/Quotes |
| Block Trade Follow Order? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| Block Trade Orders/Quotes Prick Tick Band | - | - | - | - | List of Block Trade Orders/Quotes Prick Tick Band  Will be dimmed if Block Trade Follow Orders/Quotes - ‘Y’ |

**Price Tick Orders/Quotes/Block Trade Band Attribute**

**#FS10013\_S0408\_00601**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Price Tick ID | Numeric | 5 | M | - | Price Tick ID |
| Price To | Price | 19  (Additionally, plus 1 if include “- “or “.”) | M | - | Price To |
| Tick Size | Price | 19  (Additionally, plus 1 if include “- “or “.”) | M | - | Tick Size |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0408\_00700**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0408\_00800**

| Action | Description |
| --- | --- |
| - | - |

**Validation (Ref:** [**Common Validation**](#_Common_Validation), [**Validation Rule**](#_Validation_Rule_(TBC))**)**

**#FS10013\_S0408\_00901**

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0408\_01000**

### Maintain Price Tick Limit Rule

**#FS10013\_S0408\_01101**

**Description**

**#FS10013\_S0408\_01202**

**Price Tick Limits Rule** is used to define the upper and the lower limit of allowable prices per instrument class and combo class. If not specified, default upper and lower limits defined in price tick table will be used. Incoming orders, quotes and block trades will be rejected if the price is outside the price tick limits.

**UI Layout**

**#FS10013\_S0408\_01302**

Search Page

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

**Attributes**

**#FS10013\_S0408\_01403**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Price Tick Limit ID | Numeric | 5 | M | - | The ID of the Price Tick Limit |
| Name | Alphanumeric | 12 | M | - | A unique name of the Price Tick Limit |
| Description | Alphanumeric | 40 | O | - | Description of the Price Tick Limit |
| Limit Deviation Unit | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Deviation Unit  Can be T/P |
| Deviation Tick | Numeric | 5 | O | - | Deviation Tick  Applicable only if Limit Deviation Unit = T |
| Exception Deviation Tick | Numeric | 5 | O | - | Exception Deviation Tick  Applicable only if Limit Deviation Unit = T |
| Deviation Percentage | Percentage | 9 | O | - | Deviation Percentage  Applicable only if Limit Deviation Unit = P |
| Exception Deviation Percentage | Percentage | 9 | O | - | Exception Deviation Percentage  Applicable only if Limit Deviation Unit = P |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0408\_01500**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0408\_01600**

| Action | Description |
| --- | --- |
| - | - |

**Validation (Ref:** [**Common Validation**](#_Common_Validation), [**Validation Rule**](#_Validation_Rule_(TBC))**)**

**#FS10013\_S0408\_01701**

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0408\_01800**

### Maintain Instrument Class Price Tick Limit

**#FS10013\_S0408\_01900**

**Description**

**#FS10013\_S0408\_02000**

**Instrument Class Price Tick Limit** is used to define the upper and the lower limit of allowable prices per **Instrument Class**.

**UI Layout**

**#FS10013\_S0408\_02101**

Search Page

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

**Attributes**

**#FS10013\_S0408\_02202**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Instrument Class ID | Alphanumeric | 14 | M | - | The ID of the Instrument Class |
| Price Tick Reference Price | Price | 19  (Additionally, plus 1 if include “- “or “.”) | O | - | Price Tick Reference Price |
| Price Tick Lower Limit | Price | 19  (Additionally, plus 1 if include “- “or “.”) | O | - | Price Tick Lower Limit |
| Price Tick Upper Limit | Price | 19  (Additionally, plus 1 if include “- “or “.”) | O | - | Price Tick Upper Limit |
| Next Day Price Tick Reference Price | Price | 19  (Additionally, plus 1 if include “- “or “.”) | O | - | Next Day Price Tick Reference Price |
| Next Day Price Tick Lower Limit | Price | 19  (Additionally, plus 1 if include “- “or “.”) | O | - | Next Day Price Tick Lower Limit |
| Next Day Price Tick Upper Limit | Price | 19  (Additionally, plus 1 if include “- “or “.”) | O | - | Next Day Price Tick Upper Limit |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0408\_02300**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0408\_02401**

| Action | Description |
| --- | --- |
| Add | Not allowed |
| Delete | Not allowed |

**Validation (Ref:** [**Common Validation**](#_Common_Validation), [**Validation Rule**](#_Validation_Rule_(TBC))**)**

**#FS10013\_S0408\_02501**

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0408\_02600**

### Maintain Combo Class Price Tick Limit

**#FS10013\_S0408\_02700**

**Description**

**#FS10013\_S0408\_02800**

**Combo Class Price Tick Limit** is used to define the upper and the lower limit of allowable prices per **Combo Class**.

**UI Layout**

**#FS10013\_S0408\_02902**

Search Page

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

**Attributes**

**#FS10013\_S0408\_03001**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Combo Class ID | Alphanumeric | 14 | M | - | The ID of the Combo Class |
| Price Tick Upper Limit | Price | 19  (Additionally, plus 1 if include “- “or “.”) | O | - | Price Tick Upper Limit |
| Price Tick Lower Limit | Price | 19  (Additionally, plus 1 if include “- “or “.”) | O | - | Price Tick Lower Limit |
| Price Tick Reference Price | Price | 19  (Additionally, plus 1 if include “- “or “.”) | O | - | Price Tick Reference Price |
| Next Day Price Tick Upper Limit | Price | 19  (Additionally, plus 1 if include “- “or “.”) | O | - | Next Day Price Tick Upper Limit |
| Next Day Price Tick Lower Limit | Price | 19  (Additionally, plus 1 if include “- “or “.”) | O | - | Next Day Price Tick Lower Limit |
| Next Day Price Tick Reference Price | Price | 19  (Additionally, plus 1 if include “- “or “.”) | O | - | Next Day Price Tick Reference Price |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0408\_03100**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0408\_03201**

| Action | Description |
| --- | --- |
| Add | Not allowed |
| Delete | Not allowed |

**Validation (Ref:** [**Common Validation**](#_Common_Validation), [**Validation Rule**](#_Validation_Rule_(TBC))**)**

**#FS10013\_S0408\_03301**

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0408\_03400**

### Maintain Price Limit

**#FS10013\_S0408\_03500**

**Description**

**#FS10013\_S0408\_03600**

**Price Limit** is used to protect exchange participants and the exchange from unintended executions due to erroneous input price. The system will monitor and reject orders, quotes and block trades if their price is outside the defined price limits. Implied orders generated for outright order books are also monitored by price limit function and price alignment with price limit for implied orders will be applied if needed.

**UI Layout**

**#FS10013\_S0408\_03700**

Search Page

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

**Attributes**

**#FS10013\_S0408\_03802**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Price Limit ID | Numeric | 5 | M | - | The ID of the Price Limit |
| Name | Alphanumeric | 12 | M | - | A unique name of the Price Limit |
| Description | Alphanumeric | 40 | O | - | Description of the Price Limit |
| Price Limit Items | - | - | - | - | List of Price Limit Items |

**Price Limit Item Attribute**

**#FS10013\_S0408\_03900**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Trading State ID | Numeric | 5 | M | - | Trading State ID |
| Price Limit Parameters ID | Numeric | 5 | M | - | Price Limit Parameters ID |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0408\_04000**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0408\_04100**

| Action | Description |
| --- | --- |
| - | - |

**Validation (Ref:** [**Common Validation**](#_Common_Validation), [**Validation Rule**](#_Validation_Rule_(TBC))**)**

**#FS10013\_S0408\_04201**

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0408\_04300**

### Maintain Price Limit Parameters

**#FS10013\_S0408\_04400**

**Description**

**#FS10013\_S0408\_04500**

**Price Limit Parameters** are used to set parameters for **Price Limit**.

**UI Layout**

**#FS10013\_S0408\_04605**

Search Page

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))

![](data:image/png;base64...) ![](data:image/png;base64...) ![](data:image/png;base64...)

**Attributes**

**#FS10013\_S0408\_04714**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Price Limit Parameters ID | Numeric | 5 | M | - | The ID of the Price Limit Parameters |
| Name | Alphanumeric | 12 | M | - | A unique name of the Price Limit Parameters |
| Description | Alphanumeric | 40 | O | - | Description of the Price Limit Parameters |
| Static Price Limit > Limit Deviation Unit | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Limit Deviation Unit  Can be A/P |
| Static Price Limit Rule Band | - | - | - | - | Static Price Limit Rule Band |
| Static Reference Price Source ID | Numeric | 5 | O | - | Static Reference Price Source ID |
| Remove Orders Outside Static Price Limit? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| Scope | Numeric | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Scope |
| Static Price Limit Alert Rule Band | - | - | - | - | Static Price Limit Alert Rule Band |
| Trading Halt - Instrument Class ID | Alphanumeric | 14 | O | - | Trading Halt - Instrument Class ID |
| Dynamic Last Traded Price Deviation Unit | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Deviation Unit  Can be A/P |
| Dynamic Last Traded Price Deviation Abs Value | Price | 18 | O | - | Dynamic Last Traded Price Deviation Abs Value  Applicable only if Dynamic Last Traded Price Deviation Unit = A  Support 13 + “.” + 4 decimal places |
| Dynamic Last Traded Price Deviation Percentage | Percentage | 8 | O | - | Dynamic Last Traded Price Deviation Percentage  Applicable only if Dynamic Last Traded Price Deviation Unit = P  Support 5 + “.” + 2 decimal places |
| Dynamic Price Limit Rule Band | - | - | - | - | Dynamic Price Limit Rule Band |
| Resumption Cooling-Off Interval | Numeric | 10 | O | - | Resumption Cooling-Off Interval |
| No Resumption Period | Numeric | 10 | O | - | No Resumption Period |
| Upper Resumption Level | Numeric | 20 | O | - | Upper Resumption Level |
| Lower Resumption Level | Numeric | 20 | O | - | Lower Resumption Level |

**Static/Dynamic Price Limit Rule Band Attribute**

**#FS10013\_S0408\_04805**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Expiration From | Numeric | 10 | M | - | Expiration From |
| Expiration To | Numeric | 10 | M | - | Expiration To |
| Upper Limit (%) | Percentage | 8 | O | - | Upper Limit (%)  Applicable only if Static Price Limit Deviation Unit = P  Support 5 + “.” + 2 decimal places |
| Upper Limit (Abs) | Price | 18 | O | - | Upper Limit (Abs)  Applicable only if Static Price Limit Deviation Unit = A  Support 13 + “.” + 4 decimal places |
| Lower Limit (%) | Percentage | 8 | O | - | Lower Limit (%)  Applicable only if Static Price Limit Deviation Unit = P  Support 5 + “.” + 2 decimal places |
| Lower Limit (Abs) | Price | 18 | O | - | Lower Limit (Abs)  Applicable only if Static Price Limit Deviation Unit = A  Support 13 + “.” + 4 decimal places |

**Static Price Limit Alert Rule Band Attribute**

**#FS10013\_S0408\_04852**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Upper Limit (%) | Percentage | 8 | O | - | Upper Limit (%)  Applicable only if Static Price Limit Deviation Unit = P  Support 5 + “.” + 2 decimal places |
| Upper Limit (Abs) | Price | 18 | O | - | Upper Limit (Abs)  Applicable only if Static Price Limit Deviation Unit = A  Support 13 + “.” + 4 decimal places |
| Lower Limit (%) | Percentage | 8 | O | - | Lower Limit (%)  Applicable only if Static Price Limit Deviation Unit = P  Support 5 + “.” + 2 decimal places |
| Lower Limit (Abs) | Price | 18 | O | - | Lower Limit (Abs)  Applicable only if Static Price Limit Deviation Unit = A  Support 13 + “.” + 4 decimal places |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0408\_04900**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0408\_05000**

| Action | Description |
| --- | --- |
| - | - |

**Validation (Ref:** [**Common Validation**](#_Common_Validation), [**Validation Rule**](#_Validation_Rule_(TBC))**)**

**#FS10013\_S0408\_05101**

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0408\_05200**

### Maintain Reference Price Source

**#FS10013\_S0408\_05300**

**Description**

**#FS10013\_S0408\_05400**

**Reference Price Source** is used to define Reference Price Source.

**UI Layout**

**#FS10013\_S0408\_05500**

Search Page

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

**Attributes**

**#FS10013\_S0408\_05604**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Reference Price Source ID | Numeric | 5 | M | - | The ID of the Reference Price Source |
| Name | Alphanumeric | 12 | M | - | A unique name of the Reference Price Source |
| Description | Alphanumeric | 40 | O | - | Description of the Reference Price Source |
| Price Source | Numeric | 5 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Price Source |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0408\_05700**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0408\_05800**

| Action | Description |
| --- | --- |
| - | - |

**Validation (Ref:** [**Common Validation**](#_Common_Validation), [**Validation Rule**](#_Validation_Rule_(TBC))**)**

**#FS10013\_S0408\_05901**

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0408\_06000**

### Maintain Reference Price Calculation Rule

**#FS10013\_S0408\_06100**

**Description**

**#FS10013\_S0408\_06200**

**Reference Price Calculation Rule** is used to define Reference Price Calculation Rule.

**UI Layout**

**#FS10013\_S0408\_06302**

Search Page

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290)) ![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

**Attributes**

**#FS10013\_S0408\_06404**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Calculation Rule ID | Numeric | 5 | M | - | The ID of the Reference Price Calculation Rule |
| Name | Alphanumeric | 12 | M | - | A unique name of the Reference Price Calculation Rule |
| Description | Alphanumeric | 40 | O | - | Description of the Reference Price Calculation Rule |
| Price Data Option | - | - | - | - | Price Data Option |

**Reference Price Calculation Rule Item Attribute**

**#FS10013\_S0408\_06501**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Price Data Option | Numeric | 5 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Price Data Option |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0408\_06600**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0408\_06700**

| Action | Description |
| --- | --- |
| - | - |

**Validation (Ref:** [**Common Validation**](#_Common_Validation), [**Validation Rule**](#_Validation_Rule_(TBC))**)**

**#FS10013\_S0408\_06801**

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0408\_06900**

### Maintain VCM

**#FS10013\_S0408\_07000**

**Description**

**#FS10013\_S0408\_07100**
**Volatility Control Mechanism (VCM)** is used to protect the market from disorderliness caused by extreme price volatility. If the potential matched price deviates more than a pre-defined percentage within a specific time frame, it will trigger a cooling-off period in which trading is allowed at or within a fixed price band. After the cooling-off period, trading will resume to normal with **VCM** monitoring. **VCM** is allowed to be triggered multiple times per trading session.

**UI Layout**

**#FS10013\_S0408\_07200**

Search Page

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

**Attributes**

**#FS10013\_S0408\_07303**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| VCM ID | Numeric | 5 | M | - | The ID of the VCM |
| Name | Alphanumeric | 12 | M | - | A unique name of the VCM |
| Description | Alphanumeric | 40 | O | - | Description of the VCM |
| VCM Items | - | - | - | - | VCM Items |

**VCM Item Attribute**

**#FS10013\_S0408\_07401**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Trading State ID | Numeric | 5 | M | - | Trading State ID |
| VCM Parameters ID | Numeric | 5 | M | - | VCM Parameters ID |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0408\_07500**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0408\_07600**

| Action | Description |
| --- | --- |
| - | - |

**Validation (Ref:** [**Common Validation**](#_Common_Validation), [**Validation Rule**](#_Validation_Rule_(TBC))**)**

**#FS10013\_S0408\_07701**

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0408\_07800**

### Maintain VCM Parameters

**#FS10013\_S0408\_07900**

**Description**

**#FS10013\_S0408\_08000**

**VCM Parameters** is used to define parameters for VCM.

**UI Layout**

**#FS10013\_S0408\_08102**

Search Page

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

**Attributes**

**#FS10013\_S0408\_08202**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| VCM Parameters ID | Numeric | 5 | M | - | The ID of the VCM Parameters |
| Name | Alphanumeric | 12 | M | - | A unique name of the VCM Parameters |
| Description | Alphanumeric | 40 | O | - | Description of the VCM Parameters |
| Limit Deviation Unit | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Deviation Unit  Can be A/P |
| List of Price Limit Rule Band | - | - | - | - | List of Price Limit Rule Band |
| Delay Time (second) | Numeric | 10 | M | - | Delay Time in second |
| Cooling-Off Interval (second) | Numeric | 10 | M | - | Cooling-Off Interval in second |
| Max Triggers | Numeric | 10 | M | - | Max Triggers |
| Automatic VCM Re-enable? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |

**Price Limit Rule Band Attribute**

**#FS10013\_S0408\_08303**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Expiration From | Numeric | 10 | M | - | Expiration From |
| Expiration To | Numeric | 10 | M | - | Expiration To |
| Upper Limit (%) | Percentage | 8 | O | - | Upper Limit (%)  Applicable only if Limit Deviation Unit = P  Support 5 + “.” + 2 decimal places |
| Upper Limit (Abs) | Price | 18 | O | - | Upper Limit (Abs)  Applicable only if Limit Deviation Unit = A  Support 13 + “.” + 4 decimal places |
| Lower Limit (%) | Percentage | 8 | O | - | Lower Limit (%)  Applicable only if Limit Deviation Unit = P  Support 5 + “.” + 2 decimal places |
| Lower Limit (Abs) | Price | 18 | O | - | Lower Limit (Abs)  Applicable only if Limit Deviation Unit = A  Support 13 + “.” + 4 decimal places |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0408\_08400**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0408\_08500**

| Action | Description |
| --- | --- |
| - | - |

**Validation (Ref:** [**Common Validation**](#_Common_Validation), [**Validation Rule**](#_Validation_Rule_(TBC))**)**

**#FS10013\_S0408\_08601**

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0408\_08700**

### Maintain Futures Group

**#FS10013\_S0408\_08800**

**Description**

**#FS10013\_S0408\_08900**

**Futures Group** consists of one or more calculation rules with the specification of the contract month and the trading day.

**UI Layout**

**#FS10013\_S0408\_09000**

Search Page

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

**Attributes**

**#FS10013\_S0408\_09102**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Futures Group ID | Numeric | 5 | M | - | The ID of the Futures Group |
| Name | Alphanumeric | 12 | M | - | A unique name of the Futures Group |
| Description | Alphanumeric | 40 | O | - | Description of the Futures Group |
| Futures Group Items | - | - | - | - | Futures Group |

**Futures Group Item Attribute**

**#FS10013\_S0408\_09201**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Contract Month | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Contract Month Option |
| Trading Day | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Trading Day Option |
| Calculation Rule ID | Numeric | 5 | M | - | Calculation Rule ID |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0408\_09300**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0408\_09400**

| Action | Description |
| --- | --- |
| - | - |

**Validation (Ref:** [**Common Validation**](#_Common_Validation), [**Validation Rule**](#_Validation_Rule_(TBC))**)**

**#FS10013\_S0408\_09501**

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0408\_09600**

### Control & Monitor Price Limit

**#FS10013\_S0408\_09700**

**Description**

**#FS10013\_S0408\_09800**

**Control & Monitor Price Limit** is used to control & monitor **Price Limit**.

**UI Layout**

**#FS10013\_S0408\_09904**

![](data:image/png;base64...)

**Attributes**

**#FS10013\_S0408\_10002**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Instrument ID | - | - | - | - | Read-only field.  The ID of the Instrument. |
| Effective Price Limits | - | - | - | - | Effective Price Limits |
| Static Price Limits | - | - | - | - | Static Price Limits |
| Dynamic Price Limits | - | - | - | - | Dynamic Price Limits |

**Static/Dynamic Price Limits Attributes**

**#FS10013\_S0408\_10104**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Manually Updated Ref Price | Price | 19  (Additionally, plus 1 if include “.”) | O | - | Manually Updated Ref Price |
| Effective Ref Price | - | - | - | - | Read-only field.  Effective Ref Price |
| Calculated Ref Price | - | - | - | - | Read-only field.  Calculated Ref Price (Static Price Limit only) |
| Upper Price | - | - | - | - | Read-only field.  Upper Price |
| Lower Price | - | - | - | - | Read-only field.  Lower Price |
| Upper Limit | Percentage | 8 | O | - | Upper Limit (%)  Applicable only if Unit = P  Support 5 + “.” + 2 decimal places |
| Upper Limit | Numeric | 18 | O | - | Upper Limit (Abs)  Applicable only if Unit = A  Support 13 + “.” + 4 decimal places |
| Lower Limit | Percentage | 8 | O | - | Lower Limit (%)  Applicable only if Unit = P  Support 5 + “.” + 2 decimal places |
| Lower Limit | Numeric | 18 | O | - | Lower Limit (Abs)  Applicable only if Unit = A  Support 13 + “.” + 4 decimal places |
| Unit | Char | 1 | O | - | Ref: [Common Attributes](#_Common_Attributes) - Deviation Unit  Can be A/P |

**Effective Price Limits Attributes**

**#FS10013\_S0408\_10200**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Upper Price | - | - | - | - | Read-only field.  Calculated based on static and dynamic Upper Price |
| Lower Price | - | - | - | - | Read-only field.  Calculated based on static and dynamic Lower Price |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0408\_10300**

**Actions**

**#FS10013\_S0408\_10400**

| Action | Description |
| --- | --- |
| Screen Open | Trigger a query to display all records |
| Apply | Trigger a query of records based on input filters |
| Reset Filters | Reset all filters to default: All |
| Confirm | Confirm the change and submit to backend, disabled with Read-only permission and view mode |
| Cancel | Cancel all changes, disabled with Read-only permission and view mode |

**Validation**

**#FS10013\_S0408\_10500**

| Event | Validation Rule | Validation Message |
| --- | --- | --- |
| Update Request | Invalid value input | Invalid Input |

**Notification**

**#FS10013\_S0408\_10600**

| Event | Notification |
| --- | --- |
| Update | Pop up concurrent notification if any concurrent update occurred |

### Control & Monitor VCM

**#FS10013\_S0408\_10700**

**Description**

**#FS10013\_S0408\_10800**

**Control & Monitor VCM** is used to control & monitor **VCM**.

**UI Layout**

**#FS10013\_S0408\_10903**

![](data:image/png;base64...)

**Attributes**

**#FS10013\_S0408\_11001**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Instrument ID | Alphanumeric | 32 | M | - | Read-only field.  Instrument ID |
| VCM Status | - | - | - | - | VCM Status |
| VCM Price Limits | - | - | - | - | Price Limits |

**VCM Status Attributes**

**#FS10013\_S0408\_11103**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| In VCM cooling-off period? | - | - | - | - | Read-only field.  Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| Start Time | - | - | - | - | Read-only field.  Start Time |
| End Time | - | - | - | - | Read-only field.  End Time |

**Price Limits Attributes**

**#FS10013\_S0408\_11203**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Manually Updated Ref Price | Price | 19  (Additionally, plus 1 if include “.”) | O | - | Manually Updated Ref Price |
| Effective Ref Price | - | - | - | - | Read-only field.  Effective Ref Price |
| Upper Price | - | - | - | - | Read-only field.  Upper Price |
| Lower Price | - | - | - | - | Read-only field.  Lower Price |
| Upper Limit | Percentage | 8 | O | - | Upper Limit (%)  Applicable only if Unit = P  Support 5 + “.” + 2 decimal places |
| Upper Limit | Numeric | 18 | O | - | Upper Limit (Abs)  Applicable only if Unit = A  Support 13 + “.” + 4 decimal places |
| Lower Limit | Percentage | 8 | O | - | Lower Limit (%)  Applicable only if Unit = P  Support 5 + “.” + 2 decimal places |
| Lower Limit | Numeric | 18 | O | - | Lower Limit (Abs)  Applicable only if Unit = A  Support 13 + “.” + 4 decimal places |
| Unit | Char | 1 | O | - | Ref: [Common Attributes](#_Common_Attributes) - Deviation Unit  Can be A/P |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0408\_11300**

**Actions**

**#FS10013\_S0408\_11401**

| Action | Description |
| --- | --- |
| Screen Open | Trigger a query to display all records |
| Apply | Trigger a query of records based on input filters |
| Reset Filters | Reset all filters to default: All |
| Stop VCM | Stop VCM for selected records |
| Confirm | Confirm the change and submit to backend, disabled with Read-only permission and view mode |
| Cancel | Cancel all changes, disabled with Read-only permission and view mode |

**Validation**

**#FS10013\_S0408\_11500**

| Event | Validation Rule | Validation Message |
| --- | --- | --- |
| Update Request | Invalid value input | Invalid Input |

**Notification**

**#FS10013\_S0408\_11600**

| Event | Notification |
| --- | --- |
| Update | Pop up concurrent notification if any concurrent update occurred |

### Control & Monitor Instrument Trading Halt

**#FS10013\_S0408\_11700**

**Description**

**#FS10013\_S0408\_11800**

**Control & Monitor Instrument Trading Halt** is used to control & monitor **Instrument Trading Halt**.

**UI Layout**

**#FS10013\_S0408\_11900**

![A white rectangular object with a black border  Description automatically generated](data:image/png;base64...)

**Attributes**

**#FS10013\_S0408\_12000**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Instrument ID | - | - | - | - | Read-only field.  Instrument ID |
| Halt? | - | - | - | - | Read-only field.  Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0408\_12100**

**Actions**

**#FS10013\_S0408\_12200**

| Action | Description |
| --- | --- |
| Screen Open | Trigger a query to display all records |
| Apply | Trigger a query of records based on input filters |
| Reset Filters | Reset all filters to default: All |
| Halt | Halt selected Instrument ID |
| Resume | Resume selected Halted Instrument ID |

**Validation**

**#FS10013\_S0408\_12300**

| Event | Notification |
| --- | --- |
| Halt | At least one Instrument ID selected |
| Resume | At least one Halted Instrument ID selected |

**Notification**

**#FS10013\_S0408\_12400**

| Event | Notification |
| --- | --- |
| Halt/Resume | Pop up notification to indicate the Halt/Resume command is sent successfully or not |

### Control Contingency Trigger of Inst. Class Price Tick Limit Calculation

**#FS10013\_S0408\_12501**

**Description**

**#FS10013\_S0408\_12601**

**Control Contingency Trigger of Inst. Class Price Tick Limit Calculation** is used to Control Contingency Trigger of Instrument Class Price Tick Limit Calculation.

**UI Layout**

**#FS10013\_S0408\_12700**![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

**Attributes**

**#FS10013\_S0408\_12801**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Instrument Class ID | - | - | - | - | Read-only field.  Instrument Class ID |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0408\_12900**

**Actions**

**#FS10013\_S0408\_13000**

| Action | Description |
| --- | --- |
| Screen Open | Trigger a query to display all records |
| Apply | Trigger a query of records based on input filters |
| Reset Filters | Reset all filters to default: All |
| Calculate | Calculate Price Tick Limit of selected Instrument Class ID |

**Validation**

**#FS10013\_S0408\_13100**

| Event | Notification |
| --- | --- |
| Calculate | At least one Instrument Class ID selected |

**Notification**

**#FS10013\_S0408\_13200**

| Event | Notification |
| --- | --- |
| Calculate | Pop up notification to indicate the Calculate command is sent successfully or not |

### Control Contingency Trigger of AHT Reference Price Calculation

**#FS10013\_S0408\_13300**

**Description**

**#FS10013\_S0408\_13400**

**Control Contingency Trigger of AHT Reference Price Calculation** is used to control Contingency Trigger of AHT Reference Price Calculation.

**UI Layout**

**#FS10013\_S0408\_13501** **![](data:image/png;base64...)**

**Attributes**

**#FS10013\_S0408\_13602**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Hierarchy Level | - | - | - | - | Ref: [Common Attributes](#_Common_Attributes) - Hierarchy Level |
| Entity | - | - | - | - | Entity of the Level |
| Description | - | - | - | - | Description of the Entity |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0408\_13700**

**Actions**

**#FS10013\_S0408\_13801**

| Action | Description |
| --- | --- |
| Screen Open | Trigger a query to display all records |
| Apply | Trigger a query of records based on input filters |
| Reset Filters | Reset all filters to default: All |
| Calculate | Calculate AHT Reference Price of selected Entities |

**Validation**

**#FS10013\_S0408\_13900**

| Event | Notification |
| --- | --- |
| Calculate | At least one Instrument Class ID selected |

**Notification**

**#FS10013\_S0408\_14000**

| Event | Notification |
| --- | --- |
| Calculate | Pop up notification to indicate the Calculate command is sent successfully or not |

### Control Contingency Trigger of Combo Class Price Tick Limit Calculation

**#FS10013\_S0408\_14100**

**Description**

**#FS10013\_S0408\_14200**

**Control Contingency Trigger of Combo Class Price Tick Limit Calculation** is used to Control Contingency Trigger of Combo Class Price Tick Limit Calculation.

**UI Layout**

**#FS10013\_S0408\_14300![](data:image/png;base64...)**

**Attributes**

**#FS10013\_S0408\_14400**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Combo Class ID | - | - | - | - | Read-only field.  Combo Class ID |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0408\_14500**

**Actions**

**#FS10013\_S0408\_14600**

| Action | Description |
| --- | --- |
| Screen Open | Trigger a query to display all records |
| Apply | Trigger a query of records based on input filters |
| Reset Filters | Reset all filters to default: All |
| Calculate | Calculate Price Tick Limit of selected Combo Class ID |

**Validation**

**#FS10013\_S0408\_14700**

| Event | Notification |
| --- | --- |
| Calculate | At least one Combo Class ID selected |

**Notification**

**#FS10013\_S0408\_14800**

| Event | Notification |
| --- | --- |
| Calculate | Pop up notification to indicate the Calculate command is sent successfully or not |

## Block Trade

**#FS10013\_S0409\_00100**

### Maintain Block Trade Group

**#FS10013\_S0409\_00200**

**Description**

**#FS10013\_S0409\_00300**

**Block Trade Group** is used to define block trade group attributes.

**UI Layout**

**#FS10013\_S0409\_00400**

Search Page

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290)) ![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

**Attributes**

**#FS10013\_S0409\_00500**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Block Trade Group ID | Numeric | 5 | M | - | The ID of the Block Trade Group |
| Name | Alphanumeric | 12 | M | - | A unique name of the Block Trade Group |
| Description | Alphanumeric | 40 | O | - | Description of the Block Trade Group |
| Internal Allowed? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  Whether internal block trade is allowed or not |
| Interbank Allowed? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  Whether interbank block trade is allowed or not |
| On-behalf Allowed? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  Whether on-behalf block trade is allowed or not |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0409\_00600**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0409\_00700**

| Action | Description |
| --- | --- |
| - | - |

**Validation (Ref:** [**Common Validation**](#_Common_Validation), [**Validation Rule**](#_Validation_Rule_(TBC))**)**

**#FS10013\_S0409\_00800**

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0409\_00900**

### Maintain Block Trade MVT

**#FS10013\_S0409\_01000**

**Description**

**#FS10013\_S0409\_01100**

**Block Trade MVT** is used to define block trade minimum volume thresholds attributes.

**UI Layout**

**#FS10013\_S0409\_01201**

Search Page

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

**Attributes**

**#FS10013\_S0409\_01301**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Block Trade MVT ID | Numeric | 5 | M | - | The ID of the Block Trade MVT |
| Name | Alphanumeric | 12 | M | - | A unique name of the Block Trade MVT |
| Description | Alphanumeric | 40 | O | - | Description of the Block Trade MVT |
| MVT Band | - | - | - | - | MVT Band |

**MVT Band Attribute**

**#FS10013\_S0409\_01401**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Expiration To | Numeric | 10 | M | - | Expiration To |
| MVT | Quantity | 9 | M | - | MVT |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0409\_01500**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0409\_01600**

| Action | Description |
| --- | --- |
| - | - |

**Validation (Ref:** [**Common Validation**](#_Common_Validation), [**Validation Rule**](#_Validation_Rule_(TBC))**)**

**#FS10013\_S0409\_01700**

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0409\_01800**

## Error Trade

### Maintain Combo Type Error Trade Parameters

**#FS10013\_S0410\_00100**

**Description**

**#FS10013\_S0410\_00200**

**Maintain Combo Type Error Trade Parameters** is used to maintain the configuration parameters for Combo Type Error Trade.

**UI Layout**

**#FS10013\_S0410\_00303**

Search Page

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Current_Record_and))

![](data:image/png;base64...)

**Attributes**

**#FS10013\_S0410\_00403**

| **Column** | **Type** | **Length** | **M/O** | **Default** | **Remarks** |
| --- | --- | --- | --- | --- | --- |
| Combo Type ID | Alphanumeric | 8 | M | - | Identity of the Combo Type |
| Prescribed Time Limit (minutes) | Numeric | 10 | M | - | The Prescribed Time Limit in minute |
| Contra EP Response Limit (minutes) | Numeric | 10 | M | - | The Contra EP Response Limit in minutes |
| Accept Msg Template ID | Numeric | 5 | O | - | Accept Msg Template ID |
| Reject Msg Template ID | Numeric | 5 | O | - | Reject Msg Template ID |
| Cancel Msg Template ID (By Participant) | Numeric | 5 | O | - | Cancel Msg Template ID (By Participant) |
| Cancel Msg Template ID (By Committee) | Numeric | 5 | O | - | Cancel Msg Template ID (By Committee) |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0410\_00500**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**, except the New Record)**

**#FS10013\_S0410\_00600**

**Validation (Ref:** [**Common Validation**](#_Common_Validation), [**Validation Rule**](#_Validation_Rule_(TBC))**)**

**#FS10013\_S0410\_00701**

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0410\_00800**

### Maintain Instrument Type Error Trade Parameters

**#FS10013\_S0410\_00900**

**Description**

**#FS10013\_S0410\_01000**

**Maintain Instrument Type Error Trade Parameters** is used to maintain the configuration parameters for Instrument Type Error Trade.

**UI Layout**

**#FS10013\_S0410\_01102**

Search Page

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Current_Record_and))

![](data:image/png;base64...)

**Attributes**

**#FS10013\_S0410\_01203**

| **Column** | **Type** | **Length** | **M/O** | **Default** | **Remarks** |
| --- | --- | --- | --- | --- | --- |
| Inst. Type ID | Alphanumeric | 8 | M | - | Identity of the Inst. Type |
| Prescribed Time Limit (minutes) | Numeric | 10 | M | - | The Prescribed Time Limit in minutes |
| Contra EP Response Limit (minutes) | Numeric | 10 | M | - | The Contra EP Response Limit in minutes |
| Accept Msg Template ID | Numeric | 5 | O | - | Accept Msg Template ID |
| Reject Msg Template ID | Numeric | 5 | O | - | Reject Msg Template ID |
| Cancel Msg Template ID (By Participant) | Numeric | 5 | O | - | Cancel Msg Template ID (By Participant) |
| Cancel Msg Template ID (By Committee) | Numeric | 5 | O | - | Cancel Msg Template ID (By Committee) |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0410\_01300**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**, except the New Record)**

**#FS10013\_S0410\_01400**

**Validation (Ref:** [**Common Validation**](#_Common_Validation), [**Validation Rule**](#_Validation_Rule_(TBC))**)**

**#FS10013\_S0410\_01501**

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0410\_01600**

## Report Generation and Processing

### Maintain Report

**#FS10013\_S0411\_00101**

**Description**

**#FS10013\_S0411\_00201**

**Maintain Report** is used to define different kinds of Report.

**UI Layout**

**#FS10013\_S0411\_00303**

Search Page

![](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))

![](data:image/png;base64...)

**Attributes**

**#FS10013\_S0411\_00409**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Report ID | Numeric | 5 | M | - | The ID of the Report |
| Name | Alphanumeric | 12 | M | - | A unique name of the Report |
| Description | Alphanumeric | 40 | O | - | Description of the report |
| Report Type ID | Numeric | 5 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Report Type |
| Header | Alphanumeric | 32 | M | - | Header |
| Chinese Header Name | Alphanumeric | 150 | M | - | Chinese Header Name  (At most 1200 Characters in DB as using UTF8) |
| Keep Day for Spot Month | Numeric | 1 | O | - | Keep Day for Spot Month |
| Expiration Frequency | Char | 1 | O | - | Ref: [Common Attributes](#_Common_Attributes) - Expiration Frequency |
| Report Group List ID | Numeric | 5 | M | - | Report Group List ID |
| Report Group ID | Alphanumeric | 5 | M | - | Report Group ID |
| Trading State ID | Numeric | 5 | M | - | Trading State ID |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0411\_00500**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0411\_00600**

| Action | Description |
| --- | --- |
| - | - |

**Validation (Ref:** [**Common Validation**](#_Common_Validation), [**Validation Rule**](#_Validation_Rule_(TBC))**)**

**#FS10013\_S0411\_00701**

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0411\_00800**

### [Revoked] ~~(Maintain Weekly Quotation Report,~~ merged to Maintain Report~~)~~

**~~#FS10013\_S0411\_00901~~**

**~~Description~~**

**~~#FS10013\_S0411\_01000
Weekly Quotation Report~~** ~~is used to define Weekly Quotation Report.~~

**~~UI Layout~~**

**~~#FS10013\_S0411\_01100~~**

~~Search Page~~

~~Detail Page (Record Status ref:~~ [~~Current Record and Request Record~~](#_Toc178859290)~~)~~

**~~Attributes~~**

**~~#FS10013\_S0411\_01201~~**

| ~~Column~~ | ~~Type~~ | ~~Length~~ | ~~M/O~~ | ~~Default~~ | ~~Remarks~~ |
| --- | --- | --- | --- | --- | --- |
| ~~Report ID~~ | ~~Numeric~~ | ~~5~~ | ~~M~~ | ~~-~~ | ~~The ID of the Report~~ |
| ~~Name~~ | ~~Alphanumeric~~ | ~~12~~ | ~~M~~ |  | ~~The name of the report~~ |
| ~~Description~~ | ~~Alphanumeric~~ | ~~40~~ | ~~O~~ | ~~-~~ | ~~Description~~ |
| ~~Report Type ID~~ | ~~Numeric~~ | ~~5~~ | ~~M~~ | ~~-~~ | ~~Read-only field.~~  ~~Ref:~~ [~~Common Attributes~~](#_Common_Attributes) ~~- Report Type~~ |
| ~~Header~~ | ~~Alphanumeric~~ | ~~32~~ | ~~M~~ | ~~-~~ | ~~The Header of the Report~~ |
| ~~Keep Day for Spot Month~~ | ~~Numeric~~ | ~~5~~ | ~~M~~ | ~~-~~ | ~~Keep Day for Spot Month~~ |
| ~~Expiration Frequency~~ | ~~Char~~ | ~~1~~ | ~~M~~ | ~~-~~ | ~~Ref:~~ [~~Common Attributes~~](#_Common_Attributes) ~~- Expiration Frequency~~ |
| ~~Instrument Group List ID~~ | ~~Alphanumeric~~ | ~~32~~ | ~~M~~ | ~~-~~ | ~~Instrument Group List ID~~ |

**~~Permission Behaviour (Ref:~~** [**~~Common Permission Behaviour~~**](#_Common_Permission_Behaviour)**~~)~~**

**~~#FS10013\_S0411\_01300~~**

**~~Actions (Ref:~~** [**~~Common Actions~~**](#_Common_Actions)**~~)~~**

**~~#FS10013\_S0411\_01400~~**

| ~~Action~~ | ~~Description~~ |
| --- | --- |
| ~~-~~ | ~~-~~ |

**~~Validation (Ref:~~** [**~~Common Validation~~**](#_Common_Validation)**~~)~~**

**~~#FS10013\_S0411\_01500~~**

**~~Notification (Ref:~~** [**~~Common Notification~~**](#_Common_Notification)**~~)~~**

**~~#FS10013\_S0411\_01600~~**

### Maintain Report Group List

**#FS10013\_S0411\_01702**

**Description**

**#FS10013\_S0411\_01802**

**Report Group List** is used to define Report Group List.

**UI Layout**

**#FS10013\_S0411\_01902**

Search Page

![](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))

![](data:image/png;base64...) ![](data:image/png;base64...)

**Attributes**

**#FS10013\_S0411\_02004**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Report Group List ID | Numeric | 5 | M | - | Report Group List ID |
| Name | Alphanumeric | 12 | M | - | A unique name of the Instrument Group List |
| Description | Alphanumeric | 40 | O | - | Description of the Report Group List |
| Inst. Group List Items | - | - | - | - | Inst. Group List Items |
| Combo Group List Items | - | - | - | - | Combo Group List Items |

**Inst. Group List Item Attributes**

**#FS10013\_S0411\_02101**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Instrument Class ID | Alphanumeric | 14 | M | - | Instrument Class ID |
| Underlying ID | Alphanumeric | 6 | M | - | Underlying ID |
| Contract Description | Alphanumeric | 64 | M | - | Contract Description |
| Chinese Contract Description | Alphanumeric | 50 | M | - | Chinese Contract Description  (At most 400 Characters in DB as using UTF8) |
| Contract Term | Alphanumeric | 64 | O | - | Contract Term |
| Chinese Contract Term | Alphanumeric | 50 | O | - | Chinese Contract Term  (At most 400 Characters in DB as using UTF8) |

**Combo Group List Item Attributes**

**#FS10013\_S0411\_02150**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Combo Class ID | Alphanumeric | 14 | M | - | Combo Class ID |
| Underlying ID | Alphanumeric | 6 | M | - | Underlying ID |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0411\_02200**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0411\_02300**

| Action | Description |
| --- | --- |
| - | - |

**Validation (Ref:** [**Common Validation**](#_Common_Validation), [**Validation Rule**](#_Validation_Rule_(TBC))**)**

**#FS10013\_S0411\_02401**

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0411\_02500**

### Control Daily Market Report (DMR)

**#FS10013\_S0411\_02601**

**Description**

**#FS10013\_S0411\_02701**

**Control Daily Market Report** is used to generate and stage selected daily market reports.

**UI Layout**

**#FS10013\_S0411\_02803**

**![](data:image/png;base64...)**

**Attributes**

**#FS10013\_S0411\_02901**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Report ID | - | - | - | - | Read-only field.  Report ID |
| Name | - | - | - | - | Read-only field.  Report name |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0411\_03000**

**Actions**

**#FS10013\_S0411\_03102**

| Action | Description |
| --- | --- |
| Screen Open | Show all Report ID |
| Apply | Trigger a query of records based on input filters |
| Reset Filters | Reset all filters to default: All |
| Generate | Generate selected report(s) |
| Stage | Stage selected report(s) |

**Validation**

**#FS10013\_S0411\_03201**

| Event | Notification |
| --- | --- |
| Generate | At least one record selected |
| Stage | At least one record selected |

**Notification**

**#FS10013\_S0411\_03301**

| Event | Notification |
| --- | --- |
| Generate | Pop up notification to indicate the Generate command is sent successfully or not |
| Stage | Pop up notification to indicate the Stage command is sent successfully or not |

### Control Admin Report

**#FS10013\_S0411\_03500**

**Description**

**#FS10013\_S0411\_03600**

**Control Admin Report** is used to generate selected admin reports.

**UI Layout**

**#FS10013\_S0411\_03702**

**![](data:image/png;base64...)**

**Attributes**

**#FS10013\_S0411\_03802**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Report ID | - | - | - | - | Read-only field.  Report ID |
| Report Type | - | - | - | - | Read-only field.  Ref: [Common Attributes](#_Common_Attributes) - Admin Report Type |
| Name | - | - | - | - | Read-only field.  Report name |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0411\_03900**

**Actions**

**#FS10013\_S0411\_04001**

| Action | Description |
| --- | --- |
| Screen Open | Show all Report ID |
| Apply | Trigger a query of records based on input filters |
| Reset Filters | Reset all filters to default: All |
| Generate | Generate selected report(s) |

**Validation**

**#FS10013\_S0411\_04100**

| Event | Notification |
| --- | --- |
| Generate | At least one record selected |

**Notification**

**#FS10013\_S0411\_04200**

| Event | Notification |
| --- | --- |
| Generate | Pop up notification to indicate the Generate command is sent successfully or not |

## Market Messages

**#FS10013\_S0412\_00100**

### Maintain Message Template

**#FS10013\_S0412\_00200**

**Description**

**#FS10013\_S0412\_00300**

This function is used to maintain Message Templates. Message templates can be utilized in setting up Automated Event Messages, and they may also serve as predefined layouts for composing Manual Market Announcement.

**UI Layout**

**#FS10013\_S0412\_00403**

Search Page

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Current_Record_and))

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

**Attributes**

**#FS10013\_S0412\_00503**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Message Template ID | Numeric | 5 | M | - | Identity of the template |
| Name | Alphanumeric | 32 | M | - | A unique name of the template |
| Target Triggering Event | Numeric | 2 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Supported Event  Used to verify supported variable tag. Once the template is established, it cannot be modified. |
| Message Priority | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Message Priority  To specify the priority flag of the market message. |
| Subject | Alphanumeric | 100 | M | - | Support is limited to the ASCII character set. The maximum permissible length is 100 characters, which encompasses all non-printable characters, like line breaks.  Both static plain text and variable tag are supported.  *Note: curly bracket “{” and “}” are dedicated for indicating variable tag and, as a result, their usage is restricted.* |
| Content | Alphanumeric | 900 | M | - | Support is limited to the ASCII character set. The maximum permissible length is 900 characters, which encompasses all non-printable characters, like line breaks.  Both static plain text and variable tag are supported.  *Note: curly bracket “{” and “}” are dedicated for indicating variable tag and, as a result, their usage is restricted.* |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0412\_00600**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0412\_00700**

**Validation (Ref:** [**Common Validation**](#_Common_Validation), [**Validation Rule**](#_Validation_Rule_(TBC))**)**

**#FS10013\_S0412\_00802**

Ref: FS10019 for supported key

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0412\_00900**

### Maintain Automatic Event Message

**#FS10013\_S0412\_01000**

**Description**

**#FS10013\_S0412\_01100**

This function is used to maintain Automatic Event Messages. Automatic Event Message are activated by the same triggering event. Whenever the event occurs, the system will process each configuration independently, following an ascending order based on the names of the configurations.

**UI Layout**

**#FS10013\_S0412\_01204**

Search Page

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Current_Record_and))

![](data:image/png;base64...)

**Attributes**

**#FS10013\_S0412\_01303**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Auto Event Message ID | Numeric | 5 | M | - | Identity of the message. |
| Name | Alphanumeric | 32 | M | - | A unique name of the message. |
| Triggering Event | Numeric | 2 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Supported Event (except 11)  To specify a supported event as the triggering event for this configuration. |
| Template for Market Data Channel | Numeric | 5 | O | - | Indicate a message template for market data channel. It can be left blank if dissemination through the market data channel is not necessary for the triggering event. |
| Template for Trading GUI Channel | Numeric | 5 | O | - | Indicate a message template for trading GUI channel. It can be left blank if dissemination through the trading GUI channel is not necessary for the triggering event. |
| Template for Binary Channel | Numeric | 5 | O | - | Indicate a message template for binary channel. It can be left blank if dissemination through the binary channel is not necessary for the triggering event. |
| Template for Email Channel | Numeric | 5 | O | - | Indicate a message template for email channel. It can be left blank if dissemination through the email channel is not necessary for the triggering event. |
| Recipient for Email Channel | Alphanumeric | 254 | O | - | Designate up to 5 recipients for the email distribution. If modifications to the email content are required before sending it to external, set the recipient as an internal email address only. |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0412\_01400**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0412\_01500**

**Validation (Ref:** [**Common Validation**](#_Common_Validation), [**Validation Rule**](#_Validation_Rule_(TBC))**)**

**#FS10013\_S0412\_01601**

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0412\_01700**

### Send Manual Market Announcement

**#FS10013\_S0412\_01800**

**Description**

**#FS10013\_S0412\_01900**

This function is used to disseminate a market message manually through both Market Data Channel and Binary Channel. The options and restrictions for each field correspond precisely with those outlined in the Maintain Message Template.

The variable tags are incompatible with manual market announcements. Any variable tags will be regarded as static text, and no substitution will occur. Hence, variable tags will be transferred into the market data’s market message exactly as they appear, without alterations.

**UI Layout**

**#FS10013\_S0412\_02003**

![](data:image/png;base64...)

**Attributes**

**#FS10013\_S0412\_02105**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Clone From The Message Template | Numeric | 5 | M | - | Identity of the template |
| Message Priority | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Message Priority  To specify the priority flag of the market message. |
| Include OMD? | - | - | - | - | Read-only field.  1 - True  Whether include OMD |
| Subject | Alphanumeric | 100 | M | - | Support is limited to the ASCII character set. The maximum permissible length is 100 characters, which encompasses all non-printable characters, like line breaks.  Only support static text. Any variable tags will be regarded as static text. |
| Content | Alphanumeric | 900 | M | - | Support is limited to the ASCII character set. The maximum permissible length is 900 characters, which encompasses all non-printable characters, like line breaks.  Only support static text. Any variable tags will be regarded as static text. |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0412\_02200**

**Actions**

**#FS10013\_S0412\_02300**

| Action | Description |
| --- | --- |
| Reset | Reset the form values on the screen |
| Send | Send the market message |

**Validation**

**#FS10013\_S0412\_02400**

| Action | Description |
| --- | --- |
| Nil | Nil |

**Notification**

**#FS10013\_S0412\_02500**

| Action | Description |
| --- | --- |
| Send | Pop up notification to indicate the action is successfully or not |

## Capital Adjustment

### Control Capital Adjustment

**#FS10013\_S0413\_00100**

**Description**

**#FS10013\_S0413\_00201**

This screen is used to create **Capital Adjustment**.

Approved CA change cannot be withdrawn.

The CA records will be kept for up to 7 years.

**UI Layout**

**#FS10013\_S0413\_00304**

Search Page

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290)) ![](data:image/png;base64...)

![](data:image/png;base64...)

![](data:image/png;base64...)

**Attributes**

**#FS10013\_S0413\_00407**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| CA Event ID | - | 10 | - | - | Generated by system  It’s in the format of YYYY[0-9]{6} |
| CA Event Type | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - CA Event Type |
| Underlying Issuer | Alphanumeric | 6 | M | - | Underlying Issuer |
| New Decimals For Contract Size & PQF | Numeric | 2 | O | - | New Decimals For Contract Size & PQF |
| Adjustment Ratio | Decimal | 20 (decimal point included) | M | - | If not fill, it will be generated by system  The value should include 6 decimal points |
| Effective Adjustment Date | Date | 11 | M | - | Read-only field.  Must be next Trading Date |
| List of Event Type Attributes | - | - | - | - | List of Event Type Attributes |
| List of Underlying ID | - | - | - | - | List of Underlying ID |

**Event Type: R - Right Issue Attributes**

**#FS10013\_S0413\_00501**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Number Of Old Shares (X) | Decimal | 13 (decimal point included) | M | - | Number Of Old Shares (X)  The value should include 6 decimal points |
| Number Of New Shares (Y) | Decimal | 13 (decimal point included) | M | - | Number Of New Shares (Y)  The value should include 6 decimal points |
| Subscription Price Per Share (Z) | Price | 13 (decimal point included) | M | - | Subscription Price Per Share (Z)  The value should include 6 decimal points |
| Underlying Stock Closing Price On E-1 Day (S) | Price | 13 (decimal point included) | M | - | Underlying Stock Closing Price On E-1 Day (S)  The value should include 6 decimal points |

**Event Type: B - Bonus Issue of Shares Attributes**

**#FS10013\_S0413\_00601**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Number Of Old Shares (X) | Decimal | 13 (decimal point included) | M | - | Number Of Old Shares (X)  The value should include 6 decimal points |
| Number Of New Shares (Y) | Decimal | 13 (decimal point included) | M | - | Number Of New Shares (Y)  The value should include 6 decimal points |

**Event Type: W - Bonus Issue of Warrants Attributes**

**#FS10013\_S0413\_00701**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Theoretical Value Of The Warrant Entitlement Per Share On E-1 Day (W) | Price | 13 (decimal point included) | M | - | Theoretical Value Of The Warrant Entitlement Per Share On E-1 Day (W)  The value should include 6 decimal points |
| Ordinary Dividend (OD) | Price | 13 (decimal point included) | M | - | Ordinary Dividend (OD)  The value should include 6 decimal points |
| Underlying Stock Closing Price On E-1 Day (S) | Price | 13 (decimal point included) | M | - | Underlying Stock Closing Price On E-1 Day (S)  The value should include 6 decimal points |

**Event Type: C - Share Consolidation Attributes**

**#FS10013\_S0413\_00801**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Number Of Old Shares (X) | Decimal | 13 (decimal point included) | M | - | Number Of Old Shares (X)  The value should include 6 decimal points |
| Number Of New Shares (Y) | Decimal | 13 (decimal point included) | M | - | Number Of New Shares (Y)  The value should include 6 decimal points |

**Event Type: S - Share Sub-division Attributes**

**#FS10013\_S0413\_00901**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Number Of Old Shares (X) | Decimal | 13 (decimal point included) | M | - | Number Of Old Shares (X)  The value should include 6 decimal points |
| Number Of New Shares (Y) | Decimal | 13 (decimal point included) | M | - | Number Of New Shares (Y)  The value should include 6 decimal points |

**Event Type: M - Merger (Shares + Cash) Attributes**

**#FS10013\_S0413\_01000**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Number Of Old Shares (X) | Decimal | 13 (decimal point included) | M | - | Number Of Old Shares (X)  The value should include 6 decimal points |
| Number Of New Shares (Y) | Decimal | 13 (decimal point included) | M | - | Number Of New Shares (Y)  The value should include 6 decimal points |
| Amount Of Cash (Z) | Price | 13 (decimal point included) | M | - | Amount Of Cash (Z)  The value should include 6 decimal points |
| Underlying Stock Closing Price On E-1 Day (S) | Price | 13 (decimal point included) | M | - | Underlying Stock Closing Price On E-1 Day (S)  The value should include 6 decimal points |

**Event Type: m - Merger (Shares Only) Attributes**

**#FS10013\_S0413\_01100**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Number Of Old Shares (X) | Decimal | 13 (decimal point included) | M | - | Number Of Old Shares (X)  The value should include 6 decimal points |
| Number Of New Shares (Y) | Decimal | 13 (decimal point included) | M | - | Number Of New Shares (Y)  The value should include 6 decimal points |

**Event Type: E - Spin-Off (E Day) Attributes**

**#FS10013\_S0413\_01200**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Nil | N/A | N/A | N/A | N/A | N/A |

**Event Type: F - Spin-Off (F Day; with Entitlement) Attributes**

**#FS10013\_S0413\_01300**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| VWAP Of the Entitlement On F Day (E) | Price | 13 (decimal point included) | M | - | VWAP Of the Entitlement On F Day (E)  The value should include 6 decimal points |
| VWAP Of The Old Share On F Day (S) | Price | 13 (decimal point included) | M | - | VWAP Of The Old Share On F Day (S)  The value should include 6 decimal points |

**Event Type: D - Other Cash Distribution Attributes**

**#FS10013\_S0413\_01400**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Cash Distribution (CD) | Price | 13 (decimal point included) | M | - | Cash Distribution (CD) |
| Ordinary Dividend (OD) | Price | 13 (decimal point included) | M | - | Ordinary Dividend (OD) |
| Underlying Stock Closing Price on E-1 Day (S) | Price | 13 (decimal point included) | M | - | Underlying Stock Closing Price on E-1 Day (S) |

**Event Type: X - Other CA Events Attributes**

**#FS10013\_S0413\_01500**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Nil | N/A | N/A | N/A | N/A | N/A |

**Underlying ID Attributes**

**#FS10013\_S0413\_01601**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| From Underlying ID | - | - | - | - | Read-only field. |
| To Underlying ID | Alphanumeric | 6 | M | - | To Underlying ID |
| From Underlying Code | - | - | - | - | Read-only field. |
| To Underlying Code | Numeric | 5 | M | - | To Underlying Code |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0413\_01700**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0413\_01800**

| Action | Description |
| --- | --- |
| - | - |

**Validation (Ref:** [**Common Validation**](#_Common_Validation), [**Validation Rule**](#_Validation_Rule_(TBC))**)**

**#FS10013\_S0413\_01901**

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0413\_02000**

## Participant

**#FS10013\_S0414\_00100**

### Maintain Exchange Participant

**#FS10013\_S0414\_00200**

**Description**

**#FS10013\_S0414\_00301**

**Exchange Participant** is used to define the exchange participant, its attributes and the granted trading rights.

When creating an Exchange Participant, the items below will be created together with the Exchange Participant:

* + SMP ID List will be created with fields below filled:
* SMP ID List ID
* Owner ID (current create Exchange Participant ID)

**UI Layout**

**#FS10013\_S0414\_00406**

Search Page

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))

![](data:image/png;base64...)

**Attributes**

**#FS10013\_S0414\_00506**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Exchange Participant ID | Alphanumeric | 5 | M | - | The ID of the Exchange Participant. E.g. JPM |
| Exchange ID | Alphanumeric | 2 | M | - | The ID of the Exchange. E.g. HK |
| Company ID | Numeric | 10 | M | - | The ID of the Company |
| Description | Alphanumeric | 40 | O | - | The complete name of the Exchange Participant. |
| Suspended? | Char | 1 | M | - | \* Intraday supported  Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  The Exchange Participant is suspended or not |
| Number Of Missing Heartbeat | Numeric | 5 | M | - | Number Of Missing Heartbeat  65,535 means inherit from Global Param |
| Timeout Before COD | Numeric | 10 | M | - | Timeout Before COD  4,294,967,295 means inherit from Global Param |
| Allowed Block Trade Group ID | Numeric | 5 | O | - | Allowed Block Trade Group ID |
| SMP ID List ID | Numeric | 5 | O | - | SMP ID List ID |
| Nominated Error Trade Session Usage | Char | 1 | O | - | The type of Session Usage for Error Trade Operations.  The Session Usage should match with the Session ID. |
| Nominated Error Trade Session ID | Char | 11 | O | - | The Comp ID nominated for Error Trade Operations.  The Session ID should match with the Session Usage. |
| Participant Trading Rights | - | - | - | - | List of Participant Trading Rights |

**Participant Trading Rights Attributes**

**#FS10013\_S0414\_00601**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Instrument Type ID | Alphanumeric | 8 | M | - | A unique identifier for the Instrument Type |
| Order Size Limit | Numeric | 20 | M | - | Order Size Limit |
| Block Trade Size Limit | Numeric | 20 | M | - | Block Trade Size Limit |
| Default Account | Alphanumeric | 10 | M | - | Default Account |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0414\_00700**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0414\_00800**

| Action | Description |
| --- | --- |
| - | - |

**Validation (Ref:** [**Common Validation**](#_Common_Validation), [**Validation Rule**](#_Validation_Rule_(TBC))**)**

**#FS10013\_S0414\_00901**

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0414\_01000**

### Maintain Drop Copy Group

**#FS10013\_S0414\_01100**

**Description**

**#FS10013\_S0414\_01200**

**Drop Copy Group** is used for defining a group of one or more direct order flow sessions and Trading GUI users under the same exchange participant.

**UI Layout**

**#FS10013\_S0414\_01300**

Search Page

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))![A screenshot of a computer  Description automatically generated](data:image/png;base64...) ![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

**Attributes**

**#FS10013\_S0414\_01403**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Drop Copy Group ID | Numeric | 10 | M | - | Drop Copy Group ID |
| Exchange Participant ID | Alphanumeric | 5 | M | - | The ID of the Exchange Participant. E.g. JPM |
| Name | Alphanumeric | 12 | M | - | A unique name of the Drop Copy Group |
| Description | Alphanumeric | 40 | O | - | The complete name of the Drop Copy Group. |
| Direct Trading Session | - | - | - | - | List of Direct Trading Session |
| Trading GUI User | - | - | - | - | List of Trading GUI User |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0414\_01500**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0414\_01600**

| Action | Description |
| --- | --- |
| - | - |

**Validation (Ref:** [**Common Validation**](#_Common_Validation), [**Validation Rule**](#_Validation_Rule_(TBC))**)**

**#FS10013\_S0414\_01701**

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0414\_01800**

### Maintain Direct Drop Copy Session

**#FS10013\_S0414\_01900**

**Description**

**#FS10013\_S0414\_02000**

**Direct Drop Copy Session** is a connection to facilitate an exchange participant to receive drop copy of order and trade events that belong to the drop copy groups assigned via Drop Copy Gateway.

**UI Layout**

**#FS10013\_S0414\_02102**

Search Page

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))

**![](data:image/png;base64...)**

**![](data:image/png;base64...)**

**Attributes**

**#FS10013\_S0414\_02210**

| Column | | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- | --- |
| Comp ID | | Alphanumeric | 11 | M | - | Comp ID |
| Exchange Participant ID | | Alphanumeric | 5 | M | - | The ID of the Exchange Participant. E.g. JPM |
| Blocked? | | Char | 1 | M | - | \* Intraday supported  The Comp ID is blocked or not |
| Blocked Reason | Numeric | | 1 | M | 0 | Ref: [Common Attributes](#_Common_Attributes) - Blocked Reason |
| Service Type | | Char | 1 | M | - | Read-only field.  Ref: [Common Attributes](#_Common_Attributes) - Gateway Service Type  The value must be D - Drop Copy. |
| Session Usage | | Char | 1 | M | - | Read-only field.  Ref: [Common Attributes](#_Common_Attributes) - Gateway Session Usage  The value must be D - Direct Access. |
| Partition ID | Numeric | | 5 | M | - | Partition ID |
| Sub Partition ID | Numeric | | 5 | M | - | Sub Partition ID |
| Interface Protocol | | Char | 1 | M | - | Read-only field.  Ref: [Common Attributes](#_Common_Attributes) - Interface Protocol  The value must be B -Binary |
| Legal IP Address List ID | | Numeric | 10 | M | - | \* Intraday supported  Legal IP Address List ID defined in IP Address List |
| Password | | Alphanumeric | 8 | M | - | \* Intraday supported  Password of the Comp ID  Masked with \*\*\*\*\*\* |
| Last Password Set Timestamp | | Time | 8 | M | - | Read-only field.  The last password set time. |
| Password Policy ID | | Numeric | 5 | M | - | Password policy ID of the password policy to be used to validate the password. |
| Last Successful Logon Time | | Time | 8 | O | - | Read-only field.  The Last Successful Logon Time, the value should be from Trading table |
| Password Expiration Date | | Date | 11 | O | - | Read-only field.  Password Expiration Date, the value should be from the Trading table. |
| Locked? | | Char | 1 | M | - | \* Intraday supported  Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  The Comp ID is locked or not, the value should be from the Trading table. |
| Number Of Missing Heartbeat | | Numeric | 5 | M | - | Number Of Missing Heartbeat  65,535 means inherit from Exchange Participant |
| Include Orders? | | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  Specify whether includes orders |
| Include Trades? | | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  Specify whether includes trades, must be ‘Y’ |
| Access Group By Type ID | | Numeric | 5 | O | - | Access Group By Type |
| Drop Copy Groups | | Numeric | 5 | M | - | List of Drop Copy Group |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0414\_02300**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0414\_02400**

| Action | Description |
| --- | --- |
| - | - |

**Validation (Ref:** [**Common Validation**](#_Common_Validation), [**Validation Rule**](#_Validation_Rule_(TBC))**)**

**#FS10013\_S0414\_02501**

Include Trades? must be ‘Y’

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0414\_02600**

### Maintain Direct Order Flow Session

**#FS10013\_S0414\_02700**

**Description**

**#FS10013\_S0414\_02800**

**Direct Order Flow Session** is a connection to facilitate an exchange participant to perform trading activities with granted permission and trading rights via Order Flow Gateway.

**UI Layout**

**#FS10013\_S0414\_02904**

Search Page

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))

![](data:image/png;base64...)

**Attributes**

**#FS10013\_S0414\_03008**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Comp ID | Alphanumeric | 11 | M | - | Comp ID |
| Trader ID | Alphanumeric | 11 | M | - | Trader ID |
| Exchange Participant ID | Alphanumeric | 5 | M | - | The ID of the Exchange Participant. E.g. JPM |
| Blocked? | Char | 1 | M | - | \* Intraday supported  Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  The Comp ID is blocked or not. |
| Blocked Reason | Numeric | 1 | M | 0 | Ref: [Common Attributes](#_Common_Attributes) - Blocked Reason |
| Service Type | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Gateway Service Type  The value can be O - Order Flow – CGW or P – Order Flow - PSG |
| Session Usage | Char | 1 | M | - | Read-only field.  Ref: [Common Attributes](#_Common_Attributes) - Gateway Session Usage  The value must be D - Direct Access |
| Partition ID | Numeric | 5 | M | - | Partition ID |
| Sub Partition ID | Numeric | 5 | M | - | Sub Partition ID |
| Interface Protocol | Char | 1 | M | - | Read-only field.  Ref: [Common Attributes](#_Common_Attributes) - Interface Protocol  The value must be B - Binary |
| Legal IP Address List ID | Numeric | 10 | M | - | \* Intraday supported  Legal IP Address List ID defined in IP Address List |
| Password | Alphanumeric | 8 | M | - | \* Intraday supported  Password of the Comp ID  Masked with \*\*\*\*\*\* |
| Last Password Set Timestamp | Time | 8 | M | - | Read-only field.  The last password set time. |
| Password Policy ID | Numeric | 5 | M | - | Password policy ID of the password policy to be used to validate the password. |
| Last Successful Logon Time | Time | 8 | O | - | Read-only field.  The value should be from Trading table |
| Password Expiration Date | Date | 11 | O | - | Read-only field.  The value should be from Trading table |
| Locked? | Char | 1 | M | - | \* Intraday supported  Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  Comp ID is locked or not, the value should from Trading table |
| Timeout Before COD | Numeric | 10 | M | - | Timeout Before COD  4,294,967,295 means inherit from Exchange Participant |
| Number Of Missing Heartbeat | Numeric | 5 | M | - | Number Of Missing Heartbeat  65,535 means inherit from Exchange Participant |
| Order Throttle | Numeric | 10 | M | - | Order Throttle |
| Participant User Role ID | Numeric | 5 | M | - | Must be Participant User Type - Direct Access (Trading) |
| Trading Right ID | Numeric | 5 | M | - | Trading Right ID |
| Receive Non-Critical Market Messages? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  Indicate whether receive Non-Critical Market Messages. |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0414\_03100**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0414\_03200**

| Action | Description |
| --- | --- |
| - | - |

**Validation (Ref:** [**Common Validation**](#_Common_Validation), [**Validation Rule**](#_Validation_Rule_(TBC))**)**

**#FS10013\_S0414\_03301**

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0414\_03400**

### Maintain Legal IP Address

**#FS10013\_S0414\_03500**

**Description**

**#FS10013\_S0414\_03600**

**Legal IP Address** is used for defining a list of allowed IP addresses.

**UI Layout**

**#FS10013\_S0414\_03702**

Search Page ![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290)) ![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

**Attributes**

**#FS10013\_S0414\_03804**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| IP Address List ID | Numeric | 10 | M | - | IP Address List ID |
| Name | Alphanumeric | 12 | M | - | A unique name of the IP Address List |
| Description | Alphanumeric | 40 | O | - | Description of the IP Address List |
| Is Technical? | Char | 1 | M | N | **Read Only**  Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  Y – Yes indicate that the IP Address List is internally used by PTRM GUI or Trading GUI.  This field is always N – No for new Legal IP list created by user. |
| IP Addresses | IP Address List | 15 | M | - | List of IP Addresses |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0414\_03900**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0414\_04000**

| Action | Description |
| --- | --- |
| - | - |

**Validation (Ref:** [**Common Validation**](#_Common_Validation)**,** [**IPv4 Validation**](#_IPv4_Validation), [**Validation Rule**](#_Validation_Rule_(TBC))**)**

**#FS10013\_S0414\_04101**

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0414\_04200**

### Maintain PTRM GUI User

**#FS10013\_S0414\_04300**

**Description**

**#FS10013\_S0414\_04400**

**PTRM GUI User** facilitates an exchange participant or a sponsoring participant to perform PTRM functions via PTRM GUI.

**UI Layout**

**#FS10013\_S0414\_04505**

Search Page

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))

![](data:image/png;base64...)

**Attributes**

**#FS10013\_S0414\_04612**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| User ID | - | - | - | - | Read-only field.  Generated by system |
| IDP User ID | Alphanumeric | 32 | M | - | IDP User ID |
| Exchange Participant ID | Alphanumeric | 5 | M | - | Exchange Participant ID  Allowed to input only when **Is Sponsoring Participant?** is No |
| Sponsoring Participant ID | Alphanumeric | 5 | M | - | Sponsoring Participant ID  Allowed to input only when **Is Sponsoring Participant?** is Yes |
| Is Sponsoring Participant? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  Specify is Sponsoring Participant or not |
| Suspended? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  Specify PTRM GUI User is suspended or not |
| Comp ID | Alphanumeric | 11 | M | - | Comp ID |
| Blocked? | Char | 1 | M | - | \* Intraday supported  Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  The Comp ID is blocked or not |
| Service Type | Char | 1 | M | - | Read-only field.  Ref: [Common Attributes](#_Common_Attributes) - Gateway Service Type  The value must be R - PTRM |
| Session Usage | Char | 1 | M | - | Read-only field.  Ref: [Common Attributes](#_Common_Attributes) - Gateway Session Usage  The value must be U - UI Access |
| Partition ID | Numeric | 5 | M | - | Partition ID |
| Sub Partition ID | Numeric | 5 | M | - | Sub Partition ID |
| Interface Protocol | Char | 1 | M | - | Read-only field.  Ref: [Common Attributes](#_Common_Attributes) - Interface Protocol  The value must be B - Binary |
| Legal IP Address List ID | Numeric | 10 | M | - | Read-only field.  The IP address of PTRM GUI backend connect to PTRM Gateway, hosted by HKEX |
| Password | Alphanumeric | 8 | M | - | Read-only field.  Password of the Comp ID.  Masked with \*\*\*\*\*\* |
| Last Successful Logon Time | Time | 8 | O | - | Read-only field.  the value should be from Trading table |
| Password Policy ID | Numeric | 5 | M | - | Password policy ID of the password policy to be used to validate the password. |
| Password Expiration Date | Date | 11 | O | - | Read-only field.  The value should be from Trading table. |
| Locked? | Char | 1 | M | - | Read-only field.  Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  The Comp ID is locked or not, the value should be from Trading table. |
| IDP Locked? | - | - | - | - | Read only, retrieved from IDP. |
| Number Of Missing Heartbeat | Numeric | 5 | M | - | Read-only field.  65,535 means inherit from Exchange Participant |
| Part. User Role ID | Numeric | 5 | M | - | PTRM GUI User Role ID.  Must be with Participant User Type - PTRM GUI (Trading Unit) for EP, PTRM GUI (Risk Limit Manager) for Sponsoring Participant |
| PTRM Throttle | Numeric | 10 | M | - | PTRM Throttle |
| Legal Browser IP Address List ID | Numeric | 10 | M | - | \* Intraday supported  Legal Browser IP Address List ID |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0414\_04700**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0414\_04802**

| Action | Description |
| --- | --- |
| Unlock IDP Account | Unlock IDP Account |
| Reset IDP Account | Reset IDP Account |
| Suspend IDP Account | Suspend IDP Account |

**Validation (Ref:** [**Common Validation**](#_Common_Validation), [**Validation Rule**](#_Validation_Rule_(TBC))**)**

**#FS10013\_S0414\_04901**

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0414\_05000**

### Maintain Trading GUI User

**#FS10013\_S0414\_05100**

**Description**

**#FS10013\_S0414\_05200**

**Trading GUI User** facilitates an exchange participant to perform trading activities with granted permission and trading rights via Trading GUI.

**UI Layout**

**#FS10013\_S0414\_05306**

Search Page

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))

![](data:image/png;base64...)

**Attributes**

**#FS10013\_S0414\_05411**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| User ID | - | - | - | - | Read-only field.  Generated by system |
| IDP User ID | Alphanumeric | 32 | M | - | IDP User ID |
| Exchange Participant ID | Alphanumeric | 5 | M | - | Exchange Participant ID |
| Suspended? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  IDP User ID is suspended or not |
| Comp ID | Alphanumeric | 11 | M | - | Comp ID |
| Blocked? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  The Comp ID is blocked or not  Block login Trading UI |
| Service Type | Char | 1 | M | - | Read-only field.  Ref: [Common Attributes](#_Common_Attributes) - Gateway Service Type  The value must be O - Order Flow - CGW |
| Session Usage | Char | 1 | M | - | Read-only field.  Ref: [Common Attributes](#_Common_Attributes) - Gateway Session Usage  The value must be U - UI Access |
| Partition ID | Numeric | 5 | M | - | Partition ID |
| Sub Partition ID | Numeric | 5 | M | - | Sub Partition ID |
| Interface Protocol | Char | 1 | M | - | Read-only field.  Ref: [Common Attributes](#_Common_Attributes) - Interface Protocol  The value must be B - Binary |
| Legal IP Address List ID | Numeric | 10 | M | - | Read-only field.  The Legal IP Address List ID defined in IP Address List |
| Password | Alphanumeric | 8 | M | - | Read-only field.  Specify the Password of the Comp ID  Masked with \*\*\*\*\*\* |
| Password Policy ID | Numeric | 5 | M | - | Password policy ID of the password policy to be used to validate the password. |
| Last Successful Logon Time | Time | 8 | O | - | Read-only field.  The value should be from Trading table |
| Password Expiration Date | Date | 11 | O | - | Read-only field.  The value should be from Trading table |
| Locked? | Char | 1 | M | - | Read-only field.  Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  The Comp ID is locked or not, the value should be from Trading table. |
| IDP Locked? | - | - | - | - | Read only, retrieved from IDP. |
| Number Of Missing Heartbeat | Numeric | 5 | M | - | Read-only field.  It refers to the value in Global Parameter. |
| Timeout Before COD | Numeric | 10 | M | - | Read-only field.  It refers to the value in Global Parameter. |
| Order Throttle | Numeric | 10 | M | - | Order Throttle |
| Receive Non-Critical Market Messages? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  Indicate whether receive Non-Critical Market Messages. |
| Part. User Role ID | Numeric | 5 | M | - | Trading GUI User Role ID.  Must be with Participant User Type - Trading GUI |
| Trading Right ID | Numeric | 5 | M | - | Trading Right ID |
| Legal Browser IP Address List ID | Numeric | 10 | M | - | \* Intraday supported |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0414\_05500**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0414\_05602**

| Action | Description |
| --- | --- |
| Unlock IDP Account | Unlock IDP Account |
| Reset IDP Account | Reset IDP Account |
| Suspend IDP Account | Suspend IDP Account |

**Validation (Ref:** [**Common Validation**](#_Common_Validation), [**Validation Rule**](#_Validation_Rule_(TBC))**)**

**#FS10013\_S0414\_05701**

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0414\_05800**

### Maintain Sponsoring Participant

**#FS10013\_S0414\_05900**

**Description**

**#FS10013\_S0414\_06000**

**Sponsoring Participant** is used for defining the sponsoring participant and its associated sponsored participant for PTRM functions.

**UI Layout**

**#FS10013\_S0414\_06101**

Search Page

![](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290)) ![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

**Attributes**

**#FS10013\_S0414\_06202**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Sponsoring Participant ID | Alphanumeric | 5 | M | - | The ID of the Sponsoring Participant. E.g. JPM-C |
| Exchange ID | Alphanumeric | 2 | M | - | The ID of the Exchange. E.g. HK |
| Company ID | Numeric | 10 | M | - | The ID of the Company. |
| Description | Alphanumeric | 40 | O | - | The complete name of the Sponsoring Participant. |
| Suspended? | Char | 1 | M | - | \* Intraday supported  The Sponsoring Participant is suspended or not |
| Sponsored Participants | List of sponsored exchange participant | - | M | - | Selected Exchange Participants that share the same Exchange with Sponsoring Participant for clearing. |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0414\_06300**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0414\_06400**

| Action | Description |
| --- | --- |
| - | - |

**Validation (Ref:** [**Common Validation**](#_Common_Validation), [**Validation Rule**](#_Validation_Rule_(TBC))**)**

**#FS10013\_S0414\_06501**

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0414\_06600**

### Maintain Trading Rights

**#FS10013\_S0414\_06700**

**Description**

**#FS10013\_S0414\_06800**

**Trading Rights** is used for defining the list of products allowed for trading and the corresponding limits for direct order flow sessions and Trading GUI users.

**UI Layout**

**#FS10013\_S0414\_06901**

Search Page

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290)) ![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

**Attributes**

**#FS10013\_S0414\_07002**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Trading Right ID | Numeric | 5 | M | - | The ID of the Trading Right |
| Name | Alphanumeric | 12 | M | - | A unique name of the Trading Right ID |
| Description | Alphanumeric | 40 | O | - | The complete name of the Trading Right ID |
| Trading Rights | - | - |  | - | List of Trading Rights |

**Trading Rights Attributes**

**#FS10013\_S0414\_07102**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Access Group By Type ID | Numeric | 5 | M | - | Access Group By Type ID |
| Order Size Limit | Quantity | 9 | M | 0 | Order Size Limit |
| Block Trade Size Limit | Quantity | 9 | M | 0 | Block Trade Size Limit |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0414\_07200**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0414\_07300**

| Action | Description |
| --- | --- |
| - | - |

**Validation (Ref:** [**Common Validation**](#_Common_Validation), [**Validation Rule**](#_Validation_Rule_(TBC))**)**

**#FS10013\_S0414\_07401**

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0414\_07500**

### Maintain Participant User Role

**#FS10013\_S0414\_07600**

**Description**

**#FS10013\_S0414\_07700**

A participant user role is used for managing the list of trading functionalities that can be accessed and performed.

**UI Layout**

**#FS10013\_S0414\_07804**

Search Page

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))

![](data:image/png;base64...)

**Attributes**

**#FS10013\_S0414\_07905**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Participant User Role ID | Numeric | 5 | M | - | Participant User Role ID |
| Name | Alphanumeric | 12 | M | - | A unique name of the Participant User Role ID |
| Description | Alphanumeric | 40 | O | - | The complete name of the Participant User Role ID |
| Participant User Type | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Participant User Type |
| Order Entry Allowed? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| Order Amend Allowed? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| Order Cancel Allowed? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| Order Mass Cancel Allowed? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| OBO Order Cancel Allowed? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| OBO Mass Cancel Allowed? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| Quote Request Allowed? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| Single Quote Allowed? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| Mass Quote Allowed? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| Block Trade Allowed? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| Error Trade Claim Allowed? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| TMC Creation Allowed? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| MMP Parameter Update Allowed? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| Stop Risk Group Allowed? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| Unstop Risk Group Allowed? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| PTRM Mass Cancel Allowed? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| Kill Switch Allowed? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| PTRM Kill Switch Allowed? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| Unblock Breached Risk Check Allowed? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| PTRM Parameter Update Allowed? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| Allowed Block Trade Group ID | Numeric | 5 | O | - | Allowed Block Trade Group ID |
| UI User Role ID | Alphanumeric | 32 | O | - | UI User Role ID |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0414\_08000**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0414\_08100**

| Action | Description |
| --- | --- |
| - | - |

**Validation (Ref:** [**Common Validation**](#_Common_Validation), [**Validation Rule**](#_Validation_Rule_(TBC))**)**

**#FS10013\_S0414\_08201**

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0414\_08300**

### Maintain SMP ID List

**#FS10013\_S0414\_08400**

**Description**

**#FS10013\_S0414\_08500**

SMP ID List is used to define list for SMP ID which can be assigned in Maintain Exchange Participant.

**UI Layout**

**#FS10013\_S0414\_08600**

Search Page

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290)) ![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

**Attributes**

**#FS10013\_S0414\_08702**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| SMP ID List ID | Numeric | 5 | M | - | SMP ID List ID |
| Name | Alphanumeric | 12 | M | - | A unique name of the SMP ID List ID |
| Description | Alphanumeric | 40 | O | - | The complete name of the SMP ID List ID |
| Owner ID | Alphanumeric | 5 | M | - | Exchange Participant ID |
| List of SMP ID | - | - | - | - | List of SMP ID |

**SMP ID List Attributes**

**#FS10013\_S0414\_08800**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| SMP ID List ID | Numeric | 5 | M | - | SMP ID List ID |
| SMP ID | Numeric | 20 | M | - | SMP ID |
| Status | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Status  SMP ID Status |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0414\_08900**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0414\_09000**

| Action | Description |
| --- | --- |
| - | - |

**Validation (Ref:** [**Common Validation**](#_Common_Validation), [**Validation Rule**](#_Validation_Rule_(TBC))**)**

**#FS10013\_S0414\_09101**

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0414\_09200**

### Maintain MMP Parameter

**#FS10013\_S0414\_09300**

**Description**

**#FS10013\_S0414\_09400**

MMP Parameter is used to configure MMP parameters per EP per underlying.

**UI Layout**

**#FS10013\_S0414\_09500**

Search Page

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

**Attributes**

**#FS10013\_S0414\_09602**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Exchange Participant ID | Alphanumeric | 5 | M | - | The ID of the Exchange Participant. E.g. JPM |
| Underlying ID | Alphanumeric | 6 | M | - | The Underlying equity (a unique ID). |
| Include Futures? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| Quantity Protection | Quantity | 9 | M | - | Quantity Protection |
| Delta Protection | Quantity | 9 | M | - | Delta Protection |
| Exposure Time Limit Interval | Numeric | 10 | M | - | Exposure Time Limit Interval |
| Frozen Time | Numeric | 10 | M |  | Frozen Time |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0414\_09700**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0414\_09800**

| Action | Description |
| --- | --- |
| - | - |

**Validation (Ref:** [**Common Validation**](#_Common_Validation), [**Validation Rule**](#_Validation_Rule_(TBC))**)**

**#FS10013\_S0414\_09901**

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0414\_10000**

### Control Block/Unblock Participant Per Product

**#FS10013\_S0414\_10100**

**Description**

**#FS10013\_S0414\_10200**

**Control Block/Unblock Participant Per Product** is used to block/unblock Participant per Product.

**UI Layout**

**#FS10013\_S0414\_10301**

![](data:image/png;base64...)

**Attributes**

**#FS10013\_S0414\_10403**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Participant ID | Alphanumeric | 5 | M | - | The ID of the Exchange Participant. E.g. JPM |
| Level | Alphanumeric | 6 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Hierarchy Level |
| Entity | Alphanumeric | 14 | M | - | Entity of the Level |
| Description | Alphanumeric | 40 | O | - | Description of the Entity |
| Currency | Alphanumeric | 3 | O | - | Currency of the Instrument Class  Applicable only if Level is Class |
| Blocked? | Char | 1 | O | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| Action | Alphanumeric | 5 | M | - | Explicit Blocking Action |
| When | Numeric | 4 | M | - | When |
| Modified By | Alphanumeric | 32 | M | - | Modified By |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0414\_10500**

**Actions**

**#FS10013\_S0414\_10600**

| Action | Description |
| --- | --- |
| Screen Open | Show all level per Participant |
| Apply | Trigger a query of records based on input filters |
| Reset Filters | Reset all filters to default: All |
| Block/ Unblock | Block/ Unblock selected Participant per product |

**Validation**

**#FS10013\_S0414\_10700**

| Event | Notification |
| --- | --- |
| Nil | Nil |

**Notification**

**#FS10013\_S0414\_10800**

| Event | Notification |
| --- | --- |
| Block/Unblock | Pop up notification to indicate the Block/Unblock command is sent successfully or not |

### Maintain Company

**#FS10013\_S0414\_10900**

**Description**

**#FS10013\_S0414\_11000**

Maintain Company is used to define company.

**UI Layout**

**#FS10013\_S0414\_11101**

Search Page

![](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))

![](data:image/png;base64...)

**Attributes**

**#FS10013\_S0414\_11208**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Company ID | Numeric | 10 | M | - | Company ID |
| IDP Company ID | - | - | - | - | Read-only field.  IDP Company ID |
| Company Name | Alphanumeric | 150 | M | - | A unique name of the Company  Allowed IDP characters: a-zA-Z0-9, comma (,), full stop (.), hyphen (-), apostrophe ('), parentheses (()), and (&), space, slash (/), underscore (\_) |
| Company UUID | - | - | - | - | Read-only field. |
| Description | Alphanumeric | 255 | O | - | Description of the Company |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0414\_11300**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0414\_11400**

| Action | Description |
| --- | --- |
| - | - |

**Validation (Ref:** [**Common Validation**](#_Common_Validation), [**Validation Rule**](#_Validation_Rule_(TBC))**)**

**#FS10013\_S0414\_11501**

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0414\_11600**

### Maintain Self Admin Portal User

**#FS10013\_S0414\_11700**

**Description**

**#FS10013\_S0414\_11800**

**Maintain Self Admin Portal User** is used to define User for Self Admin Portal.

**UI Layout**

**#FS10013\_S0414\_11904**

Search Page

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))

![](data:image/png;base64...)

**Attributes**

**#FS10013\_S0414\_12006**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| User ID | - | - | - | - | Read-only field.  Generated by system |
| IDP User ID | Alphanumeric | 32 | M | - | IDP User ID  Input will be capitalized automatically.  Allowed IDP characters: A-Z0-9, full stop (.), underscore (\_) and hyphen (-) |
| Exchange Participant ID | Alphanumeric | 5 | M | - | Exchange Participant ID |
| Suspended? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  IDP User ID is suspended or not |
| Legal Browser IP Address List ID | Numeric | 10 | M | - | \* Intraday supported  Legal Browser IP Address List ID |
| IDP Locked? | - | - | - | - | Read only, retrieved from IDP. |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0414\_12100**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0414\_12202**

| Action | Description |
| --- | --- |
| Unlock IDP Account | Unlock IDP Account |
| Reset IDP Account | Reset IDP Account |
| Suspend IDP Account | Suspend IDP Account |

**Validation (Ref:** [**Common Validation**](#_Common_Validation), [**Validation Rule**](#_Validation_Rule_(TBC))**)**

**#FS10013\_S0414\_12300**

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0414\_12400**

### Request External IDP User

**#FS10013\_S0414\_12502**

**Description**

**#FS10013\_S0414\_12602**

**Request External IDP User** is used to create/update External IDP user.

**UI Layout**

**#FS10013\_S0414\_12704**

![](data:image/png;base64...)

**Attributes**

**#FS10013\_S0414\_12806**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| IDP User ID | - | - | - | - | Read-only field.  IDP User ID = Company ID + "\_" + Username  Allowed IDP characters: A-Z0-9, full stop (.), underscore (\_) and hyphen (-) |
| Company ID | Numeric | 10 | M | - | The ID of the Company |
| Username | Alphanumeric | 23 | M | - | Username  Allowed IDP characters: A-Z0-9, full stop (.), underscore (\_) and hyphen (-) |
| Is Sponsoring Participant? | Char | 1 | M | N | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| Exchange Participant ID | Alphanumeric | 5 | M | - | Mandatory if Is Sponsoring Participant = N, else disabled |
| Sponsoring Participant ID | Alphanumeric | 5 | M | - | Mandatory if Is Sponsoring Participant = Y, else disabled |
| Given Name | Alphanumeric | 32 | M | - | Given Name |
| Family Name | Alphanumeric | 32 | M | - | Family Name |
| Email | Alphanumeric | 255 | M | - | A valid email address format (local-part@domain)  local-part allow a-z, A-Z, 0-9, full stop (.), underscore (\_) and hyphen (-).  domain allow a-z, A-Z, 0-9, full stop (.), hyphen (-). Hyphen is allowed if it is not the first or last character. |
| Phone Number | Alphanumeric | 16 | M | - | Phone Number  e.g.: +852-22222222 |
| User Type | Alphanumeric | 16 | M | USER | Read-only field.  Ref: [Common Attributes](#_Common_Attributes) - IDP User Type  Must be USER |
| Internal | Char | 1 | M | N | Read-only field.  Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  Must be “N - No” |
| Admin | Char | 1 | M | N | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| Effective Start Day | Date | 11 | M | - | Effective Start Day |
| OTP Delivery Method | Numeric | 1 | M | 2 | Ref: [Common Attributes](#_Common_Attributes) - OTP Delivery Method |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0414\_12900**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0414\_13000**

| Action | Description |
| --- | --- |
| - | - |

**Validation (Ref:** [**Common Validation**](#_Common_Validation), [**Validation Rule**](#_Validation_Rule_(TBC))**)**

**#FS10013\_S0414\_13100**

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0414\_13200**

## Timetable

### Maintain Trading Timetable

**#FS10013\_S0415\_00100**

**Description**

**#FS10013\_S0415\_00200**

**Trading Timetable** is used to define trading timetables.

**UI Layout**

**#FS10013\_S0415\_00302**

Search Page

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

**Attributes**

**#FS10013\_S0415\_00404**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Trading Timetable ID | Numeric | 5 | M | - | Trading Timetable ID |
| Trading Timetable Name | Alphanumeric | 12 | M | - | A unique name of the Trading Timetable |
| Description | Alphanumeric | 40 | O | - | Description of the Trading Timetable |
| Exchange ID | Alphanumeric | 2 | M | - | The ID of the Exchange. E.g. HK |
| Timetable Type | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Timetable Type |
| Trading Session States | - | - | - | - | List of Trading Session States |

**~~[Revoked]Trading Session Attributes~~**

**~~#FS10013\_S0415\_00502~~**

**Trading Session State Attributes**

**#FS10013\_S0415\_00609**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Trading Session | Numeric | 5 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Trading Session ID |
| Start Logical Day Ind | Numeric | 2 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Logical Day Ind |
| Start Time | Numeric | 8 | M | - | Start time of the trading state with the granularity of seconds (specified in local time in system time zone) |
| Transition Mode | Numeric | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Transition Mode  Can be ‘0 - Automatic’ only |
| Trading State ID | Numeric | 5 | M | - | Trading State ID  Can be Business Trading State, or Non-Business Trading State which Trading State Type is   * 8 - INTERVENTION, or * 9 - DAYEND   \*All trading timetables should have one and only one DAYEND as the last trading state |
| Num Alert | Numeric | 5 | O | - | Number of alert messages before the trading state is started.  Should be > 0 if set,  empty means no alert, and Alert Interval will be disabled. |
| Alert Interval | Numeric | 10 | O | - | Interval (in number of seconds) between alert messages before the trading state is started.  Should be > 0 if Num Alert > 0, else frontend should be disabled and will set null to DB. |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0415\_00700**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0415\_00800**

| Action | Description |
| --- | --- |
| ~~Export All~~ | ~~Export all Trading timetable to file~~ |

**Validation (Ref:** [**Common Validation**](#_Common_Validation), [**Validation Rule**](#_Validation_Rule_(TBC))**)**

**#FS10013\_S0415\_00901**

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0415\_01000**

### Maintain Trading State

**#FS10013\_S0415\_01100**

**Description**

**#FS10013\_S0415\_01200**

**Trading State** is used to define Trading State.

**UI Layout**

**#FS10013\_S0415\_01305**

Search Page

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)![](data:image/png;base64...)

**Attributes**

**#FS10013\_S0415\_01409**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Trading State ID | Numeric | 5 | M | - | Trading State ID |
| Trading State Name | Alphanumeric | 20 | M | - | A unique name of the Trading State |
| Description | Alphanumeric | 40 | O | - | Description of the Trading State |
| Trading State Type | Numeric | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Trading State Type |
| Business Trading State? | Char | 1 | M | Y | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  Default to ‘Y’ when add/update Trading State and not allowed to edit.  If ‘Y’, the trading state is created and customized by Business Operations  If ‘N’, the trading state is pre-load to the system and cannot be customized by Business Operations |
| LO Allowed? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  Limit Order Allowed or not |
| MO Allowed? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  Market Order Allowed or not |
| M2L Allowed? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  Market to Limit Order Allowed or not |
| Day Allowed? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  Day Allowed or not |
| FAK Allowed? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  Fill and Kill or not |
| FOK Allowed? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  Fill or Kill or not |
| GTC Allowed? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  Good till Cancel or not |
| GTD Allowed? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  Good till Date or not |
| At Crossing Allowed? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| Order Entry Allowed? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| Order Amend Allowed (Preserve Time Priority)? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| Order Amend Allowed (Loss Of Time Priority)? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| Order Cancel Allowed? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| Quote Request Allowed? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| Single Quote Allowed? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| Mass Quote Allowed? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| Block Trade Allowed? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| Error Trade Claim Allowed? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| TMC Creation Allowed? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| Admin Order Cancel Allowed? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| Admin Trade Cancel Allowed? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| Admin Trade Price Adjustment? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| Internal On-Behalf Enter Trade? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| Calculate AHT Static Price Limit Ref Price? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| Remove All Orders? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| Inactivate Non-AHT Orders? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| Implied Generation Applicable? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| Static Price Limit Applicable? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| Dynamic Price Limit Applicable? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| VCM Applicable? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| VCM Start Offset | Numeric | 10 | O | - | Start Offset (in number of seconds) of VCM monitoring, applicable only if the trading state enables VCM monitoring; VCM monitoring is started after the start offset from the start time of the trading state |
| VCM End Offset | Numeric | 10 | O | - | End Offset (in number of seconds) of VCM monitoring, applicable only if the trading state enables VCM monitoring; VCM monitoring is ended before the end offset from the end time of the trading state, i.e. the start time of the next trading state |
| Random Start Interval | Numeric | 10 | O | - | Random Start Interval in seconds |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0415\_01500**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0415\_01600**

| Action | Description |
| --- | --- |
| - | - |

**Validation (Ref:** [**Common Validation**](#_Common_Validation), [**Validation Rule**](#_Validation_Rule_(TBC))**)**

**#FS10013\_S0415\_01701**

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0415\_01800**

### Maintain Non-Trading Days

**#FS10013\_S0415\_01901**

**Description**

**#FS10013\_S0415\_02001**

**Non-Trading Days** are used to define Non-Trading Days.

**UI Layout**

**#FS10013\_S0415\_02102**

Search Page

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

**Attributes**

**#FS10013\_S0415\_02204**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Non-Trading Days ID | Numeric | 5 | M | - | Non-Trading Days ID |
| Non-Trading Days Name | Alphanumeric | 12 | M | - | A unique name of the Non-Trading Days |
| Description | Alphanumeric | 40 | O | - | Description of the Non-Trading Days |
| Non-Trading Days Items | - | - | - | - | List of Non-Trading Days Items |

**Non-Trading Days Item Attribute**

**#FS10013\_S0415\_02303**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Date | Date | 11 | M | - | Date |
| Trading Day Type | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Trading Day Type  Must be 'N - Non-Trading Day' and not allowed to edit |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0415\_02400**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0415\_02500**

| Action | Description |
| --- | --- |
| - | - |

**Validation (Ref:** [**Common Validation**](#_Common_Validation), [**Validation Rule**](#_Validation_Rule_(TBC))**)**

**#FS10013\_S0415\_02602**

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0415\_02700**

### Maintain Special Trading Days

**#FS10013\_S0415\_02800**

**Description**

**#FS10013\_S0415\_02900**

**Special** **Trading Days** are used to define special trading days.

**UI Layout**

**#FS10013\_S0415\_03000**

Search Page

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290)) ![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

**Attributes**

**#FS10013\_S0415\_03104**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Special Trading Days ID | Numeric | 5 | M | - | Special Trading Days ID |
| Special Trading Days Name | Alphanumeric | 12 | M | - | A unique name of the Special Trading Days |
| Description | Alphanumeric | 40 | O | - | Description of the Special Trading Days |
| Special Trading Days Items | - | - | - | - | List of Special Trading Days Items |

**Special** **Trading Days Item Attributes**

**#FS10013\_S0415\_03200**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Date | Date | 11 | M | - | Date |
| Trading Timetable ID | Numeric | 5 | M | - | Trading Timetable ID |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0415\_03300**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0415\_03400**

| Action | Description |
| --- | --- |
| - | - |

**Validation (Ref:** [**Common Validation**](#_Common_Validation), [**Validation Rule**](#_Validation_Rule_(TBC))**)**

**#FS10013\_S0415\_03501**

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0415\_03600**

### Control Trading Timetable

**#FS10013\_S0415\_03700**

**Description**

**#FS10013\_S0415\_03802**

**Control Trading Timetable** is used to update real-time timetable and move to next state.

The trading state of lower level will follow trading states of upper level if and only if the trading timetable of the lower level is inherited from the upper level. Once the trading state of lower level is updated manually, the trading timetable of lower level will detach from the upper level, and any change to the trading state of any of the two levels will not impact to trading state of another level.

Trading State of Combo refers to leg 1 if there is no timetable defined in Combo Type and Class level.

**UI Layout**

**#FS10013\_S0415\_03906**

Control Page

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

Detail Page

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

Import Page (Ref: 5.7 Template/Import Timetable)

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

**Control Page Attributes**

**#FS10013\_S0415\_04004**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Market ID/Type ID/Class ID | - | - | - | - | Read-only field.  Market ID/Type ID/Class ID |
| Level | - | - | - | - | Read-only field.  Ref: [Common Attributes](#_Common_Attributes) - Hierarchy Level |
| Product Type | - | - | - | - | Read-only field.  Ref: [Common Attributes](#_Common_Attributes) - Product Type  Empty for Market |
| Current Trading State | Numeric | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Trading State Type  Allowed to edit (edited trading state will be yellow highlighted)  Combo Type/Class will show “Not Available” if no timetable defines and cannot open detail page. |
| Next Trading State | - | - | - | - | Read-only field.  Ref: [Common Attributes](#_Common_Attributes) - Trading State Type  Combo Type/Class will show “Not Available” if no timetable defines and cannot open detail page. |

**Detail Page Attributes**

**#FS10013\_S0415\_04103**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Current | - | - | - | - | Read-only field.  Indicate current state |
| Actual Start Time | - | - | - | - | Read-only field.  Actual Start Time |
| Trading Session | Alphanumeric | 2 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Trading Session ID |
| Start Logical Day Ind | Numeric | 2 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Logical Day Ind |
| Start Time | Numeric | 8 | M | - | Start time of the trading state with the granularity of seconds (specified in local time in system time zone) |
| Random Start Interval | - | - | - | - | Read-only field.  Random Start Interval |
| Trading State ID | Numeric | 5 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Trading State ID |
| Transition Mode | Numeric | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Transition Mode |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0415\_04200**

**Actions**

**#FS10013\_S0415\_04304**

Control Page Action

| Action | Description |
| --- | --- |
| Screen Open | Show all level Trading Timetable |
| Apply | Trigger a query of records based on input filters |
| Reset Filters | Reset all filters to default: All |
| Import | Import Trading Timetable/State for different products |
| Export All | Export all Trading Timetable/State for different products to file |
| Trading Pause All | Pause all product levels with target pause time |
| Trading Pause for Selected | Pause selected product levels with target pause time |
| Early Close All | Early Close all product levels with target close time |
| Early Close for Selected | Early Close selected product levels with target close time |
| Confirm | Confirm the change and submit to backend, disabled with Read-only permission and view mode |
| Cancel | Cancel all changes, disabled with Read-only permission and view mode |

Detail Page Action

| Action | Description |
| --- | --- |
| Add | Add Trading State |
| Delete | Delete Trading State |
| Export | Export all Records from GUI current page table to CSV file |
| Confirm | Confirm the change and submit to backend, disabled with Read-only permission and view mode |
| Cancel | Cancel all changes, disabled with Read-only permission and view mode |
| Move to Next State | Move to next Trading State |

**Validation**

**#FS10013\_S0415\_04401**

| Event | Notification |
| --- | --- |
| Confirm | Input data are valid or not |
| Trading Pause | At least one product level selected, and a target pause time set |
| Early Close | At least one product level selected |

**Notification**

**#FS10013\_S0415\_04501**

| Event | Notification |
| --- | --- |
| Confirm | Pop up notification to indicate the control command is sent successfully or not |
| Trading Pause | Pop up notification to indicate the Pause command is sent successfully or not |
| Early Close | Pop up notification to indicate the Early Close command is sent successfully or not |

### ~~Control Trading Pause~~ (Merged to Control Trading Timetable)

**~~#FS10013\_S0415\_04601~~**

**~~Description~~**

**~~#FS10013\_S0415\_04700~~**

**~~Control Trading Pause~~** ~~is used to pause selected products with specific time.~~

**~~UI Layout~~**

**~~#FS10013\_S0415\_04802~~**

~~![](data:image/png;base64...)~~

**~~Attributes~~**

**~~#FS10013\_S0415\_04901~~**

| ~~Column~~ | ~~Type~~ | ~~Length~~ | ~~M/O~~ | ~~Default~~ | ~~Remarks~~ |
| --- | --- | --- | --- | --- | --- |
| ~~Market ID/Type ID/Class ID~~ | ~~-~~ | ~~-~~ | ~~-~~ | ~~-~~ | ~~Read-only field.~~  ~~Market ID/Type ID/Class ID~~ |
| ~~Level~~ | ~~-~~ | ~~-~~ | ~~-~~ | ~~-~~ | ~~Read-only field.~~  ~~Ref:~~ [~~Common Attributes~~](#_Common_Attributes) ~~- Instrument Level~~ |
| ~~Product Type~~ | ~~-~~ | ~~-~~ | ~~-~~ | ~~-~~ | ~~Read-only field.~~  ~~Ref:~~ [~~Common Attributes~~](#_Common_Attributes) ~~- Product Type~~  ~~Empty for Market~~ |
| ~~Target Pause Time~~ | ~~-~~ | ~~-~~ | ~~-~~ | ~~-~~ | ~~Read-only field.~~  ~~Target Pause Time~~ |
| ~~From Trading State~~ | ~~-~~ | ~~-~~ | ~~-~~ | ~~-~~ | ~~Read-only field.~~  ~~Ref:~~ [~~Common Attributes~~](#_Common_Attributes) ~~- Trading State Type~~ |
| ~~To Trading State~~ | ~~-~~ | ~~-~~ | ~~-~~ | ~~-~~ | ~~Read-only field.~~  ~~Ref:~~ [~~Common Attributes~~](#_Common_Attributes) ~~- Trading State Type~~ |

**~~Permission Behaviour (Ref:~~** [**~~Common Permission Behaviour~~**](#_Common_Permission_Behaviour)**~~)~~**

**~~#FS10013\_S0415\_05000~~**

**~~Actions~~**

**~~#FS10013\_S0415\_05100~~**

| ~~Action~~ | ~~Description~~ |
| --- | --- |
| ~~Screen Open~~ | ~~Show all level Trading State~~ |
| ~~Apply~~ | ~~Trigger a query of records based on input filters~~ |
| ~~Reset Filters~~ | ~~Reset all filters to default: All~~ |
| ~~Pause~~ | ~~Pause selected records with target pause time~~ |

**~~Validation~~**

**~~#FS10013\_S0415\_05200~~**

| ~~Event~~ | ~~Notification~~ |
| --- | --- |
| ~~Pause~~ | ~~At least one record selected, and a target pause time set~~ |

**~~Notification~~**

**~~#FS10013\_S0415\_05300~~**

| ~~Event~~ | ~~Notification~~ |
| --- | --- |
| ~~Pause~~ | ~~Pop up notification to indicate the Pause command is sent successfully or not~~ |

### ~~Control Early Close~~ (Merged to Control Trading Timetable)

**~~#FS10013\_S0415\_05401~~**

**~~Description~~**

**~~#FS10013\_S0415\_05501~~**

**~~Control Early Close~~** ~~is used to close early selected products.~~

**~~UI Layout~~**

**~~#FS10013\_S0415\_05602~~**

~~![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)~~

**~~Attributes~~**

**~~#FS10013\_S0415\_05701~~**

| ~~Column~~ | ~~Type~~ | ~~Length~~ | ~~M/O~~ | ~~Default~~ | ~~Remarks~~ |
| --- | --- | --- | --- | --- | --- |
| ~~Market ID/Type ID/Class ID~~ | ~~-~~ | ~~-~~ | ~~-~~ | ~~-~~ | ~~Read-only field.~~  ~~Market ID/Type ID/Class ID~~ |
| ~~Level~~ | ~~-~~ | ~~-~~ | ~~-~~ | ~~-~~ | ~~Read-only field.~~  ~~Ref:~~ [~~Common Attributes~~](#_Common_Attributes) ~~- Instrument Level~~ |
| ~~Product Type~~ | ~~-~~ | ~~-~~ | ~~-~~ | ~~-~~ | ~~Read-only field.~~  ~~Ref:~~ [~~Common Attributes~~](#_Common_Attributes) ~~- Product Type~~  ~~Empty for Market~~ |
| ~~Current Trading State~~ | ~~-~~ | ~~-~~ | ~~-~~ | ~~-~~ | ~~Read-only field.~~  ~~Ref:~~ [~~Common Attributes~~](#_Common_Attributes) ~~- Trading State Type~~ |

**~~Permission Behaviour (Ref:~~** [**~~Common Permission Behaviour~~**](#_Common_Permission_Behaviour)**~~)~~**

**~~#FS10013\_S0415\_05800~~**

**~~Actions~~**

**~~#FS10013\_S0415\_05901~~**

| ~~Action~~ | ~~Description~~ |
| --- | --- |
| ~~Screen Open~~ | ~~Show all level Trading Timetable~~ |
| ~~Apply~~ | ~~Trigger a query of records based on input filters~~ |
| ~~Reset Filters~~ | ~~Reset all filters to default: All~~ |
| ~~Early Close~~ | ~~Early Close selected records~~ |

**~~Validation~~**

**~~#FS10013\_S0415\_06001~~**

| ~~Event~~ | ~~Notification~~ |
| --- | --- |
| ~~Early Close~~ | ~~At least one record selected~~ |

**~~Notification~~**

**~~#FS10013\_S0415\_06101~~**

| ~~Event~~ | ~~Notification~~ |
| --- | --- |
| ~~Early Close~~ | ~~Pop up notification to indicate the early close command is sent successfully or not~~ |

## System

### Maintain Global Parameters

**#FS10013\_S0416\_00101**

**Description**

**#FS10013\_S0416\_00201**

**Global Parameters** are used to define the global parameters for ODP Trading Admin.

**UI Layout**

**#FS10013\_S0416\_00311**

Search Page

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))

![](data:image/png;base64...)

![](data:image/png;base64...)

**![](data:image/png;base64...)**

**Attributes**

**#FS10013\_S0416\_00416**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Global Parameters ID | Numeric | 5 | M | - | Global Parameters ID |
| Instrument Retention Period | Numeric | 5 | M | - | Instrument Retention Period in days |
| Maximum Order Quantity | Quantity | 9 | M | - | Maximum Order Quantity |
| Maximum Block Trade Quantity | Quantity | 9 | M | - | Maximum Block Trade Quantity |
| Maximum Price | Numeric | 20 | M | - | Maximum Price |
| Maximum Price Decimals | Numeric | 5 | M | - | Maximum Price Decimals |
| Minimum Price | Numeric | 20 | M | - | Minimum Price |
| Minimum Price Decimals | Numeric | 5 | M | - | Minimum Price Decimals |
| Maximum Orders Per Price Q In PREOPEN | Numeric | 10 | M | - | Maximum Orders Per Price Q In PREOPEN |
| Maximum Orders Per Price Q In OPEN | Numeric | 10 | M | - | Maximum Orders Per Price Q In OPEN |
| Maximum Order Flow Session | Numeric | 10 | M | - | Maximum Order Flow Session |
| Maximum Trading GUI User | Numeric | 10 | M | - | Maximum Trading GUI User |
| Maximum Drop Copy Session | Numeric | 10 | M | - | Maximum Drop Copy Session |
| Maximum PTRM GUI User | Numeric | 10 | M | - | Maximum PTRM GUI User |
| Maximum TPS Per Order Flow Session | Numeric | 10 | M | - | Maximum TPS Per Order Flow Session |
| Maximum Risk Group Per Sponsored Participant | Numeric | 10 | M | - | Maximum Risk Group Per Sponsored Participant |
| Maximum Trader ID Per Risk Group | Numeric | 10 | M | - | Maximum Trader ID Per Risk Group |
| Maximum Tradable Per Risk Group | Numeric | 10 | M | - | Maximum Tradable Per Risk Group |
| Maximum TPS Per PTRM Session | Numeric | 10 | M | - | Maximum TPS Per PTRM Session |
| Maximum Notification ID Per Risk Group | Numeric | 5 | M | - | Maximum Notification ID Per Risk Group |
| Maximum Trading Hours | Numeric | 2 | M | - | Maximum Trading Hours |
| Earliest Trading Start Logical Day Ind | Numeric | 2 | M | - | Earliest Trading Start Logical Day Ind |
| Earliest Trading Start Time | Numeric | 4 | M | - | Earliest Trading Start Time |
| Latest Trading End Logical Day Ind | Numeric | 2 | M | - | Latest Trading End Logical Day Ind |
| Latest Trading End Time | Numeric | 4 | M | - | Latest Trading End Time |
| Trading Pause Trading State | Numeric | 5 | M | - | Trading Pause Trading State |
| Number Of Missing Heartbeat | Numeric | 5 | M | - | Number Of Missing Heartbeat |
| Timeout Before COD | Numeric | 10 | M | - | Timeout Before COD in second |
| Duplicated Leg In Block Trade Allowed? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  Allow Duplicated Leg in Block Trade or not. |
| Block Trade Allowed Conclusion Time | Numeric | 10 | M | - | Block Trade Allowed Conclusion Time in second |
| Maximum Order Size Limit By EP | Quantity | 9 | M | - | Maximum Order Size Limit By EP |
| Maximum Block Trade Size Limit By EP | Quantity | 9 | M | - | Maximum Block Trade Size Limit By EP |
| Num Of Leg In Block Trade | Numeric | 1 | M | - | Num Of Leg In Block Trade |
| Abrupt Disconnection Trigger COD? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  Abrupt Disconnection Trigger COD? |
| Remove Orders Violating Internal Crossing Rule? | Char | 1 | M | N | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  Remove Orders Violating Internal Crossing Rule? |
| Mass Quote Allowed Different Underlying Issuer? | Char | 1 | M | - | Read-only field.  Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  Can be ‘N’ only.  Mass Quote Allowed Different Underlying Issuer? |
| Maximum Quote Entries Per Comp ID Per Instrument | Numeric | 5 | M | - | Maximum Quote Entries Per Comp ID Per Instrument |
| Maximum TMC | Numeric | 10 | M | - | Maximum TMC |
| Maximum TMC Per EP | Numeric | 10 | M | - | Maximum TMC Per EP |
| Default Order Size Limit | Quantity | 9 | M | - | Default Order Size Limit |
| Default Block Trade Size Limit | Quantity | 9 | M | - | Default Block Trade Size Limit |
| Default PTRM Max Size Limit | Quantity | 9 | M | - | Default PTRM Max Size Limit |
| Default PTRM Exposure Limit | Numeric | 20 | M | - | Default PTRM Exposure Limit |
| Default PTRM Quantity Limit | Quantity | 9 | M | - | Default PTRM Quantity Limit |
| Default PTRM Order Rate Limit | Numeric | 20 | M | - | Default PTRM Order Rate Limit |
| Default PTRM Order Rate Period | Numeric | 10 | M | - | Default PTRM Order Rate Period |
| Default PTRM Order Coefficient (%) | Percentage | 9 | M | - | Default PTRM Order Coefficient (%) |
| Default PTRM Execution Throttle Period | Numeric | 10 | M | - | Default PTRM Execution Throttle Period |
| Default PTRM Notice Threshold (%) | Percentage | 9 | M | - | Default PTRM Notice Threshold (%) |
| Default PTRM Warning Threshold (%) | Percentage | 9 | M | - | Default PTRM Warning Threshold (%) |
| Default MMP Include Futures? | Char | 1 | M | - | Default MMP Include Futures? |
| Default MMP Quantity Protection | Quantity | 9 | M | - | Default MMP Quantity Protection |
| Default MMP Delta Protection | Quantity | 9 | M | - | Default MMP Delta Protection |
| Default MMP Exposure Time Limit Interval | Numeric | 10 | M | - | Default MMP Exposure Time Limit Interval |
| Default MMP Frozen Time | Numeric | 10 | M | - | Default MMP Frozen Time |
| Disseminate Implied In Orders Via Market Data? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  Disseminate Implied In Orders Via Market Data? |
| CA Cool-off Period | Numeric | 5 | M | - | CA Cool-off Period |
| SMP ID Maintenance Request Approval Period | Numeric | 5 | M | - | SMP ID Maintenance Request Approval Period |
| SMP ID Counterparty Request Period | Numeric | 5 | M | - | SMP ID Counterparty Request Period |
| SMP ID Retention Period | Numeric | 5 | M | - | SMP ID Retention Period |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0416\_00500**

**Actions**

**#FS10013\_S0416\_00601**

Perm

| Action | Description |
| --- | --- |
| Screen Open | Show all Global Parameters |
| Update Record | Update Tomorrow Change: update record for Tomorrow |
| Update Scheduled Change: update record for Scheduled time of Today and Tomorrow |
| Update ASAP Change: update record ASAP and Tomorrow |
| Withdraw Selected | Withdraw selected record which Records Status is Active and without Pending withdraw request. |
| Export | Export all Records from GUI current page table to CSV file |
| Confirm | Confirm the change and submit to backend, disabled with Read-only permission and view mode |
| Cancel | Cancel all changes, disabled with Read-only permission and view mode |

~~Temp (Ryan confirm no Temp)~~

| ~~Action~~ | ~~Description~~ |
| --- | --- |
| ~~Screen Open~~ | ~~Show all Global Parameters~~ |
| ~~Update Record~~ | ~~Update ASAP Change: update record ASAP~~ |
| ~~Export~~ | ~~Export all Records from GUI current page table to CSV file~~ |
| ~~Confirm~~ | ~~Confirm the change and submit to backend, disabled with Read-only permission and view mode~~ |
| ~~Cancel~~ | ~~Cancel all changes, disabled with Read-only permission and view mode~~ |

**Validation (Ref:** [**Validation Rule**](#_Validation_Rule_(TBC))**)**

**#FS10013\_S0416\_00701**

**Notification**

**#FS10013\_S0416\_00800**

| Event | Notification |
| --- | --- |
| Update Request | Pop up concurrent notification if any concurrent update occurred |

### Maintain Contingency Switch

**#FS10013\_S0416\_00900**

**Description**

**#FS10013\_S0416\_01000**

**Contingency Switch** is used to allow Business Operations to enable or disable trading functions in a contingency scenario. It is allowed to disable a trading function intra-day but can only be re-enabled on the next trading day.

**UI Layout**

**#FS10013\_S0416\_01101**

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290)) ![](data:image/png;base64...)

**Attributes**

**#FS10013\_S0416\_01201**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Static Price Limit Enabled? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| Dynamic Price Limit Enabled? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| VCM Enabled? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| SMP Enabled? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| Implied Enabled? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| PTRM Enabled? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0416\_01300**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0416\_01400**

| Action | Description |
| --- | --- |
| - | - |

**Validation (Ref:** [**Common Validation**](#_Common_Validation)**)**

**#FS10013\_S0416\_01500**

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0416\_01600**

### View Password Policy

**#FS10013\_S0416\_01700**

**Description**

**#FS10013\_S0416\_01800**

**View Password Policy** is used to view password policy for ODP Trading Admin.

**UI Layout**

**#FS10013\_S0416\_01902**

Search Page

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

Detail Page

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

**Attributes**

**#FS10013\_S0416\_02002**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Password Policy ID | Numeric | 5 | M | - | Password Policy ID |
| Password Policy Name | Alphanumeric | 20 | M | - | A unique name of the Password Policy |
| Policy Type | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Password Policy Type  Password Policy Type |
| Minimum Password Length | Numeric | 5 | M | - | Minimum Password Length |
| Maximum Password Length | Numeric | 5 | M | - | Maximum Password Length |
| Minimum Upper Case Letters | Numeric | 5 | M | - | Minimum Upper Case Letters |
| Minimum Lower Case Letters | Numeric | 5 | M | - | Minimum Lower Case Letters |
| Minimum Digits | Numeric | 5 | M | - | Minimum Digits |
| Minimum Special Characters | Numeric | 5 | M | - | Minimum Special Characters |
| Password Validity Period | Numeric | 5 | M | - | Password Validity Period |
| Password Expiry Advance Alert | Numeric | 5 | M | - | Password Expiry Advance Alert |
| Enforce Password Expiry Check? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  Enforce Password Expiry Check? |
| Password Reuse Cycle | Numeric | 5 | M | - | Password Reuse Cycle |
| Number of Failed Attempts | Numeric | 5 | M | - | Number of Failed Attempts |
| Change Password on 1st Logon? | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  Change Password on 1st Logon? |
| Maximum Password Changes Per Day | Numeric | 5 | M | - | Maximum Password Changes Per Day |
| Inactivity Period | Numeric | 5 | M | - | Inactivity Period |
| Password Expiry and Inactivity Handling | Numeric | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Password Expiry and Inactivity Handling |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**, support Read-only)**

**#FS10013\_S0416\_02100**

**Actions**

**#FS10013\_S0416\_02200**

| Action | Description |
| --- | --- |
| Screen Open | Trigger a query to display all records |
| Apply | Trigger a query of records based on input filters |
| Reset Filters | Reset all filters to default: All |
| Export | Export all Records from GUI current page table to CSV file |
| Cancel | Cancel in detail page go to search page |

**Validation**

**#FS10013\_S0416\_02300**

Not allow to update

**Notification**

**#FS10013\_S0416\_02400**

No notification as not allow to update

## Control & Monitoring

**#FS10013\_S0417\_00100**

### Monitor Historical Order Book

**#FS10013\_S0417\_00200**

**Description**

**#FS10013\_S0417\_00300**

**Historical Order Book** is used to retrieve a historical state of the order book for a certain Instrument ID. The data is fetched from the OLS.

The Bid/Ask table shows the actual state of the normal order book at a certain time. The events found in the OLS are presented in two tables, Applied Events and Not Applied Events. The left table contains the events that have been applied to the order book while handling data. The table to the right contains later events.

\*Above yellow highlighted from MPA user guide, with replacing LogB file with OLS.

**#FS10013\_S0417\_00400**

Allow users to search for historical order and trade history for up to 5 business days.

**UI Layout**

**#FS10013\_S0417\_00500**

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

**Attributes**

**#FS10013\_S0417\_00600**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Premium | - | - | - | - | Bid/Ask price of the order |
| Qty | - | - | - | - | Number of contracts that the order is bidding/offering for |
| Trader ID | - | - | - | - | Identity of the trader who entered the order |
| Time Validity | - | - | - | - | An order that will expire |
| Order No | - | - | - | - | Unique identifier for the order |
| Order Type | - | - | - | - | Order Type. For example, limit order or market order |

**Applied/Not Applied Attributes**

**#FS10013\_S0417\_00701**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Tx Time | - | - | - | - | Time when the transaction arrived at the market |
| Tx Type | - | - | - | - | Transaction type done via the API |
| Record Type | - | - | - | - | OLS Record Type |
| Record Trader ID | - | - | - | - | Identification code of the trader who executed the event |
| Record Concise Info | - | - | - | - | Concise order information. This column may not be available depending on system configuration |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**, support Read-only)**

**#FS10013\_S0417\_00800**

**Actions**

**#FS10013\_S0417\_00901**

| Action | Description |
| --- | --- |
| Screen Open | Trigger a query to display all records |
| Apply | Trigger a query of records based on input filters |
| Reset Filters | Reset all filters to default: All |
| Export | Export all Records from GUI current page table to CSV file |
| Prev Change | Display the previous change in the order book |
| Next Record | See if the OLS Record affects the state of the order book |
| Next Tx | See the next transaction |
| Next Change | Display the next change in the order book |
| Double clicks the row in one of the tables Applied Events or Not Applied Events | Display the OLS Record for a specific transaction |

**Validation**

**#FS10013\_S0417\_01000**

Not allow to update

**Notification**

**#FS10013\_S0417\_01100**

No notification as not allow to update

### Monitor Quote Request

**#FS10013\_S0417\_01200**

**Description**

**#FS10013\_S0417\_01300**

**Quote Request** is used to monitor quote requests. Attributes and layout could be adjusted based on the final Quote Request Specification.

**UI Layout**

**#FS10013\_S0417\_01400**

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

**Attributes**

**#FS10013\_S0417\_01500**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Time | Time | 8 | M | - | Time |
| Instrument ID | Alphanumeric | 32 | M | - | The ID of the Instrument (a unique ID). |
| Exchange Participant ID | Alphanumeric | 5 | M | - | The ID of the Exchange Participant. E.g. JPM |
| User ID | Alphanumeric | 32 | M | - | User ID |
| B/A | Alphanumeric | 3 | M | - | Bid/Ask |
| Status | Alphanumeric | 2 | M | - | Status |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**, support Read-only)**

**#FS10013\_S0417\_01600**

**Actions**

**#FS10013\_S0417\_01700**

| Action | Description |
| --- | --- |
| Screen Open | Trigger a query to display all records |
| Apply | Trigger a query of records based on input filters |
| Reset Filters | Reset all filters to default: All |
| Export | Export all Records from GUI current page table to CSV file |

**Validation**

**#FS10013\_S0417\_01800**

Not allow to update

**Notification**

**#FS10013\_S0417\_01900**

No notification as not allow to update

### Monitor OLS Record

**#FS10013\_S0417\_02000**

**Description**

**#FS10013\_S0417\_02100**

**OLS Record** is used to monitor Order Logging Server Record. Attributes and layout could be adjusted based on the final OLS specification.

**#FS10013\_S0417\_02201**

Allow users to search for historical order and trade history at least 10 business days records.

**UI Layout**

**#FS10013\_S0417\_02300**

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

**Attributes**

**#FS10013\_S0417\_02400**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Time | - | - | - | - | Time |
| Type | - | - | - | - | Type |
| Instrument ID | - | - | - | - | The ID of the Instrument (a unique ID). |
| Trader ID | - | - | - | - | Identity of the trader who entered the order |
| Misc | - | - | - | - | Misc |
| Key | - | - | - | - | Key of the record |
| Value | - | - | - | - | Value of the record |
| Raw Value | - | - | - | - | Raw value of the record |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**, support Read-only)**

**#FS10013\_S0417\_02500**

**Actions**

**#FS10013\_S0417\_02600**

| Action | Description |
| --- | --- |
| Screen Open | Trigger a query to display all records |
| Apply | Trigger a query of records based on input filters |
| Reset Filters | Reset all filters to default: All |
| Previous | Show previous data |
| Next | Show next data |

**Validation**

**#FS10013\_S0417\_02700**

Not allow to update

**Notification**

**#FS10013\_S0417\_02800**

No notification as not allow to update

### Monitor Event and Alert

**#FS10013\_S0417\_02900**

**Description**

**#FS10013\_S0417\_03000**

This function is used to examine and monitor the events/alerts published by Gateway. This is a real-time monitoring function. New event messages will be appended to the top of the table automatically.

Only the latest set of event messages could be displayed on Event and Alert Monitoring. It is limited to 60000 records. Note that when

**UI Layout**

**#FS10013\_S0417\_03100**

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

**Attributes**

**#FS10013\_S0417\_03200**

| **Column** | **Type** | **Length** | **M/O** | **Default** | **Remarks** |
| --- | --- | --- | --- | --- | --- |
| Seq Num | Numeric | 10 | - | - | Event sequence number. |
| Event Type | Numeric | 3 | - | - | 1 = General  2 = Control Request ACK |
| Event Time | Date and Time | 20 | - | - | Time of event generation. |
| Source | Alphanumeric | 12 | - | - | Source of application sending this event. |
| Origin | Alphanumeric | 40 | - | - | Origin triggering this event, e.g. Comp ID of a session, client IP address, or MCA, etc. |
| Event ID | Numeric | 10 | - | - | Gateway internal event ID. |
| Hints | Numeric | 10 | - | - | Hint of the event.  1 = Alert  2 = Connection History  4 = Audit |
| Severity | Numeric | 3 | - | - | Domain values:  1 = Error  2 = Warning  3 = Info |
| Req # | Numeric | 5 | - | - | Request ID generated by Admin GUI for each Control Request.  This ID will be echoed back in the corresponding Control Response and Control Request Ack. |
| Req. Target | Alphanumeric | 12 | - | - | Target client ID of the event.   1. For Action 1, the target is a Comp ID, like CO12345678 2. For Action 2-3, the target can be a Comp ID, like CO12345678; or CO\*, CC\*; or \*(CO\* & CC\*) 3. For Action 4-5, the target can be all applications (\*), a component (e.g. OFG\*) or an application partition (e.g. OFG01).   For Action 6, the target is an application partition (e.g. OFG01, or DCG02); or “RESET”. |
| Request Action | Numeric | 10 | - | - | Request action of the last event.  Domain values:  1 = Reset client message sequence number (MSN) to 1.  2 = Manually logoff client.  3 = Disconnect client.  4 = Enable external connection.  5 = Disable external connection.  6 = Update Lookup Server response IP address for cold standby server. |
| Ret. Code | Numeric | 5 | - | - | Return code the request of last event.  0 = Success  <Others> = Reject |
| Description | Alphanumeric | 200 | - | - | Event description. |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0417\_03300**

**Actions**

**#FS10013\_S0417\_03400**

| Action | Description |
| --- | --- |
| Screen Open | Trigger a query to display all records |
| Apply | Trigger a query of records based on input filters |
| Reset Filters | Reset all filters to default: All |
| Export | Export all Records from GUI current page table to CSV file |

**Validation**

**#FS10013\_S0417\_03500**

| Event | Validation Rule | Validation Message |
| --- | --- | --- |
|  |  |  |

### Monitor Order Flow Gateway

**#FS10013\_S0417\_03600**

**Description**

**#FS10013\_S0417\_03700**

This function is used to show the statistics of Order Flow gateway. This is a real-time monitoring function. Process statistics published by Gateway will be updated on the screen automatically.

**UI Layout**

**#FS10013\_S0417\_03800**

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

**Attributes**

**#FS10013\_S0417\_03900**

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
| **Column** | **Type** | **Length** | **M/O** | **Default** | **Remarks** |
| ID | Alphanumeric | 50 | - | - | ID of the statistics record. |
| Instance ID | Alphanumeric | 12 | - | - | The combination of:  [Application ID]:[Instance ID]  It is the unique identifier of an application instance. |
| Component | Alphanumeric | 9 | - | - | Component name. Domain values: OFG, DCG, DCC, GCM, LS |
| Partition | Numeric | 3 | - | - | Partition number. |
| Subgroup | Char | 1 | - | - | Subgroup ID. Optional. |
| Last Updated Time | Date and Time | 20 | - | - | Last updated time. |
| Total Clients | Numeric | 10 | - | - | Total number of clients. |
| Logged-on Clients | Numeric | 10 | - | - | Total number of logged-on clients. |
| Logged-on Attempts | Numeric | 10 | - | - | Total number of logon attempts including success and failure. |
| Successful Logons | Numeric | 10 | - | - | Total number of successfully logons. |
| Disconnected Clients | Numeric | 10 | - | - | Total number of disconnected clients. |
| Not Connected Clients | Numeric | 10 | - | - | Total number of not connected clients. |
| Client Current Input Rate | Numeric | 10 | - | - | Current input message rate from client. |
| Client Current Output Rate | Numeric | 10 | - | - | Current output message rate to client. |
| Client Peak Input Rate | Numeric | 10 | - | - | Peak input message rate from client. |
| Client Peak Output Rate | Numeric | 10 | - | - | Peak output message rate to client. |
| Client Total Input | Numeric | 10 | - | - | Total number of input messages from client. |
| Client Total Output | Numeric | 10 | - | - | Total number of output messages to client. |
| New | Numeric | 10 | - | - | Total number of New Orders from client. |
| Amend | Numeric | 10 | - | - | Total number of Amend Orders from client. |
| Cancel | Numeric | 10 | - | - | Total number of Cancel Requests from client. |
| Quote | Numeric | 10 | - | - | Total number of Quote Orders from client. |
| Quote Cancel | Numeric | 10 | - | - | Total number of Quote Cancel Orders from client. |
| TCR New | Numeric | 10 | - | - | Total number of TCR New Orders from client. |
| TCR Cancel | Numeric | 10 | - | - | Total number of TCR Cancel Orders from client. |
| Obo Single | Numeric | 10 | - | - | Total number of Obo Single Cancel Orders from client. |
| Mass Cancel | Numeric | 10 | - | - | Total number of Mass Cancel Orders from client. |
| Obo Mass Cancel | Numeric | 10 | - | - | Total number of Obo Mass Cancel Orders from client. |
| Session Reject | Numeric | 10 | - | - | Total number of Session Rejects to client |
| BMR | Numeric | 10 | - | - | Total number of BMR to client |
| BMR in Throttle Breach | Numeric | 10 | - | - | Total number of BMRs that result in throttle breach. |
| New ER | Numeric | 10 | - | - | Total number of New ERs. |
| Rejected ER | Numeric | 10 | - | - | Total number of Rejected ERs. |
| Cancelled ER | Numeric | 10 | - | - | Total number of Cancelled ERs. |
| Amended ER | Numeric | 10 | - | - | Total number of Amended ERs. |
| Amend Rejected ER | Numeric | 10 | - | - | Total number of Amend Reject ERs. |
| Cancel Rejected ER | Numeric | 10 | - | - | Total number of Cancel Reject ERs. |
| Expired ER | Numeric | 10 | - | - | Total number of Expired ERs |
| Trade ER | Numeric | 10 | - | - | Total number of Trade ERs. |
| Trade Cancelled ER | Numeric | 10 | - | - | Total number of Trade Cancelled ERs. |
| Mass Cancel Report | Numeric | 10 | - | - | Total number of Mass Cancel Reports. |
| Quote Status Report | Numeric | 10 | - | - | Total number of Quote Status Reports. |
| TCR Accepted | Numeric | 10 | - | - | Total number of TCR Trade (OE) Accepted & Trade (Odd Lot) Accepted to client |
| TCR Cancelled | Numeric | 10 | - | - | Total number of TCR Cancelled to client |
| TCR Ack | Numeric | 10 | - | - | Total number of Trade Capture Report Ack to client |
| Mkt Current Output Rate | Numeric | 10 | - | - | Current output message rate to ODP. |
| Mkt Current Input Rate | Numeric | 10 | - | - | Current input message rate from ODP. |
| Mkt Peak Output Rate | Numeric | 10 | - | - | Peak output message rate to ODP. |
| Mkt Peak Input Rate | Numeric | 10 | - | - | Peak output message rate from ODP. |
| Mkt Total Input | Numeric | 10 | - | - | Total number of input messages from ODP. |
| Mkt Total Output | Numeric | 10 | - | - | Total number of output messages to ODP. |
| To Mkt - New | Numeric | 10 | - | - | Total number of BL New Orders to ODP. |
| To Mkt - Amend | Numeric | 10 | - | - | Total number of Amend Orders to ODP. |
| To Mkt - Cancel | Numeric | 10 | - | - | Total number of BL Cancel Orders to ODP. |
| To Mkt - Mass Cancel | Numeric | 10 | - | - | Total number of Mass Cancel Orders to ODP. |
| To Mkt - Obo Single Cancel | Numeric | 10 | - | - | Total number of Obo Single Cancel Orders to ODP. |
| To Mkt - Obo Mass Cancel | Numeric | 10 | - | - | Total number of Obo Mass Cancel Orders to ODP. |
| To Mkt - COD Mass Cancel | Numeric | 10 | - | - | Total number of COD Mass Cancel Orders to ODP. |
| To Mkt - Quote | Numeric | 10 | - | - | Total number of Quotes to ODP. |
| To Mkt - Quote Cancel | Numeric | 10 | - | - | Total number of Quote Cancels to ODP. |
| To Mkt - TCR New | Numeric | 10 | - | - | Total number of TCR New to ODP. |
| To Mkt - TCR Reject | Numeric | 10 | - | - | Total number of TCR Reject (i.e. to reject a TCR) to ODP. |
| To Mkt - OL New | Numeric | 10 | - | - | Total number of OL New Orders to ODP. |
| To Mkt - OL Cancel | Numeric | 10 | - | - | Total number of OL Cancel Orders to ODP. |
| To Mkt - OL Trade | Numeric | 10 | - | - | Total number of OL Trade Orders. |
| From Mkt - Order Added | Numeric | 10 | - | - | Total number of BL Order Added from ODP. |
| From Mkt - Amended | Numeric | 10 | - | - | Total number of Order Amended from ODP. |
| From Mkt - Order Updated | Numeric | 10 | - | - | Total number of Order Updated from ODP. |
| From Mkt - Order Cancelled | Numeric | 10 | - | - | Total number of Order Cancelled from ODP. |
| From Mkt - Quote Added | Numeric | 10 | - | - | Total number of Quote Added from ODP. |
| From Mkt - Quote Amended | Numeric | 10 | - | - | Total number of Quote Amended from ODP. |
| From Mkt - Quote Cancelled | Numeric | 10 | - | - | Total number of Quote Cancelled from ODP. |
| From Mkt - Trade | Numeric | 10 | - | - | Total number of BL/Quote Trade from ODP. |
| From Mkt - OE Trade | Numeric | 10 | - | - | Total number of OE Trade from ODP. |
| From Mkt - OL Order Added | Numeric | 10 | - | - | Total number of OL Order Added from ODP. |
| From Mkt - OL Trade | Numeric | 10 | - | - | Total number of OL Trade from ODP. |
| From Mkt - Trade Cancelled | Numeric | 10 | - | - | Total number of Trade Cancelled from ODP. |
| From Mkt - Order Rejected | Numeric | 10 | - | - | Total number of Order Rejected from ODP. |
| From Mkt - Order Cancel Rejected | Numeric | 10 | - | - | Total number of Order Cancel Rejected from ODP. |
| From Mkt - Order Amend Rejected | Numeric | 10 | - | - | Total number of Order Amend Rejected from ODP. |
| From Mkt - Amended Order Rejected | Numeric | 10 | - | - | Total number of Amended BL Order Rejected from ODP. |
| From Mkt - Trade Report Rejected | Numeric | 10 | - | - | Total number of Trade Report Rejected from ODP. |
| From Mkt - Quote Status Report | Numeric | 10 | - | - | Total number of Quote Status Report from ODP. |
| From Mkt - Mass Cancel Report | Numeric | 10 | - | - | Total number of Order Mass Cancel Report from ODP. |
| From Mkt - Biz Accepted | Numeric | 10 | - | - | Total number of Business Message Accepted from ODP. |
| From Mkt - Biz Accepted | Numeric | 10 | - | - | Total number of Business Message Rejected from ODP. |
| Average Forward Latency (Instant) | Numeric | 10 | - | - | Instant average GW internal forward latency. |
| Average Backward Latency (Instant) | Numeric | 10 | - | - | Instant average GW internal backward latency. |
| Internal Peak Latency (Instant) | Numeric | 10 | - | - | Instant internal peak latency. |
| Average Turnaround Latency (Instant) | Numeric | 10 | - | - | Instant average Turnaround latency. |
| Turnaround Peak Latency (Instant) | Numeric | 10 | - | - | Instant turnaround peak latency. |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0417\_04000**

**Actions**

**#FS10013\_S0417\_04100**

| Action | Description |
| --- | --- |
| Screen Open | Trigger a query to display all records |
| Apply | Trigger a query of records based on input filters |
| Reset Filters | Reset all filters to default: All |
| Export | Export all Records from GUI current page table to CSV file |

**Validation**

**#FS10013\_S0417\_04200**

| Event | Validation Rule | Validation Message |
| --- | --- | --- |
|  |  |  |

### Monitor Drop Copy Gateway

**#FS10013\_S0417\_04300**

**Description**

**#FS10013\_S0417\_04400**

This function is used to show the statistics of Drop Copy Gateway. This is a real-time monitoring function. Process statistics published by Gateway will be updated on the screen automatically.

**UI Layout**

**#FS10013\_S0417\_04500**

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

**Attributes**

**#FS10013\_S0417\_04600**

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
| **Column** | **Type** | **Length** | **M/O** | **Default** | **Remarks** |
| ID | Alphanumeric | 50 | - | - | ID of the statistics record. |
| Instance ID | Alphanumeric | 12 | - | - | The combination of:  [Application ID]:[Instance ID]  It is the unique identifier of an application instance. |
| Component | Alphanumeric | 9 | - | - | Component name. Domain values: OFG, DCG, DCC, GCM, LS |
| Partition | Numeric | 3 | - | - | Partition number. |
| Subgroup | Char | 1 | - | - | Subgroup ID. Optional. |
| Last Updated Time | Date and Time | 20 | - | - | Last updated time. |
| Total Clients | Numeric | 10 | - | - | Total number of clients. |
| Logged-on Clients | Numeric | 10 | - | - | Total number of logged-on clients. |
| Logged-on Attempts | Numeric | 10 | - | - | Total number of logon attempts including success and failure. |
| Successful Logons | Numeric | 10 | - | - | Total number of successfully logons. |
| Disconnected Clients | Numeric | 10 | - | - | Total number of disconnected clients. |
| Not Connected Clients | Numeric | 10 | - | - | Total number of not connected clients. |
| Mkt Current Input Rate | Numeric | 10 | - | - | Current input message rate from all DCCs. |
| Mkt Peak Input Rate | Numeric | 10 | - | - | Peak output message rate from all DCCs. |
| Client Current Output Rate | Numeric | 10 | - | - | Current output message rate to client. |
| Client Peak Output Rate | Numeric | 10 | - | - | Peak output message rate to client. |
| Client Total Input | Numeric | 10 | - | - | Total number of input messages from client. |
| Client Total Output | Numeric | 10 | - | - | Total number of output messages to client. |
| Session Reject | Numeric | 10 | - | - | Total number of Session Rejects to client |
| BMR | Numeric | 10 | - | - | Total number of BMR to client |
| New ER | Numeric | 10 | - | - | Total number of New ERs. |
| Cancelled ER | Numeric | 10 | - | - | Total number of Cancelled ERs. |
| Amended ER | Numeric | 10 | - | - | Total number of Amended ERs. |
| Expired ER | Numeric | 10 | - | - | Total number of Expired ERs |
| Trade ER | Numeric | 10 | - | - | Total number of Trade ERs. |
| Trade Cancelled ER | Numeric | 10 | - | - | Total number of Trade Cancelled ERs. |
| TCR New | Numeric | 10 | - | - | Total number of TCR New Orders from clients. |
| TCR Cancel | Numeric | 10 | - | - | Total number of TCR Cancel Orders from clients. |
| Instant Latency | Numeric | 10 | - | - | Instant average internal latency from receiving to the point where the message has just been sent to first client. |
| Total DCCs | Numeric | 10 | - | - | Total number of connected DCCs. |
| DCC Info | Alphanumeric |  | - | - | DCC connection information repeating group. In a comma separated string with <Partition No>|<Total Rx>,<Partition No>|<Total Rx>,… |
| à Partition No | Numeric | 3 | - | - | DCC Partition number. |
| à Total Rx | Numeric | 10 | - | - | Total number of messages received from DCC. |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0417\_04700**

**Actions**

**#FS10013\_S0417\_04800**

| Action | Description |
| --- | --- |
| Screen Open | Trigger a query to display all records |
| Apply | Trigger a query of records based on input filters |
| Reset Filters | Reset all filters to default: All |
| Export | Export all Records from GUI current page table to CSV file |

**Validation**

**#FS10013\_S0417\_04900**

| Event | Validation Rule | Validation Message |
| --- | --- | --- |
|  |  |  |

### Monitor Lookup Server Statistic

**#FS10013\_S0417\_05000**

**Description**

**#FS10013\_S0417\_05100**

This function is used to show the statistics of Lookup Server. This is a real-time monitoring function. Process statistics published by Gateway will be updated on the screen automatically.

**UI Layout**

**#FS10013\_S0417\_05200**

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

**Attributes**

**#FS10013\_S0417\_05300**

| **Column** | **Type** | **Length** | **M/O** | **Default** | **Remarks** |
| --- | --- | --- | --- | --- | --- |
| ID | Alphanumeric | 50 | - | - | ID of the statistics record. |
| Instance ID | Alphanumeric | 12 | - | - | The combination of:  [Application ID]:[Instance ID]  It is the unique identifier of an application instance. |
| Component | Alphanumeric | 9 | - | - | Component name. Domain values: OFG, DCG, DCC, GCM, LS |
| Partition | Numeric | 3 | - | - | Partition number. |
| Subgroup | Char | 1 | - | - | Subgroup ID. Optional. |
| Last Updated Time | Date and Time | 20 | - | - | Last updated time. |
| Current Connections | Numeric | 10 | - | - | Total number of current socket connections. |
| Total Accumulated Connections | Numeric | 10 | - | - | Total number of socket connections that have been established. |
| Valid Lookup Request | Numeric | 10 | - | - | Total number of valid lookup requests. |
| Invalid Lookup Requests | Numeric | 10 | - | - | Total number of invalid lookup requests. |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0417\_05400**

**Actions**

**#FS10013\_S0417\_05500**

| Action | Description |
| --- | --- |
| Screen Open | Trigger a query to display all records |
| Apply | Trigger a query of records based on input filters |
| Reset Filters | Reset all filters to default: All |
| Export | Export all Records from GUI current page table to CSV file |

**Validation**

**#FS10013\_S0417\_05600**

| Event | Validation Rule | Validation Message |
| --- | --- | --- |
|  |  |  |

### Order Flow Client Enquiry

**#FS10013\_S0417\_05700**

**Description**

**#FS10013\_S0417\_05800**

This function is used to query the information of Order Flow Client. This is a static query function.

In the upper part of the page, it shows the information of a list of Order Flow Client. Once a row is selected, it shows further details in the lower part of the page including

1. Trader static information – the static data of Trader data of the Order Flow Client.

**UI Layout**

**#FS10013\_S0417\_05900**

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

**Order Flow Client Attributes**

**#FS10013\_S0417\_06001**

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
| **Column** | **Type** | **Length** | **M/O** | **Default** | **Remarks** |
| Record ID | Alphanumeric | 50 | - | - | ID of the record. |
| Comp ID | Alphanumeric | 10 | - | - | Sender Comp ID |
| CG ID | Alphanumeric | 11 | - | - | CG ID that would be hosting this client.  CG applications will not make use of this field for any specific processing or functionality, except as a display attribute. |
| Protocol Type | Char | 1 | - | - | Ref: [Common Attributes](#_Common_Attributes) - Interface Protocol |
| Blocked | Char | 1 | - | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| In-Load Gen | Char | 1 | - | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| Session Type | Numeric | 3 | - | - | Session type/trading purpose.  1 = Normal Trading  2 = Special Participant (SP) Session  3 = Liquidity Provider (LP) Session  4 = Security Market Maker (SMM) Session  5 = Kill Button (KB) Session  Others |
| Absolute TPS | Numeric | 5 | - | - | TPS entitlement for this client session |
| Warning TPS | Numeric | 5 | - | - | TPS threshold to show warning. |
| Disconnect TPS | Numeric | 5 | - | - | TPS threshold to disconnect this client session. |
| No. of IPs | Numeric | 5 | - | - | Number of IP address assigned. |
| IP1 | Alphanumeric | 16 | - | - | IP address 1 |
| IP2 | Alphanumeric | 16 | - | - | IP address 2 |
| IP3 | Alphanumeric | 16 | - | - | IP address 3 |
| IP4 | Alphanumeric | 16 | - | - | IP address 4 |
| Encrypted | Char | 1 | - | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| COD | Char | 1 | - | - | Cancel on disconnect.  Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| Delay before Cancel | Numeric | 10 | - | - | Delay before initiating cancel for COD; in seconds. |
| Update Seq | Numeric | 5 | - | - | Update sequence number. |
| Partition ID | Numeric | 5 | - | - | Partition number. |

**Trader Attributes**

**#FS10013\_S0417\_06101**

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
| **Column** | **Type** | **Length** | **M/O** | **Default** | **Remarks** |
| Trader ID | Alphanumeric | 10 | - | - | Trader ID. |
| Participant ID | Alphanumeric | 5 | - | - | Exchange Participant ID to which this Trader belongs. |
| Suspend | Char | 1 | - | - | Is this trader suspended?  Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| Type | Char | 1 | - | - | Ref: [Common Attributes](#_Common_Attributes) - Trader Type |
| Comp ID | Alphanumeric | 10 | - | - | Sender Comp ID. |
| Update Seq | Numeric | 5 | - | - | Update sequence number. |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0417\_06200**

**Actions**

**#FS10013\_S0417\_06300**

| Action | Description |
| --- | --- |
| Screen Open | Trigger a query to display all records |
| Apply | Trigger a query of records based on input filters |
| Reset Filters | Reset all filters to default: All |
| Export | Export all Records from GUI current page table to CSV file |

**Validation**

**#FS10013\_S0417\_06400**

| Event | Validation Rule | Validation Message |
| --- | --- | --- |
|  |  |  |

### Drop Copy Client Enquiry

**#FS10013\_S0417\_06500**

**Description**

**#FS10013\_S0417\_06600**

This function is used to query the information of Drop Copy Client. This is a static query function.

**UI Layout**

**#FS10013\_S0417\_06700**

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

**Attributes**

**#FS10013\_S0417\_06801**

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
| **Column** | **Type** | **Length** | **M/O** | **Default** | **Remarks** |
| Record ID | Alphanumeric | 50 | - | - | ID of the record. |
| Comp ID | Alphanumeric | 10 | - | - | Sender Comp ID |
| CG ID | Alphanumeric | 10 | - | - | CG ID that would be hosting this client.  CG applications will not make use of this field for any specific processing or functionality, except as a display attribute. |
| Protocol Type | Char | 1 | - | - | Ref: [Common Attributes](#_Common_Attributes) - Interface Protocol |
| Blocked | Char | 1 | - | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| In-Load Gen | Char | 1 | - | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| Include Orders | Char | 1 | - | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| Include Trades | Char | 1 | - | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| Encrypted | Char | 1 | - | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| Partition ID | Numeric | 5 | - | - | Partition number. |
| Update Seq | Numeric | 5 | - | - | Update sequence number. |
| No. of IPs | Numeric | 5 | - | - | Number of IP address assigned. |
| IP1 | Alphanumeric | 15 | - | - | IP address 1 |
| IP2 | Alphanumeric | 15 | - | - | IP address 2 |
| IP3 | Alphanumeric | 15 | - | - | IP address 3 |
| IP4 | Alphanumeric | 15 | - | - | IP address 4 |
| Trader Brokers | Numeric | 5 | - | - | Number of brokers assigned. |
| Trader Details |  |  | - | - | List of Trader IDs for this drop copy session. |
| à Trader ID | Alphanumeric | 10 | - | - | Trader ID |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0417\_06900**

**Actions**

**#FS10013\_S0417\_07000**

| Action | Description |
| --- | --- |
| Screen Open | Trigger a query to display all records |
| Apply | Trigger a query of records based on input filters |
| Reset Filters | Reset all filters to default: All |
| Export | Export all Records from GUI current page table to CSV file |

**Validation**

**#FS10013\_S0417\_07100**

| Event | Validation Rule | Validation Message |
| --- | --- | --- |
|  |  |  |

### Control & Monitor Order Flow Client

**#FS10013\_S0417\_07200**

**Description**

**#FS10013\_S0417\_07301**

This function is used to monitor the connection status of Order Flow Clients. This is a real-time monitoring function. Connection statistics published by Gateway will be updated on the screen automatically.

In the upper part of a window, it shows the connection status of a list of Order Flow Clients. The table is in Tree structure with records are grouped by Participant ID, and it’s collapsed by default. Once a connection is selected, it shows further details in the lower part of the window including:

* Connection history – the event messages with Action Hint marked as Connection History.
* Client static information – the static data of Order Flow Clients.
* Trader static information – the static data of trader data of the Order Flow Client.

On a selected connection, it could be able to submit the following Control Request to this target Comp ID.

* Reset Client MSN
* Manually logoff client
* Disconnect client
* Reset Kill Switch

It follows Maker/Checker mechanism to submit control requests. After the Maker submits the request, Approver needs to enter Countersign Request function to approve the request.

**UI Layout**

**#FS10013\_S0417\_07400**

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

**Order Flow Client Connection Attributes**

**#FS10013\_S0417\_07501**

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
| **Column** | **Type** | **Length** | **M/O** | **Default** | **Remarks** |
| Participant ID | Alphanumeric | 5 | - | - | Exchange Participant ID of the Order Flow Client.  **Records are grouped by Participant ID.** |
| Logged-on | Numeric | 10 | - | - | Number of Logged-on User under the Participant ID.  **Summary figure for the Participant ID.** |
| Disconnected | Numeric | 10 | - | - | Number of Disconnected User under the Participant ID.  **Summary figure for the Participant ID.** |
| Not Connected | Numeric | 10 | - | - | Number of Not Connected User under the Participant ID.  **Summary figure for the Participant ID.** |
| ID | Alphanumeric | 50 | - | - | ID of the connection status record. |
| Instance ID | Alphanumeric | 12 | - | - | The combination of:  [Application ID]:[Instance ID]  It is the unique identifier of an application instance. |
| Component | Alphanumeric | 9 | - | - | Component name. Domain values: OFG, DCG, DCC, GCM, LS |
| Partition | Numeric | 3 | - | - | Partition number. |
| Subgroup | Char | 1 | - | - | Subgroup ID. Optional. |
| Last Updated Time | Date and Time | 20 | - | - | Last updated time. |
| Comp ID | Alphanumeric | 10 | - | - | Sender Comp ID. |
| Client Status | Numeric | 3 | - | - | Ref: [Common Attributes](#_Common_Attributes) - Client Status |
| Protocol Type | Char | 1 | - | - | Ref: [Common Attributes](#_Common_Attributes) - Interface Protocol |
| Connection Status | Numeric | 3 | - | - | Ref: [Common Attributes](#_Common_Attributes) - Connection Status |
| Connection IP | Numeric | 10 | - | - | INET address of IP address of client connection. |
| Connection Port | Numeric | 5 | - | - | Client connection port number |
| Connection Duration | Time | 8 | - | - | Client connection duration in seconds. |
| Last State Change Time | Date and Time | 20 | - | - | Last change time of client connection state. |
| Logged-on Attempts | Numeric | 10 | - | - | Total number of logon attempts including success and failure. |
| Successful Logons | Numeric | 10 | - | - | Total number of successful logons. |
| Last Received MSN | Numeric | 10 | - | - | Last received MSN from the client. |
| Next Expected MSN | Numeric | 10 | - | - | Next expected MSN from the client. |
| Last Sent MSN | Numeric | 10 | - | - | Last sent MSN to the client |
| Client Current Input Rate | Numeric | 10 | - | - | Current input message rate from client. |
| Client Current Output Rate | Numeric | 10 | - | - | Current output message rate to client. |
| Client Peak Input Rate | Numeric | 10 | - | - | Peak input message rate from client. |
| Client Peak Output Rate | Numeric | 10 | - | - | Peak output message rate to client. |
| Client Total Input | Numeric | 10 | - | - | Total number of input messages from client. |
| Client Total Output | Numeric | 10 | - | - | Total number of output messages to client. |
| New | Numeric | 10 | - | - | Total number of New Orders from client. |
| Amend | Numeric | 10 | - | - | Total number of Amend Orders from client. |
| Cancel | Numeric | 10 | - | - | Total number of Cancel Requests from client. |
| Quote | Numeric | 10 | - | - | Total number of Quote Orders from client. |
| Quote Cancel | Numeric | 10 | - | - | Total number of Quote Cancel Orders from client. |
| TCR New | Numeric | 10 | - | - | Total number of TCR New Orders from client. |
| TCR Cancel | Numeric | 10 | - | - | Total number of TCR Cancel Orders from client. |
| Obo Single | Numeric | 10 | - | - | Total number of Obo Single Cancel Orders from client. |
| Mass Cancel | Numeric | 10 | - | - | Total number of Mass Cancel Orders from client. |
| Obo Mass Cancel | Numeric | 10 | - | - | Total number of Obo Mass Cancel Orders from client. |
| Session Reject | Numeric | 10 | - | - | Total number of Session Rejects to client |
| BMR | Numeric | 10 | - | - | Total number of BMR to client |
| BMR in Throttle Breach | Numeric | 10 | - | - | Total number of BMRs that result in throttle breach. |
| New ER | Numeric | 10 | - | - | Total number of New ERs. |
| Rejected ER | Numeric | 10 | - | - | Total number of Rejected ERs. |
| Cancelled ER | Numeric | 10 | - | - | Total number of Cancelled ERs. |
| Amended ER | Numeric | 10 | - | - | Total number of Amended ERs. |
| Amend Rejected ER | Numeric | 10 | - | - | Total number of Amend Reject ERs. |
| Cancel Rejected ER | Numeric | 10 | - | - | Total number of Cancel Reject ERs. |
| Expired ER | Numeric | 10 | - | - | Total number of Expired ERs |
| Trade ER | Numeric | 10 | - | - | Total number of Trade ERs. |
| Trade Cancelled ER | Numeric | 10 | - | - | Total number of Trade Cancelled ERs. |
| Mass Cancel Report | Numeric | 10 | - | - | Total number of Mass Cancel Reports. |
| Quote Status Report | Numeric | 10 | - | - | Total number of Quote Status Reports. |
| TCR Accepted | Numeric | 10 | - | - | Total number of TCR Trade (OE) Accepted & Trade (Odd Lot) Accepted to client |
| TCR Cancelled | Numeric | 10 | - | - | Total number of TCR Cancelled to client |
| TCR Ack | Numeric | 10 | - | - | Total number of Trade Capture Report Ack to client |
| Mkt Current Output Rate | Numeric | 10 | - | - | Current output message rate to ODP. |
| Mkt Current Input Rate | Numeric | 10 | - | - | Current input message rate from ODP. |
| Mkt Peak Output Rate | Numeric | 10 | - | - | Peak output message rate to ODP. |
| Mkt Peak Input Rate | Numeric | 10 | - | - | Peak output message rate from ODP. |
| Mkt Total Input | Numeric | 10 | - | - | Total number of input messages from ODP. |
| Mkt Total Output | Numeric | 10 | - | - | Total number of output messages to ODP. |
| Mkt New Request | Numeric | 10 | - | - | Total number of BL New Orders to ODP. |
| Mkt Amend Request | Numeric | 10 | - | - | Total number of Amend Orders to ODP. |
| Mkt Cancel Request | Numeric | 10 | - | - | Total number of BL Cancel Orders to ODP. |
| Mkt Mass Cancel Request | Numeric | 10 | - | - | Total number of Mass Cancel Orders to ODP. |
| Mkt Obo Single Cancel Request | Numeric | 10 | - | - | Total number of Obo Single Cancel Orders to ODP. |
| Mkt Obo Mass Cancel Request | Numeric | 10 | - | - | Total number of Obo Mass Cancel Orders to ODP. |
| Mkt COD Mass Cancel Request | Numeric | 10 | - | - | Total number of COD Mass Cancel Orders to ODP. |
| Mkt Quote Request | Numeric | 10 | - | - | Total number of Quotes to ODP. |
| Mkt Quote Cancel Request | Numeric | 10 | - | - | Total number of Quote Cancels to ODP. |
| Mkt TCR New Request | Numeric | 10 | - | - | Total number of TCR New to ODP. |
| Mkt TCR Reject Request | Numeric | 10 | - | - | Total number of TCR Reject (i.e. to reject a TCR) to ODP. |
| Mkt OL New Request | Numeric | 10 | - | - | Total number of OL New Orders to ODP. |
| Mkt OL Cancel Request | Numeric | 10 | - | - | Total number of OL Cancel Orders to ODP. |
| Mkt OL Trade Request | Numeric | 10 | - | - | Total number of OL Trade Orders. |
| Mkt Order Added | Numeric | 10 | - | - | Total number of BL Order Added from ODP. |
| Mkt Amended | Numeric | 10 | - | - | Total number of Order Amended from ODP. |
| Mkt Order Updated | Numeric | 10 | - | - | Total number of Order Updated from ODP. |
| Mkt Order Cancelled | Numeric | 10 | - | - | Total number of Order Cancelled from ODP. |
| Mkt Quote Added | Numeric | 10 | - | - | Total number of Quote Added from ODP. |
| Mkt Quote Amended | Numeric | 10 | - | - | Total number of Quote Amended from ODP. |
| Mkt Quote Cancelled | Numeric | 10 | - | - | Total number of Quote Cancelled from ODP. |
| Mkt Trade | Numeric | 10 | - | - | Total number of BL/Quote Trade from ODP. |
| Mkt OE Trade | Numeric | 10 | - | - | Total number of OE Trade from ODP. |
| Mkt OL Order Added | Numeric | 10 | - | - | Total number of OL Order Added from ODP. |
| Mkt OL Trade | Numeric | 10 | - | - | Total number of OL Trade from ODP. |
| Mkt Trade Cancelled | Numeric | 10 | - | - | Total number of Trade Cancelled from ODP. |
| Mkt Order Rejected | Numeric | 10 | - | - | Total number of Order Rejected from ODP. |
| Mkt Order Cancel Rejected | Numeric | 10 | - | - | Total number of Order Cancel Rejected from ODP. |
| Mkt Order Amend Rejected | Numeric | 10 | - | - | Total number of Order Amend Rejected from ODP. |
| Mkt Amended Order Rejected | Numeric | 10 | - | - | Total number of Amended BL Order Rejected from ODP. |
| Mkt Trade Report Rejected | Numeric | 10 | - | - | Total number of Trade Report Rejected from ODP. |
| Mkt Quote Status Report | Numeric | 10 | - | - | Total number of Quote Status Report from ODP. |
| Mkt Mass Cancel Report | Numeric | 10 | - | - | Total number of Order Mass Cancel Report from ODP. |
| Mkt Biz Accepted | Numeric | 10 | - | - | Total number of Business Message Accepted from ODP. |
| Mkt Biz Accepted | Numeric | 10 | - | - | Total number of Business Message Rejected from ODP. |
| Average Forward Latency (Instant) | Numeric | 10 | - | - | Instant Average GW internal forward latency |
| Average Backward Latency (Instant) | Numeric | 10 | - | - | Instant Average GW internal backward latency |
| Average Turnaround Latency (Instant) | Numeric | 10 | - | - | Instant Average Turnaround latency |

**Connection History Attributes**

**#FS10013\_S0417\_07600**

Refer to the Attributes of **Monitor Event and Alert**.

**Client Attributes**

**#FS10013\_S0417\_07700**

Refer to the Attributes of **Order Flow Client Enquiry**.

**Trader Attributes**

**#FS10013\_S0417\_07800**

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
| **Column** | **Type** | **Length** | **M/O** | **Default** | **Remarks** |
| Trader ID | Alphanumeric | 10 | - | - | Trader ID. |
| Participant ID | Alphanumeric | 5 | - | - | Exchange Participant ID to which this Trader belongs. |
| Suspend | Char | 1 | - | - | Is this trader suspended?  Y = Yes  N = No |
| Type | Char | 1 | - | - | Ref: [Common Attributes](#_Common_Attributes) - Trader Type |
| Comp ID | Alphanumeric | 10 | - | - | Sender Comp ID. |
| Update Seq | Numeric | 5 | - | - | Update sequence number. |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0417\_07900**

**Actions**

**#FS10013\_S0417\_08000**

| Action | Description |
| --- | --- |
| Screen Open | Trigger a query to display all records |
| Apply | Trigger a query of records based on input filters |
| Reset Filters | Reset all filters to default: All |
| Export as CSV | Export all Records from GUI current page table to CSV file.  (Based on the filtering criteria) |
| Export all Participants as CSV | Export all Records in Participant level to CSV file. (All the filtering criteria will be ignored.) |
| Export all Comp ID as CSV | Export all Records in Comp ID level to CSV file. (All the filtering criteria will be ignored.) |
| Reset Client MSN | Reset client message sequence number (MSN) of the selected client to 1. (Only one client can be selected at a time) |
| Manually logoff client | Manually logoff the selected client.  (Only one client can be selected at a time) |
| Disconnect client | Disconnect the selected client.  (Only one client can be selected at a time) |

**Validation**

**#FS10013\_S0417\_08100**

| Event | Validation Rule | Validation Message |
| --- | --- | --- |
|  |  |  |

### Control & Monitor Drop Copy Client

**#FS10013\_S0417\_08200**

**Description**

**#FS10013\_S0417\_08300**

This function is used to monitor the connection status of drop copy clients. This is a real-time monitoring function. Connection statistics published by Gateway will be updated on the screen automatically.

In the upper part of a window, it shows the connection status of a list of Order Flow Clients. The table is in Tree structure with records are grouped by Participant ID, and it’s collapsed by default. Once a connection is selected, it could show further details in the lower part of the window including

* Connection history – the event messages with Action Hint marked as Connection History.
* Client static information – the static data of Order Flow Clients.

On a selected connection, it will be able to submit the following Control Request to this target Comp ID.

* Reset Client MSN
* Manually logoff client
* Disconnect client

It follows Maker/Checker mechanism to submit control requests. After the Maker submits the request, the Approver needs to enter Approve Request function to approve the request.

**UI Layout**

**#FS10013\_S0417\_08400**

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

**Drop Copy Client Connection Attributes**

**#FS10013\_S0417\_08501**

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
| **Column** | **Type** | **Length** | **M/O** | **Default** | **Remarks** |
| Participant ID | Alphanumeric | 5 | - | - | Exchange Participant ID of the Drop Copy Client.  **Records are grouped by Participant ID.** |
| Logged-on | Numeric | 10 | - | - | Number of Logged-on Clients under the Participant ID.  **Summary figure for the Participant ID.** |
| Disconnected | Numeric | 10 | - | - | Number of Disconnected Clients under the Participant ID.  **Summary figure for the Participant ID.** |
| Not Connected | Numeric | 10 | - | - | Number of Not Connected Clients under the Participant ID.  **Summary figure for the Participant ID.** |
| ID | Alphanumeric | 50 | - | - | ID of the connection status record. |
| Instance ID | Alphanumeric | 12 | - | - | The combination of:  [Application ID]:[Instance ID]  It is the unique identifier of an application instance. |
| Component | Alphanumeric | 9 | - | - | Component name. Domain values: OFG, DCG, DCC, GCM, LS |
| Partition | Numeric | 3 | - | - | Partition number. |
| Subgroup | Char | 1 | - | - | Subgroup ID. Optional. |
| Last Updated Time | Date and Time | 20 | - | - | Last updated time. |
| Comp ID | Alphanumeric | 10 | - | - | Sender Comp ID. |
| Client Status | Numeric | 3 | - | - | Ref: [Common Attributes](#_Common_Attributes) - Client Status |
| Protocol Type | Char | 1 | - | - | Ref: [Common Attributes](#_Common_Attributes) - Interface Protocol |
| Connection Status | Numeric | 3 | - | - | Ref: [Common Attributes](#_Common_Attributes) - Connection Status |
| Connection IP | Numeric | 10 | - | - | INET address of IP address of client connection. |
| Connection Port | Numeric | 5 | - | - | Client connection port number |
| Connection Duration | Time | 8 | - | - | Client connection duration in seconds. |
| Last State Change Time | Date and Time | 20 | - | - | Last change time of client connection state. |
| Logged-on Attempts | Numeric | 10 | - | - | Total number of logon attempts including success and failure. |
| Successful Logons | Numeric | 10 | - | - | Total number of successfully logons. |
| Current Output Rate | Numeric | 10 | - | - | Current output message rate to client. |
| Peak Output Rate | Numeric | 10 | - | - | Peak output message rate to client. |
| Client Total Input | Numeric | 10 | - | - | Total number of input messages from client. |
| Last Received MSN | Numeric | 10 | - | - | Last received MSN from the client. |
| Next Expected MSN | Numeric | 10 | - | - | Next expected MSN from the client. |
| Last Sent MSN | Numeric | 10 | - | - | Last sent MSN to the client |
| Client Total Output | Numeric | 10 | - | - | Total number of output messages to client. |
| Total Session Rejects | Numeric | 10 | - | - | Total number of Session Rejects to client |
| Total BMR | Numeric | 10 | - | - | Total number of BMR to client |
| New ER | Numeric | 10 | - | - | Total number of New ERs. |
| Cancelled ER | Numeric | 10 | - | - | Total number of Cancelled ERs. |
| Amended ER | Numeric | 10 | - | - | Total number of Amended ERs. |
| Expired ER | Numeric | 10 | - | - | Total number of Expired ERs |
| Trade ER | Numeric | 10 | - | - | Total number of Trade ERs. |
| Trade Cancelled ER | Numeric | 10 | - | - | Total number of Trade Cancelled ERs. |
| TCR New | Numeric | 10 | - | - | Total number of TCR New Orders from clients. |
| TCR Cancel | Numeric | 10 | - | - | Total number of TCR Cancel Orders from clients. |
| Instant Latency | Numeric | 10 | - | - | Instant average internal latency from receiving to the point where the message has just been sent to client. |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0417\_08600**

**Actions**

**#FS10013\_S0417\_08700**

| Action | Description |
| --- | --- |
| Screen Open | Trigger a query to display all records |
| Apply | Trigger a query of records based on input filters |
| Reset Filters | Reset all filters to default: All |
| Export as CSV | Export all Records from GUI current page table to CSV file.  (Based on the filtering criteria) |
| Export all Participants as CSV | Export all Records in Participant level to CSV file. (All the filtering criteria will be ignored.) |
| Export all Comp ID as CSV | Export all Records in Comp ID level to CSV file. (All the filtering criteria will be ignored.) |
| Reset Client MSN | Reset client message sequence number (MSN) of the selected client to 1. (Only one client can be selected at a time) |
| Manually logoff client | Manually logoff the selected client.  (Only one client can be selected at a time) |
| Disconnect client | Disconnect the selected client.  (Only one client can be selected at a time) |

**Validation**

**#FS10013\_S0417\_08800**

| Event | Validation Rule | Validation Message |
| --- | --- | --- |
|  |  |  |

### Control & Monitor Trading GUI Client

**#FS10013\_S0417\_08900**

**Description**

**#FS10013\_S0417\_09001**

This function is used to monitor the connection status of Trading GUI clients. This is a real-time monitoring function. Connection statistics published by Trading GUI will be updated on the screen automatically.

In the window, it shows the connection status of a list of Trading GUI Users. The table is in Tree structure with records are grouped by Participant ID, and it’s collapsed by default. Once a connection is selected, it will be able to submit the following Control Request to this target User.

* Manually logoff client
* Disconnect client
* Reset Kill Switch

It follows Maker/Checker mechanism to submit control requests. After the Maker submits the request, the Approver needs to enter Approve Request function to approve the request.

**UI Layout**

**#FS10013\_S0417\_09100**

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

**Attributes**

**#FS10013\_S0417\_09201**

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
| **Column** | **Type** | **Length** | **M/O** | **Default** | **Remarks** |
| Participant ID | Alphanumeric | 5 | - | - | Exchange Participant ID of the Trading GUI User.  **Records are grouped by Participant ID.** |
| Logged-on | Numeric | 10 | - | - | Number of Logged-on Users under the Participant ID.  **Summary figure for the Participant ID.** |
| Disconnected | Numeric | 10 | - | - | Number of Disconnected Users under the Participant ID.  **Summary figure for the Participant ID.** |
| Not Connected | Numeric | 10 | - | - | Number of Not Connected Users under the Participant ID.  **Summary figure for the Participant ID.** |
| User ID | Alphanumeric | 10 | - | - | Trading GUI User ID  IDP User ID? |
| Comp ID | Alphanumeric | 10 | - | - | Comp ID of the User. |
| Client Status | Numeric | 3 | - | - | Ref: [Common Attributes](#_Common_Attributes) - Client Status |
| Connection Status | Numeric | 3 | - | - | Ref: [Common Attributes](#_Common_Attributes) - Connection Status |
| Connection IP | Numeric | 10 | - | - | INET address of IP address of client connection. |
| Last State Change Time | Date and Time | 20 | - | - | Last change time of client connection state. |
| Logged-on Attempts | Numeric | 10 | - | - | Total number of logon attempts including success and failure. |
| Successful Logons | Numeric | 10 | - | - | Total number of successful logons. |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0417\_09300**

**Actions**

**#FS10013\_S0417\_09400**

| Action | Description |
| --- | --- |
| Screen Open | Trigger a query to display all records |
| Apply | Trigger a query of records based on input filters |
| Reset Filters | Reset all filters to default: All |
| Export as CSV | Export all Records from GUI current page table to CSV file.  (Based on the filtering criteria) |
| Export all Participants as CSV | Export all Records in Participant level to CSV file. (All the filtering criteria will be ignored.) |
| Export all Users as CSV | Export all Records in User level to CSV file. (All the filtering criteria will be ignored.) |
| Manually logoff client | Manually logoff the selected client.  (Only one client can be selected at a time) |
| Disconnect client | Disconnect the selected client.  (Only one client can be selected at a time) |

**Validation**

**#FS10013\_S0417\_09500**

| Event | Validation Rule | Validation Message |
| --- | --- | --- |
|  |  |  |

### Control & Monitor PTRM GUI Client

**#FS10013\_S0417\_09600**

**Description**

**#FS10013\_S0417\_09700**

This function is used to monitor the connection status of PTRM GUI clients. This is a real-time monitoring function. Connection statistics published by PTRM GUI will be updated on the screen automatically.

In the window, it shows the connection status of a list of PTRM GUI Users. The table is in Tree structure with records are grouped by Participant ID, and it’s collapsed by default. Once a connection is selected, it will be able to submit the following Control Request to this target User.

* Manually logoff client
* Disconnect client

It follows Maker/Checker mechanism to submit control requests. After the Maker submits the request, the Approver needs to enter Approve Request function to approve the request.

**UI Layout**

**#FS10013\_S0417\_09800**

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

**Attributes**

**#FS10013\_S0417\_09901**

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
| **Column** | **Type** | **Length** | **M/O** | **Default** | **Remarks** |
| Participant ID | Alphanumeric | 5 | - | - | Exchange Participant ID of the Trading GUI User.  **Records are grouped by Participant ID.** |
| Logged-on | Numeric | 10 | - | - | Number of Logged-on Users under the Participant ID.  **Summary figure for the Participant ID.** |
| Disconnected | Numeric | 10 | - | - | Number of Disconnected Users under the Participant ID.  **Summary figure for the Participant ID.** |
| Not Connected | Numeric | 10 | - | - | Number of Not Connected Users under the Participant ID.  **Summary figure for the Participant ID.** |
| User ID | Alphanumeric | 10 | - | - | Trading GUI User ID  IDP User ID? |
| Comp ID | Alphanumeric | 10 | - | - | Comp ID of the User. |
| Client Status | Numeric | 3 | - | - | Ref: [Common Attributes](#_Common_Attributes) - Client Status |
| Connection Status | Numeric | 3 | - | - | Ref: [Common Attributes](#_Common_Attributes) - Connection Status |
| Connection IP | Numeric | 10 | - | - | INET address of IP address of client connection. |
| Last State Change Time | Date and Time | 14 | - | - | Last change time of client connection state. |
| Logged-on Attempts | Numeric | 10 | - | - | Total number of logon attempts including success and failure. |
| Successful Logons | Numeric | 10 | - | - | Total number of successful logons. |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0417\_10000**

**Actions**

**#FS10013\_S0417\_10100**

| Action | Description |
| --- | --- |
| Screen Open | Trigger a query to display all records |
| Apply | Trigger a query of records based on input filters |
| Reset Filters | Reset all filters to default: All |
| Export as CSV | Export all Records from GUI current page table to CSV file.  (Based on the filtering criteria) |
| Export all Participants as CSV | Export all Records in Participant level to CSV file. (All the filtering criteria will be ignored.) |
| Export all Users as CSV | Export all Records in User level to CSV file. (All the filtering criteria will be ignored.) |
| Manually logoff client | Manually logoff the selected client.  (Only one client can be selected at a time) |
| Disconnect client | Disconnect the selected client.  (Only one client can be selected at a time) |

**Validation**

**#FS10013\_S0417\_10200**

| Event | Validation Rule | Validation Message |
| --- | --- | --- |
|  |  |  |

### Control Settlement Values

**#FS10013\_S0417\_10300**

**Description**

**#FS10013\_S0417\_10400**

**Control Settlement Values** is used to manually override settlement values.

**UI Layout**

**#FS10013\_S0417\_10504**

![](data:image/png;base64...)

**Attributes**

**#FS10013\_S0417\_10605**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Instrument ID | - | - | - | - | Read-only field.  The ID of the Instrument |
| Daily Settlement Price | Decimal | 18 | O | - | Daily Settlement Price |
| Received DSP | - | - | - | - | Read-only field.  Received DSP |
| Decimal In Received DSP | - | - | - | - | Read-only field.  Decimal In Received DSP |
| DSP Update Type | - | - | - | - | Read-only field.  Ref: [Common Attributes](#_Common_Attributes) - Update Type |
| DSP Update Time | - | - | - | - | Read-only field.  DSP Update Time |
| Previous Daily Settlement Price | Decimal | 18 | O | - | Previous Daily Settlement Price |
| Previous Received DSP | - | - | - | - | Read-only field.  Previous Received DSP |
| Decimal in Previous Received DSP | - | - | - | - | Read-only field.  Decimal in Previous Received DSP |
| Previous DSP Update Type | - | - | - | - | Read-only field.  Ref: [Common Attributes](#_Common_Attributes) - Update Type |
| Previous DSP Update Time | - | - | - | - | Read-only field.  Previous DSP Update Time |
| Previous DSP Trading Date | - | - | - | - | Read-only field.  Previous DSP Trading Date |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0417\_10700**

**Actions**

**#FS10013\_S0417\_10800**

| Action | Description |
| --- | --- |
| Screen Open | Trigger a query to display all records |
| Apply | Trigger a query of records based on input filters |
| Reset Filters | Reset all filters to default: All |
| Confirm | Confirm the change and submit to backend, disabled with Read-only permission and view mode |
| Cancel | Cancel all changes, disabled with Read-only permission and view mode |

**Validation**

**#FS10013\_S0417\_10900**

| Event | Validation Rule | Validation Message |
| --- | --- | --- |
| Update Request | Invalid value input | Invalid Input |

**Notification**

**#FS10013\_S0417\_11000**

| Event | Notification |
| --- | --- |
| Update | Pop up concurrent notification if any concurrent update occurred |

### Control Underlying Price

**#FS10013\_S0417\_11100**

**Description**

**#FS10013\_S0417\_11200**

**Control Underlying Price** is used to manually update the underlying price.

**UI Layout**

**#FS10013\_S0417\_11305**

![](data:image/png;base64...)

**Attributes**

**#FS10013\_S0417\_11405**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Underlying ID | - | - | - | - | Read-only field.  The ID of the Underlying |
| Status | - | - | - | - | Read-only field.  Ref: [Common Attributes](#_Common_Attributes) - Status |
| Last Traded Price | Decimal | 18 | O | - | Last Traded Price |
| Received Last Traded Price | - | - | - | - | Read-only field.  Received Last Traded Price |
| Decimals In Received Last Traded Price | - | - | - | - | Read-only field.  Decimals In Received Last Traded Price |
| Last Traded Price Update Type | - | - | - | - | Read-only field.  Ref: [Common Attributes](#_Common_Attributes) - Update Type |
| Last Traded Price Update Time | - | - | - | - | Read-only field.  Last Traded Price Update Time |
| Settlement Price | Decimal | 18 | O | - | Settlement Price |
| Received Settlement Price | - | - | - | - | Read-only field.  Received Settlement Price |
| Decimals In Received Settlement Price | - | - | - | - | Read-only field.  Decimals In Received Settlement Price |
| Settlement Price Update Type | - | - | - | - | Read-only field.  Ref: [Common Attributes](#_Common_Attributes) - Update Type |
| Settlement Price Update Time | - | - | - | - | Read-only field.  The time that the Settlement Price received |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0417\_11500**

**Actions**

**#FS10013\_S0417\_11600**

| Action | Description |
| --- | --- |
| Screen Open | Trigger a query to display all records |
| Apply | Trigger a query of records based on input filters |
| Reset Filters | Reset all filters to default: All |
| Confirm | Confirm the change and submit to backend, disabled with Read-only permission and view mode |
| Cancel | Cancel all changes, disabled with Read-only permission and view mode |

**Validation**

**#FS10013\_S0417\_11700**

| Event | Validation Rule | Validation Message |
| --- | --- | --- |
| Update Request | Invalid value input | Invalid Input |

**Notification**

**#FS10013\_S0417\_11800**

| Event | Notification |
| --- | --- |
| Update | Pop up concurrent notification if any concurrent update occurred |

## User Maintenance

### Maintain Exchange User

**#FS10013\_S0418\_00102**

**Description**

**#FS10013\_S0418\_00200**

This function is used to create, update and delete an internal HKEX user.

**UI Layout**

**#FS10013\_S0418\_00305**

Search Page

![](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

**Attributes**

**#FS10013\_S0418\_00406**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| **Identity** | | | | | |
| User ID | - | - | - | - | Read-only field.  Generated by system |
| IDP User ID | Alphanumeric  **Text Input** | 32 | M | - | This is the User ID that the user used to logon via IDP.  The same IDP User ID should not assigned to more than one User. |
| **General** | | | | | |
| User Type | Numeric  **Dropdown** | 1 | M | - | Type of the User.  Ref: [Common Attributes](#_Common_Attributes)  - UI User Type |
| Function Type | Numeric  **Dropdown** | 1 | M | - | **Read Only**  Function Type of the User.  Ref: [Common Attributes](#_Common_Attributes)  - Function Type  Must be 1 – Internal. |
| Suspended? | Char  **Dropdown** | 1 | M | N | The User is suspended or not.  Ref: [Common Attributes](#_Common_Attributes)  - Boolean Char |
| Locked? | Char  **Dropdown** | 1 | M | - | The User is locked or not.  Ref: [Common Attributes](#_Common_Attributes)  - Boolean Char  **Change to N to unlock the user.**  **If the original value is ‘N’, this field is not editable** |
| Locked Reason | Char  **Dropdown** | 1 | O | - | **Read-only.** It is the locked reason set by the system. This field will be cleared when ‘Locked?’ Field is N.  Ref: [Common Attributes](#_Common_Attributes)  - Locked Reason |
| Last Logon Date | Date  **Text Input** | 11 | O | - | **Read-only.**  Last Logon Date of the User.  Set by System. |
| Last Logon Source IP | Alphanumeric  **Text Input** | 15 | O | - | **Read-only.**  Last Logon Source IP.  Set by System. |

**UI User Roles Attributes**

**#FS10013\_S0418\_00500**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| App ID | Numeric  **Text Input (with Content Assist)** | 2 | M | - | The ID of the Application. |
| Role Type | Numeric  **Dropdown** | 1 | M | - | Type of the Role.  Ref: [Common Attributes](#_Common_Attributes)  - UI Role Type |
| UI User Role ID | Alphanumeric  **Text Input (With Content Assist)** | 32 | M | - | The ID of UI User Role assigned to the User.  **UI User Role should fulfill the following:**   1. **Role Type** should match with Admin GUI User’s **User Type**. If User Type is Admin, Role Type can be Admin/Non-Admin. If User Type is Non-Admin, then Role Type must be Non-Admin. 2. **Function Type** should match with Admin GUI User. 3. **Interface** is 1 - UI |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0418\_00600**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0418\_00702**

| Action | Description |
| --- | --- |
| Unlock IDP Account | Unlock IDP Account |
| Reset IDP Account | Reset IDP Account |
| Suspend IDP Account | Suspend IDP Account |

**Validation (Ref:** [**Common Validation**](#_Common_Validation)**)**

**#FS10013\_S0418\_00800**

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0418\_00900**

### Maintain UI User Role

**#FS10013\_S0418\_01000**

**Description**

**#FS10013\_S0418\_01100**

This function is used to create, update and delete UI User Roles. UI User Roles can be assigned to Exchange Users / Participant Users, etc.

**UI Layout**

**#FS10013\_S0418\_01202**

Search Page

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

**Attributes**

**#FS10013\_S0418\_01301**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| **Identity** | | | | | |
| UI User Role ID | Alphanumeric  **Text Input** | 32 | M | - | This is a unique ID and is non-editable in edit mode. |
| Description | Alphanumeric  **Text Input** | 40 | O | - | Supplementary description of the UI User Role. |
| **General** | | | | | |
| Role Type | Numeric  **Dropdown** | 1 | M | - | Type of the Role.  Ref: [Common Attributes](#_Common_Attributes)  - UI Role Type |
| App ID | Numeric  **Text Input (with Content Assist)** | 2 | M | - | The ID of the Application. |
| Function Type | Numeric  **Dropdown** | 1 | M | - | Function Type of the Role.  Ref: [Common Attributes](#_Common_Attributes)  - Function Type |
| Interface Type | Alphanumeric  **Dropdown** | 2 | M | 1 | **Read-only**  Interface to be used by the Role.  Ref: [Common Attributes](#_Common_Attributes)  - Function Interface  **Only 01 – UI is available.** |

**Allowed Functions Attributes**

**#FS10013\_S0418\_01400**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Function Name | Alphanumeric  **Text Input (with Content Assist)** | 120 | M | - | This is the Name of the function.  **The function should be aligned with the App ID + Function Type + Interface of the UI User Role.** |
| Action | Char  **Dropdown** | 1 | M | - | Allowed Action for this function.  Ref: [Common Attributes](#_Common_Attributes)  - Action  **When Action is 2, both Write and Read permissions will be assigned.**  **When Action is 9, Approve, Write and Read permissions will be assigned.** |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0418\_01500**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0418\_01600**

| Action | Description |
| --- | --- |
| - | - |

**Validation (Ref:** [**Common Validation**](#_Common_Validation)**)**

**#FS10013\_S0418\_01700**

| Event | Validation Rule | Validation Message |
| --- | --- | --- |
| New/Update Request | Functions in Allowed Functions section should be aligned with the selected **App ID** + **Function Type** + **Interface** of the UI User Role.  And the corresponding permission **(Function ID + Action)** should appear in the Permission Table in DB. | Invalid Allowed Functions |

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0418\_01800**

### Maintain System Preference

**#FS10013\_S0418\_01900**

**Description**

**#FS10013\_S0418\_02000**

This function is used to update the System Preference.

**UI Layout**

**#FS10013\_S0418\_02100**

Search Page

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

Detail Page (Record Status ref: [Current Record and Request Record](#_Toc178859290))![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

**Attributes**

**#FS10013\_S0418\_02202**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| **General** | | | | | |
| Group ID | Numeric | 5 | M | - | The unique ID of System Preference Group.  **Read-only** |
| App ID | Numeric | 2 | M | - | The ID of the App that the System Preference Group belongs to.  **Read-only** |
| Name | Alphanumeric | 12 | M | - | Name of the System Preference Group.  **Read-only** |
| Description | Alphanumeric | 32 | O | - | Description of the System Preference Group.  **Read-only** |
| **Preferences** | | | | | |
| Preference ID | Numeric | 5 | M | - | The unique ID of System Preference.  **Read-only** |
| Name | Alphanumeric | 12 | M | - | Name of the System Preference.  **Read-only** |
| Description | Alphanumeric | 40 | O | - | Description of the System Preference.  **Read-only** |
| Allow Multiple Value? | Boolean | 1 | M | - | Allow multiple value.  **Read-only** |
| Preference Value | Alphanumeric  **Text Input** | 1024 | M | - | Value of the System Preference.  **If Allow Multiple Value is Yes, user can input multiple values by using a ‘|’ separated text.** |

**Available System Preference:**

**#FS10013\_S0418\_02302**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| **Trading GUI** | | | | | |
| (Internal) Order Depth Table auto refresh rate | Numeric  **Text Input** | TBC | M | 30 | Order Depth Table auto refresh rate for Internal User in seconds. |
| **PTRM GUI** | | | | | |
| TBC | TBC | TBC | TBC | TBC | TBC |
| **Admin GUI** | | | | | |
| TBC | TBC | TBC | TBC | TBC | TBC |
| **User Maintenance** | | | | | |
| TBC | TBC | TBC | TBC | TBC | TBC |
| **Participant** | | | | | |
| TBC | TBC | TBC | TBC | TBC | TBC |
| **Instrument Hierarchy** | | | | | |
| TBC | TBC | TBC | TBC | TBC | TBC |
| **Combo Hierarchy** | | | | | |
| TBC | TBC | TBC | TBC | TBC | TBC |
| **Trading Time Table** | | | | | |
| TBC | TBC | TBC | TBC | TBC | TBC |
| **Instrument Generation** | | | | | |
| Instrument Generation Preset Number 1 – 10 | Alphanumeric  **Text Input** | 1024 | O | - | Define the Preset for Instrument Generation page.  This is the format of the preset:  <Name of the preset>|<fieldId>:<value>  For example,  “All Futures|instTypeId:HSIF,MHIF”  It will create a preset called “All Futures” and it will fill HSIF,MHIF to Instrument Type field.  Available field ID are marketId, instTypeId, instClassId |
| **Combo Generation** | | | | | |
| Combo Generation Preset Number 1 – 10 | Alphanumeric  **Text Input** | 1024 | O | - | Define the Preset for Combo Generation page.  This is the format of the preset:  <Name of the preset>|<fieldId>:<value>  For example,  “All Futures|instTypeId:HSIF,MHIF”  It will create a preset called “All Futures” and it will fill HSIF,MHIF to Instrument Type field.  Available field ID are marketId, instTypeId, instClassId, autoComboGenRuleGroupId |
| **SMP** | | | | | |
| ~~New SMP ID Format~~ | ~~Char~~ | ~~1~~ | ~~M~~ | ~~-~~ | ~~Format of the newly created SMP ID:~~   1. ~~1 - Alphanumeric Characters with size 5~~ 2. ~~2 – Numeric Digits with size 9~~ |
| SMP Maintenance Request Approval Period | Numeric | 3 | M | - | SMP Maintenance Request will be expired if it’s not approved/rejected at or after the last day of this Period. |
| Counterparty Request Period | Numeric | 3 | M | - | For SMP ID Sharing request, the request will be expired if the counterparty didn’t submit the Request at or after the last day of this Period. |
| Deleted SMP ID retention period | Numeric | 3 | M | - | A logically deleted SMP ID will be physically deleted at or after the last date of this period.  **Valid Value:**  **0 - 30** |
| **TMC Strategy** | | | | | |
| TBC | TBC | TBC | TBC | TBC | TBC |
| **Price Supervision** | | | | | |
| TBC | TBC | TBC | TBC | TBC | TBC |
| **Market Message** | | | | | |
| TBC | TBC | TBC | TBC | TBC | TBC |
| **Capital Adjustment** | | | | | |
| TBC | TBC | TBC | TBC | TBC | TBC |
| **System Parameter** | | | | | |
| TBC | TBC | TBC | TBC | TBC | TBC |
| **Market Maker Protection** | | | | | |
| TBC | TBC | TBC | TBC | TBC | TBC |
| **Block Trade** | | | | | |
| TBC | TBC | TBC | TBC | TBC | TBC |
| **Control and Monitoring** | | | | | |
| TBC | TBC | TBC | TBC | TBC | TBC |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0418\_02400**

**Actions**

**#FS10013\_S0418\_02501**

| Action | Description |
| --- | --- |
| Screen Open | Trigger a query to display all records |
| Apply | Trigger a query of records based on input filters |
| Reset Filters | Reset all filters to default: All |
| Update Record | Update Tomorrow Change: update record for Tomorrow |
| Withdraw Selected | Withdraw selected record which Records Status is Active and without Pending withdraw request |
| Export | Export all Records from GUI current page table to CSV file |
| Confirm | Confirm the change and submit to backend, disabled with Read-only permission and view mode |
| Cancel | Cancel all changes, disabled with Read-only permission and view mode |

**Validation**

**#FS10013\_S0418\_02600**

| Event | Validation Rule | Validation Message |
| --- | --- | --- |
| Update Request | Unique identifier cannot be updated | Unique identifier cannot be updated |
| Any mandatory field is empty | Invalid Input |
| Invalid value input | Invalid Input |
| ‘|’ is included in Non-Multiple Value Parameter | Multiple value is not allowed. |

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0418\_02700**

### Request Internal IDP User

**#FS10013\_S0418\_02802**

**Description**

**#FS10013\_S0418\_02902**

**Request Internal IDP User** is used to create/update Internal IDP user.

**UI Layout**

**#FS10013\_S0418\_03003**

![](data:image/png;base64...)

**Attributes**

**#FS10013\_S0418\_03106**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| IDP User ID | - | - | - | - | Read-only field.  IDP User ID = Company ID + "\_" + Username  Allowed IDP characters: A-Z0-9, full stop (.), underscore (\_) and hyphen (-) |
| Company ID | Numeric | 8 | M | <Company ID of HKEX> | Read-only field.  The ID of the Company  Company name need to be “HKEX” |
| Username | Alphanumeric | 23 | M | - | Username  Allowed IDP characters: A-Z0-9, full stop (.), underscore (\_) and hyphen (-) |
| Given Name | Alphanumeric | 32 | M | - | Given Name |
| Family Name | Alphanumeric | 32 | M | - | Family Name |
| Email | Alphanumeric | 255 | M | - | A valid email address format (local-part@domain)  local-part allow a-z, 0-9, full stop (.), underscore (\_) and hyphen (-).  domain allow a-z, 0-9, full stop (.), hyphen (-). Hyphen is allowed if it is not the first or last character. |
| Phone Number | Alphanumeric | 16 | M | - | Phone Number  e.g.: +852-22222222 |
| User Type | Alphanumeric | 16 | M | USER | Read-only field.  Ref: [Common Attributes](#_Common_Attributes) - IDP User Type  Must be USER |
| Internal | Char | 1 | M | Y | Read-only field.  Ref: [Common Attributes](#_Common_Attributes) - Boolean Char  Must be “Y - Yes” |
| Admin | Char | 1 | M | N | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
| Effective Start Day | Date | 11 | M | - | Effective Start Day |
| OTP Delivery Method | Numeric | 1 | M | 2 | Read-only field.  Ref: [Common Attributes](#_Common_Attributes) - OTP Delivery Method |

**Permission Behaviour (Ref:** [**Common Permission Behaviour**](#_Common_Permission_Behaviour)**)**

**#FS10013\_S0418\_03200**

**Actions (Ref:** [**Common Actions**](#_Common_Actions)**)**

**#FS10013\_S0418\_03300**

| Action | Description |
| --- | --- |
| - | - |

**Validation (Ref:** [**Common Validation**](#_Common_Validation), [**Validation Rule**](#_Validation_Rule_(TBC))**)**

**#FS10013\_S0418\_03400**

**Notification (Ref:** [**Common Notification**](#_Common_Notification)**)**

**#FS10013\_S0418\_03500**

# Appendix

## Irrelevant BRD Items

**#FS10013\_S0501\_00100**

The following items are no longer exist

# BRD\_DT\_0050\_030\_03400 Corporate Action Code

Add a new item and change all fields.

The following items is describing ME / Trading GUI result instead of Admin GUI

# BRD\_DT\_0050\_030\_23900 If an order breaks the applicable price limit (it depends on if it is dynamic or effective price limit applied for the trading state), the order will be rejected.

The following item should be covered by trading GUI market message screen

# BRD\_DT\_0050\_030\_21800 On the other hand, the GUI could be able to receive / store all the messages from the market.

The following will not happen in the latest admin mechanism

# BRD\_DT\_0050\_030\_14600 If there is no conflict, the CDB will accept the update. Else, this update will be prompted to be cancel the overwrite or prompt to confirm the overwrite

# BRD\_DT\_0050\_030\_14700 There should be a function to determine shall the CDB prompt out a message asking the user to confirm the overwrite or CDB reject the overwrite directly.

# BRD\_DT\_0050\_030\_14800 The function is turn on or turn off by configuring “CDB\_PREVENT\_OVERWRITE” (for example) [To be discuss between user and IT on the best practise to manage the multiple update simultaneously]

The following are covered by Maintain GUI User screen in other way

# BRD\_DT\_0050\_030\_13600 User

# BRD\_DT\_0050\_030\_13700 Add a new User.

# BRD\_DT\_0050\_030\_13800 Change the Status and Subscription status fields.

# BRD\_DT\_0050\_030\_13900 Unlock, Reinstate or set a new password for a User.

# BRD\_DT\_0050\_030\_14000 Change all fields belonging to the Additional user details functionality.

The following items could be covered by Auto Generation in other way

# BRD\_DT\_0050\_030\_11500 Series Rules

Add a new item and change all fields.

# BRD\_DT\_0050\_030\_12500 Spread Rules

Add a new item and change all fields.

The following items should be covered by DMR and reporting FS in other way

# BRD\_DT\_0050\_030\_10700 Report

Add a new item and change all fields.

# BRD\_DT\_0050\_030\_10800 Report Generation Time

Add a new item and change all fields.

# BRD\_DT\_0050\_030\_10900 Report Group

Add a new item and change all fields.

# BRD\_DT\_0050\_030\_11000 Report Template

Add a new item and change all fields.

# BRD\_DT\_0050\_030\_11100 Report Template Update

Update Report Templates.

# BRD\_DT\_0050\_030\_07600 Legal Transaction Time

Add transactions to an existing Legal Transaction Time

# BRD\_DT\_0050\_030\_07700 Legal Session State

Add session states to an existing Legal Session State

# BRD\_DT\_0050\_030\_06800 Add transactions to an already connected Legal transaction time.

# BRD\_DT\_0050\_030\_06900 Connect a new or change an already connected Automatic quote request.

# BRD\_DT\_0050\_030\_05900 Change the Traded in Genium INET Trading field to yes.

# BRD\_DT\_0050\_030\_06000 Change the Traded in Genium INET Trading field to no ONLY if the Instrument series has ever been traded.

# BRD\_DT\_0050\_030\_06100 Change the Effective expiration date if the current date and the new date is not passed in time.

# BRD\_DT\_0050\_030\_06200 If changing the effective expiration date to current business date, the process RI\_DPMON must be restarted.

# BRD\_DT\_0050\_030\_06500 Add or remove Corporate Action codes.

The follow items need to discuss with DT further, these are not relevant to GUI Admin but relevant to other backend requirement.

# BRD\_DT\_0050\_030\_04900 Change parameters concerning the generation of series. That is connect a new or change an already connected Expiration date formula, Strike price step, Cycle class, Cycle class month, Series name standard or Series rules.

# BRD\_DT\_0050\_030\_05000 Change the Traded in Genium INET Trading.

# BRD\_DT\_0050\_030\_05100 Add or remove Corporate Action codes.

# BRD\_DT\_0050\_030\_05200 Connect or change to an existing Order attribute.

# BRD\_DT\_0050\_030\_05300 Connect a new or change an already connected Automatic quote request.

# BRD\_DT\_0050\_030\_05400 Change all fields belonging to the Trade report functionality. Trade report class can only be changed to another existing Trade report class.

• # BRD\_DT\_0050\_030\_01400 Access Group By Class

- Add a new item and change all fields.

• # BRD\_DT\_0050\_030\_01600 Account Fee Type

- Add a new item and change all fields.

• # BRD\_DT\_0050\_030\_13500 Underlying Issuer

Add a new item.

# BRD\_DT\_0050\_030\_17600 Bank Identifier Code

-# BRD\_DT\_0050\_030\_08900 Change Internal Crossing.

-# BRD\_DT\_0050\_030\_08500 Connect new or change already connected Address and contact.

-# BRD\_DT\_0050\_030\_08600 Connect new or change already connected Bank, Custodian bank and Custody service.

• # BRD\_DT\_0050\_030\_01700 Account Type

- Add a new item and change all fields.

• # BRD\_DT\_0050\_030\_01800 Account Type Rule

- Add a new item and change all fields.

• # BRD\_DT\_0050\_030\_01900 Address And Contact

-Add a new item and change all fields.

• # BRD\_DT\_0050\_030\_02100 Automatic Quote Request

Add a new item and change all fields.

• # BRD\_DT\_0050\_030\_02400 Central Group

Add a new item and change all fields.

• # BRD\_DT\_0050\_030\_02500 Change Last Trading

Change last trading is supported intraday.

• # BRD\_DT\_0050\_030\_02600 Clearance System

Add a new item and change all fields.

• # BRD\_DT\_0050\_030\_02800 Connect a new or change an already connected Combo rules.

• # BRD\_DT\_0050\_030\_03100 Change the Last trading date and the Last trading time.

• # BRD\_DT\_0050\_030\_03200 Change the First trading date and the First trading time.

• # BRD\_DT\_0050\_030\_03500 Create New Series Report

Create new series report is supported intraday.

• # BRD\_DT\_0050\_030\_03600 Curve

Add a new item and change all fields.

• # BRD\_DT\_0050\_030\_03900 Days Restriction

Add a new item and change all fields.

• # BRD\_DT\_0050\_030\_04100 External Fee Type

Add a new item and change all fields.

• # BRD\_DT\_0050\_030\_04200 Fee Table

Add a new item and change all fields.

• # BRD\_DT\_0050\_030\_04300 Fee Volume Level

Add a new item and change all fields.

• # BRD\_DT\_0050\_030\_04400 Gateway Node

Add a new Gateway node.

• # BRD\_DT\_0050\_030\_04500 Gateway Type

Add a new Gateway type.

• # BRD\_DT\_0050\_030\_04600 Illegal Underlying

Add a new item.

# BRD\_DT\_0050\_030\_26800 The response time for searching same day record should be reasonably fast.

# BRD\_DT\_0050\_030\_26900 The response time for searching records older than 1 business days should follow another SLA level.

# BRD\_DT\_0050\_030\_21100 Tunnel server surveillance

# BRD\_DT\_0050\_030\_25500 In the tunnel server surveillance window, it shows the number of subscribers connected to the tunnel server.

• # BRD\_DT\_0050\_030\_07000 Issue

-# BRD\_DT\_0050\_030\_07100 Create a new issue.

-# BRD\_DT\_0050\_030\_07200 Modify the issue before the calculation is done in Genium INET Clearing.

• # BRD\_DT\_0050\_030\_07300 Legal Account Instrument

Add a new item and change all fields.

• # BRD\_DT\_0050\_030\_07900 Menu Access Type

Add menus to a Menu access type.

• # BRD\_DT\_0050\_030\_08000 OMnet Node

Add a new OMnet node.

• # BRD\_DT\_0050\_030\_08100 Organization

Add a new item and change all fields.

• # BRD\_DT\_0050\_030\_09000 Periodic Dates

Add a new item and change all fields.

• # BRD\_DT\_0050\_030\_09100 Pre Trade Limits Group

-# BRD\_DT\_0050\_030\_09200 Change the Order rate limit.

-# BRD\_DT\_0050\_030\_09300 Change the Execution throttle period(sec).

-# BRD\_DT\_0050\_030\_09400 Change the Gross futures per time.

-# BRD\_DT\_0050\_030\_09500 Change the Gross options per time.

-# BRD\_DT\_0050\_030\_09600 Change the Warning breach level.

-# BRD\_DT\_0050\_030\_09700 Change the Notification breach level.

-# BRD\_DT\_0050\_030\_09800 Change the Warning breach level per throttle period.

-# BRD\_DT\_0050\_030\_09900 Change the Notification breach level per throttle period.

-# BRD\_DT\_0050\_030\_10000 Change the Warning breach level intraday exposure.

-# BRD\_DT\_0050\_030\_10100 Change the Notification breach level intraday exposure.

-# BRD\_DT\_0050\_030\_10200Change the limits in the Max Risk Value header.

• # BRD\_DT\_0050\_030\_10300 Pre Trade Limits Notification

Add a new email address.

• # BRD\_DT\_0050\_030\_10400 Price Parameters

Add a new item and change all fields.

• # BRD\_DT\_0050\_030\_10500Product Event Type

Add a new item and change all fields.

• # BRD\_DT\_0050\_030\_10600 Product Fee Type

Add a new item and change all fields.

• # BRD\_DT\_0050\_030\_11200 Reserve Fund

Add a new item and change all fields.

• # BRD\_DT\_0050\_030\_11300 Restriction

Add a new item and change all fields.

• # BRD\_DT\_0050\_030\_11600 Series Signal Ready

Series signal ready is supported intraday.

• # BRD\_DT\_0050\_030\_12700 Subscription Type

Add broadcasts to a Subscription type.

• # BRD\_DT\_0050\_030\_12800 Suspend Resume Participant

Suspend and resume is supported intraday.

• # BRD\_DT\_0050\_030\_12900 Suspend Resume Series

Suspend and resume is supported intraday.

• # BRD\_DT\_0050\_030\_13000 Suspend Resume Trading

Suspend and resume is supported intraday.

• # BRD\_DT\_0050\_030\_13100 Trade Report

Change all fields belonging to the RULES functionality.

• # BRD\_DT\_0050\_030\_14100 User Type

-# BRD\_DT\_0050\_030\_14200 Add transactions to a User type.

-# BRD\_DT\_0050\_030\_14300 Change all fields belonging to the Password functionality.

• # BRD\_DT\_0050\_030\_21400 Prevent inactivation

# BRD\_DT\_0050\_030\_26000 The Prevent Inactivation allows user to set or remove the prevent inactivation status for selected customers or selected user.

# BRD\_DT\_0050\_030\_26100 In the listed prevented window, it shows the user who are under prevention.

# BRD\_DT\_0050\_030\_24800 In terms of modification, there are some rules for user to choose from for the settlement value calculation, though user can insert a value directly as well.

• # BRD\_DT\_0050\_030\_20700 Settlement Values

## Security Requirement

**#FS10013\_S0502\_00100**

Follow corporate IT standards please

## Housekeeping at Migration

**#FS10013\_S0503\_00100**

TBD

## Maxima Limit

**#FS10013\_S0504\_00110**

| Column | Initial Technical Limit |
| --- | --- |
| Num of Instrument | 600,000 |
| Num of Combo | 10,000 |
| Num of Leg per Combo | 4 |
| Num of TMC | 10,000 |
| Num of TMC per EP | 10,000 |
| Num of Underlying | 5,000 |
| Num of Exchange | 10 |
| Num of Market | 500 |
| Num of Instrument Group | 500 |
| Num of Instrument Type | 2,000 |
| Num of Instrument Class | 10,000 |
| Num of Combo Group | 500 |
| Num of Combo Type | 2,000 |
| Num of Combo Class | 10,000 |
| Num of Access Group By Type | 1,000 |
| Num of Company | 5,000 |
| Num of Participant per Company | 2,000 |
| Num of Exchange Participant | 10,000 |
| Num of Participant Trading Rights per EP | 500 |
| Num of Sponsoring Participant | 10,000 |
| Num of Sponsored Participant per Sponsoring Participant | 500 |
| Num of Order Flow Session | 20,000 |
| Num of Trading GUI User | 5,000 |
| Num of Drop Copy Session | 10,000 |
| Num of Drop Copy Group per Drop Copy Session | 16 |
| Num of PTRM Session | 2,000 |
| Num of PTRM GUI User | 2,000 |
| Num of Trader ID | 20,000 |
| Num of Trader ID per EP | 1,000 |
| Num of Trader ID per Order Flow Session | 1 |
| Num of TPS per Order Flow Session | 100 |
| Num of Quote Entries in Mass Quote | 15 |
| Num of Quote Entries Per Comp ID per Instrument | 250 |
| Num of Leg in Block Trade | 8 |
| Num of Trading Rights | 5,000 |
| Num of Row per Trading Rights | 500 |
| Num of SMP ID | 50,000 |
| Num of SMP ID per EP | 600 |
| Num of Exchange Participant to Share a SMP ID | 3,000 |
| Num of User Role | 100 |
| Num of Drop Copy Group | 5,000 |
| Num of Drop Copy Group per EP | 100 |
| Num of Trader ID per Drop Copy Group | 500 |
| Num of Entitled Product Type per Drop Copy Session | 16 |
| Num of Risk Group | 6,000 |
| Num of Risk Group per Sponsored Participant | 100 |
| Num of Trader ID per Risk Group | 500 |
| Num of Notification ID per Risk Group | 10 |
| Num of Tradable | 600,000 |
| Num of Tradable per Risk Group | 1,000 |
| Num of TPS per PTRM Session | 10 |
| Num of IP Address per IP Address List | 5,000 |
| Num of Non-Trading Days | 99 |
| Num of Item per Non-Trading Days | 999 |
| Num of Special Trading Days | 99 |
| Num of Item per Special Trading Days | 999 |
| Num of Trading Timetable | 999 |
| Num of Trading State per Timetable | 20 |
| Num of Trading State | 99 |
| Num of Price Tick | 999 |
| Num of Band per Price Tick | 16 |
| Num of Price Tick Limit | 999 |
| Num of Block Trade Group | 99 |
| Num of Price Limit | 99 |
| Num of Price Limit Parameters per Price Limit | 16 |
| Num of Price Limit Parameters | 99 |
| Num of Row per Price Limit Rule | 16 |
| Num of Halt Target List | 99 |
| Num of Instrument Class per Halt Target List | 16 |
| Num of Reference Price Source | 99 |
| Num of VCM | 99 |
| Num of VCM Parameters per VCM | 16 |
| Num of VCM Parameters | 99 |
| Num of Futures Group | 99 |
| Num of Reference Price Calculation Rule | 99 |
| Num of Block Trade MVT | 999 |
| Num of Band per Block Trade MVT | 16 |
| Max Order Quantity | 999,999,999 |
| Max Block Trade Quantity | 999,999,999 |
| Max Price | 999,999,999,999,999,999 |
| Max Price Decimals | 18 |
| Min Price | -999,999,999,999,999,999 |
| Min Pirce Decimals | 0 |
| Decimals in Percentage | 4 |
| Max Orders Per Price Q in PREOPEN | 100,000 |
| Max Orders Per Price Q in OPEN | 100,000 |
| Instrument Retention Period (Days) | 365 |
| Max Trading Hours | 23 |
| Max Inactive Order Per User | 2,000 |
| Num of Cycle Block per Cycle Blocks | 10 |
| Num of Block Item per Cycle Block | 36 |
| Num Rule per Last Trading Date Formula | 20 |
| Num of Auto Combo Generation Rule Group | 5,000 |
| Num of Rule per Auto Combo Generation Rule Group | 20 |

## Validation Rule

**#FS10013\_S0505\_00109**

![](data:image/x-emf;base64...)

## Short Name Full Name Mapping

**#FS10013\_S0506\_00101**

| Short Name | Full Name |
| --- | --- |
| Inst. | Instrument |
| Param | Parameter/Parameters |
| Part. | Participant |

## Template

**#FS10013\_S0507\_00100**

| Template Name | Template |
| --- | --- |
| Import Timetable | ![](data:image/x-emf;base64...) |
