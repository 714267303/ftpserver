TITLE:

**FUNCTIONAL SPECIFICATION**

***ODP-T

FS10014a – ODP Online Trading GUI***

AUTHOR : *IT/Markets Systems*  DATE : *24 Mar 2025*

LAST REVIEW Derivatives Trading Business Operations DATE : *28 Feb 2025*

**CONTENTS**

[1. Document Control 4](#_Toc224133960)

[1.1. Change History 4](#_Toc224133961)

[Trade History Aggregated Filter update - FS10014a\_S0610\_01702 4](#_Toc224133962)

[1.2. Document Cross-referenced 6](#_Toc224133963)

[1.3. Abbreviation 6](#_Toc224133964)

[2. Introduction 8](#_Toc224133965)

[3. Trading GUI Application 8](#_Toc224133966)

[3.1. Technology 8](#_Toc224133967)

[3.2. UI/UX 8](#_Toc224133968)

[3.2.1. UX Principal 8](#_Toc224133969)

[3.2.2. Principles of accessibility 9](#_Toc224133970)

[3.3. Trading UI User Journey 10](#_Toc224133971)

[3.3.1. Convenience and accessibility 10](#_Toc224133972)

[3.3.2. Visual Design 11](#_Toc224133973)

[3.3.3. Web font 11](#_Toc224133974)

[3.3.4. Navigation 11](#_Toc224133975)

[3.3.5. Add-on Workspace 12](#_Toc224133976)

[3.3.6. Real-time streaming 13](#_Toc224133977)

[3.4. Data Type 13](#_Toc224133978)

[3.4.1. UI Widget Mapping by Data Type 15](#_Toc224133979)

[3.5. Application Layout 16](#_Toc224133980)

[3.6. Multiple Language Support 17](#_Toc224133981)

[3.7. System Time and Client Local Time 17](#_Toc224133982)

[3.8. System workspace 18](#_Toc224133983)

[3.9. User Layout 18](#_Toc224133984)

[3.10. Data Search Screen 19](#_Toc224133985)

[3.11. Detail Screen 20](#_Toc224133986)

[3.12. User Input Screen 21](#_Toc224133987)

[3.13. User Setting 22](#_Toc224133988)

[3.13.1. Colour, Style and Font Setting 23](#_Toc224133989)

[3.14. Content Assistant 23](#_Toc224133990)

[3.15. GUI Notification 24](#_Toc224133991)

[3.16. Countersign Acknowledgement 25](#_Toc224133992)

[3.17. Landing Page 35](#_Toc224133993)

[3.18. Login Screen Flow 36](#_Toc224133994)

[3.19. Linked Screen Behaviour 36](#_Toc224133995)

[3.20. Hardware requirements 37](#_Toc224133996)

[4. User Session 37](#_Toc224133997)

[4.1. Session Refresh 38](#_Toc224133998)

[4.2. Inactive User Session 38](#_Toc224133999)

[4.3. Force Logout 38](#_Toc224134000)

[4.4. Invalid User Session 38](#_Toc224134001)

[4.5. Multi-Factor Authentication (MFA) 38](#_Toc224134002)

[4.6. Change Password 38](#_Toc224134003)

[4.7. Password Expiration 38](#_Toc224134004)

[4.8. Password Failure 39](#_Toc224134005)

[4.9. Cancel On Disconnect (COD) to User Session 39](#_Toc224134006)

[4.10. Multiple User Session of Browser instance and Tabs 39](#_Toc224134007)

[5. User Role and Permission 39](#_Toc224134008)

[5.1. GUI Permission Model 39](#_Toc224134009)

[5.2. User Role and Authorization 40](#_Toc224134010)

[6. Available Functions 41](#_Toc224134011)

[6.1. Enter Order 41](#_Toc224134012)

[6.2. Change Order 58](#_Toc224134013)

[6.3. Execute Order 65](#_Toc224134014)

[6.4. Order Book 71](#_Toc224134015)

[6.5. Order History 82](#_Toc224134016)

[6.6. Tailor-Made Combination 88](#_Toc224134017)

[6.7. Automatic Quote Order Book 99](#_Toc224134018)

[6.8. Local Inactive Orders 104](#_Toc224134019)

[6.9. Trade History 111](#_Toc224134020)

[6.10. Trade History Aggregated 117](#_Toc224134021)

[6.11. Ticker 121](#_Toc224134022)

[6.12. Enter Block Trade Report – Internal Block Trade and Interbank Block Trade 124](#_Toc224134023)

[6.13. Pending Trade Report and Block Trade History 142](#_Toc224134024)

[6.14. Instruments 146](#_Toc224134025)

[6.15. Price Information 149](#_Toc224134026)

[6.16. Order Depth 155](#_Toc224134027)

[6.17. Price Depth 161](#_Toc224134028)

[6.18. Market Message 164](#_Toc224134029)

[6.19. Market Statistic 167](#_Toc224134030)

[6.20. Quotes 171](#_Toc224134031)

[6.21. Quote Reply 178](#_Toc224134032)

[6.22. Trade View 184](#_Toc224134033)

[6.23. Trade Cancellation Request Dialog 190](#_Toc224134034)

[6.24. Trade Adjustment Request Dialog 193](#_Toc224134035)

[6.25. Error Trade Request View 197](#_Toc224134036)

[6.26. Error Trade Request Details 205](#_Toc224134037)

[6.27. Large Scale-Error Trade View 212](#_Toc224134038)

[6.28. Order Setting 222](#_Toc224134039)

[6.29. Confirmation Setting 229](#_Toc224134040)

[6.30. Deviation Warnings 236](#_Toc224134041)

[6.31. Client Global Parameter Setting 240](#_Toc224134042)

[6.32. Exchange On-Behalf Trade 240](#_Toc224134043)

[7. Appendix 245](#_Toc224134044)

[7.1. Irrelevant items #FS10014a\_S0700\_00100 245](#_Toc224134045)

[7.1.1. Change Order 245](#_Toc224134046)

[7.1.2. Tailor-Made Combination 246](#_Toc224134047)

[7.1.3. Trade History 246](#_Toc224134048)

[7.1.4. Enter Trade Report – Block Trades 246](#_Toc224134049)

[7.1.5. Pending Trade Report 247](#_Toc224134050)

# Document Control

## Change History

|  |  |  |  |
| --- | --- | --- | --- |
| Version  Number | Issue Date | Author | Abstract |
| 0.1 | 21 May 2024 | IT/Markets Systems | Initial Version |
| 0.2 | 14 Nov 2024 | IT/Markets Systems | First draft |
| 0.3 | 12 Dec 2024 | IT/Markets Systems | Update for Enter Trade Report and Block Trade |
| 0.4 | 23 Jan 2025 | IT/Markets Systems | Update according to Review Log comments. |
| 0.5 | 17 Feb 2025 | IT/Markets Systems | Update according to Traceability Mapping and ODP DT & IT weekly catch-up meeting discussions. |
| 0.6 | 21 Mar 2025 | IT/Markets Systems | Remove LEI |
| 0.7 | 25 Mar 2025 | IT/Markets Systems | Update Screen Sorting Requirement for Error Trade Request View and Order History  Pending Tarde Report add Open Block Trade History Dialog |
| 0.8 | 01 Apr 2025 | IT/Markets Systems | Remove MODIFIED column in Trade View |
| 0.9 | 08 Apr 2025 | IT/Markets Systems | Update Pending Trade Report Screen – Data Refresh in Table |
| 0.10 | 15 Apr 2025 | IT/Markets Systems | Confirmation Setting Grouping Label  Trade view with ATID Update Trade History Aggregated Screen – Scope of Data |
| 0.11 | 03 Jun 2025 | IT/Markets Systems | Update Order Book, Order History and Trade History remove table attributes  Add new section for Multiple User Session of Browser instance and tabs Trade History Aggregated Filter update - FS10014a\_S0610\_01702 Update No market Price confirmation setting from Order Setting to Confirmation Setting  Update Give up account to Give up information in Order Setting  Update Customer Information size from 16 to 15 align with Binary Spec  #FS10014a\_S0601\_05901 Minor wordings update to validate price tick in Enter Order screen  #FS10014a\_S0601\_02401 Update to load give up info from setting  Update Trade History, Trade View Attributes and Tooltips  Section 6.8 remove Lei and Cust Order ID  3.9 User Layout added Action Items Table |
| 0.12 | TBC | IT/Markets Systems | Update Order History Attributes and Tooltips, and add Restated action  #FS10014a\_S0604\_05000 remove notification for success amendment  #FS10014a\_S0624\_00601 Update Read Only attribute  #FS10014a\_S0623\_00501  Update Read Only attribute  Update Ticker Attributes and Tooltips  #FS10014a\_S0616\_00901 Implied Qty indicate in order depth  #FS10014a\_S0628\_00601  Update tooltips Give up Account to Give Up Information |
| 0.13 | TBC | IT/Markets Systems | 6.12 Enter Trade Report screen update Internal and interbank screen as 2 different individual functions  #FS10014a\_S0616\_01001 Updated for market order and bid/ask display as MKT for MKT and MTL orders  Enter Block Trade Screen update and attribute name update  Updated FS10014a\_S0030\_05300 not to support EDGE  6.12 update block trade screen and table attributes  Update price info screen remove ISS and REF |
| 0.14 | TBC | IT/Markets Systems | Update block trade Import Trade  Add AHT Trade Information  #FS10014a\_S0613\_00100 Update for Block Trade History Screen  Remove PRT and update COMPID tooltip in Order Book  Update for Quote and Quote Reply Section  Market Message Screen Layout update  Automatic Quote Order Book Screen Layout update  Tailor Made Combination Screen Layout update  Add BCAN fields to order screens, quote screens and trade report screens  Update Local Inactive Order to support BCAN  Update Instruments screen fields  Updated order background color for Order Book and Order History Add the Deal flag table in Trade History  Update Exchange On Behalf Trade screen  Add 4.11 Message Identifier Generation  Update Trade Adjustment Request Screen  Update Trade History description and scope of data  Update Trade View description and scope of data  Update 3.19 Linked Screen Behavior – remove Enter Trade Report and Enter TMC  Update Trade View and Trade History Screen Capture to remove header select all button  Price Info remove Underlying  Confirmation Screen update to show for external user only  Exchange On Behalf Trade update Last Traded Price and Last Traded Qty remarks  Update Countersign Acknowledgement – View Request  Automatic Quote Order Book – update Order No tooltips  Order Setting screen remove block trade type field  Confirmation Setting screen update fields. |
| 0.15 | TBC | IT/Markets Systems | Enter Order – Remove Duplicated Characters Set  Obsolete Quote Reply  Remove Export all action for Order Book, Trade History, and Trade View  Error Trade Request View – Update the section for Reject Notification  Enter Order – No need to support auto capital for CUST field  Change Order – Update COD to editable Deviation Warning – Update Premium detail to percentage type and compare to last traded price only |

## Document Cross-referenced

|  |  |  |
| --- | --- | --- |
| # | Document | Version |
| 1 | 0049 BRS ODP Online GUI | 27 Nov 2024 |
| 2 | FS10003 - Orderbook and Execution Management |  |
| 3 | FS10002 - Order Management |  |
| 4 | FS10010 - Product Structure |  |
| 5 | FS10019 - Market Message |  |
| 6 | FS10006 - Block Trade |  |
| 7 | FS10009 - Error Trade, Trade Cancellation and Adjustment |  |

## Abbreviation

|  |  |
| --- | --- |
| AHT | After Hours Trading |
| COP | Calculated Opening Price |
| OTP-D | Orion Trading Platform – Derivatives Market |
| VCM | Volatility Control Mechanism |
| ATID | Active Trader ID |

# Introduction

#FS10014a\_S0020\_00100

The section provides an overview of the OTP-D Online Trading GUI Graphical User Interface.

The Trading GUI is a web-interface based application, which facilitates external Trading, internal support functionalities, management of trading operations activities and etc.

# Trading GUI Application

## Technology

#FS10014a\_S0030\_00100

The UI Interface is empowered by web-based technology. External Client and Trading Operation users can use a web browser in Windows (Google Chrome, the exact version to be specified duly) to access the functions. It is expecting human interact the GUI interface directly instead of software or digital systems, a tools for Robotic process automation (RPA) may or may not work properly, further study/enhancement could be required in future when RPA become a priority.

## UI/UX

### UX Principal

#FS10014a\_S0030\_00200

**Familiar**

A cohesive system that creates familiar standards across products, platforms and experiences. Incorporates consistent language, patterns and behaviors in ways people expect and understand how to use.

**Scalable**
We design with the future in mind, creating a scalable, modular and dynamic experience across platforms. A system that is flexible to meet future challenges and can evolve to meet new requirements.

**Intentional**
We create with purpose and consideration for the user journey. Every step and moment of the experience should have clear purpose and intent, making every interaction feel more authentic and natural.

**Accessible**
We create products and services that are accessible for people with different needs and abilities. We design with empathy, understanding and consideration so that every user can interact with ease and without restraint.

**Contextual**
A clear understanding of the things that really matter to people in the moment. Provide relevant and actionable content found in its natural location to help clients achieve their desired outcomes.

### Principles of accessibility

#FS10014a\_S0030\_00300

Web accessibility ensures that people with disabilities can perceive, understand, navigate, interact with, and contribute to the applications you create. This means that pages are **Perceivable, Operable, Understandable and Robust.**

The following comes from the W3.org website, it explains the four principles of accessibility that the Web Contact Accessibility Guidelines (WCAG) and Success Criteria are organised around:

![](data:image/png;base64...)**Perceivable**
This principle states that digital content must be able to be understood by multiple senses.

This means that users must be able to perceive the information being presented (it can't be invisible to all of their senses).

For example, providing text alternatives for non-text content, such as images, would meet the Perceivable principle because sight isn’t required to understand the content, which benefits users who are blind.

Another example would be ensuring that color alone is not the only way to convey meaningful information, which helps users with low vision or color blindness.

![](data:image/png;base64...)

**Operable**
User interface components and navigation must be operable.

This means that users must be able to operate the interface (the interface cannot require interaction that a user cannot perform).

For instance, all functionalities must be available using only a keyboard. This ensures users who cannot use a mouse can access the same information on a webpage that mouse users can.

**Understandable**
Information and the operation of user interface must be understandable.

This means that users must be able to understand the information as well as the operation of the user interface (the content or operation cannot be beyond their understanding).

For example, all webpages must specify the language of the page and any parts of the page where the language differs from the primary language (for the benefit of screen reader users). Webpages must display and operate in a predictable manner, with an emphasis on helping users avoid and correct any errors.

![](data:image/png;base64...)

**Robust**![](data:image/png;base64...)
Content must be robust enough that it can be interpreted reliably by a wide variety of user agents, including assistive technologies.

This means that users must be able to access the content as technologies advance (as technologies and user agents evolve, the content should remain accessible).

If any of these are not true, users with disabilities will not be able to use the Web.

See www.w3.org/WAI/WCAG21/Understanding/intro for the entire article

## Trading UI User Journey

#FS10014a\_S0030\_00400

Trading UI is like doing a puzzle. It means putting together a huge number of puzzle pieces such as data processing, reliability, flexibility, accessibility, and convenience. We need to eliminate traders' mistakes and facilitate their trading; this is our top priority. For this purpose, add-on workspace concept is introduced and kept all the user flows simple and clear.

### Convenience and accessibility

#FS10014a\_S0030\_00500

Convenience and accessibility are crucial for a trading platform. We need to ensure it is easy to access and available to browser. The information architecture should consist of two main elements such as information placement on a page (view or templates) and navigation through site links. User experiences are intuitive and seamless, ensuring traders can easily navigate the site without guessing what to do next or where to find the necessary information or interaction.

### Visual Design

#FS10014a\_S0030\_00600

Overall visual design is the foundation of attraction, so we use design elements sparingly, provide an easy-to-read layout, and create concise yet meaningful and recognizable elements that grab the user's attention to achieve their goals, such as using fonts, icons, and navigation.

### Web font

#FS10014a\_S0030\_00700

Design the trading UI with accessibility in mind, adhering to accessibility guidelines and standards in the DLS. Ensure compatibility with keyboard navigation and recommended font sizes (body text should be default at 12 pixels, however user will be able to change font size to 16 pixels).

**Example:**

font-family: "FS Elliot Pro", Arial, "Heiti TC", "Heiti SC", "Microsoft JhengHei", "Microsoft YaHei", sans-serif;

Sufficient color contrast should be provided for over design elements with text. WCAG require a contrast ratio of at least 4.5:1 for normal text and 3:1 for large test to achieve level AA compliance.

### Navigation

#FS10014a\_S0030\_00800

A sidebar menu is an essential element of many websites that helps users navigate through the site’s different sections. A collapsible sidebar menu is a design pattern that allows users to collapse the menu when they don’t need it, giving them more space on the screen, and expand it when they need to access the menu items. This design pattern has the ability to maximize screen real estate.

![](data:image/png;base64...)

Saves space: An expandable sidebar menu takes up less space than a fixed sidebar menu. When users don’t need the menu, they can collapse it, giving them more space to view the website’s content.

Flexibility: The collapsible sidebar menu design pattern is versatile and can be used in various contexts, from desktop to mobile devices.

Better user experience: Collapsible sidebar menus allow users to focus on the content they want to view without distractions from the menu. Users can expand the menu when they need to access it, making the navigation more intuitive.

### Add-on Workspace

#FS10014a\_S0030\_00900

In trading UI, we define the workspace as the “canvas” into which everything else the user needs can fit. Keeping flexibility in mind, users will be able to customize, save and export their own layout setting of a workspaces. It will enable users to organize and complete daily tasks in their own way, which will save users time onboard the new platform and speed up their operational processes. The main thing is that it makes good use of all screen sizes and doesn't waste any empty space.

Users will be able to click, drag, and drop into each "view modal" from the menu/workspace. They can also organize multiple views together, which can be grouped into tab groups.

**![](data:image/png;base64...)**

### Real-time streaming

#FS10014a\_S0030\_01000

Instantaneous stock quotes and data update automatically, enabling accurate

analysis, price patterns, and effective strategies in trading UI. Overall design less visual design that can improve the performance of loading time and maximum the workspace for traders.

Custom web fonts are used around the world, but many websites load them incorrectly. This can cause a number of issues with page loading, such as performance issues, slow load times, rendering blocking, and swapping fonts during navigation. In our platform we must account for situations where the connection speed is not optimal, or users don't have time to wait a few seconds while the app/site fully loads and navigates. We use the window/mac default fonts and 12 pixels as the default font size.

## DData Type

#FS10014a\_S0030\_01101

The table below describes the internal Data Type used in the definition of logical entity attributes in the Data Dictionary.

| # | Data Type | Length | Description |
| --- | --- | --- | --- |
|  | Char | 1 | One character input and the following is allowed:   * A-Z * a-z * 0-9 * ~~:;.,\_-+|#&$@!()[]></~~ * &~#$%^()\_+-=[]\{};:,./ * Space |
|  | Boolean | 1 | Y = Yes/True or N = No/False |
|  | Numeric | As defined | Any digit from 0 to 9 and “-“, the following length are allowed:   * 3, possible value from 0 to 255 * 4, possible value from –128 to 127 * 5, possible value from 0 to 65535 * 6, possible value from -32768 to 32767 * 10, possible value from 0 to 232 - 1 * 11, possible value from - 231 to 231 - 1 * 20, possible value from 0 to 264 - 1 * 20, possible value from - 263 to 263 - 1 |
|  | Alphanumeric | As defined | Multiple characters input and the following is allowed:   * A-Z * a-z * 0-9 * ~~:;.,\_-+|#&$@!()[]></~~ * &~#$%^()\_+-=[]\{};:,./ * Space |
|  | Decimal | As defined | Any digit from 0 to 9 and “.”  With implicit decimals, the number of decimal places is separately and explicitly defined.  For example, if the size 5 and number of decimal places applicable to this field is 2 then the value can be 999.99.  Range of value is from 0 to 999,999,999,999,999,999. |
|  | Price | 19  (Additionally plus 1 if include “-“ or “.”) | Any digit from 0 to 9, “-“ and “.”  Signed number and support up to 6 decimal places by default and configurable per instrument type/class  ~~Allow user preference to control the display format for display only, for example user A can show price in order view as 10.1230 while user B show price as 10.123~~  It should consider decimal place setup by product class level for display purpose and input validation. It can be 0 – 6 decimal places, for example HSI shows 18000 without decimal place  Minimum value = -9,223,372,036,854,775,807  Maximum value = 9,223,372,036,854,775,807 |
|  | Quantity | 10 | Any digit from 0 to 9.  Minimum value = 0  Maximum value = 4,294,967,295 |
|  | Percentage | 9 | Any digit from 0 to 9.  Support up to 4 decimal places |
|  | Date | 11 | In universal time (UTC) and UI displays as DD-MMM-YYYY format |
|  | Time | 8 | In universal time (UTC) and UI displays as HH:MM:SS format |

Note the following:

1. Local Hong Kong time is used and displayed to client, while communication between Server and GUI is in Coordinated Universal Time (UTC) time
2. For Price and Percentage, size and number of decimal places are implicit
3. General data conversion will be done on behalf of the user. For example:

**Decimal (Explicit Decimal Places)**

A1. User types in Call Price = 1.23, it is converted into “Call Price” = 123 & “Decimals in Call Price” = 2 and sent to the backend.

A2. User types in Call Price = 1.234567980123, it is not allowed in the UI and is rejected.

A3. User types in Call Price = 123456798012345678.9, it is not allowed in the UI and is rejected.

**Percentage (Max 4 decimal places)**

B1. User types in IOMP Tolerance % = 4.56, it is converted into “IOMP Tolerance %” = 45600 and sent to the backend. During screen enquiry or report generation, it will show “4.5600”.

B2. User types in IOMP Tolerance % = 4.56890123, it is not allowed in the UI and is rejected.

B3. User types in IOMP Tolerance % = 45689012.3, it is not allowed in the UI and is rejected.

B4. User enters 99.9 to represent 99.9% for IOMP Tolerance %.

B5. User enters 99999 to represent 99999% for IOMP Tolerance %.

B6. User enters 99999.9999 to represent 99999.9999% for IOMP Tolerance %.

**Price (Max 6 decimal places)**

C1. User types in Minimum Price = 3.45, it is converted into “Minimum Price” = 3450000 and sent to the backend. During screen enquiry / report generation, it will show “3.450000”.

C2. User types in Minimum Price = 3.45234234, it is not allowed in the UI and is rejected.

C3. User types in Minimum Price = 345234123234567890.1, it is not allowed in the UI and is rejected.

### UI Widget Mapping by Data Type

#FS10014a\_S0030\_01201

The following session list out the general mapping of Data Type and UI Widget for display and update purpose, however they can be different in some specific functions which the user requirement may require a special display behaviour.

| # | Data Type | UI Widget | Description |
| --- | --- | --- | --- |
|  | Char | Text Input | Simple input text field to allow single character |
|  | Boolean | Dropdown  / Checkbox | Either dropdown (Default) or checkbox or radio button to support the following:  Y = Yes/True or N = No/False |
|  | Numeric | Text Input | Simple input text field to allow any digit from 0 to 9 |
|  | Alphanumeric | Text Input | Simple input text field to allow multiple character(s). |
|  | Decimal | Text Input | Simple input text field to allow any digit from 0 to 9. |
|  | Price | Spinner | An input text field with an upward and a downward arrow button and shows the next value when it is pressed. The next value is configurable, it can be based on a pre-defined delta portion.  This input text field allows any digit from 0 to 9. |
|  | Quantity | Spinner or Text Input | Simple input text field to allow any digit from 0 to 9. |
|  | Percentage | Text Input | Simple input text field to allow any digit from 0 to 9. |
|  | Date | Date selection Drop Down or  Text Input (Read-only) | Simple input text field to display date formatted value. (Default as DD-MMM-YYYY) And it is allowed to select date value in drop down |
|  | Time | Time Selection Drop Down or  Text Input (Read-only) | Simple input text field to display time formatted value. (Default as HH:MM:SS) And it is allowed to select time value in drop down.  For read-only display field, it can be supported up to 9 nano-of-second (e.g. HH:MM:SS.nnnnnnnnn) if needed based on requirement and GUI shows HH:MM:SS as default |

## Application Layout

#FS10014a\_S0030\_01300

The following session describe the application layout of Trading UI which consists of 4 major components: Header Bar, Side Bar, Footer Bar and Content Area.

![](data:image/png;base64...)

4

3

2

1

| Callout | Remarks |
| --- | --- |
| 1 | Header bar displays the application name, user profile menu and Workspace Menu. User can select available workspace in Workspace Menu and select available user actions in user profile menu. |
| 2 | Side bar displays the available function of current user in a system workspace, corresponding function is opened in Content Area after clicking on a menu item. |
| 3 | Footer bar displays the copyright information, privacy policy, disclaimer and help to user |
| 4 | Content area displays those opened function to user |

## Multiple Language Support

#FS10014a\_S0030\_01400

English only

## System Time and Client Local Time

#FS10014a\_S0030\_01500

The Hong Kong Local Time UTC/GMT +8 Hours is used as the system time for UI display, communication and processing.

Selection of date/time in GUI screen relies on Client Local PC time to provide an accurate current time of Hong Kong and user can further adjust the time to target date or time when required, for example user can target a scheduled event at 16:30 PM Hong Kong Local Time in a GUI drop down while the client UK local time is 9:30 AM.

In case of the Client Time is far away from our expected system time, a user notification is prompted to highlight the gap between client time and system time right after a successful user login. Client should follow up with their local admin to resolve it and login again.

The following system notification setting is defined:

| Absolute( Client UTC Time – Server UTC Time ) | System Notification Level |
| --- | --- |
| More than 1 minutes | INFO |
| More than 2 minutes | WARNING |
| More than 5 minutes | ERROR |

## System workspace

#FS10014a\_S0030\_01600

A workspace is a group of pre-define functions which user is allowed to organize functions in the same display Area. Their nature could be correlated and designed to facilitate client to manage their orders, trades, quote, user setting and etc in the same screen.

By design, multiple pre-defined system workspace is supported which provide extra flexibility to the internal operation to decide the grouping of function based on the nature, user role and permission if necessary. User can select & open a workspace at a time and switch to other workspace in the same login session if they are available.

For Trading GUI, one and only one Trading Workspace is available for both internal and external clients:

![](data:image/png;base64...)

## User Layout

#FS10014a\_S0030\_01701

A user layout is a visual container of a system workspace, which user can customize the size and position of GUI functions within a container as well as a single page in a physical book. Multi-tasking, content switch, instant search and etc could be supported in the layout quickly.

Moreover, user can create multiple user layout along with a nick name, switch into an existing layout, share layout to other user via Export & Import and delete an existing layout. Those newly created/updated layout is persisted into user profile during user logout.

The following table shows the available actions to maintain the user layout:

| # | Menu | Description |
| --- | --- | --- |
|  | Open Layout | Open available layout of current user |
|  | Reload Layout | Reload layout to last login setting |
|  | New Layout | Create a new layout of user |
|  | Rename Layout | Rename current layout |
|  | Delete Layout | Delete current layout |
|  | Clean Layout | Reset current layout to blank |
|  | Export Layout | Export layout to file |
|  | Import Layout | Import layout from file |
|  | Save Workspace | Persist user layout setting, Theme, Font and etc to backend |

The following describes the relationship between Workspace and layout:

![](data:image/png;base64...)

## Data Search Screen

#FS10014a\_S0030\_01801

Search screen is used to provide a place for user to list out those records based on search criteria field (In case insensitive), which supports:

* exact match, target keyword exactly matches the result
* partial match, target keyword partially matches the result base on the following arguments
  + question mark (?) to match zero or one occurrence
  + and star (\*) to match zero or more occurrence.
* Numeric value range search
* Date and Date time range search

For example, if user inputs “ABC\*”, entries with ABC, ABCx, ABC123 should show up in the search results. When user inputs “A?C”, entries with ABC should show instead.

Export to CSV is available under More Actions drop down to export the result to file.

![](data:image/png;base64...)

When multiple search criteria are specified, they are considered as **AND** condition. To find records that meet multiple values of the same criteria, it is allowed to key in “,” to select as **OR** condition up to 5 maximum values per criteria.

![](data:image/png;base64...)

Filter by label indicates the current filtering criteria of the search, and those results are displayed in the underneath table along with scroll bar or pagination bar for navigation. It is optional to Trading GUI due to limited display area in Trading Workspace layout.

Apart from filter by search criteria, user is allowed to perform value filter by using table column operation menu ![](data:image/png;base64...) > filter

*\*Please noted that More filter is replaced by table column operation menu filter feature*

![](data:image/png;base64...)

## Detail Screen

#FS10014a\_S0030\_01900

Detail screen is used to display the detail of a selected record along with the current record status and future planned status at the top of this screen. User can plan a New/Update/Delete record this screen, export the detail to file, show the record history and etc. User can open up to 5 detail record screens at a time.

Sample Detail Screen:

![](data:image/png;base64...)

## User Input Screen

#FS10014a\_S0030\_02000

Input screen provides a clean, minimalist design with sufficient space and clearly explain the required actions to user. Session Header describes the purpose of fields, and they aligned together properly as a group. In the bottom, a couple of buttons stands out with primary, secondary and monotone colours which encourage people to click on an action to complete the form and guide the user intuitively through the data input process.

Sample Input Screen:

![](data:image/png;base64...)

## User Setting

#FS10014a\_S0030\_02100

Table column setting is available in table header for user to choose the ordering and define hide/show to columns, and the setting is persisted as part of user profile during a successfully logout.

The following drop down is showed after clicking on the table header menu icon

![](data:image/png;base64...)

### Colour, Style and Font Setting

#FS10014a\_S0030\_02200

Colour setting, widget style and font size are pre-defined setting in accordance with the HKEX UI/UX principal, which allows us to maintain a consistency UI look and feel across multiple applications of HKEX.

Both Light theme and Dark theme are available, user to choose a theme from the header bar drop down menu, selected theme is effective immediately and selected theme is persisted to user profile as part of a successful logout.

## Content Assistant

#FS10014a\_S0030\_02300

Content assist is used to list out those matched values based on a partially entered text from input box. It performs an implicit query to backend server and displays the corresponding result into a dropdown menu (but limited to 10 items at a time). User can either select the desired value or navigate around these values by mouse or arrow up/down key.

Entered text followed by question mark (?) matches zero or one occurrence in the result. And entered text followed by star (\*) matches zero or more occurrence.

It lists out all **Active** items of the system without considering trading right, backend processes take the responsibility to perform the validation.

![](data:image/png;base64...)

## GUI Notification

#FS10014a\_S0030\_02400

The purpose of GUI Notification is to give/ask for a feedback or show status update to user after an event happened.

Depending on the nature of a notification, important notification message is persisted into the system internally while low priority message as well as a in progress notification message or etc, they are not persisted and cannot be recovered to GUI.

The following describes various type of notification message in Trading GUI:

**System Notification** shows at the top of Content Area

![](data:image/png;base64...)

**User Notification** shows at the bottom of Content Area

![](data:image/png;base64...)

**View Notification** shows notification message at the bottom of a targeted function view. Several notification levels are available to notify user for different purpose.

Information notification message

![](data:image/png;base64...)

Confirmation notification message

![](data:image/png;base64...)

Progress notification message

![](data:image/png;base64...)

Warning notification message

![](data:image/png;base64...)

Success notification message

![](data:image/png;base64...)

Error notification message

![](data:image/png;base64...)

## Countersign Acknowledgement

#FS10014a\_S0030\_02500

**Description**

According to the level of authorization required, actions performed in ODP Online GUI it has following behaviours:

1. No Authorization Required

Requester can perform an action directly.

1. 4-eye Confirmation Required (Maker / Checker)

The action will be submitted as an Action Request with **PENDING** status and wait for checker to review and provide the approval. Maker and checker must be different person.

Before the approval is made, Maker can check the current state of the action and reject it if it is no longer valid.

If Checker or Maker rejects the change, it is marked as “Rejected”.

Once approval is made, system will proceed to execute the action.

It should be noted that as part of the end of day housekeeping job, those pending requests will be discarded and listed as part of the end of the day pending request report.

**Accessing the Function**

#FS10014a\_S0030\_02600

Countersign window can be opened from the Pending Request menu.

**Request Status**

#FS10014a\_S0030\_02700

Whenever an action requires 4-eye Confirmation, a request will be created for Checker’s approval. The action will be executed only when Checker approved the Request.

The status of the request will be transit as below:

![A diagram of a process  Description automatically generated](data:image/png;base64...)

| # | Request Status | Description |
| --- | --- | --- |
|  | PENDING  ![](data:image/png;base64...) | When the Maker submits the request for approval, the request will become PENDING status. |
|  | APPROVED  ![](data:image/png;base64...) | Once the request has been approved by Checker, it will become APPROVED. And system will execute the Action. |
|  | REJECTED  ![](data:image/png;base64...) | If the request had been rejected by Checker, it will become REJECTED. |
|  | FAILED  ![](data:image/png;base64...) | If Checker tires to approve/reject the action, but the execution failed due to error, the request will become FAILED. |

**UI Layout**

#FS10014a\_S0030\_02802

Search Page

![](data:image/png;base64...)

Detail Page

![](data:image/png;base64...)

**Attributes**

#FS10014a\_S0030\_02900

| Column | Type | Size | Remarks |
| --- | --- | --- | --- |
| **Request Identity** | | | |
| Request ID | Numeric | 8 | A unique identifier for the countersign request to be authorized. |
| Received At | Date and Time | 14 | Date and time that the Requester submits the Action Request.  The field is displayed in DD-MM-YYYY HH:MM:SS format. |
| Requester | Alphanumeric | 120 | Name of the User who raises the request. |
| Identifier | Alphanumeric | 100 | Identifier of the countersign request for reference. |
| **Request Detail** | | | |
| Function Name | Alphanumeric | 80 | Function name that the request is going to perform the action. |
| Request Action | Alphanumeric | 10 | Request Action to be performed.  Domain values:  **Execute –** Execute the Action |
| Request Status | Alphanumeric | 10 | Status of countersign request.  Domain values:  **Pending**  **Approved (Highlighted in green)**  **Failed**  **Rejected (Highlighted in red)** |
| Update At | Alphanumeric | 14 | The time that the request status is updated in DD-MMM-YYYY HH:MM:SS.. |
| Execution Status | Alphanumeric | 10 | Status of the execution of countersign request.  Domain values:  **Pending**  **Scheduled**  **Executed**  **Failed**  **Rejected** |
| Effective Date | Date | 11 | Effective Date of the countersign request in DD-MMM-YYYY |
| **Approve / Reject Detail** | | | |
| Approver | Alphanumeric | 120 | Name of the User who approve the request. |
| Approved At | Date and Time | 14 | Approval time in DD-MMM-YYYY HH:MM:SS. |
| Rejecter | Alphanumeric | 120 | Name of the User who rejected the request. |
| Rejected At | Date and Time | 14 | Rejection time in DD-MMM-YYYY HH:MM:SS. |
| Failed Reason | Alphanumeric | 200 | Reason of failure if Request status if Failed. |

**Action Detail** Section in Detail Page displays the detail of the Action Request. Different Request Type will have different content in this section.

| Column | Type | Size | Remarks |
| --- | --- | --- | --- |
| **Action Detail** | | | |
| Attribute | Alphanumeric | 120 | Attributes of Action Item.  If there are more than one record with the same Action Item Type, a prefix “**Record X –** “will be added to the Attribute to distinguish between records. |
| Value | Alphanumeric | 1024 | Value of the Attribute. |

For example,

1. Request Detail of cancelling an Order.

The attributes and the corresponding values of the Order are displayed in the screen.

![](data:image/png;base64...)

**Tooltips**

#FS10014a\_S0030\_03000

| Column | Tooltips |
| --- | --- |
| **Request Identity** | | |
| Request ID | Specify the unique ID of the Request. |
| Received At | Specify the time that Requester raise the Request. |
| Requester | Specify the name of the User who raise the Request. |
| Identifier | Specify the identifier of the Request. |
| **Request Detail** | |
| Function Name | Specify the Function Name of the Request. |
| Request Action | Specify the Action to be performed. |
| Request Status | Specify the status of the Request. |
| Updated At | Specify the last update time of the Request. |
| Execution Status | Specify the execution status of the Request. |
| Effective Date | Specify the effective date of the Request. |
| **Approve / Reject Detail** | |
| Approver | Specify the name of the Approver who approved the Request. |
| Approved At | Specify the time that the Approver approved the Request. |
| Rejecter | Specify the name of the Approver who rejected the Request. |
| Rejected At | Specify the time that the Rejecter rejected the Request. |
| Failed Reason | Specify the reason if the Request failed to execute. |
| **Action Detail** | |
| Attribute | Specify the attribute involved in this request |
| Value | Specify the value of the corresponding attribute |

**Data refresh in table**

#FS10014a\_S0030\_03100

The table in Search Page will automatically update upon any changes of the requests.

**Default Sorting Order**

#FS10014a\_S0030\_03200

The table in Search Page is sorted by ascending order of **Received At** by default.

**Filtering Criteria**

#FS10014a\_S0030\_03301

Following filter fields are available for criteria search in the Search Page.

Display right above the table.

| Filtering Criteria | Type |
| --- | --- |
| Function Name | Text Input (with Content Assist) |
| Requester | Text Input (with Content Assist) |
| Request Status | Dropdown |

[Revoked]

**Read / Write Permission Behaviour**

#FS10014a\_S0030\_03400

| Permission | Behavior |
| --- | --- |
| Maker | Makers are allowed to perform the following:   * Query the list of Action Request of his/her company in Search Page. * View the detail of Action Request in Detail Page. * Reject his/her own Action Request which is still in Pending status. |
| Checker | Checkers are allowed to perform the following:   * Query the list of Action Request of his/her company in Search Page. * View the detail of Action Request in Detail Page. * Approve / Reject an Action Request which is in Pending status. |

**Action**

Search Page

The following actions are available in the Search Page:

1. **#FS10014a\_S0030\_03501 View Request**

Users can double click a Request to open Request Detail.

1. **#FS10014a\_S0030\_03600 Approve Request**

Users can click the **Approve Request** option from the **More Actions** menu to approve Action Requests. Only Request with **PENDING** status can be approved.

User can select one or more Requests to approve multiple requests in one click.

Confirmation box will be prompted with the following text when user click on the **Approve Request** option.

*Confirm approve of selected request(s).*

The approval will be submitted when user clicks OK on the confirmation box.

Note that if the Approve Request Option will be available only when user have the Approval right.

1. **#FS10014a\_S0030\_03700 Reject Request**

Users can click the **Reject Request** option from the **More Actions** menu to reject Action Requests.

User can select one or more Requests to approve multiple requests in one click.

Confirmation box will be prompted with the following text when user click on the **Reject Request** option.

*Confirm reject of selected request(s).*

The rejection will be submitted when user clicks OK on the confirmation box.

Note that if the Reject Request Option will be available to all users. But the rejection can be completed successfully will depends on the following:

1. User has the Approval Right.
2. Or User is the Maker of the Request.
3. **#FS10014a\_S0030\_03800 Approve all Pending Request**

Users can click the **Approve all Pending Request** option from the **More Actions** menu to approve all the Pending Requests (limit to your current filtering criteria). The system will search all the Requests with **PENDING** status based on your current filtering criteria.

Confirmation box will be prompted with the following text when user click on the **Approve all Pending Request** option.

*Confirm approve all pending request(s).*

The approval will be submitted when user clicks OK on the confirmation box. Note that there is a throttle to limit the submission rate to 5 requests per second and a progress notification will indicate the progress of the submission.

Note that if the Approve all Pending Request Option will be available only when user have the Approval right.

1. **#FS10014a\_S0030\_03900 Reject all Pending Request**

Users can click the **Reject all Pending Request** option from the **More Actions** menu to reject all the Pending Requests (limit to your current filtering criteria). The system will search all the Requests with **PENDING** status based on your current filtering criteria.

Confirmation box will be prompted with the following text when user click on the **Reject all Pending Request** option.

*Confirm reject all pending request(s).*

The rejection will be submitted when user clicks OK on the confirmation box. Note that there is a throttle to limit the submission rate to 5 requests per second and a progress notification will indicate the progress of the submission.

Note that if the Reject all Pending Request Option will be available to all users. But the rejection can be completed successfully will depends on the following:

1. User has the Approval Right.
2. Or User is the Maker of the Request.
3. **#FS10014a\_S0030\_04000 Export to CSV file**

The users can click "**Export summaries to CSV File**" to export the summaries of the selected Requests as a CSV file.

The users can click "**Export all summaries to CSV File**" to export the summaries of all Requests as a CSV file.

The users can click "**Export details to CSV File**" to export the detail of the selected Requests as a CSV file.

The users can click "**Export all details to CSV File**" to export the detail of all Requests as a CSV file.

1. **#FS10014a\_S0030\_04100 Double click a Request**

User can double click a Request in the Search Page to bring up the Detail Page for that Request.

Detail Page

The following actions are available in the Detail Page:

1. **#FS10014a\_S0030\_04200 Approve**

User with approval permission can approve the Request.

Confirmation box will be prompted with the following text when user click on the **Approve** button.

*Confirm approve request.*

The approval will be submitted when user clicks OK on the confirmation box.

Note that the **Approve** button will be available only when the following criteria matched:

1. The Request is not in **PENDING** status.
2. The user has the Approval right.
3. **#FS10014a\_S0030\_04300 Reject**

User with approval permission can reject the Request.

Confirmation box will be prompted with the following text when user click on the **Reject** button.

*Confirm reject request.*

The rejection will be submitted when user clicks OK on the confirmation box.

Note that the **Reject** button will be available only when the following criteria matched:

1. The Request is not in **PENDING** status.
2. The user has the Approval right or user is the requester of the Request.
3. **#FS10014a\_S0030\_04400 Export**

The users can click "**Export**" to export the request detail from GUI table.

**Validation**

Search Page

1. **#FS10014a\_S0030\_04500 Approve Request**
2. At least one or more Request had been selected.
3. All the selected Requests are in **PENDING** status.
4. The user has Approval Rights of the corresponding Action in the Requests.
5. **#FS10014a\_S0030\_04600 Reject Request**
6. At least one or more Request had been selected.
7. All the selected Requests are in **PENDING** status.
8. The user has Approval Rights of the corresponding Action in the Requests. Or user is the Requester of the selected Requests.

Detail Page

1. **#FS10014a\_S0030\_04700 Approve**
2. The Request is in **PENDING** status.
3. The user has Approval Rights of the corresponding Action in the Request.
4. **#FS10014a\_S0030\_04800 Reject**
5. The Request is in **PENDING** status.
6. The user has Approval Rights of the corresponding Action in the Request. Or user is the Requester of the Request.

**User Notification**

**#FS10014a\_S0030\_04900**

Success Notification – Approval/Reject is accepted

Error Notification – Request is rejected/failed

## Landing Page

**#FS10014a\_S0030\_05000**

Landing page is the main entry point of user which displays the company policy & system information, clients are redirected to authentication system (EIDP) automatically after a short countdown period (e.g. 10s).

Incompatible browsers checking takes place before redirecting to authentication system, which highlight the minimum browser requirements to accessing the application and the detected client browser agent name and version.

In case of system maintenance during weekend, this landing page is used to show the maintenance information and status.

For emergency purpose when the authentication system (EIDP) is not available, this page can be switched manually by operational script to provide a backup authentication mechanism for client to access the platform. More information will be supplemented later.

## Login Screen Flow

**#FS10014a\_S0030\_05100**

Clients are required to logon through the HKEX Single sign-on authentication system (EIDP) prior to accessing to the ODP Trading GUI functions. Following screen will be presented for user login:

TODO – add Login Screen

Upon successful logon, the user is redirected to ODP trading GUI along with corresponding user information and system preference, the main application layout is loaded after essential validations are passed and all required information is downloaded successfully. Those available functions are listed base on the user role and permission into side bar.

TODO – add side bar

After clicking on logout menu under the User Profile Icon, a confirmation dialog is displayed and ask if user want to persist user setting into user profile (For example layout, user setting and etc).

TODO – Add Logout Menu screen

## Linked Screen Behaviour

**#FS10014a\_S0030\_05201**

The following tables describe the behavior of between functions

| # | Function Name | Target Screen | Source Screen |
| --- | --- | --- | --- |
|  | Price Information |  | Yes |
|  | Quotes |  | Yes |
|  | Price Depth (Linked) | Yes | Yes |
|  | Order Depth (Linked) | Yes | Yes |
|  | Enter Order (Linked) | Yes | Yes |
|  | Instruments (Linked) | Yes | Yes |

Target Screen – Current selected/displayed Instrument ID of the function can be updated automatically based upon the source of selected Instrument ID in the above tables. Linked checkbox is available in these screens which user can decide auto update should be enabled or not. Default to unlinked when open.

Source Screen – Newly selected Instrument ID of the function can disseminate the new selection to other functions in the above table

## Hardware requirements

**#FS10014a\_S0030\_05300**

Client should access ODP Online GUI via a workstation fulfilling the following requirements:

**Operating System**

* Microsoft Windows 10 or above

**Browser**

* ~~Microsoft Edge version xxx or above~~
* Google Chrome version xxx or above

**Minimum Screen Resolution**

* 1920 x 1080

**Recommended Screen Resolution**

* 2560 x 1440 or above

# User Session

**#FS10014a\_S0040\_00100**

User is referring a physical human who make use of the Web Browser GUI to interact with the Trading Platform. After a successful login via EIDP, a new user session is created to retain the user information and status for a fixed period. Each request and response from Browser to the Trading Platform requires validation for user identity and access right to target information or function.

Each user is allowed to have one and only one active session at a time, existing user session is marked as invalid automatically before new user session is created.

## Session Refresh

**#FS10014a\_S0040\_00200**

To keep the user session alive, client browser triggers a session refresh call regularly (default to every 2 mins). Expired user session vanished automatically to prevent unauthorized access by reusing an outdated user session.

## Inactive User Session

**#FS10014a\_S0040\_00300**

By detecting mouse and keyboard activity in client browser, GUI determines the status of current user session and trigger a force logout if the current user session is inactive for a fixed period (default to 15 mins). A proper user logout is triggered by client automatically when inactive user session is detected.

## Force Logout

**#FS10014a\_S0040\_00400**

For emergency purpose, it is allowed to suspend user access and trigger a client GUI logout from Admin GUI on a best effort basis, it depends on the next refresh session or client request to the platform.

## Invalid User Session

**#FS10014a\_S0040\_00500**

Browser client is redirected to login page when invalid user session is detected. While API client with an invalid user session token is rejected along with HTTP Error code 401 (Unauthorized Response).

## Multi-Factor Authentication (MFA)

**#FS10014a\_S0040\_00600**

Apart from Username and password, One-time-password (OTP) is required during the user login to provide a strong user identity and access protection. MFA is provided by EIDP which user must register their device for One-time-password (OTP) generation in advance. More information will be supplemented later

## Change Password

**#FS10014a\_S0040\_00700**

Change password and password policy are managed by EIDP, user can be redirected to EIDP change password screen from user profile menu. More information will be supplemented later

## Password Expiration

**#FS10014a\_S0040\_00800**

Password expiration check and notification are provided by EIDP, user can receive a notification if password is going to be expired after a successful login to EIDP. More information will be supplemented later

TBC - configurable expiration days setting in EIDP

TBC - confirmed with EIDP if it is possible to generate email notification on a best effort basis if user didn’t login to the system during that period

## Password Failure

**#FS10014a\_S0040\_00900**

User account lockout due to unsuccessful login attempts are managed by EIDP. External/Internal Admin user can unlock the user account if required via EIDP maintain user account function. More information will be supplemented later

TBC – Number of consecutive unsuccessful login attempts is configurable

TBC - External/Internal Admin user can unlock account

## Cancel On Disconnect (COD) to User Session

**#FS10014a\_S0040\_01000**

When client browser is not able to maintain the communication channel with our platform due to bad network connection, hardware/software issue and etc, client should try to resolve the problem and reconnect to our platform within a system pre-defined period (e.g. 12mins) before Cancel On Disconnect (COD) is triggered on a best effort basis.

Cancel On Disconnect (COD) is not triggered in the following scenarios:

* Proper user logout by selecting logout menu item
* gracefully close Web browser or Tab by clicking on “X” button

## Multiple User Session of Browser instance and Tabs

**#FS10014a\_S0040\_01100**

When user login the application multiple times with the same user ID in different browser instances or within the same browser instance but across multiple Tabs, the last successfully login session will take over and old sessions will be redirected to landing page afterward on a best effort basis.

## Message Identifier Generation

Message Identifier is generated for client initialization messages sent to backend components such as ODP Trading Gateway and Inhouse Trading and RM Gateway. Each Comp ID is associated with its own dedicated ID pool, ensuring that message IDs are uniquely generated.

The ID follows a fixed format consisting of the current date in YYYYMMDD format concatenated with an increasing numeric sequence that resets daily. For example, the first message generated on 13 May 2026 would be 202605131, followed by 202605132, and so on.

The generated message IDs are widely used in Trading GUI, for example:

* Enter Order (Client Order ID)
* Quotes (Quote ID)
* Price Information (Quote Request ID)

# User Role and Permission

## GUI Permission Model

**#FS10014a\_S0050\_00100**

The GUI Permission model allows internal admin control over who can access and interact with functions in the GUI Application. Three permission level are allowed to set, they are “**read-only**”, “**write**” and “**approval**” level.

**Read-Only** level allows user to open a function and read the content without any changes.

**Write** level allows user to modify the content, change request may be submitted for second user approval which is configurable as part of the function permission setup. Original Requester who do not have approval right is able to reject his change request if necessary.

**Approval** level allows user to approve/reject request from other users.

## User Role and Authorization

**#FS10014a\_S0050\_00200**

GUI Permission are linked to user roles, external user account is assigned to one user role at a time while Exchange user account can be assigned to one or more user roles based on their needs. With this **role-based** authorization approach, internal admin can centralize the management of permissions by user role instead of assigning individual permission one by one to user manually.

When new user joins, admin user can simply assign the relevant role(s) to inherit those associated permission in one go. When permission change is applied to a user role, the change can be granted to users automatically without having to manually adjust the individual permission.

The setup of User Role and User account are managed by Admin GUI. For more detail please refer to Admin GUI FS.

# Available Functions

## Enter Order

**Description**

**#FS10014a\_S0601\_00100**

This function is applicable to External only.

This window is used for sending orders to backend process.

The instrument series ID can either be entered manually or update automatically based upon selected item from source windows when “Link” checkbox is checked.

Apart from price and quantity, other input fields of Enter Order Screen should remain un-touch based on the last placed order of the current user session.

**Accessing the Function**

**#FS10014a\_S0601\_00200**

Enter Order window can be opened from the menu.

ODP Online allows one Enter Order window to be opened.

**UI Layout**

**#FS10014a\_S0601\_00300**

![](data:image/png;base64...)

**Attributes**

**#FS10014a\_S0601\_00401**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| **Standard Attributes** | | | | | |
| Instrument ID | Alphanumeric  **Text Input (with Content Assist)** | 32 | M | - | **#FS10014a\_S0601\_00500**  Tradable Instrument Identifier.  The name of the instrument, it could be manually entered or automatically updated when the window is linked up with other windows.  **#FS10014a\_S0601\_00600**  ***Whenever there are changes to the Instrument ID field, the Price and Quantity will be reset.***  ***If this window is linked and user clicked an instrument from Price Information window, the Price and Quantity will be filled accordingly, otherwise Price will be reset to 0 and Quantity will be reset to default quantity.*** |
| Price | Price  **Spinner Input (With up / down per tick unit)** | [Ref to Data Type](#_Data_Type) | M | - | **#FS10014a\_S0601\_00700**  The limit price. An order is to be matched at the limit price or better.  The price could be manually entered or click at the prevailing market price of relevant instrument in the price information window, the prevailing price at the time of clicking could be automatically pop up in the price field in enter order window.  **#FS10014a\_S0601\_00800**  It's an up/low button to adjust the price up / down where the adjustment delta is in one price tick unit. (Both mouse click, and keyboard up/down are supported)  ***Negative Value is allowed on depends on Instrument.***  **#FS10014a\_S0601\_00900**  ***The price must not present when order type is Market or Market-to-Limit. For others, it must fall within the allowable price range discussed in FS-10004.*** |
| Quantity | Quantity  **Text Input**  **(With up / down per tick size)** | [Ref to Data Type](#_Data_Type) | M | - | **#FS10014a\_S0601\_01000**  The maximum executable quantity per order specification depending  on the Validity.  The quantity could be manually entered or automatically pop up with the prevailing market quantity at the time of clicking the relevant market price in the price information window.  **#FS10014a\_S0601\_01100**  It’s an up/low button to adjust the quantity up / down with the change in one contract. (Both mouse click, and keyboard up/down are supported)  ***If default quantity is defined in Order Settings, this field will be pre-filled by default when open. The same value will be filled whenever reset occurs.*** |
| ~~Yield~~ | ~~TBC~~ | ~~TBC~~ | ~~TBC~~ | ~~TBC~~ | ~~# BRD\_DT\_0049\_030\_05300~~  ~~TBC~~  ~~The Price field above could be changed to yield. This is for future planning that when we trade bond future with trading in yield base.~~ |
| ~~Total Quantity~~ | ~~TBC~~ | ~~TBC~~ | ~~TBC~~ | ~~TBC~~ | ~~# BRD\_DT\_0049\_030\_05300~~  ~~TBC~~  ~~This is for future planning that when we support Iceberg order. The total quantity field contain the total quantity of the iceberg order and the Quantity field is the exposure quantity. If the total quantity is set the same as the quantity, the order is sent as normal order without hidden quantity. The field would be active for enter only when the order validity is Iceberg, else it is disabled.~~ |
| ~~Lot Type~~ | ~~TBC~~ | ~~TBC~~ | ~~TBC~~ | ~~TBC~~ | ~~#FS10002\_S0020\_05100~~  ~~TBC~~  ~~Lot type specify order quantity relative to the instrument lot size. #FS10002\_S0020\_05200~~  ~~Domain Value:~~  **~~Round Lot~~** ~~#FS10002\_S0020\_06100~~  **~~Odd Lot~~** |
| Type | Alphanumeric  **Dropdown** | - | M | Limit Order | **#FS10014a\_S0601\_01200**  This is the order type.  **#FS10014a\_S0601\_01300**  Domain Value:  **Limit Order**  **Market Order**  **Market to Limit Order**  ***If Market Order / Market to Limit Order is selected as order type, the Price field should be disabled.*** |
| Time Validity | Alphanumeric  **Dropdown** | - | M | Day | **#FS10014a\_S0601\_01400**  This is the order validity which defines what order condition to use.  For detail, please refer to **Validity** section.  **Users can define the default validity in Order Settings. If default is defined, this field will be pre-filled by default when open. The same value will be filled whenever reset occurs.** |
| Expiry Date | Date  **Date Selection Drop Down** | - | M/O | - | **#FS10014a\_S0601\_01500**  indicate the date of expiration when Time Validity is GTD.  **#FS10014a\_S0601\_01600**  The expiry date must be ≥ current trading day, otherwise the order will be rejected.  ***\* This field is read only and its EDITABLE and MANDATORY only when Validity is Date.*** |
| ~~Client Order ID~~ | ~~Alphanumeric~~  **~~Text Input~~** | ~~TBC~~ | ~~O~~ | ~~-~~ | ~~#FS10002\_S0020\_11100~~  ~~Unique identifier for the order assigned by the market participant.~~ |
| SMP ID | Alphanumeric  **Text Input**  **(with Content Assist)** | 21 | O | - | **#FS10014a\_S0601\_01700**  The SMP ID is to prevent from being matched to an opposite order if both buy and sell orders for the trade contain the same SMP ID. |
| BCAN | Alphanumeric  **Text Input** | 17 | M | - | #FS10002\_S0020\_13100  The BCAN attribute is a pass-through attribute. It is used to identify the order’s originator for market surveillance purposes. |
| Position Effect | Alphanumeric  **Dropdown** | - | O | Open | **#FS10014a\_S0601\_01800**  Position Effect is a pass-through attribute. It allows market participants to specify either opening or closing of position for clearing procedure.  Domain Value:  **- Open**  **- Close** |
| Customer | Alphanumeric  **Text Input**  **(With Content Assist)** | 10 | O | - | **#FS10014a\_S0601\_01901**  The name or ID of a market participant’s client.  Customer client attribute serve 2 purposes:  1. An identifier for Mass order cancellation.  2. Pass-through to downstream systems for clearing procedure.  This field is to register a trade in a particular account. E.g. enter H to register a trade in house account. The field is carried in order book and order history, after match, this field is reflected in trade history customer field as well where in trade history, it reflected the carried account in clearing.  Domain Value:  **H –** House Account  **C –** Client Account  **R### –** Market Maker account  For Stock Option:  **A1 –** Customer Account  **P1 –** House Account  **M1 –** Market Maker account  ***~~Small Letters in the input will be updated to capital letter automatically.~~***  ~~UI allows the following characters input:~~   * ~~A-Z~~ * ~~a-z~~ * ~~0-9~~ * ~~:;.,\_-+|#&$@!()[]></~~ * ~~Space~~   ***Users can define a list of frequently used accounts in Order Settings. If default is defined, this field will be pre-filled by default when open. The same value will be filled whenever reset occurs.*** |
| ~~Executing Trader~~ | ~~Alphanumeric~~  **~~Text Input~~** | ~~TBC~~ | ~~O~~ | ~~-~~ | ~~#FS10002\_S0020\_16100~~  ~~Executing Trader is a free text attribute attached to the order. When it is available, market participants can submit Mass order cancel to cancel orders those match against this field.~~ |
| **Pass-through Attributes** | | | | | |
| ~~Legal Entity Identifier~~ | ~~Alphanumeric~~  **~~Text Input~~**  **~~(With Content Assist)~~** | ~~20~~ | ~~O~~ | ~~-~~ | **~~#FS10014a\_S0601\_02000~~**  ~~The Legal Entity Identifier. The global unique identifier used for identification of beneficial owner. It is a pass-through attribute to downstream systems for regulatory reporting and supervision.~~  ***~~Users can define a list of frequently used values in Order Settings. If default is defined, this field will be pre-filled by default when open. The same value will be filled whenever reset occurs.~~*** |
| Customer Information | Alphanumeric  **Text Input** | 15 | O | - | **#FS10014a\_S0601\_02100**  This field is updated with the customer information. It is a free text field where alphabets or numbers, special characters are accepted with differentiation on capital. The field content will be carried in order book, order history and trade history Info field as well.  ~~UI allows the following characters input:~~   * ~~A-Z~~ * ~~a-z~~ * ~~0-9~~ * ~~:;.,\_-+|#&$@!()[]></~~ * ~~Space~~   ***Users can define a list of frequently used values in Order Settings. If default is defined, this field will be pre-filled by default when open. The same value will be filled whenever reset occurs.***  ***Align with OAPI “Customer\_info\_s”.*** |
| Give up radio button | Boolean  **Radio Button** | 1 | O | No | **#FS10014a\_S0601\_02200**  Indicate whether give is enabled or not.  ***The Give up and Give up acc field are disabled by default. They will be enabled only if give up radio button is Yes.*** |
| Give up Participant | Alphanumeric  **Text Input**  **(with Content Assist)** | 5 | M/O | - | **#FS10014a\_S0601\_02300**  It lists the clearing participant of the give up party, which when the order is matched, the trade will be given up to. It is available only when the give up radio button is Yes.  It is a pass-through attribute to downstream systems for Give-up / Take-up process in clearing procedures.  ~~Source the latest Clearing Participant from Clearing System daily. Perform validation against the list.~~  ***Give up field is MANDATORY only when the Give up radio button is Yes.***  ***The CP list source from the eligible participant set up in CDB.*** |
| Give up Information | Alphanumeric  **Text Input**  **(with Content Assist)** | 15 | O | - | **#FS10014a\_S0601\_02401**  The Arbitrary text information concerning the give up order. It is a pass-through free text attribute for clearing procedure  ***Users can define a list of give up info to which give-ups are usually made in Order Settings. If default is defined, this field will be pre-filled by default when open. The same value will be filled whenever reset occurs.***  ***Align with OAPI field “Give-up account info”.*** |
| ~~Incentive ID~~ | ~~Alphanumeric~~  **~~Text Input~~** | ~~5~~ | ~~O~~ | ~~-~~ | ~~Incentive ID. Alphanumeric free text field with length as 5.~~ |
| ATID | Alphanumeric | 5 | O | - | **#FS10014a\_S0601\_02500**  The ATID. The ID is NOT allowed to change after order placement. |
| **#FS10014a\_S0601\_02600**  **Special Order Attributes** | | | | | |
| Tradable in AHT | Boolean  **Checkbox** | 1 | O | False | **#FS10014a\_S0601\_02700**  The indicator specifies whether an order should participate trading in AHT session. |
| Inactive | Boolean  **Checkbox** | 1 | O | False | **#FS10014a\_S0601\_02800**  Order with this attribute will be stored in local inactive order window.  ***The inactive order will keep in the “Local inactive orders” window till the series expiry.*** |
| COD | Boolean  **Checkbox** | 1 | O | True | This indicator specifies whether the order is subject to COD. |

**Validity**

| Order Condition | Description |
| --- | --- |
| Fill or Kill (FOK) | **#FS10014a\_S0601\_02900**  An order that will be fully executed on receipt or immediately rejected. It will not rest in the order book. |
| Fill and Kill (FAK) | **#FS10014a\_S0601\_03000**  An order that will be fully or partially executed on receipt and remaining volume is immediately cancelled. It will not rest in the order book.  Fill and Kill is also referred as Immediate or Cancel (IoC). |
| Day | **#FS10014a\_S0601\_03100**  Orders with Day validity will remain in the market until:  1. End of the trade day, or  2. It is cancelled, or  3. The instrument expires. |
| Good till Date (GTD) | **#FS10014a\_S0601\_03200**  An order that remains in the market until:  1. It is fully executed,  2. It is cancelled, or  3. End of the trade day on the specified date of expiration.  4. The instrument expires.  **#FS10014a\_S0601\_03300**  GTD orders expiration not yet reached will be “reloaded” in the next trading day as described in Order Reload section.  **#FS10014a\_S0601\_03400**  GTD order must include an additional attribute Expiry Date to indicate the date of expiration.  **#FS10014a\_S0601\_03500**  Combination orders would support GTD. |
| Good till Cancelled (GTC) | **#FS10014a\_S0601\_03600**  An order that remains in the market until:  1. It is fully executed,  2. It is cancelled, or  3. The instrument expires.  **#FS10014a\_S0601\_03700**  GTC orders that remain in the market after end of trading day are “reloaded” to the order book the next trading day as described in Order Reload section.  **#FS10014a\_S0601\_03800**  Combination orders would support GTC. |

**Tooltips**

**#FS10014a\_S0601\_03900**

Tooltips can be defined on input fields:

| Column | Tooltips |
| --- | --- |
| Link | Link with other windows. |
| Instrument ID | Specifies the instrument for which the order should be entered. To select other instruments, start typing the Id and select the instrument in the drop-down. |
| Price | To increase or decrease the price, use arrow up/down or click the arrows to the right of the Price field. |
| Quantity | Specifies the total number of contracts. Increase or decrease the quantity by using arrow up/down on the keyboard or by clicking the arrows to the right of the Quantity field. Use Order Settings to set a default quantity. |
| ~~Yield TBC~~ | ~~TBC~~ |
| ~~Total Quantity TBC~~ | ~~TBC~~ |
| ~~Lot Type TBC~~ | ~~TBC~~ |
| Type | Specifies the type of order. The following types are supported: Limit, Auction. |
| Time Validity | Defines what order condition to use: Date - The order is valid until an expiration date, which you yourself can specify in the Until field. Day - The order is valid for the rest of the current business day. Good till Cancelled - The order is valid until the expiration of the instrument specified in the order. FaK - Fill and Kill; fill as much as possible of the order and delete the rest of it. FoK - Fill or Kill; fill the order in its entirety, or delete all of it. If you entered Good till Date as Validity type in the Time Validity field, a calendar will appear from which you can select a date. Use Order Settings to define a default value. |
| Expiry Date | The date until which the order is valid. If Validity type Good till Date is selected, a calendar will appear in this field from which you can select a date. |
| ~~Client Order ID~~ | ~~Specifies an unique identifier for the order assigned by the market participant.~~ |
| SMP Token | Specifies the SMP Token. |
| BCAN | Specifies Broker-Client Assigned Number. It is used to identify the order’s originator for market surveillance purposes. |
| Position Effect | Specifies the requested position which is either Open or Close. |
| Customer | Specifies the customer account to which the order belongs. If nothing is specified, the trade will end up in the default account. Use Order Settings to define a list of frequently used accounts. |
| ~~Executing Trader~~ | ~~Specifies a free text attached to the order. When it is available, market participants can submit Mass order cancel to cancel orders those match against this field.~~ |
| ~~Legal Entity Identifier~~ | ~~Enter Legal Entity Identifier. The global unique identifier used for counterparty identification.~~ |
| Customer Information | Specifies any arbitrary information concerning the order. Any information entered is of no logical importance and will not be interpreted in the system. Use Order Settings to define a list of frequently used values. |
| Give up | Select if the order should be given up. |
| Give up Participant | Select a give-up participant in the drop-down list, or manually enter a participant ID to which the trade shall be given up. Use Order Settings to define a list of participants to which give-ups are usually made to display in the drop-down. |
| Give up Account | Select an account ID in the drop-down or manually enter the account ID of the give-up participant if available. Use Order Settings to define a list of frequently used give up account IDs to display in the drop down. |
| ~~Incentive ID~~ | ~~Specifies an alphanumeric free text field with length as 5.~~ |
| ATID | Specifies the ATID. The ID is NOT allowed to change after order placement. |
| Tradable in AHT | Select if the order should participate trading in AHT session. |
| Inactive | Select if the order should be prepared before the market is opened or before activating your order in the market from the Local Inactive Orders view. |
| ~~COD~~ | ~~Select if the order is subject to COD.~~ |

**Read / Write Permission Behaviour**

**#FS10014a\_S0601\_04000**

| Permission | Behavior |
| --- | --- |
| Read | User can open the window but not able to submit new Orders. |
| Write | User with write permission can fill in and submit a new Order. |

**Action**

1. **Link**

**#FS10014a\_S0601\_04100**

This option will Link the Enter Order window with other windows.

When selected, the system will automatically update the selected instrument ID from the linked windows.

Otherwise, the instrument ID can be input manually.

When linked with other windows:

1. **#FS10014a\_S0601\_04201** Clicking at a prevailing market price or quantity in the **Linked Price Information** window, the Instrument ID, Price & Quantity field will be automatically filled in with the prevailing market price and quantity at the time of clicking. Also reset the order type to limit.
2. **#FS10014a\_S0601\_04300** Clicking a record in **Order Depth** / **Price Depth** / **Enter Trade Report** / **Enter Tailor Made Combination** / **Quotes** will update the Instrument ID and reset the Price & Quantity field.

**#FS10014a\_S0601\_04410**

Enter Order window is allowed to enable the **Link** option. System will block user from enable the **Link** option on more than one Enter Order window.

And, in case there are multiple windows opened (e.g. Price Information / Order Depth / Price Depth, etc), clicking the records on those windows will trigger the update to the same Enter Order window which has the **Link** option enabled.

1. **~~Export as CSV File~~** ~~# BRD\_DT\_0049\_030\_02600 / # BRD\_DT\_0049\_030\_02100~~

~~The users can click "~~**~~Export to CSV File~~**~~" to export those records from GUI table.~~

1. **~~Import~~** ~~# BRD\_DT\_0049\_030\_02600~~

~~Import the order detail from a CSV file. This CSV file should contain only one row of record. Once imported, the content of the CSV file will be filled to the Enter Order page.~~

~~The CSV file should contain the following fields:~~

*~~"Instrument ID", "Price", "Quantity", "Type", "Time Validity", "Expiry Date", "Client Order ID", "SMP Token", "BCAN", "Position Effect", "Customer", "Executing Trader", "Legal Entity Identifier", "Customer Information", "Give up radio button", "Give up Participant", "Give up Account", "Tradable in AHT ", "Inactive"~~*

~~All the fields in the Enter Order window will be overridden by the values in the CSV file. (Including Instrument ID which was populated from the linked window.)~~

~~Confirmation box~~

1. **Buy**

**#FS10014a\_S0601\_04500**

User with write permission can fill in the Enter Order form and submit a new Buy Order. The order will be submitted to the Buy (Bid) side of the order-book.

**#FS10014a\_S0601\_04600**

Confirmation box will be prompted with the following text when user click on the Buy button.

*Confirm buy order.*

The buy order will be submitted when user clicks OK on the confirmation box. Refer to confirmation setting

**#FS10014a\_S0601\_04700**

No matter the enter order is linked up with the price information window or not, the fields except price and quantity could be kept with last order place record as the template to enter a new order.

1. **Sell**

**#FS10014a\_S0601\_04800**

User with write permission can fill in the Enter Order form and submit a new Sell Order. The order will be submitted to the Sell (Ask or Offer) side of the order-book.

**#FS10014a\_S0601\_04900**

Confirmation box will be prompted with the following text when user click on the Sell button.

*Confirm sell order.*

The sell order will be submitted when user clicks OK on the confirmation box. Refer to confirmation setting

**#FS10014a\_S0601\_05000**

No matter the enter order is linked up with the price information window or not, the fields except price and quantity could be kept with last order place record as the template to enter a new order.

1. **Clear**

**#FS10014a\_S0601\_05100**

Reset the values to default value.

If default values had been defined in Order Settings, those fields will be reset to the default value according to the setting.

If the Enter Order window had been linked with other windows, all the fields will be reset to default value except Instrument ID, Price and Quantity.

**Validation**

1. **First Trading Day Validation**
   1. **#FS10014a\_S0601\_05200** Matching Engine to perform the validation and GUI to display the rejection message.
2. **Enter Order Validation**
3. **#FS10014a\_S0601\_05300** When **Type** is **Market or Market to Limit**, **Price** should be 0.00 and not editable.
4. **#FS10014a\_S0601\_05400** If **Time** **Validity** is **Date**, the date specified in **Expiry Date** should not out of the instrument expiration date. Perform validation when lost focus or click on Buy/Sell button.
5. ~~If any invalid account is entered in the Customer field, it will fall to default account set in clearing side, e.g. account. # BRD\_DT\_0049\_030\_04600 (Comment)~~
6. **#FS10014a\_S0601\_05500** Instrument ID field validation:
   1. **#FS10014a\_S0601\_05600** The Instrument ID exists in the system. Perform validation when lost focus or click on Buy/Sell button.
   2. ~~The state of the Instrument ID is available for trading, i.e., the instrument is not in suspended or halt state. #FS10002\_S0020\_01300~~
7. **#FS10014a\_S0601\_05700** Price field validation:
   1. **#FS10014a\_S0601\_05800** Perform Premium price % based on Deviation Setting. Perform validation when lost focus or click on Buy/Sell button
   2. **#FS10014a\_S0601\_05901** Base on price tick to perform up and down adjustment (No need to check for dynamic price limit in GUI). Perform price tick validation when lost focus or click on Buy/Sell button
   3. ~~The price format is defined per product, with total 18 digits and configurable decimal place, negative supported. The default is 12 decimal numbers plus 6 decimal places. #FS10002\_S0020\_03200~~
8. **#FS10014a\_S0601\_06000** SMP Token validation
9. **#FS10014a\_S0601\_06100** Quantity field validation:
   1. **#FS10014a\_S0601\_06200** Quantity must be larger than 0 and not exceed a system limit of 9 digits value. Perform validation when lost focus or click on Buy/Sell button
   2. **#FS10014a\_S0601\_06300** Perform Max Volume check base on Deviation Setting and perform validation when lost focus or click on Buy/Sell button
   3. ~~There are limit settings for each Instrument Type including Combination in both firm level and user level. For detail, please refer to Order Management FS. #FS10002\_S0020\_04300~~
10. ~~Orders submitted in AHT session must have Tradable in AHT indicator enabled. #FS10002\_S0020\_21400~~
11. ~~First trading day validation???~~

**User Notification**

**#FS10014a\_S0601\_06400**

* Refer to UI Confirmation Setting
* Success if order is created successfully
* Error Notification if order is rejected

## Change Order

**Description**

**#FS10014a\_S0602\_00100**

This function is applicable to External only.

When client double click his own order from order book window, ~~order depth window (the order is placed by user)~~ or Local Inactive Orders window, the change order dialog will popup to screen along with the selected order information.

For editable and non-editable fields in change order dialog, please refer to attributes table for detail.

**Accessing the Function**

**#FS10014a\_S0602\_00200**

To bring up the Change Order dialog, users can double click an active or inactive order in the Order Book, ~~Order Depth~~ or Local Inactive Orders window.

~~It is possible to change the orders of other users in the same company. If an order is changed by another user, the original identity of the order will then be changed to the changer’s identity.~~

Users can only change their own order, changing the orders of other users in the same/different company is not allowed.

**#FS10014a\_S0602\_00300**

Only one Change Order dialog can be opened at a time in ODP Online. New Change Order dialog will always replace the content of the existing Change Order dialog~~.~~

**UI Layout**

**#FS10014a\_S0602\_00400**

Refer to Enter Order

“Link” checkbox and BCAN field is not required in change order dialog.

**Attributes**

**#FS10014a\_S0602\_00500**

For detail of definition of the Columns, please refer to Enter Order function.

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| **Standard Attributes** | | | | | |
| Order ID | Alphanumeric  **Read only Text Label** | - | M | - | **#FS10014a\_S0602\_00600**  Order ID is an ID assigned by ODP to unique identify an order.  **#FS10014a\_S0602\_00700**  It will be sent to the order originator when an order is accepted by the system.  **\* Not editable** |
| Instrument ID | Alphanumeric  **Text Input (with Content Assist)** | 32 | M | - | **#FS10014a\_S0602\_00800**  Tradable Instrument Identifier.  **\* Not editable** |
| Price | Price  **Text Input (With up / down per tick unit)** | [Ref to Data Type](#_Data_Type) | M | - | **#FS10014a\_S0602\_00900**  The limit price. An order is to be matched at the limit price or better. |
| Quantity | Quantity  **Text Input**  **(With up / down per tick size)** | [Ref to Data Type](#_Data_Type) | M | - | **#FS10014a\_S0602\_01000**  The maximum executable quantity per order specification depends on the Validity. |
| ~~Yield~~ | ~~TBC~~ | ~~TBC~~ | ~~TBC~~ | ~~TBC~~ | ~~TBC~~  ~~The Price field above could be changed to yield.~~ |
| ~~Total Quantity~~ | ~~TBC~~ | ~~TBC~~ | ~~TBC~~ | ~~TBC~~ | ~~TBC~~  ~~This is for future planning that when we support Iceberg order.~~ |
| ~~Lot Type~~ | ~~TBC~~ | ~~TBC~~ | ~~TBC~~ | ~~TBC~~ | ~~TBC~~  ~~Lot type specify order quantity relative to the instrument lot size.~~ |
| Type | Alphanumeric  **Dropdown** | - | M | Limit Order | **#FS10014a\_S0602\_01100**  This is the order type. |
| Time Validity | Alphanumeric  **Dropdown** | - | M | Day | **#FS10014a\_S0602\_01200**  This is the order validity which defines what order condition to use.  Change the validity time (between Day, GTC, GTD). Day order can change to GTC/GTD, vice versa.  But it cannot be changed to FAK, FOK. |
| Expiry Date | Date  **Date Selection Drop Down** | - | M/O | - | **#FS10014a\_S0602\_01300**  Indicate the date of expiration when Time Validity is GTD. |
| ~~Client Order ID~~ | ~~Alphanumeric~~  **~~Text Input~~** | ~~TBC~~ | ~~O~~ | ~~-~~ | ~~Unique identifier for the order assigned by the market participant.~~ |
| SMP ID | Alphanumeric  **Text Input**  **(with Content Assist)** | 21 | O | - | **#FS10014a\_S0602\_01400**  The SMP ID is to prevent from being matched to an opposite order if both buy and sell orders for the trade contain the same SMP ID. |
| ~~BCAN~~ | ~~Alphanumeric~~  **~~Text Input~~** | ~~17~~ | ~~O~~ | ~~-~~ | ~~The BCAN attribute is a pass-through attribute. It is used to identify the order’s originator for market surveillance purposes.~~ |
| Position Effect | Alphanumeric  **Dropdown** | - | O | Open | **#FS10014a\_S0602\_01500**  Position Effect is a pass-through attribute. It allows market participants to specify either opening or closing of position for clearing procedure. |
| Customer | Alphanumeric  **Text Input**  **(With Content Assist)** | 10 | O | - | **#FS10014a\_S0602\_01600**  The name or ID of a market participant’s client.  Refer to Enter Order |
| ~~Executing Trader~~ | ~~Alphanumeric~~  **~~Text Input~~** | ~~TBC~~ | ~~O~~ | ~~-~~ | ~~Executing Trader is a free text attribute attached to the order.~~ |
| **Pass-through Attributes** | | | | | |
| ~~Legal Entity Identifier~~ | ~~Alphanumeric~~  **~~Text Input~~**  **~~(With Content Assist)~~** | ~~20~~ | ~~O~~ | ~~-~~ | **~~#FS10014a\_S0602\_01700~~**  ~~The Legal Entity Identifier.~~ |
| Customer Information | Alphanumeric  **Text Input** | 15 | O | - | **#FS10014a\_S0602\_01800**  This field is updated with the customer information.  Refer to Enter Order |
| Give up radio button | Boolean  **Radio Button** | 1 | O | No | **#FS10014a\_S0602\_01900**  Indicate whether give is enabled or not. |
| Give up Participant | Alphanumeric  **Text Input**  **(with Content Assist)** | 5 | O | - | **#FS10014a\_S0602\_02000**  It lists the company code of the give up party.  Refer to Enter Order |
| Give up Information | Alphanumeric  **Text Input**  **(with Content Assist)** | 15 | O | - | **#FS10014a\_S0602\_02100**  The Arbitrary text information concerning the give up order.  Refer to Enter Order |
| ~~Incentive ID~~ | ~~Alphanumeric~~  **~~Text Input~~** | ~~5~~ | ~~O~~ | ~~-~~ | ~~Incentive ID. Alphanumeric free text field with length as 5.~~  **~~\* Not editable~~** |
| ATID | Alphanumeric | 5 | O | - | **#FS10014a\_S0602\_02200**  The ATID. The ID is NOT allowed to change after order placement.  **\* Not editable** |
| **Order Attributes** | | | | | |
| Tradable in AHT | Boolean  **Switch** | 1 | O | False | **#FS10014a\_S0602\_02300**  The indicator specifies whether an order should participate trading in AHT session.  **\* Not editable** |
| Inactive | Boolean  **Switch** | 1 | O | False | **#FS10014a\_S0602\_02400**  Order with this attribute will be stored in local inactive order window. |
| COD | Boolean  **Checkbox** | 1 | O | True | This indicator specifies whether the order is subject to COD.  **~~\* Not editable~~** |

**Tooltips**

**#FS10014a\_S0602\_02500**

Tooltips in the Change Order page is the same as the Enter Order page.

**Read / Write Permission Behaviour**

**#FS10014a\_S0602\_02600**

| Permission | Behavior |
| --- | --- |
| Read | User can view the detail of the Order |
| Write | User can submit a change to own Order. |

**Action**

1. **~~Export as CSV File~~** ~~# BRD\_DT\_0049\_030\_02100~~

~~The users can click "~~**~~Export to CSV File~~**~~" to export those records from GUI table.~~

1. **Buy**

**#FS10014a\_S0602\_02700**

If the original Order is a Buy Order, User can update the detail of the Order and click the Buy button to amend the Buy Order.

Note that if the Order is a Sell Order, the Buy button will be disabled.

**#FS10014a\_S0602\_02800**

Confirmation box will be prompted with the following text when user click on the Buy button.

*Confirm amend buy order.*

The buy order will be submitted when user clicks OK on the confirmation box.

1. **Sell**

**#FS10014a\_S0602\_02900**

If the original Order is a Sell Order, User can update the detail of the Order and click the Sell button to amend the Sell Order.

Note that if the Order is a Buy Order, the Sell button will be disabled.

**#FS10014a\_S0602\_03000**

Confirmation box will be prompted with the following text when user click on the Sell button.

*Confirm amend sell order.*

The sell order will be submitted when user clicks OK on the confirmation box.

**Additional confirmation due to Priority change**

The following changes will lead to losing order priority:

1. **#FS10014a\_S0602\_03100** Increase quantity.
2. **#FS10014a\_S0602\_03200** Change price.
3. **#FS10014a\_S0602\_03300** Change SMP token field.

**#FS10014a\_S0602\_03400**

The following additional text will be display in the confirmation box when user click on the Buy / Sell button.

*Confirm the amendment with losing order priority.*

**Validation**

1. **Change Order Validation**

The following changes are not allowed:

1. **#FS10014a\_S0602\_03500** Change Order of others
2. **#FS10014a\_S0602\_03700** Change from a bid order to an ask order and vice versa.
3. **#FS10014a\_S0602\_03800** Change the order validity time to FOK or FAK. (note that day, GTC, GTD are allowed to change)
4. **#FS10014a\_S0602\_03900** Change the exchange order type and **AHT flag**.

Change Order is not allowed under the following condition:

1. **#FS10014a\_S0602\_04000** If a GTD/GTC order has Tradable in AHT indicator disabled, during AHT session the order will be suspended and moved to non-public order book where only cancellation is allowed.

**#FS10014a\_S0602\_04100** For TMC order, the following changes are only allowed:

1. **#FS10014a\_S0602\_04200** Change of net price.
2. **#FS10014a\_S0602\_04300** Chang in quantity
3. **#FS10014a\_S0602\_04400** Modification of information in Customer field.
   1. **#FS10014a\_S0602\_04500** Allow amendment after partially filled
4. **#FS10014a\_S0602\_04600** Modification of information in Information field.
   1. **#FS10014a\_S0602\_04700** Allow amendment after partially filled
5. **#FS10014a\_S0602\_04800** Modification of information in LEI field.
   1. **#FS10014a\_S0602\_04900** Allow amendment after partially filled
6. **#FS10014a\_S0602\_05000** Modification of information in SMP Token.

**#FS10014a\_S0602\_05100**

If users would like to make such changes (e.g. change the instrument series of each leg, their relative ratios, as well as buy or sell position of each leg), they need to cancel the TMC order first, then create a new TMC series or enter a new TMC order with the desired changes.

**Order had been matched when attempts to change the order**

**#FS10014a\_S0602\_05200**

When the user attempts to change the order and the selected order has been partially matched or fully matched, a warning message will be prompted to ask for user’s confirmation with the following message.

Warning: order may have traded while editing. You should update order details before proceeding. Do you wish to continue without confirming details?

User can confirm to continue by clicking the OK button. Or click the Cancel button to stop submitted the change.

**User Notification**

**#FS10014a\_S0602\_05300**

Refer to UI Confirm

## Execute Order

**Description**

**#FS10014a\_S0603\_00100**

This function is applicable to External only.

When client double click an order from price information, price depth, order depth (regardless own order or not) and quotes window, the execute order dialog will be pop up with relative price and quantity, the order validity is FAK or FOK.

**~~\*Attention\*~~** ~~By nature, the functionality of the Execute Order dialog is for users to execute order with the maximum available quantity in the market at the price specified in the Price field. Therefore, changing the price itself may result in a trade with a different quantity from what is specified in the “Quantity” field when the window was originally opened. If users have the intention to change the price, they should use the Enter Order window instead.~~

**Accessing the Function**

**#FS10014a\_S0603\_00200**

The Execute Order dialog can be opened from several windows (Price Information, Quotes, Price Depth and Order Depth windows) by double-clicking a price or a quantity of an instrument series.

**#FS10014a\_S0603\_00300**

Only one Execute Order dialog is allowed in ODP Online. New Execute Order dialog will always replace the content of the existing Execute Order dialog.

**UI Layout**

**#FS10014a\_S0603\_00400**

Refer to Enter Order UI Layout.

“Link” checkbox is not required in Execute order dialog.

**Attributes**

**#FS10014a\_S0603\_00500**

For detail of definition of the Columns, please refer to Enter Order function.

| Column | Type | Length | M/O | | Default | | Remarks |
| --- | --- | --- | --- | --- | --- | --- | --- |
| **Standard Attributes** | | | | | | | |
| Instrument ID | Alphanumeric  **Text Input (with Content Assist)** | 32 | M | - | | The Instrument series ID.  The ID field is locked to the instrument that was double clicked in the Price Information window.  **\* Not editable** | |
| Price | Price  **Text Input (With up / down per tick unit)** | [Ref to Data Type](#_Data_Type) | M | - | | The limit price. An order is to be matched at the limit price or better. | |
| Quantity | Quantity  **Text Input**  **(With up / down per tick size)** | [Ref to Data Type](#_Data_Type) | M | - | | The maximum executable quantity per order specification depends on the Validity. | |
| ~~Yield~~ | ~~TBC~~ | ~~TBC~~ | ~~TBC~~ | ~~TBC~~ | | ~~TBC~~  ~~The Price field above could be changed to yield.~~ | |
| ~~Total Quantity~~ | ~~TBC~~ | ~~TBC~~ | ~~TBC~~ | ~~TBC~~ | | ~~TBC~~  ~~This is for future planning that when we support Iceberg order.~~ | |
| ~~Lot Type~~ | ~~TBC~~ | ~~TBC~~ | ~~TBC~~ | ~~TBC~~ | | ~~TBC~~  ~~Lot type specify order quantity relative to the instrument lot size.~~ | |
| Type | Alphanumeric  **Dropdown** | - | M | Limit Order | | This is the order type.  Must be Limit Order.  **\* Not editable** | |
| Time Validity | Alphanumeric  **Dropdown** | - | M | FAK | | This is the order validity which defines what order condition to use.  **Only FOK and FAK are allowed.** | |
| Expiry Date | Date  **Date Selection Drop Down** | - | M/O | - | | ~~Showing as Today.~~  **\* Not editable** | |
| ~~Client Order ID~~ | ~~Alphanumeric~~  **~~Text Input~~** | ~~TBC~~ | ~~O~~ | ~~-~~ | | ~~Unique identifier for the order assigned by the market participant.~~ | |
| SMP ID | Alphanumeric  **Text Input**  **(with Content Assist)** | 21 | O | - | | The SMP ID is to prevent from being matched to an opposite order if both buy and sell orders for the trade contain the same SMP ID. | |
| BCAN | Alphanumeric  **Text Input** | 17 | M | - | | The BCAN attribute is a pass-through attribute. It is used to identify the order’s originator for market surveillance purposes. | |
| Position Effect | Alphanumeric  **Dropdown** | - | O | Open | | Position Effect is a pass-through attribute. It allows market participants to specify either opening or closing of position for clearing procedure. | |
| Customer | Alphanumeric  **Text Input**  **(With Content Assist)** | 10 | O | - | | The name or ID of a market participant’s client.  Refer to Enter Order | |
| ~~Executing Trader~~ | ~~Alphanumeric~~  **~~Text Input~~** | ~~TBC~~ | ~~O~~ | ~~-~~ | | ~~Executing Trader is a free text attribute attached to the order.~~ | |
| **Pass-through Attributes** | | | | | | | |
| ~~Legal Entity Identifier~~ | ~~Alphanumeric~~  **~~Text Input~~**  **~~(With Content Assist)~~** | ~~20~~ | ~~O~~ | ~~-~~ | | ~~The Legal Entity Identifier.~~ | |
| Customer Information | Alphanumeric  **Text Input** | 15 | O | - | | This field is updated with the customer information.  Refer to Enter Order | |
| Give up radio button | Boolean  **Radio Button** | 1 | O | No | | Indicate whether give is enabled or not. | |
| Give up Participant | Alphanumeric  **Text Input**  **(with Content Assist)** | 5 | O | - | | It lists the company code of the give up party.  Refer to Enter Order | |
| Give up Information | Alphanumeric  **Text Input**  **(with Content Assist)** | 15 | O | - | | The Arbitrary text information concerning the give up order.  Refer to Enter Order | |
| ~~Incentive ID~~ | ~~Alphanumeric~~  **~~Text Input~~** | ~~5~~ | ~~O~~ | ~~-~~ | | ~~Incentive ID. Alphanumeric free text field with length as 5.~~ | |
| ATID | Alphanumeric | 5 | O | - | | The ATID. The ID is NOT allowed to change after order placement. | |
| **Order Attributes** | | | | | | | |
| Tradable in AHT | Boolean  **Switch** | 1 | O | False | | The indicator specifies whether an order should participate trading in AHT session. | |
| Inactive | Boolean  **Switch** | 1 | O | False | | Order with this attribute will be stored in local inactive order window.  **\* Not editable** | |
| COD | Boolean  **Checkbox** | 1 | O | True | | This indicator specifies whether the order is subject to COD. | |

**Tooltips**

**#FS10014a\_S0603\_00600**

Tooltips in the Execute Order page is the same as the Enter Order page.

**Read / Write Permission Behaviour**

**#FS10014a\_S0603\_00700**

| Permission | Behavior |
| --- | --- |
| Read | N/A |
| Write | User with write permission can fill in and submit a new Order. |

**Action**

1. **~~Export as CSV File~~** ~~# BRD\_DT\_0049\_030\_02100~~

~~The users can click "~~**~~Export to CSV File~~**~~" to export those records from GUI table.~~

1. **Buy**

**#FS10014a\_S0603\_00800**

If user double clicks on the **ask** price or quantity in Price Information Window, then user is allowed to place a Buy order only.

At the same time, the Sell button will be disabled.

**#FS10014a\_S0603\_00900**

Confirmation box will be prompted with the following text when user click on the Buy button.

*Confirm buy order.*

The buy order will be submitted when user clicks OK on the confirmation box.

1. **Sell**

**#FS10014a\_S0603\_01000**

If user double clicks on the **bid** price or quantity in Price Information Window, then user is allowed to place a Sell order only.

At the same time, the Buy button will be disabled.

**#FS10014a\_S0603\_01100**

Confirmation box will be prompted with the following text when user click on the Sell button.

*Confirm sell order.*

The sell order will be submitted when user clicks OK on the confirmation box.

**Validation**

1. **First Trading Day Validation**
   1. **#FS10014a\_S0603\_01200** Matching Engine to perform the validation and GUI to display the rejection message.
2. **Execute Order Validation**
3. **#FS10014a\_S0603\_01300** Only FOK or FAK orders are available.

**User Notification**

**#FS10014a\_S0603\_01400**

* Refer to UI Confirmation Setting

## Order Book

**Description**

**#FS10014a\_S0604\_00100**

This function is applicable to both External and Internal.

1. **#FS10014a\_S0604\_00200** External

This window allows users to manage their own orders in the Order Book, such as cancelling, changing, and inactivating orders. Users can only view or cancel orders of others under the same participant in real time.

1. **#FS10014a\_S0604\_00300** Internal

This window shows open orders of all participants that are currently exposing to the market in snapshot basis (No auto update) and they can perform cancel orders on behalf of clients if required however these cancel request requires second user approval.

**Accessing the Function**

**#FS10014a\_S0604\_00400**

Order Book window can be opened from the menu. ODP Online allows only one Order Book window for internal user and four Order Book windows for external user.

**Scope of Data**

**#FS10014a\_S0604\_00500**

The records displayed in this window is different between External and Internal:

1. **#FS10014a\_S0604\_00600** External

This window is used to display and manage user’s own latest orders or latest orders within the company. The order book displays all the orders placed by the participant who the user belongs to, and trading right is not considered for display.

1. **#FS10014a\_S0604\_00700** Internal

This window is used to display latest open orders and latest quotes of ALL participants that are currently exposing to the market.

User can filter the orders of a specific participant by using the filter.

**#FS10014a\_S0604\_00800**

The Order Book table can display up to 60K lines of latest records.

**#FS10014a\_S0604\_00900**

For external user, this view will automatically update upon any changes of the orders and the order will disappear when it is completely matched or cancelled or inactivating by user.

~~While if the order is inactivated due to cancel on disconnect mechanism, the order is marked in brown in order book. # BRD\_DT\_0049\_030\_07700~~

**UI Layout (External)**

**#FS10014a\_S0604\_01000**

![](data:image/png;base64...)

External user can click on Own Checkbox to show his own orders only. Highlight orders of other users with a light blue color in order to show the different of own orders. The order table shows all order of the user’s participant by default when first open.

**UI Layout (Internal)**

**#FS10014a\_S0604\_01100**

![](data:image/png;base64...)

Internal User can select ALL participants or no more than five target participants to perform a snapshot query. The order table is empty when first open until a snapshot is requested.

**Attributes**

**#FS10014a\_S0604\_01200**

**For detail of definition of the Columns, please refer to Enter Order function.**

| Column | Type | Remarks |
| --- | --- | --- |
| ID | Alphanumeric | The Instrument Series ID. |
| B QTY | Quantity | The quantity if a bid order. |
| A QTY | Quantity | The quantity if an ask order. |
| PRC | Price | The price of the order. |
| TYPE | Alphanumeric | The order type. |
| VALID | Alphanumeric | The validity of the order. |
| EXPIRY | Date | The date or other details on which the order expires. |
| ~~PRT~~ | ~~Alphanumeric~~ | ~~Participant on whose behalf the order was entered.~~ |
| GUP | Alphanumeric | The company identity of the Give Up client. |
| G ACC | Alphanumeric | The give-up account for a give-up order. |
| CUST | Alphanumeric | The customer of the order.  (C, H, Rxxxx, A1, P1 or M1). |
| ~~TRD >~~ COMPID | Alphanumeric | ~~The trader.~~ CompId of binary client |
| I | Alphanumeric | Indicate if it is an inactive or active order. |
| AHT | Alphanumeric | Indicate if it is a AHT order or not. |
| CNV | Alphanumeric | Indicate if it is a converted Market Order. Order that is converted from a market order to limit order or inactive order after the pre-opening period with be marked with a “Yes” in this column. |
| INFO | Alphanumeric | Any arbitrary information concerning the order. The information displayed is of no logical importance and is not interpreted in the system. |
| ~~LEI~~ | ~~Alphanumeric~~ | ~~The legal entity identifier.~~ |
| C ORD ID | Alphanumeric | Client Order ID assigned by the market participant. |
| ~~BCAN~~ | ~~TBC~~ | ~~The Broker-Client Assigned Number.~~ |
| SMP | Alphanumeric | The SMP Token. |
| ~~Incentive ID~~ | ~~Alphanumeric~~ | ~~Incentive ID. Alphanumeric free text field with length as 5.~~ |
| ATID | Alphanumeric | The ATID. The ID is NOT allowed to change after order placement. |
| COD | Alphanumeric | This indicator specifies whether the order is subject to COD. |
| RP | Alphanumeric | The requested position, that is, open or close. |
| ORDER NO | Alphanumeric | The order number received from the Marketplace. |
| ~~O CAT~~ | ~~Alphanumeric~~ | ~~The order category.~~  ~~For example, Electronic Marketplace (EMP).~~ |
| CREATED | Date Time | The time at which the order was created. |
| CHANGED | Date Time | The time of the latest order change. |
| ERROR | Alphanumeric | The failure reason if the last command failed. |
| UL ID | Alphanumeric | The underlying ID. |
| ~~UL~~ | ~~Alphanumeric~~ | ~~The underlying name.~~ |
| ~~MKT~~ | ~~Alphanumeric~~ | ~~The market.~~ |
| ~~INST TYPE~~ | ~~Alphanumeric~~ | ~~The instrument Type.~~ |
| ~~INST GROUP TYPE~~ | ~~Alphanumeric~~ | ~~The instrument Group Type.~~ |

**Tooltips**

**#FS10014a\_S0604\_01300**

| Column | Tooltips |
| --- | --- |
| ID | Specifies the instrument identity. |
| B QTY | Specifies the quantity if a bid order. |
| A QTY | Specifies the quantity if an ask order. |
| PRC | Specifies the price of the order. |
| TYPE | Specifies the order type. |
| VALID | Specifies the validity of the order. |
| EXPIRY | Specifies the date or other details on which the order expires. |
| ~~PRT~~ | ~~Specifies the participant on whose behalf the order was entered.~~ |
| GUP | Indicates that the order is a give-up order. |
| G ACC | Specifies a give-up account for a give-up order. |
| CUST | Specifies the customer of the order. |
| ~~TRD >~~ COMPID | Specifies the comp ID. |
| I | Specifies if it is an inactive or active order. A tick indicates an inactive order. |
| AHT | Specifies a AHT order. |
| ~~CNV~~ | ~~Specifies a converted Auction Order.~~ |
| INFO | Specifies any arbitrary information concerning the order. The information displayed is of no logical importance and is not interpreted in the system. |
| LEI | Specifies the legal entity identifier. |
| C ORD ID | Specifies the Client Order ID assigned by the market participant. |
| ~~BCAN~~ | ~~Specifies the Broker-Client Assigned Number.~~ |
| SMP | Specifies the SMP Token. |
| ~~Incentive ID~~ | ~~Specifies an alphanumeric free text field with length as 5.~~ |
| ATID | Specifies the ATID. |
| COD | Specifies if the order is subject to COD. |
| RP | Specifies the requested position, that is, open or close. |
| ORDER NO | Specifies the order number received from the Marketplace. |
| ~~O CAT~~ | ~~Specifies the order category.~~ |
| CREATED | Specifies the time at which the order was created. |
| CHANGED | Specifies the time of the latest order change. |
| ERROR | Specifies the failure reason if the last command failed. |
| UL ID | Specifies the underlying ID. |
| ~~UL~~ | ~~Specifies the underlying.~~ |
| ~~MKT~~ | ~~Specifies the market.~~ |
| ~~INST TYPE~~ | ~~Specifies the instrument type.~~ |
| ~~INST GROUP TYPE~~ | ~~Specifies the instrument group type.~~ |

**Data refresh in table**

**#FS10014a\_S0604\_01400**

For Internal user, order book view will not update order automatically and user need to click on Apply to query a new snapshot.

For External user, order book view will automatically update upon any changes of the orders.

**Default Sorting Order**

**#FS10014a\_S0604\_01500**

The Order Book windows is sorted by order creation time in ascending by default.

**Filtering Criteria**

**#FS10014a\_S0604\_01600**

Following filter fields are available for criteria search.

Display right above the table

| Filtering Criteria | Type |
| --- | --- |
| **#FS10014a\_S0604\_01700** Inst. ID | Text Input (with Content Assist) |
| **#FS10014a\_S0604\_01900** Participants | Text Input (with Content Assist)  \* **Applicable to Internal only (User can select ALL in this field to take a snapshot of all open orders from all participants in the market)** | |
| **#FS10014a\_S0604\_02000** Own | Checkbox  Available for external user only. User can filter own orders or all orders of their company. | |

**#FS10014a\_S0604\_02101**

[Revoked]

**Read / Write Permission Behaviour**

**#FS10014a\_S0604\_02200**

| Permission | Behavior |
| --- | --- |
| Read | User can perform the following:   * View all the data in the Order Book Table * Perform Sorting/Filtering on the Order Book Table * Export Order Book table as CSV File |
| Write | User can perform the following:   * Change an Order **(\*Applicable to External only)** * Cancel Orders (\*Second approval is required for Internal user) * Inactivate Orders Locally **(\*Applicable to External only)** |

**Action**

1. **Apply**

**#FS10014a\_S0604\_02300**

For both Internal and External User, click on Apply perform a new query request and show the result based upon filtering criteria. No more than 1 query per second is limited by GUI.

1. **Change Order (\*Applicable to External only)**

**#FS10014a\_S0604\_02400**

User can select an own order from the Order Book table and click the **Change Order** option from the **More Actions** menu to change an Order.

It will bring up the Change Order dialog for the selected Order.

User can only select one Order at a time for Change Order.

**#FS10014a\_S0604\_02500**

If a GTC/GTD order has **Tradable in AHT** indicator disabled, during AHT session the order will be suspended and moved to non-public order book where only cancellation is allowed.

1. **Cancel Order**
2. External

**#FS10014a\_S0604\_02600**

User can select one or more Orders from the Order Book table and click the **Cancel Order** button to cancel the selected Orders.
The selected orders are removed from order book after that.

**#FS10014a\_S0604\_02700**

User can cancel the orders placed by their participant.

**#FS10014a\_S0604\_02800**

For example the order placed by binary protocol user but under the same participant will be displayed in the Online GUI order book and the Online GUI user is able to cancel the orders placed by other users who are under the same participant, vice versa that user login via binary protocol can be visible to the order placed by the ODP Online GUI under the same participant via drop copy session.

1. Internal

**#FS10014a\_S0604\_02900**

Exchange operation have the capability to cancel the order on behalf of the EP via internal ODP online GUI by sorting the concerned EP’s orders in the Order Book window.

**#FS10014a\_S0604\_03000**

Exchange operation can first filter the Order of the participant and select one or more Orders from the Order Book table and click the **Cancel Order** button to cancel the selected Orders on behalf of the EP.

**#FS10014a\_S0604\_03100**

Confirmation box will be prompted with the following text when user click on the **Cancel Order** option.

*Confirm cancel orders. Found x order(s) to be deleted.*

The cancel order will be submitted when user clicks OK on the confirmation box and wait for second user approval.

1. **Cancel all Orders**
2. External

**#FS10014a\_S0604\_03200**

Similar to Cancel Order, user can click the **Cancel all Orders** button to cancel all the orders within the same participant based on GUI filter displayed result, cancel request are throttled by GUI (e.g. no more than five cancel request per second)

The orders are now removed from the central and the order book.

**#FS10014a\_S0604\_03300**

User can cancel the orders placed by their participant.

1. Internal

**#FS10014a\_S0604\_03400**

Exchange operation have the capability to cancel the order on behalf of the EP via internal ODP online GUI by filtered the concerned EP’s orders in the Order Book window.

**#FS10014a\_S0604\_03500**

Exchange operation can first filter the Order of the participant and click the **Cancel all Orders** button to cancel all the orders within the same participant based on GUI filter displayed result.

**#FS10014a\_S0604\_03600**

Confirmation box will be prompted with the following text when user click on the **Cancel all Orders** option.

*Confirm cancel of all orders.*

The cancel order will be submitted when user clicks OK on the confirmation box. Cancel request are throttled by GUI (e.g. no more than five cancel request per second) and wait for second user approval.

1. **Inactivate locally (\*Appliable to External only)**

**#FS10014a\_S0604\_03700**

User can select one or more Orders from the Order Book table and click the **Inactivate locally** option from the **More Actions** menu to inactivate the selected Orders.

**#FS10014a\_S0604\_03800**
The orders selected will be cancelled and removed from the market and kept in the local Inactive Orders window for those remaining quantity. (Inactivated orders are visible to owner only). When the number of local Inactive Orders meets the maximum Inactive Orders setting, GUI will reject this action along with the following notification:

*Number of inactive order exceeded.*

**#FS10014a\_S0604\_03900**

Confirmation box will be prompted with the following text when user click on the **Inactivate locally** option.

*Confirm inactivate locally of selected order(s).*

The inactivate locally will be submitted when user clicks OK on the confirmation box.

1. **Inactivate locally all (\*Appliable to External only)**

**#FS10014a\_S0604\_04000**

User can click the **Inactivate locally all** option from the **More Actions** menu to inactivate all the orders owned by the User. These orders will be cancelled and removed from the market and kept in the local Inactive Orders window.

**#FS10014a\_S0604\_04100**

Confirmation box will be prompted with the following text when user click on the **Inactivate locally all** option.

*Confirm inactivate locally of all orders.*

The inactivate order request will be submitted when user clicks OK on the confirmation box. Inactive requests are throttled by GUI (e.g. no more than five inactive request per second)

1. **Export to CSV file**

**#FS10014a\_S0604\_04200**

The users can click "**Export to CSV File**" to export those records from GUI table.

1. **~~Export all to CSV file~~**

**~~#FS10014a\_S0604\_04201~~**

~~The users can click "~~**~~Export all to CSV File~~**~~" to export those records from server of the corresponding participant.~~

1. **Double click an Order (\*Appliable to External only)**

**#FS10014a\_S0604\_04300**

User can double click an own Order in the Order Book window to bring up the Change Order dialog for that Order.

**#FS10014a\_S0604\_04400**

The behaviour is the same as **Change Order** option. For detail, please refer to **Change Order** option.

**Validation**

1. **#FS10014a\_S0604\_04500** **Change Order**

External

1. Allow change own order only
2. **#FS10014a\_S0604\_04600** **Cancel Order**

External

1. One or more Orders must be selected.
2. Refer to confirmation setting

Internal

1. ~~Participant must be selected, and it should be equals to “ALL”.~~
2. One or more Orders must be selected.
3. Refer to confirmation setting
4. **#FS10014a\_S0604\_04700** **Cancel All Orders**

External

1. Refer to confirmation setting

Internal

1. ~~Participant must be selected, and it should be equals to “ALL”.~~
2. Refer to confirmation setting
3. **#FS10014a\_S0604\_04800** **Inactivate locally**
4. One or more Orders must be selected.
5. The Orders should be owned by the User.
6. Refer to confirmation setting
7. **#FS10014a\_S0604\_04900** **Inactivate locally all**
8. There are Orders owned by the User.
9. Refer to confirmation setting

**User Notification**

**#FS10014a\_S0604\_05001**

~~Success Notification – Change Order, Cancel Order and etc~~

Error Notification - Change Order, Cancel Order and etc

**Order Background Color**

**#FS10014a\_S0604\_05100**

Inactive order – display dim grey colour

Other owner order – display light blue colour

## Order History

**Description**

**#FS10014a\_S0605\_00100**

This function is applicable for External.

For internal users, they can export the order history of those on-behalf cancel order from admin UI.

~~For internal, given the BO5 from each participant is not sent back to HKFE, this window will not display any participant order history. #~~ ~~BRD\_DT\_0049\_030\_08900~~

**Accessing the Function**

**#FS10014a\_S0605\_00200**

Order History window can be opened from the menu. ODP Online allows only one Order History window to be opened for external user.

**Scope of Data**

**#FS10014a\_S0605\_00300**

The window displays the history of the user’s own orders and orders entered by other users of the company of today and trading right is not considered for display. When market turns into T + 1, it should still show those history from T session.

**#FS10014a\_S0605\_00400**

The maximum number of records in the Order History Table are 60,000 records.

If the number of records exceed 60,000, the Order History Table will always showing rolling latest 60,000 records in real time, old records will be removed.

**UI Layout**

**#FS10014a\_S0605\_00500**

![](data:image/png;base64...)

**Attributes**

**#FS10014a\_S0605\_00600**

| Column | Type | Remarks |
| --- | --- | --- |
| ACTION | Alphanumeric | Displays the action of the order.  Domain Value:  **New –** New active order  **Changed –** Order has been changed  **Delete –** Order has been cancelled  **Traded –** Order has been traded, fully or partially  **Reloaded** **–** Order has been reloaded  **Restated** **–** Order has been restated  **Inactivate –** Active order has been inactivated by system |
| CNV | Alphanumeric | Indicate if it is a converted Auction Order. Order that is converted from an auction order to limit order or inactive order after the pre-opening period with be marked with a “Yes” in this column. |
| TIME | TBC | The latest order change time |
| ID | Alphanumeric | The Instrument Series ID. |
| B QTY | Quantity | Buy quantity. |
| A QTY | Quantity | Sell quantity. |
| R QTY | TBC | Remain quantity. |
| TOTAL QTY | TBC | Total quantity. |
| LMT PRC | TBC | Limit Price |
| TYPE | Alphanumeric | The order type. |
| VALID | TBC | The validity of the order. |
| EXPIRY | TBC | The date or other details on which the order expires. |
| GUP | Alphanumeric | The company identity of the Give Up client. |
| G ACC | Alphanumeric | The give-up account for a give-up order. |
| CUST | Alphanumeric | The customer of the order.  (C, H, Rxxxx, A1, P1 or M1). |
| TRD | Alphanumeric | The trader. |
| AHT | Alphanumeric | Indicate if it is a AHT order or not |
| INFO | Alphanumeric | Any arbitrary information concerning the order. The information displayed is of no logical importance and is not interpreted in the system. |
| ~~LEI~~ | ~~Alphanumeric~~ | ~~The legal entity identifier.~~ |
| C ORD ID | Alphanumeric | Client Order ID assigned by the market participant. |
| ~~BCAN~~ | TBC | ~~The Broker-Client Assigned Number.~~ |
| SMP | Alphanumeric | The SMP Token. |
| C PART | Alphanumeric | The Counterpart Company. (Only applicable to T4 block trades) |
| CC | Alphanumeric | The Order condition code. |
| RP | Alphanumeric | The requested position, that is, open or close. |
| ORDER NO | Alphanumeric | The order number received from the Marketplace. |
| ~~Incentive ID~~ | ~~Alphanumeric~~ | ~~Incentive ID. Alphanumeric free text field with length as 5.~~ |
| ATID | Alphanumeric | The ATID. The ID is NOT allowed to change after order placement. |
| COD | Alphanumeric | This indicator specifies whether the order is subject to COD. |
| ~~O CAT~~ | ~~Alphanumeric~~ | ~~The order category.~~  ~~For example, Electronic Marketplace (EMP).~~ |
| REPLY | Alphanumeric | Reply received when the order was sent  to the market place. |
| DEL REASON | Alphanumeric | \*Refer to unsolicited cancel reason |
| ~~UL~~ | ~~Alphanumeric~~ | ~~The underlying name.~~ |
| ~~MKT~~ | ~~Alphanumeric~~ | ~~The market.~~ |

**Tooltips**

**#FS10014a\_S0605\_00700**

| Column | Tooltips |
| --- | --- |
| ACTION | Specifies the action of the order. |
| CNV | Specifies a converted Auction Order. |
| TIME | Specifies the order action time. |
| ID | Specifies the instrument identity. |
| B QTY | Specifies the quantity if a bid order. |
| A QTY | Specifies the quantity if an ask order. |
| R QTY | Specifies the remain quantity. |
| TOTAL QTY | Specifies the total quantity. |
| LMT PRC | Specifies the Limit Price. |
| TYPE | Specifies the order type. |
| VALID | Specifies the validity of the order. |
| EXPIRY | Specifies the date or other details on which the order expires. |
| GUP | Indicates that the order is a give-up order. |
| G ACC | Specifies a give-up account for a give-up order. |
| CUST | Specifies the customer of the order. |
| TRD | Specifies the trader, that is, the member at the exchange. |
| AHT | Specifies a AHT order. |
| INFO | Specifies any arbitrary information concerning the order. The information displayed is of no logical importance and is not interpreted in the system. |
| LEI | Specifies the legal entity identifier. |
| C ORD ID | Specifies the Client Order ID assigned by the market participant. |
| ~~BCAN~~ | ~~Specifies the Broker-Client Assigned Number.~~ |
| SMP | Specifies the SMP Token. |
| C PART | Specifies the Counterpart Company. |
| CC | Specifies the Order condition code. |
| RP | Specifies the requested position, that is, open or close. |
| ORDER NO | Specifies the order number received from the Marketplace. |
| ~~Incentive ID~~ | ~~Specifies an alphanumeric free text field with length as 5.~~ |
| ATID | Specifies the ATID. |
| COD | Specifies if the order is subject to COD. |
| ~~O CAT~~ | ~~Specifies the order category.~~ |
| REPLY | Specifies the Market reply. |
| DEL REASON | Specifies the delete reason. |
| ~~UL~~ | ~~Specifies the underlying.~~ |
| ~~MKT~~ | ~~Specifies the market.~~ |

**Data refresh in table**

**#FS10014a\_S0605\_00800**

Auto updated when orders are entered, changed, traded, and cancelled.

**Default Sorting Order**

**#FS10014a\_S0605\_00900**

The Order History windows is sorted by ascending order of order change time by default.

**Filtering Criteria**

**#FS10014a\_S0605\_01000**

Following filter fields are available for criteria search.

Display right above the table

| Filtering Criteria | Type |
| --- | --- |
| **#FS10014a\_S0605\_01100** Action | Dropdown  Available value:  **New –** New active order created or has been activated  **Changed –** Order has been changed  **Deleted –** Order has been cancelled or has been activated  **Traded –** Order has been traded, fully or partly  **Restated** **–** Order has been restated  **~~Inactivate –~~** ~~Active order has been inactivated by system~~  Reloaded – Reloaded GTC order |

**#FS10014a\_S0605\_01201**

[Revoked]

**Read / Write Permission Behaviour**

**#FS10014a\_S0605\_01300**

| Permission | Behavior |
| --- | --- |
| Read | User can perform the following:   * View all the data in the Order History Table * Perform Sorting/Filtering on the Order History Table * Export History Book table as CSV File |
| Write | Not applicable |

**Action**

1. **Export to CSV file**

**#FS10014a\_S0605\_01400**

The users can click "**Export to CSV File**" to export those records from GUI table.

1. **Export All to CSV file**

**#FS10014a\_S0605\_01500**

The users can click "**Export all to CSV File**" to export those records from server of current participant only.

**Validation**

**#FS10014a\_S0605\_01600**

N/A

**User Notification**

**#FS10014a\_S0605\_01700**

N/A

**Order Background Color**

Inactive order – display dim grey colour

Other owner order – display light blue colour

## Tailor-Made Combination

**Description**

**#FS10014a\_S0606\_00100**

The Tailor-Made Combination (TMC) function allows external users to define and place limit orders for futures and options strategies.

~~TMC series are valid on the trading day that they are created only and will be deleted by the end of the day.~~

**#FS10014a\_S0606\_00200**

TMC series are valid once created and support multiple days (configurable) with the following TMC expiration periods:

* One Day – TMC and outstanding orders are to be removed at DAYEND.
* One Week – TMC and outstanding orders are to be removed at DAYEND on the last trading day of the week of creation.
* Two Weeks – TMC and outstanding orders are to be removed at DAYEND on the last trading day of the second week of creation.
* Four Weeks – TMC and outstanding orders are to be removed at DAYEND on the last trading day of the fourth week of creation.

Above expiration periods should be supported by ME and Trading GUI just publish what TMC stored in CDB.

On top of this, there is limitation on the total no. of TMC allowed per participant – set it to 1000 for the time being (configurable).

**#FS10014a\_S0606\_00300**

Users may combine future and/or option contracts of the same underlying in a Tailor-Made Combination.

**#FS10014a\_S0606\_00400**

Once a TMC is created via the Enter Tailor-Made Combination window, it can be traded as a normal market series

**#FS10014a\_S0606\_00500**

Both TMC series and outstanding orders of TMC will be removed after a specific duration (configurable) TBC.

**Accessing the Function**

**#FS10014a\_S0606\_00600**

Tailor-Made Combination window can be opened from the Menu. ODP Online allows only one Tailor-Made Combination window to be opened.

**Scope of Data**

~~The Exchange will notify Exchange Participants from time to time a list of prescribed strategies for TMC. Only prescribed strategies are allowed to be created. Please refer to the HKEX website for a List of Prescribed Strategies for Tailor-Made Combinations: https://www.hkex.com.hk/Services/Trading/Derivatives/Overview/Trading-Mechanism/Tailor-Made-Combinations?sc\_lang=en # BRD\_DT\_0049\_030\_11500~~

**#FS10014a\_S0606\_00700**

User input screen for TMC submission, no auto update is required. Assume all markets will support TMC with maximum 4 legs and at least 2 legs in place.

**#FS10014a\_S0606\_00800**

The aggregated maximum number of Tailor-Made Combinations that can be listed on HKATS is 20,000 per trading day.

**UI Layout**

**#FS10014a\_S0606\_00900**

**![](data:image/png;base64...)**

\* Click on Send bid/ask will not reset those content until user should click on clear all to clear data

**Attributes**

**#FS10014a\_S0606\_01000**

Positive, negative and zero prices are allowed for TMC orders.

**#FS10014a\_S0606\_01100**

TMC legs fields:

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| ID | Alphanumeric  **Text Input (with Content Assist)** | 32 | M | - | The Instrument Series ID. |
| Rel | Numeric | 5 | M | - | The relative ratio.  Minimum value = 1  Maximum value = 65534 |
| Buy/Sell | Dropdown | - |  | Buy | The leg type, that is, buy or sell. |

Input fields:

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Net price | Price  **Text Input (With up / down per tick unit)** | [Ref to Data Type](#_Data_Type) | M | - | The price to be entered with the order. |
| Qty | Quantity  **Text Input**  **(With up / down per tick size)** | [Ref to Data Type](#_Data_Type) | M | - | The quantity in relation to the Rel field. The number of times you want to trade the combination. |
| Time Validity | Alphanumeric  Dropdown | - | O | Day | Specifies the default validity when opening the Enter Order and Enter Tailor-Made Combination windows.  Domain Values:  Fill or Kill (FOK)  Fill and Kill (FAK)  Day  Good till Date (GTD)  Good till Cancelled (GTC) |
| Expiry Date | Date  **Date Selection Drop Down** | - | M/O | - | Indicate the date of expiration when Time Validity is GTD. |
| Customer | Alphanumeric  **Text Input**  **(With Content Assist)** | 10 | O | - | The clearing customer account to which the order belongs. If nothing is specified, the trade will end up in the daily account. |
| ATID | Alphanumeric | 5 | O | - | The ATID. The ID is NOT allowed to change after order placement. |
| BCAN | Alphanumeric  **Text Input** | 17 | M | - | The BCAN attribute is a pass-through attribute. It is used to identify the order’s originator for market surveillance purposes. |
| Position Effect | Alphanumeric (Drop down) |  | O | Open | Position Effect is a pass-through attribute. It allows market participants to specify either opening or closing of position for clearing procedure.  Domain Value:  **- Open**  **- Close** |
| Customer Information | Alphanumeric | 15 | O | - | Any arbitrary information concerning the order. |
| ~~Validity~~ | ~~Alphanumeric~~  **~~Text Input~~**  **~~(Drop down)~~** | ~~-~~ | ~~M~~ | ~~Day~~ | ~~The order condition to use.~~  ~~Valid values:~~  ~~Day - The order is valid for the rest of the current business day.~~  ~~FaK - Fill and Kill; fill as much as possible of the order and delete the rest of it.~~  ~~FoK - Fill or Kill; fill the order in its entirety.~~  ~~Refer to Enter Order Validity~~ |
| Tradable in AHT | Boolean  **Checkbox** | 1 | O | False | Order will remain active in AHT session or not. |

~~For Internal # BRD\_DT\_0049\_030\_11700: TBC~~

In addition, there is one more attribute for Internal.

| Column | Type | Size | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| ~~Prt~~ | ~~TBC~~ | ~~TBC~~ | ~~M~~ | ~~-~~ | ~~The participant on whose behalf the order should be placed.~~ |

**Tooltips**

**#FS10014a\_S0606\_01200**

TMC leg field:

| Column | Tooltips |
| --- | --- |
| ID | Specifies the instrument ID field. You can enter an instrument manually, or by using the arrows.  ~~Instrument ID for the trade. Instrument can be entered either using Instrument ID (if known) or starting by entering Instrument, then Expiration etc. When Instrument ID is entered, Instrument, Expiration Strike and Call/Put will be filled in automatically.~~ |
| Rel | The relative ratio between the legs in the combination. |
| Buy/Sell | Specifies the leg type, that is, buy or sell. |

Input fields:

| Column | Tooltips |
| --- | --- |
| Net price | Specifies the price to be entered with the order. Enter a price into this field by either clicking the Price button, that is, current market price, or writing a price into the field, or by using the scroll buttons. |
| Qty | Specifies the quantity in relation to the Rel field. The number of times you want to trade the combination. (Example: If the relation for a leg is 2 and the quantity is 10, this refers to a total of 20 contracts in the leg.) |
| Time Validity | Defines what order condition to use: Day - The order is valid for the rest of the current business day. FaK - Fill and Kill; fill as much as possible of the order and delete the rest of it. FoK - Fill or Kill; fill the order in its entirety, or delete all of it.  ~~Refer to Enter order and support multiple day TMC~~ |
| Expiry Date | The date until which the order is valid. If Validity type GTD is selected, a calendar will appear in this field from which you can select a date. |
| Customer | Specifies the clearing customer account to which the order belongs. If nothing is specified, the trade will end up in the daily account. Use Order Settings to define a list of frequently used accounts. |
| ATID | Specifies the ATID. |
| BCAN | The BCAN attribute is a pass-through attribute. It is used to identify the order's originator for market surveillance purposes. |
| Position Effect | Specifies the requested position which is either Open or Close. |
| Customer Information | Specifies any arbitrary information concerning the order. Any information entered is of no logical importance and will not be interpreted in the system. Use Order Settings to define a list of frequently used values. |
| Tradable in AHT | Select if the order should participate trading in AHT session. |

~~For Internal # BRD\_DT\_0049\_030\_11700: TBC~~

~~In addition, there is one more attribute for Internal.~~

| ~~Column~~ | ~~Tooltips~~ |
| --- | --- |
| ~~Prt~~ | ~~Specifies the participant on whose behalf the order should be placed.~~ |

**Default Sorting Order**

**#FS10014a\_S0606\_01300**

Insertion order

**Filtering Criteria**

**#FS10014a\_S0606\_01400**

N/A

**Read / Write Permission Behaviour**

**#FS10014a\_S0606\_01500**

| Permission | Behavior |
| --- | --- |
| Read | N/A. As this window is for inputting new order only. |
| Write | External User with write permission can fill in and submit a new Order. |

**Action**

1. **Buy**

**#FS10014a\_S0606\_01600**

Indicate that you want to buy a leg and add a new row into the combination table

1. **Sell**

**#FS10014a\_S0606\_01700**

Indicate that you want to sell a leg and add a new row into the combination table

1. **Delete**

**#FS10014a\_S0606\_01800**

Delete the checked leg in the combination table.

1. **~~Calc bid~~**

~~(It’s currently only used for Net Value, TBC for whether to keep it or not)~~

~~To calculate a bid price for the TMC that matches single orders in the market.~~

~~Note: A price can only be generated if there is enough quantity in the market.~~

1. **~~Calc ask~~**

~~(It’s currently only used for Net Value, TBC for whether to keep it or not)~~

~~To calculate a ask price for the TMC that matches single orders in the market.~~

~~Note: A price can only be generated if there is enough quantity in the market.~~

1. **Send bid**

**#FS10014a\_S0606\_01900**

This action will, if necessary, create the TMC and an order will be entered to do the strategy defined, while paying the amount defined in the Price field.

**#FS10014a\_S0606\_02000** After the order is successfully processed, the TMC order is updated in the order book **#FS10014a\_S0606\_02100** and the order history windows.

**#FS10014a\_S0606\_02200**

Don’t clear input fields and table leg after submission. User should click on Clear to clear all.

1. **Send ask**

**#FS10014a\_S0606\_02300**

This action will, if necessary, create the TMC and an order will be entered to do the strategy defined, while receiving the amount defined in the Price field.

**#FS10014a\_S0606\_02400** After the order is successfully processed, the TMC order is updated in the order book **#FS10014a\_S0606\_02500** and the order history windows.

**#FS10014a\_S0606\_02600**

Don’t clear input fields and table leg after submission. User should click on Clear to clear all.

1. **Clear**

**#FS10014a\_S0606\_02700**

Clear all leg and field then reset to order setting.

**Validation**

1. **Buy**
2. **#FS10014a\_S0606\_02800** The selected instrument is valid.
3. **#FS10014a\_S0606\_02900** Maximum supports 4 legs.
4. **Sell**
5. **#FS10014a\_S0606\_03000** The selected instrument is valid.
6. **#FS10014a\_S0606\_03100** Maximum supports 4 legs.
7. **Delete**

**#FS10014a\_S0606\_03200**

N/A

1. **Send bid**
2. **#FS10014a\_S0606\_03300** Values of mandatory fields are not empty and valid.
3. **Send ask**
4. **#FS10014a\_S0606\_03400** Values of mandatory fields are not empty and valid.
5. **Clear**

**#FS10014a\_S0606\_03500**

N/A

**Other Action for Tailor-Made Combination Orders**

1. **View Tailor-Made Combination Orders**

**#FS10014a\_S0606\_03600** Users can view the TMC in the Price Information window and place bid and ask into the series via the Enter Order window.

**#FS10014a\_S0606\_03700** A TMC order can be viewed like a normal order. For more details, please refer to Order History section Order Book section.

1. **Change Tailor-Made Combination Orders**

**#FS10014a\_S0606\_03800** User could click on their order book window and then change order window will pop up to change the TMC order.

**#FS10014a\_S0606\_03900** A TMC order can be changed like a normal order. For more details, please refer to Change Order section.

1. **Cancel Tailor-Made Combination Orders**

**#FS10014a\_S0606\_04000**

A TMC order can be cancel like a normal order. For more details, please refer to Order Book section.

1. **Execute Tailor-Made Combination Orders**

**#FS10014a\_S0606\_04100** Execution order window will be pop up if user click the TMC order via the order depth window.

**#FS10014a\_S0606\_04200** Once an order for a TMC series is executed, the trade can be found in Trade History and Ticker windows, the trade would be displayed separately as names of the individual series composing the TMC under the ID column.

**#FS10014a\_S0606\_04300** TMC trades can be identified in the above-mentioned windows by the deal source (Deal Source) TMC Combo E

**#FS10014a\_S0606\_04400** A TMC order can be executed like a normal order. For more details, please refer to Execute Order section.

**User Notification**

**#FS10014a\_S0606\_04500**

* Existing TMC warning and confirmation if the TMC is reversed

## Automatic Quote Order Book

**Description**

**#FS10014a\_S0607\_00100**

This function is applicable to External only.

Market makers can view market making orders from the Automatic Quote Order Book window.

**Accessing the Function**

**#FS10014a\_S0607\_00200**

Automatic Quote Order Book window can be opened from the Menu. ODP Online allows only one Automatic Quote Order Book window to be opened.

**Scope of Data**

**#FS10014a\_S0607\_00300**

The window displays the market making orders.

**#FS10014a\_S0607\_00400**

The maximum number of records in the Automatic Quote Order Book Table are 60K records.

**#FS10014a\_S0607\_00500**

If the number of records exceed 60K, the Automatic Quote Order Book Table will always showing rolling latest 60K records, old records will be removed from the table.

**UI Layout**

**#FS10014a\_S0607\_00600**

**![](data:image/png;base64...)**

**Attributes**

**#FS10014a\_S0607\_00700**

| Column | Type | Remarks |
| --- | --- | --- |
| ID | Alphanumeric | The Instrument Series ID. |
| B QTY | Quantity | The quantity if a bid order. |
| A QTY | Quantity | The quantity if an ask order. |
| PRC | Price | The price/premium of the order. |
| TYPE | Alphanumeric | The order type. |
| VALID | TBC | The validity of the order. |
| ~~UNTIL~~ | ~~TBC~~ | ~~The date or other details on which the order expires.~~ |
| GUP | Alphanumeric | The company identity of the Give Up client. |
| G ACC | Alphanumeric | The give-up account for a give-up order. |
| CUST | Alphanumeric | The customer of the order.  (C, H, Rxxxx, A1, P1 or M1). |
| COMPID | TBC | The trader. |
| ~~I~~ | ~~TBC~~ | ~~Indicate if it is an inactive or active order.~~ |
| ~~AHT~~ | ~~TBC~~ | ~~Indicate if it is an AHT order or not.~~ |
| ~~CNV~~ | ~~Alphanumeric~~ | ~~Indicate if it is a converted Auction Order. Order that is converted from an auction order to limit order or inactive order after the pre-opening period with be marked with a “√” in this column.~~ |
| SMP | Alphanumeric | The SMP Token. |
| INFO | Alphanumeric | Any arbitrary information concerning the order. The information displayed is of no logical importance and is not interpreted in the system. |
| ~~LEI~~ | ~~Alphanumeric~~ | ~~The legal entity identifier.~~ |
| RP | Alphanumeric | The requested position, that is, open or close. |
| ORDER NO | Alphanumeric | The order number received from the Marketplace. |
| ~~O CAT~~ | ~~Alphanumeric~~ | ~~The order category.~~  ~~For example, Electronic Marketplace (EMP).~~ |
| CREATED | TBC | The time at which the order was created. |
| ~~CHANGED~~ | ~~TBC~~ | ~~The time of the latest order change.~~ |
| ERROR REASON | Alphanumeric | The failure reason if the last command failed. |

**Tooltips**

**#FS10014a\_S0607\_00801**

| Column | Tooltips | | |
| --- | --- | --- | --- |
| ID | Specifies the instrument identity. | | |
| B QTY | Specifies the quantity if a bid order. | | |
| A QTY | Specifies the quantity if an ask order. | | |
| PRC | Specifies the price/premium of the order. | | |
| TYPE | Specifies the order type. | | |
| VALID | Specifies the validity of the order. | | |
| ~~UNTIL~~ | ~~Specifies the date or other details on which the order expires.~~ | | |
| GUP | Indicates that the order is a give-up order. | | |
| G ACC | Specifies a give-up account for a give-up order. | | |
| CUST | Specifies the customer of the order. | | |
| COMPID | Specifies the trader, that is, the member at the exchange. | | |
| ~~I~~ | ~~Specifies if it is an inactive or active order. A tick indicates an inactive order.~~ | | |
| ~~AHT~~ | ~~Specifies a AHT order.~~ | | |
| ~~CNV~~ | ~~Specifies a converted Auction Order.~~ | | |
| SMP | | Specifies the SMP Token. |
| INFO | Specifies any arbitrary information concerning the order. The information displayed is of no logical importance and is not interpreted in the system. | | |
| ~~LEI~~ | ~~Specifies the legal entity identifier.~~ | | |
| RP | Specifies the requested position, that is, open or close. | | |
| ORDER NO | Specifies the order number received from the Marketplace. | | |
| ~~O CAT~~ | ~~Specifies the order category.~~ | | |
| CREATED | Specifies the time at which the order was created. | | |
| ~~CHANGED~~ | ~~Specifies the time of the latest order change.~~ | | |
| ERROR REASON | Specifies the failure reason if the last command failed. | | |

**Data refresh in table**

~~This view will automatically update upon any changes of the orders. # BRD\_DT\_0049\_030\_11900 (Comment)~~

**#FS10014a\_S0607\_00900**

No auto update and reload after click on Apply button

**Default Sorting Order**

**#FS10014a\_S0607\_01000**

Base on CREATED column in ASC

**Filtering Criteria**

**#FS10014a\_S0607\_01101**

Following filter fields are available for criteria search.

Display right above the table

| Filtering Criteria | Type |
| --- | --- |
| ID | Text Input (with Content Assist) |

[Revoked]

**Read / Write Permission Behaviour**

**#FS10014a\_S0607\_01200**

| Permission | Behavior |
| --- | --- |
| Read | User can perform the following:   * View all the data in the Automatic Quote Order Book Table * Perform Sorting/Filtering on the Automatic Quote Order Book Table * Export Automatic Quote Order Book Table as CSV File |
| Write | User can perform the following:   * Cancel Quotes |

**Action**

1. **Export to CSV File**

**#FS10014a\_S0607\_01300**

The users can click “**Export to CSV File**” to export those records from GUI table.

1. **Cancel Quotes**

**#FS10014a\_S0607\_01400**

User can select one or more Quotes from the Automatic Quote Order Book table and click the Cancel button to cancel the selected Quotes.

The selected orders are now removed from the Automatic Quote Order Book.

Confirmation box will be prompted with the following text when user click on the Cancel option.

*Confirm cancel quotes. Found x order(s) to be deleted.*

The cancel quotes will be submitted when user clicks OK on the confirmation box.

1. **Cancel All Quotes**

**#FS10014a\_S0607\_01500**

User cancel all Quotes from the Automatic Quote Order Book table and click the Cancel all button within the same participant based on GUI filter displayed result.

The quotes will be removed from the Automatic Quote Order Book after refreshing the table.

Confirmation box will be prompted with the following text when user click on the Cancel option.

*Confirm cancel all quotes. Found x quote(s) to be deleted.*

The cancel quotes will be submitted when user clicks OK on the confirmation box with a throttling in GUI (Default 5 Quotes cancel per second).

**Validation**

1. **#FS10014a\_S0607\_01600 Cancel Quotes**
2. Open quotes exist.
3. **#FS10014a\_S0607\_01700 Cancel All Quotes**
4. Open quotes exist.

**User Notification**

**#FS10014a\_S0607\_01800**

* Cancel success or failed response

## Local Inactive Orders

**Description**

**#FS10014a\_S0608\_00100**

This function is applicable to External only.

**#FS10014a\_S0608\_00200**

And user can activate or delete individual/multiple inactivated orders by selecting respective rows, then choose the order actions inside **More Actions**.

**#FS10014a\_S0608\_00300**

User can also select **Delete all** action to delete all local inactivated orders or select the **Activate all** action to activate all local inactive orders.

~~Local inactive orders should be removed after the respective series have expired. # BRD\_DT\_0049\_030\_12400~~

**Accessing the Function**

**#FS10014a\_S0608\_00400**

Local Inactive Orders window can be opened from the Menu. ODP Online allows only one Local Inactive Orders window to be opened.

**Scope of Data**

**#FS10014a\_S0608\_00500**

All of the local inactivated orders owned by the current user will be stored in this window.

User is responsible for removing those expired inactivated orders manually when required.

Max number of Inactive order default to 20k per user account.

**UI Layout**

**#FS10014a\_S0608\_00600**

![](data:image/png;base64...)

**Attributes**

**#FS10014a\_S0608\_00700**

| Column | Type | Remarks |
| --- | --- | --- |
| ID | Alphanumeric | The Instrument Series ID. |
| BID/ASK | Alphanumeric | Indicate it’s a Bid or Ask Order.  Domain Values:  **Bid**  **Ask** |
| PRICE | Price | The price of the order. |
| QTY | Quantity | The quantity of the order. |
| TYPE | Alphanumeric | The order type. |
| CUSTOMER | Alphanumeric | The customer of the order.  (C, H, Rxxxx, A1, P1 or M1). |
| ~~TRADER~~ COMPID | Alphanumeric | The Executing Trader |
| ~~LEI~~ | ~~Alphanumeric~~ | ~~The legal entity identifier.~~ |
| ~~CUST ORDER ID~~ | ~~Alphanumeric~~ | ~~The Client Order ID.~~ |
| ~~BCAN~~ | ~~TBC~~ | ~~The Broker-Client Assigned Number.~~ |
| SMP | Alphanumeric | The SMP Token. |
| ~~Incentive ID~~ | ~~Alphanumeric~~ | ~~Incentive ID. Alphanumeric free text field with length as 5.~~ |
| ATID | Alphanumeric | The ATID. The ID is NOT allowed to change after order placement. |
| COD | Boolean | This indicator specifies whether the order is subject to COD. |
| INFO | Alphanumeric | Any arbitrary information concerning the order. The information displayed is of no logical importance and is not interpreted in the system. |
| POSITION | Alphanumeric | The requested position, that is, open or close. |
| GIVE UP | Alphanumeric | The company identity of the Give Up client. |
| GIVE UP ACC | Alphanumeric | The give-up account for a give-up order. |
| VALIDITY | Alphanumeric | The validity of the order. |
| EXPIRY | Date | The date or other details on which the order expires. |
| AHT | Alphanumeric | Indicate if it is a AHT order or not. |
| CREATED | Date Time | The time at which the order was created. |
| CHANGED | Date Time | The time of the latest order change. |
| ERROR REASON | Alphanumeric | The error reason. Reject reason after submission |

**Tooltips**

**#FS10014a\_S0608\_00801**

| Column | Tooltips |
| --- | --- |
| ID | Specifies the instrument identity. |
| BID/ASK | Specifies the bid or ask side. |
| PRICE | Specifies the price of the order. |
| QTY | Specifies the quantity of the order. |
| TYPE | Specifies the order type. |
| CUSTOMER | Specifies the customer of the order. |
| ~~TRADER~~ COMPID | Specifies the comp ID |
| ~~LEI~~ | ~~Specifies the legal entity identifier.~~ |
| ~~C ORD ID~~ | ~~Specifies the Client Order ID assigned by the market participant.~~ |
| ~~BCAN~~ | ~~Specifies the Broker-Client Assigned Number.~~ |
| SMP | Specifies the SMP Token. |
| ~~Incentive ID~~ | ~~Specifies an alphanumeric free text field with length as 5.~~ |
| ATID | Specifies the ATID. |
| COD | Specifies if the order is subject to COD. |
| INFO | Specifies any arbitrary information concerning the order. The information displayed is of no logical importance and is not interpreted in the system. |
| POSITION | Specifies the requested position, that is, open or close. |
| GIVE UP | Indicates that the order is a give-up order. |
| GIVE UP ACC | Specifies a give-up account for a give-up order. |
| VALIDITY | Specifies the validity of the order. |
| EXPIRY | Specifies the date or other details on which the order expires. |
| AHT | Specifies a AHT order. |
| CREATED | The time at which the order was created. |
| CHANGED | The time of the latest order change. |
| ERROR REASON | Specifies the failure reason if the last command failed. |

**Data refresh in table**

**#FS10014a\_S0608\_00900**

Yes

**Default Sorting Order**

**#FS10014a\_S0608\_01000**

Creation time in ASC order

**Filtering Criteria**

**#FS10014a\_S0608\_01101**

Following filter fields are available for criteria search.

Display right above the table

| Filtering Criteria | Type |
| --- | --- |
| ID | Instrument ID  Text Input (with Content Assist) |

[Revoked]

**Read / Write Permission Behaviour**

**#FS10014a\_S0608\_01200**

| Permission | Behavior |
| --- | --- |
| Read | Available for order owner only, the following user can perform the following:   * View all the data in the Local Inactive Order Table * Perform Sorting/Filtering on the Local Inactive Order Table * Export Local Inactive Order table as CSV File |
| Write | User can perform the following:   * Delete Orders from Local Inactive Order Table * Activate Orders in Local Inactive Order Table * Change order via change order dialog (Keep it as inactive checked only) |

**Action**

1. **Delete Order**

**#FS10014a\_S0608\_01300**

User can select one or more Orders from the Local Inactive Order table and click the **Delete Order** option from the **More Actions** menu to delete the selected Orders.

**#FS10014a\_S0608\_01400**

Confirmation box will be prompted with the following text when user click on the **Delete Order** option.

*Confirm delete of selected order(s).*

The Delete Order will be submitted when user clicks OK on the confirmation box.

1. **Delete all Orders**

**#FS10014a\_S0608\_01500**

User can click the **Delete all Orders** option from the **More Actions** menu to delete all Orders.

**#FS10014a\_S0608\_01600**

Confirmation box will be prompted with the following text when user click on the **Delete all Orders** option.

*Confirm delete of all orders.*

The Delete Order will be submitted when user clicks OK on the confirmation box. Request are throttled by GUI (e.g. no more than five cancel request per second)

1. **Activate Order**

**#FS10014a\_S0608\_01701**

User can select one or more Orders from the Local Inactive Order table, enter BCAN, and click the **Activate Order**button to activate the selected Orders.
The selected orders are submitted as new orders to the Trading Platform. And orders are validated as per market conditions and safeguard at the time of submission. Orders may or may not be accepted by the Trading Platform, and they are removed from the Inactive Orders screen when they are submitted from GUI.

GUI keeps orders as inactive and remain in the screen only if it fails to pass GUI validation and submit to the Trading Platform.

**#FS10014a\_S0608\_01800**

Confirmation box will be prompted with the following text when user click on the **Activate Order** option.

*Confirm activate of selected order(s).*

The Activate Order will be submitted when user clicks OK on the confirmation box.

1. **Activate all Orders**

**#FS10014a\_S0608\_01900**

User can enter BCAN and click the **Activate all Orders** option from the **More Actions** menu to activate all Orders.

**#FS10014a\_S0608\_02000**

Confirmation box will be prompted with the following text when user click on the **Activate all Orders** option.

*Confirm activate of all orders.*

The Activate all Orders will be submitted when user clicks OK on the confirmation box. Request are throttled by GUI (e.g. no more than five cancel request per second)

1. **Export as CSV File**

**#FS10014a\_S0608\_02100**

The users can click "**Export to CSV File**" to export those records from GUI table.

1. **Double click an Order**

**#FS10014a\_S0608\_02200**

User can double click an Order in the Local Inactive Orders window to bring up the Change Order dialog for that Order.

**Validation**

**#FS10014a\_S0608\_02301**

1. **Delete Order**
2. Own order only.
3. **Delete all Orders**
4. Own order only.
5. **Activate Order**
6. BCAN field is not empty
7. One or more Orders must be selected.
8. Own order only
9. Refer to enter order
10. **Activate all Orders**
11. Refer to activate order

**User Notification**

**#FS10014a\_S0608\_02400**

* Max inactive order warning
* Refer to Confirmation Setting

**Highlight**

**#FS10014a\_S0608\_02500**

Invalid inactive orders that meet one of the conditions below are highlighted in red:

* Instrument Id no longer exist
* Order expired

## Trade History

**#FS10014a\_S0609\_00100**

**Description**

**#FS10014a\_S0609\_00200**

It allows users to view trades transacted history.

**Accessing the Function**

**#FS10014a\_S0609\_00300**

Trade History window can be opened from the Menu. ODP Online allows only one Trade History window to be opened.

**Scope of Data**

**#FS10014a\_S0609\_00400**

Users can review all trade history of the current trading day but up to 60k trade history to display at a time of the current participant and trading right is not considered for display.

~~Trade History window will also display post-trade activities that are conducted by the back office or the Exchange and will return the latest 60K trades (including post-trade activities) at maximum after each searching.~~ **~~#~~** ~~BRD\_DT\_0049\_030\_12700~~

~~Two Sided trade shows underlying trade leg individually for bid and ask trade~~.

~~It is open for discussion if the max no. of trades limit is still there in ODP. (TBC)~~ **~~#~~** ~~BRD\_DT\_0049\_030\_12800~~

For Internal:

**#FS10014a\_S0609\_00500**

If the participant field is left blank, latest trades in the market will be loaded from ALL participants up to 60k trades.

**#FS10014a\_S0609\_00600**

If a specific participant (e.g. ~~HK~~ KGI) is filled in the participant filter, it will display trades made under the specific participant but displays up to 60k trade history only (e.g. KGI).

Up to eight Trade History screen can be opened at a time.

For External:

**#FS10014a\_S0609\_00700**

One and only one Trade History screen can be opened at a time

**UI Layout (External)**

**#FS10014a\_S0609\_00801**

![](data:image/png;base64...)

**UI Layout (Internal)**

**#FS10014a\_S0609\_00901**

![](data:image/png;base64...)

**Attributes**

**#FS10014a\_S0609\_01001**

| Column | Type | Remarks |
| --- | --- | --- |
| ACTION | Alphanumeric | The action of the trade. |
| PART | Alphanumeric | The participant. |
| ID | Alphanumeric | The Instrument Series ID. |
| TRADE ID | Alphanumeric | The trade identification number. |
| ~~G DEAL NO~~ | ~~TBC~~ | ~~The global deal number.~~ |
| ~~DEAL NO~~ | ~~TBC~~ | ~~The deal number.~~ |
| ~~NO~~ | ~~TBC~~ | ~~The number.~~ |
| ~~ORG NO~~ | ~~TBC~~ | ~~The original trade number.~~ |
| ~~STATE~~ | ~~Alphanumeric~~ | ~~The trade status.~~ |
| ~~TYPE~~ | ~~Alphanumeric~~ | ~~The order type.~~ |
| BOUGHT | Quantity | The bought quantity. |
| SOLD | Quantity | The sold quantity. |
| R QTY | Quantity | The remaining quantity. |
| T PRC | Price | The price. |
| CUST | Alphanumeric | The account type.  (C, H, Rxxxx, A1, P1 or M1). |
| GUP | Alphanumeric | The company identity of the Give Up client. |
| G ACC | Alphanumeric | The give up acc. |
| INFO | Alphanumeric | The customer information. |
| ~~LEI~~ | ~~Alphanumeric~~ | ~~The legal entity identifier.~~ |
| ~~P~~ | ~~TBC~~ | ~~The position.~~ |
| RP | Alphanumeric | The requested position. |
| TR TYPE | Alphanumeric | The trade report type |
| ~~ATT~~ | ~~TBC~~ | ~~The attention.~~ |
| ~~CLEARING~~ | ~~TBC~~ | ~~The clearing date.~~ |
| TIME | Date Time | The time of creation. |
| **~~\*~~**~~ASOF~~ | ~~TBC~~ | ~~The as of time.~~ |
| **~~\*~~**~~MODIFIED~~ | ~~TBC~~ | ~~The time of last modification.~~ |
| TRD | Alphanumeric | The trader Id. |
| ORDER NO | Alphanumeric | The order number. |
| DEAL SRC | Alphanumeric | The deal source.  Refer to the deal flag section for more details. |
| ~~WHOSE~~ | ~~TBC~~ | ~~The trade owner.~~ |
| C PART | Alphanumeric | The counterpart. |
| ~~UL~~ | ~~Alphanumeric~~ | ~~The underlying name.~~ |
| ~~MKT~~ | ~~Alphanumeric~~ | ~~The market.~~ |
| ~~SMP~~ | ~~Alphanumeric~~ | ~~The SMP token.~~ |
| ATID | Alphanumeric | The ATID. |

Deal flag available in the column are:

| Column | Remarks |
| --- | --- |
| EMP | Indicates that the trade is a Leg Instrument and is matched with another outright order by an auto match. |
| STC | Indicates that the trade is a Standard Combo instrument and is matched with another outright order by an auto match. |
| Cbo v. Outr | Indicates that the trade is a Standard Combo instrument and is matched with another implied order by an auto match.   Or that the trade is a Leg Instrument and is matched with another implied order by an auto match. |
| TMC Combo E | Indicates that the trade is a TMC instrument and is matched with another outright order by an auto match. |
| AUC | Indicates that the trade is a Leg Instrument and is matched with another outright order by a cross auction. |
| MPS | Indicates that the trade is an exchange on-behalf trade. |
| EMP 1 BR | Indicates that the trade is an internal, two-party block trade.  Or that the trade is an interbank, one-party block trade. (Same company) |
| EMP D BR | Indicates that the trade is an interbank, one-party block trade. |

**Tooltips**

**#FS10014a\_S0609\_01100**

| Column | Tooltips |
| --- | --- |
| ACTION | Specifies the action of the trade. |
| PART | Specifies the participant at which the trade has been done. |
| ID | Specifies the identity of the instrument. |
| TRADE ID | Trade identification number. |
| ~~G DEAL NO~~ | ~~Global deal number.~~ |
| ~~DEAL NO~~ | ~~Deal number.~~ |
| ~~NO~~ | ~~Trade number.~~ |
| ~~ORG NO~~ | ~~Original trade number.~~ |
| ~~STATE~~ | ~~Trade state.~~ |
| ~~TYPE~~ | ~~Trade type.~~ |
| BOUGHT | Bought quantity. |
| SOLD | Sold quantity. |
| R QTY | Remaining quantity. |
| T PRC | Traded price. |
| CUST | Customer. |
| GUP | Give up. |
| G ACC | Give-up account info. |
| INFO | Customer information. |
| ~~LEI~~ | ~~Legal entity identifier.~~ |
| ~~P~~ | ~~Position.~~ |
| RP | Request position. |
| TR TYPE | Trade-Report Type. |
| ~~ATT~~ | ~~Attention.~~ |
| ~~CLEARING~~ | ~~Clearing date.~~ |
| TIME | Time of creation. |
| ~~ASOF~~ | ~~As of time.~~ |
| ~~MODIFIED~~ | ~~Time of last modification.~~ |
| TRD | Trader. |
| ORDER NO | Order number. |
| DEAL SRC | Deal source. |
| ~~WHOSE~~ | ~~Whose.~~ |
| C PART | Counterparty. |
| ~~UL~~ | ~~Specifies the underlying.~~ |
| ~~MKT~~ | ~~Specifies the market.~~ |
| ~~SMP~~ | ~~Specifies the SMP token.~~ |
| ATID | Active Trader ID. |

**Data refresh in table**

For external user:

**#FS10014a\_S0609\_01200**

This view will automatically update upon any changes of the trade history. When there is filter, shall the new record meet with the filter criteria, it should be updated as well.

Subsequent trades after searching will be appended at the end of the window.

For internal user:

**#FS10014a\_S0609\_01300**

This view will automatically update upon any changes occur for ALL participants in the trade history. When there is filter, shall the new record meet with the filter criteria, it should be updated as well.

Subsequent trades after searching will be appended at the end of the window.

**Default Sorting Order**

**#FS10014a\_S0609\_01400**

The trades are sorted by TIME in ASC by default.

**Filtering Criteria**

**#FS10014a\_S0609\_01501**

Following filter fields are available for criteria search.

Display right above the table

For external user:

| Filtering Criteria | Type |
| --- | --- |
| ID | Text Input (with Content Assist) |
| SIDE | Drop Down |
| TRADES | Drop Down |

For internal user:

| Filtering Criteria | Type |
| --- | --- |
| ID | Text Input (with Content Assist) |
| PART | Text Input (with Content Assist) |
| SIDE | Drop Down |

[Revoked]

**Read / Write Permission Behaviour**

**#FS10014a\_S0609\_01600**

| Permission | Behavior |
| --- | --- |
| Read | User can perform the following:   * View all the data in the Trade History Table * Perform Sorting/Filtering on the Trade History Table * Export Trade History Table as CSV File |
| Write | N/A |

**Action**

1. **Export to CSV File**

**#FS10014a\_S0609\_01700**

The users can click "**Export to CSV File**" to export those records from GUI table.

1. **~~Submit an error trade claim (Internal/External)~~**

~~Selecting a trade in the Trade History Table and click the~~ **~~Error Trade Claim~~** ~~option to file an error trade claim.~~

1. **~~Export all (Internal)~~**

**~~#FS10014a\_S0609\_01800~~**

~~The users can click~~ **~~"Export All"~~** ~~to export all records from server.~~

~~This action is applicable to Internal only. TBC (20240830)~~

1. **~~Trade Cancel (Internal)~~**

~~Selecting trades in trade history table and submit for cancellation bypass error trade approval flow but requires second user approval~~

1. **~~Trade Adjustment (Internal)~~**

~~Selecting a trade to adjust the price in trade history table and submit for second user approval~~

**Validation**

**#FS10014a\_S0609\_01900**

1. **~~Submit an error trade claim (Internal/External)~~**
   1. ~~Multiple trades can be selected~~
   2. ~~Users under the same participant should allow to submit error trade (TBC by IT if fix allow this)~~
2. **~~Trade cancellation~~**
   1. ~~Multiple trades can be selected~~
   2. ~~Users under the same participant should allow to submit cancel (TBC by IT if fix allow this)~~
3. **~~Trade adjustment~~**
   1. ~~One and only one trade can be adjusted at a time by providing adjusted price~~

**User Notification**

**#FS10014a\_S0609\_02000**

* ~~System success/reject/fail notification for Error Trade Claim, Trade Cancel and Trade adjustment~~

## Trade History Aggregated

**#FS10014a\_S0610\_00100**

**Description**

**#FS10014a\_S0610\_00200**

It allows both external and internal users to view trades transacted history with aggregated function.

**Accessing the Function**

**#FS10014a\_S0610\_00300**

Trade History - Aggregated window can be opened from the Menu. ODP Online allows more than one Trade History - Aggregated window to be opened.

**Scope of Data**

**#FS10014a\_S0610\_00400**

The Trade History - Aggregated window displays the company’s current position based on the trades since the start of the day and trading right is not considered for display. It will display the total trades of the current trading day based upon the filter criteria to perform the real time aggregation.

**#FS10014a\_S0610\_00500**

When the Aggregated box is **unchecked**, the average price bought or sold will be displayed along with the average net position. Calculations are described below. Note that price and quantities of trades executed through the Enter Trade Report window are not included in these statistics, but trade cancellation and trade adjustment need to be included in this statistics.

**#FS10014a\_S0610\_00600**

When the Aggregated box is **checked**, a break-down of bought and sold quantities will be displayed according to the traded price. In addition, the average price bought or sold will be displayed along with the average net position in the Total row.

The rows under each aggregated row are grouped by price, and the average price format follows the instrument’s configuration.

**#FS10014a\_S0610\_00700**

For example, there are 3 trades matched on HSIK4 with price and size as below where participant Tom are all matched from sell side.

|  |  |
| --- | --- |
| Price | Size |
| 17010 | 1 |
| 17010 | 5 |
| 17020 | 10 |

Then if the aggregated box is unchecked, following will be displayed

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

Else if the aggregated box is check, it will display as follow

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

For External:

**#FS10014a\_S0610\_00800**

Support up to 6 Trade History Aggregated Screen for external user.

For Internal:

**#FS10014a\_S0610\_00900**

Support up to 8 Trade History Aggregated Screen for internal user.

**#FS10014a\_S0610\_01000**

If no participant code is in the filter field “participant”, this window will show all the trades in the market for the statistics.

**#FS10014a\_S0610\_01100**

If a participant code is updated in the filler field “participant”, only that specific participant trade aggregation information will be showed.

**UI Layout**

**#FS10014a\_S0610\_01200**

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

**Attributes**

**#FS10014a\_S0610\_01300**

| Column | Type | Remarks |
| --- | --- | --- |
| ID | Alphanumeric | The identity of the instrument |
| BOUGHT | Quantity | The bought quantity. |
| SOLD | Quantity | The sold quantity. |
| NET | Quantity | The net quantity. |
| PRICE | Price | The traded Price |
| BOUGHT | Price | The average Price: Bought |
| SOLD | Price | The average Price: Sold. |
| NET | Price | The average Price: Net. |

**Tooltips**

**#FS10014a\_S0610\_01400**

| Column | Tooltips |
| --- | --- |
| **INSTRUMENT** | |
| ID | Specifies the identity of the instrument. |
| **QUANTITIES** | |
| BOUGHT | Bought quantity. |
| SOLD | Sold quantity. |
| NET | Net quantity. |
| **TRADED** | |
| PRICE | Traded Price |
| **AVERAGE PRICE** | |
| BOUGHT | Average Price: Bought |
| SOLD | Average Price: Sold. |
| NET | Average Price: Net. |

**Data refresh in table**

**#FS10014a\_S0610\_01500**

For External:

Real Time update in both aggregated and non-aggregated mode

For Internal:

Real Time update in both aggregated and non-aggregated mode

**Default Sorting Order**

**#FS10014a\_S0610\_01600**

Order by Instrument ID column in ASC

**Filtering Criteria**

**#FS10014a\_S0610\_01702**

Following filter fields are available for criteria search.

Display right above the table

| Filtering Criteria | Type |
| --- | --- |
| ID | Text Input (with Content Assist), support one ID only |
| CompID | Text Input (with Content Assist) , support one CompID only |
| Part | Text Input (with Content Assist) , support one Participant only and available for Internal user |
| Aggregated | Checkbox (Aggregate by price) |

[Revoked]

**Read / Write Permission Behaviour**

**#FS10014a\_S0610\_01800**

| Permission | Behavior |
| --- | --- |
| Read | User can perform the following:   * View all the data in the Trade History Aggregated Table * Perform Sorting/Filtering on the Trade History Aggregated Table * Export Trade History Aggregated Table as CSV File |
| Write | N/A |

**Action**

1. **Export to CSV File**

**#FS10014a\_S0610\_01900**

The users can click "**Export to CSV File**" to export those records from GUI table.

**Validation**

**#FS10014a\_S0610\_02000**

NA

**User Notification**

**#FS10014a\_S0610\_02100**

NA

## Ticker

#FS10014a\_S0611\_00100

**Description**

#FS10014a\_S0611\_00200

The Ticker window allows the users to view and perform filtering/sorting to the trades on the Ticker table.

This window is applicable to both external and internal. The layout is the same for both.

**Accessing the Function**

#FS10014a\_S0611\_00300

The Ticker window can be opened from the Menu. ODP online allows only 1 Ticker window to be opened for external user. Support up to 6 for internal.

**Scope of Data**

Both internal and external users access the same scope of the data.

#FS10014a\_S0611\_00400

This window can display all trades performed in the HKATS markets if no filter is defined after the user has logged in without T+1 trades. User will not be able to retrieve any trade details during the logged-off period or during the intervals when there may be equipment/telecommunication problems preventing proper connection to HKATS.

#FS10014a\_S0611\_00500

The Ticker window will return the latest 60K records at maximum.

**UI Layout**

#FS10014a\_S0611\_00600

![](data:image/png;base64...)

**Attributes**

#FS10014a\_S0611\_00700

| Column | Type | Remarks |
| --- | --- | --- |
| ID | Alphanumeric | The instrument identity. |
| TRADE ID | Alphanumeric | The unique identification of the trade. |
| QTY | Quantity | The quantity of the trade. |
| PRICE | Price | The price at which the trade was done. |
| TIME | Date and Time | The date and time at which the trade was registered. |
| DEAL SOURCE | Alphanumeric | The way in which the order was matched.  Refer to Trade History attributes - deal flag section for more details. |
| ACTION | Alphanumeric | Cancel or replace, if applicable. |

**Tooltips**

#FS10014a\_S0611\_00800

| Column | Tooltips |
| --- | --- |
| ID | Specifies the instrument identity. |
| TRADE ID | Specifies the unique identification of the trade. |
| QTY | Specifies the quantity of the trade. |
| PRICE | Specifies the price at which the trade was done. |
| TIME | Specifies the date and time at which the trade was registered. |
| DEAL SOURCE | Specifies the way in which the order was matched. |
| ACTION | Cancel or replace, if applicable. |

**Data Refresh in Table**

#FS10014a\_S0611\_00900

The window will automatically update the new trades to the bottom of Ticker table.

**Default Sorting Order**

#FS10014a\_S0611\_01000

TIME Column in ASC Order

**Filtering Criteria**

#FS10014a\_S0611\_01101

The following filter fields are available for criteria search

Display right above the table

| Filtering Criteria | Type |
| --- | --- |
| ID | Text Input (with Content Assist) |

[Revoked]

**Read / Write Permission Behaviour**

#FS10014a\_S0611\_01200

| Permission | Behavior |
| --- | --- |
| Read | User can perform the following:   * View all the trades on the Ticker Table * Perform Sorting/Filtering on the Ticker Table * Export Ticker Table as CSV File |
| Write | N/A |

**Action**

a. #FS10014a\_S0611\_01300 Export to CSV File

The users can click "**Export to CSV File**" to export those records from GUI table.

**Validation**

#FS10014a\_S0611\_01400

N/A

**User Notification**

#FS10014a\_S0611\_01500

N/A

## Enter Block Trade Report – Internal Block Trade and Interbank Block Trade

**#FS10014a\_S0612\_00101**

**Description**

**#FS10014a\_S0612\_00200**

It allows users to handle block trades between two client accounts: house and client accounts, house and market maker accounts, market maker and client accounts, or two market maker accounts of the same or two different Exchange Participants.

Multi-leg are supported by all block trade types.

Internal block trade must be two-sided. Interbank block trade must be one-sided, requester has to specify a counterparty for entire block trade request. On-behalf block trade. Requester has to specify buyer and seller.

The server will not save any added trades until they are successfully submitted through the “Enter trade report” action.

**Accessing the Function**

**#FS10014a\_S0612\_00301**

Enter Internal Block Trade and Enter Interbank Block Trade can be opened from the Menu. Each of them can be opened once only at a time.

**Scope of Data**

**#FS10014a\_S0612\_00400**

Currently we support these trade type below via the following Block Trade Screens.

1. Enter Internal Block Trade (two-party trade report)
2. Enter Interbank Block Trade
3. Enter Onbehalf Block Trade (Day 2 Feature)

Each block trade support up to 8 legs, and each leg must be an Instrument or Standard Combo.

**UI Layout**

**#FS10014a\_S0612\_00501**

Enter Internal Block Trade:

**![](data:image/png;base64...)**

Add Dialog of Internal Block Trade:

![](data:image/png;base64...)

**#FS10014a\_S0612\_00601**

Enter Interbank Block Trade:

![](data:image/png;base64...)

Add Dialog of Interbank Block Trade:

![](data:image/png;base64...)

**#FS10014a\_S0612\_00700**

Enter Trade Report view (Day 2 Feature - Enter Onbehalf Block Trade):

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

Enter Trade Report Dialog (Day 2 Feature - Enter Onbehalf Block Trade):

![A white line with black lines  AI-generated content may be incorrect.](data:image/png;base64...)

\*Input fields can vary depending on the chosen trade type. Refer to Attributes section - Input fields for more details.

**Attributes**

**#FS10014a\_S0612\_00801**

When Type is **Enter Internal Block Trade:**

Enter Internal Block Trade

| Column | Type | Length | Remarks |
| --- | --- | --- | --- |
| **CONTRACT** | | | |
| ID | Alphanumeric | 32 | The instrument for the trade. |
| **QTY/PRICE** | | | |
| QTY | Quantity | [Ref to Data Type](#_Data_Type) | Quantity of the trade |
| PRICE | Price | [Ref to Data Type](#_Data_Type) | The price of the trade. |
| **BUYER** | | | |
| Customer Information | Alphanumeric | 15 | Info for buy side. |
| Give Up Participant | Alphanumeric | 5 | Either a participant or an account to give up to. |
| Give Up Information | Alphanumeric | 15 | Optional free text field that will follow the trade as information to the take up participant. |
| POS | Alphanumeric | 5 | The requested position, that is, open or close. |
| ~~ATID~~ | ~~Alphanumeric~~ | ~~5~~ | ~~Active Trader ID~~ |
| ~~LEI~~ | ~~Alphanumeric~~ | ~~10~~ | ~~Enter Legal Entity Identifier. The global unique identifier used for counterparty identification.~~ |
| **SELLER** | | | |
| Customer Information | Alphanumeric | 15 | Info for sell side. |
| Give Up Participant | Alphanumeric | 5 | Enter either a participant or an account to give up to. |
| Give Up Information | Alphanumeric | 15 | Optional free text field that will follow the trade as information to the take up participant. |
| POS | Alphanumeric  **Dropdown** | 5 | The requested position, that is, open or close. |
| ~~ATID~~ | ~~Alphanumeric~~ | ~~5~~ | ~~Active Trader ID~~ |
| ~~LEI~~ | ~~Alphanumeric~~ | ~~10~~ | ~~Enter Legal Entity Identifier. The global unique identifier used for counterparty identification.~~ |

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Buyer BCAN | Alphanumeric | 17 | M | Empty | The Buyer Broker-Client Assigned Number. |
| Seller BCAN | Alphanumeric | 17 | M | Empty | The Seller Broker-Client Assigned Number. |
| Buyer ATID | Alphanumeric | 5 | O | Empty | Buyer Active Trader ID |
| Seller ATID | Alphanumeric | 5 | O | Empty | Seller Active Trader ID |
| Trade Conclusion Date | Date and Time | 8 | M | Current business date | Future date is not allowed. |
| Trade Conclusion Time | Time | 6 | M | Time of open this page | Future time is not allowed. |
| Special Indicator | Alphanumeric  **Dropdown** | 5 | M | Empty | Domain Value:  - Empty  - BTIC  - PPR2 |
| Aggregated Trade | Boolean  **Switch** | 1 | O | False | True or False |

Add Dialog of Internal Block Trade

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| ID | Alphanumeric  **Text Input**  **(With Content Assist)** | 32 | M | - | The Contract Series ID. |
| Price | Price  **Spinner Input (With up / down per tick unit)** | [Ref to Data Type](#_Data_Type) | M | - | The Price. |
| Quantity | Quantity  **Text Input**  **(With up / down per tick size)** | [Ref to Data Type](#_Data_Type) | M | - | The Quantity. |
| **Buyer** | | | | | |
| Customer Information | Alphanumeric | 15 | O | - | Info for buy side. |
| Give Up Participant | Alphanumeric | 5 | O | - | Either a participant or an account to give up to. |
| Give Up Information | Alphanumeric | 15 | O | - | Optional free text field that will follow the trade as information to the take up participant. |
| Position Effect | Alphanumeric  **Dropdown** | 5 | O |  | The requested position, that is, open or close. |
| ~~ATID~~ | ~~Alphanumeric~~ | ~~5~~ | ~~O~~ | ~~-~~ | ~~Active Trader ID~~ |
| ~~LEI~~ | ~~Alphanumeric~~ | ~~10~~ | ~~TBC~~ |  | ~~Enter Legal Entity Identifier. The global unique identifier used for counterparty identification.~~ |
| **Seller** | | | | | |
| Customer Information | Alphanumeric | 15 | O | - | Info for sell side. |
| Give Up Participant | Alphanumeric | 5 | O | - | Either a participant or an account to give up to. |
| Give Up Information | Alphanumeric | 15 | O | - | Optional free text field that will follow the trade as information to the take up participant. |
| Position Effect | Alphanumeric  **Dropdown** | 5 | O |  | The requested position, that is, open or close. |
| ~~ATID~~ | ~~Alphanumeric~~ | ~~5~~ | ~~O~~ | ~~-~~ | ~~Active Trader ID~~ |
| ~~LEI~~ | ~~Alphanumeric~~ | ~~10~~ | ~~TBC~~ |  | ~~Enter Legal Entity Identifier. The global unique identifier used for counterparty identification.~~ |

**#FS10014a\_S0612\_00901**

When Type is **Enter Interbank Block Trade:**

Enter Interbank Block Trade

| Column | Type | Length | Remarks |
| --- | --- | --- | --- |
| **CONTRACT** | | | |
| ID | Alphanumeric | 32 | The instrument for the trade. |
| **SIDE** | | | |
| BUY/SELL | Alphanumeric | 4 | The side. Buy or Sell |
| **QTY/PRICE** | | | |
| QTY | Quantity | [Ref to Data Type](#_Data_Type) | Quantity of the trade |
| PRICE | Price | [Ref to Data Type](#_Data_Type) | The price of the trade. |
| **OWN ACCOUNT** | | | |
| Customer Information | Alphanumeric | 15 | Info for own account.  ***(Cell Editable in Accept Block Trade Dialog)*** |
| Give Up Participant | Alphanumeric | 5 | Either a participant or an account to give up to.  ***(Cell Editable in Accept Block Trade Dialog)*** |
| Give Up Information | Alphanumeric | 15 | Optional free text field that will follow the trade as information to the take up participant.  ***(Cell Editable in Accept Block Trade Dialog)*** |
| POS | Alphanumeric  **Dropdown** | 5 | The requested position, that is, open or close.  ***(Cell Editable in Accept Block Trade Dialog)*** |
| ~~ATID~~ | ~~Alphanumeric~~ | ~~5~~ | ~~Active Trader ID~~  ***~~(Cell Editable in Accept Block Trade Dialog)~~*** |
| ~~LEI~~ | ~~Alphanumeric~~ | ~~10~~ | ~~Enter Legal Entity Identifier. The global unique identifier used for counterparty identification.~~  ***~~(Cell Editable in Accept Block Trade Dialog)~~*** |

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
| BCAN | Alphanumeric | 17 | M | Empty | The Broker-Client Assigned Number. |
| ATID | Alphanumeric | 5 | O | Empty | Active Trader ID |

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
| Trade Conclusion Date | Date and Time | 8 | M | Current business date | Future date is not allowed. |
| Trade Conclusion Time | Time | 6 | M | Time of open this page | Future time is not allowed. |
| Special Indicator | Alphanumeric  **Dropdown** | 5 | M | Empty | Domain Value:  - Empty  - BTIC  - PPR2 |
| Counterparty ID | Alphanumeric  **Text Input**  **(With Content Assist)** | 5 | O | - | Counterparty. \*Allow all counterparty, no need to filter cross with the same counterparty |
| Counterparty Session ID | Alphanumeric  **Text Input**  **(With Content Assist)** | 11 | O | - | Target Comp ID |
| Aggregated Trade | Boolean  **Switch** | 1 | M | False | True or False. |

Add Dialog of Interbank Block Trade

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| ID | Alphanumeric  **Text Input**  **(With Content Assist)** | 32 | M | - | The Contract Series ID. |
| Price | Price  **Spinner Input (With up / down per tick unit)** | [Ref to Data Type](#_Data_Type) | M | - | The Price. |
| Quantity | Quantity  **Text Input**  **(With up / down per tick size)** | [Ref to Data Type](#_Data_Type) | M | - | The Quantity. |
| Side | Alphanumeric  **Dropdown** | - | M | - | Side of the trade  Domain Value:  - Buy  - Sell |
| Customer Information | Alphanumeric | 15 | O | - | Info for buy side. |
| Give Up Participant | Alphanumeric | 5 | O | - | Either a participant or an account to give up to. |
| Give Up Information | Alphanumeric | 15 | O | - | Optional free text field that will follow the trade as information to the take up participant. |
| Position Effect | Alphanumeric  **Dropdown** | 5 | O |  | The requested position, that is, open or close. |
| ~~ATID~~ | ~~Alphanumeric~~ | ~~5~~ | ~~O~~ | ~~-~~ | ~~Client Service ID.~~ |
| ~~LEI~~ |  | ~~10~~ |  |  | ~~Enter Legal Entity Identifier. The global unique identifier used for counterparty identification.~~ |

**#FS10014a\_S0612\_01000**

When Type is **(Day 2 Feature) Enter Onbehalf Block Trade:**

Enter Trade Report view

| Column | Type | Length | Remarks |
| --- | --- | --- | --- |
| **CONTRACT** | | | |
| ID | Alphanumeric | 32 | The instrument for the trade. |
| **SIDE** | | | |
| BUY/SELL | Alphanumeric | - | Side of the trade  Domain Value:  - Buy  - Sell |
| **QTY/PRICE** | | | |
| QTY | Quantity | [Ref to Data Type](#_Data_Type) | Quantity of the trade |
| PRICE | Price | [Ref to Data Type](#_Data_Type) | The price of the trade. |
| **OWN ACCOUNT *(Only Available in Accept Block Trade Dialog)*** | | | |
| Customer Information | Alphanumeric | 15 | Info for own account.  ***(Cell Editable in Accept Block Trade Dialog)*** |
| Give Up Participant | Alphanumeric | 5 | Either a participant or an account to give up to.  ***(Cell Editable in Accept Block Trade Dialog)*** |
| Give Up Information | Alphanumeric | 15 | Optional free text field that will follow the trade as information to the take up participant.  ***(Cell Editable in Accept Block Trade Dialog)*** |
| POS | Alphanumeric  **Dropdown** | 5 | The requested position, that is, open or close.  ***(Cell Editable in Accept Block Trade Dialog)*** |
| ATID | Alphanumeric | 5 | Active Trader ID.  ***(Cell Editable in Accept Block Trade Dialog)*** |
| ~~LEI~~ | ~~Alphanumeric~~ | ~~10~~ | ~~Enter Legal Entity Identifier. The global unique identifier used for counterparty identification.~~  ***~~(Cell Editable in Accept Block Trade Dialog)~~*** |

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Trade Conclusion Date | Date and Time | 8 | M | Current business date | Future date is not allowed. |
| Trade Conclusion Time | Time | 6 | M | Time of open this page | Future time is not allowed. |
| Buyer | Alphanumeric  **Text Input**  **(With Content Assist)** | TBC | TBC | TBC | The buyer. |
| Seller | Alphanumeric  **Text Input**  **(With Content Assist)** | TBC | TBC | TBC | The seller. |

Enter Trade Report Dialog

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Contract ID | Alphanumeric  **Text Input**  **(With Content Assist)** | 32 | M | - | The Contract Series ID. |
| Price | Price  **Spinner Input (With up / down per tick unit)** | [Ref to Data Type](#_Data_Type) | M | - | The Price. |
| Quantity | Quantity  **Text Input**  **(With up / down per tick size)** | [Ref to Data Type](#_Data_Type) | M | - | The Quantity. |
| Side | Alphanumeric  **Dropdown** | - | M | - | Side of the trade  Domain Value:  - Buy  - Sell |

**Tooltips**

**#FS10014a\_S0612\_01101**

When Type is **Internal Block Trade**:

| Column | Tooltips |
| --- | --- |
| ID | The contract for the trade. |
| QTY | Quantity of the trade (number of contracts). |
| PRICE | The price of the trade. |
| Customer Information | Info for buy side. |
| Give Up Participant | Specifies a participant or an account to give up to. |
| Give Up Information | Optional free text field that will follow the trade as information to the take up participant. |
| POS | Specifies the requested position, that is, open or close. |
| ~~ATID~~ | ~~Specifies the client service ID~~ |
| ~~LEI~~ | ~~Enter Legal Entity Identifier. The global unique identifier used for counterparty identification.~~ |
| Customer Information | Info for sell side. |
| Give Up Participant | Specifies a participant or an account to give up to. |
| Give Up Information | Optional free text field that will follow the trade as information to the take up participant. |
| POS | Specifies the requested position, that is, open or close. |
| ~~ATID~~ | ~~Specifies the client service ID~~ |
| ~~LEI~~ | ~~Specifies the Legal Entity Identifier. The global unique identifier used for counterparty identification.~~ |

**#FS10014a\_S0612\_01201**

When Type is **Interbank Block Trade**:

| Column | Tooltips |
| --- | --- |
| ID | The contract for the trade. |
| BUY/SELL | Specifies the side. |
| QTY | Quantity of the trade (number of contracts). |
| PRICE | The price of the trade. |
| Customer Information | Info for own account. |
| Give Up Participant | Specifies a participant or an account to give up to. |
| Give Up Information | Optional free text field that will follow the trade as information to the take up participant. |
| POS | Specifies the requested position, that is, open or close. |
| ATID | Specifies the client service ID |
| ~~LEI~~ | ~~Specifies the Legal Entity Identifier. The global unique identifier used for counterparty identification.~~ |

**#FS10014a\_S0612\_01300**

When Type is **(Day 2 Feature) Enter Onbehalf Block Trade**:

| Column | Tooltips |
| --- | --- |
| ID | The contract for the trade. |
| BUY/SELL | Specifies the side. |
| QTY | Quantity of the trade (number of contracts). |
| PRICE | The price of the trade. |

**Data refresh in table**

**#FS10014a\_S0612\_01400**

NA

**Default Sorting Order**

**#FS10014a\_S0612\_01500**

Base on Input ordering

**Filtering Criteria**

**#FS10014a\_S0612\_01600**

N/A

**Read / Write Permission Behaviour**

**#FS10014a\_S0612\_01700**

| Permission | Behavior |
| --- | --- |
| Read | N/A. As this view is for entering new trade report only. |
| Write | User with write permission can enter a new trade report. |

**Action**

1. **Add Trade**

**#FS10014a\_S0612\_01800**

Open the Enter Trade Report dialog view. Users can then input a trade to add it to the table.

1. **Import Trade Reports**

**#FS10014a\_S0612\_01901**

Import trade reports from an Excel sheet (csv format). To create a template for import, enter one or several rows and press the export icon. The Excel sheet can be modified as needed and then used for import.

Internal CSV format

| Column | Description |
| --- | --- |
| CONTRACT: ID | Refer to FS10014a\_S0612\_00801 |
| QTY/PRICE: QTY | Refer to FS10014a\_S0612\_00801 |
| QTY/PRICE: PRICE | Refer to FS10014a\_S0612\_00801 |
| BUYER: Customer Information | Refer to FS10014a\_S0612\_00801 |
| BUYER: Give Up Participant | Refer to FS10014a\_S0612\_00801 |
| BUYER: Give Up Information | Refer to FS10014a\_S0612\_00801 |
| BUYER: POS | Refer to FS10014a\_S0612\_00801 |
| SELLER: Customer Information | Refer to FS10014a\_S0612\_00801 |
| SELLER: Give Up Participant | Refer to FS10014a\_S0612\_00801 |
| SELLER: Give Up Information | Refer to FS10014a\_S0612\_00801 |
| SELLER: POS | Refer to FS10014a\_S0612\_00801 |

Interbank CSV format

| Column | Description |
| --- | --- |
| CONTRACT: ID | Refer to FS10014a\_S0612\_00901 |
| SIDE: Buy/Sell | Refer to FS10014a\_S0612\_00901 |
| QTY/PRICE: QTY | Refer to FS10014a\_S0612\_00901 |
| QTY/PRICE: PRICE | Refer to FS10014a\_S0612\_00901 |
| OWN ACCOUNT: Customer Information | Refer to FS10014a\_S0612\_00901 |
| OWN ACCOUNT: Give Up Participant | Refer to FS10014a\_S0612\_00901 |
| OWN ACCOUNT: Give Up Information | Refer to FS10014a\_S0612\_00901 |
| OWN ACCOUNT: POS | Refer to FS10014a\_S0612\_00901 |

**#FS10014a\_S0612\_02000**

Block trade quantities reported in the Price Information window is reported in the Total Turnover column. In addition, the price and quantity of trades executed through the Enter Trade Report windows are not included in the statistics calculation in Trade History – Aggregated window.

(TBC for Multi-leg support)

1. **Export to CSV File**

**#FS10014a\_S0612\_02100**

The users can click "**Export to CSV File**" to export those records from GUI table.

![](data:image/png;base64...)

**#FS10014a\_S0612\_02200**

Block trade quantities reported in the Price Information window is reported in the Total Turnover column. In addition, the price and quantity of trades executed through the Enter Trade Report windows are not included in the statistics calculation in Trade History – Aggregated window.

1. **Edit Trade**

**#FS10014a\_S0612\_02300**

Open Enter Trade Report dialog view. Users can amend an added trade for the selected row.

1. **Sw̲itch buyer/seller (TBC)**

**#FS10014a\_S0612\_02400**

Switches buyer to seller or the other way around.

1. **Delete**

**#FS10014a\_S0612\_02500**

Deletes the selected row(s) from the list of legs.

1. **E̲nter trade report**

**#FS10014a\_S0612\_02600**

E̲nter trade report.

\*A confirmation box maybe triggered due to server’s response. Users are required to confirm whether to proceed with the action.

1. **Cancel**

**#FS10014a\_S0612\_02700**

Exit the dialog.

**Validation**

**#FS10014a\_S0612\_02800**

1. **Add Trade**

TBC

1. **Import Trade Reports**

TBC

1. **Export to CSV File**

TBC

1. **Edit Trade**

TBC

1. **Sw̲itch buyer/seller (TBC)**

TBC

1. **Delete**

TBC

1. **E̲nter trade report**
2. **#FS10014a\_S0612\_02900** Minimum volume requirement on the block trade
3. TBC
4. **Cancel**

TBC

**User Notification**

**#FS10014a\_S0612\_03000**

TBC

## Pending Trade Report and Block Trade History

**#FS10014a\_S0613\_00100**

**Description**

**#FS10014a\_S0613\_00201**

It allows Internal and external users to manage unmatched interbank(Day 1) and on-behalf block trade (Day2) reports.

Unmatched block trade can be cancelled by requester only and specified counterparty can either accept or reject. Unmatched on-behalf block trade can be cancelled by both requester, buyer and seller.

Block Trade History captures details of Block Trade activities, including Requests, Responses, Confirmations, Declines, and Cancellations. It is available to both internal and external users and provides visibility into trade details as well as the Pending Trade report. Historical trade information is accessible for Sent, Received, and Confirmed records through the trade report dialog. Please note that actions button/menu such as Cancel, Accept, and Decline are not applicable on the history screen. Tables attributes and detail dialog fields for display are identical to Pending Trade report.

The Pending Trade Report and Block Trade History windows will return the latest 60K records at maximum.

**Accessing the Function**

**#FS10014a\_S0613\_00300**

Pending Trade Report and Block Trade History window can be opened from the Menu. ODP Online allows only one Pending Trade Report window and one Block Trade History to be opened.

**Scope of Data**

**#FS10014a\_S0613\_00400**

Unmatched interbank (Day 1) and on-behalf block trade reports (Day2) are displayed in the

Pending Trade Reports window.

**UI Layout**

**#FS10014a\_S0613\_00500**

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

TODO add a new Screen for Internal User

\*Internal user should be able to filter by Exchange participant for new query

**Attributes**

**#FS10014a\_S0613\_00600**

| Column | Type | Remarks |
| --- | --- | --- |
| DIRECTION | Alphanumeric | The direction of the trade. (Pending Trade Report only) |
| ACTION | Alphanumeric | Action taken on the trade. (Block Trade History only) |
| NO. OF LEGS | Numeric | Number of legs |
| ORDER NUMBER | Alphanumeric | The order number of the trade. |
| COUNTERPARTY | Alphanumeric | The counter party of the trade. |
| TRADE CONCLUSION DATE AND TIME | Date Time | The trade conclusion date and time |
| SPECIAL INDICATOR | Alphanumeric | The special indicator |
| AGGREGATED TRADE | Alphanumeric | The aggregated trade. TRUE or FALSE |
| RECEIVE TIME | Date Time | The receive time. |

**Tooltips**

**#FS10014a\_S0613\_00700**

| Column | Tooltips |
| --- | --- |
| DIRECTION | Specifies the direction of the trade. |
| ACTION | Specifies the action taken on the block trade request. |
| NO. OF LEGS | Specifies the number of legs. |
| ORDER NUMBER | Specifies the order number. |
| ACTION | Specifies the action taken on the block trade request. |
| COUNTERPARTY | Specifies the counterparty. |
| TRADE CONCLUSION DATE AND TIME | Specifies the trade conclusion date and time. |
| SPECIAL INDICATOR | Specifies the special indicator. |
| AGGREGATED TRADE | Specifies the aggregated trade. |
| RECEIVE TIME | Specifies the receive time. |

**Data refresh in table**

**#FS10014a\_S0613\_00800**

For Internal user, pending trade will not auto update and user needs to click on Apply to query a new snapshot for a target participant.

For External user, pending trade will update automatically upon any changes.

**Default Sorting Order**

**#FS10014a\_S0613\_00900**

Arrival time

**Filtering Criteria**

**#FS10014a\_S0613\_01001**

Following filter fields are available for criteria search.

Display right above the table

| Filtering Criteria | Type |
| --- | --- |
| DIRECTION | Text Input (with Dropdown) |

[Revoked]

**Read / Write Permission Behaviour**

**#FS10014a\_S0613\_01100**

| Permission | Behavior |
| --- | --- |
| Read | User can perform the following:   * View all the data in the Pending Trade Report * Perform Sorting/Filtering on the Pending Trade Report * Export Pending Trade Report as CSV File |
| Write | User can perform the following:   * View all the data in the Pending Trade Report * Perform Sorting/Filtering on the Pending Trade Report * Export Pending Trade Report as CSV File * Perform Cancel action by requester * Perform Accept action by receiver * Perform Decline action by receiver |

**Action**

1. **Cancel**

**#FS10014a\_S0613\_01200**

Cancel the pending trade by Requester

1. **Accept / Decline in Open Pending Trade Report Dialog**

**#FS10014a\_S0613\_01300**

Open Accept Pending Trade Report Dialog.

**#FS10014a\_S0613\_01401**

If users do not wish to accept the block trade request, the request can be cancelled manually, or left it unaccepted and will be expired at day end. Receiver can decline the block trade request directly.

![](data:image/png;base64...)

For accepting a pending block trade, both interbank and on-behalf block trade should use the interbank block trade table to fill in own account information.

Table fields can vary depending on the trade type. Refer to Enter Trade Report attributes section for more details.

1. **Export to CSV File**

**#FS10014a\_S0613\_01500**

The users can click "**Export to CSV File**" to export those records from GUI table.

1. **~~Open Block Trade History \*TBC the detail to display~~**

**~~#FS10014a\_S0613\_01510~~**

~~The users can click "~~**~~Open Block Trade History~~**~~" to show the history of block trade for NEW/CANCEL/ACCEPT.~~

**Validation**

**#FS10014a\_S0613\_01601**

1. **Cancel**
2. For unmatched interbank block trade, cancellation can only be done by requester.
3. For unmatched on-behalf block trade, cancellation can only be done by both requester, buyer and seller (Day 2).
4. **Accept**
5. Mandatory fields are all provided
6. **Decline**
7. For unmatched interbank block trade, cancellation can only be done by receiver.

**User Notification**

**#FS10014a\_S0613\_01700**

TBC

**Highlight**

**#FS10014a\_S0613\_01800**

Block Trades with Counter Party that is not equal to the user is highlighted in blue.

## Instruments

#FS10014a\_S0614\_00100

**Description**

#FS10014a\_S0614\_00200

The Instruments window allows the users to gather instrument information.

This window is applicable to both external and internal. The layout is the same for both and only one Instrument Screen can be opened at a time.

This window provides information about instrument series and pre-defined standard combinations. Information is displayed in the details.

Expired series will be displayed in this window during After-Hours Trading session on their respective last trading day. However, those series will not be tradable.

3 ways to display instrument information in Instruments window

1. Enter the name of the corresponding instrument in the “Instrument” field.
2. Select the corresponding instrument by the filter field in the “Instrument” field.
3. Link Instruments window with Price Information / Quotes windows, select the corresponding instrument through either window.

**Accessing the Function**

#FS10014a\_S0614\_00300

The Instruments window can be opened from the INSTRUMENTS menu. ODP online allows only one Instruments window to be opened.

**UI Layout**

#FS10014a\_S0614\_00400

![](data:image/png;base64...)

**Attributes**

#FS10014a\_S0614\_00500

| Field | Type | Remarks |
| --- | --- | --- |
| Long ID | Alphanumeric | The instrument identity. |
| Market name | Alphanumeric | The market name. |
| Underlying ID | Alphanumeric | The underlying identity. |
| Underlying | Alphanumeric | The underlying description. |
| Underlying type | Alphanumeric | The underlying type. |
| Instrument type | Alphanumeric | The instrument type. |
| Currency | Alphanumeric | The currency in which the instrument is traded. |
| Last trading time | Date and Time | The Effective Last Trading Date if exist, else Last Trading Date. |
| Strike Price | Price | The option strike price. |
| Contract size | Numeric | The contract size. |
| Legs | Numeric | The legs and ratio for combo. |

**Tooltips**

#FS10014a\_S0614\_00600

N/A

**Read / Write Permission Behaviour**

#FS10014a\_S0614\_00700

| Permission | Behavior |
| --- | --- |
| Read | User can perform the following:   * View all the instrument details |
| Write | N/A. There should be no Write permission for this window. User should either have no permission or Read permission. |

**Action**

#FS10014a\_S0614\_00800

N/A

**Validation**

#FS10014a\_S0614\_00900

NA

**User Notification**

#FS10014a\_S0614\_01000

N/A

## Price Information

#FS10014a\_S0615\_00100

**Description**

#FS10014a\_S0615\_00200

The Price Information window is a central window in ODP online, displaying market prices and updated trade information.

This window is applicable to both external and internal. The layout is the same for both.

**Accessing the Function**

#FS10014a\_S0615\_00300

The Price Information window can be opened from the menu. ODP online allows up to 4 Price Information screens for external and 8 Price Information screens for Internal.

**Scope of Data**

#FS10014a\_S0615\_00400

Internal users can access outright, combo, TMC and underlying (Index & Stock without market data in place). While external user can access outright, combo and TMC only.

This window displays the market prices and updated trade information in the selected instrument, i.e. the best bid and ask prices, last traded price, last traded quantity, high, low, open prices, and turnover.

This window has limited to 150K rows with conflated market data display to screen.

**UI Layout**

#FS10014a\_S0615\_00500

![](data:image/png;base64...)

**Attributes**

#FS10014a\_S0615\_00600

| Category | Field | Type | Remarks |
| --- | --- | --- | --- |
| INSTRUMENT | ID | Alphanumeric | The instrument identity. |
| UL ID | Alphanumeric | The underlying ID. |
| UL | Alphanumeric | The underlying. |
| MKT | Alphanumeric | The market. |
| INST GROUP TYPE | Alphanumeric | The instrument group type. |
| INST TYPE | Alphanumeric | The instrument type. |
| CUR | Alphanumeric | The currency in which the instrument is traded. |
| TSS | TBC | The trading session status. |
| ~~ISS~~ | ~~TBC~~ | ~~The instrument series status.~~ |
| LAST DATE | TBC | Last trading date of instrument  (Default set to hidden) |
| STRIKE | TBC | Strike price of instrument  (Default set to hidden) |
| MARKET | B QTY | Quantity | The best bid quantity. |
| BID | Price | The best bid price. |
| ASK | Price | The best ask price. |
| A QTY | Quantity | The best ask quantity. |
| TRADE INFORMATION | ~~EP~~ COP | Price | ~~The equilibrium price.~~ Calculated Opening Price |
| LAST | Price | The latest traded price. |
| L QTY | Quantity | The latest traded quantity. |
| HIGH | Price | The highest traded price during current trading day. |
| LOW | Price | The lowest traded price during current trading day. |
| OPEN | Price | The opening price. |
| ~~REF~~ | ~~Price~~ | ~~The reference price.~~ |
| TURN | TBC | The total number of traded contracts during current trading day. |
| O INT | TBC | The open interest. |
| TOT TR QTY | TBC | The total trade report volume. |
| AHT TRADE INFORMATION | LAST | Price | The latest traded price of AHT. |
| L QTY | Quantity | The latest traded quantity of AHT. |
| HIGH | Price | The highest traded price during AHT. |
| LOW | Price | The lowest traded price during AHT. |
| OPEN | Price | The opening price of AHT. |
| TURN | TBC | The total number of traded contracts during ATH. |
| TOT TR QTY | TBC | The total trade report volume of AHT. |
| ~~INDICATIVE~~ | ~~B QTY~~ | ~~Price~~ | ~~The best indicative bid quantity.~~ |
| ~~BID~~ | ~~Price~~ | ~~The best indicative bid price.~~ |
| ~~ASK~~ | ~~Price~~ | ~~The best indicative ask price.~~ |
| ~~A QTY~~ | ~~Price~~ | ~~The best indicative ask quantity.~~ |

**Tooltips**

#FS10014a\_S0615\_00700

| Category | Column | Tooltips |
| --- | --- | --- |
| Instrument | ID | Specifies the instrument identity. |
| UL ID | Specifies the underlying ID. |
| UL | Specifies the underlying. |
| MKT | Specifies the market. |
| INST GROUP TYPE | Specifies the instrument group type. |
| INST TYPE | Specifies the instrument type. |
| CUR | Specifies the currency in which the instrument is traded. |
| TSS | Specifies the trading session status. |
| ~~ISS~~ | ~~Specifies the instrument series status. The active state is shown in bold if its stronger than the TSS state.~~ |
| LAST DATE | Last Trading date of the instrument |
| STRIKE | Strike price of the instrument |
| Market | B QTY | Specifies the best bid quantity. |
| BID | Specifies the best bid price. |
| ASK | Specifies the best ask price. |
| A QTY | Specifies the best ask quantity. |
| Trade Information | ~~EP~~ COP | ~~Specifies the equilibrium price.~~  Specifies the calculated opening price. |
| LAST | Specifies the latest traded price. |
| L QTY | Specifies the latest traded quantity. |
| HIGH | Specifies the highest traded price during current trading day. |
| LOW | Specifies the lowest traded price during current trading day. |
| OPEN | Specifies the opening price. |
| ~~REF~~ | ~~Specifies the reference price.~~ |
| TURN | Specifies the total number of traded contracts during current trading day. |
| O INT | Specifies the open interest. |
| TOT TR QTY | Specifies the total trade report volume. |
| ~~Indicative~~ | ~~B QTY~~ | ~~Specifies the best indicative bid quantity.~~ |
| ~~BID~~ | ~~Specifies the best indicative bid price.~~ |
| ~~ASK~~ | ~~Specifies the best indicative ask price.~~ |
| ~~A QTY~~ | ~~Specifies the best indicative ask quantity.~~ |

**Data Refresh in Table**

#FS10014a\_S0615\_00800

This window will automatically update the price and trade information but in conflated way.

For numeric columns with price for example BID, ASK and etc, show foreground colour to green if new value is bigger than current value and last for 1 sec in best effort basis. Show foreground colour to red if new value is smaller than current value and last for 1 sec in best effort basis.

**Default Sorting Order**

#FS10014a\_S0615\_00900

This window is sorted by ascending order of Last Trading date, Instrument Group, Strike price (ASC) by default.

**Filtering Criteria**

#FS10014a\_S0615\_01001

The following filter fields are available for criteria search

Display right above the table

| Filtering Criteria | Type |
| --- | --- |
| ID | Text Input (with Content Assist) |

[Revoked]

**Read / Write Permission Behaviour**

#FS10014a\_S0615\_01100

| Permission | Behavior |
| --- | --- |
| Read | User can perform the following:   * View the price information of all instruments |
| Write | User can perform the following:   * Send quote request |

**Action**

a. #FS10014a\_S0615\_01200 Send Quote Request

User can send a quote request of a selected single instrument. The quote request will be displayed in the Market Message window. The Quote window will show the quote result.

To send a quote request:

1. Select an instrument from the Price Information table
2. Enter the quantity on the “Qty” field \*Optional field
3. Click “Quote Request”

b. #FS10014a\_S0615\_01300 Export to CSV File

The users can click "**Export to CSV File**" to export those records from GUI table.

c. #FS10014a\_S0615\_01400 Column Setting

Refer to 3.12 User Setting

~~User can customize Price Information window by using column setting. The customization supports ordering, show, and hide the column(s).~~

~~To reorder column:~~

1. ~~Drag a column header to the target destination~~
2. ~~Drop the column header~~

~~To show or hide column:~~

1. ~~Move cursor to any column header~~
2. ~~Click ![](data:image/png;base64...)~~
3. ~~Click ![](data:image/png;base64...)~~
4. ~~Select a column to show or unselect a column to hide~~

**Validation**

#FS10014a\_S0615\_01500

N/A

**User Notification**

#FS10014a\_S0615\_01600

Reject/Failed – Show Reject/Failed Clie message if required

Quote Confirmation – base on confirmation setting screen

## Order Depth

#FS10014a\_S0616\_00100

**Description**

#FS10014a\_S0616\_00200

The Order Depth window shows the market depth of a particular instrument series.

This window is applicable to both external and internal, but the layout is identical. Trader ID and EP of all orders are available for Internal user, but for external users they can only see Trader ID and EP of their own orders.

**Accessing the Function**

#FS10014a\_S0616\_00300

The Order Depth window can be opened from the menu. ODP online allows at most 8 Order Depth windows to be opened for external user, and 3 for internal.

**Scope of Data**

#FS10014a\_S0616\_00400

This window shows the market depth of a particular instrument series. Orders are ranked on a price and time priority basis which managed by ME

#FS10014a\_S0616\_00500

Trader and Participant Fields

External Users

* Trader and Participant fields are visible only if the order was placed by the user or another user in the same Participant

Internal Users

* Trader and Participant fields of all orders are visible to the user

#FS10014a\_S0616\_00600

Ranking Indicator

The Ranking indicator allows the user to identify the ranking of their orders. The field value refers to the price ranking in the market of the selected order, which is the row index of the mouse selected cell.

#FS10014a\_S0616\_00700

Quantity Indicator

The Quantity indicator displays the total number of contracts from ranking 1 to the ranking highlighted by the user. The field value refers to the total quantity available in the market at prices equal to or better than the selected cell.

#FS10014a\_S0616\_00800

Average Display

The Average ASK or BID indicator displays the quantity-weighted average price of orders from ranking 1 to the ranking highlighted by the user. In addition, the quantity used for calculation can also be inputted in the QTY field above based upon the selected side.

**UI Layout**

#FS10014a\_S0616\_00901

![](data:image/png;base64...)

Auto checkbox is only available for internal user.

Trader own orders highlight as green background colour.

~~Implied orders will be displayed in dark orange colour, where implied order is sorted by price and put lower than explicit order of the same price~~

Implied orders will be indicated with “\*” beside the Qty value, no colour highlight is required.

**Attributes**

#FS10014a\_S0616\_01001

| Category | Field | Type | Remarks |
| --- | --- | --- | --- |
| Bid Orders | B TRD | Alphanumeric | The bid trader. |
| B PART | Alphanumeric | The bid participant. |
| TYPE | Alphanumeric | This is the order type.  Domain Value:  **Limit Order display as - LMT**  **Market to Limit Order display as MTL**  **Market Order display as - MKT** |
| B QTY | Quantity | The bid quantity. |
| BID | Price | The bid price. Display COP if exist, otherwise display MKT for Market Order and Market to limit order |
| Ask Orders | ASK | Price | The ask price. Display COP if exist, otherwise display MKT for Market Order and Market to limit order |
| A QTY | Quantity | The ask quantity. |
| TYPE | Alphanumeric | The order type.  Domain Value:  **Limit Order display as - LMT**  **Market to Limit Order display as MTL**  **Market Order display as - MKT** |
| A PART | Alphanumeric | The ask participant. |
| A TRD | Alphanumeric | The ask trader. |

**Tooltips**

#FS10014a\_S0616\_01100

| Category | Column | Tooltips |
| --- | --- | --- |
| Bid Orders | B TRD | Specifies the bid trader (only if the order was placed by your own firm). |
| B PART | Specifies the bid participant (only if the order was placed by your own firm). |
| TYPE | Specifies the order type. |
| B QTY | Specifies the bid quantity. |
| BID | Specifies the bid price. |
| Ask Orders | ASK | Specifies the ask price. |
| A QTY | Specifies the ask quantity. |
| TYPE | Specifies the order type. |
| A PART | Specifies the ask participant (only if the order was placed by your own firm). |
| A TRD | Specifies the ask trader (only if the order was placed by your own firm). |

**Data Refresh in Table**

#FS10014a\_S0616\_01200

No auto update for external user

It will update per 15 seconds for internal user if Auto checkbox is checked

**Default Sorting Order**

#FS10014a\_S0616\_01300

Bid Orders

* The table are sorted by the **descending** order of Price and ascending order of Time.

Ask Orders

* The table are sorted by the **ascending** order of Price and ascending order of Time.

No user sorting is available

**Filtering Criteria**

#FS10014a\_S0616\_01400

The following filter fields are available for criteria search

Display right above the table

| Filtering Criteria | Type |
| --- | --- |
| ID | Instrument ID  Text Input (with Content Assist) |

**Read / Write Permission Behaviour**

#FS10014a\_S0616\_01500

| Permission | Behavior |
| --- | --- |
| Read | User can perform the following:   * View the order depth of all instruments |
| Write | N/A. There should be no Write permission for this window. User should either have no permission or Read permission. |

**Action**

a. #FS10014a\_S0616\_01600Trading via Order Depth Window

#FS10014a\_S0616\_01700

This action is appliable to the external users only. User can open Execute Order dialog to execute an order if this order is not participant’s own order.

#FS10014a\_S0616\_01800

To execute an order

1. Double click an order from the Order Depth table.
2. Execute Order dialog will be opened, the quantity will depend on the order in the depth user choose as accumulated quantity (Including own order if they are part of the selected order depth)

~~b. Change Order~~

~~External user can open Change Order dialog to change own order only. The order details will also be showed and available for change in change order screen. # BRD\_DT\_0049\_030\_17200~~ ~~Internal user can also open Change Order dialog no matter the participant of the order. # BRD\_DT\_0049\_030\_17900~~

~~To change an order~~

* 1. ~~Double click an order from the Order Depth table.~~
  2. ~~Change Order dialog will be opened.~~

b. #FS10014a\_S0616\_01900 Restrict No. of Orders Displayed

~~User can limit the number of orders shown. When this function is activated, maximum of 125 orders on the bid side and 125 orders on the ask side could be displayed in the Order Depth window.~~  GUI set a maximum number of orders to display up to 5k rows.

~~To restrict the number of orders~~

1. ~~Click Orders Limited checkbox~~

c. #FS10014a\_S0616\_02000 Export to CSV File

The users can click “More Action” -> "**Export to CSV File**" to export those records from GUI table.

**Validation**

#FS10014a\_S0616\_02100

N/A

**User Notification**

#FS10014a\_S0616\_02200

Subscription Failed – Shows error message to user if failed to subscribe order depth from server

## Price Depth

#FS10014a\_S0617\_00100

**Description**

#FS10014a\_S0617\_00200

The Price Depth window shows the five best bid and ask prices level in the market.

This window is applicable to both external and internal. The layout is the same for both.

**Accessing the Function**

#FS10014a\_S0617\_00300

The Price Depth window can be opened from the menu. ODP online allows at most 8 Price Depth window to be opened for both internal and external users.

**Scope of Data**

#FS10014a\_S0617\_00400

Both internal and external users access the same scope of the data.

This window shows the five best bid and ask prices level in the market along with the accumulated quantities for an instrument on real-time basis. The best bid starts from B1 down to B5 and the best ask starts from A1 up to A5.

Average Display

Display the calculated average price for a specified quantity indicated in the Qty for Calc field or based on selection in price ranking (e.g. if selected cell is A3, Qty for Calculation will be updated base on A1 + A2 + A3). If an Ask Price column is highlighted, this would display the Average ASK. Similarly, if a Bid Price column is highlighted, the Average BID will be displayed. The fields Ranking and Quantity refer to the price ranking in the market of the selected cell and the total quantity available in the market at prices equal to or better than the selected cell.

**UI Layout**

#FS10014a\_S0617\_00500

![](data:image/png;base64...)

**Attributes**

#FS10014a\_S0617\_00600

| Category | Field | Type | Remarks |
| --- | --- | --- | --- |
| Bid Prices (B1 – B5) | Price | Price | The 1st to 5th best bid price. |
| Qty | Quantity | The 1st to 5th best bid quantity. |
| Ask Prices (A1 – A5) | Price | Price | The 1st to 5th best ask price. |
| Qty | Quantity | The 1st to 5th best ask quantity. |

**Tooltips**

#FS10014a\_S0617\_00700

| Category | Column | Tooltips |
| --- | --- | --- |
|  | P/Q | Specifies that the row is a price or quantity row. |
| Bid Prices | B5 | Specifies the 5th best bid price. |
| B4 | Specifies the 4th best bid price. |
| B3 | Specifies the 3rd best bid price. |
| B2 | Specifies the 2nd best bid price. |
| B1 | Specifies the 1st best bid price. |
| Ask Prices | A1 | Specifies the 1st best ask price. |
| A2 | Specifies the 2nd best ask price. |
| A3 | Specifies the 3rd best ask price. |
| A4 | Specifies the 4th best ask price. |
| A5 | Specifies the 5th best ask price. |

**Data Refresh in Table**

#FS10014a\_S0617\_00800

This window will automatically update the price information.

For numeric columns, show background colour to green if new value is bigger than current value and last for 1 sec. Show background colour to red if new value is smaller than current value and last for 1 sec.

**Default Sorting Order**

#FS10014a\_S0617\_00900

N/A

No user sorting is available

**Filtering Criteria**

#FS10014a\_S0617\_01000

The following filter fields are available for criteria search

Display right above the table

| Filtering Criteria | Type |
| --- | --- |
| ID | Text Input (with Content Assist) |

**Read / Write Permission Behaviour**

#FS10014a\_S0617\_01100

| Permission | Behavior |
| --- | --- |
| Read | User can perform the following:   * View the price depth of all instruments |
| Write | N/A |

**Action**

a. #FS10014a\_S0617\_01200 Trading in Price Depth Window

Double click will open Execute Order Dialog

b. #FS10014a\_S0617\_01300 Export to CSV File

The users can click "**Export to CSV File**" to export those records from GUI table.

**Validation**

#FS10014a\_S0617\_01400

N/A

**User Notification**

#FS10014a\_S0617\_01500

Subscription Failed – Shows error message to user if failed to subscribe order depth from server

## Market Message

#FS10014a\_S0618\_00100

**Description**

#FS10014a\_S0618\_00200

The Market Message window shows the market messages sent by the exchange including instrument status messages, market announcements, and quotes messages.

This window is applicable to both external and internal. The layout is the same for both.

**Accessing the Function**

#FS10014a\_S0618\_00300

The Market Message window can be opened from the menu. Only one Market Message window can be opened at a time.

**Scope of Data**

#FS10014a\_S0618\_00400

Both internal and external users access the same scope of the data.

The Market Message window serves as one of the communication channels between the Exchange and users. Such messages include openings and closings of the markets, quote request broadcast, potential connection problems, and other information of general interest. Users can view messages from the start of the trading day from the Market Messages window regardless of login time.

Market Message is maximum to 10 lines and 80 chars each.

#FS10014a\_S0618\_00500

There are 3 major types of messages or alerts will be displayed in the Market Messages window:

1. #FS10014a\_S0618\_00600 Instrument status messages - record of changes of instrument market status.
2. #FS10014a\_S0618\_00700 Market announcements – messages / warning alerts initiated by the Exchange.
3. #FS10014a\_S0618\_00800 Quotes messages - quote request generated by other users.

Message Format

* 1. #FS10014a\_S0618\_00900 Time Column – DD-MMM-YYYY HH:MM:SS
  2. #FS10014a\_S0618\_01000 Market state change message - Market / Instrument type / Instrument class + the name of the type + “has changed to state” / will move to + state name + in 1 minutes or market activity.
  3. #FS10014a\_S0618\_01100 Quote request message - Quote request in + series name; Bid and Ask, No quantity specified / quantity xx.

This window will return the latest 60K market messages at maximum.

**UI Layout**

#FS10014a\_S0618\_01201

**![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)**

\*Full Message Body will be displayed based on user selection in the Message table

**Attributes**

#FS10014a\_S0618\_01300

| Column | Type | Remarks |
| --- | --- | --- |
| TIME | Date and Time | The time at which the message was received. |
| PRIORITY | Alphanumeric | Priority of the message |
| MESSAGE TYPE | Alphanumeric | Message type of the message |
| SUBJECT | Alphanumeric | Message Subject of the message |

**Tooltips**

#FS10014a\_S0618\_01400

| Column | Tooltips |
| --- | --- |
| TIME | Specifies the time at which the message was received. |
| PRIORITY | Priority of the message |
| MESSAGE TYPE | Message type of the message |
| SUBJECT | Message Subject of the message |

**Highlight Colour**

#FS10014a\_S0618\_01500

| Priority | Color |
| --- | --- |
| ~~LOW~~ | ~~Background color (198, 181, 91)~~ |
| NORMAL | Background color (198, 181, 91) |
| ~~HIGH~~  IMPORTANT | Background color (255, 165, 0) |
| CRITICAL | Background color (255, 0, 0) |

**Data Refresh in Table**

#FS10014a\_S0618\_01600

This window will automatically update the market message table.

**Default Sorting Order**

#FS10014a\_S0618\_01700

Sort by message TIME in ASC

**Filtering Criteria**

#FS10014a\_S0618\_01800

The following filter fields are available for criteria search

Display right above the table

| Filtering Criteria | Type |
| --- | --- |
| Type | Dropdown  **Available types:**  Trading State Change,  Alert before Trading State Change,  Underlying State Change,  Instrument/Combo State Change,  Quote Request,  VCM Cooling Off Triggered,  VCM Cooling Off Ended,  Trading Halt Triggered,  AHT Price Limit Triggered,  AHT Price Limit Alert,  Error Trade,  Manual Market Announcement |

**Read / Write Permission Behaviour**

#FS10014a\_S0618\_01900

| Permission | Behavior |
| --- | --- |
| Read | User can perform the following:   * View all the market messages |
| Write | N/A |

**Action**

a. #FS10014a\_S0618\_02000 Export to CSV File

The users can click "**Export to CSV File**" to export those records from GUI table.

**Validation**

#FS10014a\_S0618\_02100

N/A

**User Notification**

#FS10014a\_S0618\_02200

Critical Priority Message – display user warning notification at the top of this window and highlight Critical message is received. Apart from that regardless this window is not opened or not, another warning notification should be displayed at the bottom of the browser.

## Market Statistic

#FS10014a\_S0619\_00100

**Description**

#FS10014a\_S0619\_00200

The Market Statistic window shows the total turnover by market and by underlying, broken down by instrument group types.

This window is applicable to both external and internal. The layout is the same for both.

**Accessing the Function**

#FS10014a\_S0619\_00300

The Market Statistic window can be opened from the menu. ODP online allows at most 1 Market Statistic window to be opened.

**Scope of Data**

#FS10014a\_S0619\_00400

Both internal and external users access the same scope of the data.

This window shows the total turnover for each market and each underlying separately. The turnovers are shown as an aggregate from the start of the trading day and is categorize as calls, puts and forwards/futures, and other. Turnovers in normal trading and after hour trading sessions are aggregated and displayed separately.

**UI Layout**

#FS10014a\_S0619\_00500

![](data:image/png;base64...)

**Attributes**

#FS10014a\_S0619\_00600

Total turnover by market

| Category | Field | Type | Remarks |
| --- | --- | --- | --- |
| MARKET | MARKET | Alphanumeric | The market identity. |
| TRADED QTY | CALLS | Numeric | The number of traded call options. |
| PUTS | Numeric | The number of traded put options. |
| FRWDS/FUTS | Numeric | The number of traded futures/forwards. |
| OTHER | Numeric | The number of traded swaps, security lendings, etc. |
| AHT TRADE QTY | CALLS | Numeric | The number of traded call options in AHT session. |
| PUTS | Numeric | The number of traded put options in AHT session. |
| FRWDS/FUTS | Numeric | The number of traded futures/forwards in AHT session. |
| OTHER | Numeric | The number of traded swaps, security lendings, etc in AHT session. |

Total turnover by underlying

| Category | Field | Type | Remarks |
| --- | --- | --- | --- |
| UNDERLYING | SPOT | Alphanumeric | The underlying identity. |
| TRADED QTY | CALLS | Numeric | The number of traded call options. |
| PUTS | Numeric | The number of traded put options. |
| FRWDS/FUTS | Numeric | The number of traded futures/forwards. |
| OTHER | Numeric | The number of traded swaps, security lendings, etc. |
| AHT TRADED ATY | CALLS | Numeric | The number of traded call options in AHT session. |
| PUTS | Numeric | The number of traded put options in AHT session. |
| FRWDS/FUTS | Numeric | The number of traded futures/forwards in AHT session. |
| OTHER | Numeric | The number of traded swaps, security lendings, etc in AHT session. |

**Tooltips**

#FS10014a\_S0619\_00700

Total turnover by market

| Category | Column | Tooltips |
| --- | --- | --- |
| MARKET | MARKET | Specifies the market identity. |
| TRADED QTY | CALLS | Specifies the number of traded call options. |
| PUTS | Specifies the number of traded put options. |
| FRWDS/FUTS | Specifies the number of traded futures/forwards. |
| OTHER | Specifies the number of traded swaps, security lendings, etc. |
| AHT TRADE QTY | CALLS | Specifies the number of traded call options in AHT session. |
| PUTS | Specifies the number of traded put options in AHT session. |
| FRWDS/FUTS | Specifies the number of traded futures/forwards in AHT session. |
| OTHER | Specifies the number of traded swaps, security lendings, etc in AHT session. |

Total turnover by underlying

| Category | Column | Tooltips |
| --- | --- | --- |
| UNDERLYING | SPOT | Specifies the underlying identity. |
| TRADED QTY | CALLS | Specifies the number of traded call options. |
| PUTS | Specifies the number of traded put options. |
| FRWDS/FUTS | Specifies the number of traded futures/forwards. |
| OTHER | Specifies the number of traded swaps, security lendings, etc. |
| AHT TRADE QTY | CALLS | Specifies the number of traded call options in AHT session. |
|  | PUTS | Specifies the number of traded put options in AHT session. |
|  | FRWDS/FUTS | Specifies the number of traded futures/forwards in AHT session. |
|  | OTHER | Specifies the number of traded swaps, security lendings, etc in AHT session. |

**Data Refresh in Table**

#FS10014a\_S0619\_00800

This window will automatically update the market statistic.

**Default Sorting Order**

#FS10014a\_S0619\_00900

Sort by Market Name in first table

Sort by Underlying Name in second table

**Filtering Criteria**

#FS10014a\_S0619\_01000

The following filter fields are available for criteria search

Display right above the table

| Filtering Criteria | Type |
| --- | --- |
| ID | Instrument ID  Text Input (with Content Assist) |

**Read / Write Permission Behaviour**

#FS10014a\_S0619\_01100

| Permission | Behavior |
| --- | --- |
| Read | User can perform the following:   * View the market statistic of all instruments |
| Write | N/A |

**Action**

a. #FS10014a\_S0619\_01200 Export to CSV File by Market

The users can click More Action > "**Export to CSV File by Market**" to export those records from GUI market table.

b. #FS10014a\_S0619\_01300 Export to CSV File by Underlying

The users can click More Action >"**Export to CSV File by Underling**" to export those records from GUI underlying table.

**Validation**

#FS10014a\_S0619\_01400

N/A

**User Notification**

#FS10014a\_S0619\_01500

N/A

## Quotes

**#FS10014a\_S0620\_00100**

**Description**

**#FS10014a\_S0620\_00200**

This window is designed for market makers to send single quotes to the market, and display the result from single quotes only.

**Accessing the Function**

**#FS10014a\_S0620\_00300**

Quotes window can be opened from the menu. ODP Online allows only one Quotes window to be opened for internal and 5 for external.

**Scope of Data**

**#FS10014a\_S0620\_00400**

Display data market data for both internal and external of the same participant

For Internal trade Information is empty and non-editable

For External users, they can enter quote detail by cell editing then submit to market

**UI Layout**

**#FS10014a\_S0620\_00500**

![](data:image/png;base64...)

**Attributes**

**#FS10014a\_S0620\_00600**

| Column | Type | Remarks |
| --- | --- | --- |
| **INSTRUMENT** | | |
| ID | Alphanumeric | the instrument identity. |
| **\***UL ID | Alphanumeric | the underlying ID. |
| **\***UL | Alphanumeric | the underlying. |
| **\***MKT | Alphanumeric | the market. |
| **\***INST GROUP TYPE | Alphanumeric | the instrument group type. |
| **\***INST TYPE | Alphanumeric | the instrument type. |
| TSS | Alphanumeric | the trading session status. |
| ~~ISS~~ | ~~Alphanumeric~~ | ~~the instrument series status. The active state is shown in bold if its stronger than the TSS state.~~ |
| \*LAST DATE | Alphanumeric | Last Trading date of the instrument |
| \*STRIKE | Alphanumeric | Strike price of the instrument |
| **MARKET** | | |
| B QTY | Quantity | the best bid quantity. |
| BID | Price | the best bid price. |
| ASK | Price | the best ask price. |
| A QTY | Quantity | the best ask quantity. |
| **TRADE INFORMATION** | | |
| LAST | Price | the latest traded price. |
| L QTY | Quantity | the latest traded quantity. |
| HIGH | Price | the highest traded price during current trading day. |
| LOW | Price | the lowest traded price during current trading day. |
| OPEN | Price | the opening price. |
| TURN | Numeric | the total number of traded contracts during current trading day. |
| O INT | TBC | the open interest. |
| **OWN QUOTES** | | |
| **~~\*~~**~~IND B QTY~~ | ~~Quantity~~ | ~~the indicative bid quantity.~~ |
| **~~\*~~**~~IND BID~~ | ~~Price~~ | ~~the indicative bid price.~~ |
| B QTY | Quantity | the bid quantity. |
| BID | Price | the bid price. |
| ASK | Price | the ask price. |
| A QTY | Quantity | the ask quantity. |
| **~~\*~~**~~IND ASK~~ | ~~Price~~ | ~~the indicative ask price.~~ |
| **~~\*~~**~~IND A QTY~~ | ~~Quantity~~ | ~~the indicative ask quantity.~~ |
| **USED QUOTES** | | |
| **~~\*~~**~~IND B QTY~~ | ~~Quantity~~ | ~~the indicative bid quantity to be sent into the market.~~ |
| **~~\*~~**~~IND BID~~ | ~~Price~~ | ~~the indicative bid price to be sent into the market.~~ |
| B QTY | Quantity | the bid quantity to be sent into the market.  \* Cell Editable |
| BID | Price | the bid price to be sent into the market.  \* Cell Editable |
| ASK | Price | the ask price to be sent into the market.  \* Cell Editable |
| A QTY | Quantity | the ask quantity to be sent into the market.  \* Cell Editable |
| **~~\*~~**~~IND ASK~~ | ~~Price~~ | ~~the indicative ask price to be sent into the market.~~ |
| **~~\*~~**~~IND A QTY~~ | ~~Quantity~~ | ~~the indicative ask quantity to be sent into the market.~~ |
| ATID | Alphanumeric | the ATID.  \* Cell Editable |
| **STATUS** | | |
| STATUS | Alphanumeric | Displays a status message from the action on the row. |

**\*** fields are hidden by default and available for user to choose to be displayed in the quotes table.

**Status and Records Colouring in Table**

**#FS10014a\_S0620\_00700**

| Status | Description | Colour |
| --- | --- | --- |
| EXECUTED | Quote submission / cancellation succeed | Green |
| REJECTED | Quote submission / cancellation rejected | Red |
| IMPORTED | Quote imported from file successfully | Blue |
| IMPORT ERROR | Quote imported with error | Yellow |

**\*** Status and colours are removed once the user edited a row or closes the Quotes tab

| Column | Tooltips |
| --- | --- |
| ID | Specifies the instrument identity. |
| UL ID | Specifies the underlying ID. |
| UL | Specifies the underlying. |
| MKT | Specifies the market. |
| INST GROUP TYPE | Specifies the instrument group type. |
| INST TYPE | Specifies the instrument type. |
| TSS | Specifies the trading session status. |
| ~~ISS~~ | ~~Specifies the instrument series status. The active state is shown in bold if its stronger than the TSS state.~~ |
| B QTY | Specifies the best bid quantity. |
| BID | Specifies the best bid price. |
| ASK | Specifies the best ask price. |
| A QTY | Specifies the best ask quantity. |
| LAST | Specifies the latest traded price. |
| L QTY | Specifies the latest traded quantity. |
| HIGH | Specifies the highest traded price during current trading day. |
| LOW | Specifies the lowest traded price during current trading day. |
| OPEN | Specifies the opening price. |
| TURN | Specifies the total number of traded contracts during current trading day. |
| O INT | Specifies the open interest. |
| ~~IND B QTY~~ | ~~Specifies the indicative bid quantity.~~ |
| ~~IND BID~~ | ~~Specifies the indicative bid price.~~ |
| B QTY | Specifies the bid quantity. |
| BID | Specifies the bid price. |
| ASK | Specifies the ask price. |
| A QTY | Specifies the ask quantity. |
| ~~IND ASK~~ | ~~Specifies the indicative ask price.~~ |
| ~~IND A QTY~~ | ~~Specifies the indicative ask quantity.~~ |
| ~~IND B QTY~~ | ~~Specifies the indicative bid quantity to be sent into the market.~~ |
| ~~IND BID~~ | ~~Specifies the indicative bid price to be sent into the market.~~ |
| B QTY | Specifies the bid quantity to be sent into the market. |
| BID | Specifies the bid price to be sent into the market. |
| ASK | Specifies the ask price to be sent into the market. |
| A QTY | Specifies the ask quantity to be sent into the market. |
| ~~IND ASK~~ | ~~Specifies the indicative ask price to be sent into the market.~~ |
| ~~IND A QTY~~ | ~~Specifies the indicative ask quantity to be sent into the market.~~ |
| ATID | Specifies the ATID. |
| STATUS | Displays a status message from the action on the row. |

**Tooltips**

**#FS10014a\_S0620\_00800**

**Data refresh in table**

**#FS10014a\_S0620\_00900**

Real time update base on market data for Market, Trade Information, Instrument section

Real time update to show the quote quantity and price in own quotes section

**Default Sorting Order**

**#FS10014a\_S0620\_01000**

This window is sorted by ascending order of Underlying, Group/Type, Bid/Ask? by default

**Filtering Criteria**

**#FS10014a\_S0620\_01101**

Following filter fields are available for criteria search.

Display right above the table

| Filtering Criteria | Type |
| --- | --- |
| ID | Text Input (with Content Assist) |

[Revoked]

**Read / Write Permission Behaviour**

| Permission | Behavior |
| --- | --- |
| Read | * N/A. As this view is for sending quotes to the market only. * Export as CSV File |
| Write | User can perform the following:   * Perform Submit a quote action * Perform Cancel a quote action * Perform Submit all quotes action * Perform Cancel all quotes action * Perform Importing quotes action |

**Action**

**#FS10014a\_S0620\_01200**

1. **Submit selected quotes**

**#FS10014a\_S0620\_01300**

Submit selected quote.

1. **Cancel selected quotes**

**#FS10014a\_S0620\_01400**

Cancel selected quotes.

1. **~~Save filter as~~**

~~Open a view in which the user can save current search criteria.~~

1. **Submit all quotes**

**#FS10014a\_S0620\_01500**

Submit all quotes.

1. **Cancel all quotes**

**#FS10014a\_S0620\_01600**

Cancel all quotes.

1. **Import**

**#FS10014a\_S0620\_01700**

Import prepared quotes from a CSV file up to 300 records into GUI table.

Import format: Same headers from CSV export.

Required fields include:

* “INSTRUMENT: ID”
* “USED QUOTES: B QTY”
* “USED QUOTES: BID”
* “USED QUOTES: ASK”
* “USED QUOTES: A QTY”
* “USED QUOTES: ATID”

1. **Export to CSV File**

**#FS10014a\_S0620\_01800**

The users can click "**Export to CSV File**" to export those records from GUI table.

1. **Clear all**

**#FS10014a\_S0620\_01810**

Clear all user input in quote table.

**Validation**

**#FS10014a\_S0620\_01900**

1. **Submit quote**
2. A quote must be selected.
3. Validate SMP token if this is defined in CDB.
4. Refer to order confirmation
5. **Cancel quote**
6. A quote must be selected.
7. Refer to order confirmation
8. **~~Save filter as~~**
9. ~~NA~~
10. **Submit all quotes**
11. Validate SMP token if this is defined in CDB
12. Refer to order confirmation
13. **Cancel all quotes**
14. Refer to order confirmation
15. **Import**
16. Number of record cannot be more than 300
17. File format must be correct
18. Highlight record in yellow when error happen
19. Import file will trigger clear all before importing new records

**User Notification**

**#FS10014a\_S0620\_02000**

Individually show the quote status in table per submitted record.

When import more than 300 records to the screen, import will be rejected.

## Quote Reply (Obsolete)

**#FS10014a\_S0621\_00100**

**Description**

**#FS10014a\_S0621\_00200**

This function is applicable to External only.

The market maker is responsible for responding within a defined period of time. The Quote Reply window allows market makers to quickly respond to quote requests.

**#FS10014a\_S0621\_00300**

And it supports one by one reply.

This window supports only a single Quote Entry ID. The Quote Entry ID is always defaulted to 1 for all instruments. All Quote Responses submitted from this window in response to Quote Requests use Quote Entry ID = 1.

As a result, only one active Quote Response can be maintained per instrument from this window. For example, if there is an existing Quote Response for instrument ABC with quantity 2000, and the user responds to a new Quote Request for ABC with quantity 1000, the existing ABC (2000) Quote Response will be cancelled and replaced by the ABC (1000) Quote Response, which will then be displayed.

**Accessing the Function**

**#FS10014a\_S0621\_00400**

Quotes Reply window can be opened from the menu. ODP Online allows only one Quotes Reply window to be opened.

**Scope of Data**

**#FS10014a\_S0621\_00500**

The window is designed to assist market makers to respond to Quote Requests.

The table is empty each time a new Quote Reply window is opened. ~~Quote requests will also be erased when the user inputs a new filter in the instrument identity~~. Previous quote requests received during a login session can still be seen in the Market Message window.

Maximum number of quote requests that can be shown here is 300.

**UI Layout**

**#FS10014a\_S0621\_00600**

![](data:image/png;base64...)

**Attributes**

**#FS10014a\_S0621\_00700**

| Column | Type | Remarks |
| --- | --- | --- |
| TIME | Time | the time at which the quote request was sent. |
| INSTRUMENT | Alphanumeric | the instrument identity. |
| BID/ASK | Price | the bid and/or ask side of the quote request that was sent. |
| QTY | Quantity | the quantity of the quote request that was sent. |
| TIME |  | the time for the response quote. |
| BID QTY | Quantity | the bid quantity of the quote reply. |
| BID | Price | the bid price of the quote reply. |
| ASK | Price | the ask price of the quote reply. |
| ASK QTY | Quantity | the ask quantity of the quote reply. |

**Tooltips**

**#FS10014a\_S0621\_00800**

| Column | Tooltips |
| --- | --- |
| TIME | Specifies the time at which the quote request was sent. |
| INSTRUMENT | Specifies the instrument identity. |
| BID/ASK | Specifies if the bid and/or ask side of the quote request that was sent. |
| QTY | Specifies the quantity of the quote request that was sent. |
| TIME | Specifies the time for the response quote. |
| BID QTY | Specifies the bid quantity of the quote reply. |
| BID | Specifies the bid price of the quote reply. |
| ASK | Specifies the ask price of the quote reply. |
| ASK QTY | Specifies the ask quantity of the quote reply. |

**Data refresh in table**

**#FS10014a\_S0621\_00900**

The quotes by default will still be deleted in 30 seconds (Configurable by user response) which rely on GUI to trigger to perform the countdown. This is also true for when the Quote Reply window is close.

**Default Sorting Order**

**#FS10014a\_S0621\_01001**

Order by TIME in ASC

**Filtering Criteria**

**#FS10014a\_S0621\_01100**

Following filter fields are available for criteria search.

Display right above the table

| Filtering Criteria | Type |
| --- | --- |
| Instrument ID | Text Input (with Content Assist) |

**Read / Write Permission Behaviour**

**#FS10014a\_S0621\_01200**

**Action**

1. **Ignore**

**#FS10014a\_S0621\_01300**

Deleting a quote request, delete one or several rows from the table by clicking **Ignore** action.

Ignoring a quote does not trigger a cancellation. If a withdrawal timer is configured at submission, the system still submits the withdrawal request at the scheduled time.

1. **Respond…**

**#FS10014a\_S0621\_01400**

Open the Quote Response view (Dialog) by clicking **Respond** action.

**![](data:image/png;base64...)**

The withdrawal timer that triggers Quote Response cancellation is client-side and relies on the client browser session. If the client logs out or closes the Quote Reply screen before the scheduled cancel time, the timer will not fire and the system will not send the cancellation request, the Quote Response remains in the market.

**Dialog Attributes**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Instrument | Alphanumeric  **Text Input**  **(With Content Assist)** | 32 | - | - | Read-only field. The Contract Series ID. |
| Bid qty | Quantity  **Text Input**  **(With up / down per tick size)** | [Ref to Data Type](#_Data_Type) | O | - | The Bid Quantity.  **To cancel the bid side, set Bid Qty to 0**  **To un-change the bid side, set Bid Qty to empty** |
| Bid | Price  **Spinner Input (With up / down per tick unit)** | [Ref to Data Type](#_Data_Type) | O | - | The Bid Price. |
| Ask qty | Quantity  **Text Input**  **(With up / down per tick size)** | [Ref to Data Type](#_Data_Type) | O | - | The Ask Quantity.  **To cancel the ask side, set Ask Qty to 0.**  **To un-change the ask side, set Ask Qty to empty.** |
| Ask | Price  **Spinner Input (With up / down per tick unit)** | [Ref to Data Type](#_Data_Type) | O | - | The Ask Price. |
| MMP radio button | Boolean  **Radio Button** | 1 | O | - | Indicate whether MMP is enabled for the Bid side, the Ask side, or both.  ***The Give up and Give up acc field are disabled by default. They will be enabled only if give up radio button is Yes.*** |
| SMP ID | Alphanumeric  **Text Input**  **(with Content Assist)** | 21 | O | - | The SMP ID is to prevent from being matched to an opposite order if both buy and sell orders for the trade contain the same SMP ID. |
| ATID | Alphanumeric | 5 | O | - | The ATID. |
| Rest of day | Boolean  **Checkbox** | 1 | O | False | This indicator specifies whether the quote remains active until the end of the trading day. |
| Withdraw after (sec) | Numeric | TBC | M | 30 | The withdraw second specifies whether the quote will be deleted after the configured time.  **Required when Rest of Day is set to false.  Min value: 30, Max value: 360** |
| BCAN | Alphanumeric | 17 | M | - | The Broker-Client Assigned Number. |
| Current bid qty | - | - | - | - | Read-only field. The best bid quantity. |
| Current bid | - | - | - | - | Read-only field. The best bid price. |
| Current ask | - | - | - | - | Read-only field. The best ask price. |
| Current ask qty | - | - | - | - | Read-only field. The best ask quantity. |

**Dialog Tooltips**

| Column | Tooltips |
| --- | --- |
| Instrument | Specifies the instrument identity. |
| Bid qty | Specifies the bid quantity for the response quote. |
| Bid | Specifies the bid price for the response quote. |
| Ask qty | Specifies the ask quantity for the response quote. |
| Ask | Specifies the ask price for the response quote. |
| SMP Token | Specifies the SMP Token. |
| ATID | Specifies the ATID. |
| Rest of day | If ticked, the quote will not be deleted until the end of the trading day. |
| Withdraw after (sec) | Specifies if the quote shall be deleted after the specified time. |

**Dialog Action**

* 1. **Submit**

Submit quote reply.

* 1. **Clear All**

Reset the values to default value.

1. **Export to CSV File**

**#FS10014a\_S0621\_01500**

The users can click "**Export to CSV File**" to export those records from GUI table.

**Validation**

**#FS10014a\_S0621\_01600**

1. **Ignore**
2. One or more Quotes request must be selected.
3. **Respond**
4. A Quote request must be selected.
5. SMP Token validation

**User Notification**

**#FS10014a\_S0621\_01700**

Error – when response is rejected

## Trade View

**Description**

**#FS10014a\_S0622\_00100**

This function is applicable to both External and Internal, which client can view the latest trades and their status in this screen

1. External

**#FS10014a\_S0622\_00200**

This window allows users to manage/view their own trades, such as error trade under the same participant in real time.

1. Internal

**#FS10014a\_S0622\_00300**

This window shows trades of all participants that are currently exposing to the market and they can perform error, cancel and amend trades on behalf of clients if required and these request requires second user approval.

**Accessing the Function**

**#FS10014a\_S0622\_00400**

Trade View window can be opened from the Menu. ODP Online allows only one Trade View window to be opened.

**Scope of Data**

**#FS10014a\_S0622\_00500**

Users can view trades of the current trading day only and up to 60k trade history to display at a time of the current participant. It is not allowed to report Error/Cancel/Adjust Trade of preceding trading day.

For Internal:

**#FS10014a\_S0622\_00600**

If the participant field is left blank, latest trades in the market will be loaded from ALL participants up to 60k trades.

If a specific participant (e.g. KGI) is filled in the participant filter, it will display trades made under the specific participant but displays up to 60k trade history only (e.g. KGI).

**#FS10014a\_S0622\_00700**

Only one Trade View screen can be opened at a time.

For External:

**#FS10014a\_S0622\_00800**

Only one Trade View screen can be opened at a time

**UI Layout (External)**

**#FS10014a\_S0622\_00901**

![](data:image/png;base64...)

**UI Layout (Internal)**

**#FS10014a\_S0622\_01001**

![](data:image/png;base64...)

**Attributes**

**#FS10014a\_S0622\_01100**

| Column | Type | Remarks |
| --- | --- | --- |
| ACTION | Alphanumeric | The action of the trade. |
| PART | Alphanumeric | The participant. |
| ID | Alphanumeric | The Instrument Series ID. |
| TRADE ID | Alphanumeric | The trade identification number. |
| ~~G DEAL NO~~ | ~~TBC~~ | ~~The global deal number.~~ |
| ~~DEAL NO~~ | ~~TBC~~ | ~~The deal number.~~ |
| ~~NO~~ | ~~TBC~~ | ~~The number.~~ |
| ~~ORG NO~~ | ~~TBC~~ | ~~The original trade number.~~ |
| ~~STATE~~ | ~~Alphanumeric~~ | ~~The trade status.~~ |
| ~~TYPE~~ | ~~Alphanumeric~~ | ~~The order type.~~ |
| BOUGHT | Quantity | The bought quantity. |
| SOLD | Quantity | The sold quantity. |
| R QTY | Quantity | The remaining quantity. |
| T PRC | Price | The price. |
| CUST | Alphanumeric | The account type.  (C, H, Rxxxx, A1, P1 or M1). |
| GUP | Alphanumeric | The company identity of the Give Up client. |
| G ACC | Alphanumeric | The give up acc. |
| INFO | Alphanumeric | The customer information. |
| ~~LEI~~ | ~~Alphanumeric~~ | ~~The legal entity identifier.~~ |
| ~~P~~ | ~~TBC~~ | ~~The position.~~ |
| RP | Alphanumeric | The requested position. |
| TR TYPE | Alphanumeric | The trade report type |
| ~~ATT~~ | ~~TBC~~ | ~~The attention.~~ |
| ~~CLEARING~~ | ~~TBC~~ | ~~The clearing date.~~ |
| TIME | Date Time | The time of creation. |
| **~~\*~~**~~ASOF~~ | ~~TBC~~ | ~~The as of time.~~ |
| **~~\*~~**~~MODIFIED~~ | ~~Date Time~~ | ~~The time of last modification.~~ |
| TRD | Alphanumeric | The trader Id. |
| ORDER NO | Alphanumeric | The order number. |
| DEAL SRC | Alphanumeric | The deal source.  Refer to Trade History attributes - deal flag section for more details. |
| ~~WHOSE~~ | ~~TBC~~ | ~~The trade owner.~~ |
| C PART | Alphanumeric | The counterpart. |
| ~~UL~~ | ~~Alphanumeric~~ | ~~The underlying name.~~ |
| ~~MKT~~ | ~~Alphanumeric~~ | ~~The market.~~ |
| ~~SMP~~ | ~~Alphanumeric~~ | ~~SMP token~~ |
| ATID | Alphanumeric | The ATID. |

**Tooltips**

**#FS10014a\_S0622\_01200**

| Column | Tooltips |
| --- | --- |
| ACTION | Specifies the action of the trade. |
| PART | Specifies the participant at which the trade has been done. |
| ID | Specifies the identity of the instrument. |
| TRADE ID | Trade identification number. |
| ~~G DEAL NO~~ | ~~Global deal number.~~ |
| ~~DEAL NO~~ | ~~Deal number.~~ |
| ~~NO~~ | ~~Trade number.~~ |
| ~~ORG NO~~ | ~~Original trade number.~~ |
| ~~STATE~~ | ~~Trade state.~~ |
| ~~TYPE~~ | ~~Trade type.~~ |
| BOUGHT | Bought quantity. |
| SOLD | Sold quantity. |
| R QTY | Remaining quantity. |
| T PRC | Traded price. |
| CUST | Customer. |
| GUP | Give up. |
| G ACC | Give-up account info. |
| INFO | Customer information. |
| ~~LEI~~ | ~~Legal entity identifier.~~ |
| ~~P~~ | ~~Position.~~ |
| RP | Request position. |
| TR TYPE | Trade-Report Type. |
| ~~ATT~~ | ~~Attention.~~ |
| ~~CLEARING~~ | ~~Clearing date.~~ |
| TIME | Time of creation. |
| ~~ASOF~~ | ~~As of time.~~ |
| ~~MODIFIED~~ | ~~Time of last modification.~~ |
| TRD | Trader. |
| ORDER NO | Order number. |
| DEAL SRC | Deal source. |
| ~~WHOSE~~ | ~~Whose.~~ |
| C PART | Counterparty. |
| ~~UL~~ | ~~Specifies the underlying.~~ |
| ~~MKT~~ | ~~Specifies the market.~~ |
| ATID | Active Trader ID. |

**Data refresh in table**

For external user:

**#FS10014a\_S0622\_01300**

This view will automatically update upon any changes of the trade view. When there is filter, shall the new record meet with the filter criteria, it should be updated as well.

Subsequent trades after searching will be appended at the end of the window.

For internal user:

**#FS10014a\_S0622\_01400**

This view will automatically updates when any changes occur for ALL participants in the trade view and displays up to 60k records only. Subsequent trades after searching will be appended at the end of the window.

**Default Sorting Order**

**#FS10014a\_S0622\_01500**

The trades are sorted by TIME in ASC by default.

**Filtering Criteria**

**#FS10014a\_S0622\_01601**

Following filter fields are available for criteria search.

Display right above the table

| Filtering Criteria | Type |
| --- | --- |
| ID | Text Input (with Content Assist) |
| PART | Text Input (with Content Assist)  Available for Internal Only |
| SIDE | Drop Down  Available for External Only |
| MKT | Text Input (with Content Assist) |
| UL | Text Input (with Content Assist) |

[Revoked]

**Read / Write Permission Behaviour**

**#FS10014a\_S0622\_01700**

| Permission | Behavior |
| --- | --- |
| Read | User can perform the following:   * View all the data in the Trade View Table * Perform Sorting/Filtering on the Trade View Table * Export Trade View Table as CSV File |
| Write | N/A |

**Action**

1. **Export to CSV File**

**#FS10014a\_S0622\_01800**

The users can click "**Export to CSV File**" to export those records from GUI table.

1. **~~Export all to CSV File~~**

**~~#FS10014a\_S0622\_01801~~**

~~The users can click "~~**~~Export all to CSV File~~**~~" to export those records from GUI table.~~

1. **Submit an Error Trade Claim (Internal/External)**

**#FS10014a\_S0622\_01900**

Selecting a trade in the Trade View Table and click the **Error Trade Claim** option to file an error trade claim.

1. **Request a Trade Cancellation (Internal)**

**#FS10014a\_S0622\_02000**

Selecting a trade in Trade View Table and click the **Trade Cancellation Request** option to open a Trade Cancellation Request.

1. **Request a Trade Adjustment (Internal)**

**#FS10014a\_S0622\_02100**

Selecting a trade in Trade View Table and click the **Trade Adjustment Request** option to open a Trade AdjustmentRequest.

**Validation**

**#FS10014a\_S0622\_02200**

1. **Submit an Error Trade Claim**
   1. Multiple trades can be selected
   2. If ANY of the selected trade is part of a Block Trade, do not allow submitting an Error Trade Claim. (TBC)
   3. ~~Users under the same participant should allow to submit error trade~~
2. **Request a Trade Cancellation**
   1. Only one trade can be selected
   2. ~~Users under the same participant should allow to submit cancel~~
3. **Request a Trade Adjustment**
   1. Only one trade can be adjusted at a time by providing adjusted price

**User Notification**

**#FS10014a\_S0622\_02300**

System success/reject/fail notification for Error Trade Claim, Trade Cancellation and Trade Adjustment.

## Trade Cancellation Request Dialog

**Description**

**#FS10014a\_S0623\_00100**

Trade Cancellation can only be initiated by DT Operations. DT Operations can select an exchange matched trade from the trade window to initiate the trade cancellation. DT Operations only needs to select one side (either the buy side or the sell side) of the trade to initiate the trade cancellation.

**Accessing the Function**

**#FS10014a\_S0623\_00200**

Trade Cancellation Request Dialog can be opened when user select a Trade and click “Request a Trade Cancellation” in Trade View. ODP Online allows only one Trade Cancellation Request Dialog to be opened.

**Scope of Data**

**#FS10014a\_S0623\_00300**

The trade will only be cancelled when Cancel and Adjust Trade function is allowed in the current trading state of the corresponding contract (Refer to FS – Trading Timetable Section 6.2.2). Otherwise, the trade cancellation request will be rejected.

**UI Layout**

**#FS10014a\_S0623\_00400**

**![](data:image/png;base64...)**

**Attributes**

**#FS10014a\_S0623\_00501**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Trade ID | Alphanumeric  **Text Input**  **(With Content Assist)** | 32 | M | - | The trade ID.  Read-only |
| Instrument | Alphanumeric  **Text Input**  **(With Content Assist)** | 32 | M | - | The instrument.  Read-only |
| Traded Price | Price  **Text Input (With up / down per tick unit)** | [Ref to Data Type](#_Data_Type) | M | - | The traded price.  Read-only |
| Traded Quantity | Quantity  **Text Input**  **(With up / down per tick size)** | [Ref to Data Type](#_Data_Type) | M | - | The traded quantity.  Read-only |
| Trade Time | Date and Time | 8 | M | - | The trade time.  Read-only |
| Cancel Reason | Alphanumeric  **Text Input**  **(Drop down)** | - | M | - | The cancel reason.  Valid values:  1. Error Trade  2. Invalid Block Trade  3. Others  This field is editable |
| ~~Buy Side EP~~ | ~~Alphanumeric~~  **~~Text Input~~**  **~~(With Content Assist)~~** | ~~5~~ | ~~M~~ | ~~-~~ | ~~The Buy Side EP.~~  ~~Read-only~~ |
| ~~Sell Side EP~~ | ~~Alphanumeric~~  **~~Text Input~~**  **~~(With Content Assist)~~** | ~~5~~ | ~~M~~ | ~~-~~ | ~~The Sell Side EP.~~  ~~Read-only~~ |

**Tooltips**

**#FS10014a\_S0623\_00600**

| Column | Tooltips |
| --- | --- |
| Trade ID | Specifies the trade ID. |
| Instrument | Specifies the instrument. |
| Traded Price | Specifies the traded price. |
| Traded Quantity | Specifies the traded quantity. |
| Trade Time | Specifies the trade time. |
| Cancel Reason | Specifies the cancel reason. |
| ~~Buy Side EP~~ | ~~Specifies the buy side EP.~~ |
| ~~Sell Side EP~~ | ~~Specifies the sell side EP.~~ |

**Data refresh in table**

**#FS10014a\_S0623\_00700**

N/A

**Default Sorting Order**

**#FS10014a\_S0623\_00800**

N/A

**Filtering Criteria**

**#FS10014a\_S0623\_00900**

N/A

**Read / Write Permission Behaviour**

**#FS10014a\_S0623\_01000**

| Permission | Behavior |
| --- | --- |
| Read | N/A. As this dialog is for inputting new trade cancellation only. |
| Write | User with write permission can fill in and submit a new request. |

**Action**

**#FS10014a\_S0623\_01100**

1. **Submit**

Users can press **Submit** buttonto submit the Trade Cancellation Request.

Confirmation box will be prompted with the following text when user click on the **Submit** button.

*Confirm submit of Trade Cancellation Request.*

The Submit Trade Cancellation Request will be submitted for approval when user clicks OK on the confirmation box.

1. **Cancel**

Users can press **Cancel** button to close the Trade Cancellation Request window.

**Validation**

**#FS10014a\_S0623\_01200**

1. **Submit**
2. ME to perform the checking if the cancel trade is allowed in the current trading state of the corresponding contract.
3. **Cancel**

N/A

**User Notification**

**#FS10014a\_S0623\_01300**

TBC: A message will be sent to the claimant EP and the contra-side EP through the trading session of the claimed trade to notify of the trade cancellation. Should it be in UI or binary message?

## Trade Adjustment Request Dialog

**Description**

**#FS10014a\_S0624\_00100**

When an explicit order trades with another explicit order in the strategy book (a.k.a. combo vs combo trade), the trading system calculates the trade prices for each legs according to the Leg Price Calculation Algorithm specified in FS – Orderbook and Execution Management Section 6.3. Under some scenarios, the calculated price may not be in line with the market and therefore, EPs may submit request to DT Operations for Trade Adjustment.

**#FS10014a\_S0624\_00200**

Trade Adjustment can only be initiated by DT Operations. DT Operations can select a trade on a strategy book (which includes both standard strategy and Tailor-Made strategy) in the trade window to initiate the trade adjustment. DT Operations only requires selecting one side of the strategy trade (either the buy side or the sell side) on the strategy book.

**Accessing the Function**

**#FS10014a\_S0624\_00300**

Trade Adjustment Request Dialog can be opened when internal user selects a Strategy Explicit-vs-Explicit Trade and click “Request a Trade Adjustment” in Trade View window. ODP Online allows only one Trade Adjustment Request Dialog to be opened.

**Scope of Data**

**#FS10014a\_S0624\_00400**

The selected strategy trade is an explicit order vs explicit order trade. Trade Adjustment is not allowed if the validation is failed

**UI Layout**

**#FS10014a\_S0624\_00500**

**![](data:image/png;base64...)**

**Attributes**

**#FS10014a\_S0624\_00601**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| **Trade Details** | | | | | |
| Trade ID | Alphanumeric  **Text Input**  **(With Content Assist)** | 32 | M | - | The trade ID.  Read-only |
| Instrument | Alphanumeric  **Text Input**  **(With Content Assist)** | 32 | M | - | The instrument.  Read-only |
| Traded Price | Price  **Text Input (With up / down per tick unit)** | [Ref to Data Type](#_Data_Type) | M | - | The traded price.  Read-only |
| Traded Quantity | Quantity  **Text Input**  **(With up / down per tick size)** | [Ref to Data Type](#_Data_Type) | M | - | The traded quantity.  Read-only |
| Trade Time | Date and Time | 8 | M | - | The trade time.  Read-only |
| ~~Buy Side EP~~ | ~~Alphanumeric~~  **~~Text Input~~**  **~~(With Content Assist)~~** | ~~5~~ | ~~M~~ | ~~-~~ | ~~The Buy Side EP.~~  ~~Read-only~~ |
| ~~Sell Side EP~~ | ~~Alphanumeric~~  **~~Text Input~~**  **~~(With Content Assist)~~** | ~~5~~ | ~~M~~ | ~~-~~ | ~~The Sell Side EP.~~  ~~Read-only~~ |
| **Leg Prices** | | | | | |
| Price | Price  **Text Input (With up / down per tick unit)** | [Ref to Data Type](#_Data_Type) | M | - | The leg price.  Editable |

**Tooltips**

**#FS10014a\_S0624\_00700**

| Column | Tooltips |
| --- | --- |
| Trade ID | Specifies the trade ID. |
| Instrument | Specifies the instrument. |
| Traded Price | Specifies the traded price. |
| Traded Quantity | Specifies the traded quantity. |
| Trade Time | Specifies the trade time. |
| ~~Buy Side EP~~ | ~~Specifies the buy side EP.~~ |
| ~~Sell Side EP~~ | ~~Specifies the sell side EP.~~ |
| Price | Specifies the leg price. |

**Data refresh in table**

**#FS10014a\_S0624\_00800**

N/A

**Default Sorting Order**

**#FS10014a\_S0624\_00900**

N/A

**Filtering Criteria**

**#FS10014a\_S0624\_01000**

N/A

**Read / Write Permission Behaviour**

**#FS10014a\_S0624\_01100**

| Permission | Behavior |
| --- | --- |
| Read | N/A. As this dialog is for inputting new trade adjustment only. |
| Write | User with write permission can fill in and submit a new request. |

**Action**

**#FS10014a\_S0624\_01200**

1. **Submit**

Users can press **Submit** buttonto submit the Trade Adjustment Request.

Confirmation box will be prompted with the following text when user click on the **Submit** button.

*Confirm submit of Trade Adjustment Request.*

The Submit Trade Adjustment Request will be submitted for approval when user clicks OK on the confirmation box.

1. **Cancel**

Users can press **Cancel** button to close the Trade Adjustment Request window.

**Validation**

**#FS10014a\_S0624\_01300**

1. **Submit**
2. ME to check if Trade Adjustment is allowed in the current trading state of the corresponding contract.
3. The input price of each strategy leg is aligned to the price tick defined in the system.
4. The Net Price is equal to the original strategy trade price.
5. For intended prices of each leg. There is quick validation following the following formula:

![](data:image/png;base64...)

1. **Cancel**

N/A

**User Notification**

**#FS10014a\_S0624\_01400**

A message will be sent to the EPs of both side of the trade through the trading session to notify of the trade adjustment.

## Error Trade Request View

**Description**

**#FS10014a\_S0625\_00100**

This function is applicable to Internal and External users.

**#FS10014a\_S0625\_00200**

Internal Users:

This window is designed for DT Operation users to manage Error Trade Requests and their statuses. Users can view request details, select multiple trades, and perform actions such as acceptance, approval, rejection, and marking requests as processed by LET. All actions require countersign approval.

External Users:

This window is designed for claimant EPs and contra-side EPs to review the Error Trade Requests related to them and their corresponding statuses. After an Error Trade Request is accepted by DT Operation, the Contra-Side EP can Accept or Decline the request.

**Accessing the Function**

**#FS10014a\_S0625\_00300**

Error Trade Request window can be opened from the Menu. ODP Online allows only one Error Trade Request window to be opened.

**UI Layout**

**#FS10014a\_S0625\_00400**

External UI

![](data:image/png;base64...)

Internal UI

![](data:image/png;base64...)

**Attributes**

**#FS10014a\_S0625\_00501**

| Column | Type | Remarks |
| --- | --- | --- |
| Claim Time | Date and Time | The submission time of the Error Trade Request.  In DD-MM-YYYY HH:MM:SS format. |
| Direction | Alphanumeric | **External only**  Represents the Direction of the EP in the Error Trade Request. Values include:  **Claimant**  **Contra-Side** |
| Claimant Comp ID | Alphanumeric | **Internal only**  The Comp Id of EP who submits the Error Trade Request. |
| Claimant Trader ID | Alphanumeric | **Internal only**  The Trader Id of EP who submits the Error Trade Request. |
| Contra-side Comp ID | Alphanumeric | **Internal only**  The Comp Id of EP who is the contra-side of the Error Trade Request. |
| Contra-side Trader ID | Alphanumeric | **Internal only**  The Trader Id of EP who is the contra-side of the Error Trade Request. |
| Claim ID | Alphanumeric | **Internal only**  Unique ID of the Error Trade Request. |
| Trade ID | Alphanumeric | Unique ID of the Trade. |
| Traded Price | Price | The Price of the Trade. |
| Traded Quantity | Quantity | The Quantity of the Trade. |
| Security ID | Alphanumeric | The Security involved in the Trade. |
| Status | Alphanumeric | Status of the Error Trade Request:  Domain Values:  **New** – System Verification in Progress  **Accepted –** DT accepted the Error Trade claim request, pending decision by contra-side EP and/or review committee  **Rejected –** DT decided not to proceed with the Error Trade Claim  **Processed as LET –** DT decided to proceed the claim as LET  **Processed –** Error Trade Claim approved and submitted to clearing |
| Consent Reply | Alphanumeric | Reply from the Contra-side of the Error Trade Request. Values include:  **Counterparty Consented (Internal)**  **Counterparty Declined (Internal)**  **Accepted (External)**  **Declined (External)** |

**Tooltips**

**#FS10014a\_S0625\_00600**

| Column | Tooltips |
| --- | --- |
| Claim Time | Specifies the submission time of the Error Trade Request. |
| Direction | Specifies the direction of the Error Trade Request. |
| Side | Specifies the side of the Error Trade Request. |
| Claimant Comp ID | Specifies the Comp ID of EP who submits the Error Trade Request. |
| Claimant Trader ID | Specifies the Trader ID of EP who submits the Error Trade Request. |
| Contra-side Comp ID | Specifies the Comp ID of EP who is the contra-side of the Error Trade Request. |
| Contra-side Trader ID | Specifies the Trader ID of EP who is the contra-side of the Error Trade Request. |
| Claim ID | Specifies the unique ID of the Error Trade Request |
| Trade ID | Specifies the unique ID of the Trade. |
| Traded Price | Specifies the price of the Trade. |
| Traded Quantity | Specifies the quantity of the Trade. |
| Security ID | Specifies the security involved in the Trade. |
| Status | Specifies the status of the Error Trade Request. |
| Consent Reply | Specifies the Contra-Side’s reply of the Error Trade Request. |

**Data refresh in table**

**#FS10014a\_S0625\_00700**

The window is dynamically updated when EP submit a new Error Trade Request or there is a change in the status of the Error Trade Request.

**Default Sorting Order**

**#FS10014a\_S0625\_00800**

The Error Trade Request window is sorted by ascending order of claim time by default.

**Filtering Criteria**

**#FS10014a\_S0625\_00900**

| Filtering Criteria | Type |
| --- | --- |
| Claim ID | Text Input (with Content Assist) |

**Read / Write Permission Behaviour**

**#FS10014a\_S0625\_01000**

| Permission | Behavior |
| --- | --- |
| Read | User can perform the following:   * View all the data in the Error Trade Request table * Perform Sorting/Filtering on the Error Trade Request table * Export Error Trade Report table as CSV File |
| Write | User can perform the following:  Internal User:   * View all the data in the Error Trade Request Table * Perform Sorting/Filtering on the Error Trade Request table * Mark claims to be processed LET * Export trade files for LET processing * Accept / Approve / Reject an accepted Error Trade Request   External User:   * View all the data in the Error Trade Request Table related to the EP * Perform Sorting/Filtering on the Error Trade Request table * Export Error Trade Request table as CSV File * Accept / Decline a verified Error Trade Report |

**Action**

**#FS10014a\_S0625\_01100**

1. **Accept Error Trade Request(s)**

Internal User

DT Operation can select one or more Error Trade Requests from the Error Trade Request table and click the **Accept Error Trade Request(s)** option from the **More Actions** menu to accept the selected Error Trade Requests.

Confirmation box will be prompted with the following text when user click on the **Accept Error Trade Request(s)** option.

*Confirm accept of selected Error Trade Request(s).*

The Current Status of the Error Trade Requests would become **Accepted**, and the Error Trade Requests would be sent to Contra-Side EP for review.

External User

Contra-side EPs may select one or more Accepted Error Trade Requests from the Error Trade Request table and accept them via the **Accept Error Trade Request(s)** option in the **More Actions** menu.

Confirmation box will be prompted with the following text when user click on the **Accept Error Trade Request(s)** option.

*Confirm accept of selected Error Trade Request(s).*

The Contra-Side EP Response field will be updated to Accepted. Note that Contra-Side EP acceptance would not affect the Current Status field of the requests.

1. **Decline Error Trade Request(s)**

This action is for External User only. The Contra-Side EP may select one or more Accepted Error Trade Requests from the Error Trade Request table and accept them via the **Decline Error Trade Request(s)** option in the **More Actions** menu.

Confirmation box will be prompted with the following text when user click on the **Decline Error Trade Request(s)** option.

*Confirm decline of selected Error Trade Request(s).*

The Contra-Side EP Response field will be updated to Decline. **Note that Contra-Side EP acceptance would not affect the Current Status field of the requests**. The final decision maker of the request is DT Operation and review committee.

1. **Approve Error Trade Request(s)**

This action is for Internal User only. Users can select one or more Error Trade Requests from the Error Trade Request table and click the **Approve Error Trade Request(s)** option from the **More Actions** menu to approve the selected Error Trade Requests.

Confirmation box will be prompted with the following text when user click on the **Approve Error Trade Request(s)** option.

*Confirm approve of selected Error Trade Request(s).*

The Approve Error Trade Requests will be submitted when user clicks OK on the confirmation box. The status would become **Processed**.

1. **Reject Error Trade Request(s)**

This action is for Internal User only. Users can select one or more Error Trade Requests from the Error Trade Request table and click the **Reject Error Trade Request(s)** option from the **More Actions** menu to reject the selected Error Trade Requests.

Confirmation box will be prompted with the following text when user click on the **Reject Error Trade Request(s)** option.

*Confirm reject of selected Error Trade Request(s).*

The Reject Error Trade Requests will be submitted when user clicks OK on the confirmation box. The status would become **Rejected.**

1. **Proceed as LET** TBC

This action is for Internal Users only. Users can select multiple Error Trade Requests and click the “**Proceed as LET**” option from the **More Actions** menu to upload Trade File.

Confirmation box will be prompted with the following text when user click on the **Process as LET** option.

*Confirm process of selected Error Trade Request(s) as LET.*

Next, the user could download a Trade File for LET initiation in system. The status of the requests would become **Processed as LET**.

1. **Export to CSV file**

The users can click "**Export to CSV File**" to export those records from GUI table.

1. **Double click an Error Trade Request**

Users can double click an Error Trade Request entry in table to bring up the Error Trade Request Detail window for that Request.

**Validation**

**#FS10014a\_S0625\_01200**

1. **Accept Error Trade Request(s)**

Internal User

Error Trade Requests can be accepted only when:

1. Status of the Error Trade Request is **New**.
2. The validation result of Time Validation is **Pass**.

External User

Error Trade Requests can be accepted only when:

1. Status of the Error Trade Request is **Accepted**.
2. **Decline Error Trade Request(s)**

The Error Trade Requests can be declined only when:

1. Status of the Error Trade Request is **Accepted**.
2. **Decline Error Trade Request(s)**

The Error Trade Requests can be declined only when:

1. Status of the Error Trade Request is **Accepted**.
2. **Approve Error Trade Request(s)**

Error Trade Requests can be approved only when:

1. Status of the Error Trade Request is **Accepted**.
2. **Reject Error Trade Request(s)**

Error Trade Requests can be rejected only when:

1. Status of the Error Trade Request is **New** **/ Accepted**.
2. **Processed as LET** TBC

The Error Trade Requests can be processed as LET only when:

1. Status of the Error Trade Request is **Accepted**.

**User Notifications**

**#FS10014a\_S0625\_01301**

1. **New**
2. **Accept**

When a claim is accepted, a message will be sent to both the Claimant EP and the Contra-side EP via the trading session that initiated the traded orders.

Here is the message template:

Error Trade Alert

Pursuant to HKFE Rule 819B, please be advised that the following trade is claimed to be error trade and may be subjected to correction:

Contract = {Contract Name}

Price = {Traded Price}

Traded Time = {Traded Time}

Any objection from Participants of its correction must be brought to the attention of the Exchange, with explanatory reasons, by calling +852 2211-6360 within 10 minutes of this notification.

1. **Approve**

When a claim is approved by participant or by committee, a message will be sent to both the Claimant EP and the Contra-side EP via the trading session that initiated the traded orders.

Here is the message template:

Claimed Trade Cancelled (By Participant)

Error Trade (By participant)

Pursuant to HKFE Rule 819B, please be advised that the following trade is declared as erroneous.

Contract = {Contract Name}

Price = {Traded Price}

Quantity = {Traded Qty}

Trade ID = {Trade ID}

Traded Time = {Traded Time}

Claimed Trade Cancelled (By committee)

Error Trade (By committee)

Pursuant to HKFE Rule 819B, please be advised that the following trade is cis declared as erroneous as reviewed by the HKATS Error Trade Review Panel:

Contract = {Contract Name}

Price = {Traded Price}

Quantity = {Traded Qty}

Trade ID = {Trade ID}

Traded Time = {Traded Time}

1. **Reject**

When a claim is rejected after an accept, a message will be sent to both the Claimant EP and the Contra-side EP via the trading session that initiated the traded orders.

Error Trade

Pursuant to HKFE Rule 819B, please be advised that the following trade is claimed to be error trade but not deemed as erroneous:

Contract = {Contract Name}

Price = {Traded Price}

Traded Time = {Traded Time}

1. **Decline**
2. **Process as LET**

## Error Trade Request Details

**Description**

**#FS10014a\_S0626\_00100**

This function is applicable to Internal both External Users.

**#FS10014a\_S0626\_00200**

When user double-clicks an item in the Error Trade Request Window, details of the trade claim are available for review.

**Accessing the Function**

**#FS10014a\_S0626\_00300**

Error Trade Request Details window can be opened when user double clicks a Request from Error Trade Request Window. ODP Online allows only one Error Trade Report Details window to be opened.

**UI Layout**

**#FS10014a\_S0626\_00400**

Internal User

**![](data:image/png;base64...)**

\*Accept button is enabled only if the Current Status is New

\*Approve button is enabled only if the Current Status is Accepted

\*Reject button is enabled only if the Current Status is New or Accepted

External User

![](data:image/png;base64...)

\*Accept and Decline buttons are enabled only if the user is the counterparty of the Error Trade Request and Current Status is Accepted

**Attributes**

**#FS10014a\_S0626\_00500**

| Column | Type | Length | Remarks |
| --- | --- | --- | --- |
| Trade ID | Alphanumeric | TBC | Unique ID of the Trade. |
| Instrument | Alphanumeric | TBC | The instrument involved in the Trade. |
| Traded Price | Price | [Ref to Data Type](#_Data_Type) | The Price of the Trade. |
| Traded Quantity | Quantity | [Ref to Data Type](#_Data_Type) | The Quantity of the Trade. |
| Trade Time | Date and Time | 16 | The time of the Trade. |
| Claim Time | Date and Time | 16 | The submission time of the Error Trade Request.  In DD-MM-YYYY HH:MM:SS format. |
| Claimant Comp ID | Alphanumeric | TBC | The Comp ID who submits the Error Trade Request. |
| Claimant Trader ID | Alphanumeric | TBC | The Trader ID who submits the Error Trade Request. |
| Contra-side Comp ID | Alphanumeric | TBC | Comp ID on which the order executed in the subject trade of the Error Trade Claim was submitted. |
| Contra-side Trader ID | Alphanumeric | TBC | Trader ID on which the order executed in the subject trade of the Error Trade Claim was submitted. |
| Time Validation | Alphanumeric | 16 | Internal user only  Validation result on the time of the claim. |
| Last Traded Price | Price | [Ref to Data Type](#_Data_Type) | Internal user only  Last Traded Price at the claimed Error Trade. The system needs to retrieve the information for reference. Shown immediately when available. |
| Reference Price | Price | [Ref to Data Type](#_Data_Type) | Internal user only  Reference Price Manual Input. Applicable when the user accept this Error Trade Claim. Editable when the Status is New. |
| Best Bid/Offer | Price | [Ref to Data Type](#_Data_Type) | Internal user only  Best Bid/Offer at the claimed Error Trade. The system needs to retrieve the information for reference. Shown immediately when available. (Display as <Best Bid>/<Best Ask>, e.g. 18100/17900) |
| Deviation | Price | [Ref to Data Type](#_Data_Type) | Internal user only  Automatic calculation based on input Reference Price:  ![](data:image/png;base64...)$\left|Reference?Price?-?Traded?Price\right|$  $\left|Reference?Price?-?Traded?Price\right|$ |
| Potential Loss | Price | [Ref to Data Type](#_Data_Type) | Internal user only  Automatic calculation based on input Reference Price:  ![](data:image/png;base64...) |
| Current Status | Alphanumeric | TBC | Status of the Error Trade Request:  Domain Values:  **New** – System Verification in Progress  **Accepted –** DT accepted the Error Trade claim request, pending decision by contra-side EP and/or review committee  **Rejected –** DT decided not to proceed with the Error Trade Claim  **Processed as LET –** DT decided to proceed the claim as LET  **Processed –** Error Trade Claim approved and submitted to clearing |
| Decided By | Alphanumeric | TBC | Internal user only  Dropbox for selecting the cancellation reason. Editable when accepted, required if the claim is "Accepted" and being "Approve".  Followings are the options available:  (i) Approved by EP  (ii) Approved by Committee |
| Contra-EP Response | Alphanumeric | TBC | Internal User only  Status of the Contra-EP reply. N/A when Status of the Error Trade Request is New.  It can be:  (i) N/A  (ii) Accepted  (iii) Declined |
| Clearing Status | Alphanumeric | TBC | Internal User only  Status from Clearing. N/A when Status of the Error Trade Clain is New/Rejected/Accepted.  For Status is Processed, it can be:  (i) N/A  (ii) Pending Response  (iii) Acknowledged |

**Tooltips**

**#FS10014a\_S0626\_00600**

| Column | Tooltips |
| --- | --- |
| Claim ID | Specifies the unique ID of the Error Trade Request. |
| Trade ID | Specifies the unique ID of the Trade. |
| Instrument | Specifies the name of contract involved in the Trade. |
| Traded Price | Specifies the Price of the Trade. |
| Traded Quantity | Specifies the Quantity of the Trade. |
| Trade Time | Specifies the time of the Trade. |
| Claim Time | Specifies the submission time of the Error Trade Request. |
| Claimant EP | Specifies the EP who submits the Error Trade Request. |
| Contra-side EP | Specifies the Contra-side EP of the Trade. |
| Time Validation | Specifies the validation result on the time of the claim. |
| Last Traded Price | Specifies the Last Traded Price at the claimed Error Trade. |
| Reference Price | Specifies the Reference Price. |
| Best Bid/Offer | Specifies the best Bid/Offer at the claimed Error Trade. |
| Deviation | Specifies the automatic calculation based on input Reference Price. |
| Potential Loss | Specifies the automatic calculation based on input Reference Price. |
| Current Status | Specifies the status of the claim in the System |
| Decided By | Specifies the approval reason. |
| Contra-EP Response | Specifies the status of the Contra-EP reply. |
| Clearing Status | Specifies the status from Clearing |

**Read / Write Permission Behaviour**

**#FS10014a\_S0626\_00700**

| Permission | Behavior |
| --- | --- |
| Read | User can view the Error Trade Request details of each request |
| Write | Internal User  **Accept**, **Approve** or **Reject** an Error Trade Request  External User  **Accept** or **Decline** an Error Trade Request |

**Action**

**#FS10014a\_S0626\_00800**

1. **Accept**

Internal User

Confirmation box will be prompted with the following text when user click on the **Accept** button.

*Confirm accept of Error Trade Request.*

The Current Status of the Error Trade Request would become **Accepted**, and the Error Trade Request would be sent to Contra-Side EP for review.

External User

Confirmation box will be prompted with the following text when user click on the **Accept** button.

*Confirm accept Error Trade Request.*

The Contra-Side EP Response field will be updated to Accepted. **Note that Contra-Side EP acceptance would not affect the Current Status field of the requests**.

1. **Decline Error Trade Request(s)**

This action is for External User only.

Confirmation box will be prompted with the following text when user click on the **Decline** button.

*Confirm decline Error Trade Request.*

The Contra-Side EP Response field will be updated to Decline. **Note that Contra-Side EP acceptance would not affect the Current Status field of the requests**. The final decision maker of the request is DT Operation and review committee.

1. **Approve Error Trade Request(s)**

This action is for Internal User only.

Confirmation box will be prompted with the following text when user click on the **Approve** button.

*Confirm approve Error Trade Request.*

The Approve Error Trade Request will be submitted when user clicks OK on the confirmation box. The status would become **Processed**.

1. **Reject Error Trade Request(s)**

This action is for Internal User only. Users can select one or more Error Trade Requests from the Error Trade Request table and click the **Reject Error Trade Request(s)** option from the **More Actions** menu to reject the selected Error Trade Requests.

Confirmation box will be prompted with the following text when user click on the **Reject Error Trade Request(s)** option.

*Confirm reject of selected Error Trade Request(s).*

The Reject Error Trade Requests will be submitted when user clicks OK on the confirmation box. The status would become **Rejected.**

**Validation**

**#FS10014a\_S0626\_00900**

Refer to Validation section in 6.25

**User Notification (TBC)**

**#FS10014a\_S0626\_01000**

## Large Scale-Error Trade View

**Description**

**#FS10014a\_S0627\_00100**

This function is applicable to Internal only.

**#FS10014a\_S0627\_00200**

This window allows DT business to initiate LET by specify criteria for LET which includes:

a. Market, with multiple market support

b. Participant ID, optional

c. Time Range, mandatory

Alternatively, DT Business can upload a file with trade IDs for LET.

**#FS10014a\_S0627\_00300**

The initiated LET will be shown as an item in the Large Scale-Error Trade window.

**Accessing the Function**

**#FS10014a\_S0627\_00400**

Search Page

Large Scale-Error Trade window can be opened from the Menu. ODP Online allows only one Large Scale-Error Trade window to be opened.

Initiate Large Scale-Error Trade Page

Initiate Large Scale-Error Trade window can be opened by clicking on the **Initiate Large Scale-Error Trade** button in Large Scale-Error Trade window.

Detail Page

Large Scale-Error Trade detail window can be opened by double clicking a LET / select a LET and choose **More Actions > View LET** in Large Scale-Error Trade window.

**UI Layout**

**#FS10014a\_S0627\_00500**

Search Page

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

Initiate Large Scale-Error Trade Dialog

Initiate Large Error Trade (LET):

![](data:image/png;base64...)

Initiate Large Error Trade (LET) Verification:

![](data:image/png;base64...)

Detail Page

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

**Attributes**

**#FS10014a\_S0627\_00600**

Search Page

| Column | Type | Length | Remarks |
| --- | --- | --- | --- |
| LET ID | Numeric | TBC | Unique ID of the Large Scale-Error Trade. |
| LET initiate time | Date and Time | 16 | The time that the Large Scale-Error Trade being initiated.  In DD-MM-YYYY HH:MM:SS format. |
| Num of contracts | Numeric | TBC | Number of contracts involved in the LET. |
| Num of trades | Numeric | TBC | Number of trades involved in the LET. |
| Num of EPs | Numeric | TBC | Number of EPs involved in the LET |
| Status | Alphanumeric | TBC | Status of the Large-Scale Error Trade:  Domain Values:  **Pending** – Pending to retrieve information from satellite LET.  **Ready –** Information returned from satellite LET and ready to Proceed / Reject.  **Proceed –** DT confirm to proceed with the LET.  **Rejected –** DT rejected the LET. |

Initiate Large Scale-Error Trade Page

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Exchange Participants | List  **Dropdown (with multiple selection)** | - | M | - | Exchange Participants, with multiple exchange participants support |
| Market | List  **Dropdown (with multiple selection)** | - | M | - | Market, with multiple market support |
| Start Time | Time  **Time Selection Drop Down** | 6 | M | - | The start of the Time Range. |
| End Time | Time  **Time Selection Drop Down** | 6 | M | - | The end of the Time Range. |
| **Initiate Large Error Trade (LET) Verification**  (Data in this section is available only when the status is **Ready**) | | | | | |
| Number of Instruments | Quantity  **Text Input**  **(With up / down per tick size)** | 9 | M | - | The number of instruments. |
| Number of Trades | Quantity  **Text Input**  **(With up / down per tick size)** | 9 | M | - | The number of trades. |
| Number of EPs | Quantity  **Text Input**  **(With up / down per tick size)** | 9 | M | - | The number of EPs. |

Detail Page

| Column | Type | Length | Remarks |
| --- | --- | --- | --- |
| **Large-Scale Error Trade (LET) Result** | | | |
| LET ID | Numeric | TBC | Unique ID of the Large Scale-Error Trade. |
| LET initiate time | Date and Time | 16 | The time that the Large Scale-Error Trade being initiated.  In DD-MM-YYYY HH:MM:SS format. |
| Num of contracts | Numeric | TBC | Number of contracts involved in the LET. |
| Num of trades | Numeric | TBC | Number of trades involved in the LET. |
| Num of EPs | Numeric | TBC | Number of EPs involved in the LET |
| Status | Alphanumeric | TBC | Status of the Large-Scale Error Trade:  Domain Values:  **Pending** – Pending to retrieve information from satellite LET.  **Ready –** Information returned from satellite LET and ready to Proceed / Reject.  **Confirmed –** DT confirmed to proceed with the LET.  **Rejected –** DT rejected the LET.  **Proceeded –** The execution of LET completed. |
| **Large-Scale Error Trade (LET) Result**  (Data in this section is available only when the status is **Proceeded**) | | | |
| Trade ID | Numeric | - | Unique ID of the Trade. |
| Market | Alphanumeric | - | The Market. |
| Participant | Alphanumeric | - | The participant who own the trade. |
| Time | Alphanumeric | - | Time of the Trade. |
| Instrument ID | Alphanumeric | - | Instrument ID of the Trade. |

**Tooltips**

**#FS10014a\_S0627\_00700**

| Column | Tooltips |
| --- | --- |
| LET ID | Specifies the unique ID of the Large Scale-Error Trade. |
| LET initiate time | Specifies the time that the Large Scale-Error Trade being initiated. |
| Num of contracts | Specifies the number of contracts involved in the LET. |
| Num of trades | Specifies the number of trades involved in the LET. |
| Num of EPs | Specifies the number of EPs involved in the LET |
| Market | Specifies the Market of the Trade. |
| Participant | Specifies the participant who own the trade. |
| From Time | Specifies the start of the Time Range to initiate a Large Scale-Error Trade. |
| To Time | Specifies the end of the Time Range to initiate a Large Scale-Error Trade. |
| Trade ID | Specifies the unique ID of the Trade. |
| Time | Specifies the time of the Trade. |
| Instrument ID | Specifies the instrument ID of the Trade. |
| Status | Specifies the status of the Large-Scale Error Trade |

**Data refresh in table**

**#FS10014a\_S0627\_00800**

Search Page

This view will automatically update upon any changes of the LET.

**Default Sorting Order**

**#FS10014a\_S0627\_00900**

Search Page

The Large Scale-Error Trade windows is sorted by ascending order of LET initiate time by default.

**Filtering Criteria**

**#FS10014a\_S0627\_01000**

Search Page

| Filtering Criteria | Type |
| --- | --- |
| Status | Dropdown |

**Read / Write Permission Behaviour**

**#FS10014a\_S0627\_01100**

Search Page

| Permission | Behavior |
| --- | --- |
| Read | User can perform the following:   * View all the data in the Large Scale-Error Trade Table * Perform Sorting/Filtering on the Large Scale-Error Trade Table * Export Large Scale-Error Trade table as CSV File * View the detail of a Large Scale-Error Trade |
| Write | User can perform the following:   * View all the data in the Large Scale-Error Trade Table * Perform Sorting/Filtering on the Large Scale-Error Trade Table * Export Large Scale-Error Trade table as CSV File * Open the Initiate Large Scale-Error Trade page * View the detail of a Large Scale-Error Trade * Proceed a Large Scale-Error Trade * Reject a Large Scale-Error Trade |

Initiate Large Scale-Error Trade Page

| Permission | Behavior |
| --- | --- |
| Read | N/A. As this page is for initiate a new Large Scale-Error Trade only. |
| Write | User with write permission can fill in and initiate a new Large Scale-Error Trade. |

Detail Page

| Permission | Behavior |
| --- | --- |
| Read | User can perform the following:   * Export Large Scale-Error Trade as CSV File * View the detail of a Large Scale-Error Trade * View the execution result of a Large Scale-Error Trade |
| Write | User can perform the following:   * Export Large Scale-Error Trade as CSV File * View the detail of a Large Scale-Error Trade * View the execution result of a Large Scale-Error Trade * Proceed a Large Scale-Error Trade * Reject a Large Scale-Error Trade |

**Action**

**#FS10014a\_S0627\_01200**

Search Page

1. **Initiate Large Scale-Error Trade**

Bring up the Initiate Large Scale-Error Trade window.

1. **View LET**

User can select a Large Scale-Error Trade from the table and click the **View LET** option from the **More Actions** menu to view the detail of the LET.

It will bring up the detail window for the selected LET.

1. **Proceed LET**

User can select one or more LET from the LET table and click the **Proceed LET** option from the **More Actions** menu to proceed with the selected LETs.

Confirmation box will be prompted with the following text when user click on the **Proceed LET** option.

*Confirm proceed with the selected LET(s).*

The Proceed LET will be submitted when user clicks OK on the confirmation box.

Once proceeded LET, if the Trade ID exists in the Error Trade Request Window, the corresponding Error Trade Request will be updated to **Ended**.

1. **Reject LET**

User can select one or more LET from the LET table and click the **Reject LET** option from the **More Actions** menu to reject the selected LETs.

Confirmation box will be prompted with the following text when user click on the **Reject LET** option.

*Confirm reject the selected LET(s).*

The Reject LET will be submitted when user clicks OK on the confirmation box.

1. **Export to CSV file**

The users can click "**Export to CSV File**" to export those records from GUI table.

Initiate Large Scale-Error Trade Page

1. **Import**

Import the trade file in CSV file format. This CSV file contains one or more Trade ID. Once imported, system will initiate a Large-Scale Error Trade (LET). And the LET will be available in the Error Trade Request Window.

The CSV file should contain the following fields:

*"Trade ID"*

1. **Initiate Large-Scale Error Trade (LET)**

Initiate Large-Scale Error Trade (LET) based on the criteria input in the Large-Scale Error Trade (LET) Criteria section. And the LET will be available in the Error Trade Request Window.

1. **Clear**

Clear all the input in the Large-Scale Error Trade (LET) Criteria section.

Detail Page

1. **Proceed**

User can press **Proceed** buttonto proceed with the Large-Scale Error Trade.

Confirmation box will be prompted with the following text when user click on the **Proceed** button.

*Confirm proceed of Large-Scale Error Trade.*

The Proceed Large-Scale Error Trade will be submitted for approval when user clicks OK on the confirmation box.

Once proceeded LET, if the Trade ID exists in the Error Trade Request Window, the corresponding Error Trade Request will be updated to **Ended**.

1. **Reject**

User can press **Reject** buttonto accept the Large-Scale Error Trade.

Confirmation box will be prompted with the following text when user click on the **Reject** button.

*Confirm reject of Large-Scale Error Trade.*

The Reject Large-Scale Error Trade will be submitted for approval when user clicks OK on the confirmation box.

**Validation**

**#FS10014a\_S0627\_01300**

Search Page

1. **Proceed LET**
2. LET can be proceed only when the status is **Ready**.
3. **Reject LET**
4. LET can be rejected only when the status is **Ready** / **Pending**.

Initiate Large Scale-Error Trade Page

1. **Import**
2. CSV file must contain only one column “Trade ID”.
3. **Initiate Large-Scale Error Trade (LET)**
4. Market and Time Range must be selected.
5. From Time must be earlier than To Time.

Detail Page

1. **Proceed**
2. LET can be proceed only when the status is **Ready**.
3. **Reject**
4. LET can be rejected only when the status is **Ready / Pending**.

TBC

**User Notification**

**#FS10014a\_S0627\_01400**

TBC

## Order Setting

**#FS10014a\_S0628\_00100**

**Description**

**#FS10014a\_S0628\_00200**

The order setting tab allows users to set different default parameters with regards to order entering.

**Accessing the Function**

**#FS10014a\_S0628\_00300**

Order Setting window can be opened from menu. ODP Online allows only one Order Setting window to be opened.

**UI Layout**

**#FS10014a\_S0628\_00400**

![](data:image/png;base64...)![](data:image/png;base64...)

**Attributes**

**#FS10014a\_S0628\_00500**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| **Default** | | | | | |
| Time Validity | Alphanumeric  **Dropdown** | - | O | Day | Specifies the default validity when opening the Enter Order and Enter Tailor-Made Combination windows.  Domain Values:  **Fill or Kill (FOK)**  **Fill and Kill (FAK)**  **Day**  **Good till Date (GTD)**  **Good till Cancelled (GTC)** |
| Tradable in AHT | Boolean  **Switch** | - | O | - | By checking the box, Tradable in AHT will be specified when opening the Enter Order and Enter Tailor-Made Combination windows. |
| Quantity | Quantity  **Text Input**  **(With up / down per 1 quantity)** | [Ref to Data Type](#_Data_Type) | O | - | Specifies the default quantity when opening the Enter Order and Enter Trade Report windows. |
| Give Up Participant | Alphanumeric  **Text Input**  **(with Content Assist)** | 5 | O | - | Specifies the default Give Up Participant when opening the Enter Order, Enter Tailor-Made Combination and Enter Trade Report windows. |
| **Give Up Information** | | | | | |
| Give Up ~~Account~~  Information | Alphanumeric  **Text Input**  **(with Content Assist)** | 15 | O | - | Users can specify a list of Give Up information.  **Max size of the list is 20** |
| Default Give Up ~~Account~~ Information | Alphanumeric  **Text Input**  **(with Content Assist)** | 15 | O | - | Specify the default Give Up Information when opening the Enter Order and Enter Trade Report windows. |
| **Customer Information** | | | | | |
| Customer information | Alphanumeric  **Text Input** | 16 | O | - | Users can specify a list of Customer information (Info).  **Max size of the list is 20** |
| Default Customer information | Alphanumeric  **Text Input**  **(with Content Assist)** | 16 | O | - | Specify the default Customer information (Info) when opening the Enter Order, Enter Tailor-Made Combination and Enter Trade Report windows. |
| **Customers** | | | | | |
| Customers | Alphanumeric  **Text Input** | 10 | O | - | Users can specify a list of Customer(s).  **Max size of the list is 20** |
| Default Customers | Alphanumeric  **Text Input**  **(with Content Assist)** | 10 | O | - | Specify the default Customer when opening the Enter Order, Enter Tailor-Made Combination and Enter Trade Report windows. |
| **~~Miscellaneous~~** | | | | | |
| ~~Confirm no market price order~~ | ~~Boolean~~  **~~Switch~~** | ~~TBC~~ | ~~O~~ | ~~False~~ | ~~By checking the box, confirmation message will appear when users enter an order in which there is no market price.~~ |

**Tooltips**

**#FS10014a\_S0628\_00601**

| Column | Tooltips |
| --- | --- |
| Time Validity | Specifies the default validity when opening the Enter Order and Enter Tailor-Made Combination windows. |
| Tradable in AHT | By checking the box, Tradable in AHT will be specified when opening the Enter Order and Enter Tailor-Made Combination windows. |
| Quantity | Specifies the default quantity when opening the Enter Order and Enter Trade Report windows. |
| Give Up Participant | Specifies the default Give Up Participant when opening the Enter Order, Enter Tailor-Made Combination and Enter Trade Report windows. |
| Give Up ~~Account~~  information | Specifies a list of Give Up information. |
| Default Give Up ~~Account~~  information | Specifies the default Give Up information when opening the Enter Order and Enter Trade Report windows. |
| Customer information | Specifies a list of Customer information (Info). |
| Default Customer information | Specifies the default Customer information (Info) when opening the Enter Order, Enter Tailor-Made Combination and Enter Trade Report windows. |
| Customers | Specifies a list of Customer(s). |
| Default Customers | Specifies the default Customer when opening the Enter Order, Enter Tailor-Made Combination and Enter Trade Report windows. |
| ~~Confirm no market price order~~ | ~~By checking the box, confirmation message will appear when users enter an order in which there is no market price.~~ |

**Read / Write Permission Behaviour**

**#FS10014a\_S0628\_00700**

| Permission | Behavior |
| --- | --- |
| Read | User can open the page but cannot perform any update. |
| Write | User can update the Order Setting. |

**Action**

**#FS10014a\_S0628\_00800**

1. **Update**

Update the Order Setting to System according to the input.

**Validation**

**#FS10014a\_S0628\_00900**

1. Default Give up Account should exist in the Give up Account Table.
2. Default Customer Information should exist in the Customer Information Table.
3. Default Customer should exist in the Customers Table.
4. Trade Report Type should exist and active in the system.
5. Give up Account Table supported up to 20 records.
6. Customer Information Table supported up to 20 records.
7. Customer Table supported up to 20 records.

**User Notification**

**#FS10014a\_S0628\_01000**

N/A

**~~Order Confirmation Messages~~**

**~~#FS10014a\_S0628\_01100~~**

~~If~~ **~~Confirm no market price order~~** ~~had been selected, a confirmation box will be prompt when the instrument doesn’t have market price yet.~~

~~Orders can still be sent to the market by clicking~~ **~~OK~~** ~~button to the following message.~~

*~~No market price.~~*

*~~Confirm <buy/sell> order.~~*

~~The confirmation box will appear in the following places:~~

1. ~~When user submit an Order via Enter Order.~~
2. ~~When user activate an Order via Local Inactive Orders~~

## Confirmation Setting

**#FS10014a\_S0629\_00100**

**Description**

**#FS10014a\_S0629\_00200**

The Confirmations tab allows external users to specify which confirmation windows will appear when managing their orders. After a confirmation setting is activated, a pop up message will appear for users to confirm the action. By default, all tabs are checked which means pop up message will appear for users.

**Accessing the Function**

**#FS10014a\_S0629\_00300**

Confirmation Setting window can be opened from menu. ODP Online allows only one Confirmation Setting window to be opened.

**UI Layout**

**#FS10014a\_S0629\_00400**

**![](data:image/png;base64...)![](data:image/png;base64...)**

**Attributes**

**#FS10014a\_S0629\_00500**

| Column | Type | M/O | Default | Remarks |
| --- | --- | --- | --- | --- |
| **Workspace** | | | | |
| Open Layout | Boolean **Switch** | O | - | Users open a layout. |
| Reload Layout | Boolean **Switch** | O | - | Users reload a layout. |
| Delete Layout | Boolean **Switch** | O | - | Users delete a layout. |
| Clean Layout | Boolean **Switch** | O | - | Users clean layout. |
| Save Workspace | Boolean **Switch** | O | - | Users save a workspace. |
| Import Layout | Boolean **Switch** | O | - | Users import a layout. |
| **Order Book** | | | | |
| Cancel | Boolean **Switch** | O | - | Users cancel an order. |
| Cancel all | Boolean **Switch** | O | - | Users cancel all orders. (via “Cancel all” button in Order Book) |
| Inactivate locally | Boolean **Switch** | O | - | Users locally inactivate an order. |
| Inactivate locally all | Boolean **Switch** | O | - | Users locally inactivate all orders. (via “Inactivate locally all” button) |
| **Enter Order** | | | | |
| Buy | Boolean **Switch** | O | - | Users input a bid order. |
| Sell | Boolean **Switch** | O | - | Users input an ask order. |
| Confirm no market price order | Boolean **Switch** | O | - | Users confirm no market price order. |
| **Change Order** | | | | |
| Buy | Boolean **Switch** | O | - | Users change a bid order. |
| Sell | Boolean **Switch** | O | - | Users change an ask order. |
| Lose Priority | Boolean **Switch** | O | - | Users change an order and the change is going to affect the priority of the targeted order. |
| **Enter Tailor-Made Combination** | | | | |
| Buy | Boolean **Switch** | O | - | Users input a Tailor-Made Combination bid order. |
| Sell | Boolean **Switch** | O | - | Users input a Tailor-Made Combination ask order. |
| **Automatic Quote Order Book** | | | | |
| Cancel | Boolean **Switch** | O | - | Users cancel an order in Automatic Quote Order Book. |
| **Quotes** | | | | |
| Submit quote | Boolean **Switch** | O | - | Users submit a quote |
| Submit all quotes | Boolean **Switch** | O | - | Users submit all quotes. (via “Submit all quotes” button) |
| Cancel quote | Boolean **Switch** | O | - | Users cancel a quote. |
| Cancel all quotes | Boolean **Switch** | O | - | Users cancel all quotes. (via “Cancel all quotes” button) |
| **Quote Reply** | | | | |
| Submit | Boolean **Switch** | O | - | Users submit a quote reply. |
| Ignore | Boolean **Switch** | O | - | Users ignore a quote reply. |
| **Local Inactive Orders** | | | | |
| Delete selected | Boolean **Switch** | O | - | Users delete a local inactivated order. |
| Delete all | Boolean **Switch** | O | - | Users delete all local inactivated orders. (via “Delete all” button) |
| Activate selected | Boolean **Switch** | O | - | Users activate a local inactivated order. |
| Activate all | Boolean **Switch** | O | - | Users activate all local inactivated orders. (via “Activate all” button) |
| **Price Information** | | | | |
| Quote request | Boolean **Switch** | O | - | Users submit a quote request. |
| **Enter Trade Report** | | | | |
| Submit | Boolean **Switch** | O | - | Users enter a trade report. |
| **Pending Trade Report** | | | | |
| Accept | Boolean **Switch** | O | - | Users accept pending trade report. |
| Reject | Boolean **Switch** | O | - | Users reject pending trade report. |
| Cancel | Boolean **Switch** | O | - | Users cancel pending trade report. |
| **Error Trade Request View** | | | | |
| Accept | Boolean **Switch** | O | - | Users accept error trade request. |
| Reject | Boolean **Switch** | O | - | Users reject error trade request. |
| **Error Trade Request Detail** | | | | |
| Accept | Boolean **Switch** | O | - | Users accepts error trade request. |
| Reject | Boolean **Switch** | O | - | Users reject error trade request. |

**Tooltips**

**#FS10014a\_S0629\_00600**

| Column | Tooltips |
| --- | --- |
| **Workspace** | |
| Open Layout | Users open a layout. |
| Reload Layout | Users reload a layout. |
| Delete Layout | Users delete a layout. |
| Clean Layout | Users clean a layout. |
| Save Workspace | Users save a workspace. |
| Import Layout | Users import a layout. |
| **Order Book** | |
| Activate | Users activate an inactivated order. |
| Cancel | Users cancel an order. |
| Cancel all | Users cancel all orders. (via “Cancel all” button in Order Book) |
| Inactivate locally | Users locally inactivate an order. |
| Inactivate locally all | Users locally inactivate all orders. (via “Inactivate locally all” button) |
| **Enter Order** | |
| Buy | Users input a bid order. |
| Sell | Users input an ask order. |
| **Change Order** | |
| Buy | Users change a bid order. |
| Sell | Users change an ask order. |
| Lose Priority | Users change an order and the change is going to affect the priority of the targeted order. |
| **Enter Tailor-Made Combination** | |
| Buy | Users input a Tailor-Made Combination bid order. |
| Sell | Users input a Tailor-Made Combination ask order. |
| **Automatic Quote Order Book** | |
| Cancel | Users cancel an order in Automatic Quote Order Book. |
| **Quotes** | |
| Submit quote | Users submit a quote |
| Submit all quotes | Users submit all quotes. (via “Submit all quotes” button) |
| Cancel quote | Users cancel a quote. |
| Cancel all quotes | Users cancel all quotes. (via “Cancel all quotes” button) |
| **Quote Reply** | |
| Submit | Users submit a quote reply. |
| Ignore | Users ignore a quote reply. |
| **Local Inactive Orders** | |
| Delete selected | Users delete a local inactivated order. |
| Delete all | Users delete all local inactivated orders. (via “Delete all” button) |
| Activate selected | Users activate a local inactivated order. |
| Activate all | Users activate all local inactivated orders. (via “Activate all” button) |
| **Price information** | |
| Quote request | Users submit a quote request. |
| **Enter Trade Report** | |
| Submit | Users enter a trade report. |
| **Pending Trade Report** | |
| Accept | Users accept a trade report. |
| Reject | Users reject a trade report. |
| Cancel | Users cancel a trade report. |
| **Error Trade Request View** | |
| Accept | Users accept an error trade request. |
| Reject | Users reject an error trade request. |
| **Error Trade Request Detail** | |
| Accept | Users accept an error trade request. |
| Reject | Users reject an error trade request. |

**Read / Write Permission Behaviour**

**#FS10014a\_S0629\_00700**

| Permission | Behavior |
| --- | --- |
| Read | User can open the page but cannot perform any update. |
| Write | User can update the Order Setting. |

**Action**

**#FS10014a\_S0629\_00800**

1. **Update**

Update the Confirmation Setting to System according to the input.

Confirmation box will be prompted with the following text when user click on the update button.

*Confirm settings.*

The settings will be applied when user clicks OK on the confirmation box.

**Validation**

**#FS10014a\_S0629\_00900**

N/A

**User Notification**

**#FS10014a\_S0629\_01000**

N/A

**No Market Price Confirmation**

**#FS10014a\_S0629\_01100**

If **Confirm no market price order** had been selected, a confirmation box will be prompt when the instrument doesn’t have market price yet.

Orders can still be sent to the market by clicking **OK** button to the following message.

*No market price.*

*Confirm <buy/sell> order.*

The confirmation box will appear in the following places:

1. When user submit an Order via Enter Order.
2. When user activate an Order via Local Inactive Orders

## Deviation Warnings

**#FS10014a\_S0630\_00100**

**Description**

**#FS10014a\_S0630\_00200**

The order setting tab allows users to set different default parameters with regards to order entering.

**Accessing the Function**

**#FS10014a\_S0630\_00300**

Deviation Warnings window can be opened from the SETTING menu. ODP Online allows only one Deviation Warnings window to be opened.

**UI Layout**

**#FS10014a\_S0630\_00400**

![](data:image/png;base64...)

**Attributes**

**#FS10014a\_S0630\_00501**

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| **General level** | | | | | |
| Premium | Percentage  **Text Input**  **(With up / down per 0.0001)** | [Ref to Data Type](#_Data_Type) | O | - | Specifies the maximum price deviation of an order for all instruments in percentage compare to last traded price if available. |
| Max volume | Quantity  **Text Input**  **(With up / down per 1)** | [Ref to Data Type](#_Data_Type) | O | - | Specifies the maximum allowed volume for all instruments. |
| **Type Level** | | | | | |
| Instrument Type | Alphanumeric  **Text Input**  **(with Content Assist)** | - | O | - | Specify the maximum price deviation and volume for a specific instrument type. |
| Premium | Percentage  **Text Input**  **(With up / down per 0.0001)** | [Ref to Data Type](#_Data_Type) | O | - | Specify the maximum price deviation for a specific instrument type in percentage compare to last traded price if available. |
| Max volume | Quantity  **Text Input**  **(With up / down per 1)** | [Ref to Data Type](#_Data_Type) | O | - | Specify the maximum volume for a specific instrument type. |
| Action | Alphanumeric  **Dropdown** | - | O | - | The action to execute when violation occurs.  Domain Value:  **Ignore**  **Warning**  **Restriction**  refer to additional information |

**Additional Information**

**#FS10014a\_S0630\_00600**

The following table denotes all the scenarios and outcomes with respective to the Deviation warnings settings:

**Instrument Type Action:** Defined under “ACTION” column of each instrument type.

**Input:** Inputted Volume or deviated price by the users when placing the order.

**General:** Value entered in the general level (volume or price deviation)

**Type:** Value entered in the type level (volume or price deviation)

**Warn:** A warning message will pop up and warn the users. Users need to confirm before the order action.

**Restrict:** The order action is restricted and blocked. Alert message pops up.

| Inputted value (Volume/Premium Deviation) | Instrument Type Action:  Warning | Instrument Type Action:  Restriction | Instrument Type Action:  Ignore |
| --- | --- | --- | --- |
| **Input** ≥ General > Type | Warn (Type) | Restrict (Type) | Warn (General) |
| General > **Input** ≥ Type | Warn (Type) | Restrict (Type) | No message |
| **Input** ≥ Type > General | Warn (General) | Restrict (Type) | Warn (General) |
| Type > **Input** ≥ General | Warn (General) | Warn (General) | Warn (General) |

\* Bracket () denotes the attributive level of the outcome.

**Tooltips**

**#FS10014a\_S0630\_00700**

| Column | Tooltips |
| --- | --- |
| Premium | Specifies the maximum price deviation of an order for all instruments. |
| Max volume | Specifies the maximum allowed volume for all instruments. |
| Instrument Type | Specify the maximum price deviation and volume for a specific instrument type. |
| Action | Specifies the action to execute when violation occurs. |

**Read / Write Permission Behaviour**

**#FS10014a\_S0630\_00800**

| Permission | Behavior |
| --- | --- |
| Read | User can open the page but cannot perform any update. |
| Write | User can update the Deviation Warnings. |

**Action**

**#FS10014a\_S0630\_00900**

1. **Type Level – Add / Update**

User can add a new record to the Type Level table or update a record in the Type Level table by filling in the input fields and click the **Add / Update** button.

If user input an instrument type that doesn’t exists in the table, system will add this instrument type to the table as a new record.

If user input an instrument type that’s already exists in the table, system will update the corresponding record based on the new input.

1. **Type Level – Delete**

User can select one or more instrument type in the Type Level table and click the **Delete** button to delete the instrument types from the table.

1. **Update**

User can click the **Update** button to apply the change to the System.

**Validation**

**#FS10014a\_S0630\_01000**

N/A

**User Notification**

**#FS10014a\_S0630\_01100**

N/A

**Order Confirmation Messages**

**#FS10014a\_S0630\_01200**

Price Deviation Warning Message

A warning message will pop up if the order price deviates from the market price for more than the defined parameter. However, orders can still be sent to the market by clicking **OK** button to the following message.

*Price deviation exceeded.*

*Price differs X.XXXX% from market price.*

*Confirm <buy/sell> order.*

The confirmation box will appear in the following places:

1. When user submit an Order via Enter Order.
2. When user submit an Order via Execute Order.
3. When user change an Order via Change Order.
4. When user activate an Order via Local Inactive Orders

Max Volume Warning Message

The following message will pop up if the order size is greater than or equal to the quantity restrictions set in the Max volume field. However, orders can still be sent by clicking **OK** button to the following message.

*Quantity deviation exceeded.*

*Quantity greater than or equal to user defined max quantity N..*

*Confirm <buy/sell> order.*

The confirmation box will appear in the following places:

1. When user submit an Order via Enter Order.
2. When user submit an Order via Execute Order.
3. When user change an Order via Change Order.
4. When user activate an Order via Local Inactive Orders

**Mandatory Deviation Setting**

USERS ARE REQUIRED TO SET PRICE DEVIATIONS AND MAX VOLUMES FOR ALL INDIVIDUAL INSTRUMENT TYPES. THEY ARE REQUIRED TO SELECT RESTRICTIONS AS THE DEFAULT ACTION. HOWEVER, USERS ARE ALLOWED TO SET THE DEVIATION AND QUANTITY PARAMETERS AT REASONABLE LEVELS ACCORDING TO THEIR OWN TRADING PATTERNS AND PRACTICES

## Client Global Parameter Setting

TODO – External Client Self-serve setting page

## Exchange On-Behalf Trade

**Description**

**#FS10014a\_S0632\_00100**

This function is applicable to Internal only.

This window is used for exchange internal staff to input trade on behalf of Exchange Participant in special occasions.

**Accessing the Function**

**#FS10014a\_S0632\_00200**

Exchange On-Behalf window can be opened from the menu.

ODP Online allows one Exchange On-Behalf window to be opened.

**UI Layout**

**#FS10014a\_S0632\_00300**

**![](data:image/png;base64...)**

**Attributes**

**#FS10014a\_S0632\_00400**

| Column | Type | Length | M/O | | Default | | Remarks |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Instrument ID | Alphanumeric  **Text Input (with Content Assist)** | 32 | M | - | | **#FS10014a\_S0632\_00400**  Tradable Instrument Identifier.  **#FS10014a\_S0632\_00500**  ***Whenever there are changes to the Instrument ID field, the Price and Quantity will be reset.*** | |
| Price | Price  **Text Input (With up / down per tick unit)** | [Ref to Data Type](#_Data_Type) | M | - | | **#FS10014a\_S0632\_00600**  The price of Exchange On-Behalf Trade to be input by the internal exchange staff. | |
| Quantity | Quantity  **Text Input**  **(With up / down per tick size)** | [Ref to Data Type](#_Data_Type) | M | - | | **#FS10014a\_S0632\_00700**  The quantity of Exchange On-Behalf Trade to be input by the internal exchange staff.  **#FS10014a\_S0632\_00800**  It’s an up/low button to adjust the quantity up / down with the change in one contract. (Both mouse click, and keyboard up/down are supported) | |
| **Buy Side Attributes** | | | | | | | |
| Comp ID | Alphanumeric  **Text Input** | TBC | M | - | | **#FS10014a\_S0632\_01000**  Specify the buy side CompID | |
| Trader ID | Alphanumeric  **Text Input** | TBC | M | - | | **#FS10014a\_S0632\_00900**  Specify the buy side TraderID | |
| Customer | Alphanumeric  **Text Input**  **(With Content Assist)** | 10 | O | - | | The name or ID of a market participant’s client.  Refer to Enter Order | |
| Position Effect | Alphanumeric  **Text Input with Dropdown** | TBC | O | Open | | **#FS10014a\_S0632\_01100**  Specify the buy side Position Effect | |
| Customer Information | Alphanumeric  **Text Input** | 15 | O | - | | **#FS10014a\_S0632\_01200** Specify the buy side Customer Information | |
| BCAN | Alphanumeric  **Text Input** | 17 | O | - | | **#FS10002\_S0020\_13100** The BCAN attribute is a pass-through attribute. It is used to identify the order’s originator for market surveillance purposes. | |
| **Sell Side Attributes** | | | | | | | |
| Comp ID | Alphanumeric  **Text Input** | TBC | M | - | | **#FS10014a\_S0632\_01400**  Specify the sell side CompID | |
| Trader ID | Alphanumeric  **Text Input** | TBC | M | - | | **#FS10014a\_S0632\_01300** Specify the sell side TraderID | |
| Customer | Alphanumeric  **Text Input**  **(With Content Assist)** | 10 | O | - | | The name or ID of a market participant’s client.  Refer to Enter Order | |
| Position Effect | Alphanumeric  **Text Input with Dropdown** | TBC | O | Open | | **#FS10014a\_S0632\_01500**  Specify the sell side Position Effect | |
| Customer Information | Alphanumeric  **Text Input** | 15 | O | - | | **#FS10014a\_S0632\_01600**  Specifies the sell side Customer Information | |
| BCAN | Alphanumeric  **Text Input** | 17 | O | - | | **#FS10002\_S0020\_13100** The BCAN attribute is a pass-through attribute. It is used to identify the order’s originator for market surveillance purposes. | |
| **Update Statistics** | | | | | | | |
| Last Trade Price | Boolean switch | - | O | False | | **#FS10014a\_S0632\_01600**  Option to select whether the trade would update the Last Trade Price statistics. Changes in this field will also update the value of Last Traded Quantity field. | |
| Last Traded Quantity | Boolean switch | - | O | False | | **#FS10014a\_S0632\_01700**  Option to select whether the trade would update the Last Traded Quantity statistics. Changes in this field will also update the value of Last Trade Price field. | |
| High Price | Boolean switch | - | O | False | | **#FS10014a\_S0632\_01800**  Option to select whether the trade would update the High Price statistics | |
| Low Price | Boolean switch | - | O | False | | **#FS10014a\_S0632\_01900**  Option to select whether the trade would update the Low Price statistics | |
| Open Price | Boolean switch | - | O | False | | **#FS10014a\_S0632\_02000**  Option to select whether the trade would update the Last Trade Price statistics | |
| Volume | Boolean switch | - | O | False | | **#FS10014a\_S0632\_02100**  Option to select whether the trade would update the Last Trade Price statistics | |

**Validity**

**#FS10014a\_S0632\_02200**

TBC

**ToolTips**

**#FS10014a\_S0632\_02300**

Tooltips can be defined on input fields:

| Column | Tooltips |
| --- | --- |
| Instrument ID | Specifies the instrument for which the order should be entered. To select other instruments, start typing the Id and select the instrument in the drop-down. |
| Price | To increase or decrease the price, use arrow up/down or click the arrows to the right of the Price field. |
| Quantity | Specifies the total number of contracts. Increase or decrease the quantity by using arrow up/down on the keyboard or by clicking the arrows to the right of the Quantity field. |
| **Buy Side Attributes** | | |
| Comp ID | Specifies the buy side Comp ID |
| Trader ID | Specifies the buy side Trader ID |
| Customer | Specifies the customer account to which the buyer belongs. |
| Position Effect | Specifies the buy side Position Effect |
| Customer Information | Specifies any arbitrary information concerning the order. Any information entered is of no logical importance and will not be interpreted in the system. |
| BCAN | The BCAN attribute is a pass-through attribute. It is used to identify the order's originator for market surveillance purposes. |
| **Sell Side Attributes** | | |
| Comp ID | Specifies the sell side Comp ID |
| Trader ID | Specifies the sell side Trader ID |
| Customer | Specifies the customer account to which the seller belongs. |
| Position Effect | Specifies the sell side Position Effect |
| Customer Information | Specifies any arbitrary information concerning the order. Any information entered is of no logical importance and will not be interpreted in the system. |
| BCAN | The BCAN attribute is a pass-through attribute. It is used to identify the order's originator for market surveillance purposes. |
| **Update Statistics** | | |
| Last Trade Price | Select whether the trade would update the Last Trade Price statistics |
| Last Traded Quantity | Select whether the trade would update the Last Traded Quantity statistics |
| High Price | Select whether the trade would update the High Price statistics |
| Low Price | Select whether the trade would update the Low Price statistics |
| Open Price | Select whether the trade would update the Last Trade Price statistics |
| Volume | Select whether the trade would update the Last Trade Price statistics |

**Read / Write Permission Behaviour**

**#FS10014a\_S0632\_02400**

| Permission | Behavior |
| --- | --- |
| Read | User can open the window but not able to submit new Exchange On-Behalf Trades. |
| Write | User with write permission can fill in and submit new Exchange On-Behalf Trades. |

**Action**

1. **Submit**

**#FS10014a\_S0632\_02500**

User with write permission can fill in the Exchange On-Behalf Trade form and submit a new Trade. The trade would then be submitted to Clearing and Market Data for processing.

**Validation**

**#FS10014a\_S0632\_02600**

TBC

**User Notification**

**#FS10014a\_S0632\_02700**

* Success if trade is entered successfully
* Error Notification if trade is rejected

# Appendix

## Irrelevant items #FS10014a\_S0700\_00100

### Change Order

**Order Priority change when Change Order**

The following changes can be made without losing order priority:
# BRD\_DT\_0049\_030\_06000

1. Reduce quantity.

# BRD\_DT\_0049\_030\_06100

1. Change the validity time. (between Day, GTC, GTD)

# BRD\_DT\_0049\_030\_06200

1. Modification of client account field. (source from ex\_client\_s OAPI field)

# BRD\_DT\_0049\_030\_06300

1. Modification of LEI field.

# BRD\_DT\_0049\_030\_06400

1. Modification of customer information field. (source from customer\_info\_s OAPI field)

# BRD\_DT\_0049\_030\_06500

1. Modification of give up member field.

# BRD\_DT\_0049\_030\_06600

1. Modification of give up account information field.

# BRD\_DT\_0049\_030\_06700

The following changes can be made losing order priority:

# BRD\_DT\_0049\_030\_06800

1. Increase quantity.

# BRD\_DT\_0049\_030\_06900

1. Change price.

# BRD\_DT\_0049\_030\_07000

1. Change SMP token field.

# BRD\_DT\_0049\_030\_07100

**For TMC Order**

Users cannot change the instrument series of each leg, their relative ratios, as well as buy or sell position of each leg. **#** BRD\_DT\_0049\_030\_10700

### Tailor-Made Combination

# BRD\_DT\_0049\_030\_10900 TMC cannot be executed against outright series and unlike standard combinations, # BRD\_DT\_0049\_030\_11000 there is no bait order generation for TMC. # BRD\_DT\_0049\_030\_11100 Standard combinations and capital adjusted series cannot be defined as legs, and contract size of each leg must be identical for any TMC.

### Trade History

**#** BRD\_DT\_0049\_030\_12900 Currently trade history is sourced from BD6, which covers the post trade activities. After decoupling in ODP, the trade history will NOT show the post trade activities (subject to discussion on decommission of BD6).

### Enter Trade Report – Block Trades

**For External**

Currently we support following trade type for the block trades via Enter Trade Report window.

* # BRD\_DT\_0049\_030\_14300 T1 Internal Trade Report

To facilitate single leg Block Trades within one company.

* # BRD\_DT\_0049\_030\_14400 T2 Combo Trade Report

To facilitate multiple legs Block Trades within one company.

* # BRD\_DT\_0049\_030\_14500 T4 Interbank Trade Report

To facilitate single leg Block Trades within one company or between two companies.

**#** BRD\_DT\_0049\_030\_14900 Above is the current block trade behaviour, for any enhancement on block trade, please refer to BRD “ODP - NewFunctionRequest – Block Trade Facility”.

**#** BRD\_DT\_0049\_030\_15000 **For Internal**

It is the same as external version, on top of this, there are trade type T3, 102, 101, Z200, 103 available which could be defined via PD for relevant internal user.

**#** BRD\_DT\_0049\_030\_15100 Note, internal version now is still used in daily operation to insert some deal. E.g. the trade type = Z200 with the purpose to modify / update the Dynamic Reference Price Limit or the VCM Ref.Price.

### Pending Trade Report

**#** BRD\_DT\_0049\_030\_15200 Unmatched T4 trade reports are treated as rest of day orders and are displayed in the Pending Trade Reports window.

**#** BRD\_DT\_0049\_030\_15400 Note that cancellation can only be done by the party initiating the T4 block trade.
