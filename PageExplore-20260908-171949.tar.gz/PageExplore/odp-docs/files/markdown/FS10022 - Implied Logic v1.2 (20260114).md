TITLE:

**FUNCTIONAL SPECIFICATION**

***ODP-T FS10022 – Implied Logic***

AUTHOR: *IT / Markets Systems* DATE: 14 Jan 2026

LAST REVIEW: *Derivatives Trading Business Operations* DATE: *28 Feb 2025*

**CONTENTS**

[1. Document Control 4](#_Toc219729467)

[1.1. Change History 4](#_Toc219729468)

[1.2. Document Cross-referenced 4](#_Toc219729469)

[1.3. Abbreviation 4](#_Toc219729470)

[2. Introduction 5](#_Toc219729471)

[3. Assumptions 5](#_Toc219729472)

[4. Implied Concept 5](#_Toc219729473)

[4.1. Implied Direction 5](#_Toc219729474)

[4.2. Parent Orders 6](#_Toc219729475)

[4.3. Implied Price 6](#_Toc219729476)

[4.4. Implied Quantity 6](#_Toc219729477)

[4.5. Eligible Parent 7](#_Toc219729478)

[5. Implies Aggregation 7](#_Toc219729479)

[6. Implied Execution 7](#_Toc219729480)

[6.1. Execution Sequence 7](#_Toc219729481)

[6.2. Aggressor Indicator 8](#_Toc219729482)

[6.3. Trade Price 8](#_Toc219729483)

[6.4. Price Improvements 8](#_Toc219729484)

[6.5. Regeneration 8](#_Toc219729485)

[6.6. Fill or Kill 9](#_Toc219729486)

[7. Implied Processing 9](#_Toc219729487)

[7.1. Execution Phase 9](#_Toc219729488)

[7.2. Insertion Phase 9](#_Toc219729489)

[7.3. Generation Phase 10](#_Toc219729490)

[7.4. Triggering Phase 10](#_Toc219729491)

[8. Generation Sequence 10](#_Toc219729492)

[8.1. Update Aggregated Implies IN 11](#_Toc219729493)

[8.2. Update Aggregated Implies OUT 11](#_Toc219729494)

[9. Change of Trading State 12](#_Toc219729495)

[10. Additional Rules 12](#_Toc219729496)

[10.1. Implied Price Alignment 12](#_Toc219729497)

[10.2. Volatility Control Mechanism 14](#_Toc219729498)

[10.3. Market Maker Protection 15](#_Toc219729499)

[10.4. Dynamic Price Limit (DPL) 16](#_Toc219729500)

[11. Implied Trade Dissemination 16](#_Toc219729501)

[12. Configuration 16](#_Toc219729502)

[13. Examples 18](#_Toc219729503)

[13.1. Implied IN - Bid Order 18](#_Toc219729504)

[13.2. Implied IN - Ask Order 19](#_Toc219729505)

[13.3. Implied OUT to Leg 1 - Bid Order 19](#_Toc219729506)

[13.4. Implied OUT to Leg 1 - Ask Order 20](#_Toc219729507)

[13.5. Implied OUT to Leg 2 - Bid Order 20](#_Toc219729508)

[13.6. Implied OUT to Leg 2 - Ask Order 21](#_Toc219729509)

[13.7. Implied Quantity 22](#_Toc219729510)

[13.8. Eligible Parent 23](#_Toc219729511)

[13.9. Implies Aggregation 24](#_Toc219729512)

[13.10. Execution Sequence 25](#_Toc219729513)

[13.11. Price Improvements 26](#_Toc219729514)

[13.12. Regeneration 27](#_Toc219729515)

[13.13. Fill or Kill 28](#_Toc219729516)

[13.14. Implies Processing 29](#_Toc219729517)

[13.15. Implies Processing (Mass Quote) 33](#_Toc219729518)

[13.16. Change of Trading State 39](#_Toc219729519)

[13.17. Price Alignment for Aggregated Implied OUT 41](#_Toc219729520)

[13.18. No Price Alignment for Aggregated Implied IN 42](#_Toc219729521)

[13.19. Price Improvements for Aligned Implied OUT 43](#_Toc219729522)

[13.20. Parent’s Price Check 44](#_Toc219729523)

[13.21. Volatility Control Mechanism 45](#_Toc219729524)

[13.22. Changes on VCM Price Band 46](#_Toc219729525)

[13.23. Market Maker Protection 48](#_Toc219729526)

[13.24. Dynamic Price Limit 50](#_Toc219729527)

# Document Control

## Change History

|  |  |  |  |
| --- | --- | --- | --- |
| **Version**  **Number** | **Issue Date** | **Author** | **Abstract** |
| 1.0 | 11 Apr, 2024 | IT/Markets Systems | Initial Version |
| 1.1 | 29 Oct, 2024 | IT/Markets Systems | Updated according to lockdown section. |
| 1.1.1 | 27 Nov, 2024 | IT/Markets Systems | Updated section 1.2 Document Cross-referenced. |
| 1.1.2 | 10 Sep, 2025 | IT/Markets Systems | Updated sections 6, 7, 8, 10, 12 and 13. |

## Document Cross-referenced

|  |  |  |
| --- | --- | --- |
| **#** | **Document** | **Version** |
| 1 | FS10002 – Order Management | IT241122a |
| 2 | FS10003 – Orderbook and Execution Management | IT241122 |
| 3 | FS10004 – Price Supervision | IT241126a |
| 4 | FS10008 – Market Maker Protection | IT241119 |
| 5 | 0002 BRS Order Management | 2024 10 30 |
| 6 | 0003 BRS Order Book Execution Management | 2024 11 21 |
| 7 | 0004 BRS Market Integrity Safeguards | 2024 11 12 |
| 8 | 0005 BRS Trading Operations | 2024 11 22 |

## Abbreviation

|  |  |
| --- | --- |
| VCM | Volatility Control Mechanism |
| DPL | Dynamic Price Limit |
| MMP | Market Maker Protection |

# Introduction

#FS10022\_S0020\_00100

Implied trading is the ability to identify trading opportunities across order books which are linked via a combination (Combo) order book. Where there are orders for the legs of Combo or a combination of legs and Combo, matching engine can generate an implied order into the Combo order book or a leg order book of the Combo. An implied order is therefore a synthetic order generated into an order book from two orders linked via Combo order book.

Implied functionality can be used to provide accurate price (discovery) and greater trading opportunities in order books with low liquidity / activity by leveraging off trading activity of more liquid / active order books.

# Assumptions

#FS10022\_S0030\_00100

Implied generation only be considered under below conditions:

* The Combo must have 2 legs with 1:1 ratio, and tick size for all legs must be same as Combo. Moreover, Combo and all legs must be within the same matching engine partition. If any Combo violated the assumption, implied generation for that Combo will be automatically disabled by the matching engine.
* Only limit-order and quote (i.e. not iceberg nor stop order nor implied order) can be used for implied generation.
* The incoming order is resting orders on entry (e.g., not FOK nor FAK order).

# Implied Concept

#FS10022\_S0040\_00100

Implied orders are the synthetic orders generated according to the specific rules which define the order. The rules cover:

* [Implied Direction](#_Implied_Direction)
* [Parent Orders](#_Parent_Orders)
* [Implied Price](#_Implied_Price)
* [Implied Quantity](#_Implied_Quantity)
* [Eligible Parent](#_Eligible_Parent)

## Implied Direction

#FS10022\_S0040\_00200

There are 2 implied directions, one is Implied IN, another is Implied OUT.

Implied IN is calculated by matching engine for a Combo order book based upon leg orders in the leg order books of this Combo. ([Example 13.1](#_Implied_IN_-))

Implied OUT is a Combo order combined with a relevant one of its legs and calculated for another leg order book. ([Example 13.3](#_Implied_OUT_to))

## Parent Orders

#FS10022\_S0040\_00300

Parent orders are used for implied price and quantity calculation. When an implied order is generated, its 2 relevant explicit orders which are the implied order based upon are assigned as parent orders according to below rules:

* **Oldest Parent Order**: The explicit order with the earliest timestamp is assigned as Oldest Parent Order.
* **Youngest Parent Order**: The explicit order with the latest timestamp is assigned as Youngest Parent Order.

For Implied IN, one of the parent orders is the leg order from leg 1 order book, whilst another is the leg order from leg 2 order book.

For Implied OUT, one of the parent orders must be a Combo order, whilst another can be the leg order from leg 1 or leg 2 order book.

## Implied Price

#FS10022\_S0040\_00400

The implied price for an implied order is deduced from the price of its parent orders.

For Implied IN order which is inserted into Combo order book:

* **Implied Bid Price** = Leg 1 Bid – Leg 2 Ask ([Example 13.1](#_Implied_IN_-))
* **Implied Ask Price** = Leg 1 Ask – Leg 2 Bid ([Example 13.2](#_Implied_IN_-_1))

For Implied OUT order which is inserted into leg 1 order book:

* **Implied Bid Price** = Leg 2 Bid + Combo Bid ([Example 13.3](#_Implied_OUT_to))
* **Implied Ask Price** = Leg 2 Ask + Combo Ask ([Example 13.4](#_Implied_OUT_to_1))

For Implied OUT order which is inserted into leg 2 order book:

* **Implied Bid Price** = Leg 1 Bid – Combo Ask ([Example 13.5](#_Implied_OUT_to_2))
* **Implied Ask Price** = Leg 1 Ask – Combo Bid ([Example 13.6](#_Implied_OUT_to_3))

## Implied Quantity

#FS10022\_S0040\_00500

The implied quantity of an implied order is the smallest unused quantity of two parent orders.

The unused quantity means the quantity of a parent order which is not yet used for implied order generation in same side of order book.

For both Implied IN and OUT order:

* **Implied Quantity** = MIN (Unused quantity of a parent order, Unused quantity of another parent order) ([Example 13.7](#_Implied_Quantity_1))

## Eligible Parent

#FS10022\_S0040\_00600

Only the BBO explicit orders in both Combo and leg order book can be considered as parent of an implied order. Implies order cannot be a parent of implies. ([Example 13.8](#_Eligible_Parent_1))

# Implies Aggregation

#FS10022\_S0050\_00100

"Aggregated Implies" is the term that describes the overview of a group of implied orders.

The Aggregated Implies is not an order and never be inserted into an order book. It is just data which is attached to each price level in the order book. It only contains implied price and Aggregated Quantity of all implied orders that share the same implied price within the order book.

When an implied order is generated/deleted, the matching engine does not insert/remove it into the order book. Instead, it updates the Aggregated Quantity of the Aggregated Implies with the same implied price as the implied order, and then disseminates the Aggregated Quantity to market. Therefore, the order book no longer keeps track of any individual implied orders. ([Example 13.9](#_Implies_Aggregation_1))

# Implied Execution

#FS10022\_S0060\_00101

As Aggregated Implies is a collection of implied orders, some additional considerations are required in following areas during execution:

* [Execution Sequence](#_Execution_Sequence)
* [Aggressor Indicator](#_Aggressor_Indicator)
* [Trade Price](#_Trade_Price)
* [Price Improvements](#_Price_Improvements)
* [Regeneration](#_Regeneration)
* [Fill or Kill](#_Fill_or_Kill)

## Execution Sequence

#FS10022\_S0060\_00201

The matching priority of Aggregated Implies is always lower than explicit orders in same price level.

Whenever an Aggregated Implies is crossed with a resting order, the matching engine goes through all Combo that are linked to the crossed order book according to the expiration date of the other leg, starting from earliest to farthest.

For each Combo, the matching engine performs below actions:

1. Generate an implied order based on the best order in parent order books.
2. Execute the resting order, implied order and both parent orders.
3. Repeat steps 1 and 2 until no further matching opportunity, or no more implied order can be generated, or implied price is worse than the price of Aggregated Implies. ([Example 13.10](#_Execution_Sequence_2))

Please note that the implied order generated in step 1 is only for execution purposes, it is never inserted into the order book.

## Aggressor Indicator

#FS10022\_S0060\_00301

When an implied order is crossed in an order book, the aggressor indicator of the implied orders is set to 'False'. This means it is not possible to determine which side initiated the trade.

Aggressor indicator for explicit order, please refer to section “Aggressive and Passive Order” in FS “Orderbook and Execution Management”

## Trade Price

#FS10022\_S0060\_00401

When an Implied OUT order is crossed in the leg order book, the timestamp of its youngest parent is compared to the timestamp of the resting order. The trade price is determined by the price of the order that has the older timestamp.

When an Implied IN order is crossed in Combo order book, the trade price always is the price of implied IN order.

## Price Improvements

#FS10022\_S0060\_00501

When the trade price is different to the price of the matched implied order, the price improvement is assigned to its Combo parent order. ([Example 13.11](#_Price_Improvment))

## Regeneration

#FS10022\_S0060\_00601

Whenever an Aggregated Implies is executed through a Combo, the matching engine immediately calculates the implied price and quantity for that Combo and refreshes the quantity to relevant Aggregated Implies according to the implied price and then resume the execution process. ([Example 13.12](#_Regeneration_2))

## Fill or Kill

#FS10022\_S0060\_00700

Regeneration ([Section 6.5)](#_Regeneration) is not applicable to Fill or Kill order, only the current Aggregated Quantity is used for Fill or Kill matching. ([Example 13.13](#_Fill_or_Kill_1))

# Implied Processing

#FS10022\_S0070\_00101

When an incoming order (excluding Mass Quote) action in an order book which is a constituent of enabled Combo(s) has passed all incoming order validations, it will be subject to below phases: ([Example 13.14](#_Generation_Phase_1))

1. [Execution Phase](#_Execution_Phase)
2. [Insertion Phase](#_Insertion_Phase)
3. [Generation Phase](#_Generation_Phase)
4. [Triggering Phase](#_Triggering_Phase)

When the incoming order is a Mass Quote, the implied processing will be subject to below phases to handle 2 phases cancel-add processing that is described in FS “ODP-T FS – Order Management”): ([Example 13.15](#_Implies_Processing_(Mass))

Phase 1 – Cancelling Existing Quotes

1. [Insertion Phase](#_Insertion_Phase)
2. [Generation Phase](#_Generation_Phase)
3. [Triggering Phase](#_Triggering_Phase)

Phase 2 - Adding New Quotes

For each quote side:

1. [Execution Phase](#_Execution_Phase)
2. [Insertion Phase](#_Insertion_Phase)
3. [Generation Phase](#_Generation_Phase)
4. [Triggering Phase](#_Triggering_Phase)

## Execution Phase

#FS10022\_S0070\_00201

In Execution Phase, the matching engine match the incoming order as much as possible with resting explicit order according to “ODP-T FS – Orderbook and Execution Management”, or with resting Aggregated Implies according to Implied Execution ([Section 6](#_Implied_Execution)).

Execution Phase is a recursive process until there are no more matches that can be done.

## Insertion Phase

#FS10022\_S0070\_00301

The order book is updated according to the incoming order in the Insertion Phase. For example, if the incoming order is a new order and it is not fully executed in Execution Phase, it is inserted into the order book. If the order is a cancellation request, the corresponding order is removed from the order book. After the order book changes, the Affected Order Book List will be updated.

In the case that incoming action is a bulk delete or cancel existing quote action during “Phase 1 – Cancelling Existing Quotes”, it is processed according to FS “ODP-T FS – Order Management”. The Affected Order Book List will be updated for each corresponding order book that has been processed.

### Affected Order Book List

#FS10022\_S0070\_00400

The order book of the incoming order and any other order books that are linked to it by Combo are collected in a to Affected Order Book List. This list will be applied in Generation Phase.

## Generation Phase

#FS10022\_S0070\_00501

In this phase, the matching engine will update Aggregated Implies for all order books in the Affected Order Book List according to the Generation Sequence ([Section 8](#_Generation_Sequence)).The Generation Phase is a repetitive process that continues to iterate through the Affected Order Book List until there are no more possible matches on an iteration. After Generation Phase is completed, the system proceeds to the Triggering Phase ([Section 7.4](#_Triggering_Phase)).

## Triggering Phase

#FS10022\_S0070\_00600

Like MMP protection and Dynamic Price Limit, some functionalities that might affect orders and price are performed in this phase. Please refer to Additional Rules ([Section 10](#_Additional_Rules)) for details of each rule.

Depending on the requirements of individual additional rules, the Affected Order Book List can include more order books and an extra round of Generation Phase may be required.

The extra round of Generation Phase is started at the end of Triggering Phase (i.e. all additional rules are processed for each affected order book). When there are multiple rules requested an extra round of Generation Phase, only one Generation Phase is commenced.

# Generation Sequence

#FS10022\_S0080\_00100

Aggregated Implies may be required to update on multiple order books due to a matching engine instruction (e.g. Trading state is changed to open trading state, or during Generation Phase of an incoming order), when there are more than one order books are pending for update, the matching engine uses the following procedure to update Aggregated Implies:

1. [Update Aggregated Implies IN](#_Update_Aggregated_Implies)
2. [Update Aggregated Implies OUT](#_Update_Aggregated_Implies_1)

## Update Aggregated Implies IN

#FS10022\_S0080\_00201

Ascending sort all Combo order books in Affected Order Book List in following sequence:

* Market Priority
* Underlying Name
* Combo Group Name
* Expiration Date of Leg 2 (Near Leg, starting from earliest to farthest)
* Expiration Date of Leg 1 (Far Leg, starting from earliest to farthest)
* Combo Name

Aggregated Implies IN are updated for each Combo order book according to the above sorted sequence.

Within a Combo order book, Aggregated Implies on the Bid side are updated prior to the Ask side.

Once all Aggregated implies are updated for both Bid and Ask side of a Combo order book, a trade execution check is performed immediately, and then Implied Execution ([Section 6](#_Implied_Execution)) is carried out if trade condition is met. The trade execution check is a recursive process until there are no more matches that can be done.

## Update Aggregated Implies OUT

#FS10022\_S0080\_00301

Ascending sort all single (leg) order books in Affected Order Book List in following sequence:

* Market Priority
* Underlying Name
* Instrument Group Name
* Expiration Date (Starting from earliest to farthest)
* Strike Price (Starting from lowest to highest)
* Instrument Name

Aggregated Implies OUT are updated for each single order book according to the above sorted sequence one by one.

Within a single order book, Aggregated Implies on the Bid side are updated prior to the Ask side.

Foe each side (i.e. Bid and Ask), Aggregated Implies are updated based on the implied price and quantity that are calculated for each Combo which is linked to this single order book, in order of expiration date of the other leg (start from earliest to farthest) and then the instrument name of the other leg.

Once all Aggregated implied are updated for both Bid and Ask side of a single order book, a trade execution check is performed immediately, and then Implied Execution ([Section 6](#_Implied_Execution)) is carried out if trade condition is met. Any executed order books that are not already included in the Affected Order Book List are added into the list for the subsequent iteration of implies generation. The trade execution check and implies regeneration is a recursive process until there are no more matches that can be done within this order book.

# Change of Trading State

#FS10022\_S0090\_00100

Implied logic is only valid during the open trading state. While Combo and leg orders can remain in their respective order book outside an open trading state, there are no Aggregated Implies that can be in the order book in this situation.

As a new state is attached at certain levels of product hierarchy, all order books below the hierarchy are added into Affected Order Book List.

Once the trading state of all involved order books are transited to new state, Generation Phase is commenced for Aggregated Implies update (Or removal if new state is not an open trading state). ([Example 13.16](#_ICmplies_Processing_(Mass))

# Additional Rules

#FS10022\_S0100\_00100

As there are various functionalities which are supported by ODP-T that impact order, price, and execution, such as Price Limit and Market Maker Protection etc., therefore some additional rules are required for implied logic to deal with those features.

Following features are applied to Execution and Generation Phase:

* [Implied Price Alignment](#_Implied_Price_Alignment)
* [Volatility Control Mechanism (VCM)](#_Volatility_Control_Mechanism)

Features that are applied to Triggering Phase are performed as below sequence:

* [Market Maker Protection (MMP)](#_Market_Maker_Protection)
* [Dynamic Price Limit (DPL)](#_Dynamic_Price_Limit_1)

## Implied Price Alignment

#FS10022\_S0100\_00200

As an implied price is calculated from two orders from two different order books, implied price maybe far exceeded the normal price of the order book and resulting conflict with order book’s price bands (e.g., Tick Table, Static Price Limit, Dynamic Price Limit or VCM).

To prevent this situation, implied price band and price alignment are introduced.

### Implied Price Band

#FS10022\_S0100\_00300

If more than one price band is in place (e.g., Price Tick + Dynamic Price Limit + VCM), it takes the narrowest spread as implied price band. The following formulas are used to deduce the implied price band.

* **Implied Lower Limit** = MAX (Lower Limit 1, Lower Limit 2, …, Lower Limit N)
* **Implied Upper Limit** = MIN (Upper Limit 1, Upper Limit 2, …, Upper Limit N)

### Price Alignment for Aggregated Implied OUT

#FS10022\_S0100\_00400

Whenever the price of an Aggregated Implied OUT exceeds the implied price band, matching engine aligns the implied price to the band limit if the implied price is a better than the band limit, otherwise (i.e., the implied price is a worse than band limit) the Aggregated Implies will not be generated. ([Example 13.17](#_Change_of_Trading_1))

|  |  |  |
| --- | --- | --- |
| **Implied Side** | **Implied Price** | **Action** |
| Buy | > Upper limit | Align implied price to upper limit |
| Buy | < Lower limit | Aggregated Implies will not be generated |
| Sell | > Upper limit | Aggregated Implies will not be generated |
| Sell | < Lower limit | Align implied price to lower limit |

Please note that price alignment is only applicable to Implied OUT, therefore the implied price of an Implied IN can exceed the price band of Combo order book. ([Example 13.18](#_No_Price_Alignment))

### Price Improvements for Aligned Implied OUT

#FS10022\_S0100\_00500

Since implied price is aligned to a worse price, that means the implied price has a worse price than what would be possible if no price band were used.

When an Implied OUT with price alignment is matched, its parent Combo order takes all price improvements from this situation; thus, the trade price of the parent Combo order is better than the explicit price. ([Example 13.19](#_Price_Improvement_for_1))

### Parent’s Price Check

#FS10022\_S0100\_00600

When the parent’s price exceeds the implied price band of the parent’s order book, the implied quantity will not be counted into corresponding Aggregated Implies, even though the implied price would fit within the implied price band for order book of Aggregated Implies.

If the implied quantity is excluded from an Aggregated Implies due to this Parent’s Price Check, the corresponding Combo will not be considered for implied execution, therefore, that Combo will be removed from Implied Execution Sequence. ([Example13.20](#_Parent’s_Price_Check_1))

## Volatility Control Mechanism

#FS10022\_S0100\_00701

Given Price Alignment for Aggregated Implied OUT ([Section 10.1.2](#_Price_Alignment_for)) and Parent's Price Check ([Section 10.1.4](#_Parent’s_Price_Check)), VCM can be triggered by implies matching only when below conditions are satisfied:

* An Aggregated Implies OUT is generated into an order book.
* The passive order is an explicit order with price outside VCM band.
* The potential trade price is outside VCM band.

When VCM is triggered by implies matching. The matching engine perform below actions: ([Example 13.21](#_Dynamic_Price_Limit_2))

* Immediately cancel existing explicit bid and ask orders resided in order book with order price violating VCM price band according to FS “ODP-T FS – Price Supervision”.
* Match the newly generated Aggregated Implied OUT with remaining resting explicit orders and Aggregated Implied OUT (Implied price must be within VCM band due to price alignment rules) on resting side until no more matches can be done.
* Resume the Generation Phase.

### Changes on VCM Price Band

#FS10022\_S0100\_00801

Whenever the VCM price band is changed (e.g. due to delayed VCM reference price) on an order book, implied price band is also updated accordingly. The order book and any other order books that are linked to it by Combo are added in Affected Order Book List. Then Generation Phase is carried out to update Aggregated Implies. ([Example 13.22](#_Changes_on_Implied_1))

### All Possible Cases

#FS10022\_S0100\_00901

Below table summarized all VCM cases that related to Implied matching. The only case that can trigger VCM is highlighted by green. Other cases are prevented by Price Alignment for Aggregated Implied OUT ([Section 10.1.2](#_Price_Alignment_for)) or Parent’s Price Check ([Section 10.1.4](#_Parent’s_Price_Check))

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
| **Order Type of New Order** | **Order Type of Resting Order** | **Order Book to Trigger VCM** | **Can VCM be Triggered?** | **Remark** |
| Explicit Outright Order | Implied OUT | Implied Order Book | No, Prevented | Implied Price is aligned to VCM band#1 |
| Parent Leg | No, Prevented | Implied OUT is not generated#2 |
| Parent Combo | Not Support | VCM is not supported on Combo |
| Implied OUT | Explicit Outright Order | Implied Order Book | Yes | Already mentioned in [section 10.3](#_Volatility_Control_Mechanism) |
| Parent Leg | No, Prevented | Implied OUT is not generated#2 |
| Parent Combo | Not Support | VCM is not supported on Combo |
| Implied OUT | Implied OUT | Implied Order Book | No, Prevented | Implied Price is aligned to VCM band#1 |
| Parent Leg | No, Prevented | Implied OUT is not generated#2 |
| Parent Combo | Not Support | VCM is not supported on Combo |
| Explicit Combo Order | Explicit Combo Order | Combo Order Book | Not Support | VCM is not supported on Combo |
| Explicit Combo Order | Implied IN | Combo Order Book | Not Support | VCM is not supported on Combo |
| Parent Leg | No, Prevented | Implied IN is not generated#2 |
| Implied IN | Explicit Combo Order | Combo Order Book | Not Support | VCN is not supported on Combo |
| Parent Leg | No, Prevented | Implied IN is not generated#2 |

#1: According to Price Alignment for Aggregated Implied OUT ([Section 10.1.2](#_Price_Alignment_for)), the price of resting Implied OUT must be aligned to the implied band (i.e. the VCM band), therefore VCM cannot be triggered in implied order book because the trade price is at the band.

#2: According to Parent’s Price Check ([Section 10.1.4](#_Parent’s_Price_Check)), the resting implied OUT never be generated due to its parent price is outside the implied band of parent’s order book. Therefore VCM is never triggered in parent leg order book as this is an invalid case.

## Market Maker Protection

#FS10022\_S0100\_01000

MMP can be triggered in Execution Phase or Generation Phase for an order book with implied logic.

For MMP that is triggered in Execution Phase, the processing flow is documented in FS “ODP-T FS - Market Maker Protection”.

For MMP that is triggered during Generation Phase, the phase continuously runs without interruption and the protection response is performed for all triggered participant in Triggering Phase. ([Example 13.23](#_Volatility_Control_Mechanism_1))

When the protection response is done, all the order books that are involved and any other order books that have a Combo connection to them are added to a list of Affected Order Books. Then, an extra Generation Phase will be commenced at the end of Triggering Phase to update Aggregated Implies.

Please refer to FS “ODP-T FS - Market Maker Protection” for details of protection response.

## Dynamic Price Limit (DPL)

#FS10022\_S0100\_01101

Whenever a match on an orderbook, the dynamic price limit (i.e. dynamic reference price and the price band) is adjusted according to FS “ODP-T FS - Price Supervision”.

### Changes on DPL Price Band

#FS10022\_S0100\_01201

For order book with implied logic, even the DPL of the order book is adjusted due to matches, the implied price band remains unchanged until Triggering Phase. ([Example 13.24](#_Dynamic_Price_Limit))

The matching engine updates the implied price band for all matched order books according to the Generation Sequence ([Section 8](#_Generation_Sequence)).

Once the implied price band is changed for a matched order book, that order book and any other order books that are linked to it by Combo are added in Affected Order Book List and then an extra Generation Phase will commence at the end of the Triggering Phase to update Aggregated Implies.

Please refer to FS “ODP-T FS - Price Supervision” for details calculation of dynamic reference price and price band.

# Implied Trade Dissemination

#FS10022\_S0110\_00100

Please refer to section “Trade Dissemination” in “ODP-T FS – Orderbook and Execution Management”

# Configuration

#FS10022\_S0120\_00101

Implied functionality requires a lot of computing power, there is the potential for excessive system processing requirements. It is therefore imperative that the following configurations of implied functionality be controlled by Market Operational users.

* Implied Generation
* Implied IN Dissemination

### Implied Generation

#FS10022\_S0120\_00200

Implied generation can be configurated on Combo class level. The following options are available:

* Enable (Next Day Effective)
* Disable (Immediate / Schedule / Next Day Effective)

### Implied IN Dissemination

#FS10022\_S0120\_00300

Implied IN Dissemination is a configuration to control whether disseminate Implied IN information via Market Data. It can be configurated on system level. The following options are available:

* Enable (Next Day Effective)
* Disable (Next Day Effective)

# Examples

Following are the examples to illustrate different scenarios and combinations. It should be noted that some of the configurations (e.g., tick size) may not actually be realistic; they are used here solely for presentation.

* Incoming order is depicted in **red bold**.
* Implied orders are (re)generated according to incoming order are depicted in *red italics*.
* Resting implied orders are depicted in *brown italics*.
* Resting explicit orders are depicted in black.

## [Implied IN - Bid Order](#_Implied_Price)

Following orders are submitted, in time sequence (T#) shown:

* 1. Bid U2 (Leg 1) 10@10000.
  2. Ask Q2 (Leg 2) 3@9995.
  3. An implied bid order is generated in Q2/U2 for 3@5 (Leg 1 Bid – Leg 2 Ask)

![](data:image/png;base64...)

## [Implied IN - Ask Order](#_Implied_Price)

Following orders are submitted, in time sequence (T#) shown:

* 1. Ask U2 (Leg 1) 10@10000.
  2. Bid Q2 (Leg 2) 3@9995.
  3. An implied ask order is generated in Q2/U2 for 3@5 (Leg 1 Ask – Leg 2 Bid)

![](data:image/png;base64...)

## [Implied OUT to Leg 1 - Bid Order](#_Implied_Price)

Following orders are submitted, in time sequence (T#) shown:

1. Bid U2 (Leg 2) 10@10000.
2. Bid U2/Z2 3@5.
   1. An implied bid order is generated in Z2 (Leg 1) for 3@10005 (Leg 2 Bid + Combo Bid)

![](data:image/png;base64...)

## [Implied OUT to Leg 1 - Ask Order](#_Implied_Price)

Following orders are submitted, in time sequence (T#) shown:

1. Ask U2 (Leg 2) 10@10000.
2. Ask U2/Z2 3@5.
   1. An implied ask order is generated in Z2 (Leg 1) for 3 lots at 10005 (Leg 2 Ask + Combo Ask)

![](data:image/png;base64...)

## [Implied OUT to Leg 2 - Bid Order](#_Implied_Price)

Following orders are submitted, in time sequence (T#) shown:

1. Bid Z2 (Leg 1) 10@10000.
2. Ask U2/Z2 3@5.
   1. An implied bid order is generated in U2 (Leg 2) for 3@9995 (Leg 1 Bid – Combo Ask)

![](data:image/png;base64...)

## [Implied OUT to Leg 2 - Ask Order](#_Implied_Price)

Following orders are submitted, in time sequence (T#) shown:

1. Ask Z2 (Leg 1) 10@10000.
2. Bid U2/Z2 3@5.
   1. An implied ask order is generated in U2 (Leg 2) for 3@9995 (Leg 1 Ask – Combo Bid)

![](data:image/png;base64...)

## [Implied Quantity](#_Implied_Quantity)

Following orders are submitted, in time sequence (T#) shown:

1. Bid Z2 3@10000.
2. Ask Q2/Z2 2@5.
   1. Implied bid order is generated in Q2 for 2@9995 (MIN (unused quantity of T1 = 3, unused quantity of T2 = 2)).
   * The unused quantity of parent order T1 via Combo Q2/Z2 to Q2 bid side become 3 – 2 = 1 now.
3. Ask Q2/Z2 5@5.
   1. Implied bid order is generated in Q2 for 1@9995 (MIN (unused quantity of T1 = 1, unused quantity T3 = 5)).
   * The unused quantity of parent order T1 via Combo Q2/Z2 to Q2 bid side is 0 now.
4. Ask U2/Z2 3@0.
   1. Implied bid order is generated in U2 for 3@10000 (MIN (unused quantity of T1 = 3, unused quantity T4 = 3)).
   * The unused quantity of parent order T1 via Combo U2/Z2 to U2 bid side is 0 now.
5. Ask U2/Z2 1@0.
   * No implied bid order can be generated in U2 due to the unused quantity of T1 is 0.

The implied quantity of implied order which is generated in 2.1 and 3.1 is shared same unused quantity from T1 as they are through same Combo, whilst the implied order which is generated in 4.1 is not shared with 2.1 and 3.1 as they are through different Combo.

![](data:image/png;base64...)

(T3.2 > T3.1)

## [Eligible Parent](#_Eligible_Parent)

Following orders are submitted, in time sequence (T#) shown:

1. Ask Z2 for 2@10000.
2. Ask Z2 for 4@10000.
3. Bid U2/Z2 for 3@5.
   1. Implied OUT is generated in U2 for 2@9995 (T1 + T3)
   2. Implied OUT is generated in U2 for 1@9995 (T2 + T3)
4. Bid U2/Z2 2@5.
   1. Implied OUT is generated in U2 for 2@9995 (T2 + T4)
5. Bid U2/Z2 2@4.
   * No Implied OUT can be generated in U2, as T5 is not the best bid price. Only BBO Combo orders are considered as parent order.
6. Ask Q2/Z2 1@0 and Ask Q2 1@10000 (not shown in the picture)
   1. Implied OUT is generated in Z2 for 1@10000.
   * No Implied OUT can be generated in U2, as T6.1 is not an explicit order. Only BBO explicit orders are considered as parent order.
7. Ask Z2 1@10001.
   * No Implied OUT can be generated in U2, as T7 is not the best ask price. Only BBO explicit orders are considered as parent order.

![](data:image/png;base64...)

## [Implies Aggregation](#_Implies_Aggregation)

Orders are entered as depicted using the timestamp – T#:

1. At T6, Bid Q2 for 3@10000
   1. At T6.1, an Aggregated Implied Bid 3@10000 is updated in H3.
2. At T7, Bid Z2 for 5@9998
   1. At T7.1, another Aggregated Implied Bid 5@9998 is updated in H3.
3. At T8, Bid U2 for 4@10000
   1. At T8.1, Aggregated Implied Bid 3@10000 in H3 is updated to 7@10000.

![](data:image/png;base64...)

## [Execution Sequence](#_Execution_Sequence)

Orders are entered as depicted using the timestamp – T#:

1. At T8, Ask H3 for 9@10000.
   1. Matched with T6 1@10000 (explicit order is always matched prior to Aggregated Implies).
   2. Matched with T7 2@10000 (explicit order is always matched prior to Aggregated Implies).
   3. Crossed with Aggregated Implies 7@10000, expiration date of the other leg for Q2/H3 is earlier than U2/H3, so Q2/H3 is matched first.
   * Matched 1@10000 in H3, T1 1@5 in Q2/H3 and T3 1@9995 in Q2. (i.e. matched the Implied OUT T1 + T3)
   * Matched 2@10000 in H3, T1 2@5 in Q2/H3 and T5 2@9995 in Q2. (i.e. matched the Implied OUT T1 + T5)
     + All orders in parents’ best price level are exhausted. Start to match next Combo.
   * Matched 3@10000 in H3, T2 3@5 in U2/H3 and T4 3@9995 in U2. (i.e. matched the Implied OUT T2 + T4)
   * Incoming order T8 is exhausted.

![](data:image/png;base64...)

**After Execution:**

![](data:image/png;base64...)

## [Price Improvements](#_Price_Improvements)

Orders are entered as depicted using the timestamp – T#:

1. At T4, Ask Q2 for 1@9990.
   1. Add an Aggregated Implies Ask 1@9990 to H3 (Youngest Parent is T4).
   2. Matched with Aggregated Implies Bid 1@10000 (Youngest Parent is T3).
   3. Trade price is determined by compare youngest parent timestamp of Aggregated Implies Bid and Ask (i.e. T3 and T4).
   4. The trade price is 10000 (Follow the price of Aggregated Implies Bid because it’s youngest parent timestamp T3 is older than T4).
   5. As the trade price is different to the price of implied Ask, the price improvement is assigned to its Combo parent order (i.e. T1), and below matches are created:
   * 1@10000 in H3
   * 1@9990 in Q2
   * 1@10 in Q2/H3 (take all price improvements)
   * 1@10000 in U2
   * 1@0 in U2/H3

![](data:image/png;base64...)

## [Regeneration](#_Regeneration)

Orders are entered as depicted using the timestamp – T#:

1. At T11, Ask H3 for 9@9998.
   1. Matched with T8 1@10000 (explicit order is always matched prior to Aggregated Implies).
   2. Matched with T9 2@10000 (explicit order is always matched prior to Aggregated Implies).
   3. Crossed with Aggregated Implies 3@10000, expiration date of the other leg for Q2/H3 is earlier than U2/H3, so Q2/H3 is matched first.
   * Matched 1@10000 in H3, T1 1@5 in Q2/H3 and T4 1@9995 in Q2. (i.e. matched the Implied OUT T1 + T4)
     + All orders in parent’s (Q2/H3) best price level are exhausted.
     + Recalculated implied price and quantity for Q2/H3 is 1@9998.
     + Refresh the quantity of existing Aggregated Implies from 3@9998 to 4@9998 and start to match next Combo.
   * Matched 2@10000 in H3, T2 2@5 in U2/H3 and T5 2@9995 in U2. (i.e. matched the Implied OUT T2 + T5)
     + No Aggregated Implied can be recalculated for U2/H3.

![](data:image/png;base64...)

**After Regeneration, resume the execution process:**

* 1. Matched with T10 3@9999

![](data:image/png;base64...)

## [Fill or Kill](#_Fill_or_Kill)

Orders are entered as depicted using the timestamp – T#:

1. At T5, Ask H3 for 3@9999 with fill or kill flag.
   1. The order is rejected due to available quantity is 2 (1 from T4, 1 from Aggregated Implies)

![](data:image/png;base64...)

## [Implies Processing](#_Implied_Processing)

Orders are entered as depicted using the timestamp – T#:

1. **Incoming Action:**
   1. At T9, Ask H3 for 3@10000.
2. **Execution Phase:**
   1. Crossed with Aggregated Implies 2@10000, expiration date of the other leg for Q2/H3 is earlier than U2/H3, so Q2/H3 is matched first.
   * Matched 1@10000 in H3, T2 1@1 in Q2/H3 and T6 1@9999 in Q2. (i.e. matched the Implied OUT T2 + T6)
   * Matched 1@10000 in H3, T4 1@1 in U2/H3 and T8 2@9999 in U2. (i.e. matched the Implied OUT T4 + T8)

![](data:image/png;base64...)

1. **Insertion Phase:**
   1. Incoming order still has 1 quantity left, insert into order book.
   2. Put H3, Q2/H3, Q2, U2/H3, U2 into Affected Order Book List.

![](data:image/png;base64...)

1. **Generation Phase:**
   1. Update Aggregated Implies IN, generation sequence is Q2/H3 > U2/H3 (sort expiration date of leg 2 and then leg 1, start from earliest to farthest) ([Section 8.1.1](#_Update_Aggregated_Implies)).
      1. At T9.1, Aggregated Implied Ask 1@2 is updated in Q2/H3.
      2. All Aggregated Implies have been updated, perform execution check for Q2/H3.
      3. At T9.2, Aggregated Implied Ask 1@1 is updated in U2/H3.
      4. All Aggregated Implies have been updated, perform execution check for U2/H3.

![](data:image/png;base64...)

* 1. Update Aggregated Implies OUT, generation sequence is Q2 > U2 > H3 (sort to expiration date, start from earliest to farthest) ([Section 8.1.2](#_Update_Aggregated_Implies_1)).
     1. At T9.3, Aggregated Implied Ask 1@9999 is updated in Q2.
     2. All Aggregated Implies have been updated in Q2, perform execution check for Q2.

![](data:image/png;base64...)

* + 1. At T9.4, Aggregated Implied Bid 1@10000 is removed, and Bid 1@9999 is updated in U2 (Bid side is updated prior to ask side) ([Section 8.1.2 - Side](#Gen_Seq_Side)).
    2. At T9.5, Aggregated Implied Ask 1@10000 is updated in U2.
    3. All Aggregated Implies have been updated in U2, perform execution check for U2.

![](data:image/png;base64...)

* + 1. Two Combo are connected to H3, Implies for Q2/H3 is updated prior to U2/H3 (sort expiration date of the other leg) ([Section 8.1.2 - For each side](#Gen_Seq_Combo))
    2. At T9.6, Aggregated Implied Bid 1@9999 is updated in H3.

![](data:image/png;base64...)

* + 1. At T9.7, Aggregated Implied Bid 1@9999 is updated to 2@9999 in H3.
    2. All Aggregated Implies have been updated in H3, perform execution check for H3.

![](data:image/png;base64...)

* 1. All order books in the Affected Order Book List are updated and there is no match for this iteration. Generation Phase is completed.

1. **Triggering Phase**

5.1 No action in triggering phase in this example.

## [Implies Processing (Mass Quote)](#Gen_Phase_Mass_Quote)

Orders are entered as depicted using the timestamp – T#:

1. **At T5, input a mass quote with below items:**
   * Item 1: Bid Z2 for 1@20000
   * Item 2: Ask Z2 for 2@20001
   * Item 3: Amend Bid Z3 from 1@20002 to 2@20001
   * Item 4: Cancel Bid Z4 1@20000

![](data:image/png;base64...)

1. **Phase 1 - Cancel Existing Quote (Insertion Phase):**
   1. Cancel existing quote T3 1@20002 in Z3 and 1@20000 in Z4.
   * Implied orders in Bid Z2 and Bid Z7 are outdated due to parent order is cancelled.
   1. All involved order books and other order books that are linked to involved order books by Combo are added in a to Affected Order Book List.

Affected Order Book List is added in below sequence:

Z3, Z2/Z3, Z2, Z4, Z4/Z7, Z7

![](data:image/png;base64...)

1. **Phase 1 - Cancel Existing Quote (Generation Phase):**
   1. Update Aggregated Implies IN as below sequence:
      1. Z2/Z3, no actions can be done.
      2. Z4/Z7, no actions can be done.

* 1. Update Aggregated Implies OUT as below sequence:
     1. Z2 bid side, Aggregated Implied Bid 1@20001 (T4 + T1) is updated.
     2. All Aggregated Implies have been updated in Z2, performs execution check for Z2.
     3. Z3, no actions can be done.
     4. Z4, no actions can be done.
     5. Z7 bid side, Aggregated Implied Bid 1@20000 is removed.

* 1. All order books in the Affected Order Book List are updated and there is no match for this iteration. Generation Phase is completed.

![](data:image/png;base64...)

1. **Phase 1 - Cancel Existing Quote (Triggering Phase):**
   1. No action in triggering phase in this example. Phase 1 – Cancel Existing Quote is completed. Start Phase 2 – Adding New Quote.
2. **Phase 2 - Adding New Quote (1st quote side):**
   1. Process 1st quote side new Bid Z2 1@20000
   2. No Action in Execution Phase.
   3. At T5.1, add Bid 1@20000 to Z2 in Insertion Phase.
   4. No implied order can be generated in Generation Phase.
   5. No action in triggering phase for this quote side.

![](data:image/png;base64...)

1. **Phase 2 - Adding New Quote (2nd quote side)**
   1. Process 2nd quote side new Ask Z2 2@20001
   2. In Execution Phase, matched 1@20001 in Z2, T1 1@0 in Z2/Z3 and T4 1@20001 in Z3. (i.e. matched the Implied OUT T1 + T4).
   3. AT T5.2, add Bid 1@20000 to Z2 in Insertion Phase.

![](data:image/png;base64...)

* 1. AT T5.3, Aggregated Implied Ask 1@20001 is updated in Z3 in Generation Phase.
  2. No action in triggering phase for this quote side.

![](data:image/png;base64...)

1. **Phase 2 - Adding New Quote (3rd quote side)**
   1. Process 3rd quote side, amend Bid Z3 1@20002 to 2@20001.
   2. In Execution Phase, matched 1@20001 in Z3, T1 1@0 in Z2/Z3 and T5.1 1@20000 in Z3. (i.e. matched the Implied OUT T1 + T5.1)
   3. AT T5.4, add Bid 1@20001 to Z3 in Insertion Phase.
   4. No implied order can be generated in Generation Phase.
   5. No action in triggering phase for this quote side.

![](data:image/png;base64...)

1. **Phase 2 - Adding New Quote (3rd quote side)**
   1. Process 4th quote side, cancel Bid Z4 1@20000.
   2. No action in Execution, Insertion, Generation and Triggering Phase. Cancel action is already done in Step 2 “Phase 1 - Cancel Existing Quote (Insertion Phase)” and not add action for this quote side.

![](data:image/png;base64...)

## [Change of Trading State](#_Change_of_Trading)

Orders are entered as depicted using the timestamp – T#:

1. Combo order T1 and T3 are input at morning session.
2. Explicit order T4 to T13 are input at afternoon pre-market session.

![](data:image/png;base64...)

1. At T14, the trading state is changed from pre-market to continuous trading.
   1. Q2, U2, Z3, H3, Q2/H3, U2/H3 and Z2/H3 are added into the Affected Order Book List.
2. **Generation Phase**
   1. At T14.1, Aggregated Implied Ask 1@-10 is updated in Q2/H3.
   2. Matched with T3, the trade price and quantity are 1@-10 (The trade price always is the price of implied IN order) ([Section 6.3 Trade Price](#_Trade_Price))
   * Matched 1@-10 in Q2/H3.
   * Matched 1@10000 in Q2.
   * Matched 1@9990 in H3.
   1. No Implied IN can be generated for U2/H3 and Z2/H3

![](data:image/png;base64...)

* 1. No Implied OUT can be generated for Q2, U2 and Z2.
  2. At T14.2, Aggregated Implied Bid 4@10000 is updated in H3.
  3. At T14.3, Aggregated Implied Ask 4@9990 is updated in H3.
  4. All Aggregated Implies have been updated in H3, performs execution check for H3.
  + Matched 1@10000 in H3 (Implied Bid T4 + T1 matched with Implied Ask T5 + T2. Trade price set to Implied Bid as its youngest parent T4 is older than youngest parent of Implied Ask T5).
  + Matched 1@9990 in H3 (Implied Bid T8 + T1 matched with Implied Ask T6 + T2. Trade price set to Implied Ask as its youngest parent T6 is older than youngest parent of Implied Bid T8).
  + Matched 1@9990 in H3 (Implied Bid T9 + T1 matched with Implied Ask T7 + T2. Trade price set to Implied Ask as its youngest parent T7 is older than youngest parent of Implied Bid T9).
  + Matched 1@10000 in H3 (Implied Bid T10 + T1 matched with Implied Ask T11 + T2. Trade price set to Implied Bid as its youngest parent T10 is older than youngest parent of Implied Ask T11).

![](data:image/png;base64...)

## [Price Alignment for Aggregated Implied OUT](#_Price_Alignment_for)

Assume following price band are enabled for an order book:

|  |  |  |  |
| --- | --- | --- | --- |
|  | **Price Band** | **Lower Limit** | **Upper Limit** |
|  | Price Tick | 5000 | 15000 |
|  | Dynamic Price Limit | 9984 | 10816 |
|  | VCM | 9500 | 10500 |

The implied price band is 9984 to 10500:

* + **Implied Lower Limit** = MAX (500, 9984, 9500) = 9984
  + **Implied Upper Limit** = MIN (15000, 10816, 10500) = 10500

Therefore, price alignment will be applied for an Aggregated Implied when:

* + Implied Bid price > 10500 (The implied price will be aligned to 10500).
  + Implied Ask price < 9984 (The implied price will be aligned to 9984).

In contrast, Aggregated Implied will not be generated when:

* + Implied Bid price < 9948.
  + Implied Ask price > 10500.

## [No Price Alignment for Aggregated Implied IN](#Price_Align_IN)

Assume only the price tick table with range -500 to 500 is enabled for Q2/H3, therefore the implied price band is from -500 to 500.

Orders are entered as depicted using the timestamp – T#:

1. Ask Q2 for 1@10000.
2. Bid H3 for 1@11000.
   1. Add an Aggregated Implied IN Bid 1@1000 to Q2/H3, the implied price is kept in 1000 due to no price alignment for Combo order book.
3. Ask Q2/H3 for 1@0.
   1. Matched with Aggregated Implies 1@1000. The trade price is 1000, although it violated the implied price band (price tick table) -500 to 500.

![](data:image/png;base64...)

## [Price Improvements for Aligned Implied OUT](#_Price_Improvement_for)

Assume the implied price band for H3 is 10000 to 15000.

Orders are entered as depicted using the timestamp – T#:

1. Ask U2 for 1@9990.
2. Ask U2/H3 for 1@0.
   1. Add an Aggregated Implied Ask 1@9990 to H3, the implied price is aligned to 10000 due to the implied ask price is better than implied lower limit.
3. Bid Q2/H3 for 1@50.
4. Bid Q2 for 1@10000.
   1. Add an Aggregated Implied Bid 1@10050 to H3.
   2. Matched 1@10000 in H3 (Implied Bid T3 + T4 matched with Implied Ask T1 + T2 with aligned price. Trade price set to Implied Ask as its youngest parent T2 is older than youngest parent of Implied Bid T4).
   * According to price improvements ([Section 6.4](#_Price_Improvements)), trade price for Q2/H3 is improved from 50 to 0.
   * According to price improvements for aligned Implied OUT ([Section 10.1.3](#_Price_Improvement_for)), the trade price for U2/H3 is improved from 0 to 10.

![](data:image/png;base64...)

## [Parent’s Price Check](#_Parent’s_Price_Check)

Assume the implied price band for U2 is 10000 to 14999.

Orders are entered as depicted using the timestamp – T#:

1. Ask H3 for 1@15000.
2. Bid Q2/H3 for 1@0.
   1. Add an Aggregated Implied Ask 1@15000 to Q2.
3. Bid Z2 for 1@15000.
4. Bid Q2/U2 for 1@0.
5. Ask U2 1@15000.
   1. Aggregated Quantity 1 (T3 + T5) cannot be counted for U2/Z2 due to parent order T5 in U2 violating the implied price band of U2.
   2. Aggregated Quantity 1 (T4 + T5) cannot be counted for Q2 due to parent order T5 in U2 violating the implied price band of U2. Aggregated Implied Ask 1@15000 in Q2 remains unchanged, and the Combo Q2/U2 is removed from Implied Execution Sequence.
6. Bid Q2 for 1@15000.
   1. Crossed with Aggregated Implied Ask 1@15000
   * Q2/U2 is removed from Implied Execution Sequence and has no execution checks.
   * Matched 1@15000 in Q2, T2 1@0 in Q2/H3 and T1 1@15000 in H3. (i.e. matched the Implied OUT T1 + T2).

![](data:image/png;base64...)

## [Volatility Control Mechanism](#_Volatility_Control_Mechanism)

Assume only VCM is enabled for Q2, VCM and implied price band is 10000 to 15000.

Orders are entered as depicted using the timestamp – T#:

1. AT T6, Bid Q2 for 1@16000.
   1. No Aggregated Implies can be generated for Z2 and H3 due to parent order T6 violating implied price band of Q2.
2. AT T8, Ask H3 for 2@15000.
   1. Aggregated Implied IN (i.e. T6 + T7) cannot be generated for Q2/H3 due to parent order T6 violating implied price band of Q2.
   2. AT T8.1, Aggregated Implied OUT 1@15000 is updated in Q2.
   3. Crossed with T6 Bid 1@16000 and triggered VCM.
   * Explicit orders T4, T5 and T6 are cancelled due to their price violating VCM price band. (refer to VCM FS)
   * Continue the matching process.
   1. Crossed with Aggregated Implies 1@15000.
   * Matched 1@15000 in Q2.
   * Matched 1@16000 in Z2.
   * Matched 1@1000 in Q2/Z2 (take all price improvements for aligned Implied OUT).
   1. AT T8.2, Aggregated Implied OUT 1@15000 is updated in U2.

![](data:image/png;base64...)

## [Changes on VCM Price Band](#_Changes_on_Implied)

Assume only VCM is enabled for H3, and the implied price band is 14001 to 15999.

Orders are entered as depicted using the timestamp – T#:

![](data:image/png;base64...)

1. AT T7, the implied price band is changed to 15001 to 16999 due to delayed VCM reference price update.
   1. H3, Q2/H3, Q2, U2/H3, U2, Z2/H3 and Z2 are added into Affected Order Book List and commence a Generation Phase.
   * No Aggregated Implied IN can be updated.
   * Implied OUT in Z2 is updated prior to H3.
   * Aggregated Implied Bid 1@16000 is updated in Z2.
   * Aggregated Implies from Q2/H3 are updated in H3 first, 2@15999 is updated to 1@15999 and 1@16999 (price is aligned) is added.
   * Aggregated Implies from U2/H3 are updated in H3, 1@15999 is removed and 1@16000 is added.

![](data:image/png;base64...)

1. AT T8, the implied price band is changed to 16001 to 17999 due to delayed VCM reference price update.
   1. H3, Q2/H3, Q2, U2/H3, U2, Z2/H3 and Z2 are added into Affected Order Book List and commence a Generation Phase.
   * No Aggregated Implied IN can be updated.
   * Implied OUT in Z2 is updated prior to H3.
   * Aggregated Implied Bid 1@16000 is removed in Z2 due to its parent order T6 in H3 violating implied price band of H3.
   * Aggregated Implies from Q2/H3 are updated in H3 first, 1@16999 is removed and 1@17000 is added.
   * Aggregated Implies from U2/H3 are updated in H3, 1@16000 is removed due to price alignment cannot be done in this case (i.e. Implied Bid price is worse than the implied lower limit) ([Section 10.1.2](#_Price_Alignment_for))

![](data:image/png;base64...)

## [Market Maker Protection](#_Market_Maker_Protection)

Assume orders T1 to T5 are input by a market maker A, and MMP threshold for market maker A is 1.

Orders are entered as depicted using the timestamp – T#:

1. **Generation Phase:**
   1. AT T9.1, Aggregated Implied OUT Bid 6@10000 is updated in H3.
   2. Crossed Aggregated Implied OUT Ask 2@9990
   * Matched 1@9990 in H3, T7 1@0 in U2/H3 and T1 1@9990 in U2. (i.e. matched the Implied OUT T1 + T7)
   * MMP threshold for market maker A is exceeded. Protection response will be performed in Triggering Phase.
   * Matched 1@9990 in H3, T6 1@0 in Z2/H3 and T4 1@9990 in Z2. (i.e. matched the Implied OUT T4 + T6)
   * Aggregated quantity exhausted, immediately recalculate implied price and quantity for traded Combo. (i.e. U2/H3 and Z2/H3)
     + Recalculated implied price and quantity is 2@9991.
   1. Crossed Aggregated Implied OUT Ask 2@9991
   * Matched 1@9991 in H3, T7 1@0 in U2/H3 and T2 1@9991 in U2. (i.e. matched the Implied OUT T2 + T7)
   * Matched 1@9991 in H3, T6 1@0 in Z2/H3 and T5 1@9991 in Z2. (i.e. matched the Implied OUT T5 + T6)
   * Aggregated quantity exhausted, immediately recalculate implied price and quantity for traded Combo. (i.e. U2/H3 and Z2/H3)
     + Recalculated implied price and quantity is 3@9992.
   1. Crossed Aggregated Implied OUT Ask 3@9992
   * Matched 2@9992 in H3, T7 2@0 in U2/H3 and T3 2@9992 in U2. (i.e. matched the Implied OUT T3 + T7)

![](data:image/png;base64...)

1. **Triggering Phase**
   1. Protection response for market maker A is begin, T3 is removed.
   2. Involved order book U2, connected order book U2/H3 and H3 are added into Affected Order Book List for extra Generation Phase.
   3. Extra Generation Phase is commenced, and Aggregated Implied Ask T9.3 1@9992 is removed from H3.

![](data:image/png;base64...)

## [Dynamic Price Limit](#_Dynamic_Price_Limit_1)

Assume only DPL is enabled for Q2 and H3, both dynamic reference prices are 20000.

Orders are entered as depicted using the timestamp – T#:

1. AT T4, Ask H3 for 2@17000.
   1. Crossed with Aggregated Implies 1@19000.
   * Matched 1@19000 in H3, dynamic reference price and band for H3 are calculated based on trade price 19000.
   * Matched with T1 1@18000 in Q2, dynamic reference price and band for Q2 are calculated based on trade price 18000.
   * Matched with T3 1@1000.
   * Aggregated quantity exhausted, immediately recalculate implied price and quantity for traded Combo.
     + Recalculated implied price and quantity for is 1@17000.
   1. Crossed with Aggregated Implies 1@17000.
   * Matched 1@17000 in H3, dynamic reference price and band for H3 are calculated based on trade price 17000.
   * Matched with T1 1@16000 in Q2, dynamic reference price and band for Q2 are calculated based on trade price 16000.
   * Matched with T3 1@1000.
   * Incoming order exhausted.
2. In Triggering Phase, implied price band for Q2 and H3 is adjusted according to their dynamic price band.
3. As implied price band for Q2 and H3 is changed, Q2, Q2/H3 and H3 are added into Affected Order Book List.
4. Extra Generation Phase is commenced, and nothing can be generation due to no resting explicit order.

![](data:image/png;base64...)
