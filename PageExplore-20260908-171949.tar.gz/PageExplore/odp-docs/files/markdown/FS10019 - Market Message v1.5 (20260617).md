TITLE:

**FUNCTIONAL SPECIFICATION**

***ODP-T

FS10019 – Market Message***

AUTHOR: *IT / Markets Systems* DATE: *17 Jun 2026*

LAST REVIEW: *Derivatives Trading Business Operations* DATE: *28 Feb 2025*

**CONTENTS**

[1. Document Control 3](#_Toc232605868)

[1.1. Change History 3](#_Toc232605869)

[1.2. Document Cross-referenced 3](#_Toc232605870)

[1.3. Abbreviation 3](#_Toc232605871)

[2. Introduction 5](#_Toc232605872)

[3. Automatic Event Message 5](#_Toc232605873)

[3.1. Delivery Channel 5](#_Toc232605874)

[3.2. Template Format 6](#_Toc232605875)

[3.3. Supported Event 7](#_Toc232605876)

[3.4. Configuration 16](#_Toc232605877)

[4. Manual Market Announcement 18](#_Toc232605878)

# Document Control

## Change History

|  |  |  |  |
| --- | --- | --- | --- |
| **Version**  **Number** | **Issue Date** | **Author** | **Abstract** |
| 1.0 | 11 Apr, 2024 | IT/Markets Systems | Initial Version |
| 1.1 | 6 Sep, 2024 | IT/Markets System | Add tags |
| 1.2 | 16 Oct, 2024 | IT/Markets System | Update based on lockdown session and FS review log |
| 1.3 | 7 Nov, 2024 | IT/Markets System | * Update based on FS review log on 241106 * Sync up terminology with GUI * Add support event for error trade |
| 1.3.1 | 27 Nov, 2024 | IT/Markets System | Updated section 1.2 Document Cross-referenced |
| 1.3.2 | 3 Jun, 2025 | IT/Markets System | Updated section 3.1.3 |
| 1.4 | 14 Jan, 2026 | IT/Markets System | Updated section 3.3.8, 3.3.9, 3.3.10 and 3.3.11 |
| 1.5 | 17 Jun, 2026 | IT/Markets System | Updated for Trading Halt Resumption   * Updated section 3.3.8 * Added section 3.3.9, 3.3.10 and 3.3.11 |

## Document Cross-referenced

|  |  |  |
| --- | --- | --- |
| **#** | **Document** | **Version** |
| 1 | 0005 BRS Trading Operations | 2024 11 22 |
| 2 | 0051 New Wish 020 Mkt Msg and Circular | 2024 10 17 |
| 3 | 0011 ODP - Automation of Static Price Limits Market Message and Email | 2024 08 01 |
| 4 | FS10001 - Trading Timetable | IT241126 |
| 5 | FS10004 - Price Supervision | IT241126a |
| 6 | 0004 BRS Market Integrity Safeguards | 2024 11 12 |
| 7 | FS10009 - Error Trade | v3.0.1 |

## Abbreviation

|  |  |
| --- | --- |
| AHT | After Hours Trading |
| VCM | Volatility Control Mechanism |
|  |  |

# Introduction

#FS10019\_S0020\_00100

Market message is an indispensable channel to announce news and information to the whole derivatives market. The following mechanisms are implemented in ODP-T to distribute market messages:

* Automatic Event Message
* Manual Market Announcement

# Automatic Event Message

#FS10019\_S0030\_00100

Automatic event message activates based on events. Upon the occurrence of a supported event within ODP-T such as a change in market state, the system automatically generates a text message with subject, content and message priority according to associated event message template and then disseminates it through the delivery channel.

An event can be set to utilize various delivery channels, with the option to customize the event message template for each chosen channel.

Automatic event messages on the dummy market are only sent to the Admin GUI through internal messages and are not delivered to any of the delivery channels listed below. Consequently, no automatic event messages for the dummy market can be delivered to external parties, and internal users can view it in Admin GUI.

## Delivery Channel

#FS10019\_S0030\_00200

The following delivery channels are supported by automatic event messages. Depending on the configuration, the generated text message for an event can be disseminated via one or multiple of these channels:

* Market Data
* Trading GUI
* Binary
* Email

### Market Data Channel

#FS10019\_S0030\_00301

When market data channel is selected as delivery channel, the system generated text message is delivered through market data as a market message by a dedicated message type. Refer to market data specification for further information.

### Trading GUI Channel

#FS10019\_S0030\_00400

When trading GUI channel is selected as delivery channel, the system generated text message only can be shown in trading GUI, and it is not visible to market data.

### Binary Channel

#FS10019\_S0030\_00420

When the binary channel is selected as delivery channel, the system generated text message with Critical priority is disseminated to all logged in Direct Order Flow Sessions. Non-Critical message is subject to configurations in each Direct Order Flow Sessions.

Example:

|  |  |  |
| --- | --- | --- |
| **Message Priority** | **Direct Order Flow’s Configuration** | **Dissemination Decision** |
| Critical | Receive all market message | Yes |
| Critical | Receive critical only | Yes |
| Non-Critical | Receive all market message | Yes |
| Non-Critical | Receive critical only | No |

### Email Channel

#FS10019\_S0030\_00500

When email channel is selected, the system generated text message is pasted into an email in plain text format and then sent to the recipient. The recipient can be configurable for each supported event.

Please note that email delivery is not a guaranteed channel, the email delivery may fail without any notification.

## Template Format

#FS10019\_S0030\_00600

The event message template provides flexibility to customize the subject, content and format of generated text message by composing below elements:

* Static Plain Text
* Variable Tag

### Static Plain Text

#FS10019\_S0030\_00700

Static plain text in the message template is replicated exactly as it is into the generated text message and no alterations are made. The supported character set is limited to ASCII, encompassing all non-printable characters such as a line break.

It is important to point out that curly bracket “{” and “}” are dedicated for indicating variable tag and, as a result, their usage is restricted.

### Variable Tag

#FS10019\_S0030\_00800

A variable tag is specially formatted text that acts as a placeholder for a certain value that is determined by the provided key. The value can be a name, a date, a number, or any other data that is relevant for the message. The variable tag allows the message template to be customized for different events.

The format of the variable tag is defined as below:

**{Supported Key}**

For example, the variable tag {NAME} will be replaced by the instrument/combo name of the event.

#### Supported key

#FS10019\_S0030\_00900

This is the mandatory field for the tag. The entire tag will be replaced by the value that is obtained from the triggering event, in accordance with the provided key (case insensitive).

Each event supports its unique set of keys, and values can only be retrieved from the event when the provided key is supported by the event, otherwise, the entire variable tag is automatically eliminated. Please refer Supported Event (Section 3.3) for a detailed list of keys associated with each supported event.

#### Example

The following is an example of event message template and the corresponding generated text message.

**Event Message Template:**

|  |
| --- |
| This is an event message template for “{EVENT\_NAME}”.  {NAME} | {PRICE} | {STATE\_NAME}  {MARKET} | {INST\_TYPE} | {MARKET\_DESC}  Tag with unsupported key “{UNSUPPORTED\_KEY}” is eliminated. |

**Generated Text Message:**

|  |
| --- |
| This is an event message template for “Example Event”.  DHSZ4 | 350.00 | OPEN  DJI | DJIF | DIVIDEND FUTURES  Tag with unsupported key “” is eliminated. |

## Supported Event

#FS10019\_S0030\_01000

A supported event refers to an event that can occur in ODP-T and allowed to trigger Automatic Event Message feature. These events are predefined by the feature and each event is accompanied by a set of supported keys for Variable Tags (Section 3.2.2). Any events not recognized by this feature will be disregarded and never trigger Automatic Event Message.

Below is the complete list of supported events; Please refer to respective event section for details on supported keys:

* Change of Trading State
* Alert before Trading State Change
* Change of Underlying State
* Change of Instrument/Combo
* Quote Request
* Trigger VCM
* End of VCM
* Trigger Trading Halt
* Trigger AHT Price Limit
* Alert of AHT Price Limit
* Error Trade

### Change of Trading State

#FS10019\_S0030\_01100

|  |  |
| --- | --- |
| **Supported Key** | **Description** |
| PROD\_LV | The value can be “Market” or “Instrument Type” or “Instrument Class”, based on the product level at which the state change occurs. |
| PROD\_DESC | The information is sourced from the “Description” field within the market/instrument type/instrument class table of the reference database. |
| STATE\_NAME1 | Display name of trade state. |
| STATE\_DESC1 | Trading state description\*. |

1: Refer to Section 6.2 “Business Trading States” in FS “ODP-T FS - Trading Timetable” for details.

Example:

|  |  |
| --- | --- |
| **Template** | “{PROD\_LV}” “{PROD\_DESC}” has changed to state {STATE\_NAME}; {STATE\_DESC}. |
| **Generated Text Message** | “Instrument Type” “HANG SENG FUTURES & OPTIONS FUTURES” has changed to state PRE\_MKT\_ACT; Pre-Market Activities. |

### Alert before Trading State Change

#FS10019\_S0030\_01200

|  |  |
| --- | --- |
| **Supported Key** | **Description** |
| PROD\_LV | The value can be “Market” or “Instrument Type” or “Instrument Class”, based on the product level at which the state change occurs. |
| PROD\_DESC | The information is sourced from the “Description” field within the market/instrument type/instrument class table of the reference database. |
| STATE\_NAME1 | Display name of trade state. |
| START\_TIME1 | Start time of the trading state in HH:MM:SS format. |
| TIME\_LEFT | Time to reach the trading state in format XX minutes YY seconds.  For example:  122 seconds will be converted to 2 minutes 2 seconds.  120 seconds will be converted to 2 minutes.  60 seconds will be converted to 1 minute.  1 second will be converted to 1 second. |

1: Refer to Section 5.1 “Trading Schedule” in FS “ODP-T FS - Trading Timetable” for details.

Example:

|  |  |
| --- | --- |
| **Template** | “{PROD\_LV}” “{PROD\_DESC}” will move to {STATE\_NAME} at {START\_TIME} in {TIME\_LEFT} |
| **Generated Text Message** | “Market” “HANG SENG FUTURES & OPTIONS” will move to AHT\_OPEN\_PL at 17:15:00 in 1 minute |

### Change of Underlying State

#FS10019\_S0030\_01300

|  |  |
| --- | --- |
| **Supported Key** | **Description** |
| UND\_ID | The ID of the underlying. |
| STATE | The value must be “suspended” or “resumed”. |

Example:

|  |  |
| --- | --- |
| **Template** | Trading in {UND\_ID} is {STATE} |
| **Generated Text Message** | Trading in AIA is suspended |

### Change of Instrument/Combo

#FS10019\_S0030\_01400

|  |  |
| --- | --- |
| **Supported Key** | **Description** |
| TYPE | The value can be “Instrument” or “Combination”. |
| NAME | Display name of instrument or combo. |
| STATE | The value can be “created” or “modified”. |

Example:

|  |  |
| --- | --- |
| **Template** | {TYPE} {NAME} is {STATE} |
| **Generated Text Message** | Combination TMC\_AIA/001 is created |

This supported event can be triggered by underlying suspension and resumption. When the underlying is suspended/resumed, there is an individual event for each instrument that corresponds to the underlying.

### Quote Request

#FS10019\_S0030\_01500

|  |  |
| --- | --- |
| **Supported Key** | **Description** |
| NAME | Display name of instrument, combo or TMC. |
| SIDE | The value can be “Bid” or “Ask” or “Bid and Ask”, it is depending on the side that specified in the request. |
| QTY | Quantity specified in the request. |

Example:

|  |  |
| --- | --- |
| **Template** | Quote Request in {NAME}, {SIDE}, quantity {QTY} |
| **Generated Text Message** | Quote Request in DHSZ4, Bid and Ask, quantity 5 |

### Trigger VCM

#FS10019\_S0030\_01601

|  |  |
| --- | --- |
| **Supported Key** | **Description** |
| NAME | Display name of instrument, combo or TMC. |
| TRIGGER\_DATE | Date to trigger VCM in DD MMM YYYY format. |
| TRIGGER\_TIME | Time to trigger VCM in HH:MM:SS format. |
| REF\_PRICE1 | Reference price of VCM limit. |
| UP\_LIMIT1 | Upper limit of VCM. |
| LO\_LIMIT1 | Lower limit of VCM. |
| END\_DATE | End date of VCM in DD MMM YYYY format. |
| END\_TIME | End time of VCM in HH:MM:SS format. |

1: Refer to Section 4.1 “Price Limit Calculation” in FS “ODP-T FS - Price Supervision” for details.

Example:

|  |  |
| --- | --- |
| **Template** | Start of Volatility Control Mechanism cool-off period: [{NAME}]  Trigger time: [{TRIGGER\_TIME} on {TRIGGER\_DATE}],  Reference price: [{REF\_PRICE}],  Upper price limit: [{UP\_LIMIT}],  Lower price limit: [{LO\_LIMIT}],  End time: [{END\_TIME} on {END\_DATE}] |
| **Generated Text Message** | Start of Volatility Control Mechanism cool-off period: [HSIG4]  Trigger time: [10:21:13 on 19 Feb 2024],  Reference price: [20000],  Upper price limit: [21000],  Lower price limit: [19000],  End time: [10:26:13 on 19 Feb 2024] |

### End of VCM

#FS10019\_S0030\_01610

|  |  |
| --- | --- |
| **Supported Key** | **Description** |
| NAME | Display name of instrument, combo or TMC. |
| END\_DATE | End date of VCM in DD MMM YYYY format. |
| END\_TIME | End time of VCM in HH:MM:SS format. |

Example:

|  |  |
| --- | --- |
| **Template** | End of Volatility Control Mechanism cool-off period: [{NAME}]  End time: [{END\_TIME} on {END\_DATE}] |
| **Generated Text Message** | End of Volatility Control Mechanism cool-off period: [HSIG4]  End time: [10:26:13 on 19 Feb 2024] |

### Trigger Trading Halt

#FS10019\_S0030\_01701

|  |  |
| --- | --- |
| **Supported Key** | **Description** |
| UND\_ID | The ID of the underlying that the halted instrument class belongs to. |
| INST\_CLASS\_DESC | Display name of the halted instrument class |
| TRIGGER\_DATE | Date to trigger trading halt in DD MMM YYYY format. |
| TRIGGER\_TIME | Time to trigger trading halt in HH:MM:SS format. |
| TRIGGER\_SIDE | The value can be “highest bid” or “lowest ask”, depending on the side that triggers trading halt. |
| TRIGGER\_QUEUE | The value can be “buying” or “selling”, depending on the side that triggers trading halt. |
| TRIGGER\_LIMIT | The value can be “Upper” or “Lower”, depending on the side that triggers trading halt. |
| UP\_DEV1 | Upper deviation parameter of AHT (static) price limit. |
| LO\_DEV1 | Lower deviation parameter of AHT (static) price limit. |
| UNIT\_DEV1 | Must be “%” or “Point”, depending on the “unit of deviation parameter” in “price tick limits”. |

1: Refer to Section 4.1 “Price Limit Calculation” in FS “ODP-T FS - Price Supervision” for details.

Example:

|  |  |
| --- | --- |
| **Template** | The {TRIGGER\_SIDE} of the spot month {UND\_ID} Futures on the {TRIGGER\_QUEUE} queue reached the {TRIGGER\_LIMIT} Price Limit of AHT Price Limit. Trading of {INST\_CLASS\_DESC} has been halted.  Trading of the affected {INST\_CLASS\_DESC} will remain halted until the spot month {UND\_ID} Futures meets the reopening price condition after the cooling-off. |
| **Generated Text Message** | The highest bid of the spot month HTI Futures on the buying queue reached the Upper Price Limit of AHT Price Limit. Trading of HTI – PUT OPTIONS has been halted.  Trading of the affected HTI – PUT OPTIONS will remain halted until the spot month HTI Futures meets the reopening price condition after the cooling-off. |

If there are multiple instrument classes listed in the Target Instrument List for a trading halt, a separate message will be produced for each of the classes. Please refer to Section 5.2 “Target Instruments List” in FS “ODP-T FS - Price Supervision” for details of Target Instruments List.

### Trigger Trading Halt During No Resumption Period

#FS10019\_S0030\_01702

|  |  |
| --- | --- |
| **Supported Key** | **Description** |
| UND\_ID | The ID of the underlying that the halted instrument class belongs to. |
| INST\_CLASS\_DESC | Display name of the halted instrument class |
| TRIGGER\_DATE | Date to trigger trading halt in DD MMM YYYY format. |
| TRIGGER\_TIME | Time to trigger trading halt in HH:MM:SS format. |
| TRIGGER\_SIDE | The value can be “highest bid” or “lowest ask”, depending on the side that triggers trading halt. |
| TRIGGER\_QUEUE | The value can be “buying” or “selling”, depending on the side that triggers trading halt. |
| TRIGGER\_LIMIT | The value can be “Upper” or “Lower”, depending on the side that triggers trading halt. |
| UP\_DEV1 | Upper deviation parameter of AHT (static) price limit. |
| LO\_DEV1 | Lower deviation parameter of AHT (static) price limit. |
| UNIT\_DEV1 | Must be “%” or “Point”, depending on the “unit of deviation parameter” in “price tick limits”. |

1: Refer to Section 4.1 “Price Limit Calculation” in FS “ODP-T FS - Price Supervision” for details.

Example:

|  |  |
| --- | --- |
| **Template** | The {TRIGGER\_SIDE} of the spot month {UND\_ID} Futures on the {TRIGGER\_QUEUE} queue reached the {TRIGGER\_LIMIT} Price Limit of AHT Price Limit. Trading of {INST\_CLASS\_DESC} has been halted.  Trading of the affected {INST\_CLASS\_DESC} will remain halted until the end of the AHT session. |
| **Generated Text Message** | The highest bid of the spot month HTI Futures on the buying queue reached the Upper Price Limit of AHT Price Limit. Trading of HTI – PUT OPTIONS has been halted.  Trading of the affected HTI – PUT OPTIONS remain halted until the end of the AHT session. |

If there are multiple instrument classes listed in the Target Instrument List for a trading halt, a separate message will be produced for each of the classes.

### Trading Resumption

#FS10019\_S0030\_01703

|  |  |
| --- | --- |
| **Supported Key** | **Description** |
| UND\_ID | The ID of the underlying that the halted instrument class belongs to. |
| INST\_CLASS\_DESC | Display name of the halted instrument class |

Example:

|  |  |
| --- | --- |
| **Template** | Please be advised that the cooling-off period has ended and the spot month {UND\_ID} Futures has met the reopening price condition for {UND\_ID} options series under the Trading Halt Mechanism.  Trading of {INST\_CLASS\_DESC} has been resumed. |
| **Generated Text Message** | Please be advised that the cooling-off period has ended and the spot month HTI Futures has met the reopening price condition for HTI options series under the Trading Halt Mechanism.  Trading of HTI – PUT OPTIONS has been resumed. |

If there are multiple instrument classes listed in the Target Instrument List for a trading halt, a separate message will be produced for each of the classes.

### Trading Halt Remaining In Effect

#FS10019\_S0030\_01704

|  |  |
| --- | --- |
| **Supported Key** | **Description** |
| UND\_ID | The ID of the underlying that the halted instrument class belongs to. |
| INST\_CLASS\_DESC | Display name of the halted instrument class |
| NO\_RESUME\_PERIOD1 | Duration of no resumption period in format XX minutes YY seconds.  For example:  122 seconds will be converted to 2 minutes 2 seconds.  120 seconds will be converted to 2 minutes.  60 seconds will be converted to 1 minute.  1 second will be converted to 1 second. |

1: Refer to Section 5.6 “No Resumption Period” in FS “ODP-T FS - Price Supervision” for details.

Example:

|  |  |
| --- | --- |
| **Template** | Please be advised that the spot month {UND\_ID} Futures has not met the reopening price condition. As only {NO\_RESUME\_PERIOD} minutes remain in the AHT session, trading of the affected {INST\_CLASS\_DESC} will remain halted until the end of the AHT session. |
| **Generated Text Message** | Please be advised that the spot month HTI Futures has not met the reopening price condition. As only 30 minutes remain in the AHT session, trading of the affected HTI – PUT OPTIONS will remain halted until the end of the AHT session. |

If there are multiple instrument classes listed in the Target Instrument List for a trading halt, a separate message will be produced for each of the classes.

### Trigger AHT Price Limit

#FS10019\_S0030\_01801

|  |  |
| --- | --- |
| **Supported Key** | **Description** |
| UND\_ID | The ID of the underlying for the instrument that triggers the AHT (static) price limit |
| NAME | Display name of the triggering instrument, combo or TMC. |
| TRIGGER\_DATE | Date to trigger trading halt in DD MMM YYYY format. |
| TRIGGER\_TIME | Time to trigger trading halt in HH:MM:SS format. |
| UP\_DEV1 | Upper deviation parameter of AHT (static) price limit. |
| LO\_DEV1 | Lower deviation parameter of AHT (static) price limit. |
| UNIT\_DEV1 | Must be “%” or “Point”, depending on the “unit of deviation parameter” in “price tick limits”. |
| REF\_PRICE1 | Reference price of AHT (static) price limit. |
| UP\_LIMIT1 | Upper limit of AHT (static) price limit. |
| LO\_LIMIT1 | Lower limit of AHT (static) price limit. |

1: Refer to Section 4.1 “Price Limit Calculation” in FS “ODP-T FS - Price Supervision” for details.

Example:

|  |  |
| --- | --- |
| **Template** | Please be advised that “{UND\_ID}” market has reached the Price Limit Up/Down Mechanism Boundary on {TRIGGER\_DATE}, i.e. {UP\_DEV}{UNIT\_DEV} with reference to the last traded price of previous session.  Any bid orders that are higher than the Upper Price Limit and sell orders that are lower than the Lower Price Limit will be rejected.  Instrument, Ref Price, Upper PL, Lower PL  {NAME}, {REF\_PRICE}, {UP\_LIMIT}, {LO\_LIMIT} |
| **Generated Text Message** | Please be advised that “HTI” market has reached the Price Limit Up/Down Mechanism Boundary on 02 Feb 2022, i.e. 5% with reference to the last traded price of previous session.  Any bid orders that are higher than the Upper Price Limit and sell orders that are lower than the Lower Price Limit will be rejected.  Instrument, Ref Price, Upper PL, Lower PL  HTIZ2, 3904, 4099, 3709 |

Be aware that this supported event only can be triggered once per threshold per instrument per day.

### Alert of AHT Price Limit

#FS10019\_S0030\_01901

|  |  |
| --- | --- |
| **Supported Key** | **Description** |
| UND\_ID | The ID of the underlying for the instrument that triggers the AHT (static) price limit |
| TRIGGER\_DATE | Date to trigger trading halt in DD MMM YYYY format. |
| TRIGGER\_TIME | Time to trigger trading halt in HH:MM:SS format. |
| DEV\_VAL | The actual value (% or tick) that deviated to the reference price, can be positive number or negative number. |
| UP\_DEV1 | Upper deviation parameter of AHT (static) price limit. |
| LO\_DEV1 | Lower deviation parameter of AHT (static) price limit. |
| UNIT\_DEV1 | Must be “%” or “Point”, depending on the “unit of deviation parameter” in “price tick limits”. |
| REF\_PRICE1 | Reference price of AHT (static) price limit. |
| UP\_LIMIT1 | Upper limit of AHT (static) price limit. |
| LO\_LIMIT1 | Lower limit of AHT (static) price limit. |
| PREDEFINED\_TABLE | A pre-defined table to display the instrument name, last traded price and turnover for each future instrument under the instrument class in following format:  - Thousand separator for any numeric values is “,”  - Empty value is presented by “-”.  - The number of decimals for trade price follows the number of decimals configuration in tick table for the instrument. |

Please note that, the space for the fixed length filed might not align as expected in the actual email output due to the non-equal width font, and this cannot be controlled.

Example:

|  |  |
| --- | --- |
| **Template** | Dear all,  We would like to inform you that {UND\_ID} futures spot month contracts deviate {DEV\_VAL}{UNIT\_DEV} from reference price {REF\_PRICE} at {TRIGGER\_TIME}.  Please see below, {UND\_ID} futures last traded price and turnover after reaching {UP\_DEV}{UNIT\_DEV} at around {TRIGGER\_TIME}.  {PREDEFINED\_TABLE}  Regards,  Derivatives Trading Operation |
| **Generated Text Message** | Dear all,  We would like to inform you that HTI futures spot month contracts deviate +3% from reference price 4148 at 21:31:25.  Please see below, HTI futures last traded price and turnover after reaching 3% at around 21:31:25.  Instrument Name: HTIX4  Last Traded Price: 7,251.0000  Turnover: 10,582  Instrument Name: HTIZ4  Last Traded Price: 7,249.0000  Turnover: 928  Instrument Name: HTIF5  Last Traded Price: -  Turnover: -  Instrument Name: HTIH5  Last Traded Price: 7,604.0000  Turnover: 13  Instrument Name: HTIZ5  Last Traded Price: 7,500.0000  Turnover: 1  Instrument Name: HTIZ6  Last Traded Price: -  Turnover: -  Regards,  Derivatives Trading Operation |

Be aware that this supported event only can be triggered once per threshold per instrument per day.

### Error Trade

#FS10019\_S0030\_0191

Market messages that are supported by error trade claims (i.e. Accepted Claim Application Template, Claimed Trade Retained, Claimed Trade Cancelled by Participant, Claimed Trade Cancelled by Committee) supports below keys:

|  |  |
| --- | --- |
| **Supported Key** | **Description** |
| NAME | Display name of instrument, combo or TMC. |
| TRADED\_PRICE | The traded price of the error claim. |
| TRADED\_QTY | The traded quantity of the error claim. |
| TRADE\_ID | Unique ID of the trade that specified in the error claim. |
| TRADED\_TIME | Traded time of the error trade in HH:MM:SS format. |

Example:

|  |  |
| --- | --- |
| **Template** | Error Trade (By committee)  Pursuant to HKFE Rule 819B, please be advised that the following trade is declared as erroneous as reviewed by the HKATS Error Trade Review Panel:  Contract = {NAME}  Price = {TRADED\_PRICE}  Quantity = {TRADED\_QTY}  Trade ID = {TRADE\_ID}  Traded Time = {TRADED\_TIME} |
| **Generated Text Message** | Error Trade (By committee)  Pursuant to HKFE Rule 819B, please be advised that the following trade is declared as erroneous as reviewed by the HKATS Error Trade Review Panel:  Contract = JDC300.00R4  Price = 177.07  Quantity = 3  Trade ID = 142846942  Traded Time = 13:33:00 |

## Configuration

#FS10019\_S0030\_02000

Through the Admin GUI's Maintain Message Template screen, operational users have the capability to develop message templates and subsequently link a message template with a delivery channel for a particular supported event using maintain Automatic Event Message screen.Every configuration outlined in this section is designed to support creation, modification, deletion, and cloning, with changes taking effect immediately.

### Maintain Message Template

#FS10019\_S0030\_02100

Message templates can be utilized in setting up Automated Event Messages (Section 3.4.2), and they may also serve as predefined layouts for composing Manual Market Announcement (Section 4).

Message template contains the following attributes:

|  |  |
| --- | --- |
| **Attribute** | **Description** |
| Template Name | Identity of the template. The maximum length is 32. |
| Target Triggering Event | Used to verify supported variable tag. Once the template is established, it cannot be modified. |
| Message Priority | To specify the priority flag of the market message. Domain values are “Critical”, “Important” or “Normal”. |
| Subject | Support is limited to the ASCII character set. The maximum permissible length is 100 characters, which encompasses all non-printable characters, like line breaks.  Both static plain text and variable tag are supported. |
| Content | Support is limited to the ASCII character set. The maximum permissible length is 900 characters, which encompasses all non-printable characters, like line breaks.  Both static plain text and variable tag are supported. |

### Maintain Automatic Event Message

#FS10019\_S0030\_02200

It is allowed to create numerous automated event messages that are activated by the same triggering event. Whenever the event occurs, the system will process each configuration independently, following an ascending order based on the Message Event Names of the configurations.

Automatic event message contains the following attributes:

|  |  |
| --- | --- |
| **Attribute** | **Description** |
| Message Event Name | Identity of the configuration. The maximum length is 32. |
| Triggering Event | To specify a supported event as the triggering event for this configuration. Refer to the Supported Event (Section 3.3) for possible selections.  Please note that the support event “Error Trade” is excluded from triggering event of Automatic Event Message, please refer to “ODP-T FS - Error Trade” for details configuration for error trade related messages. |
| Template for Market Data Channel | Indicate a message template for market data channel. It can be left blank if dissemination through the market data channel is not necessary for the triggering event. |
| Template for Trading GUI Channel | Indicate a message template for trading GUI channel. It can be left blank if dissemination through the trading GUI channel is not necessary for the triggering event. |
| Template for Binary Channel | Indicate a message template for binary channel. It can be left blank if dissemination through the binary channel is not necessary for the triggering event. |
| Template for Email Channel | Indicate a message template for email channel. It can be left blank if dissemination through the email channel is not necessary for the triggering event. |
| Recipient for Email Channel | Designate up to 5 recipients for the email distribution. If modifications to the email content are required before sending it to external, set the recipient as an internal email address only. |

# Manual Market Announcement

#FS10019\_S0040\_00100

Operational users can manually disseminate a market message through both Market Data Channel (Section 3.1.1) and Binary Channel (Section 3.1.3) by inputting the fields below in Admin GUI’s Manual Market Announcement screen. The options and restrictions for each field correspond precisely with those outlined in the Maintain Message Template (Section 3.4.1):

* Message Priority
* Subject
* Content

Furthermore, the Manual Market Announcement feature has the capability to use a message template that was previously established through the Maintain Message Template (Section 3.4.1) which offers a standard format. Operational users have the option to make changes to the subject, content as well as priority after loading and prior to distribution.

Be aware that variable tags are incompatible with Manual Market Announcement. Any variable tags will be regarded as static text, and no substitution will occur. Hence, variable tags will be transferred into the market data’s market message exactly as they appear, without alterations.
