TITLE:

**FUNCTIONAL SPECIFICATION**

***ODP-T

FS10021 – Audit Log***

AUTHOR : *IT/Markets Systems*  DATE : 24 Mar *2025*

LAST REVIEW Derivatives Trading Business Operations DATE : 28 *Feb 2025*

**CONTENTS**

[1. Document Control 3](#_Toc183734505)

[1.1. Change History 3](#_Toc183734506)

[1.2. Document Cross-referenced 3](#_Toc183734507)

[1.3. Abbreviation 3](#_Toc183734508)

[2. Introduction 4](#_Toc183734509)

[2.1. Scope 4](#_Toc183734510)

[2.2. Primary Users 4](#_Toc183734511)

[3. Access Log 5](#_Toc183734512)

[3.1. IdP 5](#_Toc183734513)

[3.2. GUI (Internal & External) 5](#_Toc183734514)

[3.3. Binary Gateway 6](#_Toc183734515)

[4. Internal Data Administration 7](#_Toc183734516)

[5. Order & Trade Activities 9](#_Toc183734517)

[5.1. MRM Log 9](#_Toc183734518)

[5.1.1. Order Details 9](#_Toc183734519)

[5.1.2. Trade Data Details 10](#_Toc183734520)

[6. Administration Database Backup 11](#_Toc183734521)

[7. Retention 12](#_Toc183734522)

# Document Control

## Change History

|  |  |  |  |
| --- | --- | --- | --- |
| Version  Number | Issue Date | Author | Abstract |
| 0.1 | 22 Nov 2024 | IT/Markets Systems | Initial Version |
| 0.2 | 27 Dec 2024 | IT/Markets Systems | Revised according to FS10021 Review Log comments. |
| 0.3 | 23 Jan 2025 | IT/Markets Systems | Revised according to Traceability Mapping discussion agreements. |
| 1.0 | 24 Mar 2025 | IT/Markets Systems | Cover Page (System Name, Document ID, Last Modified/Reviewed Date), Version Number and Document Cross-Referenced table update. |

## Document Cross-referenced

|  |  |  |
| --- | --- | --- |
| # | Document | Version |
| 1 | BRD\_DT\_0004: 0004 BRS Market Integrity Safeguards - v1.8 - 2025 1 15.docx | v1.8 - 2025 1 15 |
| 2 | BRD\_DT\_0056: 0056 BRS\_Audit Logs\_2025 01 03\_v1.0 (Revised Tag)\_ 2025 02 03.docx | v1.0 (Revised Tag)\_ 2025 02 03 |

## Abbreviation

|  |  |
| --- | --- |
| ODP-T | Orion Derivatives Platform - Trading |

# Introduction

This document summarizes the audit log on business events in the ODP-T

## Scope

This document covers the audit log on business events on the application level.

## Primary Users

The primary users of the audit log is the Derivatives Trading Business.

# Access Log

## IdP

#FS10021\_S0030\_00100

The following events are included in the audit log:

* User Login
* User Logout

The following information are covered when applicable:

|  |  |  |
| --- | --- | --- |
| Item | Event Information | Description |
|  | Event Date & Time | The Date & Time when this event occurred in system perspective |
|  | User ID | User Identity code |
|  | Event Type | Type of the event. For example, Login / Logout |
|  | Event State | The result state of the event. For example, Success or Fail |
|  | IP Address | The IP Address which the event was originated in system perspective.  Only available for Login event. |
|  | Fail Reason | The reason if the event is fail and if available. For example, if login fail, the Fail Reason field would contain the reason why the login would fail. |

## GUI (Internal & External)

#FS10021\_S0030\_00200

The following events are included in the audit log:

* User Login[[1]](#footnote-1)
* User Logout

The following information are covered when applicable:

|  |  |  |
| --- | --- | --- |
| Item | Event Information | Description |
|  | Event Date & Time | The Date & Time when this event occurred in system perspective |
|  | User ID | User Identity code |
|  | Event Type | Type of the event. For example, Login / Logout |
|  | Event State | The result state of the event. For example, Success or Fail |
|  | IP Address | The IP Address which the event was originated in system perspective.  Only available for Login event. |

## Binary Gateway

#FS10021\_S0030\_00300

The following events are included in the audit log:

* Session Logon
* Session Logout

The following information are covered when applicable:

|  |  |  |
| --- | --- | --- |
| Item | Event Information | Description |
|  | Event Date & Time | The Date & Time when this event occurred in system perspective |
|  | Comp ID | Session Logon Identity |
|  | Event Type | Type of the event. For example, Login / Logout |
|  | Event State | The result state of the event. For example, Success or Fail. |
|  | IP Address | The IP Address which the event was originated in system perspective.  Only available for Logon event. |
|  | Fail Reason Code | The reason if the event is fail and if available. For example, if login fail, the Fail Reason field would contain the reason why the login would fail. |

# Internal Data Administration

#FS10021\_S0040\_00100

All business data entity creation and changes (deletion is considered as a change) made by HKEX internal staff through the Internal Administration GUI are included in the audit log.

The following information are covered when applicable:

| Item | Event Information | Description |
| --- | --- | --- |
|  | Event Request Date & Time | The Date & Time when this event request was created in system perspective |
|  | Event Request User ID | The User ID that initiated the event |
|  | Event Action Type | The action requested for this event. For example, Data Creation or Data Changes |
|  | Event State | The result state of the request event. For example, pending approval, approved, rejected or withdrawn. |
|  | Approver User ID | The User ID that approved the event if the event is approved |
|  | Approval Date & Time | The Date & Time when this event request was approved in system perspective. (Applicable if the event is approved) |
|  | Rejection User ID | The User ID that Rejected the event if the event is rejected |
|  | Rejection Date & Time | The Date & Time when this event request was rejected in system perspective. (Applicable if the event is rejected) |
|  | Data Record Type | The Data Record type in this event. For example, participant data, timetable etc. |
|  | Data Record Details (Old Values) | The original values (if applicable) of the data record before the changes. The details depend on the data record type. Please refer to the GUI FS for the corresponding fields for that record type. |
|  | Data Record Details (New Values) | The changed values (if applicable) of the data record. The details depend on the data record type. Please refer to the GUI FS for the corresponding fields for that record type. |

# Order & Trade Activities

## MRM Log

#FS10021\_S0050\_00100

MRM log is the message log from a Matching Engine partition contains order and trade business events.

### Order Details

#FS10021\_S0050\_00200
The event information is below is based on a new order. Some attributes might not be available depending on the action such as amending an order; especially some attributes are not amendable.

| Item | Event Information | Description |
| --- | --- | --- |
|  | Order Event Date & Time | The Date & Time of this order event in system perspective |
|  | Comp ID | The session ID that initiated the order event |
|  | Security ID Reference | Tradable Instrument Identification |
|  | Order ID | Internal Order ID |
|  | Side | Side of the order (Buy or Sell) |
|  | Order Type | Order Type |
|  | Order Price | Order Price |
|  | Order Quantity | Order Quantity |
|  | Open Quantity | Open Quantity |
|  | Filled Quantity | Filled Quantity |
|  | Order State | Order State |
|  | TIF | Time in Force; Time qualifier of the order |
|  | SMP ID | Self-Match Prevention ID. Identifier to prevent self-matching. |
|  | AHT Indicator | After-Hours Trading Indicator (a.k.a. T + 1), to indicate whether the order will be carried forward to AHT session or to indicate it is an AHT order during the submission in AHT session. |
|  | Clearing Account | The account for clearing purpose. |
|  | Customer Information | Client specified free text, a pass-through attribute |
|  | Position Effect | Indicates whether the opening or closing position after a trade |
|  | Give Up Participant | Indicates the give-up participant, for clearing purpose. |
|  | Give Up Info | Indicates the give-up info, for clearing purpose. |
|  | Active Trader ID | A field used for Client Incentive program calculation |
|  | COD | Cancel on Disconnect |
|  | Message Type | Internal Message Type |

### Trade Data Details

#FS10021\_S0050\_00300

| Item | Event Information | Description |
| --- | --- | --- |
|  | Trade Event Date & Time | The Date & Time of this trade event in system perspective |
|  | Security ID Reference | Tradable Instrument Identification |
|  | Match ID |  |
|  | Match Group ID |  |
|  | Match Event ID |  |
|  | Trade Price |  |
|  | Trade Quantity |  |
|  | Trade Type |  |
|  | Aggressor |  |
|  | Order Category |  |

# Administration Database Backup

#FS10021\_S0060\_00100
The administration database is also backup periodically for future reference.

# Retention

#FS10021\_S0070\_00100

The retention period follows the regulatory requirements or ITD standards which ever is longer.

1. User Login is handled by IdP. In GUI, the authorized return events from the users are considered as Login events in GUI. If the Login is fail on the IdP side, there would not be a Login event appear on the GUI side as the login request would not reach the GUI. [↑](#footnote-ref-1)
