TITLE:

**FUNCTIONAL SPECIFICATION**

***ODP-T***

*FS10008 Market Maker Protection*

AUTHOR : *IT/Markets Systems*  DATE : *9 Jan 2026*

LAST REVIEW *Derivatives Trading Business Operations* DATE : *28 Feb 2025*

**CONTENTS**

[1. Document Control 3](#__RefHeading___Toc218727119)

[1.1. Change History 3](#__RefHeading___Toc218727120)

[1.2. Document Cross-referenced 3](#__RefHeading___Toc218727121)

[1.3. Abbreviation 3](#__RefHeading___Toc218727122)

[2. Introduction 4](#__RefHeading___Toc218727123)

[3. Market Maker Protection 5](#__RefHeading___Toc218727124)

[3.1. Protection Types 5](#__RefHeading___Toc218727125)

[3.2. Execution Monitoring 5](#__RefHeading___Toc218727126)

[3.2.1. Trades Included 6](#__RefHeading___Toc218727127)

[3.2.2. Exposure Time Limit Interval 6](#__RefHeading___Toc218727128)

[3.3. Triggering of Market Maker Protection 6](#__RefHeading___Toc218727129)

[3.3.1. Protection Limits Check 6](#__RefHeading___Toc218727130)

[3.3.2. Cancel On MMP Triggered Flag 6](#__RefHeading___Toc218727131)

[3.3.3. Protection Response 7](#__RefHeading___Toc218727132)

[3.3.4. Release of Frozen Period 7](#__RefHeading___Toc218727133)

[3.3.5. Handling of Incoming Quote 7](#__RefHeading___Toc218727134)

[3.3.6. Examples 7](#__RefHeading___Toc218727135)

[3.4. Market Maker Protection Parameters 9](#__RefHeading___Toc218727136)

[3.4.1. Business Operations Configuration 9](#__RefHeading___Toc218727137)

[3.4.2. Exchange Participant Configuration 10](#__RefHeading___Toc218727138)

# Document Control

## Change History

|  |  |  |  |
| --- | --- | --- | --- |
| Version  Number | Issue Date | Author | Abstract |
| 0.1 | 29 Apr 2024 | IT/Markets Systems | Initial Version |
| 0.2 | 20 Sep 2024 | IT/Markets Systems | Revised Version with Tagging |
| 0.3 | 19 Nov 2024 | IT/Markets System | Revised based on review comments from business users |
| 0.4 | 15 Jun 2025 | IT/Markets System | Added Cancel On MMP Triggered Flag |
| 0.5 | 9 Jan 2026 | IT/Markets System | Revised version |

## Document Cross-referenced

|  |  |  |
| --- | --- | --- |
| # | Document | Version |
| 1 | BRD\_DT\_0005 BRS Trading Operations | 20250530 |
| 2 | BRD\_DT\_0044 BRS BAU Support | 20250429 |
| 3 | BRD\_DT\_0050 BRS\_PDMPA functions in ODP | 20250428 |
| 4 | BRD\_DT\_0052 ODP - NewFunctionRequest - Product Setup | 20240517 |

## Abbreviation

|  |  |
| --- | --- |
| EP | Exchange Participant |
| ME | Matching Engine |
| MMP | Market Maker Protection |
| ODP-T | Orion Derivatives Platform – Trading |
| PTRM | Pre Trade Risk Management |
| TMC | Tailor-Made Combination |

# Introduction

**#FS10008\_S0020\_00100**

Market Maker Protection (MMP) provides a mechanism to reduce the risk of Market Maker having outstanding quotes traded beyond a pre-defined limit.

The following protection limits are implemented:

* Quantity Protection: the total of traded quantity in a certain underlying within a given time interval
* Delta Protection: the delta of traded quantity in a certain underlying within a given time interval

When the threshold is breached, all outstanding quotes tagged with cancel on MMP triggered flag in that underlying will be cancelled by the system. And, the Market Maker can only submit new quotes in that underlying after a pre-defined period of time interval.

# Market Maker Protection

**#FS10008\_S0030\_00100**

Market Maker Protection (MMP) provides a mechanism to reduce the risk of Market Maker from excessive trading by cancelling the Market Maker’s outstanding quotes for an underlying when the traded volume has exceeded the pre-defined volume threshold with the pre-defined period of time.

## Protection Types

There are two types of protection:

* **#FS10008\_S0030\_00200** Quantity Protection
* **#FS10008\_S0030\_00300** Delta Protection

Both provide protection against excess options[[1]](#footnote-2) and futures[[2]](#footnote-3) quotes traded in the same underlying within a pre-configured exposure time limit interval. It is configurable if futures quotes should be considered.

|  |  |  |
| --- | --- | --- |
| Protection Type | Include Futures | Protection Limit Calculation |
| **Quantity Protection** | Y | Total of traded quantity of futures, call and put options in the same underlying |
| N | Total of traded quantity of call and put options in the same underlying |
| **Delta Protection** | Y | Absolute value of the sum of [(bought futures + bought call options + sold put options) – (sold futures + sold call options + bought put options)] in the same underlying |
| N | Absolute value of the sum of [(bought call options + sold put options) – (sold call options + bought put options)] in the same underlying |

It should be noted that the calculation is solely according to the traded quantity, no contract multiplier is applied.

MMP functionality is supported per ME partition. If an underlying is handled by multiple ME partitions, the calculation and the trigger of protection for each ME partition will be treated as independent.

## Execution Monitoring

**#FS10008\_S0030\_00400**

Executions from options and futures (if “Include Futures” = Y) quotes are monitored during trading state with auction matching (i.e. trading state type is UNCROSS) and continuous matching (i.e. trading state type is OPEN).

### Trades Included

**#FS10008\_S0030\_00500**

Only trades on quotes for options and futures (if “Include Futures” = Y) order books are included in the protection values calculation. Trades on the following are excluded:

* quotes for non-options and non-futures instrument,
* quotes for combo (including TMC),
* all types of orders, and
* block trades

Trades amendment and cancellation also do not affect the calculation.

### Exposure Time Limit Interval

**#FS10008\_S0030\_00600**

Exposure time limit interval is a rolling time interval for the protection calculation. A series of time buckets is defined per underlying per Market Maker. Specifically, there are N (the configured exposure time limit interval in seconds) consecutive time buckets, and the length of each bucket is one second. The traded quantity of a new trade applicable to the calculation is added to the current bucket. When the time interval of the current bucket is passed, the oldest historical time bucket will be reset and will become the new current bucket.

The Quantity Protection and Delta Protection values are calculated based on the total traded quantity of the current bucket plus the most recent N-1 completed time buckets. For example, if the configured interval is 60 seconds, the system will count the total traded quantity of the current plus the most recent 59 buckets.

## Triggering of Market Maker Protection

### Protection Limits Check

**#FS10008\_S0030\_00700**

MMP is a post execution check. The calculated values are checked against the limits only after an order or a quote item (i.e. one side of a quote pair) execution is fully processed, including any executions linked via implied trading. MMP will be triggered if the calculated value of any one protection types equals or exceeds its limit. Thus, further trades may still occur with breached limit until the current order/quote processing is completed.

### Cancel On MMP Triggered Flag

**#FS10008\_S0030\_00710**

When a single quote or a mass quote is submitted, a cancel on MMP triggered flag (a bitmask field) is specified per quote side. This flag indicates whether the quote side entry should be cancelled once MMP is triggered.

### Protection Response

When MMP is triggered, the following protection response will be invoked:

* **#FS10008\_S0030\_00800** A notification message will be generated and sent to that Market Maker to inform which underlying’s MMP has been triggered via its direct order flow sessions.
* **#FS10008\_S0030\_00900** All outstanding options and futures (if “Include Futures” = Y) quotes tagged with cancel on MMP triggered flag in that underlying for that Market Maker will be cancelled (quotes for non-options and non-futures instrument and combo, all type of orders and pending block trades will not be cancelled)
* **#FS10008\_S0030\_01000** Regardless of the cancel on MMP triggered flag, any new options and futures (if “Include Futures” = Y) quotes or quote amendments in that underlying for that Market Maker will be rejected in a pre-configured period of time interval, i.e. the frozen period, but cancellation of outstanding quotes are allowed
* The calculated value of Quantity Protection and Delta Protection for that Market Maker in that underlying will be reset
* The Quantity Protection and Delta Protection values will not be updated even there are executions during the frozen period

### Release of Frozen Period

**#FS10008\_S0030\_01050**

EP can submit a release request to reset the frozen period for a specified underlying via its own direct order flow sessions. An acknowledgment message will then be returned to indicate if the request is accepted or rejected. If the request is accepted, the frozen period will be ended immediately.

### Handling of Incoming Quote

**#FS10008\_S0030\_01100**

For a single quote or a mass quote, the calculated values are checked after processing each individual quote item. If MMP is triggered, the rest of the quote items in the same underlying will be rejected while those in another underlying without MMP triggered will still be processed. If a quote item matches with a passive quote from another Market Maker Y, resulting in triggering of MMP for Y, the rest of the quote items will be handled after all Y’s quotes for the same underlying are cancelled.

### Examples

**#FS10008\_S0030\_01200**

Example 1 – Incoming order matches with a passive quote

Market Maker X’s Quantity Protection = 5

|  |  |
| --- | --- |
| Bid | Ask |
| 10@$99 (Y’s order) | 10@$100 (X’s quote) |
| 10@$98 (X’s quote) | 10@$103 (X’s quote) |
| 10@$97 (X’s order) |  |

1. Participant Y enters a new bid order 10@$100
2. The incoming bid order fully matches with X’s ask quote 10@$100
3. MMP is triggered for X
4. All outstanding X’s quotes in that underlying are cancelled, i.e.
   1. Bid quote 10@$98
   2. Ask quote 10@$103

|  |  |
| --- | --- |
| Bid | Ask |
| 10@$99 (Y’s order) |  |
| 10@$97 (X’s order) |  |

**#FS10008\_S0030\_01300**

Example 2 – Incoming quote matches with a passive order

Market Maker X’s Quantity Protection = 5

|  |  |
| --- | --- |
| Bid | Ask |
| 10@$99 (Y’s order) | 10@$100 (Y’s order) |
| 10@$98 (X’s quote) | 10@$103 (X’s quote) |
| 10@$97 (X’s order) |  |

1. X enters a new quote (bid 10@$100, ask 10@$101)
2. The incoming bid quote item fully matches with Participant Y’s ask order 10@$100
3. MMP is triggered for X
4. All outstanding X’s quote in that underlying are cancelled
   1. Bid quote 10@$98
   2. Ask quote 10@$103
5. Ask quote item in the new quote (ask 10@$101) is rejected

|  |  |
| --- | --- |
| Bid | Ask |
| 10@$99 (Y’s order) |  |
| 10@$97 (X’s order) |  |

**#FS10008\_S0030\_01400**

Example 3 – Incoming quote matches with a passive quote

Market Maker X’s Quantity Protection = 50

Market Maker Y’s Quantity Protection = 5

|  |  |
| --- | --- |
| Bid | Ask |
| 10@$99 (Y’s quote) | 10@$100 (Y’s quote) |
| 10@$98 (X’s quote) | 10@$103 (X’s quote) |
| 10@$97 (X’s order) |  |

1. X enters a new quote (bid 10@$100, ask 10@$101)
2. The incoming bid quote item fully matches with Y’s ask quote 10@$100
3. MMP is triggered for Y
4. All outstanding Y’s quote in that underlying are cancelled
   1. Bid quote 10@$99
5. Ask quote item in the new quote (ask 10@$101) is added to order book

|  |  |  |
| --- | --- | --- |
| Bid | Ask |  |
| 10@$98 (X’s quote) | 10@$101 (X’s quote) |  |
| 10@$97 (X’s order) | 10@$103 (X’s quote) |  |

## Market Maker Protection Parameters

**#FS10008\_S0030\_01500**

MMP parameters can be managed by Business Operations and Exchange Participants (EP).

### Business Operations Configuration

**#FS10008\_S0030\_01600**

To enable MMP, Business Operations is required to configure MMP per EP per underlying with below attributes specified:

* Include futures: whether to consider futures quotes in MMP
* Quantity protection: limit of the total traded quantity per underlying within the exposure time interval; 0 means Quantity Protection is disabled
* Delta protection: limit of the delta value per underlying within the exposure time interval; 0 means Delta Protection is disabled
* Exposure time limit interval (in second): rolling time interval for calculating the protection limits; 0 means protection limits check is disabled
* Frozen time (in second): period of time interval that quotes will be rejected after the triggering of MMP; 0 means quotes will be rejected for the rest of the trading day

The above attributes can be updated intra-day with immediately effective. When the change is applied, all the calculated values will be reset and the frozen period will be effective for subsequent triggering of MMP.

**#FS10008\_S0030\_01610**

Default values of the above MMP attributes can be configured in the system. When creating a new MMP for an underlying for an EP, the MMP attributes will be automatically filled with the default values. Business Operations can manually adjust the values before submitting the request.

**#FS10008\_S0030\_01620**

For MMP creation, the system will search the list of underlying with the same issuer and active series on or after the MMP effective date

For MMP creation, the system will search the list of related underlying which is with the same underlying issuer as the specified underlying and with active instrument/combo. If MMP for the related underlying does not exist, the creation will be applied to those related underlying as well.

For MMP deletion, the system will search the list of related underlying which is with the same underlying issuer as the specified underlying (regardless with or without active instrument/combo). The deletion will be applied to those related underlying as well.

For example, the underlying issuer of underlying HKB and HKA is the same. When creating MMP for HKB for an EP, if MMP for HKA for that EP does not exist and HKA is with active instrument/combo, HKA will be considered as the related underlying and the MMP for HKA will be created as well. Similarly, when deleting MMP for HKB for an EP, if MMP for HKA for that EP does exist, MMP for HKA will be deleted as well.

**#FS10008\_S0030\_01700**

There is another set of per underlying configurations for Business Operations to control the setup of MMP for all EPs.

* Enable MMP: whether to enable MMP for this underlying for all EPs
* Minimum MM protection quantity: the floor for Quantity Protection and Delta Protection for all EPs

Both attributes can be updated intra-day with immediately effective. It should be noted that when the minimum MM protection quantity is changed, EPs’ protection limit will not be automatically adjusted even the setting is less than the new floor configured by Business Operations. For example, EP A’s quantity protection is set to 20 and minimum MM protection quantity is 10. If Business Operations update the minimum MM protection quantity to 30, EP A’s quantity protection will still be 20.

### Exchange Participant Configuration

**#FS10008\_S0030\_01800**

After MMP parameters is initially setup by Business Operations, the EP is allowed to update the following parameters per underlying via its own direct order flow sessions:

* Include futures
* Quantity protection
* Delta protection
* Exposure time limit interval (in second)
* Frozen time (in second)

An acknowledgment message will then be returned to indicate if the request is accepted or rejected.

If the same parameter is updated by Business Operations and the EP throughout the trading day, the latest will override the older one. Same as intra-day update by Business Operations, all the calculated values will be reset and the frozen period will be effective for subsequent trigger of MMP when the change from the EP is applied.

**#FS10008\_S0030\_01900**

The effective MMP parameters per underlying can be queried by the EP via its own direct order flow sessions.

1. An options is an instrument where its Instrument Group’s group type is Options [↑](#footnote-ref-2)
2. A futures is an instrument where its Instrument Group’s group type is Futures [↑](#footnote-ref-3)
