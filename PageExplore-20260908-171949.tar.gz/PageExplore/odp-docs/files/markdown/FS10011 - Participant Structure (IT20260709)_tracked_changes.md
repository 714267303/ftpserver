TITLE:

**FUNCTIONAL SPECIFICATION**

***ODP-T***

*FS10011 Participant Structure*

AUTHOR : *IT/Markets Systems*  DATE : *09 Jul 2026*

LAST REVIEW *Derivatives Trading Business Operations* DATE : *28 Feb 2025*

**CONTENTS**

[1. Document Control 3](#__RefHeading___Toc234959199)

[1.1. Change History 3](#__RefHeading___Toc234959200)

[1.2. Document Cross-referenced 4](#__RefHeading___Toc234959201)

[1.3. Abbreviation 4](#__RefHeading___Toc234959202)

[2. Introduction 5](#__RefHeading___Toc234959203)

[3. Logical Participant Structure 6](#__RefHeading___Toc234959204)

[3.1. Company 6](#__RefHeading___Toc234959205)

[3.2. Exchange Participant 7](#__RefHeading___Toc234959206)

[3.3. Sponsoring Participant 7](#__RefHeading___Toc234959207)

[3.4. Session 8](#__RefHeading___Toc234959208)

[3.4.1. Order Flow Session 9](#__RefHeading___Toc234959209)

[3.4.2. Drop Copy Session 10](#__RefHeading___Toc234959210)

[3.4.3. PTRM Session 11](#__RefHeading___Toc234959211)

[3.5. GUI User 11](#__RefHeading___Toc234959212)

[3.5.1. Trading GUI User 11](#__RefHeading___Toc234959213)

[3.5.2. PTRM GUI User 11](#__RefHeading___Toc234959214)

[3.5.3. Self Admin Portal User 12](#__RefHeading___Toc234959215)

[3.6. Participant User Role 13](#__RefHeading___Toc234959216)

[3.7. Trading Rights 14](#__RefHeading___Toc234959217)

[3.8. Password Policy 15](#__RefHeading___Toc234959218)

[4. Participant Operations 17](#__RefHeading___Toc234959219)

[4.1. Company 17](#__RefHeading___Toc234959220)

[4.1.1. Attributes 17](#__RefHeading___Toc234959221)

[4.2. Exchange Participant 18](#__RefHeading___Toc234959222)

[4.2.1. Attributes 18](#__RefHeading___Toc234959223)

[4.2.2. Intra-day Operations 18](#__RefHeading___Toc234959224)

[4.3. Sponsoring Participant 19](#__RefHeading___Toc234959225)

[4.3.1. Attributes 19](#__RefHeading___Toc234959226)

[4.3.2. Intra-day Operations 19](#__RefHeading___Toc234959227)

[4.4. Direct Order Flow Session 20](#__RefHeading___Toc234959228)

[4.4.1. Attributes 20](#__RefHeading___Toc234959229)

[4.4.2. Intra-day Operations 21](#__RefHeading___Toc234959230)

[4.5. Trading GUI User 21](#__RefHeading___Toc234959231)

[4.5.1. Attributes 22](#__RefHeading___Toc234959232)

[4.5.2. Intra-day Operations 23](#__RefHeading___Toc234959233)

[4.6. Direct Drop Copy Session 23](#__RefHeading___Toc234959234)

[4.6.1. Attributes 23](#__RefHeading___Toc234959235)

[4.6.2. Intra-day Operations 24](#__RefHeading___Toc234959236)

[4.7. Drop Copy Group 24](#__RefHeading___Toc234959237)

[4.7.1. Attributes 24](#__RefHeading___Toc234959238)

[4.8. PTRM GUI User 25](#__RefHeading___Toc234959239)

[4.8.1. Attributes 25](#__RefHeading___Toc234959240)

[4.8.2. Intra-day Operations 26](#__RefHeading___Toc234959241)

[4.9. Self Admin Portal User 26](#__RefHeading___Toc234959242)

[4.9.1. Attributes 26](#__RefHeading___Toc234959243)

[4.9.2. Intra-day Operations 27](#__RefHeading___Toc234959244)

[A. Appendix A – EIDP and ODP Trading Relationship and User Setup 28](#__RefHeading___Toc234959245)

# Document Control

## Change History

|  |  |  |  |
| --- | --- | --- | --- |
| Version  Number | Issue Date | Author | Abstract |
| 0.1 | 16 Jul 2024 | IT/Markets Systems | Initial Version |
| 0.2 | 30 Aug 2024 | IT/Markets Systems | Revised based on review comments from business users |
| 0.3 | 18 Oct 2024 | IT/Markets Systems | Revised based on review comments from business users |
| 0.4 | 29 Oct 2024 | IT/Markets Systems | Revised based on review comments from business users |
| 0.5 | 6 Dec 2024 | IT/Markets Systems | Revised based on review comments from business users  Added Self Admin Portal User |
| 0.6 | 27 Dec 2024 | IT/Markets Systems | Updated for EIDP integration |
| 0.7 | 23 Jan 2025 | IT/Markets Systems | Revised based on review comments from business users  Updated for EIDP integration |
| 0.8 | 3 Jun 2025 | IT/Markets Systems | Added “Receive Non-Critical Market Messages” attribute to Order Flow Session  Updated not to cancel pending block trades when a Direct Order Flow Session /Trading GUI User is blocked |
| 0.9 | 13 Apr 2026 | IT/Markets Systems | Updated for PSG & CGW  Updated for EIDP integration |
| 0.10 | 15 Jun 2026 | IT/Markets Systems | Revised based on review comments from business users |
| 0.11 | 09 Jul 2026 | IT/Markets Systems | Revised based on review comments from business users |

## Document Cross-referenced

|  |  |  |
| --- | --- | --- |
| # | Document | Version |
| 1 | BRD\_DT\_0002 BRS Order Management | 20250109 |
| 2 | BRD\_DT\_0004 Market Integrity Safeguards | 20250115 |
| 3 | BRD\_DT\_0005 BRS Trading Operations | 20250530 |
| 4 | BRD\_DT\_0006 BRS Drop Copy | 20240423 |
| 5 | BRD\_DT\_0008 ODP - NewFunctionRequest - Block Trade Facility | 20250506 |
| 6 | BRD\_DT\_0019 BRS\_Pre Trade Risk Management | 20250110 |
| 7 | BRD\_DT\_0027 NEW WISH 007 Connectivity Protocol | 20240628 |
| 8 | BRD\_DT\_0043 BRS EP Onboarding | 20240427 |
| 9 | BRD\_DT\_0044 BRS BAU Support | 20250529 |
| 10 | BRD\_DT\_0048 New Wish 018 System Security | 20240628 |
| 11 | BRD\_DT\_0050 BRS\_PDMPA functions in ODP | 20250528 |
| 12 | FS10002 – Order Management | 20250512 |
| 13 | FS10005 – Pre-Trade Risk Management | 20250217 |
| 14 | FS10006 – Block Trade | 20250410 |
| 15 | FS10007 – Self Match Prevention (SMP) | 20250342 |
| 16 | FS10008 – Market Maker Protection | 20250531 |
| 17 | FS10010 – Product Structure | 20250324 |
| 18 | FS10013 – Market Operation Admin GUI | 20250530 |
| 19 | FS10018 - EP Self Admin Portal | 20250324 |

## Abbreviation

|  |  |
| --- | --- |
| ASP | Application Service Provider |
| CGW | Convenience Gateway |
| EP | Exchange Participant |
| MMP | Market Maker Protection |
| ODP-T | Orion Derivatives Platform – Trading |
| PSG | Partition Specific Gateway |
| PTRM | Pre-Trade Risk Management |
| SMP | Self Match Prevention |

# Introduction

**#FS10011\_S0020\_00100**

Participant structure describes the participant hierarchy defined in the system to facilitate trading functionalities according to the participant level and permissions.

Business Operations can setup, maintain and control the participant trading activities via Admin GUI.

# Logical Participant Structure

**#FS10011\_S0030\_00100**

Logical participant structure is illustrated in the diagram and defined in the text below:

![](data:image/x-wmf;base64...)

It should be noted that exchange users for Admin GUI, Trading GUI and PTRM GUI access are intended not to be covered in the participant structure. Refer to Functional Specification “FS10013 - Market Operation Admin GUI” for the details of exchange user management.

## Company

**#FS10011\_S0030\_00150**

A company is an entity in the topmost level of participant structure, representing a firm to have business engagements.

Each company is identified using a Company ID. Each Company ID is unique within the system. This ID is linked to an EIDP Company.

The following attributes can be setup at Company level:

|  |  |
| --- | --- |
| Attributes | Description |
| Company ID | Company ID |
| Company Name | Company Name |
| Description | Complete name of company |

## Exchange Participant

**#FS10011\_S0030\_00200**

An exchange participant (EP) is an entity under a company entity and connected to an exchange entity where its sessions (i.e. connection to the system, refer to Section 3.4.) are granted access to the system and perform different types of trading activities depending on the rights assigned to the participant hierarchy.

Each EP is identified using a Participant ID. Each Participant ID is unique across all EPs within the system. This ID is linked to an EIDP Identity (Trading Participant).

The following attributes can be setup at EP level:

|  |  |
| --- | --- |
| Attributes | Description |
| Exchange | Exchange |
| Company ID | Company ID |
| Description | Complete name of participant |
| Participant Trading rights | Trading rights of products granted to EP  Refer to Section 3.7. |
| Number of missing HB | Default number of missing session heartbeat.  Refer to Functional Specification “FS10002 - Order Management” |
| Timeout before COD | Default timeout before cancel on disconnect  Refer to Functional Specification “FS10002 - Order Management” |
| Allowed block trade group | Allowed block trade functions  Refer to Functional Specification “FS10006 - Block Trade” |
| SMP ID list | Self match prevention mode and ID list  Refer to Functional Specification “FS10007 - Self Match Prevention (SMP)” |
| Market maker protection parameters | Per Underlying MMP parameters including protection limit, exposure time interval, frozen period, etc.  Refer to Functional Specification “FS10008 - Market Maker Protection” |
| Nominated error trade claim session | Nominated order flow session for error trade claim  Refer to Functional Specification “FS10009 - Error Trade, Trade Cancellation and Adjustment” |

Each EP in the system is considered as independent. The system does not impose any validation rules to disallow a firm to register multiple EPs for its internal use as well as serving its institutional clients, or an institutional client to trade via multiple EPs.

## Sponsoring Participant

**#FS10011\_S0030\_00300**

A sponsoring participant is an entity under a company entity and connected to an exchange entity where its sessions are granted access to the system solely for managing the pre-trade risk of one or more its sponsored exchange participants, i.e. pre-trade risk management (PTRM) functions.

Each sponsoring participant is identified using a Participant ID. Each Participant ID is unique across all sponsoring participants within the system. This ID is linked to an EIDP Identity (Sponsoring Participant).

The following attributes can be setup at Sponsoring Participant level:

|  |  |
| --- | --- |
| Attributes | Description |
| Exchange | Exchange |
| Company ID | Company ID |
| Description | Complete name of participant |
| List of sponsored exchange participants | Sponsored exchange participants list  Refer to Functional Specification “FS10005 - Pre Trade Risk Management (PTRM)” |

Each sponsoring participant in the system is considered as independent. The system does not impose any validation rules to disallow a firm to register multiple sponsoring participants.

## Session

**#FS10011\_S0030\_00400**

A session is a connection, under an EP or a sponsoring participant, that facilitates access to the system for trading activities.

Each session is identified using a Comp ID. This Comp ID is unique within the system across all types of sessions.

The following attributes can be setup at session level:

|  |  |
| --- | --- |
| Attributes | Description |
| Service type | Type of session for different services:   * Order Flow – PSG (refer to Section 3.4.1.) * Order Flow – CGW (refer to Section 3.4.1.) * Drop Copy (refer to Section 3.4.2.) * PTRM (refer to Section 3.4.3.) |
| Session usage | Usage of session:   * Direct access (for EP direct access) * UI access (for UI interface) |
| Partition ID | Assigned gateway partition  The system, on a regular basis (e.g. quarterly), re-assigns the session to the corresponding gateway partition based on session usage, interface protocol and other technical considerations. |
| Sub Partition ID | Assigned gateway sub partition (applicable for Order Flow – PSG only)  The system, on a regular basis (e.g. quarterly), re-assigns the session to the corresponding gateway sub partition based on session usage, interface protocol and other technical considerations. |
| Interface protocol | Interface protocol:   * Binary |
| Legal IP addresses | A list of valid IP addresses. Session connection must be established from an IP address in the list.  An IP address list is allowed to be associated with more than one session. It is also allowed for a list of IP addresses to be shared among different participants1. |
| Password | Password for session logon  A system level password policy (refer to Section 3.8.) is applied. |
| Number of missing HB | Number of missing session heartbeat  Refer to Functional Specification “FS10002 - Order Management” |

1 IT has raised concerns on potential security risks on allowing the same IP address to be shared among different participants. Business is aware of the concerns and is decided to proceed with this arrangement given Application Service Provider (ASP) Programme is an existing business use case that allowing different EPs to access the system directly through an ASP using the same set of IP addresses.

### Order Flow Session

**#FS10011\_S0030\_00500**

An order flow session provides EP access to the system for order, trade and quote management. It can be a partition specific gateway (PSG) or a convenience gateway (CGW) session.

The following additional session attributes can be setup for an order flow session:

|  |  |
| --- | --- |
| Attributes | Description |
| Timeout before COD | Session specific timeout before cancel on disconnect  Refer to Functional Specification “FS10002 - Order Management” |
| Order throttle | Throttle rate (i.e. transaction per second, TPS), which governs the rate of business messages that can be submitted per throttle interval |
| Receive non-critical market messages | Flag to specify if non-critical market message is received |

#### Trader ID

**#FS10011\_S0030\_00600**

A Trader ID is a unique ID within the system assigned to EP for trading. This ID is used to identify the owner of orders and trades.

The following attributes can be setup at Trader ID level:

|  |  |
| --- | --- |
| Attributes | Description |
| Participant user role | Business functions and UI functions permission granted to the Trader ID  Refer to Section 3.6. |
| Trading rights | Trading rights of products granted to the Trader ID  Refer to Section 3.7. |

**#FS10011\_S0030\_00700**

Each Trader ID is associated with an order flow session. An order flow session has one Trader ID only, i.e. order flow session to Trader ID is a one-to-one mapping. Orders and quotes submitted are implicitly owned by the associated Trader ID.

For EP to access via Trading GUI, the Trading GUI User (refer to Section 3.5.1.) is mapped to one Trader ID for facilitating the trading activities.

**#FS10011\_S0030\_00800**

A Trader ID for EP direct access must be associated with a direct access session, while a Trader ID for Trading GUI access must be associated with an UI access session.

*Design Consideration*

*The participant structure design is flexible to support an order flow session serving one or more Trader IDs. Orders and quotes submitted via the session are owned by the submitting Trader ID which is specified in the order/quote request. However, in ODP Trading Day 1 implementation, an order flow session is restricted to have one Trader ID only and the submitting Trade ID is implicitly assigned by the system.*

### Drop Copy Session

**#FS10011\_S0030\_01000**

A drop copy session has assignments of one or more drop copy groups under the same EP.

**#FS10011\_S0030\_01100**

A drop copy group is a group of one or more Trader IDs under the same EP. A Trader ID can be in none of, one or many drop copy groups.

**#FS10011\_S0030\_01200**

A drop copy session allows an EP to receive drop copy of order and trade events that were for Trader IDs belonging to the drop copy groups assigned.

In addition to assigned drop copy groups, below attributes can be setup for a drop copy session:

|  |  |
| --- | --- |
| Attributes | Description |
| Entitled data types | Include trades and/or orders:   * Trades only * Orders and trades |
| Entitled product types | Access group by type (i.e. a group of Instrument Types and Combo Types) |

### PTRM Session

**#FS10011\_S0030\_01300**

A PTRM session is a session for an EP or a sponsoring participant managing and monitoring PTRM functions.

The following additional session attributes can be setup for PTRM session:

|  |  |
| --- | --- |
| Attributes | Description |
| PTRM throttle | Throttle rate (i.e. transaction per second, TPS), which governs the rate of business messages that can be submitted per throttle interval.  A transaction may contain more than one PTRM limit update. A pre-defined limit restricts the max number of updates supported in one transaction.  Refer to Functional Specification “FS10005 – Pre Trade Risk Management” |

## GUI User

### Trading GUI User

**#FS10011\_S0030\_00900**

A Trading GUI User in the system is an entity to link up with an EIDP User with access right to Trading GUI for a EP. A Trading GUI User is mapped to a Trader ID, which is a one-to-one mapping, for facilitating the permission and trading rights setup and for trading. No trading activities can be accessed or performed before the initial setup of the Trading GUI User.

The following attributes can be setup at Trading GUI User level:

|  |  |
| --- | --- |
| Attributes | Description |
| Legal Browser IP addresses | A list of valid IP addresses. Browser connection to Trading GUI must be established from an IP address in the list.  An IP address list is allowed to be associated with more than one Trading GUI User. It is also allowed for a list of IP addresses to be shared among different participants1. |

1 For EP contingency arrangement, EPs may apply to access Trading GUI from SOS centre in HKEX premise.

### PTRM GUI User

**#FS10011\_S0030\_01400**

A PTRM GUI User in the system is an entity to link up with an EIDP User with access right to PTRM GUI for a EP or a sponsoring participant. Each PTRM GUI User is associated with a PTRM session. A PTRM session has one PTRM GUI User only, i.e. PTRM session to PTRM GUI User is a one-to-one mapping.

Sponsoring participants and their sponsored exchange participants can access PTRM functions via PTRM GUI only.

The following attributes can be setup at PTRM GUI user level:

|  |  |
| --- | --- |
| Attributes | Description |
| Participant user role | Business functions and UI functions permission granted to the PTRM GUI user  Sponsoring participant’s PTRM GUI user must be assigned with a participant user role, where its type = PTRM GUI (Risk Limit Manager  Exchange participant’s PTRM GUI user must be assigned with a participant user role, where its type = PTRM GUI (Trading Unit)  Refer to Section 3.6. |
| Legal Browser IP addresses | A list of valid IP addresses. Browser connection to PTRM GUI must be established from an IP address in the list.  An IP address list is allowed to be associated with more than one PTRM GUI User. It is also allowed for a list of IP addresses to be shared among different participants. |

1 For EP contingency arrangement, EPs may apply to access PTRM GUI from SOS centre in HKEX premise.

*Design Consideration*

*The participant structure design is flexible to support a PTRM session serving one or more PTRM GUI Users. However, in ODP Trading Day 1 implementation, a PTRM session is restricted to have one PTRM GUI user only.*

### Self Admin Portal User

**#FS10011\_S0030\_01405**

A Self Admin Portal User in the system is an entity to link up with an EIDP User with access right to Self Admin Portal for a EP.

The following attributes can be setup at Self Admin Portal User level:

|  |  |
| --- | --- |
| Attributes | Description |
| Legal Browser IP addresses | A list of valid IP addresses. Browser connection to Self Admin Portal must be established from an IP address in the list.  An IP address list is allowed to be associated with more than one Self Admin Portal User. It is also allowed for a list of IP addresses to be shared among different participants1. |

1 For EP contingency arrangement, EPs may apply to access Self Admin Portal from SOS centre in HKEX premise

## Participant User Role

**#FS10011\_S0030\_01500**

A participant user role is for managing the list of trading functionalities that can be accessed and performed. A participant user role can be assigned to a Trader ID or a PTRM GUI User.

The following attributes can be setup for a participant user role:

|  |  |
| --- | --- |
| Attributes | Description |
| Participant user type | Type of participant user:   * Direct access (trading) * Trading GUI * **#FS10011\_S0030\_01510** PTRM GUI (Trading Unit) * **#FS10011\_S0030\_01520** PTRM GUI (Risk Limit Manager) |
| List of business functions allowed | Business functions allowed to perform  Business functions applicable for each participant user type is predefined (refer to the table below). There must be at least one business functions allowed for a participant user role. |
| Allowed block trade group | Allowed block trade functions  Not applicable for PTRM GUI  Refer to Function Specification “FS10006 – Block Trade” |
| UI user role | List of UI permission  Not applicable for direct access (trading)  Refer to Function Specification “FS10013 - Market Operation Admin GUI” |

The following lists the business functions applicable for each user type:

|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | Applicable Business Functions | | | | | | | | | | | | | | | | | | | | |
|  | Trading-related | | | | | | | | | | | | | | | PTRM-related | | | | | |
|  | Order Entry | Order Amend | Order Cancel | Order Mass Cancel | OBO Order Cancel | OBO Order Mass Cancel | Quote Request | Single Quote | Mass Quote | Block Trade | Error Trade Claim | TMC Creation | MMP Parameter Update | Trading Kill Switch | Stop PTLG | | Unstop PTLG | PTRM Mass Cancel | PTRM Kill Switch | Unblock Breached Risk Check | PTRM Parameter Update |
| Participant user type |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | |  |  |  |  |  |
| Direct access (trading) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | |  |  |  |  |  |
| Trading GUI |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | |  |  |  |  |  |
| PTRM GUI  (Trading Unit) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | |  |  |  |  |  |
| PTRM GUI  (Risk Limit Manager) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | |  |  |  |  |  |

## Trading Rights

**#FS10011\_S0030\_01600**

To allow to trade a product, the trading rights of the product must be granted at both EP level and Trader ID level.

At EP level, the participant trading rights is granted per Instrument Type with below attributes:

|  |  |
| --- | --- |
| Attributes | Description |
| Order size limit | Maximum order quantity allowed  Default order size limit can be configured per Instrument Type. When granting a new trading right, the order size limit will be automatically filled with the default value. Business Operations can manually update the limit value.  It should be noted that 0 is a valid value meaning no limit is imposed, while a warning message will be prompted to alert Business Operations if 0 is set |
| Block trade size limit | Maximum block trade quantity allowed  Default block trade size limit can be configured per Instrument Type. When granting a new trading right, the block trade size limit will be automatically filled with the default value. Business Operations can manually update the limit value.  It should be noted that 0 is a valid value meaning no limit is imposed, while a warning message will be prompted to alert Business Operations if 0 is set |
| Default account | Default clearing account  There is for information only. There is no processing and validation logic on this attribute in the system. |

**#FS10011\_S0030\_01700**

At Trader ID level, the trading rights is granted per access group by type (i.e. a group of Instrument Types and Combo Types) with below attributes:

|  |  |
| --- | --- |
| Attributes | Description |
| Order size limit | Maximum order quantity allowed  Not specified if value = 0 |
| Block trade size limit | Maximum block trade quantity allowed  Not specified if value = 0 |

It should be noted that an EP is implicitly entitled to a Combo Type where the Instrument Types of all its legs are entitled. While at Trader ID level, the trading rights of Combo Types are required to be granted explicitly.

**#FS10011\_S0030\_01800**

For order size limit and block trade size limit, below are the rules to deduce the effective limit for a Trader ID:

|  |  |  |
| --- | --- | --- |
| Instrument Type / Combo Type | Specified at Trader ID level? | Effective limit |
| Instrument Type | Yes | Limit specified at Trader ID level |
| No | Limit specified at EP level |
| Combo Type | Yes | Limit specified at Trader ID level |
| No | Lowest limit among all legs |

## Password Policy

**#FS10011\_S0030\_01900**

A password policy is a pre-configured set of rules to defines the password requirements applied to the password managed by the system. Separate password policies can be configured and applied to different type of accounts. It should be noted that password policies cannot be changed by Business Operations via Admin GUI.

The following attributes can be setup for a password policy:

|  |  |
| --- | --- |
| Attributes | Description |
| Policy Type | Policy type:   * Internal * External |
| Minimum Password Length | Minimum length of a password |
| Maximum Password Length | Maximum length of a password |
| Minimum Upper Case Letters | Minimum number of upper case letters required |
| Minimum Lower Case Letters | Minimum number of lower case letters required |
| Minimum Digits | Minimum number of digits (i.e. 0-9) required |
| Minimum Special Characters | Minimum number of special characters required |
| Password Validity Period | Password validity period, specified in days |
| Password Expiry Advance Alert | Advance alert on password expiry, specified in days |
| Enforce Password Expiry Check? | Whether enforce password expiry check? |
| Password Reuse Cycle | Number of historical passwords that can’t be reused |
| Number of Failed Attempts | Number of failed attempts allowed, account will be locked if exceeded |
| Change Password on 1st Logon? | Whether required to change password on the first logon? |
| Maximum Password Changes Per Day | Maximum number of password change allowed per day |
| Inactivity Period | Inactivity period, specified in days (i.e. account will be considered as inactive if there is no successful logon for the specified inactivity period) |
| Password Expiry and Inactivity Handling | Handling of password expired and account inactive:   * Lock Account * Force Change Password |

# Participant Operations

**#FS10011\_S0040\_00100**

In operation perspective, entities in the participant structure are logically grouped and can be setup and maintained via individual Admin GUI functions:

|  |  |
| --- | --- |
| Admin GUI Function | Entities in Participant Structure |
| Maintain Company | Company |
| Maintain Exchange Participant | Exchange Participant |
| Maintain Sponsoring Participant | Sponsoring Participant |
| Maintain Direct Order Flow Session | Order Flow Session  Trader ID |
| Maintain Trading GUI User | Order Flow Session  Trader ID  Trading GUI User |
| Maintain Drop Copy Session | Drop Copy Session |
| Maintain Drop Copy Group | Drop Copy Group |
| Maintain PTRM GUI User | PTRM Session  PTRM GUI User |
| Maintain Self Admin Portal | Self Admin Portal User |

Unless specified, updates of participant related attributes are effective in next trading day. Business Operations are allowed to perform specified intra-day operations to control the participant trading activities with immediate effect via Admin UI and the corresponding changes will be persisted to next trading day.

## Company

**#FS10011\_S0040\_00150**

Companies are created and maintained by Business Operations using “Maintain Company” function in Admin GUI. When a Company record is created, the record will link to an existing EIDP Company or a corresponding EIDP Company will be created.

### Attributes

Below are the attributes for a Company:

|  |  |  |
| --- | --- | --- |
| Attribute | Managed By System | Remarks |
| Company Level | | |
| Company ID |  | Cannot be changed after creation |
| IDP Company ID |  | EIDP Company unique identifier, assigned by EIDP |
| Company Name |  | Link to an EIDP Company  Cannot be changed after creation |
| Company UUID |  | UUID assigned by EIDP |
| Description |  |  |

## Exchange Participant

**#FS10011\_S0040\_00200**

Exchange participants are created and maintained by Business Operations using “Maintain Exchange Participant” function in Admin GUI. When an EP record is created, the corresponding EIDP Identity (Trading Participant) will also be created.

### Attributes

Below are the attributes for an EP:

|  |  |  |
| --- | --- | --- |
| Attribute | Managed By System | Remarks |
| Exchange Participant Level | | |
| Exchange Participant |  | Link to an EIDP Identity  Cannot be changed after creation |
| Exchange |  | Cannot be changed after creation |
| Company ID |  | Cannot be changed after creation |
| Description |  |  |
| Suspended? |  | Allow to suspend/resume with immediate effect by Business Operations |
| Number of Missing HB |  |  |
| Timeout before COD |  |  |
| Allowed Block Trade Group |  |  |
| SMP ID List |  | A table with below column:   * SMP ID |
| Nominated Error Trade Session Usage |  |  |
| Nominated Error Trade Session ID |  |  |
| Trading Rights |  | A table with below columns:   * Instrument Type * Order Size Limit * Block Trade Size Limit * Default Account |

### Intra-day Operations

**#FS10011\_S0040\_00300**

The following are the operations can be performed intra-day for an EP:

|  |  |
| --- | --- |
| Operations | Description |
| Suspend/Resume | When an EP is suspended,   * no more trading activities (including order related and PTRM) are allowed1 * all open orders/quotes and unmatched block trades are cancelled by the system2 |
| Block/Unblock for a specific product (via Control Block/Unblock Participant Per Product) | An EP can be blocked at different product levels, i.e. Market, Instrument Type and Instrument Class level. A product will be considered as blocked if any level of its product hierarchy is blocked. A combo will be considered as blocked if any of its legs is blocked.  A product can be blocked and unblocked multiple times during a trading day.  When an EP is blocked for a specific product,   * all order, quote and block trades related transactions for the blocked product are rejected (For mass quote transaction, only the quote pairs for the blocked product within the mass quote transaction are rejected; For multi-leg block trade, the whole block trade is rejected) * TMC creation of the blocked product is rejected * all open orders/quotes and unmatched block trades for the concerned product are cancelled by the system1 |

1 Please refer to *Appendix B* for details. 2 Cancellation is at best effort basis. If the cancellation is triggered at a trading state in which admin order cancel operation is not allowed, the open orders/quotes and unmatched block trades will not be cancelled. Any non-cancelled orders/quotes and unmatched block trades may be matched, and EP cannot get the trades via its sessions and GUI users.

## Sponsoring Participant

**#FS10011\_S0040\_00400**

Sponsoring participants are created and maintained by Business Operations using “Maintain Sponsoring Participant” function in Admin GUI. When a sponsoring participant record is created, the corresponding EIDP Identity (Sponsoring Participant) will also be created.

The relationship between a sponsoring participant and its sponsored exchange participants are setup and maintained by Business Operations.

### Attributes

Below are the attributes for a sponsoring participant:

|  |  |  |
| --- | --- | --- |
| Attributes | Managed By System | Remarks |
| Sponsoring Participant Level | | |
| Sponsoring Participant |  | Link to an EIDP Identity  Cannot be changed after creation |
| Exchange |  | Cannot be changed after creation |
| Company ID |  | Cannot be changed after creation |
| Description |  |  |
| Suspended? |  | Allow to suspend/resume with immediate effect by Business Operations |
| List of sponsored Exchange Participants |  | A table with below column:   * Exchange Participant |

### Intra-day Operations

**#FS10011\_S0040\_00500**

The following are the operations can be performed intra-day for a sponsoring participant:

|  |  |
| --- | --- |
| Operations | Description |
| Suspend/Resume | When a sponsoring participant is suspended,   * no more PTRM activities are allowed1 * all sessions belonging to the suspended sponsoring participant cannot be logged on; already established sessions are forced logout |

1 Please refer to *Appendix B* for details.

## Direct Order Flow Session

**#FS10011\_S0040\_00600**

Direct order flow sessions are setup and maintained by Business Operations for EP direct access to the system for trading using “Maintain Direct Order Flow Session” function in Admin GUI.

When a direct order flow session is created, the system automatically generates a Trader ID to associate with the session for facilitating the trading activities. The relationship between the session and the Trader ID is a one-to-one mapping.

### Attributes

Below are the attributes for a direct order flow session (attributes managed by system are read-only attributes which cannot be updated by Business Operations):

|  |  |  |
| --- | --- | --- |
| Attributes | Managed By System | Remarks |
| Session Level | | |
| Comp ID |  | Cannot be changed after creation |
| Exchange Participant |  | Cannot be changed after creation |
| Service Type |  | Either one of below:   * Order Flow – PSG * Order Flow – CGW |
| Session Usage |  | Direct access |
| Partition ID |  |  |
| Sub Partition ID |  | Applicable for Order Flow – PSG only |
| Interface Protocol |  | Binary |
| Blocked? |  | Allow to block/unblock with immediate effect by Business Operations |
| Blocked Reason |  |  |
| Locked? |  | Allow to unlock with immediate effect by Business Operations |
| Legal IP Addresses |  | Allow to update with immediate effect by Business Operations |
| Password |  | Masked, cannot be viewed by Business Operations |
| Password Policy ID |  |  |
| Number of Missing HB |  |  |
| Last Successful Login Time |  |  |
| Password Expiration Date |  |  |
| Order Flow Session Level | | |
| Timeout before COD |  |  |
| Order Throttle |  |  |
| Receive Non-Critical Market Messages |  |  |
| Trader ID Level | | |
| Trader ID |  | Assigned by system (equal to Comp ID) |
| Participant User Role |  | Must be with participant user type = Direct access (trading) |
| Trading Rights |  |  |

### Intra-day Operations

**#FS10011\_S0040\_00700**

The following are the operations can be performed intra-day for a direct order flow session:

|  |  |
| --- | --- |
| Operations | Description |
| Block1/Unblock | When a direct order flow session is blocked,   * all open orders/quotes are cancelled by the system2 * session is forced logout and cannot be logged on |
| Unlock | A direct order flow session may be locked by the system (e.g. password expired or failed logon attempted exceeded the limit). The session cannot be logged on once locked. The session requires to be unlocked by Business Operations. |
| Change Password | Session password can be changed manually. The new password must fulfil the requirements defined in the applied password policy. It should be noted that resetting a new password will not unblock or unlock the session. |
| Update Legal IP Addresses | The IP address list can be updated with immediately effective.  The entries in the IP address list can also updated with immediately. |

1 Please refer to *Appendix B* for details. 2 Cancellation is at best effort basis. If the cancellation is triggered at a trading state in which admin order cancel operation is not allowed, the open orders/quotes will not be cancelled.

## Trading GUI User

**#FS10011\_S0040\_00800**

EP accesses Trading GUI using an EIDP User with access right to Trading GUI. Business Operations initially setup and manage Trading GUI User using “Maintain Trading GUI User” function in Admin GUI. When a new Trading GUI User is created from Admin GUI, it must be linked with an existing EIDP User.

Once the initial setup is completed, the system will automatically generate an order flow session and a Trader ID for facilitating the trading activities. Both session to Trader ID and Trader ID to Trading GUI User are one-to-one mapping relationship.

### Attributes

Below are the attributes for a Trading GUI User (attributes managed by system are read-only attributes which cannot be updated by Business Operations):

|  |  |  |
| --- | --- | --- |
| Attributes | Managed By System | Remarks |
| Trading GUI User Level | | |
| User ID |  | Cannot be changed after creation |
| IDP User ID |  | Link to an EIDP User  Cannot be changed after creation |
| Exchange Participant |  | Cannot be changed after creation |
| Suspended? |  | Allow to suspend/resume with immediate effect by Business Operations |
| Legal Browser IP Addresses |  | Allow to update with immediate effect by Business Operations |
| EIDP User Level | | |
| EIDP Locked? |  | Managed by EIDP |
| Session Level | | |
| Comp ID |  | Cannot be changed after creation |
| Service Type |  | Order Flow – CGW |
| Session Usage |  | UI access |
| Partition ID |  |  |
| Sub Partition ID |  | Must be 0 |
| Interface Protocol |  | Binary |
| Blocked? |  | Allow to block/unblock with immediate effect by Business Operations |
| Locked? |  |  |
| Legal IP Addresses |  | IP addresses of Trading GUI backend infrastructure |
| Password |  | Masked, cannot be viewed by Business Operations  Technical configuration for Trading GUI backend |
| Password Policy ID |  |  |
| Number of Missing HB |  | A system-wise configuration for all Trading/PTRM GUI User |
| Last Successful Login Time |  |  |
| Password Expiration Date |  |  |
| Order Flow Session Level | | |
| Timeout before COD |  | A system-wise configuration for all Trading/ GUI User |
| Order Throttle |  |  |
| Receive Non-Critical Market Messages |  | Must be “Y” |
| Trader ID Level | | |
| Trader ID |  | Assigned by system (equal to Comp ID) |
| User Role |  | Must be with user type = Trading GUI |
| Trading Rights |  |  |

### Intra-day Operations

**#FS10011\_S0040\_00900**

The following are the operations can be performed intra-day for a Trading GUI user:

|  |  |
| --- | --- |
| Operations | Description |
| Suspend/Resume | When a Trading GUI user is suspended,   * user cannot perform any trading functions1 * user is forced logout and cannot be logged on |
| Block/Unblock | When a Trading GUI user is blocked,   * all open orders/quotes are cancelled by the system1 * session is forced logout and cannot be logged on |
| Update Legal Browser IP Addresses | The IP address list can be updated with immediately effective.  The entries in the IP address list can also updated with immediately. |
| Reset Password (EIDP) | When a Trading GUI user is locked by EIDP, Business Operations can trigger EIDP user reset password flow (which will unlock the user account and trigger password reset by the user) |

1 Please refer to *Appendix B* for details. 2 Cancellation is at best effort basis. If the cancellation is triggered at a trading state in which admin order cancel operation is not allowed, the open orders/quotes will not be cancelled.

## Direct Drop Copy Session

**#FS10011\_S0040\_01000**

Direct drop copy sessions are setup and maintained by Business Operations for EPs’ drop copy services using “Maintain Direct Drop Copy Session” function in Admin GUI.

### Attributes

Below are the attributes for a direct drop copy session:

|  |  |  |
| --- | --- | --- |
| Attributes | Managed By System | Remarks |
| Session Level | | |
| Comp ID |  | Cannot be changed after creation |
| Exchange participant |  | Cannot be changed after creation |
| Service type |  | Drop Copy |
| Session usage |  | Direct access |
| Partition ID |  |  |
| Sub Partition ID |  | Must be 0 |
| Interface protocol |  | Binary |
| Blocked? |  | Allow to block/unblock with immediate effect by Business Operations |
| Locked? |  | Allow to unlock with immediate effect by Business Operations |
| Legal IP addresses |  | Allow to update with immediate effect by Business Operations |
| Password |  | Masked, cannot be viewed by Business Operations |
| Password Policy ID |  |  |
| Number of Allowed Missing HB |  |  |
| Last Successful Login Time |  |  |
| Password Expiration Date |  |  |
| Drop Copy Session Level | | |
| Entitled Data Types |  |  |
| Entitled Product Types |  |  |
| List of Drop Copy Groups |  | A table with below column:   * Drop Copy Group |

### Intra-day Operations

**#FS10011\_S0040\_01100**

The following are the operations can be performed intra-day for a direct drop copy session:

|  |  |
| --- | --- |
| Operations | Description |
| Block/Unblock | When a direct drop copy session is blocked,   * session is forced logout and cannot be logged on |
| Unlock | A direct drop copy session may be locked by the system (e.g. password expired or failed logon attempted exceeded the limit) The session cannot be logged on once locked. The session requires to be unlocked by Business Operations. |
| Change Password | Session password can be changed manually. The new password must fulfil the requirements defined in the applied password policy. It should be noted that resetting a new password will not unblock or unlock the session. |
| Update Legal IP Addresses | The IP address list can be updated with immediately effective.  The entries in the IP address list can also updated with immediately. |

## Drop Copy Group

**#FS10011\_S0040\_01200**

Drop copy groups are setup and maintained by Business Operations using “Maintain Drop Copy Group” function in Admin GUI.

Business Operations can add/remove direct order flow sessions and Trading GUI Users to/from the drop copy group belonging to the same EP. They system will automatically manage the relationship between the drop copy group and the Trader ID of the corresponding direct order flow sessions/Trading GUI Users.

### Attributes

Below are the attributes for a drop copy group:

|  |  |  |
| --- | --- | --- |
| Attributes | Managed By System | Remarks |
| Session Level | | |
| Drop Copy Group |  | Cannot be changed after creation |
| Exchange participant |  | Cannot be changed after creation |
| Description |  |  |
| List of Direct Order Flow Session |  | A table with below column:   * Direct Order Flow Session |
| List of Trading GUI User |  | A table with below column:   * Trading GUI User |

## PTRM GUI User

**#FS10011\_S0040\_01300**

Sponsoring participant or sponsored EP accesses PTRM GUI using an EIDP User with access right to PTRM GUI. Business Operations initially setup and maintain PTRM GUI User using “Maintain PTRM GUI User” function in Admin GUI. When a new PTRM GUI User is created from Admin GUI, it must be linked with an existing EIDP User.

Once the initial setup is completed, the system will automatically generate a PTRM session for facilitating the PTRM functions. PTRM session to PTRM GUI User is a one-to-one mapping relationship.

### Attributes

Below are the attributes for a PTRM GUI User (attributes managed by system are read-only attributes which cannot be updated by Business Operations):

|  |  |  |
| --- | --- | --- |
| Attributes | Managed By System | Remarks |
| PTRM GUI User Level | | |
| User ID |  | Cannot be changed after creation |
| IDP User ID |  | Link to an EIDP User  Cannot be changed after creation |
| Participant |  | Cannot be changed after creation |
| Is Sponsoring Participant? |  | Cannot be changed after creation |
| Suspended? |  | Allow to suspend/resume with immediate effect by Business Operations |
| User Role |  | Must be with user type = PTRM GUI (Risk Limit Manager) for sponsoring participant or PTRM GUI (Trading Unit) for exchange participant |
| Legal Browser IP Addresses |  | Allow to update with immediate effect by Business Operations |
| EIDP User Level | | |
| EIDP Locked? |  | Managed by EIDP |
| Session Level | | |
| Comp ID |  |  |
| Service Type |  | PTRM |
| Session Usage |  | UI access |
| Partition ID |  | Assigned by system |
| Interface Protocol |  | Binary |
| Blocked? |  | Allow to block/unblock with immediate effect by Business Operations |
| Locked? |  |  |
| Legal IP Addresses |  | IP addresses of PTRM GUI backend infrastructure |
| Password |  | Masked, cannot be viewed by Business Operations  Technical configuration for PTRM GUI backend |
| Password Policy ID |  |  |
| Number of Missing HB |  | A system-wise configuration for all Trading/PTRM GUI User |
| Last Successful Login Time |  |  |
| Password Expiration Date |  |  |

### Intra-day Operations

**#FS10011\_S0040\_01400**

The following are the operations can be performed intra-day for a PTRM GUI user:

|  |  |
| --- | --- |
| Operations | Description |
| Suspend1/Resume | When a PTRM GUI user is suspended,   * user cannot perform any PTRM functions * user is forced logout and cannot be logged on |
| Block1/Unblock | When a PTRM GUI user is blocked,   * session is forced logout and cannot be logged on |
| Update Legal Browser IP Addresses | The IP address list can be updated with immediately effective.  The entries in the IP address list can also updated with immediately. |
| Reset Password (EIDP) | When a PTRM GUI user is locked by EIDP, Business Operations can trigger EIDP user reset password flow (which will unlock the user account and trigger password reset by the user) |

1 Please refer to *Appendix B* for details.

## Self Admin Portal User

**#FS10011\_S0040\_01500**

EP accesses Self Admin Portal using an EIDP User with access right to Self Admin Portal. Business Operations initially setup Self Admin Portal User using “Maintain Self Admin Portal User” function in Admin GUI. When a new Self Admin Portal User is created from Admin GUI, it must be linked with an existing EIDP User.

### Attributes

Below are the attributes for a Self Portal Admin User (attributes managed by system are read-only attributes which cannot be updated by Business Operations):

|  |  |  |
| --- | --- | --- |
| Attributes | Managed By System | Remarks |
| Self Admin Portal User Level | | |
| User ID |  | Cannot be changed after creation |
| IDP User ID |  | Link to an EIDP User  Cannot be changed after creation |
| Exchange Participant |  | Cannot be changed after creation |
| Suspended? |  | Allow to suspend/resume with immediate effect by Business Operations |
| Legal Browser IP Addresses |  | Allow to update with immediate effect by Business Operations |
| EIDP User Level | | |
| EIDP Locked? |  | Managed by EIDP |

### Intra-day Operations

**#FS10011\_S0040\_01600**

The following are the operations can be performed intra-day for a Self Admin Portal User:

|  |  |
| --- | --- |
| Operations | Description |
| Suspend/Resume | When a Self Admin Portal user is suspended,   * user cannot perform any self admin functions * user is forced logout and cannot be logged on |
| Update Legal Browser IP Addresses | The IP address list can be updated with immediately effective.  The entries in the IP address list can also updated with immediately. |
| Reset Password (EIDP) | When a Self Admin Portal user is locked by EIDP, Business Operations can trigger EIDP user reset password flow (which will unlock the user account and trigger password reset by the user) |

# Appendix A – EIDP and ODP Trading Relationship and User Setup

EIDP and ODP Trading logical relationship is illustrated in the diagram below:

![](data:image/x-wmf;base64...) \* It should be noted that this diagram is for illustration purpose only. The exact relationship mapping is subject to be updated.

For example, the following are the users in EIDP:

|  |  |
| --- | --- |
| User | Access Control |
| ABCAA001 | Allow to access Trading GUI for ABCAA   * Identity = ABCAA * Identity Type = Trading Participant * Role = Access to Trading GUI |
| P\_ACBAA1001 | Allow to access PTRM GUI for ABCAA   * Identity = ABCAA * Identity Type = Trading Participant * Role = Access to PTRM GUI |
| P\_CABC1001 | Allow to access PTRM GUI for CABC   * Identity = CABC * Identity Type = Sponsoring Participant * Role = Access to PTRM GUI |

In ODP Trading, there would be corresponding Trading GUI User and PTRM GUI User as below:

* + Trading GUI User
    - User = ABCAA001, Exchange Participant = ABCAA
  + PTRM GUI User
    - User = P\_ACBAA1001, Participant = ABCAA, Is Sponsoring Participant = N
    - User = P\_CABC1001, Participant = CABC, Is Sponsoring Participant = Y

# Summary on Suspend, Block and Lock behaviours for Participants, Sessions and GUI Users

|  |  |
| --- | --- |
| **Trading Activities** | **Descriptions** |
| **T1** | Order actions |
| **T2** | Quote actions |
| **T3** | Block Trade actions |
| **T4** | Make TMC creation request |
| **T5-1** | Make Error Trade Claim request (for self) |
| **T5-2** | Make Error Trade Claim request (on behalf of other session if it is a nominated session) |
| **T6** | Enquiry about MMP parameters |
| **T7** | Enquiry about Throttle Entitlement |
| **T8** | Binary Kill Switch |
| **T9** | Exchange On Behalf Deal Entry |
| **T10-1** | PTRM Emergency Buttons – EP |
| **T10-2** | PTRM Emergency Buttons – SP |
| **T10-3** | PTRM Emergency Buttons – Exchange |
| **T11-1** | PTRM risk limit group parameters update – EP Base group |
| **T11-2** | PTRM risk limit group parameters update – EP Non-base group |
| **T12** | Make Trade Cancellation and Trade Adjustment |

|  |  |
| --- | --- |
| **System Induced behaviour** | **Descriptions** |
| **S1** | Allow staying logged in or further logging in |
| **S2** | Forced logout and mandatory password change before next log in |
| **S3** | Unsolicited cancel orders/quotes |
| **S4** | Unsolicited cancel pending block trades |
| **S5** | Reject Error Trade Claim request |
| **S6** | Reject TMC creation request |
| **S7** | Reject Kill Switch request |
| **S8** | Reject Exchange On Behalf Deal Entry |
| **S9-1** | Cannot take further PTRM actions on self EP |
| **S9-2** | Cannot take further PTRM actions on controlled EP |
| **S9-3** | Cannot take further PTRM actions on self SP |
| **S9-4** | Cannot take further PTRM actions on controlled SP |

|  |  |
| --- | --- |
| **Stakeholder** | **Descriptions** |
| **EP\_CG1** | Direct Order Flow Session (self, CGW Session) |
| **EP\_PG1** | Direct Order Flow Session (self, PSGW Session) |
| **EP\_CG2** | Direct Order Flow Session (other CGW Sessions, under the same EP) |
| **EP\_PG2** | Direct Order Flow Session (other PSGW Sessions, under the same EP) |
| **EP\_T1** | Trading GUI User – External (self) |
| **EP\_T2** | Trading GUI User – External (others, under the same EP) |
| **EP\_P1** | EP PTRM External GUI User (self) |
| **EP\_P2** | EP PTRM External GUI User (others, under the same EP) |
| **SP\_P1** | SP PTRM External GUI User (self) |
| **SP\_P2** | SP PTRM External GUI User (others, under the same SP) |
| **EX\_T1** | Exchange Internal Trading GUI User |
| **EX\_P1** | Exchange PTRM Internal GUI User |

**Please see below:
1 Exchange On Behalf Deal Entry can be made on other Exchange Participants, but trades involving the suspended Exchange Participant will be rejected.
2 Exchange On Behalf Deal Entry can be made on other users and sessions under the same Exchange Participant, but trades involving the suspended/blocked user/session will be rejected.

B.1. Suspend, Block, Lock an EP, an SP, a Session, or a User**

|  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| **Term** | **Action On** | **EP\_CG1** | **EP\_PG1** | **EP\_CG2** | **EP\_PG2** | **EP\_T1** | **EP\_T2** | **EP\_P1** | **EP\_P2** | **SP\_P1** | **SP\_P2** | **EX\_T1** | **EX\_P1** |
| **Suspend** | **Exchange Participant** | S1 S3 S4 S5 S6 S7 T6 T7 | S1 S3 S4 S5 S6 S7 T6 T7 | S1 S3 S4 S5 S6 S7 T6 T7 | S1 S3 S4 S5 S6 S7 T6 T7 | S1 S3 S4 S5 S6 | S1 S3 S4 S5 S6 | S9-1 | S9-1 | T10-1 T10-2 T11-1 T11-2 | T10-1 T10-2 T11-1 T11-2 | T91  T12 | T10-1 T10-2 T10-3 T11-1 T11-2 |
| **Block** | **Exchange Participant** | Not a valid scenario | | | | | | | | | | | |
| **Lock** | **Exchange Participant** | Not a valid scenario | | | | | | | | | | | |
| **Suspend** | **Sponsoring Participant** | T1 T2 T3 T4 T5-1 T5-2 T6 T7 T8 | T1 T2 T3 T4 T5-1 T5-2 T6 T7 T8 | T1 T2 T3 T4 T5-1 T5-2 T6 T7 T8 | T1 T2 T3 T4 T5-1 T5-2 T6 T7 T8 | T1 T2 T3 T4 T5-1 T5-2 T6 T7 T8 | T1 T2 T3 T4 T5-1 T5-2 T6 T7 T8 | T10-1 | T10-1 | S1 S9-2 | S1 S9-2 | - | T10-1 T10-2 T10-3 T11-1 T11-2 |
| **Block** | **Sponsoring Participant** | Not a valid scenario | | | | | | | | | | | |
| **Lock** | **Sponsoring Participant** | Not a valid scenario | | | | | | | | | | | |
| **Suspend** | **External User/Session(on User/Session 1)** | S2 S3 S4 S5 S6 S7 | S2 S3 S4 S5 S6 S7 | S1 T1 T2 T3 T4 T5-1 T5-2 T6 T7 T8 | S1 T1 T2 T3 T4 T5-1 T5-2 T6 T7 T8 | S2 S3 S4 S5 S6 S7 | S1 T1 T2 T3 T4 T5-1 T5-2 T6 T7 T8 | S2 | S2 | S1 | S1 | T92  T12 | T10-1 T10-2 T10-3 T11-1 T11-2 |
| **Block** | **External User/Session (on User/Session 1)** | S2 S3 S4 S5 S6 S7 | S2 S3 S4 S5 S6 S7 | S1 T1 T2 T3 T4 T5-1 T5-2 T6 T7 T8 | S1 T1 T2 T3 T4 T5-1 T5-2 T6 T7 T8 | S2 S3 S4 S5 S6 S7 | S1 T1 T2 T3 T4 T5-1 T5-2 T6 T7 T8 | S2 | S2 | S1 | S1 | T92  T12 | T10-1 T10-2 T10-3 T11-1 T11-2 |
| **Lock** | **External User/Session (on User/Session 1)** | S2 | S2 | S1 T1 T2 T3 T4 T5-1 T5-2 T6 T7 T8 | S1 T1 T2 T3 T4 T5-1 T5-2 T6 T7 T8 | S2 | S1 T1 T2 T3 T4 T5-1 T5-2 T6 T7 T8 | S2 | T10-1 | T10-1 T10-2 T11-1 T11-2 | T10-1 T10-2 T11-1 T11-2 | T9 T12 | T10-1 T10-2 T10-3 T11-1 T11-2 |
| **Suspend** | **Internal Trading GUI User** | T1 T2 T3 T4 T5 T6 T7 T8 | T1 T2 T3 T4 T5 T6 T7 T8 | T1 T2 T3 T4 T5 T6 T7 T8 | T1 T2 T3 T4 T5 T6 T7 T8 | T1 T2 T3 T4 T5 T6 T7 T8 | T1 T2 T3 T4 T5 T6 T7 T8 | T10-1 | T10-1 | T10-1 T10-2 T11-1 T11-2 | T10-1 T10-2 T11-1 T11-2 | S1 S8 | T10-1 T10-2 T10-3 T11-1 T11-2 |
| **Block** | **Internal Trading GUI User** | T1 T2 T3 T4 T5 T6 T7 T8 | T1 T2 T3 T4 T5 T6 T7 T8 | T1 T2 T3 T4 T5 T6 T7 T8 | T1 T2 T3 T4 T5 T6 T7 T8 | T1 T2 T3 T4 T5 T6 T7 T8 | T1 T2 T3 T4 T5 T6 T7 T8 | T10-1 | T10-1 | T10-1 T10-2 T11-1 T11-2 | T10-1 T10-2 T11-1 T11-2 | S1  S8 | T10-1 T10-2 T10-3 T11-1 T11-2 |
| **Lock** | **Internal Trading GUI User** | T1 T2 T3 T4 T5 T6 T7 T8 | T1 T2 T3 T4 T5 T6 T7 T8 | T1 T2 T3 T4 T5 T6 T7 T8 | T1 T2 T3 T4 T5 T6 T7 T8 | T1 T2 T3 T4 T5 T6 T7 T8 | T1 T2 T3 T4 T5 T6 T7 T8 | T10-1 | T10-1 | T10-1 T10-2 T11-1 T11-2 | T10-1 T10-2 T11-1 T11-2 | S2 | T10-1 T10-2 T10-3 T11-1 T11-2 |
| **Suspend** | **Internal PTRM GUI User** | T1 T2 T3 T4 T5 T6 T7 T8 | T1 T2 T3 T4 T5 T6 T7 T8 | T1 T2 T3 T4 T5 T6 T7 T8 | T1 T2 T3 T4 T5 T6 T7 T8 | T1 T2 T3 T4 T5 T6 T7 T8 | T1 T2 T3 T4 T5 T6 T7 T8 | T10-1 | T10-1 | T10-1 T10-2 T11-1 T11-2 | T10-1 T10-2 T11-1 T11-2 | T9 T12 | S1 S9-2 S9-4 |
| **Block** | **Internal PTRM GUI User** | T1 T2 T3 T4 T5 T6 T7 T8 | T1 T2 T3 T4 T5 T6 T7 T8 | T1 T2 T3 T4 T5 T6 T7 T8 | T1 T2 T3 T4 T5 T6 T7 T8 | T1 T2 T3 T4 T5 T6 T7 T8 | T1 T2 T3 T4 T5 T6 T7 T8 | T10-1 | T10-1 | T10-1 T10-2 T11-1 T11-2 | T10-1 T10-2 T11-1 T11-2 | T9 T12 | S1 S9-2 S9-4 |
| **Lock** | **Internal PTRM GUI User** | T1 T2 T3 T4 T5 T6 T7 T8 | T1 T2 T3 T4 T5 T6 T7 T8 | T1 T2 T3 T4 T5 T6 T7 T8 | T1 T2 T3 T4 T5 T6 T7 T8 | T1 T2 T3 T4 T5 T6 T7 T8 | T1 T2 T3 T4 T5 T6 T7 T8 | T10-1 | T10-1 | T10-1 T10-2 T11-1 T11-2 | T10-1 T10-2 T11-1 T11-2 | T9 T12 | S2 |
