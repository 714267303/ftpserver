TITLE:

**FUNCTIONAL SPECIFICATION**

***ODP-T***

*FS10018 – EP Self-Admin Portal*

AUTHOR : *IT/Markets Systems* DATE : *2025-06-11*

LAST REVIEW *Derivatives Trading Business Operations* DATE : *2025-02-28*

**CONTENTS**

[1. Document Control 3](#__RefHeading___Toc193721587)

[1.1. Change History 3](#__RefHeading___Toc193721588)

[1.2. Document Cross-referenced 4](#__RefHeading___Toc193721589)

[1.3. Abbreviation 4](#__RefHeading___Toc193721590)

[2. Introduction 5](#__RefHeading___Toc193721591)

[2.1. Application Objectives 5](#__RefHeading___Toc193721592)

[2.2. Functional Requirements 5](#__RefHeading___Toc193721593)

[2.2.1. Participant and User 5](#__RefHeading___Toc193721594)

[2.2.2. Market Maker Protection and Obligation 8](#__RefHeading___Toc193721595)

[2.2.3. Self-Match Prevention 8](#__RefHeading___Toc193721596)

[2.2.4. Pre-Trade Risk Management 8](#__RefHeading___Toc193721597)

[2.2.5. Error Trade Claim Response 9](#__RefHeading___Toc193721598)

[2.2.6. Market Message 9](#__RefHeading___Toc193721599)

[2.3. Functional Scope 9](#__RefHeading___Toc193721600)

[2.3.1. View Admin Account Details 9](#__RefHeading___Toc193721601)

[2.3.2. View Participant Details 9](#__RefHeading___Toc193721602)

[2.3.3. View Users Account Details 10](#__RefHeading___Toc193721603)

[2.3.4. Nominate Error Trade Claim Session 10](#__RefHeading___Toc193721604)

[2.3.5. Amend Max Order Size/Block Trade Size Limit per Trading Right 11](#__RefHeading___Toc193721605)

[2.3.6. Download User Login Report (daily only) 11](#__RefHeading___Toc193721606)

[2.3.7. Nominate Binary Sessions to receive Market Messages 12](#__RefHeading___Toc193721607)

[2.4. Frontend Screens 12](#__RefHeading___Toc193721608)

[2.4.1. View Admin Account 12](#__RefHeading___Toc193721609)

[2.4.2. View Participant details 13](#__RefHeading___Toc193721610)

[2.4.3. View Users Account Details 14](#__RefHeading___Toc193721611)

[2.4.4. Nominate Error Trade Claim Response User 17](#__RefHeading___Toc193721612)

[2.4.5. Amend Max Size Limit per Trading Right 19](#__RefHeading___Toc193721613)

# Document Control

## Change History

|  |  |  |  |
| --- | --- | --- | --- |
| Version  Number | Issue Date | Author | Abstract |
| V0.1 | 2024-10-15 | Jessica Chang | Bullet point features which may be covered by the EP Self-Admin portal |
| V0.2 | 2024-10-23 | Jessica Chang | * Added Section 2.2 Functional Requirement to reflect comments received in FS10018 Review Log. * Added Section 2.4 Frontend screens to illustrate the functions. * Supplemented more details inside Section 2.3 Scope. |
| V0.4a | 2024-11-18 | Jessica Chang | * Revised according to the latest discussion results inside this Functional Specifications. * Added Section 2.4 Frontend screens and its attributes and data types to illustrate the functions. |
| V0.6 | 2025-01-23 | Jessica Chang | * Revised according to the latest discussion results during Traceability mapping review exercise |
| V0.7 | 2025-03-24 | Jessica Chang | * Revised according to the decisions made during ODP IT & DT weekly catch-up meetings: (1) Revoke “Account password reset” function, (2) Revoke on-demand User Login report generation function, and (3) Add Section 2.3.7 Nominate Binary Sessions to receive Market Messages (Details pending from Business). * Cover Page, System Name, Version Number, Document cross-referenced etc. multiple section updates |
| V0.8 | 2025-06-11 | Jessica Chang | * Revise the attributes covered in frontend screens according to the latest *FS10013 Market Operation GUI* and *FS10020 Logical Data Model* (version 20250527) * Remove “Account password reset” and “on-demand User Login report generation” buttons from frontend screens |

## Document Cross-referenced

|  |  |  |
| --- | --- | --- |
| # | Document | Version |
| 1 | BRD\_DT\_0005: 0005 BRS Trading Operations \_v2.7\_ 2024 12 06 | V2.7 20241206 |
| 2 | BRD\_DT\_0007: 0007 ODP - NewFunctionRequest - Error Trade 2025 01 21 | 20250121 |
| 3 | BRD\_DT\_0032: 0032 New wish 012 Client service 2024 04 30 | 20240430 |
| 4 | BRD\_DT\_0043: 0043 BRS EP Onboarding 2024 04 27 | 20240427 |
| 5 | BRD\_DT\_0044: 0044 BRS BAU Support\_V1.6\_20250103 | V1.6 20250103 |
| 6 | BRD\_DT\_0045: 0045 BRS Reports \_V1.1\_ 2024 10 17 | V1.1 20241017 |
| 7 | BRD\_DT\_0050: 0050 BRS\_PDMPA functions in ODP\_ v1.3 2025 01 14 | V1.3 20250114 |
| 8 | BRD\_DT\_0054: 0054 Client Services - v2.1- 20241230 | V2.1 20241230 |
| 9 | *FS10007 Self-Match Prevention* |  |
| 10 | *FS10008 Market Maker Protection* |  |
| 11 | *FS10011 Participant Structure* |  |
| 12 | *FS10013 Market Operation Admin GUI* |  |
| 13 | *FS10015 Conformance Test Portal* |  |
| 14 | *FS10020 Logical Data Model* |  |
| 15 | *MS10001 Binary Messaging Protocol Specifications* |  |

## Abbreviation

*<Intentionally left as blank>*

# Introduction

## Application Objectives

**#FS10018\_S0020\_00100**
EP Self-Admin Portal intends to provide GUI User with Admin User Role to administrate on behalf of the entire Exchange Participant. All changes made inside this portal are next-day effective only, except password change function through EIDP. **#FS10018\_S0020\_00110** Please note that services which will incur billing charges to the Exchange Participants will not be entertained via this portal. Only Trading-related configurations will be entertained via this portal. **#FS10018\_S0020\_00121** Each Participant should nominate at least three External Trading GUI Users to be granted with Admin User Role, such that the Participant can enjoy all the self-service functions described below.

**#FS10018\_S0020\_00131**
There will be corresponding Internal Admin functions which can create the Self Admin Portal GUI User(s) for corresponding Exchange Participants. Details of such an assignment will be covered in *FS10011* *Participant Structure.*

## Functional Requirements

The following services are requested for EP Self-Admin Portal inside the Business Requirements Documentations[[1]](#footnote-2). Please see IT’s assessment on which services are covered inside the portal, inside ODP-T Binary Messaging Protocol or maintain as an Exchange internal operational function:

### Participant and User

**#FS10018\_S0020\_00200**

* **Participant and User onboarding** will maintain as an Exchange internal operational function. Receiving, validating and processing the forms to determine Participant-ship will remain a manual SOP for Derivatives Trading. Details on Participant’s and User’s attributes’ definitions and behaviours are covered in *FS10011 Participant Structure*, while the data types are in *FS10020 Logical Data Model*.

**#FS10018\_S0020\_00300**

* **Conformance Test** is conducted through a separate Test Portal to serve newly onboarded Participants to certify their programs have adhered to the behaviours defined inside the Interface Protocol Specifications. Environment timeslot booking will not be covered inside EP Self-Service Admin Portal and will maintain as manual SOP for Derivatives Trading. Details of Conformance Test Portal – including the test portal reference data setup, test cases, test results verifications, test marking etc., are covered in *FS10015 Conformance Test Portal*.

**#FS10018\_S0020\_00400**

* **Participant and User existing trading-related attribute amendment** will maintain as an Exchange internal operational function. Receiving, validating and processing the requests, such as updating *Number of Missing Heartbeats*, updating *Idle Timeout (seconds)[[2]](#footnote-3)* etc., will remain as a manual SOP for Derivatives Trading. Details can be found in *FS10011 Participant Structure* and *FS10013 Admin GUI*. Updated *Max Order Size*, *Max Block Trade Size Limit* per Trading Right associated with Exchange Participant level will be covered inside this portal.

**#FS10018\_S0020\_00500**

* **Client Contact Information** will not be stored inODP-T. ODP-T database will only store information of the Participant or User which are relevant for Trading functionality authorisation purposes.

**#FS10018\_S0020\_00602**

* **Account password change** and **Account password reset** bothconsists of three flows. According to the agreements between Business and IT on 2025-02-25 in ODP IT & DT weekly catch-up meeting, DT Business revoked the functional requirement on account password reset case. The account password reset flow will be revoked from the below sections as well.

  **Account password reset** means resetting the status and password for a locked account, and the reset action includes two steps: *Step 1. –* Unlock account and *Step 2. –* Change password. Please note that the scope of “account” mentioned in account password reset only covers the accounts which are already activated, are locked but not blocked[[3]](#footnote-4). Should this function be implemented, it will rely on the implementation of the “Change password” and “Forget password” functions in EIDP.

  **Account password change** means an account changing password under the case when it can still login. Should this function be implemented, it will rely on the implementation of the “Change password” and “Forget password” functions in EIDP. Please note that the account password change mentioned here only covers the accounts which are already activated and are not locked nor blocked.

  Details below:

**#FS10018\_S0020\_00611**
[Revoked] **#FS10018\_S0020\_00612**
**1. Admin user change password on-behalf-of normal users**Delegated admins (i.e. Interchangeable term with “External Admin User” in EIDP setup) will have the permission to trigger change account password on-behalf-of normal user(s), should the delegated admin and user belong to the same Exchange Participant. Please note that for the EP Self-Admin Portal User to perform such action, the Self-Admin Portal User should have the correct corresponding permission being setup inside EIDP System. Details of such flow will be covered in *EIDP Functional Specifications*.

Please note that the scope of “normal users” here only covers the Trading GUI Users and PTRM GUI Users, and not the Binary Sessions. Binary Session password change flow is covered in *MS10001 Binary Messaging Protocol Specifications*.

**#FS10018\_S0020\_00621**[Revoked] **#FS10018\_S0020\_00622**
**2. Admin account change password(s) for Admin account(s)**Since each Participant can nominate to at least three EP Self-Admin Portal User, should one of the admin user accounts require password change, the requests will be directed to be handled in EIDP. EIDP will then conduct multi-factor authentication which involves the other two or more admin users to authenticate, before the password can be changed successfully. Details of such flow will be covered in *EIDP Functional Specifications*.

**#FS10018\_S0020\_00631**

**3. Normal user change password for their own account**
Should a Trading GUI User need to change password, under the situation when an account is not locked or blocked, the User can click on “Change password” at time of logging in and change the account’s password after passing authentication checks.

Please note that due to the Functional Specifications intend to cover functions which the admin user accounts can perform on-behalf-of single/all users under the same Exchange Participant, hence this flow is only briefly described here for completeness and all updates of this password change flow will be made inside *EIDP Functional Specifications*.

**#FS10018\_S0020\_00640**[Revoked]**#FS10018\_S0020\_00641**The locked accounts could either be a Binary session account, a normal user account (i.e. External User account in EIDP terms) or an admin user account (i.e. External Admin account in EIDP terms). There will be only one flow to handle the locked accounts, which is to call Exchange Operations to assist unlocking their accounts manually.

### Market Maker Protection and Obligation

**#FS10018\_S0020\_00700**

**Market Maker Protection (MMP)** is a quote protection mechanism for Market Makers in the Hong Kong Derivatives Market. Please note that MMP parameters configurations will not be provided via the EP Self-admin portal. Enquiring and updating MMP parameters[[4]](#footnote-5) will be covered inside ODP-T Binary Messaging Protocol. Details of the MMP parameters definitions and behaviours are covered in *FS10008 Market Maker Protection*; the Binary messages to enquire/amend MMP parameters are covered in *MS10001 Binary Messaging Protocol Specifications*.

**#FS10018\_S0020\_00800**

**Market Maker Obligation calculation**, includingMM Performance Report, Clawback Report, Liquidity Level Update[[5]](#footnote-6) etc., will remain outside of ODP-T System. Subject to the interface requirements provided, the requested reference data, i.e. Product and Participant reference data, will be disseminated through the interfaces at Start of Day and its delta at time when the updated reference data becomes effective.

### Self-Match Prevention

**#FS10018\_S0020\_00900**

**Self-Match Prevention (SMP)** is an optional service which Exchange Participants can register for. SMP service registration/termination, ID registration/termination and ID sharing/un-sharing will remain as its existing flow, i.e. forms are received through ECP, forms passing validations will be processed as queries to be consumed by ODP-T Admin database. The reports related to SMP, i.e. IDs effective to the Exchange Participant as of end of same Trading Day or next Trading Day, will be provided to Exchange Participant through ECP corresponding folders at day-end. Details are covered in *FS10007 Self-Match Prevention*.

### Pre-Trade Risk Management

**#FS10018\_S0020\_01000**

**Pre-Trade Risk Management** is a mandatory service which all Exchange Participants should participate in. **Risk Limit setup** will be stored in ODP-T, available for edits for the Sponsored Participant via PTRM GUI (and Exchange Operations override via PTRM Admin GUI), and not provided through the EP Self-Admin Portal.

### Error Trade Claim Response

**#FS10018\_S0020\_01100
Error Trade Claim** is a new service which will be provided in ODP-T. Details of the request-response flow between requester, Exchange Operations, counterparty (or the respondent) and further status updates are in *FS10009 Error Trade, Trade Cancellations and Adjustments* and in *MS10001 Binary Messaging Protocol Specifications*.

### Market Message

**#FS10018\_S0020\_01150**Market Message(s) are manually-prepared or event-triggered messages disseminated to the Derivatives Markets through defined channels – either Trading GUI, Market Data System (OMD-D) and/or Binary Sessions.

According to the agreements between Business and IT on 2025-02-25 in ODP IT & DT weekly catch-up meeting, DT Business requested IT to allow EP to self-administer whether a Binary Session should receive Market Messages or not through the EP Self-Admin Portal. Please note that the nominations only apply to lower-priority market messages (i.e. messages which are not categorised as “Critical”). In other words, all defined channels are expected to deliver “Critical” market messages to clients (whether it is a GUI User or Binary Session).

## Functional Scope

The following services are proposed for EP Self-Admin Portal:

### View Admin Account Details

**#FS10018\_S0020\_01200**

The EP Admin Users can view their own account’s details, detailed attributes to be covered inside Section 2.4.1.

### View Participant Details

**#FS10018\_S0020\_01300**
The EP Admin Users can view all effective configurations of their own Exchange Participant, detailed attributes to be covered inside Section 2.4.2.

|  |  |
| --- | --- |
| Attribute | Descriptions |
| Identity – Participant ID | *Exchange Participant ID* |
| Identity – Exchange ID | *Exchange ID* |
| Identity – Company ID | *Company ID* |
| Trading Parameters – Registered for SMP? | Shows “True” or “False” by checking the amount of SMP IDs inside the list. |
| Trading Parameters – Cancel on Disconnect setting | Includes *Number of Missing Heartbeat*, *Timeout Before COD*. |
| Trading Parameters – Participant Trading Rights | Shows the Trading Rights of a Participant in the format of grid table. Each Participant Trading Right shows the corresponding *Instrument Type ID*, *Order Size Limit* and *Block Trade Size Limit*. |

### View Users Account Details

**#FS10018\_S0020\_01400**The EP Admin Users can view all effective user account’s details under the same Exchange Participant, detailed attributes to be covered inside Section 2.4.3.

|  |  |
| --- | --- |
| Attribute | Descriptions |
| Identity – Session ID/User ID | Binary Session – *Trader ID* Self Admin Portal User – *Self Admin Portal User ID* Trading GUI User – *Trading GUI User ID* PTRM GUI User – *PTRM GUI User ID* |
| Identity – Participant ID | *Exchange Participant ID* |
| Identity – Company ID | *Company ID* |
| System Access – Service Type | Gateway Service Type. Domain Values:  O = Order Flow  D = Drop Copy  R = PTRM |
| System Access – Session Usage | Domain Values:  D = Direct Access  U = UI Access |
| System Access –  Interface Protocol | Domain Values:  B = Binary |
| System Access – Order Throttle |  |
| System Access –  Last login Date/Time | GUI Users – Information from EIDP Binary Session – Information from Gateway servers |
| System Access –  Password Expiration Date |  |
| System Access –  Account Status | Shows the effective status combining the results of *Blocked*, *Locked*, and Participant *Suspended* field. |
| Trading Parameters – Cancel on Disconnect setting | Shows the two view-only fields to external – *Number of Missing Heartbeat*, *Timeout Before COD.* This information can be found when the EP admin user click into an individual user for more details. |
| Trading Right | Show by *Instrument Type/Combo Type*, *Max Order Size Limit* and *Max Block Trade Size Limit*. This information can be found when the EP admin user click into an individual user for more details. |

### Nominate Error Trade Claim Session

**#FS10018\_S0020\_01500**The EP Admin Users can nominate a single Binary Session or Trading GUI User under the Exchange Participant such that the session can respond to the Error Trade claim which were raised by counterparty EP and approved by the Exchange.

**#FS10018\_S0020\_01600**
It is optional for the Exchange Participant to nominate the Error Trade Claim Response Session. If no session or user is nominated, then the Error Trade Claim Response will be limited to be received by the trade’s original counterparty session.

In other words, assume:

* + - Trade 10001 is composed of 1 Bid-side order and 2 Ask-side orders.
    - Trade 10001’s Bid-side Order owner:
      *Exchange Participant ID* = ABCMM, *Session ID* = ABCMM001.
      *Nominated Error Trade Claim Response Session ID* = ABCMM007.
    - Trade 10001’s Ask-side Order 1 owner:
      *Exchange Participant ID* = XYZMM, *Session ID* = XYZMM001.
      *Nominated Error Trade Claim Response Session ID* = XYZMM005.
    - Trade 10001’s Ask-side Order 2 owner:
      *Exchange Participant ID* = OYXMM, *Session ID* = OYXMM001.
      *Nominated Error Trade Claim Response Session ID* = Nil.

If Error Trade Claim for Trade 10001 is raised by Bid-side (*Session ID* = ABCMM001), passed validation checks and approved by Exchange Operations, only Trade 10001’s Ask-side will receive the request to solicit response (*Session ID* = XYZMM005 and *Session ID* = OYXMM001). Details of Error Trade claim, validation checks, and cancellation flow is covered in *FS10009 Error Trade, Trade Cancellations and Adjustments.*

### Amend Max Order Size/Block Trade Size Limit per Trading Right

**#FS10018\_S0020\_01700**
The EP Admin Users can adjust the *Max Order Size Limit* and *Max Block Trade Size Limit* per Trading Right associated with the Participant level. The EP Admin Users do not have to associate themselves with the Trading Rights before they can amend the size limits. The logic to deduce the effective Order Size Limit is described inside *FS10011 Participant Structure*.

**#FS10018\_S0020\_01800**
Under the case when the Instrument Type or Combo Type is not traded (i.e. attribute *Traded* = False), and that the Participant or User is entitled to such Trading Right, the *Max Order Size Limit* and *Max Block Trade Size Limit* will not be permitted to be amended.

**#FS10018\_S0020\_01900**
Frontend validation checks are described in Section 2.4.5. Should any of the validation checks within 1 submission fail at the backend, the entire request will not be carried out.

### Download User Login Report (daily only)

**#FS10018\_S0020\_02000**The User Login Report is scheduled to be generated on daily basis and will be provided to Exchange Participants. The report covers login of Trading GUI, PTRM GUI and Binary Sessions under the same Exchange Participant. The report intends to be shared with Exchange Participants via ECP daily. This Functional Specifications will not discuss how to set up the user permission in ECP.

**#FS10018\_S0020\_02101**
[Revoked]. Attributes of the User Login Report are covered inside *FS10017 Reports Generation and Processing*.

### Nominate Binary Sessions to receive Market Messages

Details of the nomination screens to be provided by Business for IT to supplement inside this Functional Specifications.

## Frontend Screens

**#FS10018\_S0020\_02200**

The proposed screens for the mentioned functions in Section 2.3 are illustrated in the following section. No maker-checker functions are provided in EP Self-Admin Portal. All changes, once passed through validations, are effective on the next day.

### View Admin Account

**#FS10018\_S0020\_02300**

The Account screen contains a view-only table displaying delegated admin’s account detail.

|  |  |
| --- | --- |
| Function Names | Descriptions |
| View Admin account details | This function allows delegated admin to view account details. |
|  |  |

Sample Screen:
[Changes on 2025-06-11]
- Removed “Account password reset” button;
- Removed “Session Usage”, “Interface Protocol”, “Order Throttle” from System Access section;
- Removed the entire Trading Parameters section, and
- Added “Company ID” attribute.
![](data:image/png;base64...)

Attributes including the data type, size listed below:

| Column | Type | Size | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| **Identity** | | | | | |
| Session ID/User ID | Alphanumeric | 32 | M | - | Read ONLY field.  - Self Admin Portal GUI User ID (IDP User ID) (32) |
| Exchange Participant ID | Alphanumeric | 5 | M | - | The ID of the Exchange Participant. E.g. JPM |
| Company ID | Numeric | 10 | M | - | The ID of the Company |
| **System Access** |  |  |  |  |  |
|  |  |  |  |  |  |
|  |  |  |  |  |  |
|  |  |  |  |  |  |
| Last Successful Logon Time | Time | 8 | O | - | Read ONLY field.  The value should be from Trading table |
| Password Expiration Date | Date | 4 | O | - | Read ONLY field.  The value should be from Trading table |
| Account Status | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |
|  | | | | | |
|  | | | | | |
|  |  |  |  |  |  |
|  |  |  |  |  |  |

### View Participant details

**#FS10018\_S0020\_02400**

This function allows user to click on to view the Participant’s details. Please note that only details related to Trading functionalities are provided, i.e. Company addresses. Contact information etc., will not be shown inside this portal.

Sample Screen below:

![](data:image/png;base64...)

Attributes including the data type, size listed below:

| Column | Type | Size | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| **Identity** | | | | | |
| Exchange Participant ID | Alphanumeric | 5 | M | - | The ID of the Exchange Participant. E.g. JPM |
| Exchange ID | Alphanumeric | 2 | M | - | The ID of the Exchange. E.g. HK |
| Company ID | Numeric | 10 | M | - | The ID of the Company |
| **Trading Parameters** | | | | | |
| *Cancel on Disconnect Settings* | | | | | |
| Number Of Missing Heartbeat | Numeric | 2 | M | - | Number Of Missing Heartbeat |
| Timeout Before COD | Numeric | 4 | M | - | Timeout Before COD |
| *Participant Trading Rights* | | | | | |
| Instrument Type ID | Alphanumeric | 8 | M | - | A unique identifier for the Instrument Type |
| Order Size Limit | Numeric | 8 | M | - | Order Size Limit |
| Block Trade Size Limit | Numeric | 8 | M | - | Block Trade Size Limit |

### View Users Account Details

**#FS10018\_S0020\_02500**
The View Users screen is a view-only screen displaying the User/Session names belonging to the EP, including Trading GUI User, PTRM GUI User, Drop Copy Session and Binary Session. Only the Users/Sessions which are in Active or Suspended status are visible to the delegated admin. Only the latest snapshots of Users/Sessions will be provided.

Sample Screen:
(1) Full User Account List

![](data:image/png;base64...)
Attributes including the data type, size listed below:

| Column | Type | Size | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| **Identity** | | | | | |
| Session ID/User ID | Alphanumeric | 32 | M | - | Read ONLY field.  - Binary Session Trader ID (10) - Trading GUI User ID (IDP User ID) (32) - PTRM GUI User ID (IDP User ID) (32) |
| Exchange Participant ID | Alphanumeric | 5 | M | - | The ID of the Exchange Participant. E.g. JPM |
| **System Access** | | | | | |
| Service Type | Char | 1 | M | - | Read ONLY field.  Ref: [Common Attributes](#_Common_Attributes) - Gateway Service Type |
| Session Usage | Char | 1 | M | - | Read ONLY field.  Ref: [Common Attributes](#_Common_Attributes) - Gateway Session Usage |
| Interface Protocol | Char | 1 | M | - | Read ONLY field.  Ref: [Common Attributes](#_Common_Attributes) - Interface Protocol  The value must be Binary. Display “N/A” if it is a GUI User. |
| Last Successful Logon Time | Time | 8 | O | - | Read ONLY field.  The value should be from Trading table |
| Password Expiration Date | Date | 4 | O | - | Read ONLY field.  The value should be from Trading table |
| Account Status | Char | 1 | M | - | Ref: [Common Attributes](#_Common_Attributes) - Boolean Char |

(2) Individual User Account Detail

![](data:image/png;base64...)

Attributes including the data type, size listed below:

| Column | Type | Size | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| **Identity** (Attributes identical with Full List except the additional stated below:) | | | | | |
| Exchange Participant ID | Alphanumeric | 5 | M | - | The ID of the Exchange Participant. E.g. JPM |
| **System Access** (Attributes identical with Full List except the additional stated below:) | | | | | |
| Order Throttle | Numeric | 4 | M | - | Order Throttle |
| **Trading Parameters** | | | | | |
| *Cancel on Disconnect setting* | | | | | |
| Number Of Missing Heartbeat | Numeric | 2 | M | - | Read ONLY field.  Only show in individual User details screen. |
| Timeout Before COD | Numeric | 4 | M | - | Read ONLY field.  Only show in individual User details screen. |
| *Participant Trading Rights* | | | | | |
| Instrument Type ID | Alphanumeric | 8 | M | - | A unique identifier for the Instrument Type |
| Order Size Limit | Numeric | 8 | M | - | Order Size Limit |
| Block Trade Size Limit | Numeric | 8 | M | - | Block Trade Size Limit |

Display notes for frontend:

1. Each Exchange Participant can only nominate 1 Session/User to respond to the Error Trade Claims from counterparty Exchange Participants.
2. The Session/User must be active for the changes to be applied.

### Nominate Error Trade Claim Response User

**#FS10018\_S0020\_02600**

**The Nominate Error Trade Claim Response User screen is an editable screen, which delegated admin can nominate a User/Session from the latest list. Only the Users/Sessions which are in Active or Suspended status are visible to the delegated admin. Only the latest snapshot of Users/Sessions will be provided.

Sample Screen:
![](data:image/png;base64...)

Attributes including the data type, size listed below:**

| Column | Type | Size | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| **Identity** | | | | | |
| Exchange Participant ID | Alphanumeric | 5 | M | - | The ID of the Exchange Participant. E.g. JPM |
| EP Admin User Account ID | TBD |  |  |  |  |
| **(Grid Table capturing Current vs. Requested Nomination)** | | | | | |
| Current/Requested - Session ID/User ID | Alphanumeric | 32 | M | - | Read ONLY field.  - Binary Session Trader ID (10) - Trading GUI User ID (IDP User ID) (32) - PTRM GUI User ID (IDP User ID) (32) |
| Current/Requested - Service Type | Char | 1 | M | - | Read ONLY field.  Ref: [Common Attributes](#_Common_Attributes) - Gateway Service Type |
| Current/Requested - Session Usage | Char | 1 | M | - | Read ONLY field.  Ref: [Common Attributes](#_Common_Attributes) - Gateway Session Usage |
| Current/Requested - Interface Protocol | Char | 1 | M | - | Read ONLY field.  Ref: [Common Attributes](#_Common_Attributes) - Interface Protocol  The value must be Binary. Display “N/A” if it is a GUI User. |

Validation checks at frontend:

1. Each Exchange Participant can only nominate 1 Session/User to respond to the Error Trade Claims from counterparty Exchange Participants.
2. The Session/User must be active for the changes to be applied.

### Amend Max Size Limit per Trading Right

**#FS10018\_S0020\_02700**
EP delegated admin has the permission to view all Trading Rights of the Participant and request to amend the Order Size Limit and Block Trade Size Limit. The updated limit values will become effective the next day.

Sample screen:
![](data:image/png;base64...)
![](data:image/png;base64...)

Attributes including the data type, size listed below:

| Column | Type | Size | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| Trading Right ID | Numeric | 2 | M | - | The ID of the Trading Right. This column is read-only. |
| Order Size Limit | Numeric | 8 | O | 0 | Order Size Limit |
| Block Trade Size Limit | Numeric | 8 | O | 0 | Block Trade Size Limit |

Validation checks at frontend:

1. Each Instrument Type/Combo Type can only allow 1 Max Order Size Limit value, and 1 Block Trade Size Limit value to be submitted simultaneously.
2. Only actively traded Instrument Type/Combo Type, i.e. Under *Instrument Type – Traded?* = True and has at least 1 *Instrument Class – Traded?* = True and has at least 1 *Instrument Class – Status* = A (Active), can allow submissions to amend the Max Order Size Limit and Block Trade Size Limit.
3. The screen allows submissions of multiple amendments, including Max Order Size Limit and Block Trade Size Limit updates for multiple Instrument Type/Combo Type.

Validation checks at backend:

There will be a global parameter setting which allows Exchange Operations to configure the following four values:

* Default Max Order Size Limit
* Default Max Block Trade Size Limit
* Max EP Input Order Size Limit
* Max EP Input Block Trade Size Limit

1. When an Instrument Type/Combo Type is being setup, the values of “Default Max Order Size Limit” and “Default Max Block Trade Size Limit” will be filled in the Instrument Type and can be amended manually by Exchange Operations. When Exchange Participant is being setup and associated with Trading Rights, the Trading Right will be filled with values from its corresponding Instrument Type/Combo Type.
2. The values of “Max EP Input Order Size Limit” should be equal to or smaller than “Default Max Order Size Limit”, while the value of “Max EP Input Block Trade Size Limit” should be equal to or smaller than “Default Max Block Trade Size Limit”.
3. The order size limit values inputted inside the EP Self-admin portal should be equal to or smaller than “Max EP Input Order Size Limit”, and the block trade size limit values inputted inside the EP Self-admin portal should be equal to or smaller than “Max EP Input Block Trade Size Limit”.

1. The Business Requirements Documentations which this Functional Specification has covered are BRD\_DT\_0032 NEW WISH 012 Client Services Enhancements, 0043 EP Onboarding, 0044 BAU Support, partial of 0045 Reports and 0054 Client Services. [↑](#footnote-ref-2)
2. *Number of Missing Heartbeats*, *Idle Timeout (seconds)* and *Heartbeat Interval (seconds)* are Cancel on Disconnect parameters set on per Participant or per User basis. Only *Heartbeat Interval (seconds)* can be real-time updated through Binary Messaging Protocol Logon Request. The other two parameters remained as an Exchange internal operational function. [↑](#footnote-ref-3)
3. The effective status of a user account is jointly decided by two attributes – *Locked or not* and *Blocked or not*. A locked account is the consequence of surpassing the defined number of attempts to failed logins, and this is initiated by system. A blocked account is the consequence after Exchange Business Operations manually suspend the account. [↑](#footnote-ref-4)
4. Market Maker Protection parameters include the protection limits – Quantity and Delta Protection, and relevant attributes such as Exposure Time Limit Interval, Frozen Time etc. [↑](#footnote-ref-5)
5. MM Performance Report, Clawback Report and Liquidity Level Update are Market Maker Obligation calculations, which are conducted in Derivatives Surveillance system and not inside ODP-T. [↑](#footnote-ref-6)
