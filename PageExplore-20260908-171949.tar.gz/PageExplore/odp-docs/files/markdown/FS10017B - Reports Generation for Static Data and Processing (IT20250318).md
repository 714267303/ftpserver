TITLE:

**FUNCTIONAL SPECIFICATION**

**ODP-T**

*FS10017B - Reports Generation for Static Data and Processing*

AUTHOR : *IT/Markets Systems*  DATE : *18 Mar 2025*

LAST REVIEW Derivatives Trading Business Operations DATE : *28 Feb 2025*

**CONTENTS**

[Document Control 5](#__RefHeading___Toc193718692)

[1.1 Change History 5](#__RefHeading___Toc193718693)

[1.2 Document Cross-referenced 5](#__RefHeading___Toc193718694)

[1.3 Abbreviation 6](#__RefHeading___Toc193718695)

[1.4 Distribution List 6](#__RefHeading___Toc193718696)

[2 Introduction 7](#__RefHeading___Toc193718697)

[2.1 System Objectives 7](#__RefHeading___Toc193718698)

[2.2 Scopes 7](#__RefHeading___Toc193718699)

[2.3 Principal Users 7](#__RefHeading___Toc193718700)

[2.4 Document Conventions 7](#__RefHeading___Toc193718701)

[3 Reports for SMP 8](#__RefHeading___Toc193718702)

[3.1 SMP ID File Submission Status Report 8](#__RefHeading___Toc193718703)

[3.1.1 Source of Data 8](#__RefHeading___Toc193718704)

[3.1.2 Operation Flow 8](#__RefHeading___Toc193718705)

[3.1.3 Housekeeping 8](#__RefHeading___Toc193718706)

[3.1.4 Holiday Arrangements 8](#__RefHeading___Toc193718707)

[3.1.5 Report formats 8](#__RefHeading___Toc193718708)

[3.1.6 Report Layout 9](#__RefHeading___Toc193718709)

[3.1.7 Rejection Code 10](#__RefHeading___Toc193718710)

[3.2 SMP ID Full Image Report 11](#__RefHeading___Toc193718711)

[3.2.1 Source of Data 11](#__RefHeading___Toc193718712)

[3.2.2 Operation Flow 11](#__RefHeading___Toc193718713)

[3.2.3 Housekeeping 11](#__RefHeading___Toc193718714)

[3.2.4 Holiday Arrangements 11](#__RefHeading___Toc193718715)

[3.2.5 Report formats 11](#__RefHeading___Toc193718716)

[3.2.6 Report Layout 11](#__RefHeading___Toc193718717)

[3.3 SMP ID Delta Change Report 13](#__RefHeading___Toc193718718)

[3.3.1 Source of Data 13](#__RefHeading___Toc193718719)

[3.3.2 Operation Flow 13](#__RefHeading___Toc193718720)

[3.3.3 Housekeeping 13](#__RefHeading___Toc193718721)

[3.3.4 Holiday Arrangements 13](#__RefHeading___Toc193718722)

[3.3.5 Report formats 13](#__RefHeading___Toc193718723)

[3.3.6 Report Layout 13](#__RefHeading___Toc193718724)

[3.4 SMP ID Master Report 15](#__RefHeading___Toc193718725)

[3.4.1 Source of Data 15](#__RefHeading___Toc193718726)

[3.4.2 Operation Flow 15](#__RefHeading___Toc193718727)

[3.4.3 Housekeeping 15](#__RefHeading___Toc193718728)

[3.4.4 Holiday Arrangements 15](#__RefHeading___Toc193718729)

[3.4.5 Special handling 15](#__RefHeading___Toc193718730)

[3.4.6 Report formats 15](#__RefHeading___Toc193718731)

[3.4.7 Report Layout 15](#__RefHeading___Toc193718732)

[3.5 SMP ID ECP Submission Status 17](#__RefHeading___Toc193718733)

[3.5.1 Source of Data 17](#__RefHeading___Toc193718734)

[3.5.2 Operation Flow 17](#__RefHeading___Toc193718735)

[3.5.3 Housekeeping 17](#__RefHeading___Toc193718736)

[3.5.4 Holiday Arrangements 17](#__RefHeading___Toc193718737)

[3.5.5 Report formats 17](#__RefHeading___Toc193718738)

[3.5.6 Report Layout 17](#__RefHeading___Toc193718739)

[3.6 SMP ID All Submission Status 20](#__RefHeading___Toc193718740)

[3.6.1 Source of Data 20](#__RefHeading___Toc193718741)

[3.6.2 Operation Flow 20](#__RefHeading___Toc193718742)

[3.6.3 Housekeeping 20](#__RefHeading___Toc193718743)

[3.6.4 Holiday Arrangements 20](#__RefHeading___Toc193718744)

[3.6.5 Special handling 20](#__RefHeading___Toc193718745)

[3.6.6 Report formats 20](#__RefHeading___Toc193718746)

[3.6.7 Report Layout 21](#__RefHeading___Toc193718747)

[3.7 SMP ID Activities Report 23](#__RefHeading___Toc193718748)

[3.7.1 Source of Data 23](#__RefHeading___Toc193718749)

[3.7.2 Operation Flow 23](#__RefHeading___Toc193718750)

[3.7.3 Housekeeping 23](#__RefHeading___Toc193718751)

[3.7.4 Holiday Arrangements 23](#__RefHeading___Toc193718752)

[3.7.5 Report formats 23](#__RefHeading___Toc193718753)

[3.7.6 Report Layout 23](#__RefHeading___Toc193718754)

[3.8 SMP ID Housekeeping Report 26](#__RefHeading___Toc193718755)

[3.8.1 Source of Data 26](#__RefHeading___Toc193718756)

[3.8.2 Operation Flow 26](#__RefHeading___Toc193718757)

[3.8.3 Housekeeping 26](#__RefHeading___Toc193718758)

[3.8.4 Holiday Arrangements 26](#__RefHeading___Toc193718759)

[3.8.5 Report formats 26](#__RefHeading___Toc193718760)

[3.8.6 Report Layout 26](#__RefHeading___Toc193718761)

[4 Reports for CA Adjustment 28](#__RefHeading___Toc193718762)

[4.1 CA Adjustment Report (Options) 28](#__RefHeading___Toc193718763)

[4.1.1 Source of Data 28](#__RefHeading___Toc193718764)

[4.1.2 Operation Flow 28](#__RefHeading___Toc193718765)

[4.1.3 Housekeeping 28](#__RefHeading___Toc193718766)

[4.1.4 Holiday Arrangements 28](#__RefHeading___Toc193718767)

[4.1.5 Report formats 28](#__RefHeading___Toc193718768)

[4.1.6 Report Layout 28](#__RefHeading___Toc193718769)

[4.2 CA Adjustment Report (Futures) 32](#__RefHeading___Toc193718770)

[4.2.1 Source of Data 32](#__RefHeading___Toc193718771)

[4.2.2 Operation Flow 32](#__RefHeading___Toc193718772)

[4.2.3 Housekeeping 32](#__RefHeading___Toc193718773)

[4.2.4 Holiday Arrangements 32](#__RefHeading___Toc193718774)

[4.2.5 Report formats 32](#__RefHeading___Toc193718775)

[4.2.6 Report Layout 32](#__RefHeading___Toc193718776)

[5 Reports for Price Tick Limits 36](#__RefHeading___Toc193718777)

[5.1 Price Tick Limits Report 36](#__RefHeading___Toc193718778)

[5.1.1 Source of Data 36](#__RefHeading___Toc193718779)

[5.1.2 Operation Flow 36](#__RefHeading___Toc193718780)

[5.1.3 Housekeeping 36](#__RefHeading___Toc193718781)

[5.1.4 Holiday Arrangements 36](#__RefHeading___Toc193718782)

[5.1.5 Report formats 36](#__RefHeading___Toc193718783)

[5.1.6 Report Layout 37](#__RefHeading___Toc193718784)

[5.2 Price Tick Limits Exception Report 38](#__RefHeading___Toc193718785)

[5.2.1 Source of Data 38](#__RefHeading___Toc193718786)

[5.2.2 Operation Flow 38](#__RefHeading___Toc193718787)

[5.2.3 Housekeeping 38](#__RefHeading___Toc193718788)

[5.2.4 Holiday Arrangements 38](#__RefHeading___Toc193718789)

[5.2.5 Report formats 38](#__RefHeading___Toc193718790)

[5.2.6 Report Layout 39](#__RefHeading___Toc193718791)

[6 Password Expiration Reports 42](#__RefHeading___Toc193718792)

[6.1 OFG Client Password Expiration Report 42](#__RefHeading___Toc193718793)

[6.1.1 Source of Data 42](#__RefHeading___Toc193718794)

[6.1.2 Operation Flow 42](#__RefHeading___Toc193718795)

[6.1.3 Housekeeping 42](#__RefHeading___Toc193718796)

[6.1.4 Holiday Arrangements 42](#__RefHeading___Toc193718797)

[6.1.5 Special handling 42](#__RefHeading___Toc193718798)

[6.1.6 Report formats 42](#__RefHeading___Toc193718799)

[6.1.7 Report Layout 43](#__RefHeading___Toc193718800)

[6.2 Drop Copy Client Password Expiration Report 44](#__RefHeading___Toc193718801)

[6.2.1 Source of Data 44](#__RefHeading___Toc193718802)

[6.2.2 Operation Flow 44](#__RefHeading___Toc193718803)

[6.2.3 Housekeeping 44](#__RefHeading___Toc193718804)

[6.2.4 Holiday Arrangements 44](#__RefHeading___Toc193718805)

[6.2.5 Special handling 44](#__RefHeading___Toc193718806)

[6.2.6 Report formats 44](#__RefHeading___Toc193718807)

[6.2.7 Report Layout 45](#__RefHeading___Toc193718808)

[7 Last Trading Day Checklist 46](#__RefHeading___Toc193718809)

[7.1 Last Trading Day Checklist Report 46](#__RefHeading___Toc193718810)

[7.1.1 Source of Data 46](#__RefHeading___Toc193718811)

[7.1.2 Operation Flow 46](#__RefHeading___Toc193718812)

[7.1.3 Housekeeping 46](#__RefHeading___Toc193718813)

[7.1.4 Holiday Arrangements 46](#__RefHeading___Toc193718814)

[7.1.5 Special handling 46](#__RefHeading___Toc193718815)

[7.1.6 Report formats 46](#__RefHeading___Toc193718816)

[7.1.7 Report Layout 47](#__RefHeading___Toc193718817)

[8 Instrument Maintenance 48](#__RefHeading___Toc193718818)

[8.1 Instrument Maintenance report for HKFE Options Products 48](#__RefHeading___Toc193718819)

[8.1.1 Source of Data 48](#__RefHeading___Toc193718820)

[8.1.2 Operation Flow 48](#__RefHeading___Toc193718821)

[8.1.3 Housekeeping 48](#__RefHeading___Toc193718822)

[8.1.4 Holiday Arrangements 48](#__RefHeading___Toc193718823)

[8.1.5 Special handling 48](#__RefHeading___Toc193718824)

[8.1.6 Report formats 49](#__RefHeading___Toc193718825)

[8.1.7 Report Layout 49](#__RefHeading___Toc193718826)

[8.2 Instrument Maintenance Report for SEHK Options Products 52](#__RefHeading___Toc193718827)

[8.2.1 Source of Data 52](#__RefHeading___Toc193718828)

[8.2.2 Operation Flow 52](#__RefHeading___Toc193718829)

[8.2.3 Housekeeping 52](#__RefHeading___Toc193718830)

[8.2.4 Holiday Arrangements 52](#__RefHeading___Toc193718831)

[8.2.5 Special handling 52](#__RefHeading___Toc193718832)

[8.2.6 Report formats 53](#__RefHeading___Toc193718833)

[8.2.7 Report Layout 53](#__RefHeading___Toc193718834)

# Document Control

## Change History

|  |  |  |  |
| --- | --- | --- | --- |
| Version  Number | Issue Date | Author | Abstract |
| V1.0 | 31-May-2024 | IT/Markets Systems |  |
| V1.1 | 04-Feb-2024 | IT/Markets Systems | * Updated SMP ID File Submission Status Report, SMP ID Delta Change Report, SMP ID Master Report, SMP ID ECP Submission Status, SMP ID Activities Report, CA Adjustment Report (Options) * Added SMP ID All Submission Status and Instrument Maintenance report section. |
| V1.2 | 13-Mar-2025 | IT/Markets Systems | * Supplemented the FS tag in section 3.6 * Supplemented section 1.2 and 1.3 |

## Document Cross-referenced

|  |  |  |
| --- | --- | --- |
| # | Document | Version |
| 1 | BRD\_DT\_0004 BRS Market Integrity Safeguards | V1.6 |
| 2 | BRD\_DT\_0010 ODP - Automation of Price Limit Monitoring and Handling | 20240606 |
| 3 | BRD\_DT\_0018 ODP - NewFunctionRequest - Capital Adjustmen | 20241015 |
| 4 | BRD\_DT\_0020 ODP – Trading Calendar for multi purpose | 202401121 |
| 5 | BRD\_DT\_0044 BAU Support | V1.6 |

## Abbreviation

|  |  |
| --- | --- |
| RHT | Regular Trading Hour |
| AHT | After Trading Hour |
| SMP | Self-Matched Prevention |

RHT – Regular Trading Hour

AHT – After-Trading Hour

## Distribution List

Derivatives Trading Business Operations

# Introduction

## System Objectives

This encompasses a variety of reports across different areas. It consolidates the report generated in ODP-T with reference to the static Data. These reports aim to provide comprehensive data and status updates across various aspects of the system.

## Scopes

The reports to be described in this specification will be

* SMP ID File Submission Status Report
* SMP ID Full Image Report
* SMP ID Delta Change Report
* SMP ID Master Report
* SMP ID ECP Submission Status
* SMP ID All Submission Status
* SMP ID Activities Report
* SMP ID Housekeeping Report
* CA Adjustment Report (Options)
* CA Adjustment Report (Futures)
* Price Tick Limits Report
* Price Tick Limits Exception Report
* OFG Client Password Expiration Report
* Drop Copy Client Password Expiration Report
* Last Trading Day Checklist Report
* Instrument Maintenance report for HKFE Options Products
* Instrument Maintenance report for SEHK Options Products

## Principal Users

*This section lists out principal users of the system. In general, principal users include:*

* *Derivatives Trading Operations*

## Document Conventions

The notation used in this document consists of:

 "X" for alphanumeric data;

 "9" for numeric data;

 "Z" for numeric data, blank when zero;

 "|" for changes of the current issue.

# Reports for SMP

## SMP ID File Submission Status Report

#FS10017B\_S0030\_10100

The SMP File Submission Status Report contains the latest status of the “SMP ID Maintenance Form” / “Use of Existing SMP ID Form” submitted by EP. Completed and failed requests would be shown on Trading Day T; while outstanding requests will be kept until it turns completed or failed.

### Source of Data

The data source for the report is from database’s SMP ID Request table filtered by the exchange participant ID.

### Operation Flow

From Monday to Friday before 07:30, the report generator will trigger the report generation for SMP ID Request Submission Status Report.

For each exchange participant, the report gathers (1) all in-progress records, (2) completed records with effective date same as current trading date and (3) rejected records with effective date same as current trading date to compute the report. The report is delivered to EP by ECP, EPs without outstanding request will not receive this file.

EPs can keep track of the status of their submission from this report. If there is any error when processing the files, EP can check the rejection code from the report and resubmit the corrected files again.

### Housekeeping

The requirement of this report allows SMP ID Request records in database are physically deleted after a configurable number of days after turned to completed or failed status. Notes that the “All submission Status” in the later section requires records to be kept forever.

### Holiday Arrangements

No report on non-trading day.

### Report formats

The report will be in CSV format contains SMP ID request submission status for EP with outstanding request.

### Report Layout

Sample:

Date,Time,Action,Creation Ref No,SMP ID,Primary Exchange Participant,Sharing Exchange Participant,SMP Instruction,Status,Rejection Code

20240219,10:19:10,Create,"UB01","9111F","UWDMA","",A,Completed,

20240219,11:29:11,Create,"UB02","","UWDMA","",A,In Progress,

20240219,12:39:12,,"","","","",,Rejected,1102

#### Report Attribute

|  |  |
| --- | --- |
| Purpose | Show SMP ID submission request status |
| Frequency | Refer to Operation Flow |
| Sequence | Sorted by Date, Time, SMP ID ascendingly. |
| File Name | DSMPSTS\_NNNNN\_YYYYMMDD.csv  Where NNNNN is HKATS Customer Code, YYYYMMDD is date of report. |
| Chinese Version | N/A |

#### Report Type Setup

N/A

#### Field Description

| **Field name** | **Description** | **Position in csv** | **Format** | **Remarks** |
| --- | --- | --- | --- | --- |
| Date | File submission date. | 1 | YYYYMMDD |  |
| Time | File submission time. | 2 | HH:mm:ss |  |
| Action | Submission action. | 3 | X(30) | Create – Creation of SMP ID  Terminate – Termination of SMP ID  Sharing – Sharing of SMP ID  Remove Sharing – Removal of SMP ID Sharing  Change Instruction – Change of SMP Instruction  Apply Usage – Application on the use of existing SMP ID |
| Creation Ref No | The Creation Ref. No. filled in the Request Form. | 4 | X(4) |  |
| SMP ID | The SMP ID. | 5 | X(9) | For Creation of SMP ID  SMP ID will be available after the request had been completed.  For other Actions  This field reflects the SMP ID filled in the request form. |
| Primary Exchange Participant | The owner of the SMP ID. | 6 | X(5) |  |
| Sharing Exchange Participant | Participant ID of Additional EP of the SMP ID. | 7 | X(5) | Only available when Action = Sharing / Remove Sharing |
| SMP Instruction | SMP Cancellation method. | 8 | X(1) | A – Cancel Aggressive  P – Cancel Passive  Applicable to Action Create / Change Instruction. |
| Status | Submission status. | 9 | X(40) | Possible value:  Wait for Application from Other EP  In Progress  Completed  Rejected |
| Rejection Code | The reason of rejection. | 10 | 9(4) | Applicable to Status Rejected.  See Section 5.8 for the list of rejection codes. |

### Rejection Code

|  |  |
| --- | --- |
| **Code** | **Reject Reason** |
| **1101** | Form corrupted/non-readable. |
| **1102** | Form Action not selected. |
| **1103** | Missing SMP ID. |
| **1104** | Missing Sharing HKATS Customer Code. |
| **1107** | Missing Primary HKATS Customer Code. |
| **1108** | HKATS Customer Code does not exist. |
| **1109** | Exchange Participant Code or Submission Time not valid. |
| **1111** | In Maintenance Form, the Primary HKATS Customer Code is the same as Sharing HKATS Customer Code. |
| **1112** | In Consent Form, the Sharing HKATS Customer Code is the same as Primary HKATS Customer Code. |
| **1120** | SMP Instruction not selected. |
| **1242** | Request error: Duplicated request. |
| **1244** | Request error: SMP ID not found or terminated. |
| **1245** | Request error: SMP ID suspended. |
| **1246** | Request error: Primary HKATS Customer Code not found. |
| **1247** | Request error: Sharing HKATS Customer Code not found. |
| **1250** | Request error: SMP ID Sharing does not exist. |
| **1301** | Execution error: Number of active SMP ID limit exceeded. |
| **1302** | Execution error: SMP ID Sharing limit exceeded. |
| **1303** | Sharing / Consent has expired. |
| **2001** | On EP request. |
| **2999** | Please contact HKEX. |

## SMP ID Full Image Report

#FS10017B\_S0030\_20100

The SMP ID Full Image Reports contains the list of SMP ID that EP could use for trading supporting SMP features.

### Source of Data

The data source for the report is from database’s SMP ID table filtered by the exchange participant ID.

### Operation Flow

From Monday to Friday before 07:30, the report generator will trigger the report generation for SMP ID Full Image Report. The report is delivered to EP by ECP.

For each exchange participant, the report gathers all SMP ID with active and suspended status in the SMP ID List. EPs without SMP ID will not receive this file.

### Housekeeping

SMP ID records in database are physically deleted after a configurable number of days after logical deleted (Deleted status).

### Holiday Arrangements

No report on non-trading day.

### Report formats

The report will be in CSV format contains all SMP IDs relevant to the EP.

### Report Layout

Sample:

SMP ID,Primary Exchange Participant,SMP Instruction,SMP ID Status,Sharing Exchange Participant

5113L,JMP,A,Active,

9114M,JMPMF,A,Active,JMP|MPFMJ|MPFMX

#### Report Attribute

|  |  |
| --- | --- |
| Purpose | Show SMP ID available to the EP |
| Frequency | Refer to Operation Flow |
| Sequence | Sorted by SMP ID ascendingly. |
| File Name | DSMPFIMM\_NNNNN\_YYYYMMDD.csv  Where NNNNN is HKATS Customer Code, YYYYMMDD is date of report. |
| Chinese Version | N/A |

#### Report Type Setup

N/A

#### Field Description

| **Field name** | **Description** | **Position in csv** | **Format** | **Remarks** |
| --- | --- | --- | --- | --- |
| SMP ID | The SMP ID. | 1 | X(9) |  |
| Primary Exchange Participant | The owner of the SMP ID. | 2 | X(5) |  |
| SMP Instruction | SMP Cancellation method. | 3 | X(1) | A – Cancel Aggressive  P – Cancel Passive |
| SMP ID Status | The status of SMP ID. | 4 | X(20) | Possible value:  Active  Suspended |
| Sharing Exchange Participant | A list of Exchange Participant sharing the ID. | 5 | X(5) | Multiple, separated by the Pipe Character (ASCII 0x7C). |

## SMP ID Delta Change Report

#FS10017B\_S0030\_30100

The SMP ID Delta Change Reports highlights the changes of SMP ID and SMP ID Sharing related to relevant exchange participant.

### Source of Data

The data source for the report is from database’s SMP ID Change table filtered by the exchange participant ID.

### Operation Flow

From Monday to Friday before 07:30, the report generator will trigger the report generation for SMP ID Delta Change Report. The report is delivered to EP by ECP.

For each exchange participant, the report gathers all SMP ID change records which:

1. Changes initiated by form submission having effective date as trading date.
2. Changes made by HKEX having effective date in last trading date.

EPs without SMP ID changes will not receive this file.

### Housekeeping

SMP ID change records in database should be kept 3 years for purpose of audit trail and record keeping after logical deleted (Deleted status).

### Holiday Arrangements

No report on non-trading day.

### Report formats

The report will be in CSV format contains SMP ID delta changes for the EP.

### Report Layout

Sample:

SMP ID,Primary Exchange Participant,Action,SMP Instruction,Sharing Exchange Participant

0111V,MPFMJ,Create,A,

0112H,MPFMJ,Share,A,JMP

0112H,MPFMJ,Remove Sharing,,JMPMF

#### Report Attribute

|  |  |
| --- | --- |
| Purpose | Highlights the changes of SMP ID to an EP. |
| Frequency | Refer to Operation Flow |
| Sequence | Sorted by SMP ID ascendingly. |
| File Name | DSMPDLTM\_NNNNN\_YYYYMMDD.csv  Where NNNNN is HKATS Customer Code, YYYYMMDD is date of report. |
| Chinese Version | N/A |

#### Report Type Setup

N/A

#### Field Description

| **Field name** | **Description** | **Position in csv** | **Format** | **Remarks** |
| --- | --- | --- | --- | --- |
| SMP ID | The SMP ID. | 1 | X(9) |  |
| Primary Exchange Participant | The owner of the SMP ID. | 2 | X(5) |  |
| Action | The action resulted in changes. | 3 | X(30) | Create – Creation of SMP ID  Terminate – Termination of SMP ID  Sharing – Sharing of SMP ID  Remove Sharing – Removal of SMP ID Sharing  Change Instruction – Change of SMP Instruction  Suspension – Suspension of SMP ID  Resumption – SMP ID resume from suspension  Apply Usage – Application on the use of existing SMP ID |
| SMP Instruction | SMP Cancellation method. | 4 | X(1) | A – Cancel Aggressive  P – Cancel Passive |
| Sharing Exchange Participant | Participant ID of Additional EP of the SMP ID. | 5 | X(5) | Only available when Action = Sharing / Remove Sharing |

## SMP ID Master Report

#FS10017B\_S0030\_40100

The report is for internal use, it shows all SMP IDs from all participants and their attributes.

### Source of Data

The data source for the report is from database’s SMP ID table.

### Operation Flow

From Monday to Friday before 07:05, the automatic report generator will trigger the report generation for SMP ID Master Report. All SMP IDs for all participants with active and suspended status are included in the report. Besides, the report generation can be manually triggered.

The report is delivered to:

* A designated location in file server.
* DSMP@hkex.com.hk email address.

### Housekeeping

SMP ID records in database are physically deleted after a configurable number of days after logical deleted (Deleted status).

### Holiday Arrangements

No report on non-trading day.

### Special handling

A configuration is allowed to include a maximum of 20 exchange participants that are excluded from the report. The feature is designed to exclude internal exchange participants for monitoring purposes, e.g. HKEX, HKSFC etc.

### Report formats

The report will be in CSV format contains all SMP IDs across all EPs for internal use.

### Report Layout

Sample:

Primary Exchange Participant,SMP ID,SMP Instruction,SMP ID Status,Sharing Exchange Participant

MPFDD,5113L,A,Active,

MPFMC,9114M,A,Active,JMP|MPFMJ|MPFMX

#### Report Attribute

|  |  |
| --- | --- |
| Purpose | Shows full set of SMP ID for internal use. |
| Frequency | Refer to Operation Flow |
| Sequence | Sorted by exchange participant ID, SMP ID ascendingly. |
| File Name | MASTER\_yyyymmddM.csv  yyyymmdd is date of report. |
| Chinese Version | N/A |

#### Report Type Setup

|  |  |
| --- | --- |
| **Report Type** | **Exclusion Participant list for SMP ID Master Report** |
| **Report Name** | Specify the ID for the report. |
| **Participant** | Specify the list of Participant to be excluded |

#### Field Description

| **Field name** | **Description** | **Position in csv** | **Format** | **Remarks** |
| --- | --- | --- | --- | --- |
| Primary Exchange Participant | The owner of the SMP ID. | 1 | X(5) |  |
| SMP ID | The SMP ID. | 2 | X(9) |  |
| SMP Instruction | SMP Cancellation method. | 3 | X(1) | A – Cancel Aggressive  P – Cancel Passive |
| SMP ID Status | The status of SMP ID. | 4 | X(20) | Possible value:  Active  Suspended |
| Sharing Exchange Participant | A list of Exchange Participant sharing the ID. | 5 | X(5) | Multiple, separated by the Pipe Character (ASCII 0x7C). |

## SMP ID ECP Submission Status

#FS10017B\_S0030\_50100

The report is for internal use, it shows a summary of the latest active request submission status from ECP.

### Source of Data

The data source for the report is from database’s SMP ID Request table.

### Operation Flow

From Monday to Friday before 16:05, the automatic report generator will trigger the report generation for the SMP ID ECP Submissions Status. Besides, the report generation can be manually triggered. The report is delivered to the following location:

* A designated location in file server.
* DSMP@hkex.com.hk email address.

The report gathers:

1. All in-progress records,
2. Completed records with status change date same as current trading date,
3. Rejected records with status change date same as current trading date.

### Housekeeping

The requirement of this report allows SMP ID Request records in database are physically deleted after a configurable number of days after turned to completed or failed status. Notes that the “All submission Status” in the later section requires records to be kept forever.

### Holiday Arrangements

No report on non-trading day.

### Report formats

The report will be in CSV format contains all active SMP ID request submission across all EPs for internal use.

### Report Layout

Sample:

Primary Exchange Participant,SMP ID,SMP Instruction,Sharing Exchange Participant,Filename,Creation Ref No,Action,Status,Rejection Code

GSA,,P,,DSMPREQ\_00GSF\_20240219.20240219164838.829381.pdf,GS01,CREATE,

JMPAA,,P,,DSMPREQ\_00JMP\_20240219.20240219164758.829371.pdf,MP01,CREATE,

MPFDD,,A,,DSMPREQ\_00MPF\_20240219.20240219165029.829411.pdf,MC01,CREATE,

MPFMC,,A,,DSMPREQ\_00MPF\_20240219.20240219164958.829401.pdf,MC01,CREATE,

UWDMA,,A,,DSMPREQ\_00UWD\_20240219.20240219164919.829391.pdf,UB01,CREATE,

#### Report Attribute

|  |  |
| --- | --- |
| Purpose | Show SMP ID submission request status for internal use. |
| Frequency | Refer to Operation Flow |
| Sequence | Sorted by SMP ID ascendingly. |
| File Name | ECP\_Submissions.YYYYMMDD.HHMMSS.csv  Where YYYYMMDD.HHMMSS is date and time of report. |
| Chinese Version | N/A |

#### Report Type Setup

N/A

#### Field Description

| **Field name** | **Description** | **Position in csv** | **Format** | **Remarks** |
| --- | --- | --- | --- | --- |
| Primary Exchange Participant | The owner of the SMP ID. | 1 | X(5) |  |
| SMP ID | The SMP ID. | 2 | X(9) |  |
| SMP Instruction | SMP Cancellation method. | 3 | X(1) | A – Cancel Aggressive  P – Cancel Passive |
| Sharing Exchange Participant | Participant ID of Additional EP of the SMP ID. | 4 | X(5) | Only available when Action = Sharing / Remove Sharing |
| Filename | The filename submitted by EP. | 5 | X(256) |  |
| Creation Ref No | The Creation Ref. No. filled in the Request Form. | 6 | X(4) |  |
| Action | The action resulted in changes. | 7 | X(30) | Create – Creation of SMP ID  Terminate – Termination of SMP ID  Sharing – Sharing of SMP ID  Remove Sharing – Removal of SMP ID Sharing  Change Instruction – Change of SMP Instruction  Apply Usage – Application on the use of existing SMP ID  Error – Error in decoding the PDF |
| Status | The submission status | 8 | X(40) | <blank> – CS has not yet attended.  Wait for Cons(ent) – Received share request waiting for the Consent.  Completed – Approved and completed accordingly.  Rejected – Rejected by CS.  Error – Error in PDF decoding or Error in processing or request has expired – Attention required from CS.  Rejection Code is appended for reference when Rejected / Error. |
| Rejection Code | The reason of rejection. | 9 | 9(4) | Applicable to Status Rejected / Error.  See Section 5.8 for the list of rejection codes. |

## SMP ID All Submission Status

#FS10017B\_S0030\_80100

The report is for internal use, it shows a summary of all the request submission status from ECP.

### Source of Data

The data source for the report is from database’s SMP ID Request table.

### Operation Flow

From Monday to Friday before 16:05, the automatic report generator will trigger the report generation for the SMP ID ECP Submissions Status. Besides, the report generation can be manually triggered. The report is delivered to the following location:

* A designated location in file server.
* DSMP@hkex.com.hk email address.

The report gathers:

1. All in-progress records,
2. All Completed records,
3. All Rejected records.

### Housekeeping

The “All submission Status” requires request records to be kept forever.

### Holiday Arrangements

No report on non-trading day.

### Special handling

N/A

### Report formats

The report will be in CSV format contains all SMP ID request submissions across all EPs for internal use.

### Report Layout

Sample:

Primary Exchange Participant,SMP ID,SMP Instruction,Sharing Exchange Participant,Filename,Creation Ref No,Action,Status,Rejection Code

GSA,,P,,DSMPREQ\_00GSF\_20240219.20240219164838.829381.pdf,GS01,CREATE,

JMPAA,,P,,DSMPREQ\_00JMP\_20240219.20240219164758.829371.pdf,MP01,CREATE,

MPFDD,,A,,DSMPREQ\_00MPF\_20240219.20240219165029.829411.pdf,MC01,CREATE,

MPFMC,,A,,DSMPREQ\_00MPF\_20240219.20240219164958.829401.pdf,MC01,CREATE,

UWDMA,,A,,DSMPREQ\_00UWD\_20240219.20240219164919.829391.pdf,UB01,CREATE,

#### Report Attribute

|  |  |
| --- | --- |
| Purpose | Show SMP ID submission request status for internal use. |
| Frequency | Refer to Operation Flow |
| Sequence | Sorted by SMP ID ascendingly. |
| File Name | ECP\_Submissions.YYYYMMDD.HHMMSS.csv  Where YYYYMMDD.HHMMSS is date and time of report. |
| Chinese Version | N/A |

#### Report Type Setup

N/A

#### Field Description

| **Field name** | **Description** | **Position in csv** | **Format** | **Remarks** |
| --- | --- | --- | --- | --- |
| Primary Exchange Participant | The owner of the SMP ID. | 1 | X(5) |  |
| SMP ID | The SMP ID. | 2 | X(9) |  |
| SMP Instruction | SMP Cancellation method. | 3 | X(1) | A – Cancel Aggressive  P – Cancel Passive |
| Sharing Exchange Participant | Participant ID of Additional EP of the SMP ID. | 4 | X(5) | Only available when Action = Sharing / Remove Sharing |
| Filename | The filename submitted by EP. | 5 | X(256) |  |
| Creation Ref No | The Creation Ref. No. filled in the Request Form. | 6 | X(4) |  |
| Action | The action resulted in changes. | 7 | X(30) | Create – Creation of SMP ID  Terminate – Termination of SMP ID  Sharing – Sharing of SMP ID  Remove Sharing – Removal of SMP ID Sharing  Change Instruction – Change of SMP Instruction  Apply Usage – Application on the use of existing SMP ID  Error – Error in decoding the PDF |
| Status | The submission status | 8 | X(40) | <blank> – CS has not yet attended.  Wait for Cons(ent) – Received share request waiting for the Consent.  Completed – Approved and completed accordingly.  Rejected – Rejected by CS.  Error – Error in PDF decoding or Error in processing or request has expired – Attention required from CS.  Rejection Code is appended for reference when Rejected / Error. |
| Rejection Code | The reason of rejection. | 9 | 9(4) | Applicable to Status Rejected / Error.  See Section 5.8 for the list of rejection codes. |

## SMP ID Activities Report

#FS10017B\_S0030\_60100

The report is for internal use, it contains SMP ID Delta Change of all EP due to both exchange participant submission and manual administration UI.

### Source of Data

The data source for the report is from database’s SMP ID Change table.

### Operation Flow

From Monday to Friday before 07:30, the automatic report generator will trigger the report generation for SMP ID Activities Report. Besides, the report generation can be manually triggered. The report is delivered to a designated location in file server.

The report gathers all SMP ID change records which:

1. Changes initiated by form submission having effective date as trading date.
2. Changes made by HKEX having effective date in last trading date.

### Housekeeping

SMP ID change records in database should be kept 3 years for purpose of audit trail and record keeping after logical deleted (Deleted status).

### Holiday Arrangements

No report on non-trading day.

### Report formats

The report will be in CSV format contains all SMP ID changes across all EPs for internal use.

### Report Layout

File layout:

| **Line** | **Description** |
| --- | --- |
| First | Date and time of the report. |
| Second | Description of the data records. |
| 3+ | Data records |
| Last | Number of data records. |

Sample:

20241119,070501

SMP ID,Primary Exchange Participant,Action,SMP Instruction,Sharing Exchange Participant

0111V,MPFMJ,Create,A,

0112H,MPFMJ,Share,A,JMP

0112H,MPFMJ,Remove Sharing,,JMPMF

3

#### Report Attribute

|  |  |
| --- | --- |
| Purpose | Highlights any changes of SMP ID |
| Frequency | Refer to Operation Flow |
| Sequence | Sorted by SMP ID ascendingly. |
| File Name | SMPIDACT\_YYYYMMDD.HHMMSS.csv  Where YYYYMMDD.HHMMSS is date and time of report. |
| Chinese Version | N/A |

#### Report Type Setup

N/A

#### Field Description

| **Field name** | **Description** | **Position in csv** | **Format** | **Remarks** |
| --- | --- | --- | --- | --- |
| SMP ID | The SMP ID. | 1 | X(9) |  |
| Primary Exchange Participant | The owner of the SMP ID. | 2 | X(5) |  |
| Action | The action resulted in changes. | 3 | X(30) | Create – Creation of SMP ID  Terminate – Termination of SMP ID  Sharing – Sharing of SMP ID  Remove Sharing – Removal of SMP ID Sharing  Change Instruction – Change of SMP Instruction  Suspension – Suspension of SMP ID  Resumption – SMP ID resume from suspension  Apply Usage – Application on the use of existing SMP ID |
| SMP Instruction | SMP Cancellation method. | 4 | X(1) | A – Cancel Aggressive  P – Cancel Passive |
| Sharing Exchange Participant | Participant ID of Additional EP of the SMP ID. | 5 | X(5) | Only available when Action = Sharing / Remove Sharing |

## SMP ID Housekeeping Report

#FS10017B\_S0030\_70100

The report is for internal use, it contains a list of physically deleted SMP ID records. When a SMP ID is physically deleted, it no longer exists in the system and cannot be queried in admin UI.

### Source of Data

Housekeeping process. During housekeeping, the process will write those remove records in the report file.

### Operation Flow

At EOD trading state, the housekeeping task will execute. It deletes (physically) SMP ID records from the database with deleted status and last update date passed a configurable number of days. During the process, the task will write those SMP IDs in the SMP ID Housekeeping Report. The report will always be created and will contain 0 record when there is no record being physically deleted. The report is delivered to a designated location in file server.

### Housekeeping

N/A

### Holiday Arrangements

No report on non-trading day.

### Report formats

The report will be in CSV format contains all physically deleted SMP IDs.

### Report Layout

File layout:

| **Line** | **Description** |
| --- | --- |
| First | Date and time of the report. |
| Second | Description of the data records. |
| 3+ | Data records |
| Last | Number of data records. |

Sample:

20241119,030001

Primary Exchange Participant,SMP ID,SMP Instruction

JMPAA,5113L,P

MPFDD,9114M,A

MPFMC,1234J,A

UWDMA,4321D,A

4

#### Report Attribute

|  |  |
| --- | --- |
| Purpose | Show SMP ID submission request status for internal use. |
| Frequency | Refer to Operation Flow |
| Sequence | Sorted by SMP ID ascendingly. |
| File Name | SMPIDHK.YYYYMMDD.HHMMSS.csv  Where YYYYMMDD.HHMMSS is date and time of report. |
| Chinese Version | N/A |

#### Report Type Setup

N/A

#### Field Description

| **Field name** | **Description** | **Position in csv** | **Format** | **Remarks** |
| --- | --- | --- | --- | --- |
| Primary Exchange Participant | The owner of the SMP ID. | 1 | X(5) |  |
| SMP ID | The SMP ID. | 2 | X(9) |  |
| SMP Instruction | SMP Cancellation method. | 3 | X(1) | A – Cancel Aggressive  P – Cancel Passive |

# Reports for CA Adjustment

## CA Adjustment Report (Options)

#FS10017B\_S0040\_10100

The reports are for internal use, they contain all options exercise price and contract size changes after capital adjustment for Comparative Table of Strike Prices CIRCULAR preparation.

### Source of Data

The data source for the report is from database’s CA Event table.

### Operation Flow

The reports are generated after a CA event is done.

It gathers:

1. Adjustment Ratio for the CA event.
2. For each exercise price for options,
   1. The original and adjusted exercise prices.
   2. The original and adjusted contract size.

A CA event might involve multiple original underlying, there will be an individual report for each of them.

### Housekeeping

CA event data are kept in the system for 7 years.

### Holiday Arrangements

N/A

### Report formats

The reports will be in CSV format with all exercise prices and contract sizes change.

### Report Layout

File layout:

| **Line** | **Description** |
| --- | --- |
| 1st | Date of the report. |
| 2nd | CA Event ID. |
| 3rd | Instrument Group Type, Options/Futures. |
| 4th | CA Type. |
| 5th | Closing Price |
| 6th | Adjustment Ratio. |
| 7th | Original Underlying, New Underlying. |
| 8th + | Data records. Original Exercise Price, Original Contract Size, Adjusted Exercise Price, Adjusted Contract Size. |
| Last | Number of records. |

Sample:

#20240625

#2024000001

#Options

#Bonus Issue of Shares

#16.23

#0.7692

#YZC,YZB

8.00,2000,6.15,2601.6260

8.25,2000,6.35,2598.4252

8.50,2000,6.54,2599.3884

#3

#### Report Attribute

|  |  |
| --- | --- |
| Purpose | Show exercise price and contract size changes after a CA event. |
| Frequency | Refer to Operation Flow |
| Sequence | Sorted by exercise price ascendingly. |
| File Name | CA.AAAAAAAAAA.BBB.CCC.OPT.YYYYMMDD.csv  Where:  AAAAAAAAAA is the CA Event ID,  BBB is the original underlying,  CCC is the new underlying,  YYYYMMDD is the CA event date. |
| Chinese Version | N/A |

#### Report Type Setup

N/A

#### Field Description

| **Field name** | **Description** | **Position in csv** | **Format** | **Remarks** |
| --- | --- | --- | --- | --- |
| Date of the report | The date of CA Event | 1 | YYYYMMDD |  |
| CA Event ID | The ID associated to all changes by this CA Event. | 1 | 9(10) |  |
| Instrument Group Type | The Group Type attribute in Instrument Group. | 1 | X(20) | The value is “Options” |
| CA Type | The CA Type selected for the CA Event. | 1 | X(40) | Possible values:  Right Issue  Bonus Issue of Shares  Bonus Issue of Warrants  Share Consolidation  Share Sub-division  Merger (Shares + Cash)  Merger (Shares Only)  Spin-Off (E-Day)  Spin-Off (F Day; with Entitlement)  Other Cash Distribution  Other CA Events |
| Adjustment Ratio | The calculated adjustment ratio for the CA Event. | 1 | 9(5.4) |  |
| Original Underlying | The underlying ID before CA Event. | 1 | X(6) |  |
| New Underlying | The underlying ID after CA Event. | 2 | X(6) |  |
| Original Exercise Price | The exercise price before CA Event. | 1 | 9 | Number of decimals from Instrument reference data (Instrument name standard). |
| Original Contract Size | The contract size before CA Event. | 2 | 9 | Number of decimals from Instrument reference data (Price Decimals in Instrument Class). |
| Adjusted Exercise Price | The exercise price after CA Event. | 3 | 9 | Number of decimals from Instrument reference data (Instrument name standard). |
| Adjusted Contract Size | The contract size after CA Event. | 4 | 9 | Number of decimals from Instrument reference data (Price Decimals in Instrument Class). |
| Number of records | The number of data records in the report. | 1 | 9(10) |  |

## CA Adjustment Report (Futures)

#FS10017B\_S0040\_10200

The reports are for internal use, they contain all futures contract changes after capital adjustment for Comparative Table of Contract Multiplier CIRCULAR preparation.

### Source of Data

The data source for the report is from database’s CA Event table.

### Operation Flow

The reports are generated after a CA event is done.

It gathers:

1. Adjustment Ratio for the CA event.
2. For each contract month for futures,
   1. The settlement price.
   2. The original and adjusted contract multiplier.

A CA event might involve multiple original underlying, there will be an individual report for each of them.

### Housekeeping

CA event data are kept in the system for 7 years.

### Holiday Arrangements

N/A

### Report formats

The reports will be in CSV format with all exercise prices and contract sizes change.

### Report Layout

File layout:

| **Line** | **Description** |
| --- | --- |
| 1st | Date of the report. |
| 2nd | CA Event ID. |
| 3rd | Instrument Group Type, Options/Futures. |
| 4th | CA Type. |
| 5th | Closing Price |
| 6th | Adjustment Ratio. |
| 7th | Original Underlying, New Underlying. |
| 8th + | Data records. Contract Month, Original Contracted Price, Original Contracted Multiplier, Adjusted Contract Multiplier. |
| Last | Number of records. |

Sample:

#20240625

#2024000001

#Futures

#Bonus Issue of Shares

#16.23

#0.7692

#YZC,YZB

June 2024,15.39,2000,2599.6622

July 2024,15.44,2000,2599.3266

August 2024,15.43,2000,2599.8315

September 2024,16.30,2000,2599.6810

December 2024,16.65,2000,2599.5316

#5

#### Report Attribute

|  |  |
| --- | --- |
| Purpose | Show exercise price and contract size changes after a CA event. |
| Frequency | Refer to Operation Flow |
| Sequence | Sorted by contract month ascendingly. |
| File Name | CA.AAAAAAAAAA.BBB.CCC.FUT.YYYYMMDD.csv  Where:  AAAAAAAAAA is the CA Event ID,  BBB is the original underlying,  CCC is the new underlying,  YYYYMMDD is the CA event date. |
| Chinese Version | N/A |

#### Report Type Setup

N/A

#### Field Description

| **Field name** | **Description** | **Position in csv** | **Format** | **Remarks** |
| --- | --- | --- | --- | --- |
| Date of the report | The date of CA Event | 1 | YYYYMMDD |  |
| CA Event ID | The ID associated to all changes by this CA Event. | 1 | 9(10) |  |
| Instrument Group Type | The Group Type attribute in Instrument Group. | 1 | X(20) | The value is “Futures” |
| CA Type | The CA Type selected for the CA Event. | 1 | X(40) | Possible values:  Right Issue  Bonus Issue of Shares  Bonus Issue of Warrants  Share Consolidation  Share Sub-division  Merger (Shares + Cash)  Merger (Shares Only)  Spin-Off (E-Day)  Spin-Off (F Day; with Entitlement)  Other Cash Distribution  Other CA Events |
| Adjustment Ratio | The calculated adjustment ratio for the CA Event. | 1 | 9(5.4) |  |
| Original Underlying | The underlying ID before CA Event. | 1 | X(6) |  |
| New Underlying | The underlying ID after CA Event. | 2 | X(6) |  |
| Contract Month |  | 1 | MMM YYYY |  |
| Original Contracted Price | The settlement price of the contract on CA Event date. | 2 | 9 | Number of decimals from Instrument reference data (Tick table). |
| Original Contract Multiplier | The price quotation factor in original instrument class. | 3 | 9 | Number of decimals from Instrument reference data (Price Decimals in Instrument Class). |
| Adjusted Contract Multiplier | The price quotation factor in new instrument class. | 4 | 9 | Number of decimals from Instrument reference data (Price Decimals in Instrument Class). |
| Number of records | The number of data records in the report. | 1 | 9(10) |  |

# Reports for Price Tick Limits

## Price Tick Limits Report

#FS10017B\_S0050\_10100

Price Tick Limits Report is an internal report. It contains the list of instrument classes and combo classes and their corresponding calculated upper and lower price tick limits.

### Source of Data

The data source for the report is from database’s price tick limits tables.

### Operation Flow

Price Tick Limits Report will be generated after each batch of price tick limits calculation. The report contains the calculation results of the batch.

### Housekeeping

N/A

### Holiday Arrangements

No report on non-trading day

### Report formats

The report is in CSV format and is available for internal download only.

### Report Layout

Sample:

Instrument Class,Combo Class, Price Tick Lower Limit,Price Tick Upper Limit

HSIFUT,,19032,21014

,HSITS01,982,1324

#### Report Attribute

|  |  |
| --- | --- |
| Purpose | List the calculated price tick limits for each batch of instrument class/combo class |
| Frequency | Refer to Operation Flow |
| Sequence | Instrument Class first (sort by Instrument Class ID in alphabetical order),  then Combo Class (sort by Combo Class ID in alphabetical order) |
| File Name | PriceTickLimit\_<Batch ID>\_<YYYYMMDDHHMMSS>.csv |
| Chinese Version (optional) | N/A |

#### Report Type Setup

N/A

#### Field Description

| **Field name** | **Description** | **Position in csv** | **Format** | **Remarks** |
| --- | --- | --- | --- | --- |
| Instrument Class ID | Instrument Class ID | 1 | X(8) |  |
| Combo Class ID | Combo Class ID | 2 | X(14) |  |
| Price Tick Upper Limit | Calculated price tick upper limit | 3 | Z,ZZ9.99 |  |
| Price Tick Lower Limit | Calculated price tick lower limit | 4 | Z,ZZ9.99 |  |

## Price Tick Limits Exception Report

#FS10017B\_S0050\_20100

Price Tick Limits Exception Report is an internal report. It contains exceptions or errors encountered during price tick limits calculation.

### Source of Data

The data source for the report is from database’s price tick limits and settlement price tables.

### Operation Flow

Price Tick Limits Exception Report will be generated after each batch of price tick limits calculation. The report contains the exceptions or errors during the calculation.

### Housekeeping

N/A

### Holiday Arrangements

No report on non-trading day

### Report formats

The report is in CSV format and is available for internal download only.

### Report Layout

Sample:

Instrument Class ID,Combo Class ID,Reference Price,Prev Reference Price,Calculated Price Tick Lower Limit,Current Price Tick Lower Limit,Calculated Price Tick Upper Limit,Current Price Tick Upper Limit,Reference Price Not Available,Derivate Exception from Prev Reference Price,Lower Exceed Default,Derivate Exception from Prev Lower,Upper Exceed Default,Derivate Exception from Prev Upper

HSIFUT,,20001,19803,20098, 21014,19032,18932,N,N,Y,N,N,N

,HSITS01,20001,19803,1290,1324,982,921,N,N,Y,N,N,N

#### Report Attribute

|  |  |
| --- | --- |
| Purpose | List the price tick limits calculation exceptions or errors for each batch of instrument class/combo class |
| Frequency | Refer to Operation Flow |
| Sequence | Instrument Class first (sort by Instrument Class ID in alphabetical order),  then Combo Class (sort by Combo Class ID in alphabetical order) |
| File Name | PriceTickLimitException\_<Batch ID>\_<YYYYMMDDHHMMSS>.csv |
| Chinese Version (optional) | N/A |

#### Report Type Setup

N/A

#### Field Description

| **Field name** | **Description** | **Position in csv** | **Format** | **Remarks** |
| --- | --- | --- | --- | --- |
| Instrument Class ID | Instrument Class ID | 1 | X(8) |  |
| Combo Class ID | Combo Class ID | 2 | X(14) |  |
| Reference Price | Reference price for calculation (i.e. settlement price of spot month futures) | 3 | Z,ZZ9.99 | Applicable for Futures Instrument Class and Combo Class  Empty for Options Instrument Class |
| Prev Reference Price | Reference price for previous day calculation | 4 | Z,ZZ9.99 | Applicable for Futures Instrument Class and Combo Class  Empty for Options Instrument Class |
| Calculated Price Tick Upper Limit | Calculated price tick upper limit | 5 | Z,ZZ9.99 |  |
| Current Price Tick Upper Limit | Current price tick upper limit | 6 | Z,ZZ9.99 |  |
| Calculated Price Tick Lower Limit | Calculated price tick lower limit | 7 | Z,ZZ9.99 |  |
| Current Price Tick Lower Limit | Current price tick lower limit | 8 | Z,ZZ9.99 |  |
| Reference Price Not Available | Flag to indicate if today reference price is not available | 9 | X(1) | Y or N, applicable for Futures Instrument Class and Combo Class  Empty for Options Instrument Class |
| Derivate Exception from Prev Reference Price | Flag to indicate if the change of today and previous day reference price is larger than the configured exception deviation | 10 | X(1) | Y or N, applicable for Futures Instrument Class and Combo Class  Empty for Options Instrument Class |
| Upper Exceed Default | Flag to indicate if calculated upper limit exceeds default upper limit | 11 | X(1) | Y or N |
| Derivate Exception from Prev Upper | Flag to indicate if the change of calculated upper limit and current upper limit is larger than the configured exception deviation | 12 | X(1) | Y or N |
| Lower Exceed Default | Flag to indicate if calculated lower limit exceeds default lower limit | 13 | X(1) | Y or N |
| Derivate Exception from Prev Lower | Flag to indicate if the change of calculated lower limit and current lower limit is larger than the configured exception deviation | 14 | X(1) | Y or N |

# Password Expiration Reports

## OFG Client Password Expiration Report

#FS10017B\_S0060\_10100

This report prints the number of calendar days that password will expire of all OFG Active Client.

By default, this report is printed in ascending sequence based on the client ID.

### Source of Data

Database

### Operation Flow

Daily **before** the start of the day rollover

### Housekeeping

2 weeks retention period

### Holiday Arrangements

No

### Special handling

Admin GUI is able to trigger this report generation manually

### Report formats

| Field | Type | Size | Remarks |
| --- | --- | --- | --- |
| Comp ID | Alphanumeric | 10 |  |
| Trader ID | Alphanumeric | 10 |  |
| Exchange Participant ID | Alphanumeric | 5 |  |
| Last Successful Logon Date | Date Time | 8 |  |
| Password Expiry Date | Date | 8 |  |
| No. of Days to Expire | Numeric | 4 | Counting of number of days starts from current day. Zero is printed if password has expired |
| Locked? | Boolean | 1 |  |

### Report Layout

01,,<Report ID>

02,,<Company Name>

02,,<Report Header Name>

02,,DATE: DD/MM/YYYY TIME: HH:MM

03,01,<Section Header> #e.g. Record type name

04,01,<Field Name 1>,< Field Name 2>,< Field Name 3>,…

05,01,<Value 1>,<Value 2>,<Value 3>,…

06,01,Total records,ZZZZZZ9

07,,Total records,ZZZZZZ9

99,,

#### Report Attribute

|  |  |
| --- | --- |
| Purpose | Capture GUI user login status daily |
| Frequency | Daily |
| Sequence | Ascending sequence based on the state change time |
| File Name | <Report ID>-<Report Name>.csv |
| Chinese Version (optional) | No |

#### Report Type Setup

NO

#### Field Description

Refer to report format

## Drop Copy Client Password Expiration Report

#FS10017B\_S0060\_20100

This report prints the number of calendar days that password will expire of all Drop Copy Active Client.

By default, this report is printed in ascending sequence based on the client ID.

### Source of Data

Database

### Operation Flow

Daily **before** the start of the day rollover

### Housekeeping

2 weeks retention period

### Holiday Arrangements

No

### Special handling

Admin GUI is able to trigger this report generation manually

### Report formats

| Field | Type | Size | Remarks |
| --- | --- | --- | --- |
| Comp ID | Alphanumeric | 10 |  |
| Exchange Participant ID | Alphanumeric | 5 |  |
| Last Successful Logon Date | Date Time | 8 |  |
| Password Expiry Date | Date | 8 |  |
| No. of Days to Expire | Numeric | 4 | Counting of number of days starts from current day. Zero is printed if password has expired |
| Locked? | Boolean | 1 |  |

### Report Layout

01,,<Report ID>

02,,<Company Name>

02,,<Report Header Name>

02,,DATE: DD/MM/YYYY TIME: HH:MM

03,01,<Section Header> #e.g. Record type name

04,01,<Field Name 1>,< Field Name 2>,< Field Name 3>,…

05,01,<Value 1>,<Value 2>,<Value 3>,…

06,01,Total records,ZZZZZZ9

07,,Total records,ZZZZZZ9

99,,

#### Report Attribute

|  |  |
| --- | --- |
| Purpose | Capture GUI user login status daily |
| Frequency | Daily |
| Sequence | Ascending sequence based on the state change time |
| File Name | <Report ID>-<Report Name>.csv |
| Chinese Version (optional) | No |

#### Report Type Setup

NO

#### Field Description

Refer to report format

# Last Trading Day Checklist

## Last Trading Day Checklist Report

#FS10017B\_S0070\_10100

### Source of Data

Database.
With projection of Last Trading Date of Futures/Options/Combo for current and next year based on the latest Regional Calendar.

### Operation Flow

Adhoc generation.

### Housekeeping

2 weeks retention period

### Holiday Arrangements

No

### Special handling

Admin GUI is able to trigger this report generation manually

### Report formats

**Section: Futures to be added**

| Field | Type | Size | Remarks |
| --- | --- | --- | --- |
| Instrument | Alphanumeric | 32 |  |
| Last Trading Date | Date | 8 |  |

**Section: Options to be added**

| Field | Type | Size | Remarks |
| --- | --- | --- | --- |
| Instrument Class | Alphanumeric | 14 |  |
| Last Trading Date | Date | 8 |  |

**Section: Combo to be added**

| Field | Type | Size | Remarks |
| --- | --- | --- | --- |
| Combo | Alphanumeric | 32 |  |
| Combo Class | Alphanumeric | 14 |  |
| Last Trading Date | Date | 8 |  |

### Report Layout

01,,<Report ID>

02,,<Company Name>

02,,<Report Header Name>

02,,DATE: DD/MM/YYYY TIME: HH:MM

03,01,<Section Header> #e.g. Record type name

04,01,<Field Name 1>,< Field Name 2>,< Field Name 3>,…

05,01,<Value 1>,<Value 2>,<Value 3>,…

06,01,Total records,ZZZZZZ9

07,,Total records,ZZZZZZ9

99,,

#### Report Attribute

|  |  |
| --- | --- |
| Purpose | Project the Last Trading Date of Futures/Options/Combo for current and next year based on the latest Regional Calendar |
| Frequency | Adhoc |
| Sequence | Ascending sequence based on the Instrument/Instrument Class/Combo |
| File Name | <Report ID>-<Report Name>.csv |
| Chinese Version (optional) | No |

#### Report Type Setup

NO

#### Field Description

Refer to report format

# Instrument Maintenance

#FS10017A\_S0110\_10100

## Instrument Maintenance report for HKFE Options Products

#FS10017B\_S0080\_10100

The report generation function would generate a report for any new HKFE Options products Instrument maintained by the Automatic Instrument Generation function with tomorrow or next business as the First Trading Date.

### Source of Data

Instruments with Approved state in the Reference Data Base

### Operation Flow

At a scheduled time, the report generator process searches for the report name under the report type "Report for Instrument Maintenance for Index Option." It declares the possible nearest First Trading Day according to the holiday table and focuses on Instruments under the defined Instrument Class that are Status in Active, and State in either Active or Approved.

For example, if today is November 8, 2024, and November 11, 2024, is a holiday trading day,

The report will have targeted Effective Days of November 11, 2024, and November 12, 2024.

For each targeted Effective Day, the process locates the targeted Instrument’s First Trading Day as the same as targeted Effective Day. It then lists each Instrument Class with distinct Expiry dates from the nearest to the farthest maturities and their strike price ranges in intervals, which are printed in the report. If the strike interval varies within the same Expiry, it will be printed in the next row with the corresponding strike price range and interval.

If none of the Instruments in the Instrument Class need to be included in the report, the section for that Instrument Class will be omitted.

### Housekeeping

The report keeps for 7 calendar days.

### Holiday Arrangements

The report generates on each trading day, if the report generator cannot locate any Instrument for targeted Effective Day(s), the report generation would be skipped for the Report Name.

### Special handling

For new product launch and the Instruments need to be included in the report, the setup in the Report Instrument Group List must be Active before the First Trading Day of the Product launch. The Instrument will first appear in the report when its First Trading Day aligns with the next targeted Effective Day.

### Report formats

The report will be in CSV format containing the corresponding strike price range and interval for further transformation into Circular format.

### Report Layout

|  |
| --- |
| 01,,SG\_HKFEO,,,,  02,,New Index Options Strike Instrument,30-Oct-24,31-Oct-24,,  03,,Section Header,Expiry,Strike Price (L),Strike Price (U),Interval  03,01,HSI Options,25-Feb,16300,19900,100  03,01,HSI Options,25-Feb,20000,24600,200  03,02,MHI Options,25-Jun,12000,13000,200  03,02,MHI Options,25-Jun,13200,19900,100  03,02,MHI Options,25-Jun,20000,29200,200  03,02,MHI Options,25-Jun,29600,30000,400  03,03,HHI Options,25-Feb,5800,8800,100  03,04,MCH Options,25-Jun,3900,4600,100  03,04,MCH Options,25-Jun,4700,4950,50  03,04,MCH Options,25-Jun,5000,11000,100  03,05,HTI Options,25-Feb,3600,4950,50  03,05,HTI Options,25-Feb,5000,5500,100  03,06,MTW Options MSCI,25-Dec,850,995,5  03,06,MTW Options MSCI,25-Dec,1000,1050,10  03,07,Weekly HHI Options,8-Nov-24,5800,5800,0  03,08,Weekly HTI Options,8-Nov-24,3550,3550,0 |

#### Report Attribute

|  |  |
| --- | --- |
| Purpose | To show the new Instrument to be effective in the next business date |
| Frequency | Daily |
| Sequence | For product Section, ascending sequence based on the Instrument Class list  For maturity, ascending order (i.e. starting from the nearest maturity to farther maturities) |
| File Name | <Report Name>\_<Business Date in YYYYMMDD>.csv |

#### Report Type Setup

For multiple classes printed in the report, the corresponding Instrument Classes can share the same Report Name. The contracts will be grouped per instrument class according to setup order.

The report type setup fields are as below:

|  |  |
| --- | --- |
| **Report Type** | **Report for Instrument Maintenance for HKFE Options** |
| **Report Name** | Specify the ID for the report. |
| **Header** | Specify the Subject of the report |
| **Instrument Class** | Specify the instrument class of the Call or Put Options (either Call or Put options is required, assuming the same strike price would be generated for both Call and Put Options) |
| **Underlying** | Not applicable for this report type |
| **Contract Description** | Specify the Description of the product section |
| **Contract Term** | Not applicable for this report type |

Example:

|  |  |  |
| --- | --- | --- |
| **Report for New Index Options Strike Instrument** | | |
| **Report Name** | SG\_HKFEO | |
| **Header** | New Index Options Strike Instrument | |
| **Instrument Class list** | | |
| **Instrument Class** | **Contract Description** |  |
| HSICALL | HSI Options |  |
| MHICALL | MHI Options |  |
| HTICALL | HTI Options |  |
| MTWCALL | MTW Options |  |
| HSIWCALL | Weekly HSI Options |  |

#### Field Description

Category 1

| Field Name | Description | Position in csv | Format | Remarks |
| --- | --- | --- | --- | --- |
| Category | 01 | 1 | 9 |  |
| Section number | N/A | 2 |  |  |
| Report Name | **Name** setup for Report type – **Report for Instrument Maintenance for Index Option** | 3 | X(12) |  |

Category 2

| Field Name | Description | Position in csv | Format | Remarks |
| --- | --- | --- | --- | --- |
| Category | 02 | 1 | 9 |  |
| Section number | N/A | 2 |  |  |
| Subject | **Header** defined for the Report | 3 | X(32) |  |
| Date | Report Generation Business date | 4 | DD-MMM-YYYY |  |
| Effective Date | Effective date of the Instrument printed in the report | 5 | DD-MMM-YYYY | Contract’s Effective Date/ First Trading Date (which would be the next business day) |

Category 3

| Field Name | Description | Position in csv | Format | Remarks |
| --- | --- | --- | --- | --- |
| Category |  | 1 | 9 |  |
| Section number | Order number of Section Header | 2 | Z9 or 9 |  |
| Section Header | **Contract Description** of the corresponding **Instrument Class** | 3 | X(32) |  |
| Expiry | Expiration Month / Date of the Options Instrument | 4 | MMM-YYYY for Monthly Contract  DD-MMM-YYYY for Weekly Contract | The monthly contract is determined by whether the last trading date is the second last trading day of the month. Otherwise, it would be classified as weekly contract |
| Strike Price (L) | Strike Price Lower Range | 5 | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or  ZZZ9.99 |  |
| Strike Price (U) | Strike Price Upper Range | 6 | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or ZZZ9.99 |  |
| Interval | Strick Interval | 7 | ZZZ9 or  ZZ9 or  Z9 or  9 |  |

## Instrument Maintenance Report for SEHK Options Products

#FS10017B\_S0080\_20100

The report generation function would generate a report for any new Monthly Stock Options Instruments and Weekly Stock Options Instruments maintained by the Automatic Instrument Generation function with tomorrow or next business as the First Trading Date.

### Source of Data

Instruments with Approved state in the Reference Data Base

### Operation Flow

At a scheduled time, the report generator process searches for the report name under the report type "Report for Instrument Maintenance for Stock Option." It declares the possible nearest First Trading Day according to the holiday table and focuses on Instruments under the defined Instrument Class that are in either Active or Approved state where the status as Active , assume Instrument (as a ‘temporary counter’) under the Capital Adjustment – Spin Off scenario should be in suspended status which will be excluded from the report.

For example, if today is November 8, 2024, and November 11, 2024, is a holiday trading day,

The report will have targeted Effective Days of November 11, 2024, and November 12, 2024.

For each targeted Effective Day, the process locates the targeted Instrument’s First Trading Day as the same as targeted Effective Day. It then lists each Instrument Class in alphabetical order with distinct Expiry dates from the nearest to the farthest maturities and their strike prices from smallest to largest separated by the symbol “/”, which are printed in the report. If the strike interval varies within the same Expiry, it will be printed in the next row with the corresponding strike prices.

If none of the Instruments in the Instrument Class need to be included in the report, the section for that Instrument Class will be omitted.

### Housekeeping

The report keeps for 7 calendar days.

### Holiday Arrangements

The report generates on each trading day, if the report generator cannot locate any Instrument for targeted Effective Day(s), the report generation would be skipped for the Report Name.

### Special handling

For new product launch and the Instruments need to be included in the report, the setup in the Report Instrument Group List must be Active before the First Trading Day of the Product launch. The Instrument will first appear in the report when its First Trading Day aligns with the next targeted Effective Day.

### Report formats

The report will be in pre-defined text format.

### Report Layout

|  |
| --- |
| E  New Instrument <Date>  OPTN NEWS – NEW YYYYYYY STOCK OPTIONS CONTRACTS  EXN – NEW YYYYYYY STOCK OPTIONS CONTRACTS  The following new YYYYYYY stock options contracts (both calls and puts) will be available for trading on <effective Date>  CLASS EXPIRY MONTH EXERCISE PRICE  XXXXX MMM YY $Z,ZZ9.99/$Z,ZZ9.99/$Z,ZZ9.99/$Z,ZZ9.99  XXXXX MMM YY $Z,ZZ9/$Z,ZZ9/$Z,ZZ9 |

#### Report Attribute

|  |  |
| --- | --- |
| Purpose | To show the new Instrument to be effective in the next business date |
| Frequency | Daily |
| Sequence | For CLASS, Instrument Class’s underlying in alphabetical order  For EXPIRY MONTH, ascending order (i.e. starting from the nearest maturity to farther maturities)  For EXERCISE PRICE, ascending order (i.e. starting from smallest strike price to largest) |
| File Name | <Report Name>\_<Business Date in YYYYMMDD>.csv |

#### Report Type Setup

For multiple classes printed in the report, the corresponding Instrument Classes can share the same Report Name. The contracts will be grouped per instrument class according to setup order.

The report type setup fields are as below:

|  |  |
| --- | --- |
| **Report Type** | **Report for Instrument Maintenance for SEHK Options** |
| **Report Name** | Specify the ID for the report. |
| **Header** | Specify the Subject of the report |
| **Expiration Frequency** | Specify Monthly or Weekly for printing the Date format in EXPIRY MONTH |
| **Instrument Class** | Specify the instrument class of the Call or Put Options (either Call or Put options is required, assuming the same strike price would be generated for both Call and Put Options) |
| **Underlying** | Not applicable for this report type |
| **Contract Description** | Not applicable for this report type |

Example:

|  |  |  |
| --- | --- | --- |
| **Report for Instrument Maintenance for SEHK Options** | | |
| **Report Name** | SG\_SEHKO\_M | |
| **Header** | New Index Options Strike Instrument | |
| **Expiration Frequency** | Monthly | |
| **Instrument Class list** | | |
| **Instrument Class** | **Underlying** | **Contract Description** |
| A50CALL | A50 | A50 - ISHARES FTSE A50 CHINA INDEX ETF FUTURES |
| ACCCALL | AAC | AAC - AAC TECHNOLOGIES HOLDINGS INC. FUTURES |
| ABCCALL | ABC | ABC - AGRICULTURAL BANK OF CHINA LTD. FUTURES |

#### Field Description

| Field Name | Description | Position in the report | Format | Remarks |
| --- | --- | --- | --- | --- |
| Date | Report Generation Business date | 1 | DD MMM YYYY |  |
| Contract Frequency | Monthly or Weekly | 1 | XXXXXXX |  |
| Effective Date | Effective date of the Instrument printed in the report | 1 | DD MMM YYYY | Contract’s Effective Date/ First Trading Date (which would be the next business day) |
| CLASS | Underlying of the Instrument Class | 1 | X(3) |  |
| EXPIRY MONTH | Expiration Date / month of the list of EXERCISE PRICE | 2 | MMM YY for **Contract Frequency** = Monthly  DD MMM YY for **Contract Frequency** = Weekly |  |
| EXERCISE PRICE | The list of exercise price with ‘/’ as delimiter | 3 | $Z,ZZZ,ZZ9 or  $ZZZ,ZZ9 or  $ZZ,ZZ9.99 or  $Z,ZZ9.99 or  $ZZZ9.99/<next strike price> |  |
