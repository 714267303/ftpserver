TITLE:

**FUNCTIONAL SPECIFICATION**

**ODP-T**

FS10002 - Order Management

AUTHOR : IT/Markets Systems DATE : 24 Mar 2025

LAST REVIEW : Derivatives Trading Business Operations DATE : 10 Apr 2026

**CONTENTS**

[1. Document Control 4](#__RefHeading___Toc193718483)

[1.1. Change History 4](#__RefHeading___Toc193718484)

[1.2. Document Cross-referenced 4](#__RefHeading___Toc193718485)

[1.3. Abbreviation 5](#__RefHeading___Toc193718486)

[2. Introduction 6](#__RefHeading___Toc193718487)

[3. Order Type 7](#__RefHeading___Toc193718488)

[3.1. Limit Order 7](#__RefHeading___Toc193718489)

[3.2. Market Order 7](#__RefHeading___Toc193718490)

[3.3. Market to Limit 7](#__RefHeading___Toc193718491)

[4. Order Attributes 8](#__RefHeading___Toc193718492)

[4.1. Standard Attributes 8](#__RefHeading___Toc193718493)

[4.1.1. Instrument ID 8](#__RefHeading___Toc193718494)

[4.1.2. Side 9](#__RefHeading___Toc193718495)

[4.1.3. Price 9](#__RefHeading___Toc193718496)

[4.1.4. Quantity 9](#__RefHeading___Toc193718497)

[4.1.5. Lot Type 11](#__RefHeading___Toc193718498)

[4.1.6. Time Validity 11](#__RefHeading___Toc193718499)

[4.1.7. Client Order ID 14](#__RefHeading___Toc193718500)

[4.1.8. Self-Match Prevention ID (SMP ID) 14](#__RefHeading___Toc193718501)

[4.1.9. Broker-to-Client Assigned Number (BCAN) 14](#__RefHeading___Toc193718502)

[4.1.10. Cancel Hint Bitmap 14](#__RefHeading___Toc193718503)

[4.1.11. Position Effect 15](#__RefHeading___Toc193718504)

[4.1.12. Clearing Account 15](#__RefHeading___Toc193718505)

[4.1.13. Customer Information 15](#__RefHeading___Toc193718506)

[4.2. Pass-through Attributes 15](#__RefHeading___Toc193718507)

[4.2.1. Give-up Participant 16](#__RefHeading___Toc193718508)

[4.2.2. Give-up Information 16](#__RefHeading___Toc193718509)

[4.2.3. ATID 16](#__RefHeading___Toc193718510)

[4.3. Special Order Attributes 16](#__RefHeading___Toc193718511)

[4.3.1. Tradable in AHT indicator 16](#__RefHeading___Toc193718512)

[4.3.2. Cancel on Disconnect (COD) indicator 17](#__RefHeading___Toc193718513)

[4.4. Attributes from ODP 17](#__RefHeading___Toc193718514)

[4.4.1. Order ID 17](#__RefHeading___Toc193718515)

[5. Quote Type 17](#__RefHeading___Toc193718516)

[5.1. Single Quote 19](#__RefHeading___Toc193718517)

[5.2. Mass Quote 19](#__RefHeading___Toc193718518)

[6. Quote Request 19](#__RefHeading___Toc193718519)

[6.1. Regular Quote Request 20](#__RefHeading___Toc193718520)

[6.2. Exchange Quote Request 20](#__RefHeading___Toc193718521)

[7. Quote and Quote Request Attributes 20](#__RefHeading___Toc193718522)

[7.1. Single Quote 20](#__RefHeading___Toc193718523)

[7.2. Mass Quote 21](#__RefHeading___Toc193718524)

[7.3. Quote Request 22](#__RefHeading___Toc193718525)

[8. Quote Specific Validation 22](#__RefHeading___Toc193718526)

[8.1. Validation Matrix 22](#__RefHeading___Toc193718527)

[9. Order and Quote Actions 23](#__RefHeading___Toc193718528)

[9.1. Order Actions 23](#__RefHeading___Toc193718529)

[9.1.1. Order Entry 23](#__RefHeading___Toc193718530)

[9.1.2. Order Amendment 24](#__RefHeading___Toc193718531)

[9.1.3. Order Cancellation 25](#__RefHeading___Toc193718532)

[9.2. Quote Actions 25](#__RefHeading___Toc193718533)

[9.2.1. Phase 1 – Cancelling existing quotes 25](#__RefHeading___Toc193718534)

[9.2.2. Phase 2 – Adding new quotes 26](#__RefHeading___Toc193718535)

[9.2.3. Summary 26](#__RefHeading___Toc193718536)

[9.2.4. Lose Time Priority 26](#__RefHeading___Toc193718537)

[9.2.5. Quote Related Response 26](#__RefHeading___Toc193718538)

[9.3. Mass Cancellation 27](#__RefHeading___Toc193718539)

[9.4. On Behalf of Cancellation 28](#__RefHeading___Toc193718540)

[9.4.1. OBO Single Cancellation 28](#__RefHeading___Toc193718541)

[9.4.2. OBO Mass Cancellation 28](#__RefHeading___Toc193718542)

[10. Order Expiry and Reload 28](#__RefHeading___Toc193718543)

[10.1. Order Expiry 28](#__RefHeading___Toc193718544)

[10.2. Order Reload 30](#__RefHeading___Toc193718545)

[10.2.1. Order Reload Validation 30](#__RefHeading___Toc193718546)

[11. Unsolicited Order Cancellation 30](#__RefHeading___Toc193718547)

[11.1. Unmatched Trade Report 31](#__RefHeading___Toc193718548)

[12. Cancel on Disconnect (COD) 31](#__RefHeading___Toc193718549)

# Document Control

## Change History

|  |  |  |  |
| --- | --- | --- | --- |
| Version  Number | Issue Date | Author | Abstract |
| V0.1 | 20231221 | IT/Markets Systems | Initial version. |
| V0.2 | 20240315 | IT/Markets Systems | Revised based on review comments from business users |
| V1.0 | 20240927 | IT/Markets Systems | Revised based on review comments from business users |
| V2.0 | 20241031 | IT/Markets Systems | Revised based on review comments from business users |
| V3.0 | 20241126 | IT/Markets Systems | Revised based on review comments from business users |
| V3.1 | 20241206 | IT/Markets Systems | Revised based on review comments from business users |
| V3.2 | 20241227 | IT/Markets Systems | Revised based on review comments from business users |
| V3.3 | 20250324 | IT/Markets Systems | Revised based on review comments from business users |
| V3.4 | 20251115 | IT/Markets Systems | Refine/clarify the document. |

## Document Cross-referenced

|  |  |  |
| --- | --- | --- |
| # | Document | Version |
| 1 | BRD\_DT\_0002: 0002 BRS Order Management | v2.4 2025 01 09 |
| 2 | BRD\_DT\_0003: 0003 BRS Order Book Execution Management | V1.6\_2025 01 21 |
| 3 | BRD\_DT\_0004: 0004 BRS Market Integrity Safeguards | v1.8 - 2025 1 15 |
| 4 | BRD\_DT\_0038: 0038 New Wish 018 Cancel on disconnect | V2 2024 06 28 |
| 5 | BRD\_DT\_0049: 0049 BRS ODP Online | V2.8 - 2025-01-09 |
| 6 | FS10001 - Trading Timetable | 241227 |
| 7 | FS10003 - Orderbook and Execution Management | 20250324 |
| 8 | FS10004 - Price Supervision | 250122 |
| 9 | FS10007 - Self Match Prevention | 20250324 |

## Abbreviation

|  |  |
| --- | --- |
| AHT | After Hours Trading |
| BCAN | Broker-to-Client Assigned Number |
| COD | Cancel on Disconnect |
| COP | Calculated Opening Price |
| FaK | Fill and Kill |
| FS | Function Specification |
| FoK | Fill or Kill |
| GTC | Good Till Cancel |
| GTD | Good Till Date |
| ID | Identifier |
| IoC | Immediate or Cancel |
| ME | Matching Engine |
| OBO | On behalf of |
| OFG | Order Flow Gateway |
| SMP | Self-Match Prevention |
| TMC | Tailor Made Combo |

*List names of teams, units or divisions who will receive this document.*

# Introduction

To define the functional specification as how to manage orders in ODP trading system including order or quote actions, their attributes and expiry conditions.

# Order Type

#FS10002\_S0030\_00100

ODP supports several order types, which define how an order should interact with the order book based on the characteristics of each order type. Every order must have only one order type defined. The following order types are supported:

## Limit Order

#FS10002\_S0030\_00200

A limit order is an order that has a price assigned by the market participant. #FS10002\_S0030\_00300 It will be matched automatically if the prevailing market price is at the price or better.

#FS10002\_S0030\_00400

At pre-market opening auction matching, the prevailing market price is the Calculated Opening Price (COP).

## Market Order

#FS10002\_S0030\_00500

A market order is an order without price assigned by the market participant.

Market order is technically ready in day 1 but will not be rolled in day 1.

#FS10002\_S0030\_00600

In OPEN trading state, it will be traded at the best price available and allowed to trade through price levels. #FS10002\_S0030\_00700 When volume in the opposite side is exhausted, residual order volume will be cancelled. #FS10002\_S0030\_00800 The market order will not rest in the order book.

#FS10002\_S0030\_00900

In pre-market session, market orders are added to order book where time priority is given and matched at COP in auction matching. #FS10002\_S0030\_01000 Any residual order volume after auction matching will be cancelled, and not brought forward to next trading state.

## Market to Limit

#FS10002\_S0030\_01100

A Market to Limit order is placed without a price specified.

#FS10002\_S0030\_01200

In OPEN trading state, Market to Limit order will match against best price level orders in the opposite side of order book. It will only trade at the best price level, thus does not trade through the order book.

#FS10002\_S0030\_01300

When trade can be executed, any residual volume of the Market to Limit order is then converted into a limit order priced at the best on the opposite side of the order book before trade execution, i.e. the trade price.

#FS10002\_S0030\_01400

When no trade can be executed, the Market to Limit order is immediately cancelled.

#FS10002\_S0030\_01500

In PRE-MARKET session, Market to Limit orders are added to order book where time priority is given. #FS10002\_S0030\_01600 They will be matched in auction matching at COP.

#FS10002\_S0030\_01700

Any residual volume after auction matching will be converted to a limit order with price assigned by rules below and participate in next trading state.

1. #FS10002\_S0030\_01800 The COP for auction matching.
2. #FS10002\_S0030\_01900 When COP is not available hence no trade was made in auction matching, the best price on same side is used for price assignment.
3. #FS10002\_S0030\_02000 If best price is not available on same side, the order is immediately cancelled.

After the price is assigned, the converted limit order will be inserted into the order book according to order priority described in FS10003 with the assigned price as price priority and the given time priority when the order is received.

# Order Attributes

#FS10002\_S0040\_00100

Orders submitted into ODP require a number of attributes to facilitate execution & post-trade requirements and to comply with regulatory reporting requirements. Those with inappropriate conditional attributes will be rejected on entry (for example a Market order with price attached will be rejected by ODP).

## Standard Attributes

### Instrument ID

#FS10002\_S0040\_00200

Tradable Instrument Identifier. The instrument must fulfill all the following criteria to be accepted.

1. #FS10002\_S0040\_00300 The specified Instrument ID exists in the system.
2. #FS10002\_S0040\_00400 The specified Instrument’s state is available for trading, i.e., the Instrument is not in suspended, halt or delisted state.
3. The specified Instrument is valid for trading, i.e. at time of order entry, the Instrument has passed ***First Trading Date/First Trading Time*** (whichever later) and has not surpassed ***Effective Last Trading Date/Last Trading Time*** (whichever earlier).

### Side

#FS10002\_S0040\_00500

Indicates the side of the order-book the order is being submitted.

#FS10002\_S0040\_00600

Side must be either Buy (Bid) or Sell (Ask or Offer).

### Price

#FS10002\_S0040\_00700

Specified price for an order which will execute at or better than it.

#FS10002\_S0040\_00800

The price format is defined per product, with total 18 digits and configurable decimal place, negative supported. The default is 12 decimal numbers plus 6 decimal places.

#FS10002\_S0040\_00900

The price must not be present when order type is Market or Market-to-Limit. For others, it must fall within the allowable price range discussed in FS10004.

### Quantity

#FS10002\_S0040\_01000

Total volume of the order. Orders will be executed at most at the total volume.

#FS10002\_S0040\_01100

Quantity must be larger than 0 and not exceed the system limit, which is the maximum value of Little Endian encoded 32-bits signed integer, i.e. 2,147,483,647[[1]](#footnote-2).

#FS10002\_S0040\_01200

These are limit settings for each Instrument Type including Combination in both Exchange Participant level and User/Session level. The allowable range is same as the system limit. Market Operation GUI allows grouping of multiple Instrument Types together where a ***Maximum Order Size Limit*** value can be applied to multiple Exchange Participants for operational convenience.

The effective setting is determined by rules below:

1. #FS10002\_S0040\_01300 From User level Setting.

#FS10002\_S0040\_01400 For Combination Instrument Type including TMC, when the explicit Instrument Type setting is not available, the most restrictive setting (i.e. the smallest value from all legs) in User level is chosen.

1. #FS10002\_S0040\_01500 From Exchange Participant level setting when it is not available in User level setting. The same Combination Instrument Type rule in User level applies with Exchange Participant level setting.
2. #FS10002\_S0040\_01600 From a single IT configurated System limit when it is not available in Exchange Participant level.

#FS10002\_S0040\_01700
The following records down the current value configured per Instrument Type for Maximum Order Size Limit.

|  |  |
| --- | --- |
| **Example of configuration per product** |  |
| **Products** | **Maximum Order Size Limit (Contracts)** |
| Hang Seng Index Futures & Options | 1,000 |
| Mini-Hang Seng Index Futures & Options | 1,000 |
| HSI Total Return Index Futures | 1,000 |
| Hang Seng China Enterprises Index Futures & Options | 1,000 |
| Mini-Hang Seng China Enterprises Index Futures & Options | 1,000 |
| HSCEI Total Return Index Futures | 1,000 |
| Hang Seng TECH Index Futures & Options | 1,000 |
| Sector Index Futures | 1,000 |
| MSCI Index Futures & Options | 1,000 |
| HIBOR Futures | 1,000 |
| Dividend Futures | 1,000 |
| HSI Volatility Index Futures | 1,000 |
| BRICS Futures | 1,000 |
| Currency Futures & Options | 1,000 |
| CES China 120 Index Futures | 1,000 |
| USD & CNH London Aluminium Mini Futures | 1,000 |
| USD & CNH London Zinc Mini Futures | 1,000 |
| USD & CNH London Copper Mini Futures | 1,000 |
| USD & CNH London Nickel Mini Futures | 1,000 |
| USD & CNH London Tin Mini Futures | 1,000 |
| USD & CNH London Lead Mini Futures | 1,000 |
| USD Gold Futures | 1,000 |
| CNH Gold Futures | 1,000 |
| USD Silver Futures | 1,000 |
| CNH Silver Futures | 1,000 |
| Iron Ore Futures | 1,000 |
| Stock Futures & Options | 5,000 |
| Flexible Hang Seng Index Options | 5,000 |
| Flexible Hang Seng China Enterprises Index Options | 5,000 |

#### TMC Specific

#FS10002\_S0040\_01750

(The entire *Section 4.1.4.1.* will be consolidated into *FS10003*. Please refer to *FS10003 Order Book and Execution Management, 7.1.1. Creation Restrictions*.)

### Lot Type

#FS10002\_S0040\_01800

Lot type specifies order quantity relative to the instrument lot size. #FS10002\_S0040\_01900 ODP Trading System only supports Round Lot type orders.

#### Round Lot

#FS10002\_S0040\_02000

Round Lot refers to a standardized number of contracts as a trading unit.

#FS10002\_S0040\_02100

ODP supports round lot type which order quantity must be multiples to an instrument’s lot size.

### Time Validity

#FS10002\_S0040\_02200

Time validity, known as Time-in-Force, is a condition that can be applied to an order type that dictates the time span for which the order remains in the order book and how the order is handled across trading states and other conditions.

#FS10002\_S0040\_02300

The value must be either one of the following:

1. Day
2. Immediate or Cancel (IoC) / Fill and Kill
3. Fill or Kill (FoK)
4. Good till Cancelled (GTC)
5. Good till Date (GTD)
6. At Crossing

#### Day

#FS10002\_S0040\_02400

Orders with Day validity will remain in the trading system until:

1. DAYEND trading state is reached for the Instrument; or,
2. At a trading state with “Inactivate Non-AHT Orders” background function being selected for non-AHT orders handling, and that the Instrument do not participate in AHT Session; or,
3. Being cancelled by EP themselves, by Exchange Business Operations, or cancelled by the trading system as part of the defined behaviours[[2]](#footnote-3); or,
4. The Instrument expires.

#### Fill and Kill (FaK)

#FS10002\_S0040\_02500

An order that will be fully or partially executed on receipt and remaining volume is immediately cancelled. It will not rest in the order book.

Fill and Kill is also referred as Immediate or Cancel (IoC).

#### Fill or Kill (FoK)

#FS10002\_S0040\_02600

An order that will be fully executed on receipt or immediately rejected. It will not rest in the order book.

#### Good till Cancelled (GTC)

#FS10002\_S0040\_02700

An order that remains in the market until:

1. It is fully executed,
2. It is cancelled, or
3. The instrument expires.

#FS10002\_S0040\_02800

GTC orders that remain in the market after end of trading day are “reloaded” to the order book the next trading day as described in Order Reload section.

#FS10002\_S0040\_02810

Note that both Instrument and Combo support GTC time validity.

#### Good till Date (GTD)

#FS10002\_S0040\_03000

An order that remains in the market until:

1. It is fully executed,
2. It is cancelled, or
3. DAYEND trading state on the specified date of expiration, or
4. At trading state with INACT\_T\_ORDER on the specified date of expiration for non-AHT order, or
5. The instrument expires.

#FS10002\_S0040\_03100

GTD orders expiration not yet reached will be “reloaded” in the next trading day as described in Order Reload section.

#FS10002\_S0040\_03200

GTD order must include an additional attribute Expire Date to indicate the date of expiration.

#FS10002\_S0040\_03210

Note that both Instrument and Combo support GTD time validity.

##### Expire Date

#FS10002\_S0040\_03400

The expire date must be ≥ current trading day, otherwise the order will be rejected.

#### At Crossing

#FS10002\_S0040\_03410

At Crossing validity can only be input during the PREOPEN and PREOPENALLOC trading states.

All orders with At Crossing validity will be cancelled just after the uncrossing processing. This cancellation is still during the UNCROSS trading state.

#### Time Validity and Order Type Combinations

#FS10002\_S0040\_03500

Order validity conditions may not be applicable for all order types. The following tables illustrates the applicable order type and order validity combinations in PRE-MARKET and OPEN session:

#FS10002\_S0040\_03600

|  |  |  |  |
| --- | --- | --- | --- |
| **PRE-MARKET trading state** | | | |
| Order Type  Order  Validity  Condition | **Limit** | **Market** | **Market to Limit** |
| Day | **** | × | **** |
| Immediate or Cancel (IoC) | × | × | × |
| Fill or Kill (FoK) | × | × | × |
| Good till Cancelled (GTC) | **** | × | **** |
| Good till Date (GTD) | **** | × | **** |
| At Crossing | **** | **** | **** |

#FS10002\_S0040\_03700

|  |  |  |  |
| --- | --- | --- | --- |
| **OPEN trading state** | | | |
| Order Type  Order  Validity  Condition | **Limit** | **Market** | **Market to Limit** |
| Day | **** | × | **** |
| Immediate or Cancel (IoC) | **** | **1** | **** |
| Fill or Kill (FoK) | **** | **1** | **** |
| Good till Cancelled (GTC) | **** | × | **** |
| Good till Date (GTD) | **** | × | **** |
| At Crossing | × | × | × |

1 #FS10002\_S0040\_03800 Market orders are either FaK or FoK in OPEN trading state.

### Client Order ID

#FS10002\_S0040\_03900

Unique identifier for the order assigned by the market participant.

### Self-Match Prevention ID (SMP ID)

#FS10002\_S0040\_04000

The SMP ID is to prevent from being matched to an opposite order if both buy and sell orders for the trade contain the same SMP ID. The SMP mechanism is covered in FS10009.

### Broker-to-Client Assigned Number (BCAN)

#FS10002\_S0040\_04051

Identifier for the client of the Exchange Participant who may possess the right to submit an order in Hong Kong’s Security or Derivatives Market Trading System. The value is encrypted upon receipt and passed to downstream systems such as market surveillance for regulatory reporting and supervision. Due to the BCAN field nature (confidential data), the values filled in the BCAN field will not be echoed back to the client.

The BCAN field consists of two attributes: a CE Number and a BCAN value. The CE number (Central Entity Identification Number) is a 6 alphanumeric value assigned by the SFC, while the BCAN value is a randomly assigned number (from the Exchange Participant to their clients) not exceeding 10 digits (i.e. numeric value). The separator is a full stop (i.e. “.”). The BCAN value is unique per Exchange Participant, and BCAN values 0 to 99 are reserved.

The BCAN field is validated to ensure at entry, it fulfills the length and BCAN convention as agreed with Exchange Participants. It should be noted that leading zeros are not permitted for the BCAN value within the BCAN field.

Example below –

* CE number: ABC123
* BCAN value assigned to the client: 0000005678

Then “ABC123.5678” should be filled in the BCAN field upon order entry to the system.

The submission and storage of BCAN and CID (Client Identification Data) mapping files to the Exchange is outside of the scope for this document.

### Cancel Hint Value

#FS10002\_S0040\_04070

A 16-bits hint field for Mass Cancellation and On-Behalf of Cancellation feature. There are two modes of cancellation:

* Range matching

When the Cancel Hint Value is between the “from” and “to” value to be cancelled specified in the mass cancellation / on-behalf of cancellation, the order is cancelled.

* Bits matching (or Bitwise AND matching)

When any enabled bit matches the specified bit in mass cancellation / on-behalf of cancellation, the order is cancelled.

This is an optional attribute.

### Position Effect

#FS10002\_S0040\_04200

Position Effect is a pass-through attribute. It allows market participants to specify either opening or closing of position for clearing procedure.

#FS10002\_S0040\_04300

When it is not available in the order, a default value of OPEN is populated to associated trades.

### Clearing Account

#FS10002\_S0040\_04400

The clearing account of the market participant.

The attribute serves 2 purposes:

1. An identifier for Mass order cancellation.
2. Pass-through to downstream systems for clearing procedure.

#FS10002\_S0040\_04500

This is an optional attribute.

### Customer Information

#FS10002\_S0040\_04900

A free text attribute echo back to client in order acknowledgment and associated trades.

#FS10002\_S0040\_05000

This is an optional attribute.

## Pass-through Attributes

Pass-through attributes are optional, and they are not processed by trading system. The purpose of those attributes can be:

1. For downstream or surrounding systems such as for clearing. Or,
2. For echo back to the order originator in response message.

### Give-up Participant

#FS10002\_S0040\_05500

The give-up participant is a pass-through attribute to downstream systems for Give-up / Take-up process in clearing procedures.

#FS10002\_S0040\_05600

This is an optional attribute.

### Give-up Information

#FS10002\_S0040\_05100

Give-up Information is a pass-through free text attribute for clearing procedure.

#FS10002\_S0040\_05200

This is an optional attribute.

### ATID

#FS10002\_S0040\_05250

The ATID is a pass-through attribute to downstream systems.

#FS10002\_S0040\_05260

This is an optional attribute.

## Special Order Attributes

### Tradable in AHT indicator

#FS10002\_S0040\_05700

The indicator specifies whether an order should participate trading in AHT session.

#FS10002\_S0040\_05950

For non-AHT day orders, it is cancelled at trading state with INACT\_T\_ORDER attribute.

For non-AHT GTD / GTC orders, it is suspended at trading state with INACT\_T\_ORDER attribute. Suspended orders are moved to non-public order books where only cancellation is allowed.

There are more details on AHT and non-AHT orders expiration in section 10.1 Order Expiry.

#FS10002\_S0040\_06000

Orders submitted in AHT session must have Tradable in AHT indicator enabled.

#FS10002\_S0040\_06100

This attribute is ignored for products that do not have AHT trading session.

### Cancel on Disconnect (COD) indicator

#FS10002\_S0040\_06150

The COD indicator specifies the order is applicable to COD function. More details in “Cancel on Disconnect (COD)” section.

## Attributes from ODP

### Order ID

#FS10002\_S0040\_06200

Order ID is an ID assigned by ODP to uniquely identify an order. #FS10002\_S0040\_06300 It will be sent to the order originator when an order is accepted by the system.

# Quote Type

#FS10002\_S0050\_00100

Quoting is provided by a special type of transaction that has a bid side and an offer side with corresponding prices and quantities. Price quotations are like limit orders, and with the following characteristics:

1. #FS10002\_S0050\_00200 The system can support multiple outstanding quote entries for the same instrument in the order book.
2. #FS10002\_S0050\_00300 A quote entry allowed being either single-sided or two-sided (a quote pair).
3. #FS10002\_S0050\_00400 Instrument ID and Quote Entry ID in both Mass Quote and Single Quote is the identifier for quote pairs.
   1. For example, Instrument ID = A with Quote Entry ID = 9 and Instrument ID = A with Quote Entry ID = 3 are two different quotes in the order book.
   2. In another example, Instrument ID = A with Quote Entry ID = 1 and Instrument ID = B with Quote Entry ID = 1 are different.
   3. To replace an existing quote, it needs to specify the Instrument ID and Quote Entry ID.
   4. Single quotes and mass quotes do not share the same set of ID. Therefore, single quote transaction cannot update quote entry from mass quote transaction.
4. #FS10002\_S0050\_00500 Single Quote allows one quote pair in a single transaction while Mass Quote allow multiple quote pairs.
5. #FS10002\_S0050\_00600 An existing quote pair will be replaced by a new quote pair with cancel-add operations in an atomic manner to enable market makers to provide continuous quotes. The replacement allows:
   1. #FS10002\_S0050\_00700 Replace both sides of an existing quote pair.
   2. #FS10002\_S0050\_00800 Replace one side of an existing quote pair and leave the other side of this quote pair unchanged.
   3. #FS10002\_S0050\_00900 Cancel one side of an existing quote pair and leave the other side of this quote pair unchanged.
   4. #FS10002\_S0050\_01000 Cancel one side of an existing quote pair and replace the other side of this quote pair.
   5. #FS10002\_S0050\_01100 Cancel both sides of an existing quote pair.
6. #FS10002\_S0050\_01200 It is possible to replace only one side of the quote, the quote side that has not changed will retain its current price time priority.
7. #FS10002\_S0050\_01300 Quotes are expired and cancelled when entering trading state with INACT\_T\_ORDERS attribute. They will not be carried forward to AHT session.
8. #FS10002\_S0050\_01400 Bid and offer prices in a quote pair are not allowed to be crossed or locked, in that case, the quote transaction is rejected.
9. #FS10002\_S0050\_01500 If the whole mass quote or the whole single quote is rejected, a single message will be responded; otherwise, individual response will be sent per quote side.
10. #FS10002\_S0050\_01600 Quotes are having Round Lot Type.
11. #FS10002\_S0050\_01700 Instruments in mass quote can only be within the same ME.
12. #FS10002\_S0050\_01710 Mass quote does not support combo while single quote does.
13. #FS10002\_S0050\_01720 Quotes are always with Cancel on Disconnect (COD) enabled.
14. #FS10002\_S0050\_01730 A maximum of 250 outstanding quote entries individually for single quote and mass quote (Total 500) is allowed per session per security.

## Single Quote

#FS10002\_S0050\_01800

This transaction is a request to input a new quote or amend an existing quote for a given instrument in the system.

#FS10002\_S0050\_01900

If it is a new two-sided quote then effectively the quote pair will result in two independent orders, one per side; and each order will go through order specific processing, #FS10002\_S0050\_02000 bid side first and then followed by offer side.

#FS10002\_S0050\_02100

Quote modification can be performed by specifying the same Instrument ID and Quote Entry in the Single Quote.

## Mass Quote

#FS10002\_S0050\_02200

Mass Quote transactions are used to enter multiple outstanding quotes in order books.

#FS10002\_S0050\_02300

In a single mass quote transaction, Instrument ID and Quote Entry ID combination across quote pairs cannot be duplicated.

#FS10002\_S0050\_02400

It is not supported to send mass quotes for combinations.

#FS10002\_S0050\_02450

Instruments in all quote entries must belong to the same underlying.

# Quote Request

#FS10002\_S0060\_00100

A Quote Request is a transaction to ask for a quote price in a specified instrument.

#FS10002\_S0060\_00200

The Quote Request can specify an order book including combination order books and various indications of interest.

#FS10002\_S0060\_00300

Upon received the quote request, ODP will forward the request to:

1. #FS10002\_S0060\_00400 All those order entry sessions with trading right.
2. #FS10002\_S0060\_00500 Market data feed.

#FS10002\_S0060\_00550

Background information: An exchange participant could response to the Quote Request by either Single Quote, Mass Quote or Order Entry. ODP does not keep track or mandate response to Quote Request.

## Regular Quote Request

#FS10002\_S0060\_00600

Regular Quote Request transactions are initiated by market participants.

## Exchange Quote Request

#FS10002\_S0060\_00700

OTP-D supports Exchange Quote Request from Admin UI. #FS10002\_S0060\_00800 Once the request is received, it is handled the same way as from a Market Participant issued Regular Quote Request.

# Quote and Quote Request Attributes

## Single Quote

#FS10002\_S0070\_00100

Single Quote transaction contains a two-sided order pair with the following attributes:

1. Instrument ID.
2. Quote Entry ID.
3. Bid/Offer price.
4. Bid/Offer quantity.
5. Bid/Offer Cancel Hint Value
6. Bid/Offer MMP Quantity & Delta Protection
7. Self-Match Prevention ID (SMP ID)
8. Broker-to-Client Assigned Number (BCAN)
9. Clearing Account
10. Customer Information
11. Give-up Participant
12. Give-up Information
13. ATID

## Mass Quote

#FS10002\_S0070\_00200

Mass Quote transaction contains a set of quote pairs with the following attributes:

#FS10002\_S0070\_00300

1. An array of quote pairs, each of them includes:
   1. Instrument ID.
   2. Quote Entry ID.
   3. Bid/Offer price.
   4. Bid/Offer quantity.
   5. Bid/Offer Cancel Hint Value
   6. Bid/Offer MMP Quantity & Delta Protection

#FS10002\_S0070\_00400

1. A set of attributes, which are associate to all quote pairs:
   1. Self-Match Prevention ID (SMP ID)
   2. Broker-to-Client Assigned Number (BCAN)
   3. Clearing Account
   4. Customer Information
   5. Give-up Participant
   6. Give-up Information
   7. ATID

#FS10002\_S0070\_00500

The number of allowed quote pairs is configurable, up to 24 two-sided quote pairs are supported to be sent in one transaction.

Each Mass Quote message must have a minimum of one quote pair, up to a maximum of 24 quote pairs, with Quote Entry ID ranging from 1 to 250.

## Quote Request

#FS10002\_S0070\_00600

Quote Request allows market participants to request a quote for a specific instrument. There are Regular Quote Request and Exchange Quote Request, their only difference is the initiator of the transaction, the transaction message itself is the same.

#FS10002\_S0070\_00700

The transaction includes the following information:

1. Instrument ID.
2. Side. #FS10002\_S0070\_00800 This is an optional attribute.
3. Quantity. #FS10002\_S0070\_00900 This is an optional attribute.

# Quote Specific Validation

#FS10002\_S0080\_00100

Where a mass quote fails incoming validation, ODP-T will notify the mass quote originator of the rejection reason through:

1. Mass Quote Acknowledgment/Reject message for full mass quote rejection (where the entire mass quote is rejected), or
2. Following per quote messages:
   1. Order Rejected
   2. Order Cancel Rejected
   3. Order Amend Rejected

## Validation Matrix

| At | Validation | Whole Mass Quote  Rejection | Quote Side Rejection |
| --- | --- | --- | --- |
| OFG | Submitted with valid syntax | **✓** |  |
| OFG | Valid EP | **✓** |  |
| OFG | Valid Comp ID | **✓** |  |
| OFG | Trader has mass quote permissions | **✓** |  |
| OFG | Quote ID uniqueness | **✓** |  |
| OFG | At least one Quote Entry ID is present | **✓** |  |
| OFG | All instruments must be valid | **✓** |  |
| OFG | All instruments are outright instruments | **✓** |  |
| OFG | Trader has the access right to trade all the instruments | **✓** |  |
| OFG | EP is not “blocked” for a specific product in relation to this Mass Quote | **✓**  (ALL instruments are effectively ‘Blocked’ for this EP) | **✓** |
| ME | EP is not “blocked” for a specific product in relation to this Mass Quote |  | **✓** |
| OFG | 1<= Quote Entry ID <= 250 | **✓** |  |
| OFG | Number of quote pairs (i.e., Quote Entry IDs) present must be <=24 | **✓** |  |
| OFG | No duplicate quote pair | **✓** |  |
| OFG | Only one side of a quote pair can be unchanged  (i.e. Validation failure if both sides of a quote entry are marked as unchanged) | **✓** |  |
| OFG | SMP ID must be within technical limits, must also belong to the EP | **✓** |  |
| ME | Order book permission for mass quote |  | **✓** |
| ME | Validity of trading state (Open) – i.e., is mass quote allowed in this trading state. |  | **✓** |
| ME | Validity of Effective Trading Status for an Instrument |  | **✓** |
| OFG | Validity of order quantity (range validation) | **✓** |  |
| OFG | Validity of order price (includes tick size validation and range validation) | **✓** | **✓** |
| ME | Validity of order price (includes SPL & DPL & VCM) |  | **✓** |
| OFG | Validity of other attributes in OFG side | **✓** |  |
| ME | Validity of other attributes where applicable in ME side |  | **✓** |
| OFG | Mass Quote submitted with crossed quotes within a Quote Price Level | **✓** |  |
| ME | MMP protection is not in effect |  | **✓** |
| ME | PTRM stop/kill switch |  | **✓** |
| ME | PTRM limit checks |  | **✓** |

# Order and Quote Actions

## Order Actions

### Order Entry

#FS10002\_S0090\_00100

A Direct Order Flow Session or a Trading GUI User under an Exchange Participant can submit an order entry request for a single order with order attributes as defined in *Section 4. Order Attributes* (of the same document) in an allowable trading state (i.e. during a trading state in which the Order Entry is selected as an allowed trading function) as described in *FS10001 Trading Timetable*.

#FS10002\_S0090\_00200

The processing flow for an order entry request goes as follows:

1. New order entry requests will be subject to validations against the entry channel, the submitter’s permissions, allowable functions at the submitted time and order attributes described in [*Section 4. Order Attributes*](#_Order_Attributes) (in this specifications document), and in interface protocol specifications.

   Below is a summary of the validations performed against an order –
   1. Whether the entry channel[[3]](#footnote-4) where the order entry requests being placed can reach the Matching Engine partition where the Instrument is physically located in,
   2. Whether the Participant or Session/GUI User has been suspended or has the Trading Right to trade the specified Instrument,
   3. Whether the specified Instrument has been ***suspended/halted/expired*** or not allowed to be traded under the current Trading State[[4]](#footnote-5),
   4. Whether incorrect values have been filled in for order attributes (i.e. Expiry date is present in the order request which its TIF condition is not GTD etc.),
   5. Whether impermissible values have been filled in for order attributes (i.e. invalid price due to breaching Price Tick Limit, Static Price Limit or Dynamic Price Limit[[5]](#footnote-6) etc.),
   6. Whether the acceptance of this order entry request would exceed the thresholds defined for Risk Group parameters[[6]](#footnote-7).
2. If all validations pass,
   1. The order will be added to the order book with order priority assigned as described in *FS10003 Order Book and Execution Management, Section 4. Order Priority*.
   2. If the order is resting in an open order book and matching is applicable for the current trading state, order execution will take place as described in *FS10003 Order Book and Execution Management, Section 5.2 Continuous Matching*.

### Order Amendment

#FS10002\_S0090\_00300

Until the order is fully executed, a Direct Order Flow Session or a Trading GUI User under an Exchange Participant can make changes to their submitted orders identified by Client Order ID in an allowable trading state (i.e. during a trading state in which the Order Amend, whether preserving time priority or loss of time priority, is selected as an allowed trading function) as described in *FS10001 Trading Timetable*.

#FS10002\_S0090\_00400 A list of attributes below is allowed to be modified by submitting an amend request.

* 1. Price.
  2. Quantity.
  3. Time Validity.
  4. GTD Expire Date.
  5. Position Effect.
  6. Self-Match Prevention ID (SMP ID).
  7. Cancel Hint Value.
  8. Cancel on Disconnect (COD) Indicator.
  9. Clearing Account.
  10. Customer Information.
  11. Give-up Participant.
  12. Give-up Information.

Note:

* If an amendment request results in triggering VCM, the amendment request will be accepted first, and such amended order will be put into the order book. Then VCM is triggered and such amended order will be cancelled due to VCM.

#FS10002\_S0090\_00500

Modification of attributes other than those in the allowed list above will result in the transaction being rejected.

#FS10002\_S0090\_00510

Order amendment will also go through validation same as order entry. Failed validation will result in rejection, and the original order remains unchanged.

#### Time Validity

#FS10002\_S0090\_00550

Time Validity cannot be amended to FoK, FaK or At Crossing.

FoK, FaK or At Crossing order cannot be amended to other Time Validity.

Time Validity Day, GTC and GTD can be amendable from one type to another among them.

#### Lose Time Priority

#FS10002\_S0090\_00600

Among all amendable attributes, the following changes will result in loss of time priority:

* + 1. Price change.
    2. Quantity increase.
    3. SMP ID change.

### Order Cancellation

#FS10002\_S0090\_00700

A Direct Order Flow Session or a Trading GUI User under an Exchange Participant can submit a request to cancel a single order in an allowable trading state (i.e. during a trading state in which the Order Cancel is selected as an allowed trading function) defined in FS10001. The request must include the Client Order ID of the order to be cancelled.

## Quote Actions

#FS10002\_S0090\_00800

The submitted quote transactions by Exchange Participants are subject to validations as described in [Section 8. Quote Specific Validation](#_Quote_Specific_Validation) inside this specifications document.

#FS10002\_S0090\_00900

Upon the quote transaction is received, a full transaction reject validation is done. If the validations pass, then the transaction will go into a 2 phases cancel-add processing.

### Phase 1 – Cancelling existing quotes

#FS10002\_S0090\_01000

In a quote pair, the Bid side will be processed followed by the Offer side. #FS10002\_S0090\_01100 In case of transaction having multiple quote pairs, they are process one-by-one as follows:

1. If it is a no change instruction, it is skipped. Otherwise,
2. The Instrument ID and Quote Entry ID combination are used to locate the existing quotes in the order book from the same order entry session. #FS10002\_S0090\_01200 If the quote exists, it is then cancelled. Otherwise, no action is performed.

### Phase 2 – Adding new quotes

#FS10002\_S0090\_01300

Follow the same quote pair processing sequence as in Phase 1. All quote pairs are processed as follows:

1. If it is a no change or cancel instruction, it is skipped. Otherwise,
2. The quote will be added to the order book, order priority assigned as per FS10003.

### Summary

* When adding a new quote, no action in Phase 1 and adding the quote in Phase 2.
* When amending an existing quote, cancelling the existing quote in Phase 1 and adding the quote in Phase 2.
* When deleting an existing quote, cancelling the existing quote in Phase 1 and no action in Phase 2.

### Lose Time Priority

#FS10002\_S0090\_01400

Quotes will lose priority when any amendment occurs.

### Quote Related Response

#FS10002\_S0090\_01450

Response transaction to order request is 1-to-1, it means Market Participation will receive 1 response transaction for 1 request transaction.

For quote, the response transaction is per quote side. The responses are as following:

1. If the quote side is new, there will be 1 response transaction. I.e. 2 response transactions for 2-sided quote entry and 1 response transaction for single-sided quote entry.
2. If the quote side is amending an outstanding quote, there will be 2 response transactions according to the “cancel-add” processing. A cancel transaction of the outstanding quote in Phase 1, and then an add transaction with quote attributes from the request in Phase 2.

Note that for mass quote request, all outstanding quote sides are cancelled before new ones with updated attributes are added back to order books. For example, mass quote with 10 2-sided quote entries, there will be a total of 40 response transactions; 20 cancel transactions and then followed by 20 add transactions.

1. If the quote side is cancelling a quote, there will be 1 response transaction. I.e. 2 response transactions for a 2-sided quote entry and 1 response transaction for single-sided quote entry.

Note that when the quote side indicates a no-change action, no response transaction will be sent for it.

## Mass Cancellation

#FS10002\_S0090\_01500

Mass cancellation allows market participant to bulk cancel orders and quotes by submitting selection criteria.

1. Based on orders or quotes:
   1. All orders and quotes. Or
   2. All orders. Or
   3. All quote.
2. Based on Instrument hierarchy to cancel orders or quotes:
   1. For a Market. Or
   2. For an Instrument Type (cover both instrument type and combo type). Or
   3. For an Instrument Class (cover both instrument class and combo class). Or
   4. For an underlying. Or
   5. For an Instrument.
3. Based on the side of orders or quotes:
   1. For both sides. Or
   2. For Buy side. Or
   3. For Sell side.

#FS10002\_S0090\_01600

In addition, the following attributes are allowed to further narrow down the selection:

1. By Clearing Account.
2. By Value to Be Cancelled From/To and Bits to Be Cancelled. (Refer to 4.1.10)

#FS10002\_S0090\_01700

Note that, Mass Cancellation request cannot cancel unaccepted one-party trades.

#FS10002\_S0090\_01800

Exchange users (i.e., HKEX Market Ops) can also cancel orders. The GUI details is in FS-XXXXX.

## On Behalf of Cancellation

#FS10002\_S0090\_01900

Market participants can also submit an on behalf of cancellation (OBO cancellation) request from any of his session to cancel order from another session under the same firm.

### OBO Single Cancellation

#FS10002\_S0090\_02000

For OBO cancelling a single order or quote in another session under the same participant, the request must include the following attributes to indicate the order to be cancelled.

* Instrument ID
* Side
* Order ID

### OBO Mass Cancellation

#FS10002\_S0090\_02100

For OBO cancelling multiple orders or quotes from another session or all sessions (including same session) under the same participant, OBO Mass Cancellation is used. The attributes used to select orders to be cancelled from Mass Cancellation are supported, and an additional attribute to indicate sessions:

1. By Owning Session. It accepts the Comp ID of the owning session under the same participant, a wildcard value indicates all sessions is supported, and this all-sessions-wildcard also includes the session who submits this OBO Mass Cancellation.

# Order Expiry and Reload

## Order Expiry

#FS10002\_S0100\_00100

All orders and quotes expire according to the Time Validity either explicitly specified when they are submitted to ODP or implicitly defined in trading rule.

#FS10002\_S0100\_00200

For Day orders:

* Regardless of the AHT indicator, they are expired and removed from ODP when reach DAYEND trading state. #FS10002\_S0100\_00300 No cancellation transactions will be sent.
* With AHT indicator is false and reach the trading state with INACT\_T\_ORDER attribute, they are expired and cancelled. Unsolicited cancellation transaction will be sent.

#FS10002\_S0100\_00800

For GTD orders:

* Not on the expire date:
  + Regardless of the AHT indicator, done-for-day transactions will be sent at DAYEND trading state.
  + With AHT indicator is false and reach the trading state with INACT\_T\_ORDER attribute, suspend transactions will be sent. At the same time, they are removed from the market and stored in non-public order books where only cancellation is allowed.
* On the expire date:
  + Regardless of the AHT indicator and reach DAYEND trading state, same behavior as Day orders at the DAYEND trading state.
  + With AHT indicator is false and reach the trading state with INACT\_T\_ORDER attribute, #FS10002\_S0100\_00900 same behavior as GTD orders not on expire date at the trading state with INACT\_T\_ORDER attribute.

#FS10002\_S0100\_00850

For GTC orders:

* The behavior is same as GTD orders not on the expire date.

#FS10002\_S0100\_00400

All quotes expire and are removed from ODP when reached (a) trading state with INACT\_T\_ORDER and (b) DAYEND trading state.

* #FS10002\_S0100\_00450 At the trading state with INACT\_T\_ORDER attribute, quote unsolicited cancelled transactions will be sent.
* #FS10002\_S0100\_00500 At DAYEND trading state, no cancellation transactions will be sent.

#FS10002\_S0100\_00600

Orders with Time Validity of FaK and FoK will not rest in order book. If FoK order cannot be fully matched upon submission, it will be rejected immediately. If FaK order cannot be matched any order upon submission, it will be rejected immediately. Partially filled FaK order will be cancelled immediately after the matching. #FS10002\_S0100\_00700 Unsolicited cancellation transaction will be sent for partially filled FaK order.

#FS10002\_S0100\_01000

Orders for expired instruments after the last trading date/time are kept in the order book until DAYEND trading state with no further actions can be taken. #FS10002\_S0100\_01100 They are removed from ODP at DAYEND with no cancellation transactions sent. Note that unsolicited cancellation for cases listed in section 11 Unsolicited Order Cancellation will not be effective to order on expired instrument.

## Order Reload

#FS10002\_S0100\_01200

GTC and GTD orders did not yet expire after the end of trading day are carried forward to the next trading day through a “reload” process.

#FS10002\_S0100\_01300

In DAYEND trading state, ODP persists those orders in data store.

In SOD trading state of next trading day, ODP read data store for GTC and GTD orders which expire date attribute ≥ current trading date and Instrument not yet expired, they are added back to the order book available for trading again.

#FS10002\_S0100\_01400

All order attributes including Order ID remain the same after the reload process.

### Order Reload Validation

#FS10002\_S0100\_01500

All outstanding GTC and GTD orders, which are not expired, will be reloaded into the system at the SOD trading state. Subsequent validation and removal / unsolicited cancellation of orders will only happen when specific setting for individual function has been configured according to respective functional specification. For example, the "Remove Orders Violating the Internal Crossing Rule" parameter as mentioned in FS10007 Self Match Prevention.

# Unsolicited Order Cancellation

#FS10002\_S0110\_00100

Under the following conditions, relevant orders and quotes will be cancelled by ODP.

1. Underlying suspension.
2. Instrument suspension.
3. User session suspension.
4. Exchange Participant suspension.
5. Various limit checks, details refer to *FS10004 Price Supervision*.
6. Cancelled manually via UI interface.
7. Cancel on Disconnect (COD)

## Unmatched Trade Report

#FS10002\_S0110\_00200

Under the following conditions, relevant unmatched trade reports will be cancelled by ODP.

1. Underlying suspension.
2. Instrument suspension.
3. Exchange Participant suspension.
4. Cancelled manually via UI interface.

# Cancel on Disconnect (COD)

#FS10002\_S0120\_00100

Orders with COD indicator specified and all quotes are applicable to COD function.

#FS10002\_S0120\_00200

When the order entry session of a market participant disconnects, the specified orders and all quotes from the order entry session are unsolicited cancelled.

#FS10002\_S0120\_00300

Disconnection is defined as the order entry session idle for a configurable period in seconds without any messages incoming from market participant including (a) business messages like new order and (b) session messages like heartbeat. In ODP, a timer is set up for each session and any incoming message reset the timer. When the timer timeouts, the session will go into another phase of counting additional timeout seconds. COD feature is triggered if there is still no message received and the counting finished.

In addition, a global parameter to enable detection of network-level disconnect. When it is enabled, network-level disconnection will also start the additional timeout counting phase. Similarly, the COD feature is triggered if there is still no message received and the counting finished. Note that the detection is done on a best effort basis.

#FS10002\_S0120\_00400

COD configuration for all order entry sessions:

1. Enable detection of network-level disconnect.
   1. This is a Yes / No value.

COD configuration per order entry session with the following parameters:

1. Number of missing heartbeats.
   1. The accepted value is from 1 up to 1,000.
   2. Notes: The heartbeat interval is defined by market participant when the order entry session is established. The accepted value is from 1 second up to 60 seconds.
2. Additional timeout seconds before triggering COD.
   1. The accepted value is from 0 second up to 10,000 seconds.

#FS10002\_S0120\_00500

COD will be triggered in the following situations:

1. When detection of network-level disconnect is No and a network-level disconnection from the order entry session without a proper Logout message and did not Logon again within the time interval of missing heartbeats plus additional timeout seconds. Or,
2. When detection of network-level disconnect is Yes and a detected network-level disconnection from the order entry session without a proper Logout message and did not Logon again within the time interval of additional timeout seconds. Or,
3. The order entry session is inactive without any messages being received for the time interval of missing heartbeats plus additional timeout seconds.

#FS10002\_S0120\_00600

The following should be noted:

1. COD does not cover unmatched trade reports.
2. COD cannot cancel orders in a trading state which does not allow order cancellation.

1. Details of the max value which can be inputted per order in External Trading GUI, please refer to *FS10014a ODP Online GUI*. [↑](#footnote-ref-2)
2. Defined system behaviour resulting into unsolicited cancel include the following but not limited to – session/user Cancel on Disconnect, Exchange Participant suspension, site failover (empty order book) etc. [↑](#footnote-ref-3)
3. Entry channels could be ODP-TR External Trading GUI or Binary Order Flow Gateway (PSGW or CSGW). [↑](#footnote-ref-4)
4. Please refer to *FS10001 Trading Timetable, Section 6. Trading State* for more details. [↑](#footnote-ref-5)
5. Please refer to the whole document, *FS10004 Price Supervision*, for more details. [↑](#footnote-ref-6)
6. Please refer to the whole document, *FS10005 Pre-Trade Risk Management*, for more details. [↑](#footnote-ref-7)
