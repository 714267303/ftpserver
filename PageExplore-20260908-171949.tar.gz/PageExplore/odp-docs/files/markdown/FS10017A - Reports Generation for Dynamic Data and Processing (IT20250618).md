TITLE:

**FUNCTIONAL SPECIFICATION**

**ODP-T**

*FS10017A - Reports Generation for Dynamic Data and Processing*

AUTHOR : *IT/Markets Systems*  DATE : *17 Feb 2025*

LAST REVIEW Derivatives Trading Business Operations DATE : *28 Feb 2025*

**CONTENTS**

[1 Document Control 7](#__RefHeading___Toc189607812)

[1.1 Change History 7](#__RefHeading___Toc189607813)

[1.2 Document Cross-referenced 7](#__RefHeading___Toc189607814)

[1.3 Abbreviation 7](#__RefHeading___Toc189607815)

[1.4 Distribution List 7](#__RefHeading___Toc189607816)

[2 Introduction 8](#__RefHeading___Toc189607817)

[2.1 System Objectives 8](#__RefHeading___Toc189607818)

[2.2 Scopes 8](#__RefHeading___Toc189607819)

[2.3 Principal Users 8](#__RefHeading___Toc189607820)

[2.4 Document Conventions 8](#__RefHeading___Toc189607821)

[Dynamic Data Reports 9](#__RefHeading___Toc189607822)

[3 Daily Market Report 9](#__RefHeading___Toc189607823)

[3.1 Source of Data 9](#__RefHeading___Toc189607824)

[3.2 Operation Flow 9](#__RefHeading___Toc189607825)

[3.3 Data Archival 10](#__RefHeading___Toc189607826)

[3.4 Holiday Arrangement 10](#__RefHeading___Toc189607827)

[3.5 New Instruments handling 11](#__RefHeading___Toc189607828)

[3.6 Report formats and publish 11](#__RefHeading___Toc189607829)

[3.7 Report Types and Layout 13](#__RefHeading___Toc189607830)

[**Report Types for products with After-Hours trading Session** 13](#__RefHeading___Toc189607831)

[3.7.1 Day Trading Session Reports - Futures with AHT 13](#__RefHeading___Toc189607832)

[3.7.2 Day Trading Session Reports – Indices Options with AHT 22](#__RefHeading___Toc189607833)

[3.7.3 Day Trading Session Reports - Tailor-made Combination with AHT 33](#__RefHeading___Toc189607834)

[3.7.4 Night Trading Session Reports - Futures with AHT 38](#__RefHeading___Toc189607835)

[3.7.5 Night Trading Session Reports –Indices Options with AHT 43](#__RefHeading___Toc189607836)

[3.7.6 Night Trading Session Reports - Tailor-made Combination with AHT 47](#__RefHeading___Toc189607837)

[**Report Types for products with Regular-Hours Trading Session Only** 51](#__RefHeading___Toc189607838)

[3.7.7 Stock Futures 51](#__RefHeading___Toc189607839)

[3.7.8 Indices Futures for Indices, Hibo, T-Bond, Dividend and Commodity 56](#__RefHeading___Toc189607840)

[3.7.9 Stock Options 63](#__RefHeading___Toc189607841)

[3.7.10 Indices / Currency Options 73](#__RefHeading___Toc189607842)

[3.7.11 Flexible Indices Options 79](#__RefHeading___Toc189607843)

[3.7.12 Tailor-Made Combination 84](#__RefHeading___Toc189607844)

[4 Weekly Quotation (Stock Options) Report 89](#__RefHeading___Toc189607845)

[4.1 Source of Data 89](#__RefHeading___Toc189607846)

[4.2 Operation Flow 90](#__RefHeading___Toc189607847)

[4.3 Data Archival 90](#__RefHeading___Toc189607848)

[4.4 Holiday Arrangements 90](#__RefHeading___Toc189607849)

[4.5 New Underlying handling 91](#__RefHeading___Toc189607850)

[4.6 Report formats 91](#__RefHeading___Toc189607851)

[4.7 Report Layout 92](#__RefHeading___Toc189607852)

[4.7.1 Table Attribute 94](#__RefHeading___Toc189607853)

[4.7.2 Report Type Setup 94](#__RefHeading___Toc189607854)

[4.7.3 Field Description 95](#__RefHeading___Toc189607855)

[5 Daily Trading Admin Reports 102](#__RefHeading___Toc189607856)

[5.1 Daily Trading Admin Records Report 102](#__RefHeading___Toc189607857)

[5.1.1 Source of Data 102](#__RefHeading___Toc189607858)

[5.1.2 Operation Flow 102](#__RefHeading___Toc189607859)

[5.1.3 Housekeeping 102](#__RefHeading___Toc189607860)

[5.1.4 Holiday Arrangements 102](#__RefHeading___Toc189607861)

[5.1.5 Special handling 102](#__RefHeading___Toc189607862)

[5.1.6 Report formats 103](#__RefHeading___Toc189607863)

[5.1.7 Report Layout 105](#__RefHeading___Toc189607864)

[5.2 Daily Trading Admin Changes Report 107](#__RefHeading___Toc189607865)

[5.2.1 Source of Data 107](#__RefHeading___Toc189607866)

[5.2.2 Operation Flow 107](#__RefHeading___Toc189607867)

[5.2.3 Housekeeping 107](#__RefHeading___Toc189607868)

[5.2.4 Holiday Arrangements 107](#__RefHeading___Toc189607869)

[5.2.5 Special handling 107](#__RefHeading___Toc189607870)

[5.2.6 Report formats 108](#__RefHeading___Toc189607871)

[5.2.7 Report Layout 109](#__RefHeading___Toc189607872)

[5.3 Daily Trading Admin Error Report 111](#__RefHeading___Toc189607873)

[5.3.1 Source of Data 111](#__RefHeading___Toc189607874)

[5.3.2 Operation Flow 111](#__RefHeading___Toc189607875)

[5.3.3 Housekeeping 111](#__RefHeading___Toc189607876)

[5.3.4 Holiday Arrangements 111](#__RefHeading___Toc189607877)

[5.3.5 Special handling 111](#__RefHeading___Toc189607878)

[5.3.6 Report formats 112](#__RefHeading___Toc189607879)

[5.3.7 Report Layout 113](#__RefHeading___Toc189607880)

[5.4 Daily Trading Admin Withdraw Report 115](#__RefHeading___Toc189607881)

[5.4.1 Source of Data 115](#__RefHeading___Toc189607882)

[5.4.2 Operation Flow 115](#__RefHeading___Toc189607883)

[5.4.3 Housekeeping 115](#__RefHeading___Toc189607884)

[5.4.4 Holiday Arrangements 115](#__RefHeading___Toc189607885)

[5.4.5 Special handling 115](#__RefHeading___Toc189607886)

[5.4.6 Report formats 116](#__RefHeading___Toc189607887)

[5.4.7 Report Layout 117](#__RefHeading___Toc189607888)

[6 User Login Reports 119](#__RefHeading___Toc189607889)

[6.1 Daily Trading GUI User Login Report 119](#__RefHeading___Toc189607890)

[6.1.1 Source of Data 119](#__RefHeading___Toc189607891)

[6.1.2 Operation Flow 119](#__RefHeading___Toc189607892)

[6.1.3 Housekeeping 119](#__RefHeading___Toc189607893)

[6.1.4 Holiday Arrangements 119](#__RefHeading___Toc189607894)

[6.1.5 Special handling 119](#__RefHeading___Toc189607895)

[6.1.6 Report formats 120](#__RefHeading___Toc189607896)

[6.1.7 Report Layout 120](#__RefHeading___Toc189607897)

[6.2 Daily PTRM GUI User Login Report 122](#__RefHeading___Toc189607898)

[6.2.1 Source of Data 122](#__RefHeading___Toc189607899)

[6.2.2 Operation Flow 122](#__RefHeading___Toc189607900)

[6.2.3 Housekeeping 122](#__RefHeading___Toc189607901)

[6.2.4 Holiday Arrangements 122](#__RefHeading___Toc189607902)

[6.2.5 Special handling 122](#__RefHeading___Toc189607903)

[6.2.6 Report formats 123](#__RefHeading___Toc189607904)

[6.2.7 Report Layout 123](#__RefHeading___Toc189607905)

[6.3 Daily/On-demand User Login Report 125](#__RefHeading___Toc189607906)

[6.3.1 Source of Data 125](#__RefHeading___Toc189607907)

[6.3.2 Operation Flow 125](#__RefHeading___Toc189607908)

[6.3.3 Housekeeping 125](#__RefHeading___Toc189607909)

[6.3.4 Holiday Arrangements 125](#__RefHeading___Toc189607910)

[6.3.5 Special handling 125](#__RefHeading___Toc189607911)

[6.3.6 Report formats 125](#__RefHeading___Toc189607912)

[6.3.7 Report Layout 125](#__RefHeading___Toc189607913)

[6.4 Daily/On-demand User List Report 127](#__RefHeading___Toc189607914)

[6.4.1 Source of Data 127](#__RefHeading___Toc189607915)

[6.4.2 Operation Flow 127](#__RefHeading___Toc189607916)

[6.4.3 Housekeeping 127](#__RefHeading___Toc189607917)

[6.4.4 Holiday Arrangements 127](#__RefHeading___Toc189607918)

[6.4.5 Special handling 127](#__RefHeading___Toc189607919)

[6.4.6 Report formats 127](#__RefHeading___Toc189607920)

[6.4.7 Report Layout 127](#__RefHeading___Toc189607921)

[7 Daily Statistics Reports 129](#__RefHeading___Toc189607922)

[7.1 Daily Host Report 129](#__RefHeading___Toc189607923)

[7.1.1 Source of Data 129](#__RefHeading___Toc189607924)

[7.1.2 Operation Flow 129](#__RefHeading___Toc189607925)

[7.1.3 Housekeeping 129](#__RefHeading___Toc189607926)

[7.1.4 Holiday Arrangements 129](#__RefHeading___Toc189607927)

[7.1.5 Special handling 129](#__RefHeading___Toc189607928)

[7.1.6 Report formats 129](#__RefHeading___Toc189607929)

[7.1.7 Report Layout 129](#__RefHeading___Toc189607930)

[7.2 HKATS Daily Trading Statistics Report for Hosting Service 131](#__RefHeading___Toc189607931)

[7.2.1 Source of Data 131](#__RefHeading___Toc189607932)

[7.2.2 Operation Flow 131](#__RefHeading___Toc189607933)

[7.2.3 Housekeeping 131](#__RefHeading___Toc189607934)

[7.2.4 Holiday Arrangements 131](#__RefHeading___Toc189607935)

[7.2.5 Special handling 131](#__RefHeading___Toc189607936)

[7.2.6 Report formats 131](#__RefHeading___Toc189607937)

[7.2.7 Report Layout 131](#__RefHeading___Toc189607938)

[7.3 HKATS Daily Trading Statistics Report by Connection and Device 133](#__RefHeading___Toc189607939)

[7.3.1 Source of Data 133](#__RefHeading___Toc189607940)

[7.3.2 Operation Flow 133](#__RefHeading___Toc189607941)

[7.3.3 Housekeeping 133](#__RefHeading___Toc189607942)

[7.3.4 Holiday Arrangements 133](#__RefHeading___Toc189607943)

[7.3.5 Special handling 133](#__RefHeading___Toc189607944)

[7.3.6 Report formats 133](#__RefHeading___Toc189607945)

[7.3.7 Report Layout 133](#__RefHeading___Toc189607946)

[7.4 Daily Exception Login Report 135](#__RefHeading___Toc189607947)

[7.4.1 Source of Data 135](#__RefHeading___Toc189607948)

[7.4.2 Operation Flow 135](#__RefHeading___Toc189607949)

[7.4.3 Housekeeping 135](#__RefHeading___Toc189607950)

[7.4.4 Holiday Arrangements 135](#__RefHeading___Toc189607951)

[7.4.5 Special handling 135](#__RefHeading___Toc189607952)

[7.4.6 Report formats 135](#__RefHeading___Toc189607953)

[7.4.7 Report Layout 135](#__RefHeading___Toc189607954)

[8 Connectivity Monitoring Reports 137](#__RefHeading___Toc189607955)

[8.1 CCP Report 137](#__RefHeading___Toc189607956)

[8.1.1 Source of Data 137](#__RefHeading___Toc189607957)

[8.1.2 Operation Flow 137](#__RefHeading___Toc189607958)

[8.1.3 Housekeeping 137](#__RefHeading___Toc189607959)

[8.1.4 Holiday Arrangements 137](#__RefHeading___Toc189607960)

[8.1.5 Special handling 137](#__RefHeading___Toc189607961)

[8.1.6 Report formats 137](#__RefHeading___Toc189607962)

[8.1.7 Report Layout 137](#__RefHeading___Toc189607963)

[8.2 CCP User Report 139](#__RefHeading___Toc189607964)

[8.2.1 Source of Data 139](#__RefHeading___Toc189607965)

[8.2.2 Operation Flow 139](#__RefHeading___Toc189607966)

[8.2.3 Housekeeping 139](#__RefHeading___Toc189607967)

[8.2.4 Holiday Arrangements 139](#__RefHeading___Toc189607968)

[8.2.5 Special handling 139](#__RefHeading___Toc189607969)

[8.2.6 Report formats 139](#__RefHeading___Toc189607970)

[8.2.7 Report Layout 139](#__RefHeading___Toc189607971)

[8.3 CG Report 141](#__RefHeading___Toc189607972)

[8.3.1 Source of Data 141](#__RefHeading___Toc189607973)

[8.3.2 Operation Flow 141](#__RefHeading___Toc189607974)

[8.3.3 Housekeeping 141](#__RefHeading___Toc189607975)

[8.3.4 Holiday Arrangements 141](#__RefHeading___Toc189607976)

[8.3.5 Special handling 141](#__RefHeading___Toc189607977)

[8.3.6 Report formats 141](#__RefHeading___Toc189607978)

[8.3.7 Report Layout 141](#__RefHeading___Toc189607979)

[9 PTRM Reports 143](#__RefHeading___Toc189607980)

[9.1 PTRM Audit Reports 143](#__RefHeading___Toc189607981)

[9.1.1 Source of Data 143](#__RefHeading___Toc189607982)

[9.1.2 Operation Flow 143](#__RefHeading___Toc189607983)

[9.1.3 Housekeeping 143](#__RefHeading___Toc189607984)

[9.1.4 Holiday Arrangements 144](#__RefHeading___Toc189607985)

[9.1.5 Report formats 144](#__RefHeading___Toc189607986)

[9.1.6 Report Layout 144](#__RefHeading___Toc189607987)

[9.2 PTRM Util Reports 147](#__RefHeading___Toc189607988)

[9.2.1 Source of Data 147](#__RefHeading___Toc189607989)

[9.2.2 Operation Flow 147](#__RefHeading___Toc189607990)

[9.2.3 Housekeeping 147](#__RefHeading___Toc189607991)

[9.2.4 Holiday Arrangements 147](#__RefHeading___Toc189607992)

[9.2.5 Report formats 148](#__RefHeading___Toc189607993)

[9.2.6 Report Layout 148](#__RefHeading___Toc189607994)

[10 Volatility Control Mechanism (Derivative Market) Cooling-off Period Trigger History 152](#__RefHeading___Toc189607995)

[10.1.1 Source of Data 152](#__RefHeading___Toc189607996)

[10.1.2 Operation Flow 152](#__RefHeading___Toc189607997)

[10.1.3 Housekeeping 152](#__RefHeading___Toc189607998)

[10.1.4 Holiday Arrangements 152](#__RefHeading___Toc189607999)

[10.1.5 Special handling 152](#__RefHeading___Toc189608000)

[10.1.6 Report formats 152](#__RefHeading___Toc189608001)

[10.1.7 Report Layout 152](#__RefHeading___Toc189608002)

[11 APPENDIX A – Report Type mapping with current Market Code for Daily Market Report 154](#__RefHeading___Toc189608005)

[12 APPENDICES B – Report samples in Chinese version for Daily Market Report 160](#__RefHeading___Toc189608006)

# Document Control

## Change History

|  |  |  |  |
| --- | --- | --- | --- |
| Version  Number | Issue Date | Author | Abstract |
| V1.0 | 31-May-2024 | IT/Markets Systems |  |
| V2.0 | 22-Nov-2024 | IT/Markets Systems | * Added Weekly Quotation Report * Divided the FS10017 in 2 document, FS10017A (this FS) as dynamic Data related report |
| V2.1 | 04-Feb-2024 | IT/Markets Systems | * Added PTRM Reports * Added VCM Cool-off period trigger history |
| V2.2 | 13-Feb-2024 | IT/Markets Systems | * Updated BRS Tag |
| V2.3 | 17-Feb-2024 | IT/Markets Systems | * Supplemented section 8.1 and 8.2 |

## Document Cross-referenced

|  |  |  |
| --- | --- | --- |
| # | Document | Version |
| 1 | BRD\_DT\_0013 ODP - Daily Market Report | 20240426 |
| 2 | BRD\_DT\_0014 ODP - NewFunctionRequest Connectivity Monitoring | 20240426 |
| 3 | BRD\_DT\_0019 BRS\_Pre Trade Risk Management | V6.0 |
| 4 | BRD\_DT\_0025 NEW WISH 005 Operation Enhancement Trade Information | 20240426 |
| 5 | BRD\_DT\_0042 BRS Trading Information Reports | V5.0 |
| 6 | BRD\_DT\_0045 BRS\_Reports | V1.1 |
| 7 | BRD\_DT\_0054 Client Services | V2.1 |

## Abbreviation

|  |  |
| --- | --- |
| RHT | Regular Trading Hour |
| AHT | After Trading Hour |

## Distribution List

Derivatives Trading Business Operations

# Introduction

## System Objectives

The trading system report aims to provide a detailed and precise overview of the financial market’s performance. It compiles dynamic data on trade statistics, open interest, settlement prices, and turnover into cohesive and insightful reports. These reports are generated either at specific events or on a set schedule, offering detailed insights into market activities. Additionally, a comprehensive end-of-day summary delivers a holistic view. The system excels in data integration, seamlessly combining information from various sources such as the Matching Engine, Clearing System, and Risk Management System.

## Scopes

The reports to be described in this specification will be

* Daily Market Report (DMR)
* Weekly Quotation (Stock Options) Report

## Principal Users

*This section lists out principal users of the system. In general, principal users include:*

* *Derivatives Trading Operations*

## Document Conventions

The notation used in this document consists of:

 "X" for alphanumeric data;

 "9" for numeric data;

 "Z" for numeric data, blank when zero;

 "|" for changes of the current issue.

# Dynamic Data Reports

# Daily Market Report

#FS10017A\_S0030\_00100

The report generator creates the Daily Market Report (DMR) by gathering trade statistics from the Market Statistic Consolidator. For Open Interest, Settlement Price, and Implied Volatility (IV), it retrieves data from the clearing and risk system. It then uses the instrument’s detailed information from the reference data to determine the detailed report content and compile the report for RHT and AHT respectively

## Source of Data

#FS10017A\_S0030\_00200

The Reference Data encompasses the preparation needed for report generation. This includes identifying the types of reports required and the specific instruments that will be aggregated and presented in the trading activity reports. Additionally, it involves determining the trading timetable to ascertain whether the current date is open for trading and to establish the relevant trading hours.

The Trade Data segment focuses on retrieving instrument trade statistics from the Market Statistics Consolidator. Alongside this, Clearing and Risk Management Data is essential for accurate reporting. Key components include Open Interest, which reflects the current day's interest value provided by the clearing system. The Settlement Price and the Implied Volatility are supplied by the risk management system. If this data is unavailable at the time of report generation, it will be marked as '-'.

## Operation Flow

#FS10017A\_S0030\_00300

Start of Day:

The system's processing commences at the start of the trading day, loading the reference data and previous day's concluding trade statistics for RHT reports.

Market Open (Regular Trading Hour):

No actions during the RHT

Market Close (Regular Trading Hour):

When the market closes for all instrument classes or underlying assets in the Report Name, the process generates the preliminary report version based on the latest statistics for the related instruments. After the report is generated, the report generator begins monitoring for any error trades matched in RHT that may have occurred until the dayend batch starts. If any statistics update due to the error trade, an updated report will be generated for the specific Report Name. For those unavailable clearing and risk data, it will be shown as ‘’-“ (dash) in the report.

* In the Day Trading Session reports, the previous trading day shown in the report is *Previous Trading Date* and the trading day is *Current Trading Date*.
* The AHT Session DMR is still using the report in previous trading day in the HKEX web.

Open Interest and Settlement Price available:

At the scheduled time, the process retrieves the Open Interest from the Clearing system and the Settlement Price from the Risk system. The generator will then use this data to produce an updated version of the report.

After-Hours Trading Open:

No actions for AHT trades.

After-Hours Trading close:

When the AHT market closes for all instrument classes or underlying assets in the Report Name, the process generates the preliminary report version based on the latest AHT statistics for the related instruments. or error trade handling, the process is similar to that during RHT but is applied only to AHT trades. The AHT Session reports will be updated if any error trade executed before the Dayend batch.

* In the Day Trading Session reports, the previous trading day shown in the report is *Previous Trading Date* and the trading day is *Current Trading Date*.
* In the generated AHT Session DMR, the trading day would change to *Current Trading Date*.

## Data Archival

#FS10017A\_S0030\_00400

At dayend, the last sets of RHT and AHT report data are archived in the database, preserving a historical record. This stored data facilitates the generation of Night Trade Session Reports and data continuity in the next trading day.

## Holiday Arrangement

#FS10017A\_S0030\_00500

The process generates reports for tradable products on the trading day only. The product does not open for trading on the trading day will be skipped for generations.

**Products tradable on holiday Trading Day**

#FS10017A\_S0030\_00600

1. Both RHT and AHT reports are generated as normal trade day
2. In RHT report, AHT section should reference the trading information from previous day AHT session as usual. RHT section carries the trading information of current business day.
3. For AHT report, it is posted as normal trade day.

**Products not tradable on Holiday trading day**

#FS10017A\_S0030\_00700

1. Both RHT and AHT reports are not generated and posted on HK Holiday

In Next business day after HK holiday,

1. In RHT report, AHT section will reference to zero trading information due to previous day is holiday. RHT section carries the trading information of the current business day.
2. For AHT report after AHT opened, it is posted as normal trade day.

## New Instruments handling

#FS10017A\_S0030\_00800

The instrument will appear in the report once it becomes active in the reference database, providing users with the flexibility to control when the instrument is displayed.

New market implementation

#FS10017A\_S0030\_00900

To facilitate the generation of the first DMR report on the first business date, a new Report Name associated with the new instrument class must be established on the preceding trading date.

For example, if the first trading day is Monday and the pre-launch day is the previous Friday, the Report Name should be setup on that Friday. This ensures that the first DMR for the new market is ready for the first trading day.

New Instrument

#FS10017A\_S0030\_01000

As the DMR will feature instruments that are active on or after the effective date, any instruments generated manually or through the automatic instrument generation process will be included in the report on the pre-launch date.

For example, for Weekly Index Options, which follow a regular prelaunch contract arrangement, the instrument can be added before the prelaunch date. The daily market report would then show the prelaunch contract week with figures as “-“ or “0”.

## Report formats and publish

#FS10017A\_S0030\_01100

Two output formats will be produced: an HTML format for publishing the Daily Market Report on the HKEX website for viewing, and a CSV format that will be available for external download.

## Report Types and Layout

#FS10017A\_S0030\_01200

The reports are generated after individual market close. An updated version would be generated when trade cancellation has been executed. This ensures a consistent and timely update on trading statistics.

A day-end batch process generates a finalized dayend version of the report, encompassing the ultimate trade statistics of the trading day.

There are 4 main different catalogues of reports as below:

* Day Trading Session
* After-Hours Trading Session
* Tailor-Made Combination
* Tailor-Made Combination After-Hours Trading Session

### **Report Types for products with After-Hours trading Session**

### Day Trading Session Reports - Futures with AHT

#FS10017A\_S0030\_01300

#### Report Layout

|  |  |
| --- | --- |
| 1  2  3456789012345678901234567890123456789012345678901234567890123456789012345678901234567890 | <HTML><HEAD><meta name="MS.LOCALE" content="EN-US"><TITLE> XXXXXXXXXXXXXXXXXXXXXXXXX FUTURES DAILY MARKET REPORT</TITLE>  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">  </HEAD>  <BODY><PRE>  XXXXXXXXXXXXXXXXXXXXXXXXX FUTURES DAILY MARKET REPORT (xxxxxx)  Hong Kong Exchanges and Clearing Limited and/or its subsidiaries endeavour to ensure the  accuracy and reliability of the information provided, but do not guarantee its accuracy and  reliability and accept no liability (whether in tort or contract or otherwise) for any loss  or damage arising from any inaccuracies or omissions.  Prev. Trading Day of the Exchange Trading Day of the Exchange  DD MMM YYYY, WEEKDAY DD MMM YYYY, WEEKDAY  XXX - XXXXXXXXXXXXXXXXXXXXXXXXXXXX  Contract Size = xxxxxxxxxx  After-Hours Trading Session | Day Trading Session | Combined  | |  Contract \*Open \*Daily \*Daily \*Close Volume | \*Open \*Daily \*Daily Volume Settle- Chg in |\*Contract\*Contract Volume Open Change in  Month Price High Low Price Price | High Low ment Setl | High Low Interest OI  | Price Price |  | |  MMM-YY E X | P I R E | D Z,ZZZ,ZZ9 ±Z,ZZZ,ZZ9  MMM-YY ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 | ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ±ZZZ,ZZ9 | ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 Z,ZZZ,ZZ9 ±Z,ZZZ,ZZ9 …  MMM-YY ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 | ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ±ZZZ,ZZ9 | ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 Z,ZZZ,ZZ9 ±Z,ZZZ,ZZ9    Total ZZZ,ZZ9 Z,ZZZ,ZZ9 ±Z,ZZZ,ZZ9  XXX - XXXXXXXXXXXXXXXXXXXXXXXXXXXX  Contract Size = xxxxxxxxxx  After-Hours Trading Session | Day Trading Session | Combined  | |  Contract \*Open \*Daily \*Daily \*Close Volume | \*Open \*Daily \*Daily Volume Settle- Chg in |\*Contract\*Contract Volume Open Change in  Month Price High Low Price Price | High Low ment Setl | High Low Interest OI  | Price Price |  | |  MMM-YY E X | P I R E | D Z,ZZZ,ZZ9 ±Z,ZZZ,ZZ9  MMM-YY ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 | ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ±ZZZ,ZZ9 | ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 Z,ZZZ,ZZ9 ±Z,ZZZ,ZZ9 …  MMM-YY ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 | ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ±ZZZ,ZZ9 | ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 Z,ZZZ,ZZ9 ±Z,ZZZ,ZZ9    Total ZZZ,ZZ9 Z,ZZZ,ZZ9 ±Z,ZZZ,ZZ9  …  …  …  All Contracts Total ZZZ,ZZ9 Z,ZZZ,ZZ9 ±Z,ZZZ,ZZ9  Trading Day of the Exchange  DD MMM YYYY, WEEKDAY  Day Trading Session  XXX - XXXXXXXXXXXXXXXXXXXXXXXXXXXX  Contract STRATEGY Open Daily Daily Volume  Month Price High Low  MMM-11/MMM-11 Calendar Spread ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9  …  MMM-11/MMM-11 Calendar Spread ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9  Total ZZZ,ZZ9  XXX - XXXXXXXXXXXXXXXXXXXXXXXXXXXX  Contract STRATEGY Open Daily Daily Volume  Month Price High Low  MMM-11/MMM-11 Calendar Spread ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9  …  MMM-11/MMM-11 Calendar Spread ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9  Total ZZZ,ZZ9  …  …  …  All Strategies Total ZZZ,ZZ9  \*\*\* END OF REPORT \*\*\*  \*All Calendar Spread vs. Calendar Spread transactions are excluded  </PRE></BODY></HTML> |
|  | 1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901 |

#### Report Attribute

|  |  |
| --- | --- |
| Purpose | To generate a report showing the market summary of futures indices instrument (single / multiple classes) with After-Hours Trading on T session |
| Frequency | Refer to the operation flow |
| Sequence | Contract year and month |
| Page Size | 91 columns |
| File Name | <Report Name>F<yymmdd>.htm |
| Chinese Version | Please refer to Appendix B |

#### Report Type Setup

To assign the instrument printed in the report, it is required to create a record in the report type. The reports will be generated per Report Name. Each Report Name requires users to define the corresponding list of Instrument Class. The report generator would locate all contracts and Standard Combo under per assigned Instrument Class. Users are required to define the Report Header for the Report Name. The Contract Description, Contract Term for each instrument class printed in the report. The contracts will be grouped per instrument class and printed in Instrument class’s alphabetical order.

The report type setup fields are as below:

|  |  |
| --- | --- |
| **Report Type** | **Report for Futures with AHT** |
| **Report Name** | Specify the ID for the report. |
| **Instrument Class** | Assign the corresponding Instrument Class to locate the corresponding contracts printed in the report |
| **Underlying** | Not applicable for this report type |
| **Header** | Specify the header of the report |
| **Contract Description** | Specify the Contract description |
| **Contract Term** | Specify the Contract price per index point |
| **Keep Day for spot month** | Specify the number of days to show ‘EXPIRED’ for the spot month Futures Instruments after the Last Trading Date. The ‘EXPIRED’ row will display the updated Open Interest information, with the figure gradually reducing to zero for expired instruments.  0 means there is no need to show ‘EXPIRED’  1 means to show ‘EXPIRED’ for 1 day after the Last Trading Date  2 means to show ‘EXPIRED’ for 2 days after the Last Trading Date  Maximum value = 5 |

Example for HSI Futures:

|  |  |  |  |
| --- | --- | --- | --- |
| **Report for Futures with AHT** | | | |
| **Report Name** | HSIF | | |
| **Header** | Hang Seng Index Future | | |
| **Instrument Class list** | | | |
| **Instrument Class** | | **Contract Description** | **Contract Term** |
| HSIFUT | | HSI - Hang Seng Index Futures HK$50 per index point |  |

Example for LME mini Futures

|  |  |  |
| --- | --- | --- |
| **Report for Futures with AHT** | | |
| **Report Name** | LMEF | |
| **Header** | CNH London Metal Mini Future (LME) | |
| **Instrument Class list** | | |
| **Instrument Class** | **Contract Description** | **Contract Term** |
| LRAFUT | LRA - CNH London Aluminium Mini Futures RMB5 per minimum fluctuation | Contract Size = 5 tonnes |
| LRCFUT | LRC - CNH London Copper Mini Futures RMB10 per minimum fluctuation | Contract Size = 5 tonnes |
| LRNFUT | LRN - CNH London Nickel Mini Futures RMB10 per minimum fluctuation | Contract Size = 1 tonne |
| LRPFUT | LRP - CNH London Lead Mini Futures RMB5 per minimum fluctuation | Contract Size = 5 tonnes |
| LRSFUT | LRS - CNH London Tin Mini Futures RMB10 per minimum fluctuation | Contract Size = 1 tonne |
| LRZFUT | LRZ - CNH London Zinc Mini Futures RMB5 per minimum fluctuation | Contract Size = 5 tonnes |

Noted: The Instrument Class list will be sorted by alphabetical order.

#### Fields Description

| **Field name** | **Description** | **Position on 3.7.1.1** | **Format** | **Remarks** |
| --- | --- | --- | --- | --- |
| HTML header & report title | The report title | Line 1 – 5 |  | E.g. “CNH LONDON METAL MINI” |
| Prev. Trading Day of the Exchange | To show the date of previous business day | Line 12 – 13 | DD MMM YYYY, WEEKDAY |  |
| Current Trading Date | To show the business date of the report | Line 12 – 13 | DD MMM YYYY, WEEKDAY | Trading Day of the Exchange |
| Contract Description | Specified in the corresponding Report Name’s Instrument Class. | Line 15, xxx |  | e.g. “LRA – CNH London Aluminium Mini Futures RMB5 per minimum fluctuation  or blank if not defined. |
| Contract term | Specified in the corresponding Report Name’s Instrument Class.  Blank if not defined. | Line 16, xxx |  | e.g.  Contract Size = 5 tonnes”  or blank if not defined. |
| **Market Statistic** |  | Line 24– Line xxx |  |  |
| Contract Month | To show the contract year and month of the instruments. |  | MMM-YY  where MMM = JAN .. DEC and  YY = the last two digits of the contract year |  |
| After-Hours Trading Session |  |  |  |  |
| Open Price | To show the first traded price of the instruments on previous T+1 session |  | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or  ZZZ9.99 | Display “EXPIRED” from Open Price field to Volume field for any expired instruments of the month. |
| Daily High | To show the highest traded price on previous T+1 session |  | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or  ZZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Daily Low | To show the lowest traded price on previous T+1 session |  | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or  ZZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Close Price | To show the last traded price on previous T+1 session |  | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or  ZZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Volume | To show the number of traded volume of the instruments on previous T+1 session |  | Z,ZZZ,ZZ9 or  ZZZZZZ9 | NIL – when instruments expired  “0“- when not applicable |
| Day Trading Session |  |  |  |  |
| Open Price | To show the first traded price of the instruments of today |  | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or  ZZZ9.99 | Display “EXPIRED” from Open Price field to Volume field for any expired instruments of the month. |
| Daily High | To show the highest traded price of today |  | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or  ZZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Daily Low | To show the lowest traded price of today |  | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or  ZZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Volume | To show the number of traded volume of the instruments of today |  | Z,ZZZ,ZZ9 or  ZZZZZZ9 | NIL – when instruments expired  “0“- when not applicable |
| Settlement Price | To show the settlement price of the instruments of today |  | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or  ZZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Chg in Setl Price | To show the change of settlement price from that of previous business day |  | ±Z,ZZZ,ZZ9 or  ±ZZZ,ZZ9 or  ±ZZ,ZZ9.99 or  ±Z,ZZ9.99 or  ±ZZZ9.99 | NIL – when instruments expired  “-“- when today’s settlement price is not available  Today’s settlement price minus previous day’s settlement price available from clearing system. |
| Combined Session |  |  |  |  |
| Contract High | To show the highest price of the contract since commerce trading |  | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or  ZZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Contract Low | To show the Lowest price of the contract since commerce trading |  | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or  ZZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Volume | To show the number of traded volume of the instruments combining previous trading day’s After-Hours Trading Session and current trading day’s Regular-Hours Trading Session |  | Z,ZZZ,ZZ9 or  ZZZZZZ9 | NIL – when instruments expired  “0“- when not applicable |
| Open Interest | To show the open interest of current business day |  | Z,ZZZ,ZZ9 or  ZZZZZZ9 | “-“- when not applicable |
| Change in OI | To show the change of today’s open interest from previous date |  | ±Z,ZZZ,ZZ9 or  ±ZZZZZZ9 | “-“- when todays’ Open Interest is not available  Today’s OI minus previous day’s open interest available from clearing system. |
| **All Contracts Total** |  | Line xxx |  |  |
| Volume | To show the number of traded volume of all instruments in all contract months in today |  | Z,ZZZ,ZZ9 or  ZZZZZZ9 |  |
| Open Interest | To show the open interest of all instruments in today |  | Z,ZZZ,ZZ9 or  ZZZZZZ9 |  |
| Change in OI | To show the change of open interest of all instruments in today minus previous day |  | ±Z,ZZZ,ZZ9 or  ±ZZZZZZ9 |  |
| **Strategies Declaration** |  | Lines xxx |  |  |
| System Date | To show the business date of the report | Line xxx | DD MMM YYYY, WEEKDAY | Trading Day of the Exchange |
| Contract Description | Specified in the corresponding Report Name’s Instrument Class. | Line 15, xxx |  | e.g. “LRA – CNH London Aluminium Mini Futures RMB5 per minimum fluctuation  or blank if not defined. |
| **Strategies** |  | Lines xxx |  |  |
| Calendar spread Month | To show the calendar spread months |  | MMM-YY / MMM-YY | where MMM = JAN .. DEC and  YY = the last two digits of the contract year |
| Strategy type | Strategy description |  | Alphanumeric |  |
| Open Price | To show the first traded price of the instruments of today |  | Z,ZZZ,ZZ9 or  ZZ,ZZ9.99 or  ZZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Daily High | To show the highest traded price of today |  | Z,ZZZ,ZZ9 or  ZZ,ZZ9.99 or  ZZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Daily Low | To show the lowest traded price of today |  | Z,ZZZ,ZZ9 or  ZZ,ZZ9.99 or  ZZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Volume | To show the number of traded volume of the instruments of today |  | Z,ZZZ,ZZ9 or  ZZZZZ9 | NIL – when instruments expired  “0“- when not applicable |
| **All Strategy Total** |  | Line xxx |  |  |
| Volume | To show the number of traded volume of all instruments in all contract months |  | Z,ZZZ,ZZ9 or  ZZZZZ9 |  |

### Day Trading Session Reports – Indices Options with AHT

#FS10017A\_S0030\_01400

#### Report Layout

|  |  |
| --- | --- |
| 1  2  3456789012345678901234567890123456789012345678901234567 | <HTML><HEAD>  <meta name="MS.LOCALE" content="EN-US">  <TITLE> XXXXXXXXXXXXXXXXXXXXXXXXX OPTIONS DAILY MARKET REPORT</TITLE>  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">  </HEAD><BODY><PRE>  XXXXXXXXXXXXXXXXXXXXXXXXX OPTIONS DAILY MARKET REPORT (xxxxxx)  Hong Kong Exchanges and Clearing Limited and/or its subsidiaries endeavour to ensure the  accuracy and reliability of the information provided, but do not guarantee its accuracy and  reliability and accept no liability (whether in tort or contract or otherwise) for any loss  or damage arising from any inaccuracies or omissions.  TOP 10 TRADED (BY VOLUME) VOLUME O.Q.P. IV% DAILY DAILY OPEN O.Q.P.  CLOSE HIGH LOW INTEREST CHANGE  X MMM-YY ZZZZZZZZZ9 ZZZZZZZZ9 ZZZZZZZZ9 ZZZ9 ZZZZZZZZ9 ZZZZZZZZ9 ZZZZZZZZ9 ±ZZZZZZZ9    (Top 2ND – 10TH instruments by traded volume)    XXXXXXXXXXXXXXXXXXXXXXXXX Options XXXXXX per point    Prev. Trading Day of the Exchange Trading Day of the Exchange  DD MMM YYYY, WEEKDAY DD MMM YYYY, WEEKDAY  After-Hours Trading Session | Day Trading Session | Combined  | |  <A NAME="month1"></A>  CONTRACT STRIKE \*OPENING \*DAILY \*DAILY CLOSE VOLUME |\*OPENING \*DAILY \*DAILY O.Q.P. O.Q.P. IV% VOLUME | \*Contract \*Contract Volume Open Change in  MONTH PRICE PRICE HIGH LOW PRICE | PRICE HIGH LOW CLOSE CHANGE | High Low Interest OI  MMM-YY ZZZZZ9 C ZZZZZZZ9 ZZZZZZ9 ZZZZZZ9 ZZZZZZ9 ZZZZZZ9 | ZZZZZZ9 ZZZZZZ9 ZZZZZZ9 ZZZZZZ9 ±ZZZZZZ9 ZZZ9 ZZZZZZZZZ9 | ZZZZZZZZ9 ZZZZZZZZ9 ZZZZZZZZZ9 ZZZZZZZZ9 ±ZZZZZZZ9 …  MMM-YY ZZZZZ9 C ZZZZZZZ9 ZZZZZZ9 ZZZZZZ9 ZZZZZZ9 ZZZZZZ9 | ZZZZZZ9 ZZZZZZ9 ZZZZZZ9 ZZZZZZ9 ±ZZZZZZ9 ZZZ9 ZZZZZZZZZ9 | ZZZZZZZZ9 ZZZZZZZZ9 ZZZZZZZZZ9 ZZZZZZZZ9 ±ZZZZZZZ9    TOTAL CALL ZZZZZZ9 | TOTAL CALL ZZZZZZZZZ9 | TOTAL CALL ZZZZZZZZZ9 ZZZZZZZZ9 ±ZZZZZZZ9  CONTRACT STRIKE \*OPENING \*DAILY \*DAILY CLOSE VOLUME |\*OPENING \*DAILY \*DAILY O.Q.P. O.Q.P. IV% VOLUME | \*Contract \*Contract Volume Open Change in  MONTH PRICE PRICE HIGH LOW PRICE | PRICE HIGH LOW CLOSE CHANGE | High Low Interest OI  MMM-YY ZZZZZ9 C ZZZZZZZ9 ZZZZZZ9 ZZZZZZ9 ZZZZZZ9 ZZZZZZ9 | ZZZZZZ9 ZZZZZZ9 ZZZZZZ9 ZZZZZZ9 ±ZZZZZZ9 ZZZ9 ZZZZZZZZZ9 | ZZZZZZZZ9 ZZZZZZZZ9 ZZZZZZZZZ9 ZZZZZZZZ9 ±ZZZZZZZ9 …  MMM-YY ZZZZZ9 C ZZZZZZZ9 ZZZZZZ9 ZZZZZZ9 ZZZZZZ9 ZZZZZZ9 | ZZZZZZ9 ZZZZZZ9 ZZZZZZ9 ZZZZZZ9 ±ZZZZZZ9 ZZZ9 ZZZZZZZZZ9 | ZZZZZZZZ9 ZZZZZZZZ9 ZZZZZZZZZ9 ZZZZZZZZ9 ±ZZZZZZZ9    TOTAL PUT ZZZZZZ9 | TOTAL PUT ZZZZZZZZZ9 | TOTAL PUT ZZZZZZZZZ9 ZZZZZZZZ9 ±ZZZZZZZ9  | MONTH PUT/CALL RATIO ZZZZZ9.Z9  | MONTH TOTAL ZZZZZZZZZ9 ZZZZZZZZ9 ±ZZZZZZZ9  MARKET PUT/CALL RATIO ZZZZZ9.Z9  MARKET TOTAL ZZZZZZZZZ9 ZZZZZZZZ9 ±ZZZZZZZ9  \*\*\* END OF REPORT \*\*\*  O.Q.P. - OFFICIAL QUOTATION PRICE  \*ALL COMBO VS. COMBO TRANSACTIONS ARE EXCLUDED  </PRE></BODY></HTML> |
|  | 123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901 |

#### Report Attribute

|  |  |
| --- | --- |
| Purpose | To generate a report showing the market summary of options indices instruments (multiple classes) with After-Hours Trading on T session |
| Frequency | Refer to the operation flow |
| Sequence | Contract year and month |
| Page Size | 171 columns |
| File Name | <Report Name>O<yymmdd>.htm |
| Chinese Version | Please refer to Appendix B |

#### Report Type Setup

To assign the instrument printed in the report, it is required to create a record in the report type. The reports will be generated per Report Name. Each Report Name requires users to define the corresponding Options Call and Put Instrument Class. The report generator would locate all contracts under the specified Call and Put Options Instrument Class. Users are required to define the Report Header of the Report Name. And the Contract Description, Contract Term for the corresponding options class printed in the report.

The order of printing the options contracts under the same Report Name is as follows:

1. Call Options with the nearest maturity, sorted by Strike Price from lowest to highest (each row represents a different Strike Price)
2. Put Options with the same nearest maturity, sorted by Strike Price from Lowest to highest (each row represents a different Strike Price)
3. Call Options with the next nearest maturity, sorted by Strike Price from lowest to highest (each row represents a different Strike Price)
4. Put Options with the next nearest maturity, sorted by Strike Price from lowest to highest (each row represents a different Strike Price)
5. Repeat steps 3-4 for the remaining maturities, going from the nearest to the furthest.

For multiple classes printed in a single report, the corresponding Instrument Class can share the same Report Name. The contracts will be grouped per instrument class in alphabetical order.

The report type setup fields are as below:

|  |  |
| --- | --- |
| **Report Type** | **Report for Options with AHT** |
| **Report Name** | Specify the ID for the report. |
| **Header** | Specify the header of the report |
| **Instrument Class** | Specify the instrument class of the Call / Put Options |
| **Underlying** | Specify the Underlying of the Instrument Class to group the CALL and PUT Instrument in the instrument sorting |
| **Contract Description** | Specify the Contract description |
| **Contract Term** | Specify the Contract price per index point |
| **Expiration Frequency** | Specify the instrument is in Monthly or Weekly Expire.   * The Contract Month / Week would be displayed in MMM-YY if Monthly is selected * The Contract Month / Week would be displayed in DD-MMM-YY if Weekly is selected   Default value is Monthly |

Example:

Example for HSI Options

|  |  |  |  |
| --- | --- | --- | --- |
| **Report for Options with AHT** | | | |
| **Report Name** | | HSIO | |
| **Header** | | Hang Seng Index Options | |
| **Instrument Class list** | | | |
| **Instrument Class** | **Underlying** | **Contract Description** | **Contract Term** |
| HSICALL | HSI | Hang Seng Index Options HK$50 per point |  |
| HSIPUT | HSI |  |  |

Noted: The Instrument Class list will be sorted by alphabetical order.

#### Fields Description

| **Field name** | **Description** | **Position on 3.7.2.1** | **Format** | **Remarks** |
| --- | --- | --- | --- | --- |
| HTML header & report title | The report title | Line 1 – 13 | Refer to the Header field in the report type setup | "HANG SENG INDEX " or  “MINI-HANG SENG INDEX " or  “HANG SENG CHINA ENTERPRISES INDEX " or  “MINI-HANG SENG CHINA ENTERPRISES INDEX " Or  “HANG SENG TECH INDEX” or  “HANG SENG INDEX FUTURES “ or  “HANG SENG CHINA ENTERPRISES INDEX FUTURES " |
| **TOP 10 TRADED (SORT BY VOLUME)** |  | Line 14-15 |  | List the 10 most traded instruments defined for the report. |
| Put/Call code | The put or call symbol of the Top 10 Traded option |  | “P”,“C” | C – Call options  P – Put options |
| The contract month/day of the instruments | To show the contract month and year of the instruments |  | MMM-YY | For **Expiration Frequency** = Monthly, show month and year of the last trade day of the Instrument  For **Expiration Frequency** = Weekly, show last trade day of the Instrument |
| Strike price of the instruments | To show the strike price of the options instruments |  | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZZZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or  ZZZ9.99 |  |
| Volume | To show the traded volume of the instruments |  | Z,ZZZ,ZZ9 or  ZZZZZZ9 |  |
| O.Q.P Close | To show the settlement price of the instruments |  | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZZZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or  ZZZ9.99 | NIL – when instruments expired  “-“- when not applicable |
| IV% | To show the implied volatility of the instruments |  | ZZ9 | “-“- when not applicable |
| Daily High | To show the highest traded price of the instruments |  | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZZZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or  ZZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Daily Low | To show the lowest traded price of the instruments |  | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZZZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or  ZZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Open Interest | To show the open interest of the instruments |  | Z,ZZZ,ZZ9 or  ZZZZZZ9 | “-“- when not applicable |
| O.Q.P. Change | To show the change in settlement price of the instruments from the previous business day |  | ±ZZZZ9 or  ±ZZZ9.99 | ‘N/A‘ when not applicable  Today’s OI minus previous day’s settlement price available from clearing system. |
| Contract Description | Specified in the corresponding Report Name’s Instrument Class. | Line 15, xxx |  | "HANG SENG INDEX OPTIONS HK$ 50 PER POINT" or  "MINI-HANG SENG INDEX OPTIONS HK$ 10 PER POINT" or  "HANG SENG CHINA ENTERPRISES INDEX OPTIONS HK$ 50 PER POINT" or  “MINI-HANG SENG CHINA ENTERPRISES INDEX OPTIONS HK$ 10 PER POINT " Or  “HANG SENG TECH INDEX OPTIONS HK$ 50 PER POINT” or  “HANG SENG INDEX FUTURES OPTIONS HK$ 50 PER POINT “ or  “HANG SENG CHINA ENTERPRISES INDEX FUTURES OPTIONS HK$ 50 PER POINT " |
| Prev. Trading Day of the Exchange | To show the date of previous business day | Line 29 – 30 | DD MMM YYYY, WEEKDAY | The previous business day means the previous trading day of any market that was open for trading. |
| System Date | To show the creation date of the report | Line 29 – 30 | DD MMM YYYY, WEEKDAY | Trading Day of the Exchange |
| After-Hours Trading Session | Session header | Line 32 | Hardcode in template file for the market. |  |
| Day Trading Session | Session header | Line 32 | Hardcode in template file for the market. |  |
| **Market Statistic** |  | Line 35– Line xxx |  |  |
| Contract Month / Week | To show the contract expiration month or date of the Instrument according to the Expiration Frequency |  | MMM-YY for Expiration Frequency = Monthly  DD-MMM-YY for Expiry Frequency = Weekly  where  DD = day of month  MMM = JAN .. DEC and  YY = the last two digits of the contract year | Show Contract Month when **Expiration Frequency** = Monthly  Show Contract Week when **Expiration Frequency** = Weekly |
| After-Hours Trading Session |  |  |  |  |
| Open Price | To show the first traded price of the instruments on **Prev. Trading Day** T+1 session |  | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZZZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or  ZZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Daily High | To show the highest traded price on **Prev. Trading Day** T+1 session |  | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZZZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or  ZZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Daily Low | To show the lowest traded price on **Prev. Trading Day** T+1 session |  | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZZZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or  ZZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Close Price | To show the last traded price on **Prev. Trading Day** T+1 session |  | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZZZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or  ZZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Volume | To show the number of traded volume of the instruments on **Prev. Trading Day** T+1 session |  | Z,ZZZ,ZZ9 or  ZZZZZZ9 | “0“- when not applicable |
| Day Trading Session |  |  |  |  |
| Open Price | To show the first traded price of the instruments of today |  | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZZZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or  ZZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Daily High | To show the highest traded price of today |  | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZZZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or  ZZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Daily Low | To show the lowest traded price of today |  | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZZZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or  ZZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Volume | To show the number of traded volume of the instruments |  | Z,ZZZ,ZZ9 or  ZZZZZZ9 | “0“- when not applicable |
| O.Q.P Close | To show the settlement price of the instruments |  | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZZZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or  ZZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| O.Q.P. Change | To show the change in settlement price of the instruments from the previous business day |  | ±ZZZZ9 or  ±ZZZ9.99 | ‘N/A‘ when not applicable  Today’s settlement price minus previous day’s settlement price available from clearing system. |
| Combined Session |  |  |  |  |
| Contract High | To show the highest price of the contract |  | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZZZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or  ZZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Contract Low | To show the Lowest price of the contract |  | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZZZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or  ZZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Volume | To show the number of traded volume of the instruments |  | Z,ZZZ,ZZ9 or  ZZZZZZ9 | “0“- when not applicable |
| Open Interest | To show the open interest of previous business day |  | Z,ZZZ,ZZ9 or  ZZZZZZ9 | “-“- when not applicable |
| Change in OI | To show the change of open interest in the two previous business days |  | ±Z,ZZZ,ZZ9 or  ±ZZZZZZ9 | “-“- when not applicable  Today’s Open Interest minus previous day’s Open Interest available from clearing system. |
| **Contracts Total (CALL/PUT)** |  | Line xxx |  | Show per Instrument’s Last Trading day group per Instrument Class in Call / Put |
| AHT Volume | To show the number of traded volume of all instruments |  | Z,ZZZ,ZZ9 or  ZZZZZZ9 |  |
| RHT Volume | To show the number of traded volume of all instruments |  | Z,ZZZ,ZZ9 or  ZZZZZZ9 |  |
| Combined Volume | To show the number of traded volume of all instruments |  | Z,ZZZ,ZZ9 or  ZZZZZZ9 |  |
| Open Interest | To show the open interest of all instruments in the previous business day |  | Z,ZZZ,ZZ9 or  ZZZZZZ9 |  |
| Change in OI | To show the change of open interest of all instruments in the two previous business days |  | ±Z,ZZZ,ZZ9 or  ±ZZZZZZ9 |  |
| **Month /Week Total**  **(Contract Month / Week)** |  | Line xxx |  | Show per Instrument’s Last Trading day group per Underlying |
| Ratio | Put Call Ratio of the Month |  | ZZZZZZ9.99 | ‘----------‘ when call = 0 |
| Volume | To show the number of traded volume of all instruments |  | Z,ZZZ,ZZ9 or  ZZZZZZ9 |  |
| Open Interest | To show the open interest of all instruments in the previous business day |  | Z,ZZZ,ZZ9 or  ZZZZZZ9 |  |
| Change in OI | To show the change of open interest of all instruments in the two previous business days |  | ±Z,ZZZ,ZZ9 or  ±ZZZZZZ9 |  |
| **Market Total**  **(Contract Month)** |  | Line xxx |  |  |
| Ratio | Put Call Ratio of the Month |  | ZZZZZZ9.99 | ‘----------‘ when call = 0 |
| Volume | To show the number of traded volume of all instruments |  | Z,ZZZ,ZZ9 or  ZZZZZZ9 |  |
| Open Interest | To show the open interest of all instruments in the previous business day |  | Z,ZZZ,ZZ9 or  ZZZZZZ9 |  |
| Change in OI | To show the change of open interest of all instruments in the two previous business days |  | ±Z,ZZZ,ZZ9 or  ±ZZZZZZ9 |  |

### Day Trading Session Reports - Tailor-made Combination with AHT

#FS10017A\_S0030\_01500

#### Report Layout

|  |  |
| --- | --- |
| 1  2  34567890123456789012345678901234567890 | <HTML><HEAD><meta name="MS.LOCALE" content="EN-US"><TITLE> XXXXXXXXXXXXXXXXXXXXXXXXX TAILOR-MADE COMBINATION DAILY MARKET REPORT</TITLE>  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">  </HEAD>  <BODY><PRE>  XXXXXXXXXXXXXXXXXXXXXXXXX TAILOR-MADE COMBINATION DAILY MARKET REPORT  Hong Kong Exchanges and Clearing Limited and/or its subsidiaries endeavour to ensure the  accuracy and reliability of the information provided, but do not guarantee its accuracy and  reliability and accept no liability (whether in tort or contract or otherwise) for any loss  or damage arising from any inaccuracies or omissions.  Prev. Trading Day of the Exchange  DD MMM YYYY, WEEKDAY    After-Hours Trading Session  General Name Leg 1 Leg 2 Leg 3 Leg 4 Open Price Daily High Daily Low Last Volume    1 TMC\_XXX/NNN (X N) XXXXXXXXXX (X N) XXXXXXXXXX (X N) XXXXXXXXXX (X N) XXXXXXXXXX ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9  2 TMC\_XXX/NNN (X N) XXXXXXXXXX (X N) XXXXXXXXXX (X N) XXXXXXXXXX (X N) XXXXXXXXXX ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9  …  N TMC\_XXX/NNN (X N) XXXXXXXXXX (X N) XXXXXXXXXX (X N) XXXXXXXXXX (X N) XXXXXXXXXX ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9  Trading Day of the Exchange  DD MMM YYYY, WEEKDAY    Day Trading Session  General Name Leg 1 Leg 2 Leg 3 Leg 4 Open Price Daily High Daily Low Last Volume    1 TMC\_XXX/NNN (X N) XXXXXXXXXX (X N) XXXXXXXXXX (X N) XXXXXXXXXX (X N) XXXXXXXXXX ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9  2 TMC\_XXX/NNN (X N) XXXXXXXXXX (X N) XXXXXXXXXX (X N) XXXXXXXXXX (X N) XXXXXXXXXX ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9  …  N TMC\_XXX/NNN (X N) XXXXXXXXXX (X N) XXXXXXXXXX (X N) XXXXXXXXXX (X N) XXXXXXXXXX ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9  \*\*\* END OF REPORT \*\*\*  </PRE></BODY></HTML> |
|  | 12345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901 |

#### Report Attribute

|  |  |
| --- | --- |
| Purpose | To generate a report showing the market summary of futures and options tailor-made combination instruments with After-Hours Trading on T session |
| Frequency | Refer to the operation flow |
| Sequence | Contract year and month |
| Page Size | 161 columns |
| File Name | <Report Name>TMC<yymmdd>.htm |
| Chinese Version | Please refer to Appendix B |

#### Report Type Setup

To assign the Tailor Made Combo (TMC) Contracts printed in the report, it is required to create a record in the report type. The reports will be generated per Report Name. Each Report Name requires users to define the corresponding list of Combo Class. The report generator would locate all TMC under per assigned Combo Class. Users are required to define the Report Header for the Report Name. The Contract Description, Contract Term for each instrument class printed in the report. The report will only show the contracts with traded volume and will be grouped per instrument class and printed in Instrument class’s alphabetical order.

The report type setup fields are as below:

|  |  |
| --- | --- |
| **Report Type** | **Report for Tailor-made Combination with AHT** |
| **Report Name** | Specify the ID for the report. |
| **Instrument Class** | Assign the corresponding Combo Class to locate the corresponding contracts printed in the report |
| **Underlying** | Not applicable for this report type |
| **Header** | Specify the header of the report |
| **Contract Description** | Specify the Contract description |
| **Contract Term** | Specify the Contract price per index point |

Example for HSI TMC:

|  |  |  |  |
| --- | --- | --- | --- |
| **Report for TMC with AHT** | | | |
| **Report Name** | HSITMC | | |
| **Header** | Hang Seng Index Futures and Options | | |
| **Instrument Class list** | | | |
| **Instrument Class** | | **Contract Description** | **Contract Term** |
| HSI\_TMC | |  |  |

Noted: The Instrument Class list will be sorted by alphabetical order.

#### Fields Description

| **Field name** | **Description** | **Position on 3.7.3.1** | **Format** | **Remarks** |
| --- | --- | --- | --- | --- |
| HTML header & report title | The report title | Line 1 – 5 | Refer to the Header field in the report type setup | “HANG SENG INDEX FUTURES AND OPTIONS” or  “HANG SENG CHINA ENTERPRISES INDEX FUTURES AND OPTIONS” or  “MINI-HANG SENG INDEX FUTURES AND OPTIONS” or  “MINI-HANG SENG CHINA ENTERPRISES INDEX FUTURES AND OPTIONS” or  “HANG SENG INDEX FUTURES OPTIONS” or  “HANG SENG CHINA ENTERPRISES INDEX FUTURES OPTIONS” |
| Prev. Trading Day of the Exchange | To show the previous business date T+1 session | Line 13 | DD MMM YYYY, WEEKDAY |  |
| After-Hours Trading Session | Session header | Line 15 | Hardcode in template file for the market. |  |
| **Market Statistic** |  | Line 19 – Line xxx |  |  |
| Row Number | To show the row number of contract |  | N |  |
| General Name | Name of TMC contract |  | TMC\_XXX/NNN | XXX – class code  NNN – TMC code |
| Leg 1 | To show the first leg of contract combination |  | (X N) XXXXXX | (X N) – Bid/Ask and leg ratio  XXXXXX – Normal instruments name of leg  “-“ – when not applicable |
| Leg 2 | To show the second leg of contract combination |  | (X N) XXXXXX | (X N) – Bid/Ask and leg ratio  XXXXXX – Normal instruments name of leg  “-“ – when not applicable |
| Leg 3 | To show the third leg of contract combination |  | (X N) XXXXXX | (X N) – Bid/Ask and leg ratio  XXXXXX – Normal instruments name of leg  “-“ – when not applicable |
| Leg 4 | To show the fourth leg of contract combination |  | (X N) XXXXXX | (X N) – Bid/Ask and leg ratio  XXXXXX – Normal instruments name of leg  “-“ – when not applicable |
| Open Price | To show the first traded price of the instruments |  | Z,ZZZ,ZZ9 or  ZZ,ZZ9.99 or  ZZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Daily High | To show the highest traded price of today |  | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or  ZZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Daily Low | To show the lowest traded price of today |  | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or  ZZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Last | To show the last traded price of today |  | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or  ZZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Volume | To show the number of traded volume of the instruments |  | Z,ZZZ,ZZ9 or  ZZZZZZ9 | NIL – when instruments expired  “0“- when not applicable |
| System Date | To show the business date of the report | Line xxx | DD MMM YYYY, WEEKDAY | Trading Day of the Exchange |
| Day Trading Session | Session header | Line xxx | Hardcode in template file for the market. |  |
| **Market Statistic** |  | Line xxx – xxx |  |  |
| Row Number | To show the row number of contract |  | N |  |
| General Name | Name of TMC contract |  | TMC\_XXX/NNN | XXX – class code  NNN – TMC code |
| Leg 1 | To show the first leg of contract combination |  | (X N) XXXXXX | (X N) – Bid/Ask and leg ratio  XXXXXX – Normal instruments name of leg  “-“ – when not applicable |
| Leg 2 | To show the second leg of contract combination |  | (X N) XXXXXX | (X N) – Bid/Ask and leg ratio  XXXXXX – Normal instruments name of leg  “-“ – when not applicable |
| Leg 3 | To show the third leg of contract combination |  | (X N) XXXXXX | (X N) – Bid/Ask and leg ratio  XXXXXX – Normal instruments name of leg  “-“ – when not applicable |
| Leg 4 | To show the fourth leg of contract combination |  | (X N) XXXXXX | (X N) – Bid/Ask and leg ratio  XXXXXX – Normal instruments name of leg  “-“ – when not applicable |
| Open Price | To show the first traded price of the instruments |  | Z,ZZZ,ZZ9 or  ZZ,ZZ9.99 or  ZZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Daily High | To show the highest traded price of today |  | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or  ZZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Daily Low | To show the lowest traded price of today |  | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or  ZZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Last | To show the last traded price of today |  | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or  ZZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Volume | To show the number of traded volume of the instruments |  | Z,ZZZ,ZZ9 or  ZZZZZZ9 | NIL – when instruments expired  “0“- when not applicable |

### Night Trading Session Reports - Futures with AHT

#FS10017A\_S0030\_01600

#### Report Layout

|  |  |
| --- | --- |
| 1  2  3456789012345678901234567890123456789012345678901234567890123456789012345678901234 | <HTML><HEAD><meta name="MS.LOCALE" content="EN-US"><TITLE> XXXXXXXXXXXXXXXXXXXXXXXXX FUTURES DAILY MARKET REPORT</TITLE>  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">  </HEAD>  <BODY><PRE>  XXXXXXXXXXXXXXXXXXXXXXXXX AFTER-HOURS TRADING ACTIVITY SUMMARY  Hong Kong Exchanges and Clearing Limited and/or its subsidiaries endeavour to ensure the  accuracy and reliability of the information provided, but do not guarantee its accuracy and  reliability and accept no liability (whether in tort or contract or otherwise) for any loss  or damage arising from any inaccuracies or omissions.  Trading Day of the Exchange  DD MMM YYYY, WEEKDAY    XXX - XXXXXXXXXXXXXXXXXXXXXXXXXXXX  Contract Size = xxxxxxxxxx  After-Hours Trading Session  Contract \*Open \*Daily \*Daily \*Close Volume  Month Price High Low Price    MMM-YY ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9  …  MMM-YY ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9    Total ZZZ,ZZ9  XXX - XXXXXXXXXXXXXXXXXXXXXXXXXXXX  Contract Size = xxxxxxxxxx  After-Hours Trading Session  Contract \*Open \*Daily \*Daily \*Close Volume  Month Price High Low Price    MMM-YY ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9  …  MMM-YY ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9    Total ZZZ,ZZ9  …  …  …  All Contracts Total ZZZ,ZZ9  XXX - XXXXXXXXXXXXXXXXXXXXXXXXXXXX  Contract STRATEGY Open Daily Daily Volume  Month Price High Low  MMM-11/MMM-11 Calendar Spread ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9  …  MMM-11/MMM-11 Calendar Spread ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9  Total ZZZ,ZZ9  XXX - XXXXXXXXXXXXXXXXXXXXXXXXXXXX  Contract STRATEGY Open Daily Daily Volume  Month Price High Low  MMM-11/MMM-11 Calendar Spread ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9  …  MMM-11/MMM-11 Calendar Spread ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9  Total ZZZ,ZZ9  …  …  …  All Strategies Total ZZZ,ZZ9  \*\*\* END OF REPORT \*\*\*  \*All Calendar Spread vs. Calendar Spread transactions are excluded  </PRE></BODY></HTML> |
|  | 1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901 |

#### Report Attribute

|  |  |
| --- | --- |
| Purpose | To generate a report showing the market summary of futures indices instruments with After-Hours Trading on T+1 Session |
| Frequency | Refer to the operation flow |
| Sequence | Contract year and month |
| Page Size | 91 columns |
| File Name | <Report Name>FA<yymmdd>.htm |
| Chinese Version | Please refer to Appendix B |

#### Report Type Setup

It inherits from the Report Type Setup in Futures with AHT [3.7.1.3]. A report for After Hour Trading statistic will be generated when a Report Name has been defined.

#### Fields Description

| **Field name** | **Description** | **Position on 3.7.4.1** | **Format** | **Remarks** |
| --- | --- | --- | --- | --- |
| HTML header & report title | The report title | Line 1 – 5 | Refer to the Header field in the report type setup | e.g. “CNH London Metal Mini Futures” |
| System Date | To show the business date of the report | Line 12 | DD MMM YYYY, WEEKDAY | Trading Day of the Exchange |
| Contract Description | Specified in the corresponding Report Name’s Instrument Class. | Line 15, xxx |  | e.g. “LRA – CNH London Aluminium Mini Futures RMB5 per minimum fluctuation  or blank if not defined. |
| Contract term | contract size of product | Line xxx |  | e.g. “Contract Size = 5 tonnes”  or blank if not defined. |
| **Market Statistic** |  | Line 24 – xxx |  |  |
| Contract Month | To show the contract year and month of the instruments. |  | MMM-YY  where MMM = JAN .. DEC and  YY = the last two digits of the contract year |  |
| After-Hours Trading Session |  |  |  |  |
| Open Price | To show the first traded price of the instruments |  | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or  ZZZ9.99 | Display “EXPIRED” from Open Price field to Volume field for any expired instruments of the month. |
| Daily High | To show the highest traded price of today |  | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or  ZZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Daily Low | To show the lowest traded price of today |  | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or  ZZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Close Price | To show the last traded price of today |  | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or  ZZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Volume | To show the number of traded volume of the instruments |  | Z,ZZZ,ZZ9 or  ZZZZZZ9 | NIL – when instruments expired  “0“- when not applicable |
| **Total** |  | Line xxx |  |  |
| Volume | To show the number of traded volume of instruments |  | Z,ZZZ,ZZ9 or  ZZZZZZ9 |  |
| **All Contracts Total** |  | Line xxx |  |  |
| Volume | To show the number of traded volume of all instruments |  | Z,ZZZ,ZZ9 or  ZZZZZZ9 |  |
| **Strategies Declaration** |  |  |  |  |
| Market ID and Contract price per index point | The short name for the market, and the price of contract per index point. | Line xxx |  | e.g. “LRA - CNH London Aluminium Mini Futures”  as configured in MIX underlying control table |
| **Strategies** |  | Lines xxx |  |  |
| Calendar spread Month | To show the calendar spread months |  | MMM-YY / MMM-YY | where MMM = JAN .. DEC and  YY = the last two digits of the contract year |
| Strategy type | Strategy description |  | Alphanumeric |  |
| Open Price | To show the first traded price of the instruments |  | Z,ZZZ,ZZ9 or  ZZ,ZZ9.99 or  ZZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Daily High | To show the highest traded price of today |  | Z,ZZZ,ZZ9 or  ZZ,ZZ9.99 or  ZZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Daily Low | To show the lowest traded price of today |  | Z,ZZZ,ZZ9 or  ZZ,ZZ9.99 or  ZZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Volume | To show the number of traded volume of the instruments |  | Z,ZZZ,ZZ9 or  ZZZZZ9 | NIL – when instruments expired  “0“- when not applicable |
| **Total** |  | Line xxx |  |  |
| Volume | To show the number of traded volume of all instruments |  | Z,ZZZ,ZZ9 or  ZZZZZ9 |  |
| **All Strategy Total** |  | Line xxx |  |  |
| Volume | To show the number of traded volume of all instruments in all contract months |  | Z,ZZZ,ZZ9 or  ZZZZZ9 |  |

### Night Trading Session Reports –Indices Options with AHT

#FS10017A\_S0030\_01700

#### Report Layout

|  |  |
| --- | --- |
| 1  2  3456789012345678901234567890123456789012 | <HTML><HEAD><meta name="MS.LOCALE" content="EN-US"><TITLE> XXXXXXXXXXXXXXXXXXXXXXXXX OPTIONS DAILY MARKET REPORT</TITLE>  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">  </HEAD>  <BODY><PRE>  XXXXXXXXXXXXXXXXXXXXXXXXX AFTER-HOURS TRADING ACTIVITY SUMMARY  Hong Kong Exchanges and Clearing Limited and/or its subsidiaries endeavour to ensure the  accuracy and reliability of the information provided, but do not guarantee its accuracy and  reliability and accept no liability (whether in tort or contract or otherwise) for any loss  or damage arising from any inaccuracies or omissions.  XXXXXXXXXXXXXXXXXXXXXXXXX Options XXXXXX per point    Trading Day of the Exchange  DD MMM YYYY, WEEKDAY  After-Hours Trading Session    <A NAME="month1"></A>  CONTRACT STRIKE \*OPENING \*DAILY \*DAILY CLOSE VOLUME  MONTH PRICE PRICE HIGH LOW PRICE  MMM-YY ZZZZZ9 C ZZZZZZZ9 ZZZZZZ9 ZZZZZZ9 ZZZZZZ9 ZZZZZZ9  …  MMM-YY ZZZZZ9 C ZZZZZZZ9 ZZZZZZ9 ZZZZZZ9 ZZZZZZ9 ZZZZZZ9    TOTAL CALL ZZZZZZ9  CONTRACT STRIKE \*OPENING \*DAILY \*DAILY CLOSE VOLUME  MONTH PRICE PRICE HIGH LOW PRICE  MMM-YY ZZZZZ9 C ZZZZZZZ9 ZZZZZZ9 ZZZZZZ9 ZZZZZZ9 ZZZZZZ9  …  MMM-YY ZZZZZ9 C ZZZZZZZ9 ZZZZZZ9 ZZZZZZ9 ZZZZZZ9 ZZZZZZ9    TOTAL PUT ZZZZZZ9  MARKET TOTAL ZZZZZZ9  \*\*\* END OF REPORT \*\*\*  \*ALL COMBO VS. COMBO TRANSACTIONS ARE EXCLUDED  </PRE></BODY></HTML> |
|  | 1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901 |

#### Report Attribute

|  |  |
| --- | --- |
| Purpose | To generate a report showing the market summary of options indices instruments with After-Hours Trading on T+1 Session |
| Frequency | Refer to the operation flow |
| Sequence | Contract year and month |
| Page Size | 91 columns |
| File Name | <Report Name>OA<yymmdd>.htm |
| Chinese Version | Please refer to Appendix B |

#### Report Type Setup

It inherits from the Report Type Setup in Options with AHT [3.7.2.3]. A report for After Hour Trading statistic will be generated when a Report Name has been defined.

#### Fields Description

| **Field name** | **Description** | **Position on 3.7.5.1** | **Format** | **Remarks** |
| --- | --- | --- | --- | --- |
| HTML header & report title | The report title | Line 1 – 11 | Refer to the Header field in the report type setup | "HANG SENG INDEX " or  “MINI-HANG SENG INDEX " or  “HANG SENG CHINA ENTERPRISES INDEX " or“MINI-HANG SENG CHINA ENTERPRISES INDEX” Or  “HANG SENG TECH INDEX “ or  “HANG SENG INDEX FUTURES “ or  “HANG SENG CHINA ENTERPRISES INDEX FUTURES " |
| Contract Description | Specified in the corresponding Report Name’s Instrument Class. | Line 15, xxx |  | "HANG SENG INDEX OPTIONS HK$ 50 PER POINT" or  "MINI-HANG SENG INDEX OPTIONS HK$ 10 PER POINT" or  "HANG SENG CHINA ENTERPRISES INDEX OPTIONS HK$ 50 PER POINT" or  “MINI-HANG SENG CHINA ENTERPRISES INDEX OPTIONS HK$ 10 PER POINT” Or  “HANG SENG TECH INDEX OPTIONS HK$ 50 PER POINT” or  “HANG SENG INDEX FUTURES OPTIONS HK$ 50 PER POINT “ or  “HANG SENG CHINA ENTERPRISES INDEX FUTURES OPTIONS HK$ 50 PER POINT " |
| System Date | To show the creation date of the report | Line 14 – 15 | DD MMM YYYY, WEEKDAY | Trading Day of the Exchange |
| After-Hours Trading Session | Session header | Line 17 | Hardcode in template file for the market. |  |
| **Market Statistic** |  | Line 20– Line xxx |  |  |
| Contract Month / Week | To show the contract expiration month or date of the Instrument according to the Expiration Frequency |  | MMM-YY for Expiration Frequency = Monthly  DD-MMM-YY for Expiry Frequency = Weekly  where  DD = day of month  MMM = JAN .. DEC and  YY = the last two digits of the contract year |  |
| After-Hours Trading Session |  |  |  |  |
| Open Price | To show the first traded price of the instruments on T+1 session |  | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZZZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or  ZZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Daily High | To show the highest traded price on T+1 session |  | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZZZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or  ZZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Daily Low | To show the lowest traded price on T+1 session |  | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZZZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or  ZZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Close Price | To show the last traded price on T+1 session |  | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZZZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or  ZZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Volume | To show the number of traded volume of the instruments on T+1 session |  | Z,ZZZ,ZZ9 or  ZZZZZZ9 | “0“- when not applicable |
| **Contracts Total (CALL/PUT)** |  | Line xxx |  |  |
| Volume | To show the number of traded volume of all instruments |  | Z,ZZZ,ZZ9 or  ZZZZZZ9 |  |
| **Market Total** |  | Line xxx |  |  |
| Volume | To show the number of traded volume of all instruments |  | Z,ZZZ,ZZ9 or  ZZZZZZ9 |  |

### Night Trading Session Reports - Tailor-made Combination with AHT

#FS10017A\_S0030\_01800

#### Report Layout

|  |  |
| --- | --- |
| 1  2  3456789012345678901234567 | <HTML><HEAD><meta name="MS.LOCALE" content="EN-US"><TITLE> XXXXXXXXXXXXXXXXXXXXXXXXX TAILOR-MADE COMBINATION DAILY MARKET REPORT</TITLE>  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">  </HEAD>  <BODY><PRE>  XXXXXXXXXXXXXXXXXXXXXXXXX TAILOR-MADE COMBINATION DAILY MARKET REPORT  Hong Kong Exchanges and Clearing Limited and/or its subsidiaries endeavour to ensure the  accuracy and reliability of the information provided, but do not guarantee its accuracy and  reliability and accept no liability (whether in tort or contract or otherwise) for any loss  or damage arising from any inaccuracies or omissions.  Trading Day of the Exchange  DD MMM YYYY, WEEKDAY    After-Hours Trading Session  General Name Leg 1 Leg 2 Leg 3 Leg 4 Open Price Daily High Daily Low Last Volume    1 TMC\_XXX/NNN (X N) XXXXXXXXXX (X N) XXXXXXXXXX (X N) XXXXXXXXXX (X N) XXXXXXXXXX ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9  2 TMC\_XXX/NNN (X N) XXXXXXXXXX (X N) XXXXXXXXXX (X N) XXXXXXXXXX (X N) XXXXXXXXXX ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9  …  N TMC\_XXX/NNN (X N) XXXXXXXXXX (X N) XXXXXXXXXX (X N) XXXXXXXXXX (X N) XXXXXXXXXX ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9  \*\*\* END OF REPORT \*\*\*  </PRE></BODY></HTML> |
|  | 12345678901234567890123456789012345678901234567890123456789012345678901234567890123456789011234567890123456789012345678901234567890123456789012345678901234567890 |

#### Report Attribute

|  |  |
| --- | --- |
| Purpose | To generate a report showing the market summary of futures and options tailor-made combination instruments with After-Hours Trading on T+1 Session |
| Frequency | Refer to the operation flow |
| Sequence | Contract year and month |
| Page Size | 160 columns |
| File Name | <Report Name>TMCA<yymmdd>.htm |
| Chinese Version | Please refer to Appendix B |

#### Report Type Setup

It inherits from the Report Type Setup in TMC with AHT [3.7.3.3]. A report for After Hour Trading statistic will be generated when a Report Name has been defined.

#### Fields Description

| **Field name** | **Description** | **Position on 3.7.6.1** | **Format** | **Remarks** |
| --- | --- | --- | --- | --- |
| HTML header & report title | The report title | Line 1 – 5 | Refer to the Header field in the report type setup | “HANG SENG INDEX FUTURES AND OPTIONS” or  “HANG SENG CHINA ENTERPRISES INDEX FUTURES AND OPTIONS” or  “MINI-HANG SENG INDEX FUTURES AND OPTIONS” or  “MINI-HANG SENG CHINA ENTERPRISES INDEX FUTURES AND OPTIONS” or  “HANG SENG INDEX FUTURES OPTIONS” or  “HANG SENG CHINA ENTERPRISES INDEX FUTURES OPTIONS” |
| System Date | To show the business date T+1 session | Line 13 | DD MMM YYYY, WEEKDAY | Trading Day of the Exchange |
| After-Hours Trading Session | Session header | Line 15 | Hardcode in template file for the market. |  |
| **Market Statistic** |  | Line 19 – Line xxx |  |  |
| Row Number | To show the row number of contract |  | N |  |
| General Name | Name of TMC contract |  | TMC\_XXX/NNN | XXX – class code  NNN – TMC code |
| Leg 1 | To show the first leg of contract combination |  | (X N) XXXXXX | (X N) – Bid/Ask and leg ratio  XXXXXX – Normal instruments name of leg  “-“ – when not applicable |
| Leg 2 | To show the second leg of contract combination |  | (X N) XXXXXX | (X N) – Bid/Ask and leg ratio  XXXXXX – Normal instruments name of leg  “-“ – when not applicable |
| Leg 3 | To show the third leg of contract combination |  | (X N) XXXXXX | (X N) – Bid/Ask and leg ratio  XXXXXX – Normal instruments name of leg  “-“ – when not applicable |
| Leg 4 | To show the fourth leg of contract combination |  | (X N) XXXXXX | (X N) – Bid/Ask and leg ratio  XXXXXX – Normal instruments name of leg  “-“ – when not applicable |
| Open Price | To show the first traded price of the instruments |  | Z,ZZZ,ZZ9 or  ZZ,ZZ9.99 or  ZZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Daily High | To show the highest traded price of today |  | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or  ZZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Daily Low | To show the lowest traded price of today |  | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or  ZZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Last | To show the last traded price of today |  | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or  ZZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Volume | To show the number of traded volume of the instruments |  | Z,ZZZ,ZZ9 or  ZZZZZZ9 | NIL – when instruments expired  “0“- when not applicable |

### **Report Types for products with Regular-Hours Trading Session Only**

### Stock Futures

#FS10017A\_S0030\_01900

#### Report Layout

|  |  |
| --- | --- |
| 1  2  3456789012345678901234567 | <HTML><HEAD>  <TITLE>STOCK FUTURES DAILY MARKET REPORT</TITLE></HEAD><BODY><PRE>  HONG KONG STOCK FUTURES DAILY MARKET REPORT    Hong Kong Exchanges and Clearing Limited and/or its subsidiaries endeavour to ensure the  accuracy and reliability of the information provided, but do not guarantee its accuracy and  reliability and accept no liability (whether in tort or contract or otherwise) for any loss  or damage arising from any inaccuracies or omissions.    Trading Day of the Exchange Prev. Trading Day of the Exchange  DD MMM YYYY, WEEKDAY DD MMM YYYY,  WEEKDAY    Contract \*Opening \*Daily \*Daily Settlement Change in Volume Open Change in  Month Price High Low Price Settlement Interest OI  Price  ALC - ALUMINUM CORPORATION OF CHINA LTD. FUTURES - CONTRACT MULTIPLIER 2,000  JAN-06 - - - 5.84 -0.14 0 0 0  FEB-06 - - - 5.86 -0.14 0 0 0  MAR-06 - - - 5.88 -0.14 0 0 0  JUN-06 - - - 5.78 -0.14 0 0 0  SEP-06 - - - 5.84 -0.14 0 0 0  XXX – XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX  MMM-YY ZZZZZ9.99 ZZZZZ9.99 ZZZZZ9.99 ZZZZZ9.99 ±ZZZZZ9.99 ZZZZZZ9 ZZZZZZ9 ±ZZZZZZ9  :  MMM-YY ZZZZZ9.99 ZZZZZ9.99 ZZZZZ9.99 ZZZZZ9.99 ±ZZZZZ9.99 ZZZZZZ9 ZZZZZZ9 ±ZZZZZZ9    :  : (List all contracts of each Stock Futures Class in alphabetical order)  :    All Contracts Total ZZZZZZ9 ZZZZZZ9 ±ZZZZZZ9  class Contract STRATEGY Open Daily Daily Volume  Month Price High Low  ALC MMM-YY/MMM-YY Calendar Spread ZZZZZ9.99 ZZZZZ9.99 ZZZZZ9.99 ZZZZZZ9  .  .  ZJM MMM-YY/MMM-YY Calendar Spread ZZZZZ9.99 ZZZZZ9.99 ZZZZZ9.99 ZZZZZZ9  All Strategies Total ZZZZZZ9    \*\*\* END OF REPORT \*\*\*    \*All Calendar Spread vs. Calendar Spread transactions are excluded  </PRE></BODY></HTML> |
|  | 12345678901234567890123456789012345678901234567890123456789012345678901234567890123456789011234567890123456 |

#### Report Attribute

|  |  |
| --- | --- |
| Purpose | To generate a report showing the market summary of future instruments |
| Frequency | Refer to the operation flow |
| Sequence | Contract year and month and futures contract id. |
| Page Size | 106 columns |
| File Name | <Report Name>SF<yymmdd>.htm |
| Chinese Version | Please refer to Appendix B |

#### Report Type Setup

To assign the Stock Futures instruments printed in the report, it is required to create a record in the report type. The reports will be generated per Report Name. Each Report Name requires users to define the corresponding list of Instrument Class. The report generator would locate all contracts and Standard Combo under per assigned Instrument Class. Users are required to define the Report Header for the Report Name. The Contract Description, Contract Term for each instrument class printed in the report. The contracts will be grouped per instrument class and printed in Instrument class’s alphabetical order.

The report type setup fields are as below:

|  |  |
| --- | --- |
| **Report Type** | **Report for Stock Futures** |
| **Report Name** | Specify the ID for the report. |
| **Instrument Class** | Assign the corresponding Instrument Class to locate the corresponding contracts printed in the report |
| **Underlying** | Not applicable for this report type |
| **Header** | Specify the header of the report |
| **Contract Description** | Specify the Contract description |
| **Contract Term** | Specify the Contract price per index point |
| **Keep Day for spot month** | Specify the number of days to show ‘EXPIRED’ for the spot month Futures Instruments after the Last Trading Date. The ‘EXPIRED’ row will display the updated Open Interest information, with the figure gradually reducing to zero for expired instruments.  0 means there is no need to show ‘EXPIRED’  1 means to show ‘EXPIRED’ for 1 day after the Last Trading Date  2 means to show ‘EXPIRED’ for 2 days after the Last Trading Date  Maximum value = 5 |

Sample for Stock Futures

|  |  |  |
| --- | --- | --- |
| **Report for Futures** | | |
| **Report Name** | STOCK | |
| **Header** | Stock Futures | |
| **Instrument Class list** | | |
| **Instrument Class** | **Contract Description** | **Contract Term** |
| A50FUT | A50 - ISHARES FTSE A50 CHINA INDEX ETF FUTURES | CONTRACT MULTIPLIER 5,000 |
| AACFUT | AAC - AAC TECHNOLOGIES HOLDINGS INC. FUTURES | CONTRACT MULTIPLIER 1,000 |
| ABCFUT | ABC - AGRICULTURAL BANK OF CHINA LTD. FUTURES | CONTRACT MULTIPLIER 10,000 |
| ACCFUT | ACC - ANHUI CONCH CEMENT CO. LTD. FUTURES | CONTRACT MULTIPLIER 500 |
| AIAFUT | AIA - AIA GROUP LTD. FUTURES | CONTRACT MULTIPLIER 1,000 |
| ALBFUT | ALB - ALIBABA GROUP HOLDING LIMITED FUTURES | CONTRACT MULTIPLIER 500 |

Noted: The Instrument Class list will be sorted by alphabetical order.

#### Fields Description

| **Field name** | **Description** | **Position on 3.7.7.1** | **Format** | **Remarks** |
| --- | --- | --- | --- | --- |
| HTML header & report title | The report title | Line 1 – 3 | Refer to the Header field in the report type setup | “STOCK FUTURES DAILY MARKET REPORT” |
| System Date | To show the creation date of the report | Line 11– 12 | DD MMM YYYY, WEEKDAY | Trading Day of the Exchange |
| Prev. Trading Day of the Exchange | To show the date of previous business day | Line 11 – 13 | DD MMM YYYY, WEEKDAY | This field will not be available if the “Open Interest” and “Change in OI” is representing the data in same business day |
| **Market Statistic** |  | Line 18 - 23 |  |  |
| **Contract Description & Contract Term** | Specified in the corresponding Report Name’s Instrument Class. |  |  | Ex. “ABC - AGRICULTURAL BANK OF CHINA LTD. FUTURES - CONTRACT MULTIPLIER 10,000  ” |
| Contract Month | To show the contract year and month of the instruments. |  | MMM-YY  where MMM = JAN .. DEC and  YY = the last two digits of the contract year |  |
| Opening Price | To show the first traded price of the instruments |  | ZZZZZ9.99 | “0.00“ when not applicable |
| Daily High | To show the highest traded price of today |  | ZZZZZ9.99 | “0.00“ when not applicable |
| Daily Low | To show the lowest traded price of today |  | ZZZZZ9.99 | “0.00“ when not applicable |
| Settlement Price | To show the settlement price of the instruments |  | ZZZZZ9.99 |  |
| Change in Settlement Price | To show the change of settlement price from that of previous business day |  | ±ZZZZZ9.99 | “-“ when not applicable / flag set in CA Arrangement in MIX GUI |
| Volume | To show the number of traded volume of the instruments |  | ZZZZZZ9 | “0“ when not applicable |
| Open Interest | To show the open interest of previous business day |  | ZZZZZZ9 | “-“ when not applicable |
| Change in OI | To show the change of open interest in the two previous business days |  | ±ZZZZZZ9 | “-“ when not applicable / flag set in CA Arrangement in MIX GUI |
| **Contracts Total** |  | Line 34 |  |  |
| Volume | To show the number of traded volume of all instruments |  | ZZZZZZ9 |  |
| Open Interest | To show the open interest of all instruments in the previous business day |  | ZZZZZZ9 |  |
| Change in OI | To show the change of open interest of all instruments in the two previous business days |  | ±ZZZZZZ9 |  |
| **Strategies Declaration** |  | Lines 37 - 45 |  |  |
| **Strategies** |  | Lines 40 – 43 |  |  |
| Class code | The class code of the commodity |  | Alphanumeric |  |
| Calendar spread Month | To show the calendar spread months |  | MMM-YY / MMM-YY | where MMM = JAN .. DEC and  YY = the last two digits of the contract year |
| Strategy type | Strategy description |  | Alphanumeric |  |
| Open Price | To show the first traded price of the instruments |  | ZZZZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Daily High | To show the highest traded price of today |  | ZZZZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Daily Low | To show the lowest traded price of today |  | ZZZZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Volume | To show the number of traded volume of the instruments |  | ZZZZZZ9 | NIL – when instruments expired  “0“- when not applicable |
| **All Strategy Total** |  | Line 45 |  |  |
| Volume | To show the number of traded volume of all instruments in all contract months |  | ZZZZZZ9 |  |

### Indices Futures for Indices, Hibor, T-Bond, Dividend and Commodity

#FS10017A\_S0030\_01950

#### Report Layout

|  |  |
| --- | --- |
| 1  2  3456789012345678901234567 | <HTML><HEAD><TITLE>XXXXXXXXXXXXXXXXXXXXXXXXX INDEX FUTURES DAILY MARKET REPORT</TITLE></HEAD>  <BODY><PRE>  XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX FUTURES DAILY MARKET REPORT  Hong Kong Exchanges and Clearing Limited and/or its subsidiaries endeavour to ensure the  accuracy and reliability of the information provided, but do not guarantee its accuracy and  reliability and accept no liability (whether in tort or contract or otherwise) for any loss  or damage arising from any inaccuracies or omissions.  Trading Day of the Exchange Prev. Trading Day of the Exchange  DD MMM YYYY, WEEKDAY DD MMM YYYY,  WEEKDAY  XXX - XXXXXXXXXXXXXXXXXXXXXXXXXXXX PER INDEX POINT  Contract \*Open \*Daily \*Daily Settle- Chg in\*Contract\*Contract Volume Open Change in  Month Price High Low ment Setl High Low Interest OI  Price Price    MMM-YY E X P I R E D Z,ZZZ,ZZ9 ±Z,ZZZ,ZZ9  MMM-YY NNNNNNN NNNNNNN NNNNNNN NNNNNNN ±NNNNNNN NNNNNNN NNNNNNN Z,ZZZ,ZZ9 Z,ZZZ,ZZ9 ±Z,ZZZ,ZZ9 MMM-YY NNNNNNN NNNNNNN NNNNNNN NNNNNNN ±NNNNNNN NNNNNNN NNNNNNN Z,ZZZ,ZZ9 Z,ZZZ,ZZ9 ±Z,ZZZ,ZZ9 MMM-YY NNNNNNN NNNNNNN NNNNNNN NNNNNNN ±NNNNNNN NNNNNNN NNNNNNN Z,ZZZ,ZZ9 Z,ZZZ,ZZ9 ±Z,ZZZ,ZZ9 MMM-YY NNNNNNN NNNNNNN NNNNNNN NNNNNNN ±NNNNNNN NNNNNNN NNNNNNN Z,ZZZ,ZZ9 Z,ZZZ,ZZ9 ±Z,ZZZ,ZZ9  All Contracts Total Z,ZZZ,ZZ9 Z,ZZZ,ZZ9 ±Z,ZZZ,ZZ9  Contract STRATEGY Open Daily Daily Volume  Month Price High Low  MMM-11/MMM-11 Calendar Spread NNNNNNNNN NNNNNNNNNN NNNNNNNNNN NNNNNNNNN  …  MMM-11/MMM-11 Calendar Spread ZZZ9.99 ZZZ9.99 ZZZ9.99 ZZZZZ9  All Strategies Total ZZZZZ9  \*\*\* END OF REPORT \*\*\*  \*All Calendar Spread vs. Calendar Spread transactions are excluded  </PRE></BODY></HTML> |
|  | 12345678901234567890123456789012345678901234567890123456789012345678901234567890123456789011234567890123456789 |

#### Report Attribute

|  |  |
| --- | --- |
| Purpose | To generate a report showing the market summary of futures indices instruments |
| Frequency | Refer to the operation flow |
| Sequence | Contract year and month |
| Page Size | 109 columns |
| File Name | < Report Name >IF<yymmdd>.htm |
| Chinese Version | Please refer to Appendix B |

#### Report Type Setup

To assign the Futures instrument for Hibor, T-Bond, Dividend Futures printed in the report, it is required to create a record in the report type. The reports will be generated per Report Name. Each Report Name requires users to define the corresponding list of Instrument Class. The report generator would locate all contracts and Standard Combo under per assigned Instrument Class. Users are required to define the Report Header for the Report Name. The Contract Description, Contract Term for each instrument class printed in the report. The contracts will be grouped per instrument class and printed in Instrument class’s alphabetical order.

The report type setup fields are as below:

|  |  |
| --- | --- |
| **Report Type** | **Report for Indices Futures for Indices, Hibo, T-Bond, Dividend and Commodity** |
| **Report Name** | Specify the ID for the report. |
| **Instrument Class** | Assign the corresponding Instrument Class to locate the corresponding contracts printed in the report |
| **Underlying** | Not applicable for this report type |
| **Header** | Specify the header of the report |
| **Contract Description** | Specify the Contract description |
| **Contract Term** | Specify the Contract price per index point |
| **Keep Day for spot month** | Specify the number of days to show ‘EXPIRED’ for the spot month Futures Instruments after the Last Trading Date. The ‘EXPIRED’ row will display the updated Open Interest information, with the figure gradually reducing to zero for expired instruments.  0 means there is no need to show ‘EXPIRED’  1 means to show ‘EXPIRED’ for 1 day after the Last Trading Date  2 means to show ‘EXPIRED’ for 2 days after the Last Trading Date  Maximum value = 5 |

Sample for HIBOR Futures:

|  |  |  |
| --- | --- | --- |
| **Report for Futures** | | |
| **Report Name** | HIBOR | |
| **Header** | HIBOR Futures | |
| **Instrument Class list** | | |
| **Instrument Class** | **Contract Description** | **Contract Term** |
| HB1FUT | HB1 - One-Month HIBOR Futures HK$125 per basis point | Contract Size = HK$15,000,000 |
| HB3FUT | HB3 - Three-Month HIBOR Futures HK$125 per basis point | Contract Size = HK$5,000,000 |

Noted: The Instrument Class list will be sorted by alphabetical order.

#### Fields Description

| **Field name** | **Description** | **Position on 3.7.8.1** | **Format** | **Remarks** |
| --- | --- | --- | --- | --- |
| HTML header & report title | The report title | Line 1 – 3 | Hardcode in template file for the market. | “HSI VOLATILITY INDEX (VHSI)” or  “IBOVESPA INDEX” or  “MICEX INDEX” or  “FTSE/JSE Top40” or  “CES CHINA 120 INDEX” |
| System Date | To show the creation date of the report | Line 11 - 12 | DD MMM YYYY, WEEKDAY | Trading Day of the Exchange |
| Prev. Trading Day of the Exchange | To show the date of previous business day | Line 10 – 12 | DD MMM YYYY, WEEKDAY | This field will not be available if the “Open Interest” and “Change in OI” is representing the data in same business day |
| Contract Description | Specified in the corresponding Report Name’s Instrument Class. | Line 14, xxx |  |  |
| **Market Statistic** |  | Line 20 – 24 |  |  |
| Contract Month | To show the contract year and month of the instruments. |  | MMM-YY  where MMM = JAN .. DEC and  YY = the last two digits of the contract year |  |
| Open Price | To show the first traded price of the instruments |  | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or  ZZZ9.99 or  ZZZZ9.9 | Display “EXPIRED” from Open Price field to Volume field for any expired instruments of the month. |
| Daily High | To show the highest traded price of today |  | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or  ZZZ9.99 or  ZZZZ9.9 | NIL – when instruments expired  “0“- when not applicable |
| Daily Low | To show the lowest traded price of today |  | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or  ZZZ9.99 or  ZZZZ9.9 | NIL – when instruments expired  “0“- when not applicable |
| Settlement Price | To show the settlement price of the instruments |  | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or  ZZZ9.99 or  ZZZZ9.9 | NIL – when instruments expired  “0“- when not applicable |
| Chg in Setl Price | To show the change of settlement price from that of previous business day |  | ±Z,ZZZ,ZZ9 or  ±ZZZ,ZZ9 or  ±ZZ,ZZ9.99 or  ±Z,ZZ9.99 or  ±ZZZ9.99 or  ±ZZZZ9.9 | NIL – when instruments expired  “-“- when not applicable |
| Contract High | To show the highest price of the contract |  | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or  ZZZ9.99 or  ZZZZ9.9 | NIL – when instruments expired  “0“- when not applicable |
| Contract Low | To show the Lowest price of the contract |  | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or  ZZZ9.99 or  ZZZZ9.9 | NIL – when instruments expired  “0“- when not applicable |
| Volume | To show the number of traded volume of the instruments |  | Z,ZZZ,ZZ9 or  ZZZZZZ9 | NIL – when instruments expired  “0“- when not applicable |
| Open Interest | To show the open interest of previous business day |  | Z,ZZZ,ZZ9 or  ZZZZZZ9 | “-“- when not applicable |
| Change in OI | To show the change of open interest in the two previous business days |  | ±Z,ZZZ,ZZ9 or  ±ZZZZZZ9 | “-“- when not applicable |
| **All Contracts Total** |  | Line 26 |  |  |
| Volume | To show the number of traded volume of all instruments |  | Z,ZZZ,ZZ9 or  ZZZZZZ9 |  |
| Open Interest | To show the open interest of all instruments in the previous business day |  | Z,ZZZ,ZZ9 or  ZZZZZZ9 |  |
| Change in OI | To show the change of open interest of all instruments in the two previous business days |  | ±Z,ZZZ,ZZ9 or  ±ZZZZZZ9 |  |
| **Strategies Declaration** |  | Lines 32 - 36 |  |  |
| **Strategies** |  | Lines 32 – 34 |  |  |
| Calendar spread Month | To show the calendar spread months |  | MMM-YY / MMM-YY | where MMM = JAN .. DEC and  YY = the last two digits of the contract year |
| Strategy type | Strategy description |  | Alphanumeric |  |
| Open Price | To show the first traded price of the instruments |  | Z,ZZZ,ZZ9 or  ZZ,ZZ9.99 or  ZZZ9.99 or  ZZZZ9.9 | NIL – when instruments expired  “0“- when not applicable |
| Daily High | To show the highest traded price of today |  | Z,ZZZ,ZZ9 or  ZZ,ZZ9.99 or  ZZZ9.99 or  ZZZZ9.9 | NIL – when instruments expired  “0“- when not applicable |
| Daily Low | To show the lowest traded price of today |  | Z,ZZZ,ZZ9 or  ZZ,ZZ9.99 or  ZZZ9.99 or  ZZZZ9.9 | NIL – when instruments expired  “0“- when not applicable |
| Volume | To show the number of traded volume of the instruments |  | Z,ZZZ,ZZ9 or  ZZZZZ9 | NIL – when instruments expired  “0“- when not applicable |
| **All Strategy Total** |  | Line 36 |  |  |
| Volume | To show the number of traded volume of all instruments in all contract months |  | Z,ZZZ,ZZ9 or  ZZZZZ9 |  |

### Stock Options

#FS10017A\_S0030\_02000

#### Report Layout

|  |  |
| --- | --- |
| 1  2  34567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012 | <html><head>  <title>Daily Market Report</title></head><body><pre>  <TABLE WIDTH="75%" BORDER="2">  <TR>  <TD><A HREF="#SUMMARY">SUMMARY</a></TD>  <TD><A HREF="#ALC">ALC</A></TD>  <TD><A HREF="#BCM">BCM</A></TD>  <TD><A HREF="#BEA">BEA</A></TD>  <TD><A HREF="#BOC">BOC</A></TD>  <TD><A HREF="#CCB">CCB</A></TD>  </TR>  .  .  .  <TR>  <TD><A HREF="#TRF">TRF</a></TD>  <TD><A HREF="#WHL">WHL</a></TD>  <TD>&nbsp;</TD>  <TD>&nbsp;</TD>  <TD>&nbsp;</TD>  <TD>&nbsp;</TD>  </TABLE>  <A NAME="SUMMARY">  Hong Kong Exchanges and Clearing Limited and/or its subsidiaries endeavour to ensure the  accuracy and reliability of the information provided, but do not guarantee its accuracy and  reliability and accept no liability (whether in tort or contract or otherwise) for any loss  or damage arising from any inaccuracies or omissions.    STOCK OPTIONS DAILY MARKET REPORT AS AT DD MMM YYYY  HKATS UNDERLYING SUMMARY TRADING VOLUME SUMMARY OPEN INTEREST IV%  CODE STOCK TOTAL CALLS PUTS TOTAL CALLS PUTS \*  BEA BANK OF EAST ASIA (00023) Z,ZZZ,ZZ9 Z,ZZZ,ZZ9 Z,ZZZ,ZZ9 ZZ,ZZZ,ZZ9 ZZ,ZZZ,ZZ9 ZZ,ZZZ,ZZ9 ZZ9  XXX XXXXXXXXXXXXXXXXXXXXXXX (99999) Z,ZZZ,ZZ9 Z,ZZZ,ZZ9 Z,ZZZ,ZZ9 ZZ,ZZZ,ZZ9 ZZ,ZZZ,ZZ9 ZZ,ZZZ,ZZ9 ZZ9  :  :  WHL THE WHARF (HLDGS) LTD (00004) Z,ZZZ,ZZ9 Z,ZZZ,ZZ9 Z,ZZZ,ZZ9 ZZ,ZZZ,ZZ9 ZZ,ZZZ,ZZ9 ZZ,ZZZ,ZZ9 ZZ9  TOTAL Z,ZZZ,ZZ9 Z,ZZZ,ZZ9 Z,ZZZ,ZZ9 ZZ,ZZZ,ZZ9 ZZ,ZZZ,ZZ9 ZZ,ZZZ,ZZ9  SETTLE- % CHG IN  SETTLE- OPEN MENT SETTLE-  TOP 10 TRADED (BY VOLUME) VOLUME MENT IV% HIGH LOW INTEREST PRICE MENT  PRICE CHANGE\*\* PRICE  X XXX DDMMMYY Z,ZZ9.99 Z,ZZZ,ZZ9 Z,ZZ9.99 ZZ9 Z,ZZ9.99 Z,ZZ9.99 ZZ,ZZZ,ZZ9 ±Z,ZZ9.99 ±Z,ZZ9.99  :  *(Top 2ND – 10TH instruments by traded volume)*  :  TOP 5 UP (BY % CHANGE IN SETTLEMENT PRICE)  X XXX DDMMMYY Z,ZZ9.99 Z,ZZZ,ZZ9 Z,ZZ9.99 ZZ9 Z,ZZ9.99 Z,ZZ9.99 ZZ,ZZZ,ZZ9 ±Z,ZZ9.99 ±Z,ZZ9.99  :  *(Top 2ND - 5TH instruments up by % change in settlement price)*  :  TOP 5 DOWN (BY % CHANGE IN SETTLEMENT PRICE)  X XXX DDMMMYY Z,ZZ9.99 Z,ZZZ,ZZ9 Z,ZZ9.99 ZZ9 Z,ZZ9.99 Z,ZZ9.99 ZZ,ZZZ,ZZ9 ±Z,ZZ9.99 ±Z,ZZ9.99  :  *(Top 2ND - 5TH instruments down by % change in settlement price)*  :  \* THE IMPLIED VOLATILITIES FOR AT THE MONEY CALL AND PUT INSTRUMENTS FOR THE SPOT  MONTH  \*\* SETTLEMENT PRICE CHANGE FROM SETTLEMENT PRICE OF THE PREVIOUS TRADING DAY  ('N/A' IF PREVIOUS PRICE IS NOT AVAILABLE)  <A NAME="BEA">  CONTRACT OPENING DAILY DAILY SETTLE- CHANGE IN IV% VOLUME OPEN CHANGE  PRICE HIGH LOW MENT SETL INTEREST IN OI  PRICE PRICE  CLASS BEA – BANK OF EAST ASIA CLOSING PRICE HK$Z,ZZ9.99  DDMMMYY Z,ZZ9.99 C Z,ZZ9.99 Z,ZZ9.99 Z,ZZ9.99 Z,ZZ9.99 ±Z,ZZ9.99 ZZ9 Z,ZZZ,ZZ9 ZZ,ZZZ,ZZ9 ±ZZ,ZZZ,ZZ9  :    TOTAL CALL Z,ZZZ,ZZ9 ZZ,ZZZ,ZZ9 ±ZZ,ZZZ,ZZ9  DDMMMYY Z,ZZ9.99 P Z,ZZ9.99 Z,ZZ9.99 Z,ZZ9.99 Z,ZZ9.99 ±Z,ZZ9.99 ZZ9 Z,ZZZ,ZZ9 ZZ,ZZZ,ZZ9 ±ZZ,ZZZ,ZZ9  :    TOTAL PUT Z,ZZZ,ZZ9 ZZ,ZZZ,ZZ9 ±ZZ,ZZZ,ZZ9  <A NAME="XXX">  CONTRACT OPENING DAILY DAILY SETTLE- CHANGE IN IV% VOLUME OPEN CHANGE  PRICE HIGH LOW MENT SETL INTEREST IN OI  PRICE PRICE    CLASS XXX – XXXXXXXXXXXXXXXXXXXXXXX CLOSING PRICE HK$Z,ZZ9.99  DDMMMYY Z,ZZ9.99 C Z,ZZ9.99 Z,ZZ9.99 Z,ZZ9.99 Z,ZZ9.99 ±Z,ZZ9.99 ZZ9 Z,ZZZ,ZZ9 ZZ,ZZZ,ZZ9 ±ZZ,ZZZ,ZZ9  :    TOTAL CALL Z,ZZZ,ZZ9 ZZ,ZZZ,ZZ9 ±ZZ,ZZZ,ZZ9  DDMMMYY Z,ZZ9.99 P Z,ZZ9.99 Z,ZZ9.99 Z,ZZ9.99 Z,ZZ9.99 ±Z,ZZ9.99 ZZ9 Z,ZZZ,ZZ9 ZZ,ZZZ,ZZ9 ±ZZ,ZZZ,ZZ9  :    TOTAL PUT Z,ZZZ,ZZ9 ZZ,ZZZ,ZZ9 ±ZZ,ZZZ,ZZ9  ALL CONTRACTS TOTAL Z,ZZZ,ZZ9 ZZ,ZZZ,ZZ9 ±ZZ,ZZZ,ZZ9    \*\*\*End of Report\*\*\* |
|  | 123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890112345678901 |

#### Report Attribute

|  |  |
| --- | --- |
| Purpose | To generate a report showing the market summary of stock options instruments. |
| Frequency | Refer to the operation flow |
| Sequence | Contract year, month and week  Summary – HKATS code in alphabetical order  TOP 10 Traded – Descending order in instruments traded volume  TOP 5 Up – Descending order in positive change in settlement price  TOP 5 Down – Descending order in negative change in settlement price |
| Page Size | 101 columns |
| File Name | < Report Name >SO<yymmdd>.htm |
| Chinese Version | Please refer to Appendix B |

#### Report Type Setup

This report type specific designed for Stock Option (SO)s and Weekly Stock Options (WSO). To assign the SO and WSO instruments printed in the report, it is required to create a record in the report type. The reports will be generated per Report Name. Each Report Name requires users to define the Underlying. Assuming the Instrument class for SO and WSO share the same Underlying, the report generator would locate the corresponding SO and WSO Call and Put Options linked with the Underlying, then extract all contracts under the specified Call and Put Options Instrument Classes. Users are required to define the Report Header of the Report Name. And the Contract Description, Contract Term for the corresponding options class printed in the report.

The order of printing the options contracts is the same as [3.7.2.3] and applicable to print SO and WSO sorted by expiration date.

For multiple classes printed in a single report, the corresponding Instrument Class can share the same Report Name. The contracts will be grouped per Underlying in alphabetical order.

Capital Adjustment handling

* On Capital Adjustment E-1 day, the Closing Price of the Underlying subject to CA will be the adjusted Closing Price inputted in the CA module.
* On Capital Adjustment E day, both the standard and adjusted class would have the “Change in Settlement Price” information shown as “-“ (dash).

The report type setup fields are as below:

|  |  |
| --- | --- |
| **Report Type** | **Report for Stock Options** |
| **Report Name** | Specify the ID for the report. |
| **Header** | Specify the header of the report |
| **Instrument Class** | Specify the Call and Put Options Instrument Classes |
| **Underlying** | Specify the Underlying linked with the Call and Put Options classes. |
| **Contract Description** | Specify the Contract description |
| **Contract Term** | Specify the Contract price per index point |

Example for Stock Options

|  |  |  |  |
| --- | --- | --- | --- |
| **Report for Options with AHT** | | | |
| **Report Name** | | DQE | |
| **Header** | | Stock Options | |
| **Underlying list** | | | |
| **Instrument Class** | **Underlying** | **Contract Description** | **Contract Term** |
| A50CALL | A50 | A50 - ISHARES FTSE A50 CHINA INDEX ETF FUTURES | CONTRACT MULTIPLIER 5,000 |
| A50PUT | A50 | A50 - ISHARES FTSE A50 CHINA INDEX ETF FUTURES | CONTRACT MULTIPLIER 5,000 |
| ACCCALL | AAC | AAC - AAC TECHNOLOGIES HOLDINGS INC. FUTURES | CONTRACT MULTIPLIER 1,000 |
| ACCPUT | ACC | AAC - AAC TECHNOLOGIES HOLDINGS INC. FUTURES | CONTRACT MULTIPLIER 1,000 |
| ABCCALL | ABC | ABC - AGRICULTURAL BANK OF CHINA LTD. FUTURES | CONTRACT MULTIPLIER 10,000 |
| ABCPUT | ABC | ABC - AGRICULTURAL BANK OF CHINA LTD. FUTURES | CONTRACT MULTIPLIER 10,000 |

Noted: The Underlying list will be sorted by alphabetical order.

#### Fields Description

| **Field name** | **Description** | **Position on 3.7.9.1** | **Format** | **Remarks** |
| --- | --- | --- | --- | --- |
| Short-Cut Table | Short-cut to the particular stock options section in the report. | Line 1 to 24 |  |  |
| System Date | To show the creation date of the report | Line 31 | DD MMM YYYY |  |
| **Summary Statistic** |  | Line 36 – 42 |  |  |
| HKATS Code | The three characters symbol in HKATS for the stock options class |  |  |  |
| Underlying Stock | The underlying stock name and code defined for the HKATS code. |  |  | It will retrieve from the stock name and code from the product structure setup. |
| Total (Summary Trading Volume) | To show the total trade volume of a particular Stock Options class |  | Z,ZZZ,ZZ9 |  |
| Calls (Summary Trading Volume) | To show the trade volume of all call instruments of a particular Stock Options class |  | Z,ZZZ,ZZ9 |  |
| Puts (Summary Trading Volume) | To show the trade volume of all put instruments of a particular Stock Options class |  | Z,ZZZ,ZZ9 |  |
| Total (Summary Open Interest) | To show the total open interest of a particular Stock Options class |  | ZZ,ZZZ,ZZ9 |  |
| Calls (Summary Open Interest) | To show the open interest of all call instruments of a particular Stock Options class |  | ZZ,ZZZ,ZZ9 |  |
| Puts (Summary Open Interest) | To show the open interest of all put instruments of a particular Stock Options class |  | ZZ,ZZZ,ZZ9 |  |
| IV% | To show the implied volatility for at-the-money call and put instruments for the spot month |  | ZZ9  For new or capital adjusted stock, ‘spot month’ refers to the first contract month of the class.  On expiry day, ‘spot month’ refers to the first contract month of the class, excluding those expired contract instruments.  If today is the last trade day of the Stock Options class, print ‘-’ |  |
| Total (Total - Summary Trading Volume) | To show the total trade volume of all Stock Options classes |  | Z,ZZZ,ZZ9 |  |
| Calls (Total - Summary Trading Volume) | To show the total trade volume of all call instruments |  | Z,ZZZ,ZZ9 |  |
| Puts (Total - Summary Trading Volume) | To show the total trade volume of all put instruments |  | Z,ZZZ,ZZ9 |  |
| Total (Total - Summary Open Interest) | To show the total open interest of all Stock Options classes |  | ZZ,ZZZ,ZZ9 |  |
| Calls (Total - Summary Open Interest) | To show the total open interest of all call instruments |  | ZZ,ZZZ,ZZ9 |  |
| Puts (Total - Summary Open Interest) | To show the total open interest of all put instruments |  | ZZ,ZZZ,ZZ9 |  |
| **TOP 10 TRADED (SORT BY VOLUME)** |  | Line 49 |  |  |
| Put/Call code | The put or call symbol of the Top 10 Traded stock option |  | “P”, “C” |  |
| HKATS Code | The three characters symbol in HKATS for the stock options class |  | XXX |  |
| The contract month of the instruments | To show the contract month and year of the instruments |  | DDMMMYY |  |
| Strike price of the instruments | To show the strike price of the options instruments |  | Z,ZZ9.99 |  |
| Volume | To show the traded volume of the instruments |  | Z,ZZZ,ZZ9 |  |
| Settlement Price | To show the settlement price of the instruments |  | Z,ZZ9.99 |  |
| IV% | To show the implied volatility of the instruments |  | ZZ9 |  |
| High | To show the highest traded price of the instruments |  | Z,ZZ9.99 |  |
| Low | To show the lowest traded price of the instruments |  | Z,ZZ9.99 |  |
| Open Interest | To show the open interest of the instruments |  | ZZ,ZZZ,ZZ9 |  |
| Settlement Price Change | To show the change in settlement price of the instruments from the previous business day |  | ±Z,ZZ9.99 |  |
| % Chg in Settlement Price | To show the % change in settlement price of instruments from the previous business day |  | ±Z,ZZ9.99 |  |
| **TOP 5 UP (SORT BY % CHANGE IN SETTLEMENT)** | Same field definition as “TOP 10 Traded” | Line 56 |  | Sort by the % change in settlement price in descending order. |
| **TOP 5 DOWN (SORT BY % CHANGE IN SETTLEMENT)** | Same field definition as “TOP 10 Traded” | Line 63 |  | Sort by the % change in settlement price in ascending order. |
| **STOCK OPTIONS CLASS SECTION** |  | Line 73 – 110 |  |  |
| Short Cut tag for the options class | It is the tag for short-cut button in Header table |  |  |  |
| Class name and description | The HKATS code and the description of HKATS code in MIX |  |  |  |
| Closing Price | The closing price of the underlying stock code |  | Z,ZZ9.99 |  |
| The contract month of the instruments | To show the contract month and year of the instruments |  | DDMMMYY |  |
| Strike price of the instruments | To show the strike price of the options instruments |  | Z,ZZ9.99 |  |
| Put/Call code | The put or call symbol of the Top 10 Traded stock option |  | “P”, “C” |  |
| Opening Price | To show the first traded price of the instruments |  | Z,ZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Daily High | To show the highest traded price of today |  | Z,ZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Daily Low | To show the lowest traded price of today |  | Z,ZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Settlement Price | To show the settlement price of the instruments |  | Z,ZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Change in Setl Price | To show the change of settlement price from that of previous business day |  | ±Z,ZZ9.99 | NIL – when instruments expired  “-“- when not applicable / flag set in CA Arrangement in MIX GUI |
| IV% | The IV from DIRS |  | ZZ9 | NIL – when instruments expired  “0“- when not applicable |
| Volume | To show the number of traded volume of the instruments |  | Z,ZZZ,ZZ9 | NIL – when instruments expired  “0“- when not applicable |
| Open Interest | To show the open interest of business day after market closed |  | ZZ,ZZZ,ZZ9 | “-“- when not applicable |
| Change in OI | To show the change of open interest of business days after market closed |  | ±ZZ,ZZZ,ZZ9 | “-“- when not applicable / flag set in CA Arrangement in MIX GUI |
| **Market Contracts Total** |  | Line 109 |  |  |
| Volume | To show the number of traded volume of all instruments |  | Z,ZZZ,ZZ9 |  |
| Open Interest | To show the open interest of all instruments for current business day |  | ZZ,ZZZ,ZZ9 |  |
| Change in OI | To show the change of open interest of all instruments with previous business days |  | ±ZZ,ZZZ,ZZ9 |  |

### Indices / Currency Options

#FS10017A\_S0030\_02100

#### Report Layout

|  |  |
| --- | --- |
| 1  2  34567890123456789012345678901234567890123456789 | <HTML><HEAD>  <TITLE>XXXXXXXXXXXXXXXXX OPTIONS DAILY MARKET REPORT</TITLE></HEAD><BODY><PRE>  XXXXXXXXXXXXXXXXXX OPTIONS DAILY MARKET REPORT  Hong Kong Exchanges and Clearing Limited and/or its subsidiaries endeavour to ensure the  accuracy and reliability of the information provided, but do not guarantee its accuracy and  reliability and accept no liability (whether in tort or contract or otherwise) for any loss  or damage arising from any inaccuracies or omissions.  xxxxxxxxxxxxxxxxxxxxxxxxxxxxx    Trading Day of the Exchange Prev. Trading Day of the Exchange  dd mmm yyyy, weekday dd mmm yyyy,  weekday    CONTRACT STRIKE OPENING DAILY DAILY O.Q.P. O.Q.P. IV% VOLUME OPEN CHANGE  MONTH PRICE PRICE HIGH LOW CLOSE CHANGE INTEREST IN OI  MMM-YY ZZZZ9 C ZZZZ9 ZZZZ9 ZZZZ9 ZZZZ9 ±ZZZZ9 ZZ9 ZZZZZZ9 ZZZZZZ9 ±ZZZZZ9  :  :  MMM-YY ZZZZ9 C ZZZZ9 ZZZZ9 ZZZZ9 ZZZZ9 ±ZZZZ9 ZZ9 ZZZZZZ9 ZZZZZZ9 ±ZZZZZ9    TOTAL CALL ZZZZZZ9 ZZZZZZ9 ±ZZZZZ9  CONTRACT STRIKE OPENING DAILY DAILY O.Q.P. O.Q.P. IV% VOLUME OPEN CHANGE  MONTH PRICE PRICE HIGH LOW CLOSE CHANGE INTEREST IN OI  MMM-YY ZZZZ9 P ZZZZ9 ZZZZ9 ZZZZ9 ZZZZ9 ±ZZZZ9 ZZ9 ZZZZZZ9 ZZZZZZ9 ±ZZZZZ9  :  :  MMM-YY ZZZZ9 P ZZZZ9 ZZZZ9 ZZZZ9 ZZZZ9 ±ZZZZ9 ZZ9 ZZZZZZ9 ZZZZZZ9 ±ZZZZZ9    TOTAL PUT ZZZZZZ9 ZZZZZZ9 ±ZZZZZ9  MONTH PUT/CALL RATIO ZZZZZZ9.99 MONTH TOTAL ZZZZZZ9 ZZZZZZ9 ±ZZZZZ9  .  .  .  .  MARKET PUT/CALL RATIO ZZZZZZ9.99 MARKET TOTAL ZZZZZZ9 ZZZZZZ9 ±ZZZZZ9  \*\*\* END OF REPORT \*\*\*  O.Q.P. - OFFICIAL QUOTATION PRICE  ALL COMBO VS COMBO TRANSACTIONS ARE EXCLUDED  </PRE></BODY></HTML> |
|  | 123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890112345678901234 |

#### Report Attribute

|  |  |
| --- | --- |
| Purpose | To generate a report showing the market summary of currency options instruments for market |
| Frequency | Refer to the operation flow |
| Sequence | Contract year and month |
| Page Size | 104 columns |
| File Name | < Report Name >IO<yymmdd>.htm |
| Chinese Version | Please refer to Appendix B |

#### Report Type Setup

To assign the Options instrument printed in the report, it is required to create a record in the report type. The reports will be generated per Report Name. Each Report Name requires users to define the corresponding Options Call and Put Instrument Class. The report generator would locate all contracts under the specified Call and Put Options Instrument Class. Users are required to define the Report Header of the Report Name. And the Contract Description, Contract Term for the corresponding options class printed in the report.

The order of printing the options contracts is the same as 3.7.5.3

For multiple classes printed in a single report, the corresponding Instrument Class can share the same Report Name. The contracts will be grouped per instrument class in alphabetical order.

The report type setup fields are as below:

|  |  |
| --- | --- |
| **Report Type** | **Report for Indices / Currency Options** |
| **Report Name** | Specify the ID for the report. |
| **Header** | Specify the header of the report |
| **Instrument Class** | Specify the instrument class of the Call and Put Options |
| **Underlying** | Specify the Underlying group with the Call and Put Options |
| **Contract Description** | Specify the Contract description |
| **Contract Term** | Specify the Contract price per index point |

Example for CUS Options

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
| **Report for Indices and Currency Options** | | | | |  |
| **Report Name** | | CUSO | | |  |
| **Header** | | RMB Currency Option | | |  |
| **Instrument Class list** | | | | |  |
| **Instrument Class** | **Underlying** | | **Contract Description** | **Contract Term** | |
| CUSCALL | CUS | | USD/CNH Options RMB10 per minimum fluctuation |  | |
| CUSPUT | CUS | | USD/CNH Options RMB10 per minimum fluctuation |  | |

Noted: The Instrument Class list will be sorted by alphabetical order.

#### Fields Description

| **Field name** | **Description** | **Position on 3.7.10.1** | **Format** | **Remarks** |
| --- | --- | --- | --- | --- |
| HTML header & report title | The report title | Line 1 – 3 | Refer to the Header field in the report type setup | “RMB CURRENCY” or  “HANG SENG TECH INDEX OPTIONS” or  “MSCI TAIWAN (USD) INDEX OPTIONS” or  “MSCI CHINA FREE (USD) INDEX OPTIONS” or |
| Contract Description | Specified in the corresponding Report Name’s Instrument Class | Line 11 |  | "USD/CNH OPTIONS RMB10 PER MINIMUM FLUCTUATION" or  “Hang Seng TECH Index Options HK$50 per point” or  “MSCI Taiwan (USD) Index Options USD100 per point” or  “MSCI China Free (USD) Index Options USD5 per point” or |
| System Date | To show the creation date of the report | Line 14 – 15 | DD MMM YYYY, WEEKDAY | Trading Day of the Exchange |
| Prev. Trading Day of the Exchange | To show the date of previous business day | Line 13 – 15 | DD MMM YYYY, WEEKDAY | This field will not be available if the “Open Interest” and “Change in OI” is representing the data in same business day |
| **Market Statistic** |  | Line 19 – 22 |  |  |
| Contract Month | To show the contract year and month of the instruments. |  | MMM-YY  where MMM = JAN .. DEC and  YY = the last two digits of the contract year |  |
| Strike Price | To show the strike price and call put code of the instruments |  | ZZZZ9 X |  |
| Opening Price | To show the first traded price of the instruments |  | ZZZZ9 | NIL – when instruments expired  “-“- when not applicable |
| Daily High | To show the highest traded price of today |  | ZZZZ9 | NIL – when instruments expired  “0“- when not applicable |
| Daily Low | To show the lowest traded price of today |  | ZZZZ9 | NIL – when instruments expired  “0“- when not applicable |
| O.Q.P Close | To show the settlement price of the instruments |  | ZZZZ9 | NIL – when instruments expired  “0“- when not applicable |
| O.Q.P Change | To show the change of settlement price from that of previous business day |  | ±ZZZZ9 | NIL – when instruments expired  “-“- when not applicable |
| IV% | The IV from DIRS |  | ZZ9 | NIL – when instruments expired  “0“- when not applicable |
| Volume | To show the number of traded volume of the instruments |  | ZZZZZZ9 | NIL – when instruments expired  “0“- when not applicable |
| Open Interest | To show the open interest of previous business day |  | ZZZZZZ9 | “-“- when not applicable |
| Change in OI | To show the change of open interest in the two previous business days |  | ±ZZZZZ9 | “-“- when not applicable |
| **Contracts Total (CALL/PUT)** |  | Line 24 |  |  |
| Volume | To show the number of traded volume of all instruments |  | ZZZZZZ9 |  |
| Open Interest | To show the open interest of all instruments in the previous business day |  | ZZZZZZ9 |  |
| Change in OI | To show the change of open interest of all instruments in the two previous business days |  | ±ZZZZZ9 |  |
| **Month Total**  **(Contract Month)** |  | Line 35 |  |  |
| Ratio | Put Call Ratio of the Month |  | ZZZZZZ9.99 | ‘----------‘ when call = 0 |
| Volume | To show the number of traded volume of all instruments |  | ZZZZZZ9 |  |
| Open Interest | To show the open interest of all instruments in the previous business day |  | ZZZZZZ9 |  |
| Change in OI | To show the change of open interest of all instruments in the two previous business days |  | ±ZZZZZ9 |  |
| **Market Total** |  | Line 42 |  |  |
| Ratio | Put Call Ratio of the Market |  | ZZZZZZ9.99 | ‘----------‘ when call = 0 |
| Volume | To show the number of traded volume of all instruments |  | ZZZZZZ9 |  |
| Open Interest | To show the open interest of all instruments in the previous business day |  | ZZZZZZ9 |  |
| Change in OI | To show the change of open interest of all instruments in the two previous business days |  | ±ZZZZZ9 |  |

### Flexible Indices Options

#FS10017A\_S0030\_02200

#### Report Layout

|  |  |
| --- | --- |
| 1  2  345678901234567890123456789012345678901234567890123456789012345678901 | <HTML><HEAD>  <TITLE>XXXXXXXXXXXXXXXXX FLEXIBLE OPTIONS DAILY MARKET REPORT</TITLE></HEAD><BODY><PRE>  XXXXXXXXXXXXXXXXXX FLEXIBLE OPTIONS DAILY MARKET REPORT  Hong Kong Exchanges and Clearing Limited and/or its subsidiaries endeavour to ensure the  accuracy and reliability of the information provided, but do not guarantee its accuracy and  reliability and accept no liability (whether in tort or contract or otherwise) for any loss  or damage arising from any inaccuracies or omissions.  xxxxxxxxxxxxxxxxxxxxxxxxxxxxx PER POINT    Trading Day of the Exchange Prev. Trading Day of the Exchange  dd mmm yyyy, weekday dd mmm yyyy,  weekday    CONTRACT STRIKE OPENING DAILY DAILY S.P. S.P. IV% VOLUME OPEN CHANGE  MONTH PRICE PRICE HIGH LOW CLOSE CHANGE INTEREST IN OI  MMM-YY ZZZZ9 C - - - ZZZZ9 ±ZZZZ9 ZZ9 ZZZZZZ9 ZZZZZZ9 ±ZZZZZ9  :  :  MMM-YY ZZZZ9 C - - - ZZZZ9 ±ZZZZ9 ZZ9 ZZZZZZ9 ZZZZZZ9 ±ZZZZZ9    TOTAL CALL ZZZZZZ9 ZZZZZZ9 ±ZZZZZ9  CONTRACT STRIKE OPENING DAILY DAILY S.P. S.P. IV% VOLUME OPEN CHANGE  MONTH PRICE PRICE HIGH LOW CLOSE CHANGE INTEREST IN OI  MMM-YY ZZZZ9 P - - - ZZZZ9 ±ZZZZ9 ZZ9 ZZZZZZ9 ZZZZZZ9 ±ZZZZZ9  :  :  MMM-YY ZZZZ9 P - - - ZZZZ9 ±ZZZZ9 ZZ9 ZZZZZZ9 ZZZZZZ9 ±ZZZZZ9    TOTAL PUT ZZZZZZ9 ZZZZZZ9 ±ZZZZZ9  MONTH TOTAL ZZZZZZ9 ZZZZZZ9 ±ZZZZZ9  .  .  .  .  CONTRACT STRIKE OPENING DAILY DAILY S.P. S.P. IV% VOLUME OPEN CHANGE  MONTH PRICE PRICE HIGH LOW CLOSE CHANGE INTEREST IN OI  MMM-YY ZZZZ9 C - - - ZZZZ9 ±ZZZZ9 ZZ9 ZZZZZZ9 ZZZZZZ9 ±ZZZZZ9  :  :  MMM-YY ZZZZ9 C - - - ZZZZ9 ±ZZZZ9 ZZ9 ZZZZZZ9 ZZZZZZ9 ±ZZZZZ9    TOTAL CALL ZZZZZZ9 ZZZZZZ9 ±ZZZZZ9  CONTRACT STRIKE OPENING DAILY DAILY S.P. S.P. IV% VOLUME OPEN CHANGE  MONTH PRICE PRICE HIGH LOW CLOSE CHANGE INTEREST IN OI  MMM-YY ZZZZ9 P - - - ZZZZ9 ±ZZZZ9 ZZ9 ZZZZZZ9 ZZZZZZ9 ±ZZZZZ9  :  :  MMM-YY ZZZZ9 P - - - ZZZZ9 ±ZZZZ9 ZZ9 ZZZZZZ9 ZZZZZZ9 ±ZZZZZ9    TOTAL PUT ZZZZZZ9 ZZZZZZ9 ±ZZZZZ9  MONTH TOTAL ZZZZZZ9 ZZZZZZ9 ±ZZZZZ9  MARKET TOTAL ZZZZZZ9 ZZZZZZ9 ±ZZZZZ9  \*\*\* END OF REPORT \*\*\*  S.P. – SETTLEMENT PRICE  </PRE></BODY></HTML> |
|  | 123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890112345678901234 |

#### Report Attribute

|  |  |
| --- | --- |
| Purpose | To generate a report showing the market summary of flexible options indices instruments for markets. |
| Frequency | Refer to the operation flow |
| Sequence | Contract year and month |
| Page Size | 104 columns |
| File Name | <Report Name>FO<yymmdd>.htm |
| Chinese Version | Please refer to Appendix B |

#### Report Type Setup

To assign the Options instrument printed in the report, it is required to create a record in the report type. The reports will be generated per Report Name. Each Report Name requires users to define the corresponding Options Call and Put Instrument Class. The report generator would locate all contracts under the specified Call and Put Options Instrument Class. Users are required to define the Report Header of the Report Name. And the Contract Description, Contract Term for the corresponding options class printed in the report.

The order of printing the options contracts is the same as 3.7.5.3

For multiple classes printed in a single report, the corresponding Instrument Class can share the same Report Name. The contracts will be grouped per instrument class in alphabetical order. If there is no instrument found within the defined instrument class, the report will display ‘NO OPTIONS INSTRUMENTS AVAILABLE’.

The report type setup fields are as below:

|  |  |
| --- | --- |
| **Report Type** | **Report for Flexible Indices Options** |
| **Report Name** | Specify the ID for the report. |
| **Header** | Specify the header of the report |
| **Instrument Class** | Specify the instrument class of the Call and Put Options |
| **Underlying** | Specify the Underlying group with the Call and Put Options |
| **Contract Description** | Specify the Contract description |
| **Contract Term** | Specify the Contract price per index point |

Example for Flexible HSI Options

|  |  |  |  |
| --- | --- | --- | --- |
| **Report for Indices and Currency Options** | | | |
| **Report Name** | | XHSO | |
| **Header** | | Flexible HSI Options | |
| **Instrument Class list** | | | |
| **Instrument Class** | **Underlying** | **Contract Description** | **Contract Term** |
| XHSCALL | XHS | Flexible Hang Seng Index Options HK$50 per point |  |
| XHSPUT | XHS | Flexible Hang Seng Index Options HK$50 per point |  |

Noted: The Instrument Class list will be sorted by alphabetical order.

#### Fields Description

| **Field name** | **Description** | **Position on 3.7.11.1** | **Format** | **Remarks** |
| --- | --- | --- | --- | --- |
| HTML header & report title | The report title | Line 1 – 3 | Refer to the Header field in the report type setup | “HANG SENG INDEX” or  “HANG SENG CHINA ENTERPRISES INDEX " |
| Contract Description and Contract Term | Specified in the corresponding Report Name’s Instrument Class | Line 11 | Hardcode in the template file for the market. | "HANG SENG INDEX FLEXIBLE OPTIONS HK$50 PER POINT" or  "HANG SENG CHINA ENTERPRISES INDEX FLEXIBLE OPTIONS HK$ 50 PER POINT" |
| System Date | To show the creation date of the report | Line 14 – 15 | DD MMM YYYY, WEEKDAY | Trading Day of the Exchange |
| Prev. Trading Day of the Exchange | To show the date of previous business day | Line 13 – 15 | DD MMM YYYY, WEEKDAY | This field will not be available if the “Open Interest” and “Change in OI” is representing the data in same business day |
| **Market Statistic** |  | Line 19 – 22 |  |  |
| Contract Month | To show the contract year and month of the instruments. |  | MMM-YY  where MMM = JAN .. DEC and  YY = the last two digits of the contract year |  |
| Strike Price | To show the strike price and call put code of the instruments |  | ZZZZ9 X |  |
| Opening Price | To show the first traded price of the instruments |  | - | Hardcode “-“ |
| Daily High | To show the highest traded price of today |  | - | Hardcode “-“ |
| Daily Low | To show the lowest traded price of today |  | - | Hardcode “-“ |
| S.P Close | To show the settlement price of the instruments |  | ZZZZ9 | NIL – when instruments expired  “0“- when not applicable |
| S.P Change | To show the change of settlement price from that of previous business day |  | ±ZZZZ9 | NIL – when instruments expired  “-“- when not applicable |
| IV% | The IV from DIRS |  | ZZ9 | NIL – when instruments expired  “0“- when not applicable |
| Volume | To show the number of traded volume of the instruments |  | ZZZZZZ9 | NIL – when instruments expired  “0“- when not applicable |
| Open Interest | To show the open interest of previous business day |  | ZZZZZZ9 | “-“- when not applicable |
| Change in OI | To show the change of open interest in the two previous business days |  | ±ZZZZZ9 | “-“- when not applicable |
| **Contracts Total (CALL/PUT)** |  | Line 24 |  |  |
| Volume | To show the number of traded volume of all instruments |  | ZZZZZZ9 |  |
| Open Interest | To show the open interest of all instruments in the previous business day |  | ZZZZZZ9 |  |
| Change in OI | To show the change of open interest of all instruments in the two previous business days |  | ±ZZZZZ9 |  |
| **Month Total**  **(Contract Month)** |  | Line 35 |  |  |
| Volume | To show the number of traded volume of all instruments |  | ZZZZZZ9 |  |
| Open Interest | To show the open interest of all instruments in the previous business day |  | ZZZZZZ9 |  |
| Change in OI | To show the change of open interest of all instruments in the two previous business days |  | ±ZZZZZ9 |  |
| **Market Total** |  | Line 65 |  |  |
| Volume | To show the number of traded volume of all instruments |  | ZZZZZZ9 |  |
| Open Interest | To show the open interest of all instruments in the previous business day |  | ZZZZZZ9 |  |
| Change in OI | To show the change of open interest of all instruments in the two previous business days |  | ±ZZZZZ9 |  |

### Tailor-Made Combination

#FS10017A\_S0030\_02300

#### Report Layout

|  |  |
| --- | --- |
| 1  2  345678901234567890123456789 | <HTML><HEAD><meta name="MS.LOCALE" content="EN-US"><TITLE> XXXXXXXXXXXXXXXXXXXXXXXXX TAILOR-MADE COMBINATION DAILY MARKET REPORT</TITLE>  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">  </HEAD>  <BODY><PRE>  XXXXXXXXXXXXXXXXXXXXXXXXX TAILOR-MADE COMBINATION DAILY MARKET REPORT  Hong Kong Exchanges and Clearing Limited and/or its subsidiaries endeavour to ensure the  accuracy and reliability of the information provided, but do not guarantee its accuracy and  reliability and accept no liability (whether in tort or contract or otherwise) for any loss  or damage arising from any inaccuracies or omissions.  Trading Day of the Exchange  DD MMM YYYY, WEEKDAY      General Name Leg 1 Leg 2 Leg 3 Leg 4 Open Price Daily High Daily Low Last Volume    1 TMC\_XXX/NNN (X N) XXXXXXXXXX (X N) XXXXXXXXXX (X N) XXXXXXXXXX (X N) XXXXXXXXXX ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9  2 TMC\_XXX/NNN (X N) XXXXXXXXXX (X N) XXXXXXXXXX (X N) XXXXXXXXXX (X N) XXXXXXXXXX ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9  3 TMC\_XXX/NNN (X N) XXXXXXXXXX (X N) XXXXXXXXXX (X N) XXXXXXXXXX (X N) XXXXXXXXXX ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9  …  …  …  N TMC\_XXX/NNN (X N) XXXXXXXXXX (X N) XXXXXXXXXX (X N) XXXXXXXXXX (X N) XXXXXXXXXX ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9 ZZZ,ZZ9  \*\*\* END OF REPORT \*\*\*  </PRE></BODY></HTML> |
|  | 12345678901234567890123456789012345678901234567890123456789012345678901234567890123456789011234567890123456789012345678901234567890123456789012345678901234567890 |

#### Report Attribute

|  |  |
| --- | --- |
| Purpose | To generate a report showing the market summary of futures and options tailor-made combination instruments |
| Frequency | Refer to the operation flow |
| Sequence | Contract year and month |
| Page Size | 160 columns |
| File Name | <Report Name>TM<yymmdd>.htm |
| Chinese Version | Please refer to Appendix B |

#### Report Type Setup

To assign the Tailor Made Combo (TMC) Contracts printed in the report, it is required to create a record in the report type. The reports will be generated per Report Name. Each Report Name requires users to define the corresponding list of Combo Class. The report generator would locate all TMC under per assigned Combo Class. Users are required to define the Report Header for the Report Name. The Contract Description, Contract Term for each instrument class printed in the report. The report will only show the contracts with traded volume and will be grouped per instrument class and printed in Instrument class’s alphabetical order.

The report type setup fields are as below:

|  |  |
| --- | --- |
| **Report Type** | **Report for Tailor-Made Combination** |
| **Report Name** | Specify the ID for the report. |
| **Instrument Class** | Assign the corresponding Combo Class to locate the corresponding contracts printed in the report |
| **Underlying** | Not applicable for this report type |
| **Header** | Specify the header of the report |
| **Contract Description** | Specify the Contract description |
| **Contract Term** | Specify the Contract price per index point |

Example for MTW TMC:

|  |  |  |  |
| --- | --- | --- | --- |
| **Report for TMC** | | | |
| **Report Name** | MTWTMC | | |
| **Header** | MSCI Taiwan (USD) Index Futures and Options | | |
| **Instrument Class list** | | | |
| **Instrument Class** | | **Contract Description** | **Contract Term** |
| TMC\_MTW | |  |  |

Noted: The report will only list the TMC in active status and volume > 0. It will The Instrument Class list will be sorted by alphabetical order.

#### Fields Description

| **Field name** | **Description** | **Position on 3.7.12.1** | **Format** | **Remarks** |
| --- | --- | --- | --- | --- |
| HTML header & report title | The report title | Line 1 – 5 | Refer to the Header field in the report type setup | “STOCK OPTIONS” or  “HANG SENG TECH INDEX FUTURES AND OPTIONS” or  “MSCI TAIWAN (USD) INDEX FUTURES AND OPTIONS” or  “MSCI CHINA FREE (USD) INDEX FUTURES AND OPTIONS” |
| System Date | To show the business date of the report | Line 13 | DD MMM YYYY, WEEKDAY | Trading Day of the Exchange |
| **Market Statistic** |  | Line 18 – 24 |  |  |
| Row Number | To show the row number of contract |  | N |  |
| General Name | Name of TMC contract |  | TMC\_XXX/NNN | XXX – class code  NNN – TMC code |
| Leg 1 | To show the first leg of contract combination |  | (X N) XXXXXX | (X N) – Bid/Ask and leg ratio  XXXXXX – Normal instruments name of leg  “-“ – when not applicable |
| Leg 2 | To show the second leg of contract combination |  | (X N) XXXXXX | (X N) – Bid/Ask and leg ratio  XXXXXX – Normal instruments name of leg  “-“ – when not applicable |
| Leg 3 | To show the third leg of contract combination |  | (X N) XXXXXX | (X N) – Bid/Ask and leg ratio  XXXXXX – Normal instruments name of leg  “-“ – when not applicable |
| Leg 4 | To show the fourth leg of contract combination |  | (X N) XXXXXX | (X N) – Bid/Ask and leg ratio  XXXXXX – Normal instruments name of leg  “-“ – when not applicable |
| Open Price | To show the first traded price of the instruments |  | Z,ZZZ,ZZ9 or  ZZ,ZZ9.99 or  ZZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Daily High | To show the highest traded price of today |  | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or  ZZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Daily Low | To show the lowest traded price of today |  | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or  ZZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Last | To show the last traded price of today |  | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or  ZZZ9.99 | NIL – when instruments expired  “0“- when not applicable |
| Volume | To show the number of traded volume of the instruments |  | Z,ZZZ,ZZ9 or  ZZZZZZ9 | NIL – when instruments expired  “0“- when not applicable |

# Weekly Quotation (Stock Options) Report

#FS10017A\_S0040\_00100

It is the report for Stock Options Instrument only and generated after Stock Options market close in every Friday. It queries the weekly market statistic data from Market Statistic Consolidator and the Market Statistic for the current week. Then, compute the statistic for current week and changes in previous week. After the report generation has completed, it stores the computed data into the Database.

## Source of Data

The report incorporates data from four key tables: Turnover Volume table, Open Interest table, 10 Most Active Instruments by Volume, and the Volume and Open Interest Summary. It makes use of the trade volume and Open Interest data stored for Daily Market Report before Dayend in each trading day

Turnover Volume Table

The data is computed based on the total turnover of call and put options traded on a daily basis during the previous week. It includes the trading volume, percentage change from the previous week, and the Put/Call ratio for each underlying stock option's call and put contracts.

Open Interest Table

The data retrieves the Open Interest from the last trading day of the week per stock options instruments.

10 Most Active Instruments by Volume Table

The data is organized by the expiration date of the option contracts to summarizes the 10 most actively traded stock option contracts by volume, broken down into call and put volumes.

Volume and Open Interest Summary Table

The data provides an aggregated view of the total traded volume and open interest across all stock option instruments during the week, from both the call/put and the total perspectives.

## Operation Flow

In each Friday before the dayend batch, the report generator will trigger the report generation for Weekly Quotation Report. It gathers the stored trade volume and Open Interest data from Monday to Friday of the current week and the aggregated data in the previous week to compute the report.

## Data Archival

No data needs to be stored as all data for report generation were retrieved from the database.

## Holiday Arrangements

In Volume and Open Interest Summary table, the volume will be shown as 0 when it is a non-trading date for Stock Options. For Open Interest, the value in the previous day opens for trading would be shown.

e.g. if 11-Oct-2024 is holiday for Stock Options, the Volume on 11-Oct-2024 would be shown as 0, the Open Interest on 11-Oct-2024 would use the value on 10-Oct-2024 as below:

![](data:image/png;base64...)

## New Underlying handling

The new Underlying will be included in the report at least 1 trading date being active in the report day range.

## Report formats

Two output formats will be produced: an HTML format for publishing the Weekly Quotation (Stock Options) on the HKEX website for viewing, and a CSV format that will be available for external download.

## Report Layout

* Layout in HTML format for preview

![](data:image/png;base64...)

![](data:image/png;base64...)

* Layout in csv format

|  |
| --- |
| Derivatives Market,,,,,,  Weekly Quotations,,,,,,  THE STOCK EXCHANGE OF HONG KONG LTD.,,,,,,  "DATE : 04 OCT 2024, FRIDAY",,,,,,  WEEKLY QUOTATIONS FOR STOCK OPTIONS (07/10/2024 - 11/10/2024),,,,,,  "The Stock Exchange of Hong Kong Limited endeavours to ensure the accuracy and reliability of the information provided, but does not guarantee its accuracy and reliability and accepts no liability (whether in tort or contract or otherwise) for any loss or damage arising from any inaccuracies or omissions.",,,,,,  ,,,,,,  TURNOVER VOLUME OF STOCK OPTIONS CONTRACTS FOR THE WEEK (07/10/2024 - 11/10/2024),,,,,,  Class,Stock Code,Total,Call,Put,% Change from Previous Week,Put/Call Ratio  A50 X ISHARES A50,02823,32688,21835,11573,28.1,0.55  AAC AAC TECH,02018,24520,14176,10344,1.1,0.73  ACC ANHUI CONCH,00914,"30,354","17,375","12,979",-5.4,0.75  Market Total,,"6,908,205","4,455,637","2,452,568",-16.4,0.55  ,,,,,,  OPEN INTEREST OF STOCK OPTIONS ON 11/10/2024,,,,,,  Class,Stock Code,Total,Call,Put,% Change from Previous Week,Put/Call Ratio  A50 X ISHARES A50,02823,"32,688","21,835","11,573",28.1,0.55  AAC AAC TECH,02018,"24,520","14,176","10,344",1.1,0.73  ACC ANHUI CONCH,00914,"30,354","17,375","12,979",-5.4,0.75  Market Total,,"14,007,635","7,008,598","6,999,037",-3.6,1  ,,,,,,  10 MOST ACTIVE INSTRUMENTS BY VOLUME FOR THE WEEK (07/10/2024 - 11/10/2024),,,,,,  Options Type,Underlying Code,LTD,Strike Price,Volume,,  Call Options,TCH,18OCT24,500.00,"53,732",,  Call Options,TCH,25OCT24,460.00,"35,191",,  Call Options,TCH,25OCT24,520.00,"34,491",,  Put Options,TCH,18OCT24,400.00,"21,849",,  Put Options,XCC,25OCT24,5.50,"17,611",,  Put Options,TCH,25OCT24,420.00,"17,588",,  ,,,,,,  VOLUME AND OPEN INTEREST SUMMARY,,,,,,  Date,Volume - Total,Volume - Call,Volume - Put,OI - Total,OI - Call,OI - Put  7/10/2024,"2,033,358","1,274,481","758,877","12,213,596","5,852,702","6,360,894"  8/10/2024,"2,181,038","1,451,803","749,235","13,008,788","6,354,104","6,654,684"  9/10/2024,"1,330,112","851,707","478,405","13,425,429","6,624,583","6,800,846"  10/10/2024,"1,019,969","635,738","384,231","15,760,501","7,994,836","7,765,665"  11/10/2024,0,0,0,"15,760,501","7,994,836","7,765,665" |

### Table Attribute

|  |  |
| --- | --- |
| Purpose | Showing the turnover volume and open interest of each Stock Options and Weekly Stock Options Underlying |
| Frequency | Refer to the operation flow |
| Sequence | For TURNOVER VOLUME OF STOCK OPTIONS CONTRACTS FOR THE WEEK, sort by underlying in alphabetical order  For OPEN INTEREST OF STOCK OPTIONS, sort by underlying in alphabetical order  For 10 MOST ACTIVE INSTRUMENTS BY VOLUME FOR THE WEEK, sort by 10 most volume Instrument from most to least in CALL and PUT respectively  For VOLUME AND OPEN INTEREST SUMMARY, sort by Date from Monday to Friday |
| File Name | <Report Name>WQ<yymmdd>.htm |
| Chinese Version | TBC |

### Report Type Setup

It is required to configure the list of Instrument Class and its corresponding underlying. The report generator will collect all Instrument Class linked to the Underlying, e.g. Monthly Stock Options and Weekly Stock Options Instrument Class should be linked to the same Underlying, then, it calculates the relevant statistics accordingly. The calculation will also encompass contracts that are currently in suspended status, as well as capital-adjusted contracts.

The report type setup fields are as below:

|  |  |
| --- | --- |
| **Report Type** | **Weekly Quotation Report** |
| **Report Name** | Specify the ID for the report. |
| **Header** | Specify the header of the report |
| **Underlying** | Specify the Underlying linked with the Call and Put Options classes. |
| **Contract Description** | Specify the Contract description |
| **Contract Term** | Specify the Contract price per index point |

Example for Stock Options

|  |  |  |
| --- | --- | --- |
| **Report for Weekly Quotation** | | |
| **Report Name** | WQR | |
| **Header** | WEEKLY QUOTATIONS FOR STOCK OPTIONS CONTRACTS FOR THE WEEK | |
| **Instrument Group list** | | |
| **Instrument Class** | | **Underlying** |
| A50CALL | | A50 |
| A50PUT | | A50 |
| A50CALLWSO | | A50 |
| A50PUTWSO | | A50 |
| ACCCALL | | ACC |
| ACCPUT | | ACC |

Noted: The Underlying list will be sorted by alphabetical order.

### Field Description

Each row represents a specific stock option Underlying, providing the relevant turnover information for the week.

| **Field name** | **Description** | **Position in csv** | **Format** | **Remarks** |
| --- | --- | --- | --- | --- |
| Exchange Information | Includes the exchange's name, contact details, and a disclaimer regarding the accuracy of the report. | 1 |  |  |
| Report Header | Specify the report title | 1 | "WEEKLY QUOTATIONS FOR STOCK OPTIONS CONTRACTS FOR THE WEEK" |  |
| Date range | Specifies the reporting period | 1 | DD/MM/YYYY - DD/MM/YYYY |  |
| **Table Title 1** | Specify the title of the first table in the report |  | **TURNOVER VOLUME OF STOCK OPTIONS CONTRACTS FOR THE WEEK** |  |
| Date range | Specifies the reporting period | 1 | DD/MM/YYYY - DD/MM/YYYY |  |
| Class | Underlying + underlying description | 1 |  |  |
| Stock Code | The unique identifier for each stock option. Refer to the Stock Code configured per Underlying | 2 |  |  |
| Total | Total number of call options traded + Total number of put options traded per Underlying | 3 | Z,ZZZ,ZZ9 |  |
| Call | Total number of call options traded | 4 | Z,ZZZ,ZZ9 |  |
| Put | Total number of put options traded per Underlying | 5 | Z,ZZZ,ZZ9 |  |
| % Change from Previous Week | (Total volume for this week – Total volume in previous week) / Total volume in previous week per Underlying | 6 | ±Z,ZZ9.99 |  |
| Put/Call Ratio | Calculation expressing the relationship between put and call options traded per Underlying | 7 | ±Z,ZZ9.99 |  |
| **Market Total** |  | 1 |  |  |
| Total | Total number of call options traded + Total number of put options traded for all Underlying | 3 | Z,ZZZ,ZZ9 |  |
| Call | Total number of call options traded for all Underlying | 4 | Z,ZZZ,ZZ9 |  |
| Put | Total number of put options traded for all Underlying | 5 | Z,ZZZ,ZZ9 |  |
| % Change from Previous Week | (Total volume for this week – Total volume in previous week) / Total volume in previous week for all Underlying | 6 | ±Z,ZZ9.99 |  |
| Put/Call Ratio | Calculation expressing the relationship between put and call options traded for all Underlying | 7 | ±Z,ZZ9.99 |  |
| **Table Title 2** | Specify the title of the second table in the report |  | **OPEN INTEREST OF STOCK OPTIONS** |  |
| Date range | Last trading date of the week | 1 | DD/MM/YYYY |  |
| Class | Underlying + underlying description | 1 |  |  |
| Stock Code | The unique identifier for each stock option. Refer to the Stock Code configured per Underlying | 2 |  |  |
| Total | Number of call options OI + number of put options OI per Underlying | 3 | Z,ZZZ,ZZ9 | Only show the IO of the last trading day of the week |
| Call | Number OI of call options per Underlying | 4 | Z,ZZZ,ZZ9 | Only show the IO of the last trading day of the week |
| Put | Number OI of put options per Underlying | 5 | Z,ZZZ,ZZ9 | Only show the IO of the last trading day of the week |
| % Change from Previous Week | (OI for this week –OI in previous week) / OI in previous week per Underlying | 6 | ±Z,ZZ9.99 |  |
| Put/Call Ratio | Calculation expressing the relationship between put and call options OI per Underlying | 7 | ±Z,ZZ9.99 |  |
| **Market Total** |  |  |  |  |
| Total | Total number of call options OI + Total number of put options OI for all Underlying | 3 | Z,ZZZ,ZZ9 |  |
| Call | Total number OI of call options for all Underlying | 4 | Z,ZZZ,ZZ9 |  |
| Put | Total number OI of put options for all Underlying | 5 | Z,ZZZ,ZZ9 |  |
| % Change from Previous Week | (Total OI for this week – Total OI in previous week) / Total OI in previous week for all Underlying | 6 | ±Z,ZZ9.99 |  |
| Put/Call Ratio | Calculation expressing the relationship between put and call options OI for all Underlying | 7 | ±Z,ZZ9.99 |  |
| **Table Title 3** | Specify the title of the third table in the report |  | **10 MOST ACTIVE INSTRUMENTS BY VOLUME FOR THE WEEK** |  |
| Date range | Specifies the reporting period | 1 | DD/MM/YYYY - DD/MM/YYYY |  |
| **Call Options** | The 10 most volume Call Options Instrument in Stock Options and Weekly Stock Options sort by volume | 1 | **CALL** |  |
| Underlying Code | Underlying Code of the Underlying | 2 | XXX |  |
| Last Trading Day | Last Trading Day of the Instrument | 3 | DD/MM |  |
| Strike Price | Strike Price of the Instrument | 4 | Z,ZZ9.99 |  |
| Volume | Total number of call options traded | 5 | Z,ZZZ,ZZ9 |  |
| **Put Options** | The 10 most volume Put Options Instrument in Stock Options and Weekly Stock Options sort by volume | 1 | **PUT** |  |
| Underlying Code | Underlying Code of the Underlying | 2 | XXX |  |
| Last Trading Day | Last Trading Day of the Instrument | 3 | DD/MM |  |
| Strike Price | Strike Price of the Instrument | 4 | Z,ZZ9.99 |  |
| Volume | Total number of call options traded | 5 | Z,ZZZ,ZZ9 |  |
| **Table Title 4** | Specify the title of the fourth table in the report |  | **VOLUME AND OPEN INTEREST SUMMARY** |  |
| Date | Trading date of the date | 1 |  |  |
| **Volume** |  |  |  |  |
| Total | Total number of call options traded on the date + Total number of put options traded on the date | 2 | Z,ZZZ,ZZ9 | Shown as 0 for non-trading day |
| Call | Total number of call options in Stock Options traded on the date | 3 | Z,ZZZ,ZZ9 | Shown as 0 for non-trading day |
| Put | Total number of put options in Stock Options traded on the date | 4 | Z,ZZZ,ZZ9 | Shown as 0 for non-trading day |
| **Open Interest** |  |  |  |  |
| Total | Total number of call options Open Interest on the date + Total number of put options Open Interest on the date | 5 | Z,ZZZ,ZZ9 | Show previous trading day’s OI for non-trading day |
| Call | Total number of call options in Stock Options Open Interest on the date | 6 | Z,ZZZ,ZZ9 | Show previous trading day’s OI for non-trading day |
| Put | Total number of put options in Stock Options Open Interest on the date | 7 | Z,ZZZ,ZZ9 | Show previous trading day’s OI for non-trading day |

# Daily Trading Admin Reports

## Daily Trading Admin Records Report

#FS10017A\_S0050\_10100

This report prints the current value of records of each Admin Maintain Functions individually from entity table in raw data format.

By default, this report is printed in ascending sequence based on the Key fields (e.g. ID, Code, Name and etc).

### Source of Data

Database

### Operation Flow

Daily **after** the start of the day rollover

### Housekeeping

2 weeks retention period

### Holiday Arrangements

No

### Special handling

Admin GUI is able to trigger this report generation manually

### Report formats

| Row Type Code | Name | Mand / Opt | Description |
| --- | --- | --- | --- |
| 01 | Report ID | M | This row contains the Report ID. Only appears once in a report and on the very first line of a report |
| 02 | Report Header | M | This row contains the report header rows. A report header can have multiple rows, it is possible to have multiple rows containing this type code. |
| 03 | Section Header | O | A report can have one to many sections. Each section shares the same set of data columns.  This row contains the section header (if defined in the corresponding report).  A section header can have multiple rows, it is possible to have multiple rows containing this type code. |
| 04 | Column Header | M | This row contains the column header of the report data. Each section can have one column header. |
| 05 | Data Row | M | This row contains the data record. |
| 06 | Section Footer | O | A report can have one to many sections. Each section shares the same set of data columns.  This row contains the section footer (if defined in the corresponding report).  A section footer can have multiple rows, it is possible to have multiple rows containing this type code. |
| 07 | Report Footer | M | This row contains the report footer rows. A report footer can have multiple rows, therefore it is possible to have multiple rows containing this type code. |
| 99 | End of Report | M | End of the report. This is the very last line in the report. All lines after this line are ignored. |
| # | Comment Line | O | This line is a comment line. The line contents can be ignored. |

### Report Layout

01,,<Report ID>

02,,<Company Name>

02,,<Report Header Name>

02,,DATE: DD/MM/YYYY TIME: HH:MM

03,01,<Section Header> #e.g. Record type name

04,01,<Field Name 1>,< Field Name 2>,< Field Name 3>,…

05,01,<Value 1>,<Value 2>,<Value 3>,…

06,01,Total records,ZZZZZZ9

07,,Total records,ZZZZZZ9

99,,

#### Report Attribute

|  |  |
| --- | --- |
| Purpose | Capture all records of entity daily |
| Frequency | Daily |
| Sequence | Ascending sequence based on the Key fields (e.g. ID, Code, Name and etc). |
| File Name | <Report ID>-<Report Name>.csv |
| Chinese Version (optional) | No |

#### Report Type Setup

NO

#### Field Description

Refer to Admin GUI Attributes tables (Value formatting will be ignored and raw data will be printed into the report only)

## Daily Trading Admin Changes Report

#FS10017A\_S0050\_20100

This report prints the changed records of each Admin Maintain Functions individually from entity table in raw data format.

By default, this report is printed in ascending sequence based on the Key fields (e.g. ID, Code, Name and etc).

### Source of Data

Database

### Operation Flow

Daily **before** the start of the day rollover

### Housekeeping

2 weeks retention period

### Holiday Arrangements

No

### Special handling

Admin GUI is able to trigger this report generation manually

### Report formats

| Row Type Code | Name | Mand / Opt | Description |
| --- | --- | --- | --- |
| 01 | Report ID | M | This row contains the Report ID. Only appears once in a report and on the very first line of a report |
| 02 | Report Header | M | This row contains the report header rows. A report header can have multiple rows, it is possible to have multiple rows containing this type code. |
| 03 | Section Header | O | A report can have one to many sections. Each section shares the same set of data columns.  This row contains the section header (if defined in the corresponding report).  A section header can have multiple rows, it is possible to have multiple rows containing this type code. |
| 04 | Column Header | M | This row contains the column header of the report data. Each section can have one column header. |
| 05 | Data Row | M | This row contains the data record. |
| 06 | Section Footer | O | A report can have one to many sections. Each section shares the same set of data columns.  This row contains the section footer (if defined in the corresponding report).  A section footer can have multiple rows, it is possible to have multiple rows containing this type code. |
| 07 | Report Footer | M | This row contains the report footer rows. A report footer can have multiple rows, therefore it is possible to have multiple rows containing this type code. |
| 99 | End of Report | M | End of the report. This is the very last line in the report. All lines after this line are ignored. |
| # | Comment Line | O | This line is a comment line. The line contents can be ignored. |

### Report Layout

01,,<Report ID>

02,,<Company Name>

02,,<Report Header Name>

02,,DATE: DD/MM/YYYY TIME: HH:MM

03,01,<Section Header> #e.g. Record type name

04,01,<Field Name 1>,< Field Name 2>,< Field Name 3>,…

05,01,<Value 1>,<Value 2>,<Value 3>,…

06,01,Total records,ZZZZZZ9

07,,Total records,ZZZZZZ9

99,,

#### Report Attribute

|  |  |
| --- | --- |
| Purpose | Capture changed records of entity daily |
| Frequency | Daily |
| Sequence | Ascending sequence based on the Key fields (e.g. ID, Code, Name and etc). |
| File Name | <Report ID>-<Report Name>.csv |
| Chinese Version (optional) | No |

#### Report Type Setup

NO

#### Field Description

Refer to Admin GUI Attributes tables (Value formatting will be ignored and raw data will be printed into the report only) along with the following attribute for change detail in each row

| # | Field | Column Heading | Type | Size | Remarks |
| --- | --- | --- | --- | --- | --- |
|  | Request Action | Request Action | Alphanumeric | 10 |  |
|  | Request Status | Request Status | Alphanumeric | 10 |  |
|  | Request Date Time | Request Date Time | Alphanumeric | 20 | DD-MMM-YYYY HH:mm:ss |
|  | Approved Date Time | Approved Date Time | Alphanumeric | 20 | DD-MMM-YYYY HH:mm:ss |
|  | Requester | Requester | Alphanumeric | 64 |  |
|  | Approver | Approver | Alphanumeric | 64 |  |
|  | Receive Date Time | Receive Date Time | Alphanumeric | 20 | DD-MMM-YYYY HH:mm:ss |
|  | Receive Date Time | Input Time | Time | 20 | DD-MMM-YYYY HH:mm:ss |

## Daily Trading Admin Error Report

#FS10017A\_S0050\_30100

This report prints the Pending/Rejected/Failed change request of each Admin Maintain Functions individually from entity table in raw data format.

By default, this report is printed in ascending sequence based on the Key fields (e.g. ID, Code, Name and etc).

### Source of Data

Database

### Operation Flow

Daily **before** the start of the day rollover

### Housekeeping

2 weeks retention period

### Holiday Arrangements

No

### Special handling

Admin GUI is able to trigger this report generation manually

### Report formats

| Row Type Code | Name | Mand / Opt | Description |
| --- | --- | --- | --- |
| 01 | Report ID | M | This row contains the Report ID. Only appears once in a report and on the very first line of a report |
| 02 | Report Header | M | This row contains the report header rows. A report header can have multiple rows, it is possible to have multiple rows containing this type code. |
| 03 | Section Header | O | A report can have one to many sections. Each section shares the same set of data columns.  This row contains the section header (if defined in the corresponding report).  A section header can have multiple rows, it is possible to have multiple rows containing this type code. |
| 04 | Column Header | M | This row contains the column header of the report data. Each section can have one column header. |
| 05 | Data Row | M | This row contains the data record. |
| 06 | Section Footer | O | A report can have one to many sections. Each section shares the same set of data columns.  This row contains the section footer (if defined in the corresponding report).  A section footer can have multiple rows, it is possible to have multiple rows containing this type code. |
| 07 | Report Footer | M | This row contains the report footer rows. A report footer can have multiple rows, therefore it is possible to have multiple rows containing this type code. |
| 99 | End of Report | M | End of the report. This is the very last line in the report. All lines after this line are ignored. |
| # | Comment Line | O | This line is a comment line. The line contents can be ignored. |

### Report Layout

01,,<Report ID>

02,,<Company Name>

02,,<Report Header Name>

02,,DATE: DD/MM/YYYY TIME: HH:MM

03,01,<Section Header> #e.g. Record type name

04,01,<Field Name 1>,< Field Name 2>,< Field Name 3>,…

05,01,<Value 1>,<Value 2>,<Value 3>,…

06,01,Total records,ZZZZZZ9

07,,Total records,ZZZZZZ9

99,,

#### Report Attribute

|  |  |
| --- | --- |
| Purpose | Capture error records of entity daily |
| Frequency | Daily |
| Sequence | Ascending sequence based on the Key fields (e.g. ID, Code, Name and etc). |
| File Name | <Report ID>-<Report Name>.csv |
| Chinese Version (optional) | No |

#### Report Type Setup

NO

#### Field Description

Refer to Admin GUI Attributes tables (Value formatting will be ignored and raw data will be printed into the report only) along with the following attribute for change detail in each row

| # | Field | Column Heading | Type | Size | Remarks |
| --- | --- | --- | --- | --- | --- |
|  | Request Action | Request Action | Alphanumeric | 10 |  |
|  | Request Status | Request Status | Alphanumeric | 10 | Pending/Failed/Rejected |
|  | Request Date Time | Request Date Time | Alphanumeric | 20 | DD-MMM-YYYY HH:mm:ss |
|  | Approved Date Time | Approved Date Time | Alphanumeric | 20 | DD-MMM-YYYY HH:mm:ss |
|  | Requester | Requester | Alphanumeric | 64 |  |
|  | Approver | Approver | Alphanumeric | 64 |  |
|  | Receive Date Time | Receive Date Time | Alphanumeric | 20 | DD-MMM-YYYY HH:mm:ss |
|  | Receive Date Time | Input Time | Time | 20 | DD-MMM-YYYY HH:mm:ss |

## Daily Trading Admin Withdraw Report

#FS10017A\_S0050\_40100

This report prints the withdraw change request of each Admin Maintain Functions individually from entity table in raw data format.

By default, this report is printed in ascending sequence based on the Key fields (e.g. ID, Code, Name and etc).

### Source of Data

Database

### Operation Flow

Daily **before** the start of the day rollover

### Housekeeping

2 weeks retention period

### Holiday Arrangements

No

### Special handling

Admin GUI is able to trigger this report generation manually

### Report formats

| Row Type Code | Name | Mand / Opt | Description |
| --- | --- | --- | --- |
| 01 | Report ID | M | This row contains the Report ID. Only appears once in a report and on the very first line of a report |
| 02 | Report Header | M | This row contains the report header rows. A report header can have multiple rows, it is possible to have multiple rows containing this type code. |
| 03 | Section Header | O | A report can have one to many sections. Each section shares the same set of data columns.  This row contains the section header (if defined in the corresponding report).  A section header can have multiple rows, it is possible to have multiple rows containing this type code. |
| 04 | Column Header | M | This row contains the column header of the report data. Each section can have one column header. |
| 05 | Data Row | M | This row contains the data record. |
| 06 | Section Footer | O | A report can have one to many sections. Each section shares the same set of data columns.  This row contains the section footer (if defined in the corresponding report).  A section footer can have multiple rows, it is possible to have multiple rows containing this type code. |
| 07 | Report Footer | M | This row contains the report footer rows. A report footer can have multiple rows, therefore it is possible to have multiple rows containing this type code. |
| 99 | End of Report | M | End of the report. This is the very last line in the report. All lines after this line are ignored. |
| # | Comment Line | O | This line is a comment line. The line contents can be ignored. |

### Report Layout

01,,<Report ID>

02,,<Company Name>

02,,<Report Header Name>

02,,DATE: DD/MM/YYYY TIME: HH:MM

03,01,<Section Header> #e.g. Record type name

04,01,<Field Name 1>,< Field Name 2>,< Field Name 3>,…

05,01,<Value 1>,<Value 2>,<Value 3>,…

06,01,Total records,ZZZZZZ9

07,,Total records,ZZZZZZ9

99,,

#### Report Attribute

|  |  |
| --- | --- |
| Purpose | Capture withdraw records of entity daily |
| Frequency | Daily |
| Sequence | Ascending sequence based on the Key fields (e.g. ID, Code, Name and etc). |
| File Name | <Report ID>-<Report Name>.csv |
| Chinese Version (optional) | No |

#### Report Type Setup

NO

#### Field Description

Refer to Admin GUI Attributes tables (Value formatting will be ignored and raw data will be printed into the report only) along with the following attribute for change detail in each row

| # | Field | Column Heading | Type | Size | Remarks |
| --- | --- | --- | --- | --- | --- |
|  | Request Action | Request Action | Alphanumeric | 10 |  |
|  | Request Status | Request Status | Alphanumeric | 10 | Pending/Failed/Rejected |
|  | Request Date Time | Request Date Time | Alphanumeric | 20 | DD-MMM-YYYY HH:mm:ss |
|  | Approved Date Time | Approved Date Time | Alphanumeric | 20 | DD-MMM-YYYY HH:mm:ss |
|  | Requester | Requester | Alphanumeric | 64 |  |
|  | Approver | Approver | Alphanumeric | 64 |  |
|  | Receive Date Time | Receive Date Time | Alphanumeric | 20 | DD-MMM-YYYY HH:mm:ss |
|  | Receive Date Time | Input Time | Time | 20 | DD-MMM-YYYY HH:mm:ss |

# User Login Reports

## Daily Trading GUI User Login Report

#FS10017A\_S0060\_10100

This report prints the Trading GUI login user login and logout activity.

By default, this report is printed in ascending sequence based on the state changes time.

### Source of Data

Database

### Operation Flow

Daily **before** the start of the day rollover

### Housekeeping

2 weeks retention period

### Holiday Arrangements

No

### Special handling

Admin GUI is able to trigger this report generation manually

### Report formats

|  |  |  |  |
| --- | --- | --- | --- |
| **Field** | **Type** | **Size** | **Remarks** |
| Participant ID | Alphanumeric | 5 | Exchange Participant ID of the Trading GUI User. |
| User ID | Alphanumeric | 10 | Trading GUI User ID  IDP User ID? |
| Comp ID | Alphanumeric | 10 | Comp ID of the User. |
| Client Status | Numeric | 1 | 1 = Normal  2 = Blocked  3 = Locked  4 = Suspended |
| Connection Status | Numeric | 1 | 0 = Not connected  1 = Logged-on  2 = Disconnected |
| Connection IP | Numeric | 4 | INET address of IP address of client connection. |
| Last State Change Time | Date and Time | 14 | Last change time of client connection state. |

### Report Layout

01,,<Report ID>

02,,<Company Name>

02,,<Report Header Name>

02,,DATE: DD/MM/YYYY TIME: HH:MM

03,01,<Section Header> #e.g. Record type name

04,01,<Field Name 1>,< Field Name 2>,< Field Name 3>,…

05,01,<Value 1>,<Value 2>,<Value 3>,…

06,01,Total records,ZZZZZZ9

07,,Total records,ZZZZZZ9

99,,

#### Report Attribute

|  |  |
| --- | --- |
| Purpose | Capture GUI user login status daily |
| Frequency | Daily |
| Sequence | Ascending sequence based on the state change time |
| File Name | <Report ID>-<Report Name>.csv |
| Chinese Version (optional) | No |

#### Report Type Setup

NO

#### Field Description

Refer to report format

## Daily PTRM GUI User Login Report

#FS10017A\_S0060\_20100

This report prints the PTRM GUI login user login and logout activity.

By default, this report is printed in ascending sequence based on the state changes time.

### Source of Data

Database

### Operation Flow

Daily **before** the start of the day rollover

### Housekeeping

2 weeks retention period

### Holiday Arrangements

No

### Special handling

Admin GUI is able to trigger this report generation manually

### Report formats

|  |  |  |  |
| --- | --- | --- | --- |
| **Field** | **Type** | **Size** | **Remarks** |
| Participant ID | Alphanumeric | 5 | Exchange Participant ID of the PTRM GUI User. |
| User ID | Alphanumeric | 10 | PTRM GUI User ID  IDP User ID? |
| Comp ID | Alphanumeric | 10 | Comp ID of the User. |
| Client Status | Numeric | 1 | 1 = Normal  2 = Blocked  3 = Locked  4 = Suspended |
| Connection Status | Numeric | 1 | 0 = Not connected  1 = Logged-on  2 = Disconnected |
| Connection IP | Numeric | 4 | INET address of IP address of client connection. |
| Last State Change Time | Date and Time | 14 | Last change time of client connection state. |

### Report Layout

01,,<Report ID>

02,,<Company Name>

02,,<Report Header Name>

02,,DATE: DD/MM/YYYY TIME: HH:MM

03,01,<Section Header> #e.g. Record type name

04,01,<Field Name 1>,< Field Name 2>,< Field Name 3>,…

05,01,<Value 1>,<Value 2>,<Value 3>,…

06,01,Total records,ZZZZZZ9

07,,Total records,ZZZZZZ9

99,,

#### Report Attribute

|  |  |
| --- | --- |
| Purpose | Capture GUI user login status daily |
| Frequency | Daily |
| Sequence | Ascending sequence based on the state change time |
| File Name | <Report ID>-<Report Name>.csv |
| Chinese Version (optional) | No |

#### Report Type Setup

NO

#### Field Description

Refer to report format

## Daily/On-demand User Login Report

#FS10017A\_S0060\_30100

### Source of Data

Please refer to ***FS10013 Market Operation Admin GUI,***

* ***Section 4.17.10 Control & Monitor Order Flow Client*** (FS Tag number: #FS10013\_S0417\_07300),
* ***Section 4.17.11 Control & Monitor Drop Copy Client*** (FS Tag number: #FS10013\_S0417\_08300),
* ***Section 4.17.12 Control & Monitor Trading GUI Client*** (FS Tag number: #FS10013\_S0417\_09000) and
* ***Section 4.17.13 Control & Monitor PTRM GUI Client*** (FS Tag number: #FS10013\_S0417\_09700)

for detailed descriptions on source of data.

Operation Flow

Generated on-demand during the day via Trading Admin GUI.

### Housekeeping

Gateway statistics are published in real-time. Housekeeping follows the Gateway and Trading Admin GUI service window.

### Holiday Arrangements

Holiday Arrangements follow the Gateway and Trading Admin GUI service window.

### Special handling

Exchange Business Operations is able to trigger this report generation manually from Trading Admin GUI screens.

### Report formats

CSV format is available for export on-demand.

|  |  |  |  |
| --- | --- | --- | --- |
|  |  |  |  |
|  |  |  |  |

### Report Layout

TBD

#### Report Attribute

|  |  |
| --- | --- |
|  |  |
|  |  |
|  |  |
|  |  |

TBD – This section should be describing about the headers of the report.

#### Report Type Setup

Not Applicable.

#### Field Description

Please refer to ***FS10013 Market Operation Admin GUI,***

* ***Section 4.17.10 Control & Monitor Order Flow Client*** (FS Tag number: #FS10013\_S0417\_07500),
* ***Section 4.17.11 Control & Monitor Drop Copy Client*** (FS Tag number: #FS10013\_S0417\_08500),
* ***Section 4.17.12 Control & Monitor Trading GUI Client*** (FS Tag number: #FS10013\_S0417\_09200) and
* ***Section 4.17.13 Control & Monitor PTRM GUI Client*** (FS Tag number: #FS10013\_S0417\_09900)

for detailed field descriptions.

## Daily/On-demand User List Report

#FS10017A\_S0060\_40100

### Source of Data

Please refer to ***FS10013 Market Operation Admin GUI,***

* ***Section 4.17.8 Order Flow Client Enquiry*** (FS Tag number: #FS10013\_S0417\_05800) and
* ***Section 4.17.9 Drop Copy Client Enquiry*** (FS Tag number: #FS10013\_S0417\_06600)

for detailed descriptions on source of data.

### Operation Flow

Generated on-demand during the day via Trading Admin GUI.

### Housekeeping

Housekeeping follows Trading Admin GUI service window.

### Holiday Arrangements

Holiday Arrangements follow the Gateway and Trading Admin GUI service window.

### Special handling

Exchange Business Operations is able to trigger this report generation manually from Trading Admin GUI screens.

### Report formats

CSV format is available for export on-demand.

|  |  |  |  |
| --- | --- | --- | --- |
|  |  |  |  |
|  |  |  |  |

### Report Layout

TBD

#### Report Attribute

|  |  |
| --- | --- |
|  |  |
|  |  |
|  |  |
|  |  |

TBD – This section should be describing about the headers of the report.

#### Report Type Setup

Not Applicable.

#### Field Description

Please refer to ***FS10013 Market Operation Admin GUI,***

* ***Section 4.17.8 Order Flow Client Enquiry*** (FS Tag number: #FS10013\_S0417\_06000) and
* ***Section 4.17.9 Drop Copy Client Enquiry*** (FS Tag number: #FS10013\_S0417\_06800)

for detailed descriptions on source of data.

Daily Statistics Reports

## Daily Host Report

#FS10017A\_S0070\_10100

Daily Host Report provides Trade statistics on distribution of login connections, number of contracts traded, number of trades and order book changes (OBC) by connection locations, network service providers and types of devices. The daily reports will be distributed to DT users who monitor business activities and assess business risk.

### Source of Data

**Date, User, Connection Type, No. of Trade, Contract Volume** and **OBC** comes from Trading System’s static reference and dynamic transaction data.

The originally requested information such as **Workstation, Location of Connection** and **Network Service Provider** come from sources outside of the Trading System. The Exchange Business Operations team should solicit these details from the relevant data owners and come up with the same view as today’s Daily Hosting Statistics Reports outside the ODP Trading Platform.

Operation Flow

Prepared at day-end via system triggered batch job. Report will be delivered to Exchange Business Operations’ SFTP file servers for retrieval.

### Housekeeping

TBD – Housekeeping follows our Report Generation component and Report Distribution component service window.

### Holiday Arrangements

TBD – Holiday Arrangements follow our Report Generation component and Report Distribution component service window.

### Special handling

Not applicable.

### Report formats

CSV format is available for this report.

|  |  |  |  |
| --- | --- | --- | --- |
|  |  |  |  |
|  |  |  |  |

### Report Layout

TBD

#### Report Attribute

TBD – This section should be describing about the headers of the report.

|  |  |
| --- | --- |
|  |  |
|  |  |
|  |  |
|  |  |

Report Type Setup

Not applicable.

#### Field Description

The following attributes are static reference data from Trading System:

| Column | Type | Length | Default | Remarks |
| --- | --- | --- | --- | --- |
| Date | Date | 11 | - | Date |
| Comp ID | Alphanumeric | 10 | - | Currently in Genium, the attribute was referred to as “Trading Code”, which is composed of Country ID + Customer Information + User ID. Since the purpose of this field is to guarantee uniqueness at per Session/User level, in ODP-T it is suggested to use Comp ID instead. |
| Service Type | Char | 1 | - | O - Order Flow D - Drop Copy R - PTRM |
| Session Usage | Char | 1 | - | D - Direct Access U - UI Access |

The following attributes are dynamic Transaction data from Trading System:

| Column | Type | Length | Default | Remarks |
| --- | --- | --- | --- | --- |
| **No. of Trades  (Traded Count)** | Numeric | 10 (possible value from 0 to 232 – 1) | - | Since Business did not clearly define the logic on how to produce these figures, IT would need to refer to ODP-T Binary Gateway Specifications for the type definitions and the aggregation behaviour on ***Trades (Orders Executed)***. Theoretically speaking, IT could leverage the application log of Gateway to produce these statistics. |
| **Contract Volume (Traded Volume)** | Numeric | 10 (possible value from 0 to 232 – 1) | - | Pending for Business to clarify on the logic to calculate Contract Volume aggregated by per Comp ID. ODP-T has a Trade Statistics Component which will calculate the Traded Volume by per Order Book, and further processing is required to aggregate to per Comp ID level. |
| **Order Book Changes (or in short, OBC)** | Numeric | 10 (possible value from 0 to 232 – 1) | - | Pending for Business to clarify on the logic to calculate Contract Volume aggregated by per Comp ID. The current calculation logic should be aggregating the number of MR3 (Order Book Change Log Transactions) in LogB.  **Do generated implied aggregated quantities count as 1 or multiple OBCs?** |

## HKATS Daily Trading Statistics Report for Hosting Service

## #FS10017A\_S0070\_20100

### Source of Data

TBD

### Operation Flow

TBD

### Housekeeping

TBD

### Holiday Arrangements

TBD

### Special handling

TBD

### Report formats

|  |  |  |  |
| --- | --- | --- | --- |
| **Field** | **Type** | **Size** | **Remarks** |
|  |  |  |  |

### Report Layout

TBD

#### Report Attribute

|  |  |
| --- | --- |
| Purpose | TBD |
| Frequency | Daily |
| Sequence | Ascending sequence based on the state change time |
| File Name | TBD |

#### Report Type Setup

TBD

#### Field Description

TBD

## HKATS Daily Trading Statistics Report by Connection and Device

#FS10017A\_S0070\_30100

### Source of Data

TBD

### Operation Flow

TBD

### Housekeeping

TBD

### Holiday Arrangements

TBD

### Special handling

TBD

### Report formats

|  |  |  |  |
| --- | --- | --- | --- |
| **Field** | **Type** | **Size** | **Remarks** |
|  |  |  |  |

### Report Layout

TBD

#### Report Attribute

|  |  |
| --- | --- |
| Purpose | TBD |
| Frequency | Daily |
| Sequence | Ascending sequence based on the state change time |
| File Name | TBD |

#### Report Type Setup

TBD

#### Field Description

TBD

## Daily Exception Login Report

#FS10017A\_S0070\_40100

### Source of Data

TBD

### Operation Flow

TBD

### Housekeeping

TBD

### Holiday Arrangements

TBD

### Special handling

TBD

### Report formats

|  |  |  |  |
| --- | --- | --- | --- |
| **Field** | **Type** | **Size** | **Remarks** |
|  |  |  |  |

### Report Layout

TBD

#### Report Attribute

|  |  |
| --- | --- |
| Purpose | TBD |
| Frequency | Daily |
| Sequence | Ascending sequence based on the state change time |
| File Name | TBD |

#### Report Type Setup

TBD

#### Field Description

TBD

# Connectivity Monitoring Reports

## CCP Report

#FS10017A\_S0080\_10100

### Source of Data

Gateway log files

### Operation Flow

Scheduled hourly at 08:00, 09:00, 09:45, 10:00, 11:00 from Monday to Friday.

### Housekeeping

only keep for 7 calendar days

### Holiday Arrangements

no Special arrangement for Holiday

### Special handling

Not applicable

### Report formats

Output in csv format

### Report Layout

|  |
| --- |
| Generation date: 17-Feb-2024 15:39:00  Comp ID,IP Address,Login Time,Gateway,Port  XXX1234,XXXW01001,17-Feb-2024 05:39:01,10.161.67.11,35001  YYY4567,XXXW01001,17-Feb-2024 05:47:08,10.161.67.11,35001 |

#### Report Attribute

|  |  |
| --- | --- |
| Purpose | Provide the snapshot of current login Comp ID. |
| Frequency | Daily |
| Sequence | Ascending sequence based on the state change time |
| File Name | ccp\_YYYYMMDD.csv |

#### Report Type Setup

No setup required

#### Field Description

| Field Name | Description | Position in csv | Format | Remarks |
| --- | --- | --- | --- | --- |
| Generation Date | Date time of the report generated | 1 | DD-MMM-YYYY HH:MM:SS |  |
| Comp ID |  | 1 | X(12) |  |
| IP Address | IP Address of the Comp ID connection host | 2 | X(12) |  |
| Login Time | Time when the Comp ID connected to the system | 3 | DD-MMM-YYYY HH:MM:SS |  |
| Gateway | IP Address of the Comp ID connected gateway | 4 | 99.999.99.99 |  |
| Port | Port of the Comp ID connected gateway | 5 | 99999 |  |

## CCP User Report

#FS10017A\_S0080\_20100

### Source of Data

Connection activities logging retrieved from Gateway log files

### Operation Flow

Generated after the start of dayend batch

### Housekeeping

only keep for 7 calendar days

### Holiday Arrangements

no Special arrangement for Holiday

### Special handling

Not applicable

### Report formats

Output in csv format

### Report Layout

|  |
| --- |
| 2025/02/14 08:08:18.656757, 88OFG07:0, CO01828505, 2358, 2, 3, Logout received.  2025/02/14 08:08:18.656764, 88OFG07:0, CO01828505, 2513, 2, 3, Logout session(Responding to the logout message)  2025/02/14 08:11:25.082574, 88DCG03:0, 10.141.53.17:53753, 8109, 0, 2, Connection disconnected  2025/02/14 08:11:36.256293, 88DCG04:0, CC02128001, 8136, 6, 3, First Logon CC02128001 - MktState: 0x3, CliState: 0x11, Rx: 0, NextExpected: 1, Tx: 0, IgnoreInboundMsg: Y, BeingDisconnected: N, Stitch Info: (N, N, N)  2025/02/14 08:11:36.260572, 88DCG04:0, 10.141.53.27:50968, 8104, 0, 3, New connection from FIX\_3:87 - 10.141.53.27:50968. connectionID: 300000087 |

#### Report Attribute

|  |  |
| --- | --- |
| Purpose | To provide the history of user connection activities |
| Frequency | Daily |
| Sequence | Ascending sequence based on the state change time |
| File Name | ccp\_user\_YYYYMMDD\_HHMMSS.csv |

#### Report Type Setup

No setup required

#### Field Description

| Field Name | Description | Position in csv | Format | Remarks |
| --- | --- | --- | --- | --- |
| Event Date time | Date time of the event | 1 | DD-MMM-YYYY HH:MM:SS |  |
| Gateway |  | 2 | X(12) |  |
| User ID | Comp ID for Binary session  Source IP Address for FIX Session | 3 | X(12) |  |
| Event | Logon, Logout and other connection status related events | 4 | X(512) |  |

# PTRM Reports

## PTRM Audit Reports

#FS10017A\_S0009\_10100

A daily report is generated in real-time that logs all actions and events per Sponsoring Participant and Exchange. The audit event will include the time stamp, event type, involved PTLG and user id.

### Source of Data

It captures all events relating to PTRM. The following event types will be shown in the report.

* Add or remove non-base Risk Group
* PTLG parameter updated
* Breach Event Triggered
* Emergency Button executed
* Any order, quote or trade report transaction rejected by max order size and block trade size (first n )

### Operation Flow

Generated daily during the dayend batch

### Housekeeping

Keep the previous day reports

### Holiday Arrangements

No special arrangement for holiday trading

### Report formats

The reports will be in CSV format

### Report Layout

File layout:

| **Line** | **Description** |
| --- | --- |
| First | Header |
| 3+ | Data records |

Sample:

Timestamp,Exchange Participant,Trading Member,PTLG,Category,User,Action,Effective,Item,Old Value,New Value,Event Level,Event Risk Type,Event Order ID,Event Side,Event OrderBookID,Reject Code

20240423-08:16:01.619,HKCMLF,HKCTDMM,HKCMLF\_HKCTDMM\_BASE,Ref Data,P\_CMLF22016,Update,Intraday,PTLG,HKCMLF\_HKCTDMM\_BASE,HKCMLF\_HKCTDMM\_BASE,,,,,,

20240423-08:16:01.619,HKCMLF,HKCTDMM,HKCMLF\_HKCTDMM\_BASE,Ref Data,P\_CMLF22016,Update,Intraday,OPEN\_BUY (HSIFUT),11,922337203685477,,,,,,

#### Report Attribute

|  |  |
| --- | --- |
| Purpose | Audit report for PTRM events |
| Frequency | Daily |
| Sequence | Sorted by Timestamp ascendingly. |
| File Name | RX\_AUDIT\_XXXXX\_YYYYMMDD.HHMMSS.csv  Where XXXXX is the participant ID, YYYYMMDD.HHMMSS is date and time of report. |
| Chinese Version | N/A |

#### Field Description

| **Column** | **Description** | **Value** |
| --- | --- | --- |
| Timestamp | Generation Time | YYYYMMDD-HH:MM:SS |
| Sponsoring Participant | Participant Code | e.g. HKCJPM |
| Sponsoed Participant | Participant Code | e.g. HKJPMMB |
| Risk Group | Risk Group ID | e.g. HKCJPM\_HKJPM\_BASE |
| Category | A Risk Group is Breached | BREACH |
| A Risk Group is Unbreached | UNBREACH |
| Order rejected by PTRM | REJECT |
| Emergency button executed | SUPERVISORY ACTION |
| Parameters update | REF DATA |
| User | The user ID triggered the audit event | e.g. KGI161 will be recorded, if it sent an order to breach a Risk Check or the order rejected by PTRM. P\_CKGI1234 will be recoreded if it executed the emergency button or updated a parameter |
| Action | Record "UPDATE" when it is a parameter update | UPDATE |
| Effective | The effective day of the event | INTRADAY or TOMORROW |
| Item | A Risk Group is breached or Unbreached | Blank due to not applicable for this event |
| Order rejected by PTRM | Blank due to not applicable for this event |
| Emergency button executed | STOP |
| UNSTOP |
| MASS CANCEL |
| Parameters update | Risk Check Parameter (Tradable if applicable) e.g.  NET\_FUTURES\_LONG OPEN\_BUY (HSIF) |
| Old Value | Value before update, only applicable to Parameters update Category | 0 to 922337203685477 |
| New Value | Value after update, only applicable to Parameters update Category | e.g. MAX\_BLOCK\_TRADE\_SIZE OPEN\_BUY (HSIF) |
| Event Level | Only applicable when the Risk Group is breached | BREACH |
| Event Risk Check | The breached Risk Check Type. Only applicable when the Risk Group is breached | e.g. BLOCK\_TRADE\_BOUGHT GROSS\_FUTURES\_LONG\_PER\_TIME |
| Event Order ID | The order ID triggered the breach event.  Only applicable when the Risk Group is breached | Order ID |
| Event Side | The bid or ask side of the order triggered the breach event.  Only applicable when the Risk Group is breached | BUY or SELL |
| Instrument Name | Instrument name of the order triggered the breach event.  Only applicable when the Risk Group is breached | e.g. HSIZ3 |
| Reject Code | Reject reason to reject the order Only applicable for REJECT category | e.g. RX\_PRETRADE\_USER\_BLOCKED |

## PTRM Util Reports

#FS10017A\_S0090\_20100

A daily reports generates the utilization statistic of risk limits for each PTLG. The report is generated per Sponsoring Participant and Exchange in dayend state.

### Source of Data

For each risk check, the following utilization will be shown in the report.

* Maximum value of the day
* The timestamp of the order to hit the maximum value occurred
* The percentage of the maximum utilization in the risk check limit
* For Position Limit, Order Size, and Block Trade limits, the utilization is shown in each parameter limit per tradable.

### Operation Flow

Generated daily during the dayend batch

### Housekeeping

Keep the previous day reports

### Holiday Arrangements

No special arrangement for holiday trading

### Report formats

The reports will be in CSV format

### Report Layout

File layout:

| **Line** | **Description** |
| --- | --- |
| First | Header |
| 3+ | Data records |

Sample:

Timestamp,Exchange Participant,Trading Member,PTLG,Tradeable/RiskGroup,RiskType,Max Utilization,Max Utilization %,Max Utilization Time

20241114-03:22:01.131,HKCORN,HKORNMA,HKCORN\_HKORNMA\_BASE,HSIF,MAX\_SIZE,1,1%,20241113-10:10:36.746

20241114-03:22:01.131,HKCORN,HKORNMA,HKCORN\_HKORNMA\_BASE,HHIF,MAX\_SIZE,2,1.4%,20241113-09:30:39.746

20241114-03:22:01.131,HKCORN,HKORNMA,HKCORN\_HKORNMA\_BASE,MHIFUT,MAX\_SIZE,0,0%,N/A

20241114-03:22:01.131,HKCORN,HKORNMA,HKCORN\_HKORNMA\_BASE,HTIFUT,MAX\_SIZE,2,0.9%,20241113-09:51:12.739

20241114-03:22:01.131,HKCORN,HKORNMA,HKCORN\_HKORNMA\_BASE,MCHFUT,MAX\_SIZE,0,0%,N/A

20241114-03:22:01.131,HKCORN,HKORNMA,HKCORN\_HKORNMA\_BASE,MCAFUT,MAX\_SIZE,4,1.3%,20241113-16:24:41.937

20241114-03:22:01.131,HKCORN,HKORNMA,HKCORN\_HKORNMA\_BASE,HSIF,MAX\_BLOCK\_TRADE\_SIZE,0,0%,N/A

20241114-03:22:01.131,HKCORN,HKORNMA,HKCORN\_HKORNMA\_BASE,HHIF,MAX\_BLOCK\_TRADE\_SIZE,0,0%,N/A

20241114-03:22:01.131,HKCORN,HKORNMA,HKCORN\_HKORNMA\_BASE,MHIFUT,MAX\_BLOCK\_TRADE\_SIZE,0,0%,N/A

20241114-03:22:01.131,HKCORN,HKORNMA,HKCORN\_HKORNMA\_BASE,HTIFUT,MAX\_BLOCK\_TRADE\_SIZE,0,0%,N/A

20241114-03:22:01.131,HKCORN,HKORNMA,HKCORN\_HKORNMA\_BASE,MCHFUT,MAX\_BLOCK\_TRADE\_SIZE,0,0%,N/A

20241114-03:22:01.131,HKCORN,HKORNMA,HKCORN\_HKORNMA\_BASE,MCAFUT,MAX\_BLOCK\_TRADE\_SIZE,0,0%,N/A

#### Report Attribute

|  |  |
| --- | --- |
| Purpose | Utilization report for PTRM events |
| Frequency | Daily |
| Sequence | Sorted by Timestamp ascendingly. |
| File Name | RX\_UTIL\_XXXXX\_YYYYMMDD.HHMMSS.csv  Where XXXXX is the participant ID, YYYYMMDD.HHMMSS is date and time of report. |
| Chinese Version | N/A |

#### Field Description

| **Column** | **Description** | **Value** |
| --- | --- | --- |
| Timestamp | Generation Time | YYYYMMDD-HH:MM:SS |
| Sponsoring Participant | Participant Code | e.g. HKCJPM |
| Sponsored Participant | Participant Code | e.g. HKJPMMB |
| Risk Group | Risk Group ID | e.g. HKCJPM\_HKJPM\_BASE |
| Risk Check Level | Position Limit | Shows in Tradable ID. E.g. HSIF, SOMC |
| Block Trade Limit |
| Order Size |
| Block Trade |
| Order Rate | Shows as GROUP |
| Intraday Exposure |
| Execution Throttle Exposure |
| Order Exposure Reference |
| Risk Check | Parameters in Order Rate | ORDER\_RATE |
| Parameters in Intraday Exposure | GROSS\_FUTURES\_LONG |
| GROSS\_FUTURES\_SHORT |
| GROSS\_OPTIONS\_LONG |
| GROSS\_OPTIONS\_SHORT |
| NET\_FUTURES\_LONG |
| NET\_FUTURES\_SHORT |
| NET\_OPTIONS\_LONG |
| NET\_OPTIONS\_SHORT |
| Parameters in Execution Throttle Exposure | GROSS\_FUTURES\_LONG\_PER\_TIME |
| GROSS\_FUTURES\_SHORT\_PER\_TIME |
| GROSS\_OPTIONS\_LONG\_PER\_TIME |
| GROSS\_OPTIONS\_SHORT\_PER\_TIME |
| Parameters in Order Exposure Reference | OPEN\_GROSS\_FUTURES\_LONG |
| OPEN\_GROSS\_FUTURES\_SHORT |
| OPEN\_GROSS\_OPTIONS\_LONG |
| OPEN\_GROSS\_OPTIONS\_SHORT |
| Parameters in Position Limit | OPEN\_BUY |
| OPEN\_SELL |
| ORDER\_RATE |
| RiskType |
| TOTAL\_BUY |
| TOTAL\_NET\_BUY |
| TOTAL\_NET\_SELL |
| TOTAL\_SELL |
| TRADED\_BOUGHT |
| TRADED\_NET |
| TRADED\_SOLD |
| Parameters in Block Trade Limit | BLOCK\_TRADE\_BOUGHT |
| BLOCK\_TRADE\_SOLD |
| Parameters in Block Trade Size | MAX\_BLOCK\_TRADE\_SIZE |
| Parameters in Order Size | MAX\_SIZE |
| Max Utilization | The maximum value from SOD to EOD | 0 to 922337203685477 |
| Max Utilization % | % | 0 to 100% |
| Max Utilization Time | The maximum value happening time | HH:MM:SS or N/A if the utilization is 0 |

# Volatility Control Mechanism (Derivative Market) Cooling-off Period Trigger History

#FS10017A\_S0100\_10100

### Source of Data

Notification message when VCM is triggered.
Refer to #FS10004\_S0060\_02800

### Operation Flow

A process will monitor notifications. When a VCM notification message is triggered by any instrument, it will capture the information in the message and compile it into a CSV format, which can then be transformed into an HTML format.

### Housekeeping

The records will keep 1 year.

### Holiday Arrangements

No special arrangement for Holiday Trading.

### Special handling

N/A

### Report formats

It will be output in csv format

### Report Layout

|  |
| --- |
| Date,Contract,Cooling-off Period Start Time and End Time,Reference Price,Lower Limit,Upper Limit  08 Oct 2024,HTIV4,10:35:49 - 10:40:49,4865,4622,5108  08 Oct 2024,HTIX4,10:35:43 - 10:40:43,4900,4655,5145  08 Oct 2024,HTIX4,09:34:30 - 10:39:30,5321,5055,5587 |

#### Report Attribute

|  |  |
| --- | --- |
| Purpose | For the dedicated webpage for storing the records of VCM trigger history |
| Frequency | Triggered by the VCM is triggered |
| Sequence | Order by Date, Cooling-off Period Start Time |
| File Name | Vcm\_cooloffperiod\_yyyymmdd.csv |

#### Report Type Setup

No setup required

#### Field Description

| Field Name | Description | Position in csv | Format | Remarks |
| --- | --- | --- | --- | --- |
| Date | Date of the VCM triggered | 1 | DD-MMM-YYYY | Refer to the system date received the VCM notification message |
| Contract | The Instrument triggered VCM | 2 | X(12) | Refer to instrument concerned in the VCM notification message |
| Cooling-off Period Start Time and End Time | Start time and end time of the VCM cool-off period | 3 | HH:MM:SS - HH:MM:SS | Refer to VCM trigger time and end time of the cooling-off period in the VCM notification message |
| Reference Price | Reference price that triggered the VCM | 4 | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or  ZZZ9.99 | Refer to the VCM reference price in the VCM notification message |
| Lower Limit | Lower price limit during the cool off period | 5 | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or  ZZZ9.99 | Refer to the VCM lower price limit in the VCM notification message |
| Upper Limit | Upper price limit during the cool off period | 6 | Z,ZZZ,ZZ9 or  ZZZ,ZZ9 or  ZZ,ZZ9.99 or  Z,ZZ9.99 or  ZZZ9.99 | Refer to the VCM upper price limit in the VCM notification message |

# APPENDIX A – Report Type mapping with current Market Code for Daily Market Report

|  |  |  |
| --- | --- | --- |
| **Market code** | **Description** | **Report Type** |
| HIBOR | HIBOR Future | 3.7.8 Indices Futures for Indices, Hibo, T-Bond, Dividend and Commodity |
| VHSF | VHS Future | 3.7.8 Indices Futures for Indices, Hibo, T-Bond, Dividend and Commodity |
| CHHF | CES China 120 index Future | 3.7.8 Indices Futures for Indices, Hibo, T-Bond, Dividend and Commodity |
| CUSO | RMB Curreny Option | 3.7.10 Indices / Currency Options |
| STOCK | Stock Futures | 3.7.7 Stock Futures |
| DQE | Stock Options | 3.7.9 Stock Options |
| XHSO | Flexible HSI Options | 3.7.11 Flexible Indices Options |
| XHIO | Flexible HHI Options | 3.7.11 Flexible Indices Options |
| BONDF | Bond Futures | 3.7.8 Indices Futures for Indices, Hibo, T-Bond, Dividend and Commodity |
| DIVIDEND | Dividend Future | 3.7.8 Indices Futures for Indices, Hibo, T-Bond, Dividend and Commodity |
| SECTIDXF | Sector Indices Futures | 3.7.8 Indices Futures for Indices, Hibo, T-Bond, Dividend and Commodity |
| MTWO | MSCI Taiwan (USD) Index Options | 3.7.10 Indices / Currency Options 3.7.12 Tailor-Made Combination |
| HTIO | Hang Seng Tech Index Option | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) |
| MCSF | Mini USD/CNH Futures | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) |
| CINF | Cash-Settled INR/CNH Futures | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) |
| UINF | Cash-Settled INR/USD Futures | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) |
| CUSF | RMB Currency Future | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) |
| GDUF | USD Gold Futures | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) |
| GDRF | CNH Gold Futures | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) |
| SIUF | USD Silver Futures | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) |
| SIRF | CNH Silver Futures | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) |
| MXJF | MSCI AC Asia ex Japan Net Total Return Index Futures | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) |
| IRONF | TSI IRON ORE 62% - CFR CHINA INDEX Future | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) |
| TRIF | HSCEI TRI Index Futures | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) |
| MWNF | MSCI Taiwan Net Total Return (USD) Index Futures | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) |
| MJUF | MSCI Japan Net Total Return (USD) Index Futures | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) |
| MINF | MSCI India Net Total Return (USD) Index Futures | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) |
| MDNF | MSCI Indonesia Net Total Return (USD) Index Futures | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) |
| MANF | MSCI Australia Net Total Return (USD) Index Futures | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) |
| MTNF | MSCI Thailand Net Total Return (USD) Index Futures | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) |
| MMNF | MSCI Malaysia Net Total Return (USD) Index Futures | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) |
| EANF | MSCI EM Asia Net Total Return (USD) Index Futures | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) |
| MSGF | MSCI Singapore Free (SGD) Index Futures | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) |
| MSNF | MSCI Singapore Net Total Return (USD) Index Futures | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) |
| MVNF | MSCI Vietnam Net Total Return (USD) Index Futures | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) |
| MHKF | MSCI Hong Kong Net Total Return (USD) Index Futures | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) |
| MPNF | MSCI Philippines Net Total Return (USD) Index Futures | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) |
| MIAF | MSCI Indonesia Index (USD) Futures | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) |
| EMNF | MSCI Emerging Markets Net Total Return (USD) Index Futures | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) |
| MEIF | MSCI Emerging Markets (USD) Index Futures | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) |
| TWPF | MSCI Taiwan an 25/50 (USD) Index Futures | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) |
| TWNF | MSCI Taiwan an 25/50 Net Total Return (USD) Index Futures | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) |
| MNDF | MSCI India (USD) Index Futures | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) |
| MTDF | MSCI Thailand (USD) Index Futures | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) |
| MMAF | MSCI Malaysia (USD) Index Futures | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) |
| MPSF | MSCI Philippines (USD) Index Futures | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) |
| MVIF | MSCI Vietnam (USD) Index Futures | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) |
| MGNF | MSCI Singapore Free Net Total Return (USD) Index Futures | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) |
| MNZF | MSCI New Zealand Net Total Return (USD) Index Futures | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) |
| HGTF | HHI TRI Index Futures | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) |
| MCAF | MSCI China A 50 Connect (USD) Index Futures | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) |
| CHNF | MSCI China Net Total Return (USD) Index Futures | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) |
| CHIF | MSCI China (USD) Index Futures | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) |
| MXCF | MSCI EM ex China Net Total Return (USD) Index Futures | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) |
| MXKF | MSCI EM ex Korea Net Total Return (USD) Index Futures | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) |
| MACF | MSCI EM Asia ex China Net Total Return (USD) Index Futures | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) |
| MAKF | MSCI EM Asia ex Korea Net Total Return (USD) Index Futures | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) |
| MEEF | MSCI EM EMEA Net Total Return (USD) Index Futures | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) |
| MELF | MSCI EM LatAm Net Total Return (USD) Index Futures | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) |
| MPCF | MSCI Pacific Net Total Return (USD) Index Futures | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) |
| MPJF | MSCI Pacific ex Japan Net Total Return (USD) Index Futures | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) |
| MTWF | MSCI Taiwan (USD) Index Futures | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) 3.7.12 Tailor-Made Combination |
| HSIF | Hang Seng Index Future | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) 3.7.3 Day Trading Session Reports - Tailor-made Combination 3.7.6 Night Trading Session Reports - Tailor-made Combination |
| MHIF | Mini-Hang Seng Index Future | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) 3.7.3 Day Trading Session Reports - Tailor-made Combination 3.7.6 Night Trading Session Reports - Tailor-made Combination |
| HHIF | Hang Seng China Enterprises Index Future | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) 3.7.3 Day Trading Session Reports - Tailor-made Combination 3.7.6 Night Trading Session Reports - Tailor-made Combination |
| HTIF | Hang Seng Tech Index Futures | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) 3.7.3 Day Trading Session Reports - Tailor-made Combination 3.7.6 Night Trading Session Reports - Tailor-made Combination |
| MCHF | Mini-Hang Seng China Enterprises Index Future | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) 3.7.3 Day Trading Session Reports - Tailor-made Combination 3.7.6 Night Trading Session Reports - Tailor-made Combination |
| LMEF | CNH London Metal Mini Future (LME) | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) |
| LMEUF | USD London Metal Mini (LUA) | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) |
| CRMBCF | Cash-Settled RMB Currency Futures | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) |
| UCNF | Cash-Settled CNH/USD Futures | 3.7.1 Day Trading Session Reports - Futures (Single / multiple Classes) 3.7.4 Night Trading Session Reports - Futures (single / multiple Classes) |
| HSIO | Hang Seng Index Options | 3.7.2 Day Trading Session Reports – (Weekly) Indices Options 3.7.5 Night Trading Session Reports – (Weekly) Indices Options |
| MHIO | Mini-Hang Seng Index Option | 3.7.2 Day Trading Session Reports – (Weekly) Indices Options 3.7.5 Night Trading Session Reports – (Weekly) Indices Options |
| HHIO | Hang Seng China Enterprises Index Option | 3.7.2 Day Trading Session Reports – (Weekly) Indices Options 3.7.5 Night Trading Session Reports – (Weekly) Indices Options |
| MCHO | Mini-Hang Seng China Enterprises Index Option | 3.7.2 Day Trading Session Reports – (Weekly) Indices Options 3.7.5 Night Trading Session Reports – (Weekly) Indices Options |
| PTEO | Hang Seng TECH Index Futures Options | 3.7.2 Day Trading Session Reports – (Weekly) Indices Options 3.7.5 Night Trading Session Reports – (Weekly) Indices Options 3.7.3 Day Trading Session Reports - Tailor-made Combination 3.7.6 Night Trading Session Reports - Tailor-made Combination |
| PHSO | Hang Seng Index Futures Options | 3.7.2 Day Trading Session Reports – (Weekly) Indices Options 3.7.5 Night Trading Session Reports – (Weekly) Indices Options 3.7.3 Day Trading Session Reports - Tailor-made Combination 3.7.6 Night Trading Session Reports - Tailor-made Combination |
| PHHO | Hang Seng China Enterprises Index Futures Options | 3.7.2 Day Trading Session Reports – (Weekly) Indices Options 3.7.5 Night Trading Session Reports – (Weekly) Indices Options 3.7.3 Day Trading Session Reports - Tailor-made Combination 3.7.6 Night Trading Session Reports - Tailor-made Combination |
| HSIWO | Weekly Hang Seng Index Options | 3.7.2 Day Trading Session Reports – (Weekly) Indices Options 3.7.5 Night Trading Session Reports – (Weekly) Indices Options 3.7.3 Day Trading Session Reports - Tailor-made Combination 3.7.6 Night Trading Session Reports - Tailor-made Combination |
| HHIWO | Weekly Hang Seng China Enterprises Index Options | 3.7.2 Day Trading Session Reports – (Weekly) Indices Options 3.7.5 Night Trading Session Reports – (Weekly) Indices Options 3.7.3 Day Trading Session Reports - Tailor-made Combination 3.7.6 Night Trading Session Reports - Tailor-made Combination |

# APPENDICES B – Report samples in Chinese version for Daily Market Report

港元利率期貨每日市場報告

香港交易及結算所有限公司及/或其附屬公司竭力確保其提供之資料準確可靠，惟不保證該等資料絕對正確，

亦不對由於任何資料不確或遺漏所引起之損失或損害負上責任(不論是民事侵權行為責任或合約責任或其他)。

交易所的交易日 交易所的前交易日

2009 年 6 月 16 日, 星期二 2009 年 6 月 15 日, 星期一

HB1 - 一個月港元利率期貨每基點港元$125.00

合約價值 = 港元$15,000,000

合約月份 \*開市 \*全日最高 \*全日最低 結算價 結算價變動 \*合約最高 \*合約最低 成交量 未平倉合約 未平倉合約變動

09 年 06 月 已 到 期 0 0

09 年 07 月 0.00 0.00 0.00 99.80 0.00 99.77 99.77 0 5 +5

…

…

09 年 12 月 0.00 0.00 0.00 99.97 - 0.00 0.00 0 - -

總計 0 10 +10

HB3 - 三個月港元利率期貨每基點港元$125.00

合約價值 = 港元$5,000,000

合約月份 \*開市 \*全日最高 \*全日最低 結算價 結算價變動 \*合約最高 \*合約最低 成交量 未平倉合約 未平倉合約變動

09 年 06 月 已 到 期 843 0

09 年 07 月 0.00 0.00 0.00 99.62 0.00 99.50 99.50 0 20 0

…

…

11 年 06 月 0.00 0.00 0.00 99.09 - 0.00 0.00 0 - -

總計 8 1374 +3

所有合約總計 8 1384 +13

HB1 - 一個月港元利率期貨

合約月份 策略 開市 全日最高 全日最低 成交量

12 年 03 月/12 年 04 月 跨期組合 0.00 0.00 0.00 0

12 年 03 月/12 年 05 月 跨期組合 0.00 0.00 0.00 0

…

…

12 年 06 月/12 年 08 月 跨期組合 0.00 0.00 0.00 0

12 年 07 月/12 年 08 月 跨期組合 0.00 0.00 0.00 0

總計 0

HB3 - 三個月港元利率期貨

合約月份 策略 開市 全日最高 全日最低 成交量

12 年 03 月/12 年 03 月 跨期組合 0.00 0.00 0.00 0

12 年 03 月/12 年 04 月 跨期組合 0.00 0.00 0.00 0

12 年 03 月/12 年 05 月 跨期組合 0.00 0.00 0.00 0

…

…

13 年 09 月/13 年 12 月 跨期組合 0.00 0.00 0.00 0

總計 0

所有策略總計 0

\*\*\*　全表完 \*\*\*

\*不包括跨期對跨期及港元利率疊期買賣交易

恒生指數期貨每日市場報告 (附載即日之未平倉合約)

香港交易及結算所有限公司及/或其附屬公司竭力確保其提供之資料準確可靠，惟不保證該等資料絕對正確，

亦不對由於任何資料不確或遺漏所引起之損失或損害負上責任(不論是民事侵權行為責任或合約責任或其他)。

HHI - 恒生指數期貨每指數點港元$50

交易所的前交易日 交易所的交易日

2018 年 5 月 30 日, 星期三 2018 年 5 月 31 日, 星期四

收市後交易時段 | 即日交易時段 | 合併全日交易資料

| |

合約月份 \*開市 \*全日最高 \*全日最低 \*最後成交 成交量 | \*開市 \*全日最高 \*全日最低 成交量 結算價 結算價變動 | \*合約最高 \*合約最低 成交量 未平倉合約 未平倉合約變動

| |

18 年 05 月 已 | 到 期 | 0 -927

18 年 06 月 0 0 0 0 0 | 31,820 31,839 31,820 3 31,624 +1 | 34,508 31,131 3 207 +3

18 年 07 月 - - - - - | 31,839 31,851 31,839 2 31,146 - | 31,851 31,839 2 2 -

18 年 09 月 0 0 0 0 0 | 31,870 31,870 31,870 1 31,373 +1 | 34,597 31,306 1 140 +1

18 年 12 月 0 0 0 0 0 | 31,855 31,855 31,855 1 30,700 +1 | 31,855 31,855 1 1 +1

19 年 12 月 0 0 0 0 0 | 0 0 0 0 30,378 +1 | 33,320 33,320 0 15 0

20 年 12 月 0 0 0 0 0 | 0 0 0 0 30,001 +1 | 0 0 0 0 0

21 年 12 月 0 0 0 0 0 | 0 0 0 0 29,973 +1 | 34,500 34,100 0 10 0

22 年 12 月 0 0 0 0 0 | 0 0 0 0 32,956 +1 | 34,050 33,050 0 10 0

23 年 12 月 0 0 0 0 0 | 32,830 32,830 32,830 1 29,379 +1 | 32,830 32,830 1 1 +1

所有合約總計 8 386 -921

交易所的交易日

2018 年 5 月 31 日, 星期四

即日交易時段

合約月份 策略 開市 全日最高 全日最低 成交量

18 年 06 月/18 年 07 月 跨期組合 0 0 0 0

18 年 06 月/18 年 09 月 跨期組合 0 0 0 0

18 年 06 月/18 年 12 月 跨期組合 0 0 0 0

18 年 07 月/18 年 09 月 跨期組合 0 0 0 0

18 年 07 月/18 年 12 月 跨期組合 0 0 0 0

18 年 09 月/18 年 12 月 跨期組合 0 0 0 0

所有策略總計 0

\*\*\*　全表完 \*\*\*

\*不包括跨期對跨期買賣交易

恒生指數期貨收市後交易活動摘要

香港交易及結算所有限公司及/或其附屬公司竭力確保其提供之資料準確可靠，惟不保證該等資料絕對正確，

亦不對由於任何資料不確或遺漏所引起之損失或損害負上責任(不論是民事侵權行為責任或合約責任或其他)。

HHI - 恒生指數期貨每指數點港元$50

交易所的交易日

2018 年 4 月 11 日, 星期三

收市後交易時段

合約月份 \*開市 \*全日最高 \*全日最低 \*最後成交 成交量

18 年 04 月 30,897 31,086 30,788 30,960 40,653

18 年 05 月 30,747 30,906 30,629 30,850 82

18 年 06 月 30,619 30,780 30,526 30,702 54

18 年 09 月 30,244 30,450 30,215 30,330 19

18 年 12 月 0 0 0 0 0

19 年 12 月 0 0 0 0 0

20 年 12 月 0 0 0 0 0

21 年 12 月 0 0 0 0 0

22 年 12 月 0 0 0 0 0

所有合約總計 40,808

合約月份 策略 開市 全日最高 全日最低 成交量

18 年 04 月/18 年 05 月 跨期組合 0 0 0 0

18 年 04 月/18 年 06 月 跨期組合 0 0 0 0

18 年 04 月/18 年 09 月 跨期組合 0 0 0 0

18 年 05 月/18 年 06 月 跨期組合 0 0 0 0

18 年 05 月/18 年 09 月 跨期組合 0 0 0 0

18 年 06 月/18 年 09 月 跨期組合 0 0 0 0

所有策略總計 0

\*\*\*　全表完 \*\*\*

\*不包括跨期對跨期買賣交易

恒生指數期權每日市場報告 (附載即日之未平倉合約)

香港交易及結算所有限公司及/或其附屬公司竭力確保其提供之資料準確可靠，惟不保證該等資料絕對正確，

亦不對由於任何資料不確或遺漏所引起之損失或損害負上責任(不論是民事侵權行為責任或合約責任或其他)。

十大成交(按成交量) 成交量 正式收市價 引申波幅% 全日最高 全日最低 未平倉合約 正式收市價變動

18 年 06 月 30000 認沽 1 511 33 550 550 0 -18

恒生指數期權 每指數點港元$50

交易所的前交易日 交易所的交易日

2018 年 5 月 30 日, 星期三 2018 年 5 月 31 日, 星期四

收市後交易時段 | 即日交易時段 | 合併全日交易資料

| |

合約月份 行使價 \*開市 \*全日最高 \*全日最低 正式收市價 成交量 | \*開市 \*全日最高 \*全日最低 結算價 結算價變動 引申波幅% 成交量 | \*合約最高 \*合約最低 成交量 未平倉合約 未平倉合約變動

18 年 06 月 14400 認購 0 0 0 0 0 | 0 0 0 17224 +1 0 0 | 1555 1500 0 445 0

18 年 06 月 15000 認購 0 0 0 0 0 | 0 0 0 16624 +1 0 0 | 0 0 0 85 0

…

…

18 年 06 月 38000 認購 - - - - -1 | 0 0 0 15 - 30 0 | 0 0 0 0 -

認購總計 0 | 認購總計 0 | 認購總計 0 1580 0

合約月份 行使價 \*開市 \*全日最高 \*全日最低 正式收市價 成交量 | \*開市 \*全日最高 \*全日最低 結算價 結算價變動 引申波幅% 成交量 | \*合約最高 \*合約最低 成交量 未平倉合約 未平倉合約變動

18 年 06 月 14400 認沽 0 0 0 0 0 | 0 0 0 1 0 89 0 | 0 0 0 0 0

18 年 06 月 15000 認沽 0 0 0 0 0 | 0 0 0 1 0 84 0 | 0 0 0 0 0

18 年 06 月 38000 認沽 - - - - -1 | 0 0 0 6391 - 30 0 | 0 0 0 0 -

認沽總計 0 | 認沽總計 1 | 認沽總計 1 0 0

| 合約月份認沽/認購比率 --------

| 合約月份總計 1 1580 0

合約月份 行使價 \*開市 \*全日最高 \*全日最低 正式收市價 成交量 | \*開市 \*全日最高 \*全日最低 結算價 結算價變動 引申波幅% 成交量 | \*合約最高 \*合約最低 成交量 未平倉合約 未平倉合約變動

23 年 12 月 24000 認購 - - - - -1 | 0 0 0 13827 - 45 0 | 0 0 0 0 -

23 年 12 月 24400 認購 - - - - -1 | 0 0 0 13589 - 45 0 | 0 0 0 0 -..

..

23 年 12 月 36800 認購 - - - - -1 | 0 0 0 6344 - 31 0 | 0 0 0 0 -

認購總計 0 | 認購總計 0 | 認購總計 0 0 0

合約月份 行使價 \*開市 \*全日最高 \*全日最低 正式收市價 成交量 | \*開市 \*全日最高 \*全日最低 結算價 結算價變動 引申波幅% 成交量 | \*合約最高 \*合約最低 成交量 未平倉合約 未平倉合約變動

23 年 12 月 24000 認沽 - - - - -1 | 0 0 0 8448 - 45 0 | 0 0 0 0 -

23 年 12 月 24400 認沽 - - - - -1 | 0 0 0 8610 - 45 0 | 0 0 0 0 -..

..

23 年 12 月 36800 認沽 - - - - -1 | 0 0 0 13765 - 31 0 | 0 0 0 0 -

認沽總計 0 | 認沽總計 0 | 認沽總計 0 0 0

| 合約月份認沽/認購比率 --------

| 合約月份總計 0 0 0

市場認沽/認購比率 --------

市場總計 1 2068 0

\*\*\* 全表完 \*\*\*

\*不包括組合對組合買賣交易

小型恒生中國企業指數期權每日市場報告

香港交易及結算所有限公司及/或其附屬公司竭力確保其提供之資料準確可靠，惟不保證該等資料絕對正確，

亦不對由於任何資料不確或遺漏所引起之損失或損害負上責任(不論是民事侵權行為責任或合約責任或其他)。

小型恒生中國企業指數期權每指數點港元$10

交易所的交易日

2018 年 4 月 11 日, 星期三

合約月份 行使價 開市 全日最高 全日最低 正式收市價 正式收市價變動 引申波幅% 成交量 未平倉合約 未平倉合約變動

18 年 04 月 9400 認購 0 0 0 2914 -25 0 0 0 0

18 年 04 月 9500 認購 0 0 0 2814 -25 0 0 0 0

…

…

18 年 04 月 16600 認購 0 0 0 1 0 50 0 1 0

認購總計 768 1538 +19

合約月份 行使價 開市 全日最高 全日最低 正式收市價 正式收市價變動 引申波幅% 成交量 未平倉合約 未平倉合約變動

18 年 04 月 9400 認沽 0 0 0 1 0 47 0 1 0

18 年 04 月 9500 認沽 0 0 0 1 0 45 0 4 0

…

…

18 年 04 月 16600 認沽 0 0 0 4286 +25 0 0 0 0

認沽總計 516 1247 +175

合約月份認沽/認購比率 0.67 合約月份總計 1284 2785 +194

合約月份 行使價 開市 全日最高 全日最低 正式收市價 正式收市價變動 引申波幅% 成交量 未平倉合約 未平倉合約變動

18 年 09 月 8600 認購 0 0 0 3440 -16 31 0 0 0

18 年 09 月 8800 認購 0 0 0 3252 -14 30 0 0 0

…

…

18 年 09 月 17000 認購 0 0 0 3 -1 19 0 16 0

認購總計 0 101 0

合約月份 行使價 開市 全日最高 全日最低 正式收市價 正式收市價變動 引申波幅% 成交量 未平倉合約 未平倉合約變動

18 年 09 月 8600 認沽 0 0 0 56 +9 31 0 1 0

18 年 09 月 8800 認沽 0 0 0 68 +12 30 0 1 0

…

…

18 年 09 月 17000 認沽 0 0 0 5017 +24 19 0 0 0

認沽總計 0 91 0

合約月份認沽/認購比率 ---------- 合約月份總計 0 192 0

市場認沽/認購比率 0.59 市場總計 1894 5710 +488

\*\*\* 全表完 \*\*\*

不包括組合對組合買賣交易

自訂條款恒生指數期權每日市場報告

香港交易及結算所有限公司及/或其附屬公司竭力確保其提供之資料準確可靠，惟不保證該等資料絕對正確，

亦不對由於任何資料不確或遺漏所引起之損失或損害負上責任(不論是民事侵權行為責任或合約責任或其他)。

自訂條款恒生指數期權每指數點港元$50

交易所的交易日

2018 年 4 月 11 日, 星期三

合約月份 行使價 認購/認沽 開市 全日最高 全日最低 結算價 結算價變動 引申波幅% 成交量 未平倉合約 未平倉合約變動

18 年 05 月 31600 認購 - - - 479 +40 18 0 0 0

18 年 05 月 32600 認購 - - - 210 +19 18 0 0 0

認購總計 0 0 0

合約月份 行使價 認購/認沽 開市 全日最高 全日最低 結算價 結算價變動 引申波幅% 成交量 未平倉合約 未平倉合約變動

18 年 05 月 27600 認沽 - - - 183 0 26 0 0 0

認沽總計 0 0 0

合約月份總計 0 0 0

市場總計 0 0 0

\*\*\* 全表完 \*\*\*

行業指數期貨每日市場報告

香港交易及結算所有限公司及/或其附屬公司竭力確保其提供之資料準確可靠，惟不保證該等資料絕對正確，

亦不對由於任何資料不確或遺漏所引起之損失或損害負上責任(不論是民事侵權行為責任或合約責任或其他)。

交易所的交易日

2018 年 4 月 11 日, 星期三

GTI - 中華交易服務博彩業指數期貨每指數點港元$50

合約月份 \*開市 \*全日最高 \*全日最低 結算價 結算價變動 \*合約最高 \*合約最低 成交量 未平倉合約 未平倉合約變動

18 年 04 月 0.0 0.0 0.0 6,388.5 +21.5 6,668.0 6,668.0 0 5 0

18 年 05 月 0.0 0.0 0.0 6,395.5 +22.5 0.0 0.0 0 0 0

18 年 06 月 0.0 0.0 0.0 6,388.5 +21.5 0.0 0.0 0 0 0

18 年 09 月 0.0 0.0 0.0 6,388.5 +21.5 0.0 0.0 0 0 0

總計 0 5 0

ITI - 恒生資訊科技器材指數期貨每指數點港元$50

合約月份 \*開市 \*全日最高 \*全日最低 結算價 結算價變動 \*合約最高 \*合約最低 成交量 未平倉合約 未平倉合約變動

18 年 04 月 0.0 0.0 0.0 3,578.5 +3.5 3,935.0 3,515.0 0 10 0

18 年 05 月 0.0 0.0 0.0 3,567.0 +3.5 0.0 0.0 0 0 0

18 年 06 月 0.0 0.0 0.0 3,578.5 +3.5 0.0 0.0 0 0 0

18 年 09 月 0.0 0.0 0.0 3,578.5 +3.5 0.0 0.0 0 0 0

總計 0 10 0

MBI - 恒生中國內地銀行指數期貨每指數點港元$50

合約月份 \*開市 \*全日最高 \*全日最低 結算價 結算價變動 \*合約最高 \*合約最低 成交量 未平倉合約 未平倉合約變動

18 年 04 月 3,489.5 3,517.0 3,464.5 3,492.5 +18.0 3,657.5 3,347.5 112 39 0

18 年 05 月 3,458.5 3,483.0 3,438.0 3,461.0 +18.0 3,483.0 3,330.0 88 35 -8

18 年 06 月 0.0 0.0 0.0 3,493.0 +18.0 0.0 0.0 0 0 0

18 年 09 月 0.0 0.0 0.0 3,493.5 +18.0 0.0 0.0 0 0 0

總計 200 74 -8

MCI - 恒生中國內地醫療保健指數期貨每指數點港元$50

合約月份 \*開市 \*全日最高 \*全日最低 結算價 結算價變動 \*合約最高 \*合約最低 成交量 未平倉合約 未平倉合約變動

18 年 04 月 0.0 0.0 0.0 6,256.0 -334.0 5,820.0 5,820.0 0 1 0

18 年 05 月 0.0 0.0 0.0 6,241.5 -334.5 6,634.0 6,587.0 0 0 0

18 年 06 月 0.0 0.0 0.0 6,256.0 -334.0 0.0 0.0 0 0 0

18 年 09 月 0.0 0.0 0.0 6,256.0 -334.0 0.0 0.0 0 0 0

總計 0 1 0

MOI - 恒生中國內地石油及天然氣指數期貨每指數點港元$50

合約月份 \*開市 \*全日最高 \*全日最低 結算價 結算價變動 \*合約最高 \*合約最低 成交量 未平倉合約 未平倉合約變動

18 年 04 月 1,895.5 1,895.5 1,880.0 1,881.5 +40.0 1,895.5 1,708.0 90 112 +50

18 年 05 月 1,854.5 1,854.5 1,840.0 1,841.5 +40.5 1,854.5 1,753.0 53 60 +13

18 年 06 月 0.0 0.0 0.0 1,881.5 +40.0 0.0 0.0 0 0 0

18 年 09 月 0.0 0.0 0.0 1,881.5 +40.0 0.0 0.0 0 0 0

總計 143 172 +63

MPI - 恒生中國內地地產指數期貨每指數點港元$50

合約月份 \*開市 \*全日最高 \*全日最低 結算價 結算價變動 \*合約最高 \*合約最低 成交量 未平倉合約 未平倉合約變動

18 年 04 月 7,486.5 7,536.5 7,454.0 7,473.0 +11.5 7,536.5 6,474.0 55 44 +1

18 年 05 月 7,497.5 7,497.5 7,437.5 7,422.0 +12.0 7,497.5 6,785.0 24 20 -6

18 年 06 月 0.0 0.0 0.0 7,473.0 +11.5 0.0 0.0 0 0 0

18 年 09 月 0.0 0.0 0.0 7,473.0 +11.5 0.0 0.0 0 0 0

總計 79 64 -5

SSI - 恒生軟件服務指數期貨每指數點港元$50

合約月份 \*開市 \*全日最高 \*全日最低 結算價 結算價變動 \*合約最高 \*合約最低 成交量 未平倉合約 未平倉合約變動

18 年 04 月 0.0 0.0 0.0 8,333.0 -95.0 8,747.0 8,086.0 0 9 0

18 年 05 月 0.0 0.0 0.0 8,336.5 -95.0 0.0 0.0 0 0 0

18 年 06 月 0.0 0.0 0.0 8,333.0 -95.0 0.0 0.0 0 0 0

18 年 09 月 0.0 0.0 0.0 8,333.0 -95.0 0.0 0.0 0 0 0

總計 0 9 0

所有合約總計 422 335 +50

GTI - 中華交易服務博彩業指數期貨

合約月份 策略 開市 全日最高 全日最低 成交量

18 年 04 月/18 年 05 月 跨期組合 0.0 0.0 0.0 0

18 年 04 月/18 年 06 月 跨期組合 0.0 0.0 0.0 0

18 年 04 月/18 年 09 月 跨期組合 0.0 0.0 0.0 0

18 年 05 月/18 年 06 月 跨期組合 0.0 0.0 0.0 0

18 年 05 月/18 年 09 月 跨期組合 0.0 0.0 0.0 0

18 年 06 月/18 年 09 月 跨期組合 0.0 0.0 0.0 0

總計 0

ITI - 恒生資訊科技器材指數期貨

合約月份 策略 開市 全日最高 全日最低 成交量

18 年 04 月/18 年 05 月 跨期組合 0.0 0.0 0.0 0

18 年 04 月/18 年 06 月 跨期組合 0.0 0.0 0.0 0

18 年 04 月/18 年 09 月 跨期組合 0.0 0.0 0.0 0

18 年 05 月/18 年 06 月 跨期組合 0.0 0.0 0.0 0

18 年 05 月/18 年 09 月 跨期組合 0.0 0.0 0.0 0

18 年 06 月/18 年 09 月 跨期組合 0.0 0.0 0.0 0

總計 0

MBI - 恒生中國內地銀行指數期貨

合約月份 策略 開市 全日最高 全日最低 成交量

18 年 04 月/18 年 05 月 跨期組合 0.0 0.0 0.0 0

18 年 04 月/18 年 06 月 跨期組合 0.0 0.0 0.0 0

18 年 04 月/18 年 09 月 跨期組合 0.0 0.0 0.0 0

18 年 05 月/18 年 06 月 跨期組合 0.0 0.0 0.0 0

18 年 05 月/18 年 09 月 跨期組合 0.0 0.0 0.0 0

18 年 06 月/18 年 09 月 跨期組合 0.0 0.0 0.0 0

總計 0

MCI - 恒生中國內地醫療保健指數期貨

合約月份 策略 開市 全日最高 全日最低 成交量

18 年 04 月/18 年 05 月 跨期組合 0.0 0.0 0.0 0

18 年 04 月/18 年 06 月 跨期組合 0.0 0.0 0.0 0

18 年 04 月/18 年 09 月 跨期組合 0.0 0.0 0.0 0

18 年 05 月/18 年 06 月 跨期組合 0.0 0.0 0.0 0

18 年 05 月/18 年 09 月 跨期組合 0.0 0.0 0.0 0

18 年 06 月/18 年 09 月 跨期組合 0.0 0.0 0.0 0

總計 0

MOI - 恒生中國內地石油及天然氣指數期貨

合約月份 策略 開市 全日最高 全日最低 成交量

18 年 04 月/18 年 05 月 跨期組合 0.0 0.0 0.0 0

18 年 04 月/18 年 06 月 跨期組合 0.0 0.0 0.0 0

18 年 04 月/18 年 09 月 跨期組合 0.0 0.0 0.0 0

18 年 05 月/18 年 06 月 跨期組合 0.0 0.0 0.0 0

18 年 05 月/18 年 09 月 跨期組合 0.0 0.0 0.0 0

18 年 06 月/18 年 09 月 跨期組合 0.0 0.0 0.0 0

總計 0

MPI - 恒生中國內地地產指數期貨

合約月份 策略 開市 全日最高 全日最低 成交量

18 年 04 月/18 年 05 月 跨期組合 0.0 0.0 0.0 0

18 年 04 月/18 年 06 月 跨期組合 0.0 0.0 0.0 0

18 年 04 月/18 年 09 月 跨期組合 0.0 0.0 0.0 0

18 年 05 月/18 年 06 月 跨期組合 0.0 0.0 0.0 0

18 年 05 月/18 年 09 月 跨期組合 0.0 0.0 0.0 0

18 年 06 月/18 年 09 月 跨期組合 0.0 0.0 0.0 0

總計 0

SSI - 恒生軟件服務指數期貨

合約月份 策略 開市 全日最高 全日最低 成交量

18 年 04 月/18 年 05 月 跨期組合 0.0 0.0 0.0 0

18 年 04 月/18 年 06 月 跨期組合 0.0 0.0 0.0 0

18 年 04 月/18 年 09 月 跨期組合 0.0 0.0 0.0 0

18 年 05 月/18 年 06 月 跨期組合 0.0 0.0 0.0 0

18 年 05 月/18 年 09 月 跨期組合 0.0 0.0 0.0 0

18 年 06 月/18 年 09 月 跨期組合 0.0 0.0 0.0 0

總計 0

所有策略總計 0

\*\*\*　全表完 \*\*\*

\*不包括跨期對跨期買賣交易

美元黃金期貨每日市場報告 (附載即日之未平倉合約)

香港交易及結算所有限公司及/或其附屬公司竭力確保其提供之資料準確可靠，惟不保證該等資料絕對正確，

亦不對由於任何資料不確或遺漏所引起之損失或損害負上責任(不論是民事侵權行為責任或合約責任或其他)。

GDU - 美元黃金期貨最低價格波幅 = 每克美金0.01元

合約單位 = 1千克

交易所的前交易日營 交易所的交易日

2018 年 4 月 10 日, 星期二 2018 年 4 月 11 日, 星期三

收市後交易時段 | 即日交易時段 | 合併全日交易資料

| |

合約月份 \*開市 \*全日最高 \*全日最低 \*最後成交 成交量 | \*開市 \*全日最高 \*全日最低 成交量 結算價 結算價變動 | \*合約最高 \*合約最低 成交量 未平倉合約 未平倉合約變動

| |

18 年 04 月 0.00 0.00 0.00 0.00 0 | 43.10 43.10 43.10 1 43.25 +0.30 | 43.93 40.22 1 62 -1

18 年 05 月 0.00 0.00 0.00 0.00 0 | 43.26 43.34 43.26 10 43.32 +0.29 | 44.15 42.39 10 14 +1

…

…

19 年 03 月 0.00 0.00 0.00 0.00 0 | 0.00 0.00 0.00 0 43.96 +0.30 | 0.00 0.00 0 0 0

所有合約總計 73 162 -26

營業日

2018 年 4 月 11 日, 星期三

即日交易時段

合約月份 策略 開市 全日最高 全日最低 成交量

18 年 04 月/18 年 05 月 跨期組合 0.00 0.00 0.00 0

18 年 04 月/18 年 06 月 跨期組合 0.00 0.00 0.00 0

…

…

18 年 12 月/19 年 02 月 跨期組合 0.00 0.00 0.00 0

所有策略總計 0

\*\*\*　全表完 \*\*\*

\*不包括跨期對跨期買賣交易

股票期貨每日市場報告

香港交易及結算所有限公司及/或其附屬公司竭力確保其提供之資料準確可靠，惟不保證該等資料絕對正確，

亦不對由於任何資料不確或遺漏所引起之損失或損害負上責任(不論是民事侵權行為責任或合約責任或其他)。

交易所的交易日 交易所的前交易日營

2009 年 6 月 16 日, 星期二 2009 年 6 月 15 日, 星期一

合約月份 \*開市 \*全日最高 \*全日最低 結算價 結算價變動 成交量 未平倉合約 未平倉合約變動

ALC - 中國鋁業股份有限公司股票期貨 – 合約乘數 2,000

09 年 06 月 0.00 0.00 0.00 8.00 -0.29 0 0 0

09 年 07 月 8.00 8.00 7.90 8.04 -0.28 29 33 -7

09 年 08 月 7.93 7.93 7.85 8.04 -0.23 8 0 0

09 年 09 月 0.00 0.00 0.00 7.89 -0.29 0 0 0

09 年 12 月 0.00 0.00 0.00 7.93 -0.29 0 0 0

BCL - 中國銀行股份有限公司股票期貨 - 合約乘數1,000

09 年 06 月 0.00 0.00 0.00 3.59 +0.05 0 42 0

09 年 07 月 0.00 0.00 0.00 3.61 +0.04 0 0 0

09 年 08 月 0.00 0.00 0.00 3.56 +0.04 0 0 0

09 年 09 月 0.00 0.00 0.00 3.57 +0.04 0 0 0

09 年 12 月 0.00 0.00 0.00 3.53 +0.04 0 0 0

…

…

WHL - 九龍倉集團有限公司股票期貨 - 合約乘數1,000

09 年 06 月 0.00 0.00 0.00 27.81 -1.05 0 0 -1

09 年 07 月 28.10 28.10 27.44 27.93 -0.90 50 0 0

09 年 08 月 0.00 0.00 0.00 28.13 -1.22 0 0 0

09 年 09 月 0.00 0.00 0.00 27.45 -1.20 0 0 0

09 年 12 月 0.00 0.00 0.00 27.16 -1.18 0 0 0

所有合約總計 627 14655 +4969

類別 合約月份 策略 開市 全日最高 全日最低 成交量

ALC 12 年 03 月/12 年 04 月 跨期組合 0.00 0.00 0.00 0

BCL 12 年 03 月/12 年 04 月 跨期組合 0.00 0.00 0.00 0

BCM 12 年 03 月/12 年 04 月 跨期組合 0.00 0.00 0.00 0

BEA 12 年 03 月/12 年 04 月 跨期組合 0.00 0.00 0.00 0

..

..

HNP 12 年 03 月/12 年 04 月 跨期組合 0.00 0.00 0.00 0

HSB 12 年 03 月/12 年 04 月 跨期組合 0.00 0.00 0.00 0

HWL 12 年 03 月/12 年 04 月 跨期組合 0.00 0.00 0.00 0

ICB 12 年 03 月/12 年 04 月 跨期組合 0.00 0.00 0.00 0

..

..

PIC 12 年 03 月/12 年 04 月 跨期組合 0.00 0.00 0.00 0

SHK 12 年 03 月/12 年 04 月 跨期組合 0.00 0.00 0.00 0

SWA 12 年 03 月/12 年 04 月 跨期組合 0.00 0.00 0.00 0

WHL 12 年 03 月/12 年 04 月 跨期組合 0.00 0.00 0.00 0

所有策略總計 0

\*\*\*　全表完 \*\*\*

\*不包括跨期對跨期買賣交易

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
| [摘要](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22SUMMARY%23SUMMARY) | [ALC](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22ALC%23ALC) | [BCL](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22BCL%23BCL) | [BCM](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22BCM%23BCM) | [BEA](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22BEA%23BEA) | [BEB](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22BEB%23BEB) |
| [BOC](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22BOC%23BOC) | [CCB](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22CCB%23CCB) | [CCC](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22CCC%23CCC) | [CCE](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22CCE%23CCE) | [CHA](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22CHA%23CHA) | [CHT](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22CHT%23CHT) |
| [CHU](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22CHU%23CHU) | [CIT](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22CIT%23CIT) | [CKH](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22CKH%23CKH) | [CKI](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22CKI%23CKI) | [CLI](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22CLI%23CLI) | [CLP](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22CLP%23CLP) |
| [CMA](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22CMA%23CMA) | [CMB](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22CMB%23CMB) | [CNC](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22CNC%23CNC) | [CPA](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22CPA%23CPA) | [CPC](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22CPC%23CPC) | [CRC](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22CRC%23CRC) |
| [CRG](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22CRG%23CRG) | [CSE](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22CSE%23CSE) | [CTB](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22CTB%23CTB) | [CTC](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22CTC%23CTC) | [DWM](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22DWM%23DWM) | [ESA](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22ESA%23ESA) |
| [ESP](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22ESP%23ESP) | [FIH](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22FIH%23FIH) | [HEH](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22HEH%23HEH) | [HEX](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22HEX%23HEX) | [HKB](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22HKB%23HKB) | [HKC](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22HKC%23HKC) |
| [HKG](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22HKG%23HKG) | [HLD](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22HLD%23HLD) | [HNP](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22HNP%23HNP) | [HSB](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22HSB%23HSB) | [HWL](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22HWL%23HWL) | [ICB](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22ICB%23ICB) |
| [JSE](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22JSE%23JSE) | [JXC](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22JXC%23JXC) | [LIF](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22LIF%23LIF) | [MTR](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22MTR%23MTR) | [NWD](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22NWD%23NWD) | [PAI](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22PAI%23PAI) |
| [PCA](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22PCA%23PCA) | [PCC](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22PCC%23PCC) | [PEC](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22PEC%23PEC) | [PIC](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22PIC%23PIC) | [SHK](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22SHK%23SHK) | [SWA](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22SWA%23SWA) |
| [TRF](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22TRF%23TRF) | [WHL](../../D%3A%5Ctemp%5CDQEC090616.HTM%22%20%5Cl%20%22WHL%23WHL) |  |  |  |  |

香港交易及結算所有限公司及/或其附屬公司竭力確保其提供之資料準確可靠，惟不保證該等資料絕對正確，

亦不對由於任何資料不確或遺漏所引起之損失或損害負上責任(不論是民事侵權行為責任或合約責任或其他)。

股票期權每日市場報告 2009 年 6 月 16 日

HKATS 正股名稱 成交量摘要 未平倉合約摘要 引申波幅%

代號 總計 認購 認沽 總計 認購 認沽 \*

ALC 中國鋁業股份有限公司 (02600) 565 73 492 13,333 6,544 6,789 69

BCL 中國銀行股份有限公司 (03988) 15,330 5,238 10,092 604,839 241,511 363,328 46

BCM 交通銀行股份有限公司 (03328) 4,567 1,317 3,250 117,210 24,134 93,076 49

BEA 東亞銀行有限公司 (00023) 407 17 390 18,284 8,956 9,328 55

BEB 東亞銀行有限公司(資本調整-A) (00023) 90 90 0 11,061 6,152 4,909 56

…

…

WHL 九龍倉集團有限公司 (00004) 56 16 40 4,011 992 3,019 54

總計 287,105 145,451 141,654 5,560,523 1,919,824 3,640,699

十大成交(按成交量) 成交量 結算價 引申波幅% 最高 最低 未平倉合約 結算價變動\*\* 結算價變動百份比

認購 CCB 09 年 09 月 8.00 44,000 0.06 46 0.00 0.00 919 +0.02 +50.00

認沽 CCB 09 年 09 月 8.00 22,030 2.45 49 2.45 2.45 23,350 -0.04 -1.60

…

…

認購 CCB 10 年 03 月 5.50 1,901 0.87 40 0.81 0.76 2,044 +0.10 +12.98

五大升幅(按結算價變動百份比)

認沽 HKB 09 年 12 月 26.00 0 0.05 53 0.00 0.00 3,370 +0.04 +400.00

…

…

認沽 CHA 09 年 06 月 9.28 0 0.07 61 0.00 0.00 61 +0.05 +250.00

五大跌幅(按結算價變動百份比)

認沽 CKI 09 年 06 月 26.00 0 0.01 15 0.00 0.00 138 -0.07 -87.50

…

…

認購 HWL 09 年 06 月 62.50 0 0.03 46 0.00 0.00 407 -0.10 -76.92

\*現貨月認購及認沽的等價期權系列的引申波幅

\*\*與前交易日結算價作比較(如沒有前結算價則以'N/A'代表)

合約 開市 全日最高 全日最低 結算價 結算價變動 引申波幅% 成交量 未平倉合約 未平倉合約變動

類別 ALC - 中國鋁業股份有限公司 收市價 港元$ 8.01

認購 09 年 06 月 1.90 0.00 0.00 0.00 6.11 -0.29 0 0 0 0

認購 09 年 06 月 2.00 0.00 0.00 0.00 6.01 -0.29 0 0 0 0

…

…

認購 09 年 12 月 9.50 0.00 0.00 0.00 0.92 -0.14 61 0 60 0

認購 09 年 12 月 10.00 0.00 0.00 0.00 0.80 -0.12 61 0 20 0

認購總計 73 6,544 +65

認沽 09 年 06 月 1.90 0.00 0.00 0.00 0.01 0.00 339 0 0 0

認沽 09 年 06 月 2.00 0.00 0.00 0.00 0.01 0.00 327 0 25 0

…

…

認沽 09 年 12 月 9.50 0.00 0.00 0.00 2.42 +0.15 61 0 0 0

認沽 09 年 12 月 10.00 0.00 0.00 0.00 2.80 +0.17 61 0 0 0

認沽總計 492 6,789 +304

合約 開市 全日最高 全日最低 結算價 結算價變動 引申波幅% 成交量 未平倉合約 未平倉合約變動

類別 BCL - 中國銀行股份有限公司 收市價 港元$ 3.73

認購 09 年 06 月 1.10 0.00 0.00 0.00 2.63 +0.04 0 0 2,000 0

認購 09 年 06 月 1.20 0.00 0.00 0.00 2.53 +0.04 0 0 2,000 0

…

…

認沽 09 年 12 月 34.00 0.00 0.00 0.00 8.32 +0.76 48 0 15 0

認沽 09 年 12 月 36.00 0.00 0.00 0.00 9.93 +0.84 48 0 0 0

認沽總計 40 3,019 +30

所有合約總計 287,105 5,560,523 -21,932

\*\*\*　全表完 \*\*\*

#不包括組合對組合買賣交易

恒生指數期貨及期權自選組合每日市場報告

香港交易及結算所有限公司及/或其附屬公司竭力確保其提供之資料準確可靠，惟不保證該等資料絕對正確，

亦不對由於任何資料不確或遺漏所引起之損失或損害負上責任(不論是民事侵權行為責任或合約責任或其他)。

交易所的交易日

2013 年 12 月 11 日, 星期三

自選組合名稱 合約1 合約2 合約3 合約4 開市 全日最高 全日最低 最後成交 成交量

1 TMC\_HHI/010 (買 1) HHI23400A4 (賣 2) HHI24000A4 (買 1) HHI24600A4 - 103 103 103 103 5

2 TMC\_HHI/020 (賣 1) HHI22400X3 (買 1) HHI22600X3 - - 21 21 21 21 1

3 TMC\_HHI/021 (買 1) HHI23200L3 (賣 1) HHI23200X3 - - 238 238 238 238 1

4 TMC\_HHI/022 (買 1) HHI23600L3 (賣 2) HHI24000L3 - - 25 25 25 25 15

5 TMC\_HHI/023 (買 1) HHI23400L3 (賣 1) HHI24000L3 - - 176 176 176 176 2

6 TMC\_HHI/031 (買 1) HHI23400L3 (賣 1) HHI23800L3 - - 134 134 134 134 8

\*\*\*　全表完 \*\*\*

倫敦金屬期貨小型合約每日市場報告 (附載即日之未平倉合約)

香港交易及結算所有限公司及/或其附屬公司竭力確保其提供之資料準確可靠，惟不保證該等資料絕對正確，

亦不對由於任何資料不確或遺漏所引起之損失或損害負上責任(不論是民事侵權行為責任或合約責任或其他)。

交易所的前交易日營 交易所的交易日

2014 年 11 月 14 日, 星期五 2014 年 11 月 17 日, 星期一

LRA - 倫敦鋁期貨小型合約每最低價格波幅人民幣5元

合約單位 = 5噸

收市後交易時段 | 即日交易時段 | 合併全日交易資料

| |

合約月份 \*開市 \*全日最高 \*全日最低 \*最後成交 成交量 | \*開市 \*全日最高 \*全日最低 成交量 結算價 結算價變動 | \*合約最高 \*合約最低 成交量 未平倉合約 未平倉合約變動

| |

14 年 11 月 10,505 10,545 10,480 10,490 123 | 12,800 12,820 12,800 105 11,582 +11,582 | 12,820 10,480 228 229 +229

14 年 12 月 10,425 10,855 10,325 10,330 117 | 12,900 12,900 12,700 432 10,917 +10,917 | 12,900 10,325 549 120 +120

15 年 01 月 10,445 10,445 10,445 10,445 3 | 0 0 0 130 10,470 +10,470 | 10,445 10,445 133 3 +3

…

…

15 年 10 月 0 0 0 0 0 | 0 0 0 0 0 0 | 0 0 0 0 0

合約總計 910 352 +352

LRC - 倫敦銅期貨小型合約每最低價格波幅人民幣10元

合約單位 = 5噸

收市後交易時段 | 即日交易時段 | 合併全日交易資料

| |

合約月份 \*開市 \*全日最高 \*全日最低 \*最後成交 成交量 | \*開市 \*全日最高 \*全日最低 成交量 結算價 結算價變動 | \*合約最高 \*合約最低 成交量 未平倉合約 未平倉合約變動

| |

14 年 11 月 33,580 33,940 33,500 33,510 134 | 43,500 43,500 43,500 11 37,838 +37,838 | 43,500 33,500 145 190 +190

14 年 12 月 33,550 33,550 33,550 33,550 2 | 43,600 43,700 43,500 8 37,393 +37,393 | 43,700 33,550 10 5 +5

15 年 01 月 0 0 0 0 0 | 43,900 43,900 43,900 103 0 0 | 43,900 43,900 103 0 0

…

…

15 年 10 月 0 0 0 0 0 | 0 0 0 0 0 0 | 0 0 0 0 0

合約總計 358 195 +195

LRZ - 倫敦鋅期貨小型合約每最低價格波幅人民幣5元

合約單位 = 5噸

收市後交易時段 | 即日交易時段 | 合併全日交易資料

| |

合約月份 \*開市 \*全日最高 \*全日最低 \*最後成交 成交量 | \*開市 \*全日最高 \*全日最低 成交量 結算價 結算價變動 | \*合約最高 \*合約最低 成交量 未平倉合約 未平倉合約變動

| |

14 年 11 月 10,535 10,840 10,505 10,525 148 | 14,300 14,300 14,300 102 12,151 +12,151 | 14,300 10,505 250 154 +154

14 年 12 月 10,545 10,545 10,545 10,545 2 | 14,320 14,360 14,260 35 12,491 +12,491 | 14,360 10,545 37 5 +5

15 年 01 月 0 0 0 0 0 | 0 0 0 130 0 0 | 0 0 130 0 0

…

…

15 年 10 月 0 0 0 0 0 | 0 0 0 0 0 0 | 0 0 0 0 0

合約總計 417 159 +159

所有合約總計 1,685 706 +706

交易所的交易日

2014 年 11 月 17 日, 星期一

即日交易時段

LRA - 倫敦鋁期貨小型合約

合約月份 策略 開市 全日最高 全日最低 成交量

14 年 11 月/14 年 12 月 跨期組合 10 20 10 2

14 年 11 月/15 年 01 月 跨期組合 0 0 0 0

…

…

15 年 08 月/15 年 10 月 跨期組合 0 0 0 0

15 年 09 月/15 年 10 月 跨期組合 0 0 0 0

總計 32

LRC - 倫敦銅期貨小型合約

合約月份 策略 開市 全日最高 全日最低 成交量

14 年 11 月/14 年 12 月 跨期組合 50 50 50 1

14 年 11 月/15 年 01 月 跨期組合 0 0 0 0

…

…

15 年 08 月/15 年 10 月 跨期組合 0 0 0 0

15 年 09 月/15 年 10 月 跨期組合 0 0 0 0

總計 4

LRZ - 倫敦鋅期貨小型合約

合約月份 策略 開市 全日最高 全日最低 成交量

14 年 11 月/14 年 12 月 跨期組合 10 20 10 2

14 年 11 月/15 年 01 月 跨期組合 0 0 0 0

14 年 11 月/15 年 02 月 跨期組合 0 0 0 0

…

…

15 年 08 月/15 年 10 月 跨期組合 0 0 0 0

15 年 09 月/15 年 10 月 跨期組合 0 0 0 0

總計 32

所有策略總計 68

\*\*\*　全表完 \*\*\*

\*不包括跨期對跨期買賣交易

人民幣貨幣期權每日市場報告

香港交易及結算所有限公司及/或其附屬公司竭力確保其提供之資料準確可靠，惟不保證該等資料絕對正確，

亦不對由於任何資料不確或遺漏所引起之損失或損害負上責任(不論是民事侵權行為責任或合約責任或其他)。

美元兌人民幣期權每最低價格波幅人民幣0.0001元

交易所的交易日

2017 年 1 月 27 日, 星期五

合約月份 行使價 開市 全日最高 全日最低 正式收市價 正式收市價變動 引申波幅% 成交量 未平倉合約 未平倉合約變動

17 年 02 月 6.05 認購 0.0000 0.0000 0.0000 0.7921 -0.0011 29 0 12 0

17 年 02 月 6.10 認購 0.0000 0.0000 0.0000 0.7440 -0.0012 30 0 20 0

…

…

17 年 02 月 7.65 認購 0.0000 0.0000 0.0000 0.0079 -0.0012 30 0 0 0

認購總計 2 44 +2

合約月份 行使價 開市 全日最高 全日最低 正式收市價 正式收市價變動 引申波幅% 成交量 未平倉合約 未平倉合約變動

17 年 02 月 6.05 認沽 0.0000 0.0000 0.0000 0.0047 -0.0009 29 0 3 0

17 年 02 月 6.10 認沽 0.0000 0.0000 0.0000 0.0066 -0.0010 30 0 0 0

…

…

17 年 02 月 7.65 認沽 0.0000 0.0000 0.0000 0.8205 -0.0010 30 0 20 0

認沽總計 20 53 +20

合約月份認沽/認購比率 10.00 合約月份總計 22 97 +22

…

…

合約月份 行使價 開市 全日最高 全日最低 正式收市價 正式收市價變動 引申波幅% 成交量 未平倉合約 未平倉合約變動

18 年 03 月 6.05 認購 0.0000 0.0000 0.0000 1.5167 -0.0010 29 0 0 0

18 年 03 月 6.10 認購 0.0000 0.0000 0.0000 1.4847 -0.0010 29 0 0 0

…

…

18 年 03 月 7.65 認購 0.0000 0.0000 0.0000 0.7228 -0.0011 30 0 0 0

認購總計 0 0 0

合約月份 行使價 開市 全日最高 全日最低 正式收市價 正式收市價變動 引申波幅% 成交量 未平倉合約 未平倉合約變動

18 年 03 月 6.05 認沽 0.0000 0.0000 0.0000 0.3947 -0.0008 29 0 0 0

18 年 03 月 6.10 認沽 0.0000 0.0000 0.0000 0.4127 -0.0008 29 0 0 0

…

…

18 年 03 月 7.65 認沽 0.0000 0.0000 0.0000 1.2008 -0.0009 30 0 0 0

認沽總計 0 0 0

合約月份認沽/認購比率 ---------- 合約月份總計 0 0 0

市場認沽/認購比率 10.00 市場總計 22 97 +22

\*\*\* 全表完 \*\*\*

不包括組合對組合買賣交易

人民幣黃金期貨每日市場報告 (附載即日之未平倉合約)

香港交易及結算所有限公司及/或其附屬公司竭力確保其提供之資料準確可靠，惟不保證該等資料絕對正確，

亦不對由於任何資料不確或遺漏所引起之損失或損害負上責任(不論是民事侵權行為責任或合約責任或其他)。

GDR - 人民幣黃金期貨最低價格波幅 = 每克人民幣0.05元

合約單位 = 1千克

交易所的前交易日營 交易所的交易日

2018 年 4 月 10 日, 星期二 2018 年 4 月 11 日, 星期三

收市後交易時段 | 即日交易時段 | 合併全日交易資料

| |

合約月份 \*開市 \*全日最高 \*全日最低 \*最後成交 成交量 | \*開市 \*全日最高 \*全日最低 成交量 結算價 結算價變動 | \*合約最高 \*合約最低 成交量 未平倉合約 未平倉合約變動

| |

18 年 04 月 0.00 0.00 0.00 0.00 0 | 273.70 273.70 273.70 2 273.85 +1.30 | 280.25 267.25 2 0 -2

18 年 05 月 0.00 0.00 0.00 0.00 0 | 271.40 271.40 271.40 5 272.30 +1.30 | 275.10 268.85 5 9 +3

…

…

19 年 03 月 0.00 0.00 0.00 0.00 0 | 0.00 0.00 0.00 0 282.40 +1.30 | 0.00 0.00 0 0 0

所有合約總計 15 118 +8

交易所的交易日

2018 年 4 月 11 日, 星期三

即日交易時段

合約月份 策略 開市 全日最高 全日最低 成交量

18 年 04 月/18 年 05 月 跨期組合 0.00 0.00 0.00 0

18 年 04 月/18 年 06 月 跨期組合 0.00 0.00 0.00 0

…

…

18 年 12 月/19 年 02 月 跨期組合 0.00 0.00 0.00 0

所有策略總計 0

\*\*\*　全表完 \*\*\*

\*不包括跨期對跨期買賣交易

TSI CFR 中國鐵礦石 62% 鐵粉期貨每日市場報告 (附載即日之未平倉合約)

香港交易及結算所有限公司及/或其附屬公司竭力確保其提供之資料準確可靠，惟不保證該等資料絕對正確，

亦不對由於任何資料不確或遺漏所引起之損失或損害負上責任(不論是民事侵權行為責任或合約責任或其他)。

交易所的前交易日 交易所的交易日

2018 年 4 月 10 日, 星期二 2018 年 4 月 11 日, 星期三

FEM - TSI CFR 中國鐵礦石 62% 鐵粉期貨 - 月度合約每最低價格波幅美元0.01

合約單位 = 100 噸

收市後交易時段 | 即日交易時段 | 合併全日交易資料

| |

合約月份 \*開市 \*全日最高 \*全日最低 \*最後成交 成交量 | \*開市 \*全日最高 \*全日最低 成交量 結算價 結算價變動 | \*合約最高 \*合約最低 成交量 未平倉合約 未平倉合約變動

| |

18 年 04 月 0.00 0.00 0.00 0.00 0 | 0.00 0.00 0.00 0 63.86 -0.91 | 78.11 61.98 0 56 0

18 年 05 月 0.00 0.00 0.00 0.00 0 | 0.00 0.00 0.00 0 64.20 -0.91 | 76.97 62.01 0 53 0

…

…

20 年 03 月 0.00 0.00 0.00 0.00 0 | 0.00 0.00 0.00 0 63.43 -0.91 | 0.00 0.00 0 0 0

合約總計 0 138 0

FEQ - TSI CFR 中國鐵礦石 62% 鐵粉期貨 - 季度合約每最低價格波幅美元0.01

合約單位 = 100 噸

收市後交易時段 | 即日交易時段 | 合併全日交易資料

| |

合約月份 \*開市 \*全日最高 \*全日最低 \*最後成交 成交量 | \*開市 \*全日最高 \*全日最低 成交量 結算價 結算價變動 | \*合約最高 \*合約最低 成交量 未平倉合約 未平倉合約變動

| |

18 年 06 月 0.00 0.00 0.00 0.00 0 | 0.00 0.00 0.00 0 64.20 -0.89 | 68.48 68.48 0 15 0

18 年 09 月 0.00 0.00 0.00 0.00 0 | 0.00 0.00 0.00 0 62.94 -1.04 | 0.00 0.00 0 0 0

…

…

20 年 03 月 0.00 0.00 0.00 0.00 0 | 0.00 0.00 0.00 0 60.78 -0.89 | 0.00 0.00 0 0 0

合約總計 0 15 0

所有合約總計 0 153 0

交易所的交易日

2018 年 4 月 11 日, 星期三

即日交易時段

FEM - TSI CFR 中國鐵礦石 62% 鐵粉期貨 - 月度合約

合約月份 策略 開市 全日最高 全日最低 成交量

18 年 04 月/18 年 05 月 跨期組合 0.00 0.00 0.00 0

18 年 04 月/18 年 06 月 跨期組合 0.00 0.00 0.00 0

…

…

18 年 08 月/18 年 09 月 跨期組合 0.00 0.00 0.00 0

總計 0

FEQ - TSI CFR 中國鐵礦石 62% 鐵粉期貨 - 季度合約

合約月份 策略 開市 全日最高 全日最低 成交量

18 年 06 月/18 年 09 月 跨期組合 0.00 0.00 0.00 0

18 年 06 月/18 年 12 月 跨期組合 0.00 0.00 0.00 0

…

…

19 年 09 月/20 年 03 月 跨期組合 0.00 0.00 0.00 0

19 年 12 月/20 年 03 月 跨期組合 0.00 0.00 0.00 0

總計 0

所有策略總計 0

\*\*\*　全表完 \*\*\*

\*不包括跨期對跨期買賣交易

恒生中國企業指數期權收市後交易活動摘要

香港交易及結算所有限公司及/或其附屬公司竭力確保其提供之資料準確可靠，惟不保證該等資料絕對正確，

亦不對由於任何資料不確或遺漏所引起之損失或損害負上責任(不論是民事侵權行為責任或合約責任或其他)。

恒生中國企業指數期權 每指數點港元$50

交易所的交易日

2018 年 5 月 31 日, 星期四

收市後交易時段

合約月份 行使價 \*開市 \*全日最高 \*全日最低 正式收市價 成交量

18 年 06 月 3000 認購 0 0 0 0 0

18 年 06 月 5000 認購 0 0 0 0 0

…

…

18 年 06 月 16600 認購 0 0 0 0 0

認購總計 100

合約月份 行使價 \*開市 \*全日最高 \*全日最低 正式收市價 成交量

18 年 06 月 3000 認沽 0 0 0 0 0

18 年 06 月 5000 認沽 0 0 0 0 0

…

…

18 年 06 月 16600 認沽 0 0 0 0 0

認沽總計 0

…

…

合約月份 行使價 \*開市 \*全日最高 \*全日最低 正式收市價 成交量

23 年 12 月 9400 認購 0 0 0 0 0

23 年 12 月 9600 認購 0 0 0 0 0

…

…

23 年 12 月 14600 認購 0 0 0 0 0

認購總計 0

合約月份 行使價 \*開市 \*全日最高 \*全日最低 正式收市價 成交量

23 年 12 月 9400 認沽 0 0 0 0 0

23 年 12 月 9600 認沽 0 0 0 0 0

…

…

23 年 12 月 14600 認沽 0 0 0 0 0

認沽總計 0

市場總計 100

\*\*\* 全表完 \*\*\*

\*不包括組合對組合買賣交易

恒生中國企業指數期貨及期權自選組合每日市場報告

香港交易及結算所有限公司及/或其附屬公司竭力確保其提供之資料準確可靠，惟不保證該等資料絕對正確，

亦不對由於任何資料不確或遺漏所引起之損失或損害負上責任(不論是民事侵權行為責任或合約責任或其他)。

交易所的前交易日營

2018 年 5 月 30 日, 星期三

收市後交易時段

自選組合名稱 合約1 合約2 合約3 合約4 開市 全日最高 全日最低 最後成交 成交量

是日沒有交易

交易所的交易日

2018 年 5 月 31 日, 星期四

即日交易時段

自選組合名稱 合約1 合約2 合約3 合約4 開市 全日最高 全日最低 最後成交 成交量

1 TMC\_HHI/010 (買 1) HHI23400A4 (賣 2) HHI24000A4 (買 1) HHI24600A4 - 103 103 103 103 5

2 TMC\_HHI/020 (賣 1) HHI22400X3 (買 1) HHI22600X3 - - 21 21 21 21 1

\*\*\* 全表完 \*\*\*

恒生中國企業指數期貨及期權自選組合收市後交易活動摘要

香港交易及結算所有限公司及/或其附屬公司竭力確保其提供之資料準確可靠，惟不保證該等資料絕對正確，

亦不對由於任何資料不確或遺漏所引起之損失或損害負上責任(不論是民事侵權行為責任或合約責任或其他)。

交易所的交易日

2018 年 5 月 31 日, 星期四

收市後交易時段

自選組合名稱 合約1 合約2 合約3 合約4 開市 全日最高 全日最低 最後成交 成交量

1 TMC\_HHI/010 (買 1) HHI23400A4 (賣 2) HHI24000A4 (買 1) HHI24600A4 - 103 103 103 103 5

2 TMC\_HHI/020 (賣 1) HHI22400X3 (買 1) HHI22600X3 - - 21 21 21 21 1

\*\*\* 全表完 \*\*\*

每周恒生指數期權每日市場報告 (附載即日之未平倉合約)

香港交易及結算所有限公司及/或其附屬公司竭力確保其提供之資料準確可靠，惟不保證該等資料絕對正確，

亦不對由於任何資料不確或遺漏所引起之損失或損害負上責任(不論是民事侵權行為責任或合約責任或其他)。

十大成交(按成交量) 成交量 正式收市價 引申波幅% 全日最高 全日最低 未平倉合約 正式收市價變動

19年01月18日 28800 認購 2 1 20 389 388 2 -6

19年01月18日 29000 認購 2 1 25 239 230 50 -3

…

19年01月25日 28800 認沽 1 626 11 269 269 1 -102

每周恒生指數期權每指數點港元$50

交易所的前交易日營 交易所的交易日

2019 年 1 月 16 日, 星期三 2019 年 1 月 17 日, 星期四

收市後交易時段 | 即日交易時段 | 合併全日交易資料

| |

合約周份 行使價 \*開市 \*全日最高 \*全日最低 正式收市價 成交量 | \*開市 \*全日最高 \*全日最低 結算價 結算價變動 引申波幅% 成交量 | \*合約最高 \*合約最低 成交量 未平倉合約 未平倉合約變動

19年01月18日 21600 認購 0 0 0 0 0 | 0 0 0 6495 +30 0 0 | 6400 6280 0 108 0

19年01月18日 21800 認購 0 0 0 0 0 | 0 0 0 6295 +30 0 0 | 0 0 0 0 0

…

19年01月18日 32400 認購 0 0 0 0 0 | 0 0 0 1 0 95 0 | 0 0 0 0 0

認購總計 0 | 認購總計 4 | 認購總計 4 973 +4

合約周份 行使價 \*開市 \*全日最高 \*全日最低 正式收市價 成交量 | \*開市 \*全日最高 \*全日最低 結算價 結算價變動 引申波幅% 成交量 | \*合約最高 \*合約最低 成交量 未平倉合約 未平倉合約變動

19年01月18日 21600 認沽 0 0 0 0 0 | 0 0 0 1 0 170 0 | 2 1 0 93 0

19年01月18日 21800 認沽 0 0 0 0 0 | 0 0 0 1 0 164 0 | 0 0 0 0 0

…

19年01月18日 32400 認沽 0 0 0 0 0 | 0 0 0 4305 -30 0 0 | 0 0 0 0 0

認沽總計 0 | 認沽總計 1 | 認沽總計 1 860 +1

| 合約周份認沽/認購比率 0.25

| 合約周份總計 5 1833 +5

合約周份 行使價 \*開市 \*全日最高 \*全日最低 正式收市價 成交量 | \*開市 \*全日最高 \*全日最低 結算價 結算價變動 引申波幅% 成交量 | \*合約最高 \*合約最低 成交量 未平倉合約 未平倉合約變動

19年01月25日 21600 認購 0 0 0 0 0 | 0 0 0 6595 +4 0 0 | 0 0 0 0 0

19年01月25日 21800 認購 0 0 0 0 0 | 0 0 0 6395 +3 0 0 | 0 0 0 0 0

…

19年01月25日 32400 認購 0 0 0 0 0 | 0 0 0 1 -50 33 0 | 0 0 0 0 0

認購總計 0 | 認購總計 1 | 認購總計 1 2 +1

合約周份 行使價 \*開市 \*全日最高 \*全日最低 正式收市價 成交量 | \*開市 \*全日最高 \*全日最低 結算價 結算價變動 引申波幅% 成交量 | \*合約最高 \*合約最低 成交量 未平倉合約 未平倉合約變動

19年01月25日 21600 認沽 0 0 0 0 0 | 0 0 0 1 -22 60 0 | 0 0 0 0 0

19年01月25日 21800 認沽 0 0 0 0 0 | 0 0 0 1 -23 58 0 | 0 0 0 0 0

…

19年01月25日 32400 認沽 0 0 0 0 0 | 0 0 0 4205 -99 0 0 | 0 0 0 0 0

認沽總計 0 | 認沽總計 3 | 認沽總計 3 3 +3

| 合約周份認沽/認購比率 3.00

| 合約周份總計 4 5 +4

市場認沽/認購比率 0.80

市場總計 9 1838 +9

\*\*\* 全表完 \*\*\*

\*不包括組合對組合買賣交易
