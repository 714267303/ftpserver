TITLE:

**FUNCTIONAL SPECIFICATION**

***OTP-D***

***FS10009 - Error Trade, Trade Cancellation and Adjustment***

AUTHOR : *IT/Markets Systems*  DATE : *15 Jul 2026*

LAST REVIEW *Derivatives Trading Business Operations* DATE : *28 Feb 2025*

**CONTENTS**

[1. Document Control 4](#_Toc187833958)

[1.1 Change History 4](#_Toc187833959)

[1.2 Document Cross-referenced 4](#_Toc187833960)

[1.3 Abbreviation 4](#_Toc187833961)

[1.4 Distribution List 5](#_Toc187833962)

[2. Introduction 6](#_Toc187833963)

[3. Error Trade Handling 7](#_Toc187833964)

[3.1 Overview 7](#_Toc187833965)

[3.2 Submission of Claim 8](#_Toc187833966)

[3.3 Validation of Error Trade Claim 9](#_Toc187833967)

[3.3.1 Time of the Claim Validation 9](#_Toc187833968)

[3.4 Reference Price Capture 9](#_Toc187833969)

[3.5 Review and Approval of Error Trade Claim 10](#_Toc187833970)

[3.5.1 Review of Error Trade Claim 10](#_Toc187833971)

[3.5.2 Communication with Exchange Participants and Market 10](#_Toc187833972)

[3.5.2.1 Acceptance of Error Trade Claim 10](#_Toc187833973)

[3.5.2.2 Rejection of Error Trade Claim 11](#_Toc187833974)

[3.5.2.3 Large Error Trade (LET) of Error Trade Claim 11](#_Toc187833975)

[3.5.3 Claimed Trade Retention and Cancellation 11](#_Toc187833976)

[3.6 Example 12](#_Toc187833977)

[3.7 Other Operation Requirements 14](#_Toc187833978)

[4. Large-Scale Error Trade (LET) Handling 15](#_Toc187833979)

[4.1 Initiation of LET 15](#_Toc187833980)

[4.2 Confirmation of LET 15](#_Toc187833981)

[5. Trade Cancellation 17](#_Toc187833982)

[5.1 Initiation of Trade Cancellation 17](#_Toc187833983)

[5.2 Cancellation of Trade 17](#_Toc187833984)

[5.3 Trade Cancellation Window 18](#_Toc187833985)

[5.4 Other Operation Requirements 18](#_Toc187833986)

[6. Trade Adjustment 19](#_Toc187833987)

[6.1 Initiation of Trade Adjustment 19](#_Toc187833988)

[6.2 Adjustment of Trade 19](#_Toc187833989)

[6.3 Trade Adjustment Window 20](#_Toc187833990)

[7. Day 2 Requirements 21](#_Toc187833991)

[7.1 Indicative Quotes 21](#_Toc187833992)

[7.2 Client Portal information retrieval 21](#_Toc187833993)

[7.3 Report Generation 21](#_Toc187833994)

# Document Control

## Change History

|  |  |  |  |
| --- | --- | --- | --- |
| Version  Number | Issue Date | Author | Abstract |
| 0.1 | 02 May 2024 | IT/Markets Systems | Initial Version |
| 0.2 | 27 May 2024 | IT/Markets Systems | Updated base on BRS Review Log and updated requirement |
| 0.3 | 05 June 2024 | IT/Markets Systems | Incorporated Trade Cancellation and Adjustment requirements |
| 0.4 | 28 June 2024 | IT/Markets Systems | Added tags for traceability |
| 0.5 | 11 Nov 2024 | IT/Markets Systems | Updated base on updated BRS dated 20241031 |
| 0.6 | 08 Jan 2025 | IT/Markets Systems | Updated base on BRS dated 20250108 |
| 0.7 | 24 Mar 2025 | IT/Markets Systems | Updated according to Functional Specification Checklist |
| 0.8 | 15 Jul 2026 | IT/Markets Systems | Updated per user request to add Market Message dissemination channel.  Updated trading state conditions for Trade Cancellation and Trade Adjustment. |

## Document Cross-referenced

|  |  |  |
| --- | --- | --- |
| # | Document | Version |
| 1 | BRD\_DT\_0007 ODP – NewFunctionRequest – Error Trade | 20250121 |
| 2 | BRD\_DT\_0016 ODP – NewFunctionRequest – Trade Cancellation and Adjustment | 20250108 |
| 3 | BRD\_DT\_0003 BRS Order Book Execution Management | 20250121 |
| 4 | HKFE Exchange Rule | 29 Mar 2024 |
| 5 | FS10003 – Orderbook and Execution Management | 31 Oct 2024 |
| 6 | FS10019 - Market Message | 18 Oct 2024 |
| 7 | FS10012 - Trade Stats and Info Dissemination | 22 Jan 2025 |
| 8 | FS10001 – Trading Timetable | 17 Oct 2024 |

## Abbreviation

|  |  |
| --- | --- |
| ODP | Orion Derivatives Platform |
| ODP-T | ODP - Trading |
| TMC | Tailor-Made Combination |
| EP | Exchange Participant |
| GUI | Graphical User Interface |
| LET | Large-Scale Error Trade |
| OMD-D | Orion Market Data Platform - Derivatives Market |
| DT | Derivatives Trading |
| PQF | Price Quotation Factor |

# Introduction

**#FS10009\_S0020\_00100**

Under HKFE Exchange Rule 819B/Options Trading Rules 540, if a trade takes place on the trading system at a level which deviates from the price parameters from time to time established by the Exchange and notified to Exchange Participants (the “Price Parameters”), the Exchange will entertain any claim from an original party to the trade that the price was in error.

**#FS10009\_S0020\_00200**

Effective on 7th December 2020, the Exchange supplemented the Error Trade Handling Procedures with a new set of Large-Scale Error Trade (“LET”) Handling Procedures. Large-Scale Error Trade Handling Procedures aims to enhance the Exchange’s ability to handle LET in a timely manner. Under the new LET procedures, the Exchange will consider factors, such as the number of trades, counterparties, and instrument/combo involved, to determine whether the claim should be handled as a LET claim. A model for quicker Notation/Reference Price determination by theoretical prices on outright options contracts will be used to facilitate the identification of related error trades and affected counterparties.

**#FS10009\_S0020\_00300**

In addition to the above mentioned error trade handling, Derivative Trading (DT) Operations can cancel an exchange matched trade.

**#FS10009\_S0020\_00400**

For explicit strategy order vs strategy order (a.k.a. combo vs combo) matches in the order book, DT Operations can adjust the trade price of each leg upon request from the Exchange Participants (EPs) who are the original parties to the subject trade.

# Error Trade Handling

EPs that are original parties of a trade can file error trade claims to the Exchange if the trades deviate from the established Error Trade Price Parameters. The claim request will be handled by an auxiliary service within ODP-T but outside of the central order book processing due to the complex price validation logics.

## Overview

Followings are the parties involved in an Error Trade Claim:

**#FS10009\_S0030\_00050**

|  |  |
| --- | --- |
| Party | Description/Remarks |
| Claimant Trade Owning CompID | The originating trading session of the claimant EP on which the order executed in the subject trade of the Error Trade Claim was submitted. It can submit Error Trade Claim on owned trades.  The specific trade cancellation resulting from the Error Trade Claim will always be sent to this session. |
| Claimant Nominated CompID | The optional nominated trading session of the claimant EP which can submit on-behalf Error Trade Claim for trades from trading sessions of the claimant EP. |
| Claim Submitting CompID | The trading session on which the Error Trade Claim is submitted.[[1]](#footnote-1)  This can be either (i) Claimant Trade Owning Comp ID or (ii) Claimant Nominated Comp ID, if there exists one.  Subsequent messages related to the specific Error Trade Claim (i.e. the acknowledgement and accept/reject notification) will always be sent on this session for the Claimant EP. |
| DT Operations | Through the Trading GUI of DT, the DT operations decides whether to accept, reject or approve an Error Trade Claim. |
| Contra-EP Trade Owning CompID | The originating trading session of the contra-EP on which the order executed in the subject trade of the Error Trade Claim was submitted.  The specific trade cancellation resulting from the Error Trade Claim will always be sent to this session. |
| Contra-EP Nominated CompID | The optional nominated trading session of the Contra-EP. It receives all Error Trade Claim notifications resulting from claims initiated by other EPs. |
| Contra-EP Claim Accepting CompID | The trading session of the contra-EP on which the Error Trade Claim notification is delivered for response. This can be either (i) Contra-EP Trade Owning CompID, if no nomination is made; or (ii) Contra-EP Nominated CompID, if nomination is made.  Subsequent messages related to the specific Error Trade Claim (i.e. the acknowledgement and accept/reject notification) will always be sent on this session for the Contra-EP. |

The Error Trade Claim process can be summarized with the following steps and the subsequent sections describe the process in detail.

1. The Claimant EP submits Error Trade Claim via the Claim Submitting CompID.
2. DT Operations validates the Error Trade Claim submissions and decides whether to accept or reject the claim.
3. If the claim is accepted, the contra-EP is notified via the Contra-EP Claim Accepting CompID. The Contra-EP may respond by accepting or declining the claim.
4. DT Operations retains or cancels the subject trade based on the trading rules.
5. Claimant Trade Owning CompID and Contra-EP Trade Owning CompID receive the trade cancellation if the trade is cancelled. Such cancellation will be sent to clearing.

## Submission of Claim

There are two ways an Exchange Participant (EP) can submit an error trade claim to OTP-D:

**#FS10009\_S0030\_00100**

* By selecting a trade in the Trading GUI and press the “Error Trade Claim” button. This is also applicable to Derivative Trading (DT) Operations.

**#FS10009\_S0030\_00200**

* By submitting a transaction-based request via the direct trading session with the Trade ID and instrument/combo identifier of the error trade to be claimed.

**#FS10009\_S0030\_00205**
It should be noted that only exchange order book matched trades are subjected to error trade claim. Followings are the types of trades that are not allowed for error trade claims:

* Block trades
* Trades entered by the exchange (e.g. Internal On-Behalf Enter Trade – Refer to Section 3.1.3.10 in BRS Order Book Execution Management)
* Trades of strategy legs from an explicit combo-vs-explicit combo trade

**#FS10009\_S0030\_00240**

The trading system will reject the initiation of error trade claim when an error trade claim is still in progress for the specific trade (identified by Trade ID and Instrument/Combo ID) regardless of the initiator. This is to avoid having two different trading sessions (i.e. the nominated trading session and the originating trading session) initiating error trade claim on the same trade simultaneously. Initiation of error trade claim on a trade that is already cancelled will also be rejected.

**#FS10009\_S0030\_00300**

Upon the reception of the claim, the trading system should validate the corresponding Trade ID and the instrument/combo identifier provided.

**#FS10009\_S0030\_00500** A new item will be shown in the Error Trade Request window in the Trading GUI of the Derivative Trading (DT) Operations with status marked as “New”. Details of the trade claim are available for review in the detail window, which includes the following:

* Claimant EP ID and side of the trade
* Contra-side EP ID and side of the trade
* Instrument/Combo ID
* Price
* Quantity
* Trade Time

## Validation of Error Trade Claim

**#FS10009\_S0030\_00600**

In addition to the validation of the Trade ID and the instrument/combo, the trading system also validates the Time of the Claim.

### Time of the Claim Validation

**#FS10009\_S0030\_00700**

The trading system validates the time of the claim to ensure that the claim is submitted within a configurable period (in minutes) after the trade was made. **#FS10009\_S0030\_00710** This configuration parameter is defined at the Instrument Type/Combo Type level using respective function in Admin GUI.

**#FS10009\_S0030\_00720**

Under the current trading rules, the prescribed time limit after execution of the trade and expected configuration are as follows:

|  |  |
| --- | --- |
| Category | Prescribed Time Limit |
| Futures and Call/Put Options (except Stock Options) and standard strategies (combinations) Trade | 10 minutes |
| Stock Options (Call/Put) Trade | 30 minutes |
| Tailor-Made Combination Trade | 30 minutes |

## Reference Price Capture

**#FS10009\_S0030\_00750**

Upon reception of the error trade claim, the trading system retrieves the Last Traded Price and the Best Bid/Ask Prices prior to the claimed trade of the instrument. These prices will be displayed in the detail window of Trading GUI of the DT operations when the retrieval is complete. For prices that are not available, “N/A” will be displayed.

## Review and Approval of Error Trade Claim

### Review of Error Trade Claim

**#FS10009\_S0030\_01300**

DT Operations can view the following information in the detail window:

* Result of the time validation
* Instrument ID/Combo ID of the claimed trade
* Traded price of the claimed trade
* Traded quantity of the claimed trade
* Traded time of the claimed trade
* Time of claim
* Claimant EP
* Contra-side EP
* Trade ID of the claimed trade
* Captured reference prices as defined in section 3.4

**#FS10009\_S0030\_01310**

DT Operations decides the action based on the validation results. The allowed actions are listed below:

|  |  |  |  |
| --- | --- | --- | --- |
| Time Validation Result | Actions | | |
| Reject | Accept | Initiate LET |
| Pass | ü | ü | ü |
| Failed | ü | û | û |

### Communication with Exchange Participants and Market

#### Acceptance of Error Trade Claim

**#FS10009\_S0030\_01320**

When DT Operations accepts the Error Trade Claim, it is required to input the actual reference price in the detail window. The trading GUI should calculate the Price Deviation and Potential Loss based on the following formula:

$$Price Deviation= \left|Reference Price - Traded Price\right|$$

$$Potential Loss= \left|Reference Price - Traded Price\right|×PQF×Traded Qty$$

**#FS10009\_S0030\_01400**

A message will be sent to both the Claim Submitting CompID and the Contra-EP Claim Accepting CompID. The message includes the status of claim (i.e. Accepted), Trade ID of the claimed trade, corresponding traded price and quantity. **#FS10009\_S0030\_01410** A market message is also sent through the Trading GUI, Binary (i.e. Direct Order Flow Sessions) and OMD-D to the entire market. DT Operations configures the message template to be used by selecting a message template1 defined in the system at the same product hierarchy level as the Error Trade Price Parameters. The status of the error trade claim will be updated to “Accepted”.

**#FS10009\_S0030\_01411**

Upon the reception of the Error Trade Notification, the Contra-side EP should respond to the notification via the Contra-EP Claim Accepting CompID. The Contra-side EP has the option to accept or reject the corresponding error trade claim. **#FS10009\_S0030\_01412** The Contra-side EP should respond within a configurable time (in minutes, at Instrument Type/Combo Type level). When the Contra-side EP attempts to respond after the configurable time or if the claim is already approved/rejected, such response will be rejected by the trading system.

#### Rejection of Error Trade Claim

**#FS10009\_S0030\_01420** When DT Operations rejects the Error Trade Claim, a message is sent to the Claim Submitting CompID. The message includes the status of claim (i.e. Rejected), Trade ID of the claimed trade, time of claim (time at which the trading system received the claim, in nanosecond accuracy) and the corresponding traded price and quantity. The status of the error trade claim will be updated to “Rejected”.

#### Large Error Trade (LET) of Error Trade Claim

**#FS10009\_S0030\_01430** If the DT Operations decides to Initiate LET, a trade file is generated by the system for download which can be used to initiate LET through the process mentioned in Section 4.1. The status of the corresponding error trade claims will be updated to “Processed”.

### Claimed Trade Retention and Cancellation

**#FS10009\_S0030\_01500**

Upon the acceptance of the error trade claim, the system allows DT Operations to retain or cancel the claimed trade after the decision is made regardless of the Contra-EP’s response.

**#FS10009\_S0030\_01510**

If the claimed trade is retained, a market message is sent through the Trading GUI, Binary (i.e. Direct Order Flow Sessions) and OMD-D to the entire market. DT Operations configures the retain message template to be used by selecting a message template1 defined in the system at the same product hierarchy level as the Error Trade Price Parameters. The status of the error trade claim on DT Operations screen will be updated to “Rejected”.

**#FS10009\_S0030\_01520**

For claimed trade that proceeds to be cancelled, DT Operations selects whether the error trade is approved by participant or by committee.

**#FS10009\_S0030\_01530**

After the confirmation, the trading system will perform the following actions:

1. Sends a message to the clearing system for further processing. An acknowledgement from the clearing system is expected after the message is processed. The trading system keeps track whether such an acknowledgement is received from the clearing system and display the status in the detail window.
2. At the same time, the trading system updates the market information, including the open, high, low, last and turnover (refer to FS10012 - Trade Stats and Info Dissemination for details).
3. A message will be sent to the claimant EP and the contra-side EP through the Claimant Trade Owning CompID and Contra-EP Trade Owning CompID respectively. The message includes the Trade ID, price and quantity of the cancelled trade.
4. A market message is sent through the Trading GUI, Binary (i.e. Direct Order Flow Sessions) and OMD-D to the entire market. DT Operations configures two templates to be used by selecting a message template[[2]](#footnote-2) defined in the system at the same product hierarchy level as the Error Trade Price Parameters, one for error trade by participant and the other by committee. The system will determine the template based on the selected option in which the cancellation was made.
5. The status of the error trade claim will be updated to “Processed”.

It should be noted that the trade will only be cancelled when Cancel and Adjust Trade function is allowed in the current trading state of the corresponding instrument/combo (Refer to FS – Trading Timetable Section 6.2.2). Otherwise, the cancel will be rejected.

## Example

Example – Stock Index Options (e.g. HSIC/HSIP)

*Time Validation Parameter*

|  |
| --- |
| Prescribed Time Limit (minutes) |
| 10 |

*EP Response Parameter*

|  |
| --- |
| Contra EP Response Limit (minutes) |
| 10 |

*Market Message Template*

|  |  |
| --- | --- |
| Accepted Claim Application Template | HKFE\_ERROR\_TRADE\_ACCEPT |
| Claimed Trade Retained | HKFE\_ERROR\_TRADE\_RETAINED |
| Claimed Trade Cancelled (By Participant) | HKFE\_ERROR\_TRADE\_EP |
| Claimed Trade Cancelled (By Committee) | HKFE\_ERROR\_TRADE\_PANEL |

*Message Templates[[3]](#footnote-3)*

Template ID: HKFE\_ERROR\_TRADE\_ACCEPT

Error Trade Alert

Pursuant to HKFE Rule 819B, please be advised that the following trade is claimed to be error trade and may be subjected to correction:

Contract = {NAME}

Price = {TRADED\_PRICE}

Traded Time = {TRADE\_TIME}

Any objection from Participants of its correction must be brought to the attention of the Exchange, with explanatory reasons, by calling +852 2211-6360 within 10 minutes of this notification.

Template ID: HKFE\_ERROR\_TRADE\_RETAINED

Error Trade

Pursuant to HKFE Rule 819B, please be advised that the following trade is claimed to be error trade but not deemed as erroneous:

Contract = {NAME}

Price = {TRADED\_PRICE}

Traded Time = {TRADE\_TIME}

Template ID: HKFE\_ERROR\_TRADE\_EP

Error Trade (By participant)

Pursuant to HKFE Rule 819B, please be advised that the following trade is declared as erroneous.

Contract = {NAME}

Price = {TRADED\_PRICE}

Quantity = {TRADED\_QTY}

Trade ID = {TRADE\_ID}

Traded Time = {TRADE\_TIME}

Template ID: HKFE\_ERROR\_TRADE\_PANEL

Error Trade (By committee)

Pursuant to HKFE Rule 819B, please be advised that the following trade is declared as erroneous as reviewed by the HKATS Error Trade Review Panel:

Contract = {NAME}

Price = {TRADED\_PRICE}

Quantity = {TRADED\_QTY}

Trade ID = {TRADE\_ID}

Traded Time = {TRADE\_TIME}

## Other Operation Requirements

**#FS10009\_S0030\_01700**

DT Operations is allowed to submit error trade claims internally by selecting multiple trades in the internal Trading GUI. Same processes of error trade claim will be initiated which allows DT Operations to handle each error trade accordingly.

**#FS10009\_S0030\_01800** A file upload function is provided to allow DT Operations to specify a list of Trade IDs to initiate error trade claims. Each trade includes in the file is validated and processed independently.

# Large-Scale Error Trade (LET) Handling

Large-Scale Error Trade (“LET”) Handling Procedures aims to enhance the Exchange’s ability to handle LET in a timely manner. Under the LET procedures, the Exchange will consider factors, such as the number of trades, counterparties, and contracts involved, to determine whether the claim should be handled as a LET claim.

## Initiation of LET

**#FS10009\_S0040\_00100**

Given LET is most probably triggered due to EP system malfunction, LET remains to be a manual procedure initiated by DT Operations.

**#FS10009\_S0040\_00110**

There are two ways to initiate the LET in the trading system:

1. DT Operations can specify the followings for the LET satellite to retrieve related trades:
   1. Market, with multiple market support
   2. Participant ID, optional
   3. Time Range, mandatory
2. DT Operations can upload a trade file, which includes a list of Trade IDs to be included in a LET claim.

**#FS10009\_S0040\_00120** Through the satellite LET system, the trading system retrieves the following information to DT Operations. This includes the following information according to the criteria or trade list provided:

* + Number of contracts involved
  + Number of trades involved
  + Number of EPs involved

It should be noted that the numbers provided in the notification do not need to have the trade price validated.

## Confirmation of LET

**#FS10009\_S0040\_00200**

With the notification, DT Operations decides whether to proceed the LET or not. It is possible to terminate the LET process by rejecting the LET initiation.

**#FS10009\_S0040\_00220**

The trading system relies on the LET satellite system to carry out the price validations and receives a list of trades to be cancelled in the LET.

**#FS10009\_S0040\_00230**

For each of the qualified trade, the trading system performs the following:

1. Sends a message to the clearing system for further processing. An acknowledgement from the clearing system is expected after the message is processed. The trading system keeps track whether such an acknowledgement is received from the clearing system.
2. A message will be sent to both parties involved in the specific trade through the trade owning trading sessions. The message includes the Trade ID, price and quantity of the cancelled trade.

**#FS10009\_S0040\_00250**

The trading system will update the market information, including the open, high, low, last and turnover (refer to FS10012 - Trade Stats and Info Dissemination for details) without waiting for any clearing acknowledgement.

It should be noted that trades will only be cancelled when Cancel Trade and Adjust function is allowed in the current trading state of the corresponding instrument/combo (Refer to FS – Trading Timetable Section 6.2.2). It is possible that some of the trades in the LET cannot be cancelled due to the timetable limitation.

# Trade Cancellation

Trade cancellation allows DT Operations to cancel an exchange matched trade (i.e. order book matched trades and block trades) under special circumstances. For error trade, one should refer to Section 3 for appropriate market communications as required in the trading rule.

## Initiation of Trade Cancellation

**#FS10009\_S0050\_00100**

Trade Cancellation can only be initiated by DT Operations. DT Operations can select an exchange matched trade from the trade view to initiate the trade cancellation. DT Operations only needs to select one side (either the buy side or the sell side) of the trade to initiate the trade cancellation.

**#FS10009\_S0050\_00110**

DT Operations also selects the reason of cancellation from a drop box with following options before the trade cancellation is submitted to the system:

* Error Trade
* Invalid Block Trade
* Others

## Cancellation of Trade

It should be noted that trade will only be cancelled when Admin Trade Cancel function is allowed in the current trading state of the corresponding instrument/combo (Refer to FS – Trading Timetable Section 6.2.2). Otherwise, the trade cancellation request will be rejected.

**#FS10009\_S0050\_00200**

When the Trade Cancellation is confirmed, the trading system will:

1. Sends a message to the clearing system for further processing. An acknowledgement from the clearing system is expected after the message is processed. The trading system keeps track whether such an acknowledgement is received from the clearing system.
2. At the same time, the trading system updates the market information, including the open, high, low, last and turnover (refer to FS10012 - Trade Stats and Info Dissemination for details).
3. A message will be sent to the claimant EP and the contra-side EP through the trading session of the claimed trade to notify of the trade cancellation.

**#FS10009\_S0050\_00210**

The internal trade cancellation message within the trading system will carry the cancelled Trade ID and the cancellation reason. These will be reflected in the message to the clearing system and other downstream system through the interface between. The message gap detection and recovery mechanism will be addressed in the corresponding interface specification.

## Trade Cancellation Window

**#FS10009\_S0050\_00300**

All Trade Cancellation requests made by DT Operations will be displayed in a Trade Cancellation window of trading GUI of DT operations with the following information:

* Time of the Trade Cancellation Request
* Trade ID
* Instrument/Combo ID of the cancelled trade
* Reason of cancellation
* Clearing Status

## Other Operation Requirements

**#FS10009\_S0050\_00400** A file upload function is provided to allow DT Operations to specify a list of Trade IDs and reason of cancellation for trade cancellations in the trade view. Each entry, which contains the Trade ID and the corresponding reason, includes in the file is validated, approved and processed independently.

# Trade Adjustment

When an explicit order trades with another explicit order in the strategy book (a.k.a. combo vs combo trade), the trading system calculates the trade prices for each legs according to the Leg Price Calculation Algorithm specified in FS – Orderbook and Execution Management Section 6.3. Under some scenarios, the calculated price may not be in line with the market and therefore, EPs may submit request to DT Operations for Trade Adjustment.

## Initiation of Trade Adjustment

**#FS10009\_S0060\_10100**

Trade Adjustment can only be initiated by DT Operations. DT Operations can select a trade on a strategy book (which includes both standard strategy and Tailor-Made strategy) in the trade view to initiate the trade adjustment. DT Operations only requires selecting one side of the strategy trade (either the buy side or the sell side) on the strategy book.

**#FS10009\_S0060\_10110**

The system validates that the selected strategy trade is an explicit order vs explicit order trade. Trade Adjustment is not allowed if this validation fails.

**#FS10009\_S0060\_10120**

Upon the initiation, DT Operations is allowed to enter the intended prices of each leg. The system validates the intended price:

1. The input price of each strategy leg is aligned to the price tick defined in the system.
2. The Net Price is equal to the original strategy trade price. The Net Price is calculated according to the following formula.

$$Net Price= \left(\sum\_{\begin{array}{c}x\in Legs\\x\in Buy\end{array}}^{}Price\_{x}×Ratio\_{x}\right)-\left(\sum\_{\begin{array}{c}y\in Legs\\y\in Sell\end{array}}^{}Price\_{y}×Ratio\_{y}\right)$$

**#FS10009\_S0060\_10130**

The system rejects any adjustment failing these validations.

## Adjustment of Trade

It should be noted that trade will only be amended when Admin Trade Price Adjustment function is allowed in the current trading state of the corresponding instrument/combo (Refer to FS – Trading Timetable Section 6.2.2). Otherwise, the trade adjustment request will be rejected.

**#FS10009\_S0060\_10200**

When the trade adjustment is confirmed, the system will:

1. Sends a message as trade amendment to the clearing system for further processing. An acknowledgement from the clearing system is expected after the message is processed. The trading system keeps track whether such an acknowledgement is received from the clearing system.
2. A message will be sent to the EPs of both side of the trade through the trade owning trading session to notify of the trade adjustment.

**#FS10009\_S0060\_10210**

The trade adjustment message is sent to the to the clearing system and other downstream through the interface between. The message gap detection and recovery mechanism will be addressed in the corresponding interface specification.

## Trade Adjustment Window

**#FS10009\_S0060\_10300**

All Trade Adjustment requests made by DT Operations will be displayed in a Trade Adjustment window with the following information:

* Time of the Trade Adjustment Request
* Trade ID
* Traded Strategy (a.k.a. Combo) Contract Name
* Clearing Status

# Day 2 Requirements

The items listed in this section are requirements that requires more clarifications on the scope for analysis. It is agreed that these requirements will not be included in the Day 1. Further discussion is required on the coverage of these requirements.

## Indicative Quotes

**#FS10009\_S0080\_00100**

It is proposed that the Trading System should allow DT Operations to send quote request to market makers only. Upon receiving the quote request, the market makers can reply with indicative quotes that are not tradable and shown outside of the central order book.

## Client Portal information retrieval

**#FS10009\_S0080\_00200**

The trading system should retrieve contact details of the claimant EPs and contra-side EPs from the “Client Portal”.

## Report Generation

**#FS10009\_S0080\_00300**

The trading system should allow DT Operations to generate:

* Incident Report
* Claim Assessment
* Minutes of Error Trade Review

1. For clarity, both Claimant Trade Owning CompID and Claimant Nominated CompID can assume the role of Claim Submitting CompID for a specific trade. However, only one of them can assume the role of Claim Submitting CompID throughout a claim process. [↑](#footnote-ref-1)
2. The maximum characters included in the message is limited to 900 ASCII characters due to the limitation of OMD-D. Refer to FS10019 - Market Message for details. [↑](#footnote-ref-2)
3. Message Templates here are not part of the Error Trade Parameters Configuration. They illustrate the setup of template based on the FS10019 – Market Messages. [↑](#footnote-ref-3)
