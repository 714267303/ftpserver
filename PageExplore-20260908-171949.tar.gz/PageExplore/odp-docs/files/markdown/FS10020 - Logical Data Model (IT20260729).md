TITLE:

**FUNCTIONAL SPECIFICATION**

***ODP-TR***

*FS10020 Logical Data Model*

AUTHOR : *IT/Markets Systems*  DATE : *29 Jul 2026*

LAST REVIEW *Derivatives Trading Business Operations* DATE : *28 Feb 2025*

**CONTENTS**

[1. Document Control 6](#__RefHeading___Toc236222939)

[1.1. Change History 6](#__RefHeading___Toc236222940)

[1.2. Document Cross-referenced 6](#__RefHeading___Toc236222941)

[1.3. Abbreviation 7](#__RefHeading___Toc236222942)

[2. Introduction 8](#__RefHeading___Toc236222943)

[2.1. Entity 8](#__RefHeading___Toc236222944)

[2.2. Attribute 8](#__RefHeading___Toc236222945)

[2.3. Data Model 8](#__RefHeading___Toc236222946)

[3. Logical Data Relationship 9](#__RefHeading___Toc236222947)

[3.1. Product 9](#__RefHeading___Toc236222948)

[3.2. Participant 9](#__RefHeading___Toc236222949)

[3.3. Pre-Trade Risk Management (PTRM) 10](#__RefHeading___Toc236222950)

[3.4. Market Message 11](#__RefHeading___Toc236222951)

[3.5. Exchange User & GUI 11](#__RefHeading___Toc236222952)

[3.6. Instrument & Combo Generation 11](#__RefHeading___Toc236222953)

[3.7. Report 11](#__RefHeading___Toc236222954)

[4. Data Flow Diagrams 12](#__RefHeading___Toc236222955)

[5. Data Classification 13](#__RefHeading___Toc236222956)

[6. Location of Data 14](#__RefHeading___Toc236222957)

[7. Logical Data Entities 15](#__RefHeading___Toc236222958)

[7.1. Product 15](#__RefHeading___Toc236222959)

[7.1.1. Access Group By Type 15](#__RefHeading___Toc236222960)

[7.1.2. Access Group By Type – Combo Type 15](#__RefHeading___Toc236222961)

[7.1.3. Access Group By Type – Instrument Type 15](#__RefHeading___Toc236222962)

[7.1.4. Block Trade Group 15](#__RefHeading___Toc236222963)

[7.1.5. Block Trade MVT 15](#__RefHeading___Toc236222964)

[7.1.6. Block Trade MVT Band 15](#__RefHeading___Toc236222965)

[7.1.7. Capital Adjustment Event 15](#__RefHeading___Toc236222966)

[7.1.8. Capital Adjustment Event – Item 16](#__RefHeading___Toc236222967)

[7.1.9. Capital Adjustment Instrument 17](#__RefHeading___Toc236222968)

[7.1.10. Capital Adjustment Instrument Class 17](#__RefHeading___Toc236222969)

[7.1.11. Capital Adjustment Underlying 17](#__RefHeading___Toc236222970)

[7.1.12. Combo 17](#__RefHeading___Toc236222971)

[7.1.13. Combo Class 18](#__RefHeading___Toc236222972)

[7.1.14. Combo Class Price Tick Limit 18](#__RefHeading___Toc236222973)

[7.1.15. Combo Group 19](#__RefHeading___Toc236222974)

[7.1.16. Combo Leg 19](#__RefHeading___Toc236222975)

[7.1.17. Combo Type 19](#__RefHeading___Toc236222976)

[7.1.18. Combo Type Error Trade Parameters 19](#__RefHeading___Toc236222977)

[7.1.19. Exchange 20](#__RefHeading___Toc236222978)

[7.1.20. Futures Group 20](#__RefHeading___Toc236222979)

[7.1.21. Futures Group – Item 20](#__RefHeading___Toc236222980)

[7.1.22. Halt Target List 20](#__RefHeading___Toc236222981)

[7.1.23. Halt Target List – Item 20](#__RefHeading___Toc236222982)

[7.1.24. Instrument 21](#__RefHeading___Toc236222983)

[7.1.25. Instrument – Daily Settlement Price 21](#__RefHeading___Toc236222984)

[7.1.26. Instrument – Daily Settlement Price History 21](#__RefHeading___Toc236222985)

[7.1.27. Instrument Class 22](#__RefHeading___Toc236222986)

[7.1.28. Instrument Class Price Tick Limit 22](#__RefHeading___Toc236222987)

[7.1.29. Instrument Group 23](#__RefHeading___Toc236222988)

[7.1.30. Instrument Type 23](#__RefHeading___Toc236222989)

[7.1.31. Instrument Type Error Trade Parameters 24](#__RefHeading___Toc236222990)

[7.1.32. Market 24](#__RefHeading___Toc236222991)

[7.1.33. Non-Trading Days 25](#__RefHeading___Toc236222992)

[7.1.34. Non-Trading Days - Item 25](#__RefHeading___Toc236222993)

[7.1.35. Price Limit 25](#__RefHeading___Toc236222994)

[7.1.36. Price Limit – Item 25](#__RefHeading___Toc236222995)

[7.1.37. Price Limit Parameters 25](#__RefHeading___Toc236222996)

[7.1.38. Price Limit Alert Rule 26](#__RefHeading___Toc236222997)

[7.1.39. Price Limit Alert Rule – Item 26](#__RefHeading___Toc236222998)

[7.1.40. Price Limit Rule 26](#__RefHeading___Toc236222999)

[7.1.41. Price Limit Rule – Individual Band 27](#__RefHeading___Toc236223000)

[7.1.42. Price Tick 27](#__RefHeading___Toc236223001)

[7.1.43. Price Tick Order Band 27](#__RefHeading___Toc236223002)

[7.1.44. Price Tick Block Trade Band 27](#__RefHeading___Toc236223003)

[7.1.45. Price Tick Limit Rule 27](#__RefHeading___Toc236223004)

[7.1.46. Reference Price Source 28](#__RefHeading___Toc236223005)

[7.1.47. Reference Price Source – Item 28](#__RefHeading___Toc236223006)

[7.1.48. Reference Price Calculation Rule 28](#__RefHeading___Toc236223007)

[7.1.49. Reference Price Calculation Rule – Item 28](#__RefHeading___Toc236223008)

[7.1.50. Special Trading Days 29](#__RefHeading___Toc236223009)

[7.1.51. Special Trading Days – Item 29](#__RefHeading___Toc236223010)

[7.1.52. TMC Strategy 29](#__RefHeading___Toc236223011)

[7.1.53. TMC Strategy Leg 29](#__RefHeading___Toc236223012)

[7.1.54. TMC Strategy List 30](#__RefHeading___Toc236223013)

[7.1.55. TMC Strategy List - Item 30](#__RefHeading___Toc236223014)

[7.1.56. Trading State 30](#__RefHeading___Toc236223015)

[7.1.57. Trading Timetable 32](#__RefHeading___Toc236223016)

[7.1.58. Trading Timetable Session – Trading State 32](#__RefHeading___Toc236223017)

[7.1.59. Underlying 32](#__RefHeading___Toc236223018)

[7.1.60. Underlying - Price 33](#__RefHeading___Toc236223019)

[7.1.61. Underlying – Price History 33](#__RefHeading___Toc236223020)

[7.1.62. Underlying – Status 34](#__RefHeading___Toc236223021)

[7.1.63. VCM 34](#__RefHeading___Toc236223022)

[7.1.64. VCM – Item 34](#__RefHeading___Toc236223023)

[7.1.65. VCM Parameters 34](#__RefHeading___Toc236223024)

[7.2. Participant 34](#__RefHeading___Toc236223025)

[7.2.1. Company 34](#__RefHeading___Toc236223026)

[7.2.2. Drop Copy Group 34](#__RefHeading___Toc236223027)

[7.2.3. Drop Copy Group – Trader ID 35](#__RefHeading___Toc236223028)

[7.2.4. Drop Copy Session 35](#__RefHeading___Toc236223029)

[7.2.5. Drop Copy Session – Drop Copy Group 35](#__RefHeading___Toc236223030)

[7.2.6. Exchange Participant 35](#__RefHeading___Toc236223031)

[7.2.7. IP Address List 35](#__RefHeading___Toc236223032)

[7.2.8. IP Address List – Item 36](#__RefHeading___Toc236223033)

[7.2.9. MMP Parameters 36](#__RefHeading___Toc236223034)

[7.2.10. Order Flow Session 36](#__RefHeading___Toc236223035)

[7.2.11. Order Flow Session – Trader ID 36](#__RefHeading___Toc236223036)

[7.2.12. Participant Trading Rights 36](#__RefHeading___Toc236223037)

[7.2.13. Participant User Role 36](#__RefHeading___Toc236223038)

[7.2.14. Self Admin Portal User 37](#__RefHeading___Toc236223039)

[7.2.15. Self Admin Portal User Extended 37](#__RefHeading___Toc236223040)

[7.2.16. Session 38](#__RefHeading___Toc236223041)

[7.2.17. Session Extended 38](#__RefHeading___Toc236223042)

[7.2.18. Session Extended – GUI User 39](#__RefHeading___Toc236223043)

[7.2.19. SMP ID 39](#__RefHeading___Toc236223044)

[7.2.20. SMP ID List 39](#__RefHeading___Toc236223045)

[7.2.21. SMP ID List – Item 39](#__RefHeading___Toc236223046)

[7.2.22. SMP Request 40](#__RefHeading___Toc236223047)

[7.2.23. Trader ID 40](#__RefHeading___Toc236223048)

[7.2.24. Trader ID – Trading GUI User 41](#__RefHeading___Toc236223049)

[7.2.25. Trading GUI User 41](#__RefHeading___Toc236223050)

[7.2.26. Trading Right 41](#__RefHeading___Toc236223051)

[7.2.27. Trading Right – Item 41](#__RefHeading___Toc236223052)

[7.3. PTRM 41](#__RefHeading___Toc236223053)

[7.3.1. PTRM GUI User 41](#__RefHeading___Toc236223054)

[7.3.2. PTRM Session 42](#__RefHeading___Toc236223055)

[7.3.3. PTRM Session – PTRM GUI User 42](#__RefHeading___Toc236223056)

[7.3.4. Risk Group 42](#__RefHeading___Toc236223057)

[7.3.5. Risk Group – Order Coefficient 42](#__RefHeading___Toc236223058)

[7.3.6. Risk Group – Risk Check Limit 42](#__RefHeading___Toc236223059)

[7.3.7. Risk Group Notification List 43](#__RefHeading___Toc236223060)

[7.3.8. Risk Group Notification List – Item 43](#__RefHeading___Toc236223061)

[7.3.9. Risk Group Position Limit 43](#__RefHeading___Toc236223062)

[7.3.10. Risk Group Position Limit – Tradable Risk Check Limit 43](#__RefHeading___Toc236223063)

[7.3.11. Risk Group Tradable 44](#__RefHeading___Toc236223064)

[7.3.12. Risk Group Tradable List 44](#__RefHeading___Toc236223065)

[7.3.13. Risk Group User List 44](#__RefHeading___Toc236223066)

[7.3.14. Risk Group User List – Item 44](#__RefHeading___Toc236223067)

[7.3.15. Sponsoring Participant 44](#__RefHeading___Toc236223068)

[7.3.16. Sponsoring Participant – Sponsored Participant 45](#__RefHeading___Toc236223069)

[7.4. Market Message 45](#__RefHeading___Toc236223070)

[7.4.1. Automatic Event Message 45](#__RefHeading___Toc236223071)

[7.4.2. Market Message Template 46](#__RefHeading___Toc236223072)

[7.5. Exchange User & GUI 46](#__RefHeading___Toc236223073)

[7.5.1. Application 46](#__RefHeading___Toc236223074)

[7.5.2. Application Function 46](#__RefHeading___Toc236223075)

[7.5.3. Exchange User 47](#__RefHeading___Toc236223076)

[7.5.4. Exchange User – Role 47](#__RefHeading___Toc236223077)

[7.5.5. Local Inactive Order 47](#__RefHeading___Toc236223078)

[7.5.6. Permission 48](#__RefHeading___Toc236223079)

[7.5.7. Permission – Item 48](#__RefHeading___Toc236223080)

[7.5.8. UI System Preference 48](#__RefHeading___Toc236223081)

[7.5.9. UI System Preference Group 48](#__RefHeading___Toc236223082)

[7.5.10. UI User Preference 49](#__RefHeading___Toc236223083)

[7.5.11. UI User Preference Default 49](#__RefHeading___Toc236223084)

[7.5.12. UI User Preference Group 49](#__RefHeading___Toc236223085)

[7.5.13. UI User Role 49](#__RefHeading___Toc236223086)

[7.5.14. UI User Role Permission 49](#__RefHeading___Toc236223087)

[7.6. Instrument & Combo Generation 49](#__RefHeading___Toc236223088)

[7.6.1. Auto Combo Generation Rule Group 50](#__RefHeading___Toc236223089)

[7.6.2. Auto Combo Generation Rule Group – Item 50](#__RefHeading___Toc236223090)

[7.6.3. Auto Instrument Generation 50](#__RefHeading___Toc236223091)

[7.6.4. Combo Name Standard 51](#__RefHeading___Toc236223092)

[7.6.5. Combo Name Standard - Item 51](#__RefHeading___Toc236223093)

[7.6.6. Combo Rule – Banker Link 51](#__RefHeading___Toc236223094)

[7.6.7. Combo Rule – Manual Link 52](#__RefHeading___Toc236223095)

[7.6.8. Combo Rule – Manual Link Leg 53](#__RefHeading___Toc236223096)

[7.6.9. Combo Rule – Multiple Link 53](#__RefHeading___Toc236223097)

[7.6.10. Cycle Block 53](#__RefHeading___Toc236223098)

[7.6.11. Cycle Block – Item 53](#__RefHeading___Toc236223099)

[7.6.12. Cycle Blocks 54](#__RefHeading___Toc236223100)

[7.6.13. Last Trading Date Calendar 54](#__RefHeading___Toc236223101)

[7.6.14. Last Trading Date Calendar – Monthly Item 54](#__RefHeading___Toc236223102)

[7.6.15. Last Trading Date Calendar – Weekly Default Item 54](#__RefHeading___Toc236223103)

[7.6.16. Last Trading Date Calendar – Weekly Specific Item 54](#__RefHeading___Toc236223104)

[7.6.17. Last Trading Date DST Adjustment 55](#__RefHeading___Toc236223105)

[7.6.18. Last Trading Date DST Adjustment Dates 55](#__RefHeading___Toc236223106)

[7.6.19. Last Trading Date Formula 55](#__RefHeading___Toc236223107)

[7.6.20. Last Trading Date Formula Rules 55](#__RefHeading___Toc236223108)

[7.6.21. Lifecycle Time Rule 56](#__RefHeading___Toc236223109)

[7.6.22. Name Standard 57](#__RefHeading___Toc236223110)

[7.6.23. Name Standard - Item 57](#__RefHeading___Toc236223111)

[7.6.24. Regional Calendar 58](#__RefHeading___Toc236223112)

[7.6.25. Regional Calendar Holidays 58](#__RefHeading___Toc236223113)

[7.6.26. Regional Calendar MICs 58](#__RefHeading___Toc236223114)

[7.6.27. Regional Calendar Upload – Exchange Trading 58](#__RefHeading___Toc236223115)

[7.6.28. Regional Calendar Upload – Financial Centers 58](#__RefHeading___Toc236223116)

[7.6.29. Strike Price Range 59](#__RefHeading___Toc236223117)

[7.6.30. Strike Price Reference 59](#__RefHeading___Toc236223118)

[7.6.31. Strike Price Table 59](#__RefHeading___Toc236223119)

[7.6.32. Strike Price Table – Item 59](#__RefHeading___Toc236223120)

[7.7. Report 60](#__RefHeading___Toc236223121)

[7.7.1. Report 60](#__RefHeading___Toc236223122)

[7.7.2. Report Combo Group List – Item 60](#__RefHeading___Toc236223123)

[7.7.3. Report Group List 60](#__RefHeading___Toc236223124)

[7.7.4. Report Instrument Group List – Item 60](#__RefHeading___Toc236223125)

[7.7.5. Report Type 60](#__RefHeading___Toc236223126)

[7.7.6. SMP Participant Exclusion List- Item 61](#__RefHeading___Toc236223127)

[7.8. System 61](#__RefHeading___Toc236223128)

[7.8.1. Admin Sequence 61](#__RefHeading___Toc236223129)

[7.8.2. Contingency Switch 62](#__RefHeading___Toc236223130)

[7.8.3. Distribution Queue Header 62](#__RefHeading___Toc236223131)

[7.8.4. Distribution Queue HTTP Body 62](#__RefHeading___Toc236223132)

[7.8.5. Distribution Queue SMTP Body 63](#__RefHeading___Toc236223133)

[7.8.6. Distribution Queue SFTP Body 63](#__RefHeading___Toc236223134)

[7.8.7. Gateway Partition 63](#__RefHeading___Toc236223135)

[7.8.8. Global Parameters 63](#__RefHeading___Toc236223136)

[7.8.9. Market Operation Transaction 65](#__RefHeading___Toc236223137)

[7.8.10. Market Operation Transaction – Item 66](#__RefHeading___Toc236223138)

[7.8.11. Market State 66](#__RefHeading___Toc236223139)

[7.8.12. ME Partition 66](#__RefHeading___Toc236223140)

[7.8.13. Password Policy 67](#__RefHeading___Toc236223141)

[7.8.14. PTRM Market Operation Transaction 67](#__RefHeading___Toc236223142)

[7.8.15. PTRM Market Operation Transaction – Item 68](#__RefHeading___Toc236223143)

[7.8.16. Reload Orders 68](#__RefHeading___Toc236223144)

[7.8.17. System State 69](#__RefHeading___Toc236223145)

[7.8.18. Trading Sequence 70](#__RefHeading___Toc236223146)

[7.8.19. Transaction 70](#__RefHeading___Toc236223147)

[7.8.20. Transaction – Item 71](#__RefHeading___Toc236223148)

[7.8.21. Transaction Event 71](#__RefHeading___Toc236223149)

[8. System Limits 72](#__RefHeading___Toc236223150)

[9. Data Types 75](#__RefHeading___Toc236223151)

[10. Data Dictionary 76](#__RefHeading___Toc236223152)

# Document Control

## Change History

|  |  |  |  |
| --- | --- | --- | --- |
| Version  Number | Issue Date | Author | Abstract |
| 0.1 | 16 Sep 2024 | IT/Markets Systems | Initial Version |
| 0.2 | 29 Oct 2024 | IT/Markets Systems | Revised Version |
| 0.3 | 22 Nov 2024 | IT/Markets Systems | Revised Version |
| 0.4 | 10 Feb 2025 | IT/Markets Systems | Revised Version |
| 0.5 | 14 Feb 2025 | IT/Markets Systems | Revised Version |
| 0.6 | 5 Mar 2025 | IT/Markets Systems | Revised Version |
| 0.7 | 24 Mar 2025 | IT/Markets Systems | Revised Version |
| 0.8 | 14 Apr 2025 | IT/Markets Systems | Revised Version |
| 0.9 | 17 Jun 2025 | IT/Markets Systems | Revised Version |
| 0.10 | 30 Jul 2025 | IT/Markets Systems | Revised Version |
| 0.11 | 1 Sep 2025 | IT/Markets Systems | Revised Version |
| 0.12 | 14 Nov 2025 | IT/Markets Systems | Revised Version |
| 0.13 | 9 Jan 2026 | IT/Markets Systems | Revised Version |
| 0.14 | 29 Jan 2026 | IT/Markets Systems | Revised Version |
| 0.15 | 16 Mar 2026 | IT/Markets Systems | Revised Version |
| 0.16 | 16 Apr 2026 | IT/Markets Systems | Revised Version |
| 0.17 | 26 May 2026 | IT/Markets Systems | Revised Version |
| 0.18 | 16 Jun 2026 | IT/Markets Systems | Revised Version |
| 0.19 | 8 Jul 2026 | IT/Markets Systems | Revised Version |
| 0.20 | 29 Jul 2026 | IT/Markets Systems | Revised Version |

## Document Cross-referenced

|  |  |  |
| --- | --- | --- |
| # | Document | Version |
| 1 | FS10001 – Trading Timetable | 20250916 |
| 2 | FS10002 – Order Management | 20250929 |
| 3 | FS10003 – Order Book and Execution Management | 20250324 |
| 4 | FS10004 – Price Supervision | 20250731 |
| 5 | FS10005 – Pre-Trade Risk Management | 20250217 |
| 6 | FS10006 – Block Trade | 20250709 |
| 7 | FS10007 – Self Match Prevention (SMP) | 20250324 |
| 8 | FS10008 – Market Maker Protection | 20250615 |
| 9 | FS10009 – Error Trade, Trade Cancellation and Adjustment | 20250116 |
| 10 | FS10010 – Product Structure | 20250724 |
| 11 | FS10011 – Participant Structure | 20260603 |
| 12 | FS10017A – Reports Generation for Dynamic Data and Processing | 20250618 |
| 13 | FS10017B – Reports Generation for Static Data and Processing | 20250318 |
| 14 | FS10019 – Market Message | 20260130 |
| 15 | FS10023 – Instrument and Combo Generation | 20250617 |

## Abbreviation

|  |  |
| --- | --- |
| AHT | After Hours Trading |
| EP | Exchange Participant |
| MMP | Market Maker Protection |
| PTRM | Pre-Trade Risk Management |
| SMP | Self Match Prevention |
| TMC | Tailor Made Combination |
| VCM | Volatility Control Mechanism |

# Introduction

Logical data model describes the data items and their logical relationships to support the functional requirements of ODP Trading. The scope of such data maintained in ODP Trading is only for consumption requirements within the ODP Trading and the satellite/support systems that are associated with ODP Trading.

## Entity

An entity is a logical definition of the grouping within which data items of similar characteristics are stored together. For example, information related to a market is stored in the Market entity describing its characteristics.

## Attribute

An attribute is a characteristic of an entity. For example, Market ID and Market Type are attributes of a Market.

For each entity, the primary key is the attribute or set of attributes which uniquely identifies each occurrence of the entity. For example, each occurrence of the Market entity is uniquely identified by the Market ID attribute. Primary keys consisting of more than one attribute are known as composite keys. Primary keys are highlighted in Bold and Italics.

An attribute highlighted in green color is a foreign key which links other entities and can be an alternate key to access that entity. For example, Exchange is a foreign key to the Market entity, which links each Market to an Exchange as well as identifies Market assigned to each Exchange.

## Data Model

The logical data model diagram illustrates the relationships between entities. Each relationship is defined in the data model diagram as either “one-to-one” or “one-to-many”.

Each entity from the logical data model is defined with its attributes, primary keys and foreign keys. Each attribute is defined with its data type and size.

# Logical Data Relationship

The ER diagrams below describe the inter-relationships among data entitles:

## Product

The ER diagram below describes the inter-relationships among product related data entitles:

![](data:image/x-wmf;base64...)

Below ER diagram zooms in the inter-relationships among price supervision related data entitles:

![](data:image/x-wmf;base64...)

## Participant

The ER diagram below describes the inter-relationships among participant related data entitles:

![](data:image/x-wmf;base64...)

## Pre-Trade Risk Management (PTRM)

The ER diagram below describes the inter-relationships among pre-trade risk management (PTRM) related data entitles:

![](data:image/x-wmf;base64...)

## Market Message

Refer to FS10019 – Market Message.

## Exchange User & GUI

The ER diagram below describes the inter-relationships among exchange user and GUI related data entitles:

![](data:image/x-wmf;base64...)

## Instrument & Combo Generation

Refer to FS10023 – Instrument and Combo Generation.

## Report

Refer to FS10017A – Reports Generation for Dynamic Data and Processing and FS10017B – Reports Generation for Static Data and Processing.

# Data Flow Diagrams

Data Flow Diagrams are intentionally excluded from this FS for the reason that they are covered broadly in system interfaces related documents.

# Data Classification

The sensitivity level of significant data entities within ODP-TR are classified as follows based on the business needs and their associated impacts.

|  |  |  |  |
| --- | --- | --- | --- |
| Entity | Public | Internal Data | Confidential1 |
| **Product** |  |  |  |
| **Participant – Session** |  |  |  |
| **Participant (excluding Session)** |  |  |  |
| **PTRM – Risk Group Notification List** |  |  |  |
| **PTRM**  **(excluding Risk Group Notification List)** |  |  |  |
| **Market Message – Automatic Event Message** |  |  |  |
| **Market Message (excluding Automatic Event Message)** |  |  |  |
| **Exchange User & GUI** |  |  |  |
| **Instrument & Combo Generation** |  |  |  |
| **Report** |  |  |  |
| **System** |  |  |  |

1. Confidential data refers to some individual data attributes of the entity only, for example Password and Email, not the entire data entity.

# Location of Data

ODP-TR data is mainly located on the ODP-TR application servers and/or in the designated database.

# Logical Data Entities

## Product

### Access Group By Type

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Access Group By Type ID*** | Access Group By Type ID |  |
| Name | Business Parameter Name |  |
| Description | Description |  |

### Access Group By Type – Combo Type

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Access Group By Type ID*** | Access Group By Type ID |  |
| ***Combo Type ID*** | Combo Type ID |  |

### Access Group By Type – Instrument Type

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Access Group By Type ID*** | Access Group By Type ID |  |
| ***Instrument Type ID*** | Instrument Type ID |  |

### Block Trade Group

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Block Trade Group ID*** | Block Trade Group ID |  |
| Name | Business Parameter Name |  |
| Description | Description |  |
| Internal Allowed? | Boolean |  |
| Interbank Allowed? | Boolean |  |
| On-behalf Allowed? | Boolean |  |

### Block Trade MVT

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Block Trade MVT ID*** | Block Trade MVT ID |  |
| Name | Business Parameter Name |  |
| Description | Description |  |

### Block Trade MVT Band

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Block Trade MVT ID*** | Block Trade MVT ID |  |
| Expiration To | Exception |  |
| MVT | Quantity |  |

### Capital Adjustment Event

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***CA Event ID*** | CA Event ID |  |
| Underlying Issuer | Underlying Issuer |  |
| CA Event Type | CA Event Type | Domain Values:  R = Right Issue  B = Bonus Issue of Shares  W = Bonus Issue of Warrants  C = Share Consolidation  S = Share Sub-division  M = Merger (Shares and Cash)  m = Merger (Shares Only)  E = Spin-Off (E-Day)  F = Spin-Off (F-Day; with Entitlement)  D = Other Cash Distribution (Special Dividend)  X = Other CA Events |
| Number Of Old Shares (X) | Num Shares | With 6 (default) implied decimal places |
| Number Of New Shares (Y) | Num Shares | With 6 (default) implied decimal places |
| Subscription Price Per Share (Z) | Price | With 6 (default) implied decimal places |
| Underlying Stock Closing Price On E-1 Day (S) | Price | With 6 (default) implied decimal places |
| Theoretical Value Of The Warrant Entitlement Per Share On E-1 Day (W) | Price | With 6 (default) implied decimal places |
| Ordinary Dividend (OD) | Price | With 6 (default) implied decimal places |
| Amount Of Cash (Z) | Price | With 6 (default) implied decimal places |
| VWAP Of The Entitlement On F Day (E) | Price | With 6 (default) implied decimal places |
| VWAP Of The Old Share On F Day (S) | Price | With 6 (default) implied decimal places |
| Cash Distribution (CD) | Price | With 6 (default) implied decimal places |
| New Decimals For Contract Size & PQF | Decimal In Pirce |  |
| Adjustment Ratio | Price | With 6 (default) implied decimal places |
| Effective Adjustment Date | Date |  |

### Capital Adjustment Event – Item

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***CA Event ID*** | CA Event ID |  |
| ***Item Number*** | List Position |  |
| ***From Underlying ID*** | Underlying ID |  |
| ***To Underlying ID*** | Underlying ID |  |
| From Underlying Code | Underlying Code |  |
| To Underlying Code | Underlying Code |  |

### Capital Adjustment Instrument

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***CA Instrument ID*** | CA Instrument ID |  |
| ***CA Event ID*** | CA Event ID |  |
| ***From Instrument ID*** | Security ID |  |
| ***To Instrument ID*** | Security ID |  |
| From Price Quotation Factor | Price Quotation Factor | Applicable for futures only |
| To Price Quotation Factor | Price Quotation Factor | Applicable for futures only |
| From Contracted Price | Price | Applicable for futures only |
| To Contracted Price | Price | Applicable for futures only |
| From Contract Size | Contract Size | Applicable for options only |
| To Contract Size | Contract Size | Applicable for options only |
| From Strike Price | Price | Applicable for options only |
| To Strike Price | Price | Applicable for options only |
| From Modifier | Modifier |  |
| To Modifier | Modifier |  |

### Capital Adjustment Instrument Class

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***CA Instrument Class ID*** | CA Instrument Class ID |  |
| ***CA Event ID*** | CA Event ID |  |
| ***From Instrument Class ID*** | Instrument Class ID |  |
| ***To Instrument Class ID*** | Instrument Class ID |  |
| From Decimals For Contract Size & PQF | Decimals In Price |  |
| To Decimals For Contract Size & PQF | Decimals In Price |  |

### Capital Adjustment Underlying

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***CA Underlying ID*** | CA Underlying ID |  |
| ***CA Event ID*** | CA Event ID |  |
| ***From Underlying ID*** | Underlying ID |  |
| ***To Underlying ID*** | Underlying ID |  |
| From Underlying Code | Underlying Code |  |
| To Underlying Code | Underlying Code |  |
| From Status | Status | Domain Values:  A = Active  S = Suspended |
| To Status | Status | Domain Values:  A = Active  S = Suspended |

### Combo

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Combo ID*** | Security ID |  |
| ***Combo Class ID*** | Combo Class ID |  |
| Ref Num | Ref Num |  |
| Status | Status | Domain Values:  A = Active  S = Suspended  D = Delisted (applicable for TMC only) |
| Effective Date | Date |  |
| Last Trading Date | Date |  |
| Effective Last Trading Date | Date |  |
| Last Trading Time | Time |  |
| First Trading Date | Date |  |
| First Trading Time | Time |  |
| Modifier | Modifier |  |
| Number of Legs | Num Legs |  |

### Combo Class

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Combo Class ID*** | Combo Class ID |  |
| Description | Description |  |
| ***Combo Type ID*** | Combo Type ID |  |
| ***Underlying ID*** | Underlying ID |  |
| Traded? | Boolean |  |
| Implied? | Boolean |  |
| Currency | Currency Code |  |
| ***Price Tick ID*** | Price Tick ID |  |
| ***Price Tick Limit ID*** | Price Tick Limit ID |  |
| Auto Price Tick Limit Update? | Boolean |  |
| ***Special Trading Days ID*** | Special Trading Days ID |  |
| ***Normal Day Timetable ID*** | Timetable ID |  |
| Block Trade Eligible? | Boolean |  |
| Block Trade Minimum Volume Thresholds | Quantity |  |
| Lot Size | Quantity |  |
| TMC Expiration Period | TMC Expiration Period | Domain Values:  1 = 1 Day  2 = 1 Week  3 = 2 Weeks  4 = 4 Weeks |
| ***Name Standard ID*** | Name Standard ID |  |
| Auto Generation? | Boolean |  |

### Combo Class Price Tick Limit

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Combo Class ID*** | Combo Class ID |  |
| Price Tick Upper Limit | Price |  |
| Price Tick Lower Limit | Price |  |
| Price Tick Reference Price | Price |  |
| Next Day Price Tick Upper Limit | Price |  |
| Next Day Price Tick Lower Limit | Price |  |
| Next Day Price Tick Reference Price | Price |  |

### Combo Group

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Combo Group ID*** | Combo Group ID |  |
| Combo Group Code | Combo Group Code |  |
| Short Name | Short Name |  |
| Description | Description |  |
| Tailor Made Only? | Boolean |  |
| Time Spread Level | Time Spread Level |  |

### Combo Leg

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Combo ID*** | Security ID |  |
| ***Leg Number*** | Leg Number |  |
| Operation | Side Char | Domain Values:  B = Buy  S = Sell |
| Ratio | Ratio |  |
| ***Leg Instrument ID*** | Security ID |  |

### Combo Type

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Combo Type ID*** | Combo Type ID |  |
| Description | Description |  |
| ***Market ID*** | Market ID |  |
| ***Combo Group ID*** | Combo Group ID |  |
| Allowed Different Price Quotation Factor? | Boolean |  |
| ***Special Trading Days ID*** | Special Trading Days ID |  |
| ***Normal Day Timetable ID*** | Timetable ID |  |
| Block Trade Eligible? | Boolean |  |
| ***TMC Strategy List ID*** | TMC Strategy List ID |  |
| TMC Allow Cross Market? | Boolean |  |
| TMC Max Ratio | Ratio |  |
| TMC Max Ratio Difference | Ratio |  |
| TMC Number Retention Days | Duration In Days |  |
| TMC Expiration Period | TMC Expiration Period | Domain Values:  1 = 1 Day  2 = 1 Week  3 = 2 Weeks  4 = 4 Weeks |
| ***Name Standard ID*** | Name Standard ID |  |
| Identify In Quote Request? | Boolean |  |
| Allow GTC And GTD Orders? | Boolean |  |

### Combo Type Error Trade Parameters

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Combo Type ID*** | Combo Type ID |  |
| Prescribed Time Limit | Time Interval Second |  |
| Contra EP Response Limit | Time Interval Second |  |
| ***Accept Msg Template ID*** | Message Template ID |  |
| ***Reject Msg Template ID*** | Message Template ID |  |
| ***Cancel By EP Msg Template ID*** | Message Template ID |  |
| ***Cancel By Panel Msg Template ID*** | Message Template ID |  |

### Exchange

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Exchange ID*** | Exchange ID |  |
| Description | Description |  |
| Exchange Code | Exchange Code |  |
| Short Name | Short Name |  |

### Futures Group

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Futures Group ID*** | Futures Group ID |  |
| Name | Business Parameter Name |  |
| Description | Description |  |

### Futures Group – Item

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Futures Group ID*** | Futures Group ID |  |
| ***Contract Month*** | Contract Month Option | Domain Values:  S = Spot  N = Non-Spot  B = Both |
| ***Trading Day*** | Trading Day Option | Domain Values:  1 = Normal  2 = Last Trading Day  3 = Last Trading Day + 1 |
| ***Calculation Rule ID*** | Calculation Rule ID |  |

### Halt Target List

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Halt Target List ID*** | Halt Target List ID |  |
| Name | Business Parameter Name |  |
| Description | Description |  |

### Halt Target List – Item

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Halt Target List ID*** | Halt Target List ID |  |
| ***Instrument Class ID*** | Instrument Class ID |  |

### Instrument

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Instrument ID*** | Security ID |  |
| ***Instrument Class ID*** | Instrument Class ID |  |
| Strike Price | Price |  |
| Traded? | Boolean |  |
| Effective Date | Date |  |
| Status | Status | Domain Values:  A = Active  S = Suspended |
| Last Trading Date | Date |  |
| Effective Last Trading Date | Date |  |
| Last Trading Time | Time |  |
| First Trading Date | Date |  |
| First Trading Time | Time |  |
| Modifier | Modifier |  |
| Price Quotation Factor | Price Quotation Factor |  |
| Contract Size | Contract Size |  |
| Block Trade Minimum Volume Thresholds | Quantity |  |
| ISIN | ISIN |  |
| SEDOL | SEDOL |  |

### Instrument – Daily Settlement Price

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Instrument ID*** | Security ID |  |
| Daily Settlement Price | Price | Stored as implied decimal according to the decimal in price tick |
| Received DSP | Price |  |
| Decimals In Received DSP | Decimals In Price |  |
| DSP Update Type | Update Type | Domain Values:  E = External Source  M = Manual |
| DSP Update Time | Timestamp |  |
| Previous Daily Settlement Price | Price |  |
| Previous Received DSP | Price |  |
| Decimals In Previous Received DSP | Decimals In Price |  |
| Previous DSP Update Type | Update Type | Domain Values:  S = System (housekeeping)  M = Manual |
| Previous DSP Update Time | Timestamp |  |
| Previous DSP Trading Date | Date |  |

### Instrument – Daily Settlement Price History

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Instrument ID*** | Security ID |  |
| Trading Date | Date |  |
| Seq | Seq |  |
| Daily Settlement Price | Price |  |
| Received DSP | Price |  |
| Decimals In Received DSP | Decimals In Price |  |
| Received Time | Timestamp |  |

### Instrument Class

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Instrument Class ID*** | Instrument Class ID |  |
| Description | Description |  |
| ***Instrument Type ID*** | Instrument Type ID |  |
| ***Underlying ID*** | Underlying ID |  |
| Traded? | Boolean |  |
| Currency | Currency Code |  |
| Settlement Currency | Currency Code |  |
| ***Price Tick ID*** | Price Tick ID |  |
| ***Price Tick Limit ID*** | Price Tick Limit ID |  |
| Auto Price Tick Limit Update? | Boolean |  |
| ***Corresponding Instrument Class For Price Tick*** | Instrument Class ID |  |
| ***Price Limit ID*** | Price Limit ID |  |
| ***VCM ID*** | VCM ID |  |
| ***AHT Reference Price Futures Group ID*** | Futures Group ID |  |
| ***Corresponding Instrument Class For AHT Reference Price*** | Instrument Class ID |  |
| Price Quotation Factor | Price Quotation Factor |  |
| Contract Size | Contract Size |  |
| Decimals For Contract Size & PQF | Decimals In Price |  |
| Decimals For Strike Price | Decimals In Price |  |
| ***Special Trading Days ID*** | Special Trading Days ID |  |
| ***Normal Day Timetable ID*** | Timetable ID |  |
| Block Trade Eligible? | Boolean |  |
| ***Block Trade MVT ID*** | Block Trade MVT ID |  |
| Block Trade Static Price Limit? | Boolean |  |
| Lot Size | Quantity |  |
| ***Name Standard ID*** | Name Standard ID |  |
| Auto Generation? | Boolean |  |
| ***Auto Instrument Generation Rule ID*** | Auto Instrument Generation Rule ID |  |
| Last CA Effective Date | Date |  |
| Cycle Block Frozen Date | Date |  |
| Furthest Expiry Date | Date |  |

### Instrument Class Price Tick Limit

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Instrument Class ID*** | Instrument Class ID |  |
| Price Tick Upper Limit | Price |  |
| Price Tick Lower Limit | Price |  |
| Price Tick Reference Price | Price |  |
| Next Day Price Tick Upper Limit | Price |  |
| Next Day Price Tick Lower Limit | Price |  |
| Next Day Price Tick Reference Price | Price |  |

### Instrument Group

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Instrument Group ID*** | Instrument Group ID |  |
| Description | Description |  |
| Short Name | Short Name |  |
| Instrument Group Code | Instrument Group Code |  |
| Group Type | Group Type | Domain Values:  O = Options  F = Forward  U = Futures  A = FRA  C = Cash  P = Payment  E = Exchange rate  S = Interest rate swap |
| Physical Delivery? | Boolean |  |
| Maturity? | Boolean |  |
| Options Type | Options Type | Domain Values:  C = Call P = Put |
| Options Style | Options Style | Domain Values:  A = American E = European S = Asian B = Bermudan I = Knock-in O = Knock-out N = Binary R = Ratchet |
| Options Variant | Options Variant | Domain Values:  N = Normal C = Cap F = Floor |
| Futures Styled Options? | Boolean |  |

### Instrument Type

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Instrument Type ID*** | Instrument Type ID |  |
| Description | Description |  |
| ***Market ID*** | Market ID |  |
| ***Instrument Group ID*** | Instrument Group ID |  |
| Traded? | Boolean |  |
| ***Special Trading Days ID*** | Special Trading Days ID |  |
| ***Normal Day Timetable ID*** | Timetable ID |  |
| Block Trade Eligible? | Boolean |  |
| Identify In Quote Request? | Boolean |  |
| Default Order Size Limit | Quantity |  |
| Default Block Trade Size Limit | Quantity |  |
| Maximum Order Size Limit By EP | Quantity |  |
| Maximum Block Trade Size Limit By EP | Quantity |  |

### Instrument Type Error Trade Parameters

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Instrument Type ID*** | Instrument Type ID |  |
| Prescribed Time Limit | Time Interval Second |  |
| Contra EP Response Limit | Time Interval Second |  |
| ***Accept Msg Template ID*** | Message Template ID |  |
| ***Reject Msg Template ID*** | Message Template ID |  |
| ***Cancel By EP Msg Template ID*** | Message Template ID |  |
| ***Cancel By Panel Msg Template ID*** | Message Template ID |  |

### Market

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Market ID*** | Market ID |  |
| Description | Description |  |
| Market Code | Market Code |  |
| ***Exchange ID*** | Exchange ID |  |
| MIC | MIC |  |
| Market Type | Market Type | Domain Values:  S = Stock F = Fixed Income U = Currency E = Power/energy C = Commodity P = Payment I = Index G = General |
| Index? | Boolean |  |
| Dummy? | Boolean |  |
| Traded? | Boolean |  |
| Normal Trading Days | Trading Days | Bitmask to represent available trading days:  1 - Mon  10 - Tue  100 - Wed  1000 - Thu  10000 - Fri  100000 - Sat  1000000 - Sun  For Mon to Fri, value = 31 |
| ***Special Trading Days ID*** | Special Trading Days ID |  |
| ***Non-Trading Days ID*** | Non-Trading Days ID |  |
| ***Normal Day Timetable ID*** | Timetable ID |  |
| ***Block Trade MVT ID*** | Block Trade MVT ID |  |
| Priority Number | Market Priority Number |  |

### Non-Trading Days

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Non-Trading Days ID*** | Non-Trading Days ID |  |
| Non-Trading Days Name | Business Parameter Name |  |
| Description | Description |  |

### Non-Trading Days - Item

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Non-Trading Days ID*** | Non-Trading Days ID |  |
| ***Date*** | Date |  |
| Trading Day Type | Trading Day Type | Always N = Non-Trading Day |

### Price Limit

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Price Limit ID*** | Price Limit ID |  |
| Name | Business Parameter Name |  |
| Description | Description |  |

### Price Limit – Item

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Price Limit ID*** | Price Limit ID |  |
| ***Trading State ID*** | Trading State ID | 0 = same price limit parameters applied on all trading states |
| ***Price Limit Parameters ID*** | Price Limit Param ID |  |

### Price Limit Parameters

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Price Limit Parameters ID*** | Price Limit Param ID |  |
| Name | Business Parameter Name |  |
| Description | Description |  |
| ***Static Price Limit Rule ID*** | Price Limit Rule ID |  |
| ***Static Reference Price Source ID*** | Ref Price Source ID |  |
| Remove Orders Outside Static Price Limit? | Boolean |  |
| ***Static Price Limit Alert Rule ID*** | Price Limit Alert Rule ID |  |
| ***Dynamic Price Limit Rule ID*** | Price Limit Rule ID |  |
| Dynamic Last Traded Price Deviation Unit | Deviation Unit | Domain Values:  A = Absolute Value  P = Percentage |
| Dynamic Last Traded Price Deviation Abs Value | Price | Applicable only if Deviation Unit = A  With 6 (default) implied decimal places |
| Dynamic Last Traded Price Deviation Percentage | Percentage | Applicable only if Deviation Unit = P |
| ***Halt Target List ID*** | Halt Target List ID |  |
| Resumption Cooling-Off Interval | Time Interval Second |  |
| No Resumption Period | Time Interval Second |  |
| Upper Resumption Level Percentage | Percentage |  |
| Lower Resumption Level Percentage | Percentage |  |

### Price Limit Alert Rule

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Price Limit Alert Rule ID*** | Price Limit Rule Alert ID |  |
| Scope | Monitoring Scope | 0 = All  1 = Reference futures only |
| Limit Deviation Unit | Deviation Unit | A = Absolute Value  P = Percentage |

### Price Limit Alert Rule – Item

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Price Limit Rule ID*** | Price Limit Rule ID |  |
| ***Item Number*** | List Position |  |
| Upper Limit Abs Value | Price | Applicable only if Deviation Unit = A  With 6 (default) implied decimal places |
| Upper Limit Percentage | Percentage | Applicable only if Deviation Unit = P |
| Lower Limit Abs Value | Price | Applicable only if Deviation Unit = A  With 6 (default) implied decimal places |
| Lower Limit Percentage | Percentage | Applicable only if Deviation Unit = P |

### Price Limit Rule

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Price Limit Rule ID*** | Price Limit Rule ID |  |
| Limit Deviation Unit | Deviation Unit | A = Absolute Value  P = Percentage |

### Price Limit Rule – Individual Band

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Price Limit Rule ID*** | Price Limit Rule ID |  |
| Expiration From | Expiration | 0 = expiration based limits are not enabled |
| ***Expiration To*** | Expiration | 0 = expiration based limits are not enabled |
| Upper Limit Abs Value | Price | Applicable only if Deviation Unit = A  With 6 (default) implied decimal places |
| Upper Limit Percentage | Percentage | Applicable only if Deviation Unit = P |
| Lower Limit Abs Value | Price | Applicable only if Deviation Unit = A  With 6 (default) implied decimal places |
| Lower Limit Percentage | Percentage | Applicable only if Deviation Unit = P |

### Price Tick

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Price Tick ID*** | Price Tick ID |  |
| Price Tick Name | Business Parameter Name |  |
| Description | Description |  |
| Decimals | Decimals In Price |  |
| Default Upper Limit | Price |  |
| Default Lower Limit | Price |  |

### Price Tick Order Band

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Price Tick ID*** | Price Tick ID |  |
| Price To | Price |  |
| Tick Size | Price |  |

### Price Tick Block Trade Band

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Price Tick ID*** | Price Tick ID |  |
| Price To | Price |  |
| Tick Size | Price |  |

### Price Tick Limit Rule

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Price Tick Limit ID*** | Price Tick Limit ID |  |
| Name | Business Parameter Name |  |
| Description | Description |  |
| Limit Deviation Unit | Deviation Unit | Domain Values:  T = Number of Ticks P = Percentage |
| Deviation Tick | Num Ticks |  |
| Deviation Percentage | Percentage |  |
| Exception Deviation Tick | Num Ticks |  |
| Exception Deviation Percentage | Percentage |  |

### Reference Price Source

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Reference Price Source ID*** | Ref Price Source ID |  |
| Name | Business Parameter Name |  |
| Description | Description |  |

### Reference Price Source – Item

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Reference Price Source ID*** | Ref Price Source ID |  |
| ***Price Source*** | Price Source | Domain Values:  1 = Opening Price  2 = Prev Trading Session Last Traded Price  3 = Calculated Price |

### Reference Price Calculation Rule

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Calculation Rule ID*** | Calculation Rule ID |  |
| Name | Business Parameter Name |  |
| Description | Description |  |

### Reference Price Calculation Rule – Item

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Calculation Rule ID*** | Calculation Rule ID |  |
| Calculation Priority | List Position |  |
| Price Data Option | Price Data Option | Domain Values:  1 = Last traded price  2 = Previous day’s settlement price  3 - Reference price of the nearest earlier contract month  4 = Spot month last traded price + Previous day’s rollover spread  5 = Spot month last traded price + Expired spot month spread  6 = Last traded price of corresponding instrument  7 = Spot month last traded price + Previous day’s rollover spread of corresponding instrument |

### Special Trading Days

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Special Trading Days ID*** | Special Trading Days ID |  |
| Special Trading Days Name | Business Parameter Name |  |
| Description | Description |  |

### Special Trading Days – Item

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Special Trading Days ID*** | Special Trading Days ID |  |
| Date | Date |  |
| ***Trading Timetable ID*** | Timetable ID |  |

### TMC Strategy

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Strategy ID*** | TMC Strategy ID |  |
| Name | TMC Strategy Name |  |
| Description | Description |  |
| Short Name | Short Name |  |
| Allowed Reserved? | Boolean |  |
| Number of Legs | Num Legs |  |

### TMC Strategy Leg

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Strategy ID*** | TMC Strategy ID |  |
| ***Leg Number*** | Leg Number |  |
| Operation | Side Char | Domain Values:  B = Buy  S = Sell |
| Ratio Relative? | Boolean |  |
| Ratio Condition | TMC Strategy Leg Condition | Domain Values:  0 = Any  1 = Equal to Leg n  2 = Higher than Leg n  3 = Lower than Leg n  4 = Not equal to Leg n  5 = 2x Leg n |
| Ratio Reference Leg | Leg Number | Applicable only if Ratio Relative? = N |
| Ratio Exact | Ratio | Applicable only if Ratio Relative? = Y |
| Strike Price Condition | TMC Strategy Leg Condition | Domain Values:  0 = Any  1 = Equal to Leg n  2 = Higher than Leg n  3 = Lower than Leg n  4 = Not equal to Leg n |
| Strike Price Reference Leg | Leg Number |  |
| Last Trading Date Condition | TMC Strategy Leg Condition | Domain Values:  0 = Any  1 = Equal to Leg n  2 = Higher than Leg n  3 = Lower than Leg n  4 = Not equal to Leg n |
| Last Trading Date Reference Leg | Leg Number |  |
| ***Instrument Group ID 1*** | Instrument Group ID |  |
| ***Instrument Group ID 2*** | Instrument Group ID |  |
| ***Instrument Gorup ID 3*** | Instrument Group ID |  |

### TMC Strategy List

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Strategy ID List*** | TMC Strategy List ID |  |
| Name | Business Parameter Name |  |
| Description | Description |  |

### TMC Strategy List - Item

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Strategy ID List*** | TMC Strategy List ID |  |
| ***Strategy ID*** | TMC Strategy ID |  |
| Position | List Position |  |

### Trading State

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Trading State ID*** | Trading State ID |  |
| Trading State Name | Trading State Name |  |
| Description | Description |  |
| Trading State Type | Trading State Type | Domain Values:  0 = SOD (a technical trading state)  1 = PREMKTACT  2 = PREOPEN  3 = PREOPENALLOC  4 = OPENALLOC  5 = UNCROSS  6 = OPEN  7 = PAUSE  8 = INTERVENTION (a technical trading state)  9 = DAYEND (a technical trading state) |
| Business Trading State? | Boolean | If Y, the trading state is created and customized by Business Operations  If N, the trading state is pre-load to the system and cannot be customized by Business Operations |
| LO Allowed? | Boolean |  |
| MO Allowed? | Boolean |  |
| M2L Allowed? | Boolean |  |
| Day Allowed? | Boolean |  |
| FAK Allowed? | Boolean |  |
| FOK Allowed? | Boolean |  |
| GTC Allowed? | Boolean |  |
| GTD Allowed? | Boolean |  |
| At Crossing Allowed? | Boolean |  |
| Order Entry Allowed? | Boolean |  |
| Order Amend (Preserve Time Priority) Allowed? | Boolean |  |
| Order Amend (Loss Of Time Priority) Allowed? | Boolean |  |
| Order Cancel Allowed? | Boolean |  |
| Quote Request Allowed? | Boolean |  |
| Single Quote Allowed? | Boolean |  |
| Mass Quote Allowed? | Boolean |  |
| Block Trade Allowed? | Boolean |  |
| Error Trade Claim Allowed? | Boolean |  |
| TMC Creation Allowed? | Boolean |  |
| Admin Order Cancel Allowed? | Boolean |  |
| Admin Trade Cancel Allowed? | Boolean |  |
| Admin Trade Price Adjustment? | Boolean |  |
| Internal On-Behalf Enter Trade? | Boolean |  |
| Calculate AHT Static Price Limit Ref Price? | Boolean |  |
| Remove All Orders? | Boolean |  |
| Inactivate Non-AHT Orders? | Boolean |  |
| Implied Generation Applicable? | Boolean |  |
| Static Price Limit Applicable? | Boolean |  |
| Dynamic Price Limit Applicable? | Boolean |  |
| VCM Applicable? | Boolean |  |
| VCM Start Offset | Time Interval Second |  |
| VCM End Offset | Time Interval Second |  |
| Pre-open Allocation Start Offset | Time Interval Second |  |
| Pre-open Allocation Random Interval | Time Interval Second |  |
| Open Allocation Start Offset | Time Interval Second |  |
| Open Allocation Random Interval | Time Interval Second |  |
| Uncross Start Offset | Time Interval Second |  |

### Trading Timetable

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Trading Timetable ID*** | Timetable ID |  |
| Trading Timetable Name | Timetable Name |  |
| Description | Description |  |
| ***Exchange ID*** | Exchange ID |  |
| Timetable Type | Timetable Type | Domain Values:  F = Full Day Timetable  H = Half Day Timetable |

### Trading Timetable Session – Trading State

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Trading Timetable ID*** | Timetable ID |  |
| ***Trading Session*** | Trading Session ID | Domain Values:  1 = Morning  2 = Afternoon  3 = Day  4 = AHT (After Hours) |
| ***Start Logical Day Ind*** | Logical Day Indicator | Domain Values:  -1 = T-1  0 = T  1 = T+1 |
| ***Start Time*** | Time |  |
| Transition Mode | Transition Mode | Domain Values:  0 = Automatic  1 = Manual |
| ***Trading State ID*** | Trading State ID |  |
| Alert Interval | Time Interval Second |  |
| Num Alert | Num Alert |  |

### Underlying

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Underlying ID*** | Underlying ID |  |
| Description | Description |  |
| Underlying Code | Underlying Code |  |
| ME Partition ID | Partition ID |  |
| Status | Status | Domain Values:  A = Active  S = Suspended |
| Underlying Type | Underlying Type | Domain Values:  S = Stock C = Currency I = Fixed Income E = Power/Energy A = Commodity M = Metal |
| Index? | Boolean |  |
| Underlying Issuer | Underlying Issuer |  |
| MMP Enabled? | Boolean |  |
| Minimum MMP Quantity | Quantity Limit | 0 = no limit |
| Price Decimals | Decimals In Price |  |
| Currency | Currency Code |  |
| CA Spin-off In Progress? | Boolean |  |
| CA Created? | Boolean |  |
| CA Reuse Cool-off Date | Date |  |
| Data Source | Data Source | Domain Values:  0 = N/A  1 = OMD-C  2 = OMD-I |
| Data Source Symbol Code | Data Source Symbol Code |  |
| CA Priority | CA Priority |  |

### Underlying - Price

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Underlying ID*** | Underlying ID |  |
| Last Traded Price | Price | Stored as implied decimal according to the decimal in underlying |
| Received Last Traded Price | Price |  |
| Decimals In Received Last Traded Price | Decimals In Price |  |
| Last Traded Price Update Type | Update Type |  |
| Last Traded Price Update Time | Timestamp |  |
| Settlement Price | Price | Stored as implied decimal according to the decimal in underlying |
| Received Settlement Price | Price |  |
| Decimals In Received Settlement Price | Decimals In Price |  |
| Settlement Price Update Type | Update Type |  |
| Settlement Price Update Time | Timestamp |  |

### Underlying – Price History

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Underlying ID*** | Underlying ID |  |
| Trading Date | Date |  |
| Seq | Seq |  |
| Last Traded Price | Price | Stored as implied decimal according to the decimal in underlying |
| Received Last Traded Price | Price |  |
| Decimals In Received Last Traded Price | Decimals In Price |  |
| Settlement Price | Price | Stored as implied decimal according to the decimal in underlying |
| Received Settlement Price | Price |  |
| Decimals In Received Settlement Price | Decimals In Price |  |
| Receive Time | Timestamp |  |

### Underlying – Status

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Underlying ID*** | Underlying ID |  |
| Status | Status | Domain Values:  A = Active  S = Suspended |
| Last Update Time | Timestamp |  |

### VCM

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***VCM ID*** | VCM ID |  |
| Name | Business Parameter Name |  |
| Description | Description |  |

### VCM – Item

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***VCM ID*** | VCM ID |  |
| ***Trading State ID*** | Trading State ID | 0 = same VCM parameters applied on all trading states |
| ***VCM Parameters ID*** | VCM Param ID |  |

### VCM Parameters

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***VCM Parameters ID*** | VCM Param ID |  |
| Name | Business Parameter Name |  |
| Description | Description |  |
| ***Price Limit Rule ID*** | Price Limit Rule ID |  |
| Delay Time | Time Interval Second |  |
| Cooling-Off Interval | Time Interval Second |  |
| Max Triggers | Max Triggers |  |
| Automatic VCM Re-enable? | Boolean |  |

## Participant

### Company

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Company ID*** | Company ID |  |
| IDP Company ID | IDP Company ID |  |
| Company Name | Company Name |  |
| Company UUID | Company UUID | Link to EIDP |
| Description | Company Description |  |

### Drop Copy Group

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Drop Copy Group ID*** | Drop Copy Group ID |  |
| ***Exchange Participant ID*** | Participant ID |  |
| Name | Business Parameter Name |  |
| Description | Description |  |

### Drop Copy Group – Trader ID

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Drop Copy Group ID*** | Drop Copy Group ID |  |
| ***Trader ID*** | Trader ID |  |

### Drop Copy Session

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Comp ID*** | Comp ID |  |
| Include Orders? | Boolean |  |
| Include Trades? | Boolean |  |
| ***Access Group By Type ID*** | Access Group By Type ID | Entitled to all products if not specified |

### Drop Copy Session – Drop Copy Group

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Comp ID*** | Comp ID |  |
| ***Drop Copy Group ID*** | Drop Copy Group ID |  |

### Exchange Participant

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Exchange Participant ID*** | Participant ID |  |
| Identity UUID | Identity UUID | Link to EIDP |
| ***Exchange ID*** | Exchange ID |  |
| ***Company ID*** | Company ID |  |
| Description | Description |  |
| Suspended? | Boolean |  |
| Number of Missing Heartbeat | Num Missing Heartbeat |  |
| Timeout Before COD | Time Interval Second |  |
| ***Allowed Block Trade Group ID*** | Block Trade Group ID |  |
| ***SMP ID List*** | SMP ID List ID |  |
| Nominated Error Trade Session Usage | Session Usage | Domain Values:  D = Direct Access  U = UI Access |
| ***Nominated Error Trade Session ID*** | Comp ID |  |

### IP Address List

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***IP Address List ID*** | IP Address List ID |  |
| Name | Business Parameter Name |  |
| Description | Description |  |
| Is Technical? | Boolean |  |

### IP Address List – Item

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***IP Address List ID*** | IP Address List ID |  |
| ***IP Address*** | IP Address |  |

### MMP Parameters

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Exchange Participant ID*** | Participant ID |  |
| ***Underlying ID*** | Underlying ID |  |
| Include Futures? | Boolean |  |
| Quantity Protection | Quantity Limit | 0 = no limit |
| Delta Protection | Quantity Limit | 0 = no limit |
| Exposure Time Limit Interval | Time Interval Second | 0 = all limit check disabled |
| Frozen Time | Time Interval Second | 0 = reject all quotes for the rest of the trading day |

### Order Flow Session

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Comp ID*** | Comp ID |  |
| Timeout Before COD | Time Interval Second |  |
| Order Throttle | TPS |  |
| Receive Non Critical Market Messages? | Boolean |  |

### Order Flow Session – Trader ID

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Comp ID*** | Comp ID |  |
| ***Trader ID*** | Trader ID |  |

### Participant Trading Rights

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Exchange Participant ID*** | Participant ID |  |
| ***Instrument Type ID*** | Instrument Type ID |  |
| Order Size Limit | Quantity | 0 = no limit |
| Block Trade Size Limit | Quantity | 0 = no limit |
| Default Account | Default Account | For information only |

### Participant User Role

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Participant User Role ID*** | Participant User Role ID |  |
| Name | Business Parameter Name |  |
| Description | Description |  |
| Participant User Type | Type Of Participant User | Domain Values:  D = Direct access (trading)  T = Trading GUI  E = PTRM GUI (trading unit)  C = PTRM GUI (risk limit manager) |
| Order Entry Allowed? | Boolean |  |
| Order Amend Allowed? | Boolean |  |
| Order Cancel Allowed? | Boolean |  |
| Order Mass Cancel Allowed? | Boolean |  |
| OBO Order Cancel Allowed? | Boolean |  |
| OBO Mass Cancel Allowed? | Boolean |  |
| Quote Request Allowed? | Boolean |  |
| Single Quote Allowed? | Boolean |  |
| Mass Quote Allowed? | Boolean |  |
| Block Trade Allowed? | Boolean |  |
| Error Trade Claim Allowed? | Boolean |  |
| TMC Creation Allowed? | Boolean |  |
| MMP Parameter Update Allowed? | Boolean |  |
| Kill Switch Allowed? | Boolean |  |
| Stop Risk Group Allowed? | Boolean |  |
| Unstop Risk Group Allowed? | Boolean |  |
| PTRM Mass Cancel Allowed? | Boolean |  |
| PTRM Kill Switch Allowed? | Boolean |  |
| Unblock Breached Risk Check Allowed? | Boolean |  |
| PTRM Parameter Update Allowed? | Boolean |  |
| ***Allowed Block Trade Group ID*** | Block Trade Group ID |  |
| ***UI User Role ID*** | UI User Role ID |  |

### Self Admin Portal User

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***User ID*** | User ID |  |
| IDP User | IDP User ID |  |
| IDP User UUID | IDP User UUID | Link to EIDP |
| ***Exchange Participant ID*** | Participant ID |  |
| Suspended? | Boolean |  |
| ***Legal Browser IP Address List ID*** | IP Address List ID |  |
| ***UI User Role ID*** | UI User Role ID |  |

### Self Admin Portal User Extended

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***User ID*** | User ID |  |
| Last Signon Date | Date |  |
| Last Signon Time | Timestamp |  |
| Signon Count | Signon Count |  |

### Session

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Comp ID*** | Comp ID | Identity of a session |
| ***Exchange Participant ID*** | Participant ID |  |
| ***Sponsoring Participant ID*** | Participant ID |  |
| Is Sponsoring Participant? | Boolean |  |
| Service Type | Gateway Service Type | Domain Values:  P = Order Flow - PSG  O = Order Flow - CGW  D = Drop Copy  R = PTRM |
| Session Usage | Session Usage | Domain Values:  D = Direct Access  U = UI Access |
| Partition ID | Partition ID |  |
| Sub Partition ID | Sub Partition ID | Applicable for Order Flow – PSG only |
| Interface Protocol | Interface Protocol | Domain Values:  B = Binary  F = FIX |
| Blocked? | Boolean |  |
| Blocked Reason | Blocked Reason | Domain Values:  0 = N/A  1 = Blocked by Admin |
| Encryption Required? | Boolean |  |
| ***Legal IP Address List ID*** | IP Address List ID |  |
| Password | Password |  |
| Password Salt | Password Salt | Assigned automatically by the system when new Comp ID is added |
| ***Password Policy ID*** | Password Policy ID |  |
| Number of Missing Heartbeat | Num Missing Heartbeat |  |
| Last Password Set Date | Date |  |
| Last Password Set Timestamp | Timestamp |  |

### Session Extended

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Comp ID*** | Comp ID | Identity of a session |
| Password | Password |  |
| Password Salt | Password Salt |  |
| Locked? | Boolean |  |
| Locked Reason | Locked Reason | Domain Values:  <blank> = N/A  E = Password Expired  R = Password Retry Attempts Exceeded  I = Inactivity |
| Locked Time | Timestamp |  |
| Force Password Change? | Boolean |  |
| In Testing Mode? | Boolean |  |
| Last Signon Date | Date |  |
| Password Expiry Date | Date |  |
| Password Update Count | Password Update Count |  |
| Last Signon Time | Timestamp |  |
| Last Password Set Date | Date |  |
| Last Password Set Timestamp | Timestamp |  |
| Failed Password Attempts | Failed Signon Attempts |  |
| Failed Signon Attempts | Failed Signon Attempts |  |
| Signon Count | Signon Count |  |

### Session Extended – GUI User

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Comp ID*** | Comp ID | Identity of a session |
| Encrypted Password | Encrypted Password |  |
| Password Salt | Password Salt |  |
| Last Password Set Date | Date |  |
| Last Password Set Timestamp | Timestamp |  |

### SMP ID

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***SMP ID*** | SMP ID |  |
| Description | Description |  |
| Creation Reference Number | Creation Ref No |  |
| ***Owner ID*** | Participant ID |  |
| Cancellation Method | SMP Instruction | Domain Values:  A = Cancel aggressive  P = Cancel passive |
| Status | SMP ID Status | Domain Values:  A = Active  D = Deleted |
| Status Last Update Date | Date |  |

### SMP ID List

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***SMP ID List ID*** | SMP ID List ID |  |
| Name | Business Parameter Name |  |
| Description | Description |  |
| ***Owner ID*** | Participant ID |  |

### SMP ID List – Item

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***SMP ID List ID*** | SMP ID List ID |  |
| ***SMP ID*** | SMP ID |  |
| Status | SMP ID Status | Domain Values:  A = Active  D = Deleted |

### SMP Request

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***SMP Request ID*** | SMP Request ID |  |
| Submit Date Time | Timestamp |  |
| Uploader | Participant ID |  |
| Participant ID | Participant ID |  |
| Related Participant ID | Participant ID |  |
| Type | SMP Request Type | Domain Values:  R - Request  C - Consent |
| Action | SMP Request Action | Domain Values:  C - Create SMP ID  T - Terminate SMP ID  S - Share SMP ID  R - Remove SMP ID Sharing |
| Rejection Code | SMP Request Code |  |
| Request Status | SMP Request Status | Domain Values:  N - New  R - Ready to Submit  S - Submitted  X - Expired  F - Fulfilled  J - Rejected by HKEX  E - Error  I - Received  P - Pending Reject |
| Last Update Date Time | Timestamp |  |
| SMP ID | SMP ID |  |
| Primary Participant | Participant ID |  |
| PDF File Name | PDF File Name |  |
| Last Error Code | SMP Request Code |  |
| SMP Consent ID | SMP Request ID |  |
| Consent Status | SMP Request Status | Domain Values:  N - New  R - Ready to Submit  S - Submitted  X - Expired  F - Fulfilled  J - Rejected by HKEX  E - Error  I - Received  P - Pending Reject |
| SMP Instruction | SMP Instruction | Domain Values:  A = Cancel aggressive  P = Cancel passive |
| Creation Reference Number | Creation Ref No |  |

### Trader ID

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Trader ID*** | Trader ID |  |
| ***Exchange Participant ID*** | Participant ID |  |
| Suspended? | Boolean |  |
| ***Participant User Role ID*** | Participant User Role ID |  |
| ***Trading Right ID*** | Trading Right ID |  |

### Trader ID – Trading GUI User

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Trader ID*** | Trader ID |  |
| ***User ID*** | User ID |  |

### Trading GUI User

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***User ID*** | User ID |  |
| IDP User | IDP User ID |  |
| IDP User UUID | IDP User UUID | Link to EIDP |
| ***Exchange Participant ID*** | Participant ID |  |
| Suspended? | Boolean |  |
| ***Legal Browser IP Address List ID*** | IP Address List ID |  |

### Trading Right

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Trading Right ID*** | Trading Right ID |  |
| Name | Business Parameter Name |  |
| Description | Description |  |

### Trading Right – Item

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Trading Right ID*** | Trading Right ID |  |
| ***Access Group By Type ID*** | Asset Group By Type ID |  |
| Order Size Limit | Quantity | 0 = no limit |
| Block Trade Size Limit | Quantity | 0 = no limit |

## PTRM

### PTRM GUI User

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***User ID*** | User ID |  |
| IDP User | IDP User ID |  |
| IDP User UUID | IDP User UUID | Link to EIDP |
| ***Exchange Participant ID*** | Participant ID |  |
| ***Sponsoring Participant ID*** | Participant ID |  |
| Is Sponsoring Participant? | Boolean |  |
| Suspended? | Boolean |  |
| ***Participant User Role ID*** | Participant User Role ID |  |
| ***Legal Browser IP Address List ID*** | IP Address List ID |  |

### PTRM Session

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Comp ID*** | Comp ID |  |
| PTRM Throttle | TPS |  |

### PTRM Session – PTRM GUI User

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Comp ID*** | Comp ID |  |
| ***User ID*** | User ID |  |

### Risk Group

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Risk Group ID*** | Risk Group ID |  |
| ***Sponsoring Participant*** | Participant ID |  |
| ***Sponsored Participant*** | Participant ID |  |
| Base Group? | Boolean | One and only one Base Group per Sponsored Participant |

### Risk Group – Order Coefficient

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Risk Group ID*** | Risk Group ID |  |
| Futures Order Coefficient (%) | Percentage |  |
| Options Order Coefficient (%) | Percentage |  |

### Risk Group – Risk Check Limit

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Risk Group ID*** | Risk Group ID |  |
| Order Rate Period | Time Interval Second | 1 - 300 |
| Order Rate Limit | Order Rate Limit |  |
| Position Limit Notice Threshold (%) | Percentage |  |
| Position Limit Warning Threshold (%) | Percentage |  |
| Net Futures Exposure Limit | Risk Exposure Limit |  |
| Gross Futures Exposure Limit | Risk Exposure Limit |  |
| Net Options Exposure Limit | Risk Exposure Limit |  |
| Gross Options Exposure Limit | Risk Exposure Limit |  |
| Exposure Notice Threshold (%) | Percentage |  |
| Exposure Warning Threshold (%) | Percentage |  |
| Gross Futures Execution Throttle Limit | Risk Exposure Limit |  |
| Gross Options Execution Throttle Limit | Risk Exposure Limit |  |
| Execution Throttle Period | Time Interval Second | 300 – 600 |
| Execution Notice Threshold (%) | Percentage |  |
| Execution Warning Threshold (%) | Percentage |  |
| Enable Notice Email? | Boolean |  |
| Enable Warning Email? | Boolean |  |
| Enable Breach Email? | Boolean |  |

### Risk Group Notification List

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Notification ID*** | Notification ID |  |
| Name | PTRM Parameter Name |  |
| Description | Description |  |
| ***Risk Group ID*** | Risk Group ID |  |

### Risk Group Notification List – Item

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Notification ID*** | Notification ID |  |
| ***Email Address*** | Email Address |  |

### Risk Group Position Limit

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Position Limit ID*** | Position Limit ID |  |
| Name | PTRM Parameter Name |  |
| Description | Description |  |
| ***Risk Group ID*** | Risk Group ID |  |

### Risk Group Position Limit – Tradable Risk Check Limit

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Position Limit ID*** | Position Limit ID |  |
| ***Tradable List ID*** | Tradable List ID |  |
| ***Tradable ID*** | Tradable ID |  |
| Open Buy Limit | Quantity Limit |  |
| Open Sell Limit | Quantity Limit |  |
| Traded Bought Limit | Quantity Limit |  |
| Traded Sold Limit | Quantity Limit |  |
| Traded Net Limit | Quantity Limit |  |
| Total Buy Limit | Quantity Limit |  |
| Total Sell Limit | Quantity Limit |  |
| Total Net Buy Limit | Quantity Limit |  |
| Total Net Sell Limit | Quantity Limit |  |
| Block Trade Bought Limit | Quantity Limit |  |
| Block Trade Sold Limit | Quantity Limit |  |
| Max Order Size | Quantity |  |
| Max Block Trade Size | Quantity |  |

### Risk Group Tradable

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Tradable List ID*** | Tradable List ID |  |
| ***Tradable ID*** | Tradable ID |  |
| Product Level | Product Level | Domain Values:  M = Market  T = Instrument Type  t = Combo Type  C = Instrument Class  c = Combo Class |
| ***Market ID*** | Market ID | Applicable only if Product Level = M |
| ***Instrument Type ID*** | Instrument Type ID | Applicable only if Product Level = T |
| ***Combo Type ID*** | Combo Type ID | Applicable only if Product Level = t |
| ***Instrument Class ID*** | Instrument Class ID | Applicable only if Product Level = C |
| ***Combo Class ID*** | Combo Class ID | Applicable only if Product Level = c |

### Risk Group Tradable List

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Tradable List ID*** | Tradable List ID |  |
| Name | PTRM Parameter Name |  |
| Description | Description |  |
| ***Risk Group ID*** | Risk Group ID |  |

### Risk Group User List

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***User List ID*** | User List ID |  |
| Name | PTRM Parameter Name |  |
| Description | Description |  |
| ***Risk Group ID*** | Risk Group ID |  |

### Risk Group User List – Item

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***User List ID*** | User List ID |  |
| ***Trader ID*** | Trader ID |  |

### Sponsoring Participant

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Sponsoring Participant ID*** | Participant ID |  |
| Identity UUID | Identity UUID | Link to EIDP |
| ***Exchange ID*** | Exchange ID |  |
| ***Company ID*** | Company ID |  |
| Description | Description |  |
| Suspended? | Boolean |  |

### Sponsoring Participant – Sponsored Participant

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Sponsoring Participant ID*** | Participant ID |  |
| ***Sponsored Participant ID*** | Participant ID |  |

## Market Message

### Automatic Event Message

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Auto Event Message ID*** | Auto Event Message ID |  |
| Name | Message Name |  |
| Triggering Event | Message Triggering Event | Domain Values:  1 = Change of Trading State  2 = Alert before Trading State Change  3 = Change of Underlying State  4 = Change of Instrument/Combo  5 = Quote Request  6 = Trigger VCM  7 = End of VCM  8 = Trigger Trading Halt  9 = Trigger AHT Price Limit  10 = Alert of AHT Price Limit  13 = Trigger Trading Halt During No Resumption Period  14 = Trading Resumption  15 = Trading Halt Remaining in Effect |
| ***Template for Market Data Channel*** | Message Template ID |  |
| ***Template for Trading GUI Channel*** | Message Template ID |  |
| ***Template for Binary Channel*** | Message Template ID |  |
| ***Template for Email Channel*** | Message Template ID |  |
| Recipient for Email Channel 1 | Email Address |  |
| Recipient for Email Channel 2 | Email Address |  |
| Recipient for Email Channel 3 | Email Address |  |
| Recipient for Email Channel 4 | Email Address |  |
| Recipient for Email Channel 5 | Email Address |  |

### Market Message Template

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Message Template ID*** | Message Template ID |  |
| Name | Message Name |  |
| Target Trigger Event | Message Triggering Event | Domain Values:  1 = Change of Trading State  2 = Alert before Trading State Change  3 = Change of Underlying State  4 = Change of Instrument/Combo  5 = Quote Request  6 = Trigger VCM  7 = End of VCM  8 = Trigger Trading Halt  9 = Trigger AHT Price Limit  10 = Alert of AHT Price Limit  11 = Error Trade  13 = Trigger Trading Halt During No Resumption Period  14 = Trading Resumption  15 = Trading Halt Remaining in Effect |
| Message Priority | Message Priority | Domain Values:  C = Critical  I = Important  N = Normal |
| Subject | Message Subject |  |
| Content | Message Content |  |

## Exchange User & GUI

### Application

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***App ID*** | App ID |  |
| App Name | App Name |  |

### Application Function

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Function ID*** | Function ID |  |
| ***App ID*** | App ID |  |
| Function Number | Function No |  |
| Function Type | Function Type | Domain Values:  1 = Internal  2 = External |
| Interface Type | Interface Type | Domain Values:  01 = UI  02 = API |
| Function Name | Function Name |  |
| Display Sequence | Display Sequence |  |

### Exchange User

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***User ID*** | User ID |  |
| IDP User | Admin User ID | Link to EIDP |
| IDP User UUID | IDP User UUID | Link to EIDP |
| User Type | User Type |  |
| Function Type | Function Type | Domain Values:  1 = Internal  2 = External |
| Suspended? | Boolean |  |

### Exchange User – Role

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***User ID*** | Internal User Role ID |  |
| ***UI User Role ID*** | UI User Role ID |  |

### Local Inactive Order

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Sequence ID*** | Seq |  |
| Instrument ID | Security ID |  |
| Price | Price |  |
| Qty | Quantity |  |
| Side | Side Binary | Domain Values:  1 = Buy  2 = Sell |
| Order Type | Order Type | Domain Values:  1 = Limit Order  2 = Market Order  3 = Market To Limit Order |
| Time Validity | TIF | Domain Values:  0 = Day  1 = GTC  6 = GTD |
| Expiry Date | Date |  |
| SMP ID | SMP ID |  |
| Position Effect | Position Effect | Domain Values:  O = Open  C = Close |
| Customer | Customer |  |
| Customer Information | Customer Info |  |
| Is Give Up | Boolean |  |
| Give Up Participant | Give Up Participant |  |
| Give Up Information | Give Up Information |  |
| ATID | ATID |  |
| AHT | Boolean |  |
| COD | Boolean |  |
| User ID | User ID |  |
| IDP User ID | IDP User ID | Link to EIDP |
| Group ID | Group ID |  |
| Created Time | Timestamp |  |
| Changed Time | Timestamp |  |

### Permission

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Permission ID*** | Permission ID |  |
| ***Function ID*** | Function ID |  |
| Action | Action | Domain Value:  1 = Read  2 = Write  9 = Approve |
| Remarks | Remarks |  |
| Authorization Mode | Auth Mode | Domain Values:  1 = No Approval Required  3 = Approval Required |

### Permission – Item

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Permission ID*** | Permission ID |  |
| ***Type*** | Permission Item Type |  |
| ***Value*** | Permission Item Value |  |
| Param | Permission Item Param |  |

### UI System Preference

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***UI System Preference ID*** | UI System Preference ID |  |
| Name | Business Parameter Name |  |
| Description | Description |  |
| ***UI System Preference Group ID*** | UI System Preference Group ID |  |
| Allow Multiple Values? | Boolean |  |
| Value | UI Preference Value |  |

### UI System Preference Group

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***UI User Preference Group ID*** | UI User Preference Group ID |  |
| Name | Business Parameter Name |  |
| Description | Description |  |
| ***App ID*** | App ID |  |

### UI User Preference

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***User ID*** | User ID |  |
| ***UI User Preference ID*** | UI User Preference ID |  |
| Value | UI Preference Value |  |

### UI User Preference Default

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***UI User Preference ID*** | UI User Preference ID |  |
| Name | UI Preference Name |  |
| Description | Description |  |
| ***UI User Preference Group ID*** | UI User Preference Group ID |  |
| Allow Multiple Values? | Boolean |  |
| Default Value | UI Preference Value |  |

### UI User Preference Group

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***UI User Preference Group ID*** | UI User Preference Group ID |  |
| Name | UI Preference Name |  |
| Description | Description |  |
| ***App ID*** | App ID |  |

### UI User Role

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***UI User Role ID*** | UI User Role ID |  |
| Description | Description |  |
| Role Type | UI User Role Type | Domain Values:  1 = Admin  2 = Non-Admin |
| ***App ID*** | App ID |  |
| Function Type | Function Type | Domain Values:  1 = Internal  2 = External |
| Interface Type | Interface Type |  |

### UI User Role Permission

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***UI User Role ID*** | UI User Role ID |  |
| ***Permission ID*** | Permission ID |  |

## Instrument & Combo Generation

### Auto Combo Generation Rule Group

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Auto Combo Generation Rule Group ID*** | Auto Combo Generation Rule Group ID |  |
| Name | Business Parameter Name |  |
| Description | Description |  |
| Unit | Cycle Unit | Domain Values:  M = Monthly  W = Weekly  D = Daily |
| Type | Group Type | Domain Values:  O = Options  U = Futures |
| Until Days to Last Trading | Until Days to LTD |  |
| Pre-launch Days | Pre Launch Days |  |
| One-off Pre-launch | Boolean |  |
| Enabled? | Boolean |  |

### Auto Combo Generation Rule Group – Item

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Auto Combo Generation Rule Group ID*** | Auto Combo Generation Rule Group ID |  |
| Rule Number | List Position |  |
| ***Manual Link ID*** | Auto Combo Generation Rule ID |  |
| ***Multiple Link ID*** | Auto Combo Generation Rule ID |  |
| ***Banker Link ID*** | Auto Combo Generation Rule ID |  |
| Auto Combo Generation Rule Type | Auto Combo Generation Rule Type | Domain Values:  1 = Manual Link Rule  2 = Multiple Link Rule  3 = Banker Link Rule |

### Auto Instrument Generation

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Auto Instrument Generation Rule ID*** | Auto Instrument Generation Rule ID |  |
| Description | Description |  |
| ***Instrument Class ID*** | Instrument Class ID |  |
| Unit | Cycle Unit | Domain Values:  M = Monthly  W = Weekly  D = Daily |
| Until Days to Last Trading | Until Days to LTD |  |
| Pre-launch Days | Pre Launch Days |  |
| One-off Pre-launch FTD | Date |  |
| Last Trading Date Group | LTD Group |  |
| Last Trading Date Group Priority | LTD Group Priority |  |
| Strike Price Group | Strike Price Group |  |
| ***Cycle Blocks ID*** | Cycle Blocks ID |  |
| ***LTD Formula ID*** | LTD Formula ID |  |
| ***LTD Calendar ID*** | LTD Calendar ID |  |
| ***Lifecycle Time Rule ID*** | Lifecycle Time Rule ID |  |

### Combo Name Standard

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Name Standard ID*** | Name Standard ID |  |
| Name | Business Parameter Name |  |
| Description | Description |  |
| Type | Name Standard Type | Domain Values:  C = Combo |

### Combo Name Standard - Item

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Name Standard ID*** | Name Standard ID |  |
| ***Position*** | List Position |  |
| Category | Category | Domain Values:  1 = Underlying  2 = Last Trading Date  3 = Free Text  4 = Short name instrument group  5 = Contract size  6 = Strike price integer part (only for Options Type)  7 = Strike price decimal part (only for Options Type)  8 = Short Name Strategy  9 = Short Name Combo Group |
| Number of Characters | Num Characters | Applicable only if Category != 2 |
| Name Standard Date Format | Name Standard Date Format | Applicable only if Category = 2  Domain Values:  1 = Year (YYYY)  2 = Year (YY)  3 = Year (Y)  4 = Month Code  5 = Month Number (NN)  6 = Month Name (MMM)  7 = Date (DD)  8 = Week Number (WW) |
| Free Text | Free Text |  |
| Leg Number | Leg Number | Applicable only if Category != 5, 8, 9 |

### Combo Rule – Banker Link

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Banker Link ID*** | Auto Combo Generation Rule ID |  |
| Name | Business Parameter Name |  |
| Description | Description |  |
| Unit | Cycle Unit | Domain Values:  M = Monthly |
| ***Instrument Class ID*** | Instrument Class ID |  |
| Banker Selection Type | Banker Selection Type | Domain Values:  R = Relative  A = Absolute |
| Banker Contracts From Spot | Contracts From Spot | Applicable only if Banker Selection Type = R |
| Banker Month Selection | Month Selection | Applicable only if Banker Selection Type = R |
| Banker Month | Banker Month | Applicable only if Banker Selection Type = A  Domain Values:  1 = JAN  2 = FEB  3 = MAR  4 = APR  5 = MAY  6 = JUN  7 = JUL  8 = AUG  9 = SEP  10 = OCT  11 = NOV  12 = DEC |
| Leg Contracts | Leg Contracts |  |
| Leg From Reference | Leg From Reference | Domain Values:  S = Spot  B = Banker |
| Leg Month Selection | Month Selection | Domain Values:  1 = All  2 = Even  3 = Odd  4 = Quarterly  5 = Half-yearly  6 = Yearly  14 = Quarterly (Skip Spot/Spot-Next Month) |
| Min Time Spread | Min Time Spread |  |

### Combo Rule – Manual Link

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Manual Link ID*** | Auto Combo Generation Rule ID |  |
| Name | Business Parameter Name |  |
| Description | Description |  |
| Unit | Cycle Unit | Domain Values:  M = Monthly |
| ***Combo Class ID*** | Combo Class ID |  |

### Combo Rule – Manual Link Leg

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Manual Link ID*** | Auto Combo Generation Rule ID |  |
| ***Leg Number*** | Leg Number |  |
| ***Instrument Class ID*** | Instrument Class ID |  |
| Contracts From Spot | Contracts From Spot |  |
| Month Selection | Month Selection | Domain Values:  1 = All  2 = Even  3 = Odd  4 = Quarterly  5 = Half-yearly  6 = Yearly |
| Operation | Side Char | Domain Values:  B = Buy  S = Sell |
| Ratio | Ratio |  |

### Combo Rule – Multiple Link

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Multiple Link ID*** | Auto Combo Generation Rule ID |  |
| Name | Business Parameter Name |  |
| Description | Description |  |
| Unit | Cycle Unit | Domain Values:  M = Monthly |
| ***Instrument Class ID*** | Instrument Class ID |  |
| Leg Contracts | Leg Contracts |  |
| Month Selection | Month Selection | Domain Values:  1 = All  2 = Even  3 = Odd  4 = Quarterly  5 = Half-yearly  6 = Yearly  14 = Quarterly (Skip Spot/Spot-Next Month) |
| Min Time Spread | Min Time Spread |  |

### Cycle Block

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Cycle Blocks ID*** | Cycle Blocks ID |  |
| ***Block Number*** | List Position |  |
| ***Strike Price Range ID*** | Strike Price Range ID |  |
| ***Strike Price Reference ID*** | Strike Price Reference ID |  |

### Cycle Block – Item

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Cycle Blocks ID*** | Cycle Blocks ID |  |
| ***Block Number*** | List Position |  |
| ***Cycle Number*** | List Position |  |
| Cycle Item | Cycle Item |  |

### Cycle Blocks

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Cycle Blocks ID*** | Cycle Blocks ID |  |
| Name | Business Parameter Name |  |
| Description | Description |  |
| Unit | Cycle Unit | Domain Values:  M = Monthly  W = Weekly  D = Daily |
| Type | Cycle Type | Domain Values:  O = Options  U = Futures |

### Last Trading Date Calendar

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Last Trading Date Calendar ID*** | LTD Calendar ID |  |
| Name | Business Parameter Name |  |
| Description | Description |  |
| Unit | Cycle Unit | Domain Values:  M = Monthly  W = Weekly |

### Last Trading Date Calendar – Monthly Item

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Last Trading Date Calendar ID*** | LTD Calendar ID |  |
| ***Last Trading Date*** | Date |  |

### Last Trading Date Calendar – Weekly Default Item

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Last Trading Date Calendar ID*** | LTD Calendar ID |  |
| ***Year*** | Calendar Year |  |
| Default Weekday | Weekday | Domain Values:  1 = Monday  2 = Tuesday  3 = Wednesday  4 = Thursday  5 = Friday  6 = Saturday  7= Sunday |

### Last Trading Date Calendar – Weekly Specific Item

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Last Trading Date Calendar ID*** | LTD Calendar ID |  |
| ***Year*** | Calendar Year |  |
| Week Number | Week Number |  |
| Weekday | Weekday | Domain Values:  1 = Monday  2 = Tuesday  3 = Wednesday  4 = Thursday  5 = Friday  6 = Saturday  7= Sunday |

### Last Trading Date DST Adjustment

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***DST Adjustment ID*** | LTD DST Adjustment ID |  |
| Name | Business Parameter Name |  |
| Description | Description |  |
| Adjustment Minutes | Adjustment Minutes |  |

### Last Trading Date DST Adjustment Dates

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***DST Adjustment ID*** | LTD DST Adjustment ID |  |
| ***Year*** | Calendar Year |  |
| From | Date |  |
| To | Date |  |

### Last Trading Date Formula

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Last Trading Date Formula ID*** | LTD Formula ID |  |
| Name | Business Parameter Name |  |
| Description | Description |  |
| Unit | Cycle Unit | Domain Values:  M = Monthly  W = Weekly  D = Daily |

### Last Trading Date Formula Rules

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Last Trading Date Formula ID*** | LTD Formula ID |  |
| ***Rule Number*** | List Position |  |
| Rule Type | Rule Type | Domain Values:  1 = Monthly Trade Day Rule  2 = Monthly Calendar Day Rule  3 = Monthly Weekday Rule  4 = Weekday Rule  5 = Weekly Trade Day Rule  6 = Delta Trade Day Rule  7 = Delta Trade Day On Holiday Rule  8 = Delta Calendar Day Rule  9 = Using Regional Calendar Rule  10 = Current Day Rule |
| Month Delta | Month Delta | Applicable only if Rule Type = 1, 2  Domain Values:  0 - 11 |
| Day | Anchoring Day | Applicable only if Rule Type = 1, 2, 5  Domain Values:  1 = First trading day of the month  2 = Last trading day of the month  3 = First day of the month  4 = Last day of the month  5 = Fist trading day of the week  6 = Last trading day of the week |
| Week In Month | Week In Month | Applicable only if Rule Type = 3 |
| From Month End? | Boolean | Applicable only if Rule Type = 3 |
| Weekday | Weekday | Applicable only if Rule Type = 4  Domain Values:  1 = Monday  2 = Tuesday  3 = Wednesday  4 = Thursday  5 = Friday  6 = Saturday  7= Sunday |
| Delta Days | Delta Days | Applicable only if Rule Type = 6, 7, 8 |
| Regional Calendar ID | Regional Calendar ID | Applicable only if Rule Type = 9 |
| Include Product Calendar? | Boolean | Applicable only if Rule Type = 9 |

### Lifecycle Time Rule

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Lifecycle Time Rule ID*** | Lifecycle Time Rule ID |  |
| Name | Business Parameter Name |  |
| Description | Description |  |
| Normal Day Last Trading Time | Time |  |
| Normal Day DST Adjustment? | Boolean |  |
| Half Day Last Trading Time | Time |  |
| Half Day DST Adjustment? | Boolean |  |
| ***DST Adjustment ID*** | LTD DST Adjustment ID |  |
| First Trading Time | Time |  |

### Name Standard

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Name Standard ID*** | Name Standard ID |  |
| Name | Business Parameter Name |  |
| Description | Description |  |
| Type | Name Standard Type | Domain Values:  O = Options  U = Futures |

### Name Standard - Item

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Name Standard ID*** | Name Standard ID |  |
| ***Position*** | List Position |  |
| Category | Category | Domain Values:  1 = Underlying  2 = Last Trading Date  3 = Free Text  4 = Short name instrument group  5 = Contract size  6 = Strike price integer part (only for Options Type)  7 = Strike price decimal part (only for Options Type) |
| Number of Characters | Num Characters | Applicable only if Category != 2 |
| Name Standard Date Format | Name Standard Date Format | Applicable only if Category = 2  Domain Values:  1 = Year (YYYY)  2 = Year (YY)  3 = Year (Y)  4 = Month Code  5 = Month Number (NN)  6 = Month Name (MMM)  7 = Date (DD)  8 = Week Number (WW) |
| Free Text | Free Text |  |

### Regional Calendar

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Regional Calendar ID*** | Regional Calendar ID |  |
| Name | Business Parameter Name |  |
| Description | Description |  |
| Normal Trading Days | Trading Days | Bitmask to represent available trading days:  1 - Mon  10 - Tue  100 - Wed  1000 - Thu  10000 - Fri  100000 - Sat  1000000 - Sun  For Mon to Fri, value = 31 |

### Regional Calendar Holidays

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Regional Calendar ID*** | Regional Calendar ID |  |
| ***Holiday*** | Date |  |
| Import? | Boolean |  |
| Manual? | Boolean |  |
| Ignore? | Boolean |  |

### Regional Calendar MICs

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Regional Calendar ID*** | Regional Calendar ID |  |
| ***Regional Calendar Type*** | Regional Calendar Type | Domain Values:  E = Exchange Trading  F = Financial Centers |
| ***ISO Code*** | MIC |  |

### Regional Calendar Upload – Exchange Trading

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***ISO Code*** | MIC |  |
| Regional Calendar Name | Regional Calendar Name |  |
| ***Event Date*** | Date |  |
| Event Name | Regional Calendar Name |  |

### Regional Calendar Upload – Financial Centers

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***ISO Code*** | MIC |  |
| Regional Calendar Name | Regional Calendar Name |  |
| ***Event Date*** | Date |  |
| Event Name | Regional Calendar Name |  |

### Strike Price Range

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Strike Price Range ID*** | Strike Price Range ID |  |
| Name | Business Parameter Name |  |
| Description | Description |  |
| Method | Range Method | Domain Values:  P = Percentage  S = Steps |
| Up Range Percentage | Percentage | Applicable only if Method = P |
| Up Range Step | Range Step | Applicable only if Method = S |
| Down Range Percentage | Percentage | Applicable only if Method = P |
| Down Range Step | Range Step | Applicable only if Method = S |
| ***Strike Price Table ID*** | Strike Price Table ID |  |

### Strike Price Reference

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Strike Price Reference ID*** | Strike Price Reference ID |  |
| Name | Business Parameter Name |  |
| Description | Description |  |
| Source Type | Source Type | Domain Values:  I = Instrument Class  U = Underlying |
| ***Instrument Class ID*** | Instrument Class ID | Applicable only if Source Type = I |
| ***Underlying ID*** | Underlying ID | Applicable only if Source Type = U |
| Price Type | Price Type | Domain Values:  1 = Settlement Price  2 = Last Traded Price of current Trading Date |
| Delta Days | Delta Days |  |

### Strike Price Table

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Strike Price Table ID*** | Strike Price Table ID |  |
| Name | Business Parameter Name |  |
| Description | Description |  |
| Decimals | Decimals In Price |  |

### Strike Price Table – Item

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Strike Price Table ID*** | Strike Price Table ID |  |
| ***Below Price*** | Price |  |
| Intervals | Price |  |

## Report

### Report

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Report ID*** | Report ID |  |
| Name | Business Parameter Name |  |
| Description | Description |  |
| ***Report Type ID*** | Report Type ID |  |
| Header | Report Header |  |
| Chinese Header Name | Chinese Header Name |  |
| Keep Day For Spot Month | Keey Day |  |
| Expiration Frequency | Expiration Frequency | Domain Values:  M = Monthly  W = Weekly |
| ***Report Group List ID*** | Report Group List ID |  |
| Report Group ID | Report Group ID |  |
| ***Trading State ID*** | Trading State ID |  |

### Report Combo Group List – Item

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Combo Group List ID*** | Report Group List ID |  |
| ***Combo Class ID*** | Combo Class ID |  |
| ***Underlying ID*** | Underlying ID |  |

### Report Group List

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Report Group List ID*** | Report Group List ID |  |
| Name | Business Parameter Name |  |
| Description | Description |  |

### Report Instrument Group List – Item

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Instrument Group List ID*** | Report Group List ID |  |
| ***Instrument Class ID*** | Instrument Class ID |  |
| ***Underlying ID*** | Underlying ID |  |
| Contract Description | Contract Description |  |
| Chinese Contract Description | Chinese Contract Description |  |
| Contract Term | Contract Term |  |

### Report Type

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Report Type ID*** | Report Type ID | Domain Values:  1 = Day Reports - Futures with AHT  2 = Day Reports - Index Options with AHT  3 = Day Reports - TMC with AHT  4 = Night Reports - Futures with AHT  5 = Night Reports - Index Options with AHT  6 = Night Reports - TMC with AHT  7 = Stock Futures Reports  8 = Index Futures Reports  9 = Stock Options Reports  10 = Index & Currency Options Reports  11 = Flexible Index Options Reports  12 = TMC Reports  13 = Weekly Quotation Report  14 = HKFE Options Inst. Maintenance Report  15 = SEHK Options Inst. Maintenance Report  16 = SMP Participant Exclusion List |
| Name | Report Name |  |
| Description | Description |  |
| Instrument Group Type | Group Type | Domain Values:  O = Options  F = Forward  U = Futures  A = FRA  C = Cash  P = Payment  E = Exchange rate  S = Interest rate swap |
| Report Group | Report Group | Domain Values:  D = Daily Market Report  W = Weekly Quotation Report  M = Instrument Maintenance Report Type  S = SMP Participant Exclusion List |

### SMP Participant Exclusion List- Item

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Report ID*** | Report ID |  |
| ***Exchange Participant ID*** | Participant ID |  |

## System

### Admin Sequence

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Table Name*** | Table Name |  |
| ***Seq Key*** | Seq Key |  |
| Seq | Seq |  |
| Creation Time | Timestamp |  |
| Last Update Time | Timestamp |  |

### Contingency Switch

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Contingency Switch ID*** | Contingency Switch ID |  |
| Static Price Limit Enabled? | Boolean |  |
| Dynamic Price Limit Enabled? | Boolean |  |
| VCM Enabled? | Boolean |  |
| SMP Enabled? | Boolean |  |
| Implied Enabled? | Boolean |  |
| PTRM Enabled? | Boolean |  |

### Distribution Queue Header

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Distribution Queue Header ID*** | Distribution Queue Header ID |  |
| App ID | App ID |  |
| Event ID | Event ID |  |
| Event Type | Event Type |  |
| Send Type | Distribution Type | Domain Values:  1 = SMTP 2 = SFTP 3 = HTTP |
| Message Priority | Message Priority | Domain Values:  C = Critical I = Important N = Normal |
| Status | Distribution Status | Domain Values:  N = New A = Acked E = Executed F = Failed R = Rejected |
| Retry Count | Retry Count |  |
| Max Retry | Retry Count |  |
| Creation Time | Timestamp |  |
| Sent Time | Timestamp |  |
| Last Failure Reason | Failed Reason |  |

### Distribution Queue HTTP Body

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Distribution Queue Header ID*** | Distribution Queue Header ID |  |
| Distribution Queue HTTP Body ID | Distribution Queue Body ID |  |
| Destination URL | URL |  |
| Request HTTP Header | Request HTTP Header |  |
| Request HTTP Body | Request HTTP Body |  |

### Distribution Queue SMTP Body

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Distribution Queue Header ID*** | Distribution Queue Header ID |  |
| Distribution Queue SMTP Body ID | Distribution Queue Body ID |  |
| Destination URL | URL |  |
| To Email | Email Address |  |
| Email Subject | Message Subject |  |
| Email Body | Message Content |  |

### Distribution Queue SFTP Body

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Distribution Queue Header ID*** | Distribution Queue Header ID |  |
| Distribution Queue SFTP Body ID | Distribution Queue Body ID |  |
| Destination URL | URL |  |
| File Name | SFTP File Name |  |

### Gateway Partition

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Service Type*** | Gateway Service Type | Domain Values:  P = Order Flow - PSG  O = Order Flow - CGW  D = Drop Copy  R = PTRM |
| ***Partition ID*** | Partition ID |  |
| ***Sub Partition ID*** | Sub Partition ID | Applicable for Order Flow – PSG only |
| Session Usage | Session Usage | Domain Values:  D = Direct Access  U = UI Access |
| Interface Protocol | Interface Protocol | Domain Values:  B = Binary  F = FIX |

### Global Parameters

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Global Parameters ID*** | Global Parameters ID |  |
| Instrument Retention Period | Duration In Days |  |
| Maximum Order Quantity | Quantity |  |
| Maximum Block Trade Quantity | Quantity |  |
| Maximum Price | Price |  |
| Maximum Price Decimals | Decimals In Price |  |
| Minimum Price | Price |  |
| Minimum Price Decimals | Decimals In Price |  |
| Maximum Orders Per Price Q In PREOPEN | Max Orders Per Price Q |  |
| Maximum Orders Per Price Q In OPEN | Max Orders Per Price Q |  |
| Maximum Order Flow Session | Num Session |  |
| Maximum Trading GUI User | Num User |  |
| Maximum Drop Copy Session | Num Session |  |
| Maximum PTRM GUI User | Num User |  |
| Maximum TPS Per Order Flow Session | TPS |  |
| Maximum Risk Group Per Sponsored Participant | Num Risk Group |  |
| Maximum Trader ID Per Risk Group | Num Trader ID |  |
| Maximum Risk Limit Group Per Risk Group | Num Risk Limit Group |  |
| Maximum TPS Per PTRM Session | TPS |  |
| Maximum Notification ID Per Risk Group | Num Notification ID |  |
| Maximum Trading Hours | Max Trading Hours |  |
| Earliest Trading Start Logical Day Ind | Logical Day Indicator |  |
| Earliest Trading Start Time | Time |  |
| Latest Trading End Logical Day Ind | Logical Day Indicator |  |
| Latest Trading End Time | Time |  |
| ***Trading Pause Trading State ID*** | Trading State ID |  |
| Number Of Missing Heartbeat | Num Missing Heartbeat |  |
| Timeout Before COD | Time Interval Second |  |
| Duplicated Leg In Block Trade Allowed? | Boolean |  |
| Block Trade Allowed Conclusion Time | Time Interval Second |  |
| Maximum Order Size Limit By EP | Quantity |  |
| Maximum Block Trade Size Limit By EP | Quantity |  |
| Num Of Leg In Block Trade | Num Legs |  |
| Abrupt Disconnection Trigger COD? | Boolean |  |
| Remove Orders Violating Internal Crossing Rule? | Boolean |  |
| Mass Quote Allowed Different Underlying Issuer? | Boolean |  |
| Maximum Quote Entries Per Comp ID Per Instrument | Num Quote Entries |  |
| Maximum TMC | Num Instrument |  |
| Maximum TMC Per EP | Num Instrument |  |
| Default Order Size Limit | Quantity |  |
| Default Block Trade Size Limit | Quantity |  |
| Default PTRM Max Size Limit | Quantity |  |
| Default PTRM Exposure Limit | Risk Exposure Limit |  |
| Default PTRM Quantity Limit | Quantity Limit |  |
| Default PTRM Order Rate Limit | Order Rate Limit |  |
| Default Order Ratio Period | Time Interval Second |  |
| Default Order Coefficient (%) | Percentage |  |
| Default Execution Throttle Period | Time Interval Second |  |
| Default PTRM Notice Threshold (%) | Percentage |  |
| Default PTRM Warning Threshold (%) | Percentage |  |
| Default MMP Include Futures? | Boolean |  |
| Default MMP Quantity Protection | Quantity Limit |  |
| Default MMP Delta Protection | Quantity Limit |  |
| Default MMP Exposure Time Limit Interval | Time Interval Second |  |
| Default MMP Frozen Time | Time Interval Second |  |
| Disseminate Implied In Orders Via Market Data? | Boolean |  |
| CA Cool-off Period | Duration In Days |  |
| SMP ID Maintenance Request Approval Period | Duration In Days |  |
| SMP ID Counterparty Request Period | Duration In Days |  |
| SMP ID Retention Period | Duration In Days |  |

### Market Operation Transaction

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***TX ID*** | TX ID |  |
| TX Request ID | TX Request ID |  |
| Market Operation Tx Type | Market Operation Tx Type | Domain Values:  1 = Request  2 = Response  3 = Update |
| Source | Component ID |  |
| Destination | Component ID |  |
| Market Operation Type | Market Operation Type |  |
| Market Operation Tx Status | Market Operation Tx Status | Domain Values:  N = New  S = Submitted  A = Acked  E = Executed  F = Failed  R = Rejected |
| Error Code | Error Code | Update when transaction fails  0 means no error |
| Error Description | Error Description | <blank> for success case |
| Admin Sequence | Seq | Sequence number stamped by msg from Admin to MAP (starting from 1) |
| Backend Sequence | Seq | Sequence number stamped by msg from Backend to Admin (starting from 1) |
| Creation User ID | Admin User ID |  |
| Creation Time | Timestamp |  |
| Modification User ID | Admin User ID |  |
| Modification Time | Timestamp |  |
| Authoriser User ID | Admin User ID |  |
| Authoriser Time | Timestamp |  |
| Last Update Time | Timestamp |  |
| Update Count | Update Count |  |

### Market Operation Transaction – Item

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***TX ID*** | TX ID |  |
| ***Item Sequence*** | Item Sequence |  |
| Item Type | Tx Type |  |
| Item Action | Item Action | Domain Values:  A = Add  U = Update  D = Delete  W = Withdraw |
| ***Parent TX ID*** | TX ID |  |
| Item Detail | Item Detail |  |

### Market State

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Market ID*** | Market ID |  |
| Trading Date | Date | Business Date |
| Trade Date | Date |  |
| Market State | Market State | Domain Values:  1 = SOD 2 = Normal Processing  9 = EOD |
| Market Startup Time | Timestamp |  |
| Last State Change Time | Timestamp |  |

### ME Partition

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***ME Type*** | ME Type | Domain Values:  O = Order Management  B = Block Trade  T = Trade Management |
| ***Partition ID*** | Partition ID |  |

### Password Policy

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Password Policy ID*** | Password Policy ID |  |
| Password Policy Name | Password Policy Name |  |
| Policy Type | Password Policy Type | Domain Values:  I = Internal  E = External  S = System (development use ONLY) |
| Minimum Password Length | Password Length | Must > 0 |
| Maximum Password Length | Password Length |  |
| Minimum Upper Case Letters | Password Min Characters |  |
| Minimum Lower Case Letters | Password Min Characters |  |
| Minimum Digits | Password Min Characters |  |
| Minimum Special Characters | Password Min Characters |  |
| Password Validity Period | Password Validity Period |  |
| Password Expiry Advance Alert | Password Expiry Alert | Advance alert on password expiry, specified in days: 0 – 99 |
| Enforce Password Expiry Check? | Boolean |  |
| Password Reuse Cycle | Password Reuse Cycle | Number of Historical Passwords that can’t be reused:  0 = any password can be reused,  1 = the most recent password can’t be reused;  <and so on> |
| Number of Failed Attempts | Num Failed Attempts |  |
| Change Password on 1st Logon? | Boolean |  |
| Maximum Password Changes Per Day | Max Password Changes Per Day |  |
| Inactivity Period | Inactivity Period |  |
| Password Expiry and Inactivity Handling | Password Expiry Inactivity Handling | Domain Values:  0 = No Action  1 = Lock Account  2 = Force Change Password |

### PTRM Market Operation Transaction

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***TX ID*** | TX ID |  |
| TX Request ID | TX Request ID |  |
| Market Operation Tx Type | Market Operation Tx Type | Domain Values:  1 = Request  2 = Response  3 = Updste |
| Source | Component ID |  |
| Destination | Component ID |  |
| Market Operation Type | Market Operation Type |  |
| Market Operation Tx Status | Market Operation Tx Status | Domain Values:  N = New  S = Submitted  A = Acked  E = Executed  F = Failed  R = Rejected |
| Error Code | Error Code | Update when transaction fails  0 means no error |
| Error Description | Error Description | <blank> for success case |
| Admin Sequence | Seq | Sequence number stamped by msg from Admin to Backend (starting from 1) |
| Backend Sequence | Seq | Sequence number stamped by msg from MAP to Backend (starting from 1) |
| Creation User ID | Admin User ID |  |
| Creation Time | Timestamp |  |
| Modification User ID | Admin User ID |  |
| Modification Time | Timestamp |  |
| Authoriser User ID | Admin User ID |  |
| Authoriser Time | Timestamp |  |
| Last Update Time | Timestamp |  |
| Update Count | Update Count |  |

### PTRM Market Operation Transaction – Item

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***TX ID*** | TX ID |  |
| ***Item Sequence*** | Item Sequence |  |
| Item Type | Tx Type |  |
| Item Action | Item Action | Domain Values:  A = Add  U = Update  D = Delete  W = Withdraw |
| ***Parent TX ID*** | TX ID |  |
| Item Detail | Item Detail |  |

### Reload Orders

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Sequence ID*** | Seq |  |
| ***Comp ID*** | Comp ID |  |
| ***Trader ID*** | Trader ID |  |
| ***Security ID*** | Security ID |  |
| Client Order ID | Client Order ID |  |
| Order ID | Order ID |  |
| Side | Side | Domain Values:  0 = Buy  1 = Sell |
| Order Type | Order Type | Domain Values:  1 = Limit Order |
| Order Price | Price |  |
| Order Quantity | Quantity |  |
| Open Quantity | Quantity |  |
| Filled Quantity | Quantity |  |
| Order Submission Timestamp | Timestamp |  |
| Priority Timestamp | Timestamp |  |
| Day Order ID | Order ID |  |
| Quote Entry ID | Quote Entry ID |  |
| Order State | Order State |  |
| TIF | TIF | Domain Values:  1 = GTC  6 = GTD |
| Expiry Time | Timestamp |  |
| Public Open Quantity | Quantity |  |
| Display Quantity | Quantity |  |
| Customer Info | Customer Info |  |
| Lot Type | Lot Type | Domain Values:  2 = Round Lot |
| Order Version Number | Order Version Number |  |
| Original Order Type | Order Type | Domain Values:  1 = Limit Order  2 = Market Order  3 = Market To Limit Order |
| SMP ID | SMP ID |  |
| Clearing Account | Clearing Account |  |
| Give Up Participant | Give Up Participant |  |
| Give Up Info | Give Up Information |  |
| Position Effect | Position Effect | Domain Values:  O = Open  C = Close |
| AHT Flag | Binary Flag | Domain Values:  0 = N  1 = Y |
| COD Flag | Binary Flag | Domain Values:  0 = N  1 = Y |
| ATID | ATID |  |
| Cancel Hint Value | Cancel Hint Value |  |
| Cancel On MMP Trigger Flag | Binary Flag | Domain Values:  0 = N  1 = Y |

### System State

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| Trading Date | Date | Business Date |
| Trade Date | Date |  |
| Logical Day Num | Logical Day Num | Start with 0; incremented by 1 per intra-day system restart |
| System State | System State | Domain Values:  1 = SOD 2 = Normal Processing  9 = EOD |
| Active Site | Site ID | Domain Values:  P = Primary  S = Secondary |
| DR Site Activated | Boolean |  |
| DR Site Activation Time | Timestamp |  |
| In Testing Mode? | Boolean |  |
| System Startup Time | Timestamp |  |
| Last State Change Time | Timestamp |  |

### Trading Sequence

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Identifier*** | Identifier |  |
| ***Seq Key*** | Seq Key |  |
| Seq | Seq |  |
| Creation Time | Timestamp |  |
| Last Update Time | Timestamp |  |

### Transaction

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***TX ID*** | TX ID |  |
| TX Source | TX Source | Domain Values:  A = Admin UI  T = Trading UI |
| TX Type | TX Type |  |
| TX Identifier | TX Indentifier |  |
| Function ID | Function ID | Function ID of the UI function. System will resolve the Function Name based on Application entity |
| TX Status | TX Status | Domain Values:  P = Pending Approval  A = Approved  R = Rejected  F = Failed (for approval) |
| TX Request ID | TX Request ID |  |
| Event ID | Event ID |  |
| Execution Status | Execution State | Domain Values:  P = Pending  S = Scheduled  E = Executed  F = Failed  R= Rejected |
| TX Action | TX Action | Domain Values:  A = Add  U = Update  D = Delete  W = Withdraw |
| System Approve | Boolean |  |
| Original Event Type | Event Type |  |
| User Group | User Group ID |  |
| Error Code | Error Code |  |
| Error Description | Error Description |  |
| Effective Date | Date |  |
| Scheduled Time | Timestamp |  |
| Related TX ID | TX ID |  |
| Creation User ID | Admin User ID |  |
| Creation Time | Timestamp |  |
| Modification User ID | Admin User ID |  |
| Modification Time | Timestamp |  |
| Authoriser User ID | Admin User ID |  |
| Authoriser Time | Timestamp |  |
| Last Update Time | Timestamp |  |
| Update Count | Update Count |  |

### Transaction – Item

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***TX ID*** | TX ID |  |
| ***Item Sequence*** | Item Sequence |  |
| Item Type | Tx Type |  |
| Item Action | Item Action | Domain Values:  A = Add  U = Update  D = Delete  W = Withdraw |
| ***Parent TX ID*** | TX ID |  |
| Item Detail | Item Detail |  |

### Transaction Event

|  |  |  |
| --- | --- | --- |
| Attribute | Type | Remarks |
| ***Event ID*** | Event ID |  |
| ***Event Type*** | Event Type |  |
| Event Body | Event Body |  |
| ***Event Status*** | Event Status | Domain Values:  N = New  K = Acked  S = Submitted  E = Executed  R = Rejected  F = Failed |
| Event Timestamp | Timestamp |  |

# System Limits

The system design has to take into account certain boundaries as the basis for the technical solution. The absolute technical upper limits set for entities, parameters and attributes are as follows.

|  |  |  |  |
| --- | --- | --- | --- |
| Attribute | Technical Limit | Adjustable by Business Operations?1 | Remarks |
| Num of Instrument | 600,000 |  |  |
| Num of Combo | 10,000 |  |  |
| Num of Leg per Combo | 4 |  |  |
| Num of TMC | 10,000 | Y |  |
| Num of TMC per EP | 10,000 | Y |  |
| Num of Underlying | 5,000 |  |  |
| Num of Exchange | 10 |  |  |
| Num of Market | 500 |  |  |
| Num of Instrument Group | 500 |  |  |
| Num of Instrument Type | 2,000 |  |  |
| Num of Instrument Class | 10,000 |  |  |
| Num of Combo Group | 500 |  |  |
| Num of Combo Type | 2,000 |  |  |
| Num of Combo Class | 10,000 |  |  |
| Num of Access Group By Type | 1,000 |  |  |
| Num of Company | 5,000 |  |  |
| Num of Participant per Company | 2,000 |  |  |
| Num of Exchange Participant | 2,000 |  |  |
| Num of Participant Trading Rights per EP | 500 |  |  |
| Num of Sponsoring Participant | 2,000 |  |  |
| Num of Sponsored Participant per Sponsoring Participant | 500 |  |  |
| Num of Order Flow Session | 20,000 | Y |  |
| Num of Trading GUI User | 3,000 | Y |  |
| Num of Drop Copy Session | 2,000 | Y |  |
| Num of Drop Copy Group per Drop Copy Session | 16 |  |  |
| Num of PTRM Session | 2,000 |  |  |
| Num of PTRM GUI User | 2,000 | Y |  |
| Num of Trader ID | 20,000 |  |  |
| Num of Trader ID per EP | 1,000 |  |  |
| Num of Trader ID per Order Flow Session | 1 |  |  |
| Num of TPS per Order Flow Session | 100 | Y |  |
| Num of Quote Entries in Mass Quote | 15 |  |  |
| Num of Quote Entries Per Comp ID per Instrument | 250 | Y |  |
| Num of Leg in Block Trade | 8 | Y |  |
| Num of Trading Rights | 5,000 |  |  |
| Num of Row per Trading Rights | 500 |  |  |
| Num of SMP ID | 50,000 |  |  |
| Num of SMP ID per EP | 600 |  |  |
| Num of Exchange Participant to Share a SMP ID | 3000 |  |  |
| Num of User Role | 100 |  |  |
| Num of Drop Copy Group | 5,000 |  |  |
| Num of Drop Copy Group per EP | 100 |  |  |
| Num of Trader ID per Drop Copy Group | 500 |  |  |
| Num of Entitled Product Type per Drop Copy Session | 16 |  |  |
| Num of Risk Group | 6,000 | Y |  |
| Num of Risk Group per Sponsored Participant | 100 | Y |  |
| Num of Trader ID per Risk Group | 500 | Y |  |
| Num of Notification ID per Risk Group | 10 | Y |  |
| Num of Tradable | 600,000 |  |  |
| Num of Tradable per Risk Group | 1,000 | Y |  |
| Num of TPS per PTRM Session | 10 | Y |  |
| Num of IP Address per IP Address List | 5000 |  |  |
| Num of Non-Trading Days | 99 |  |  |
| Num of Item per Non-Trading Days | 999 |  |  |
| Num of Special Trading Days | 99 |  |  |
| Num of Item per Special Trading Days | 999 |  |  |
| Num of Trading Timetable | 999 |  |  |
| Num of Trading State per Timetable | 20 |  |  |
| Num of Trading State | 99 |  |  |
| Num of Price Tick | 999 |  |  |
| Num of Band per Price Tick | 16 |  |  |
| Num of Price Tick Limit | 999 |  |  |
| Num of Block Trade Group | 99 |  |  |
| Num of Price Limit | 99 |  |  |
| Num of Price Limit Parameters per Price Limit | 16 |  |  |
| Num of Price Limit Parameters | 99 |  |  |
| Num of Row per Price Limit Rule | 16 |  |  |
| Num of Halt Target List | 99 |  |  |
| Num of Instrument Class per Halt Target List | 16 |  |  |
| Num of Reference Price Source | 99 |  |  |
| Num of VCM | 99 |  |  |
| Num of VCM Parameters per VCM | 16 |  |  |
| Num of VCM Parameters | 99 |  |  |
| Num of Futures Group | 99 |  |  |
| Num of Reference Price Calculation Rule | 99 |  |  |
| Num of Block Trade MVT | 999 |  |  |
| Num of Band per Block Trade MVT | 16 |  |  |
| Max Order Quantity | 999,999,999 | Y |  |
| Max Block Trade Quantity | 999,999,999 | Y |  |
| Max Price | 999,999,999,999,999,999 | Y |  |
| Max Price Decimals | 18 | Y |  |
| Min Price | -999,999,999,999,999,999 | Y |  |
| Min Pirce Decimals | 0 | Y |  |
| Decimals in Percentage | 4 |  |  |
| Max Orders Per Price Q in PREOPEN | 100,000 | Y |  |
| Max Orders Per Price Q in OPEN | 100,000 | Y |  |
| Instrument Retention Period (Days) | 365 | Y |  |
| Max Trading Hours | 23 | Y |  |
| Max Inactive Order Per User | 2,000 |  |  |
| Num of Cycle Block per Cycle Blocks | 10 |  |  |
| Num of Block Item per Cycle Block | 36 |  |  |
| Num Rule per Last Trading Date Formula | 20 |  |  |
| Num of Auto Combo Generation Rule Group | 5,000 |  |  |
| Num of Rule per Auto Combo Generation Rule Group | 20 |  |  |

Notes:

1. Business Operations can customize the upper limits for the designated items (i.e., as needed per business requirements) using Admin GUI (Maintain Global Parameters screen) with the general rule that Business Upper Limit must always be less than or equal to Technical Upper Limit.

# Data Types

The table below describes each data type used in the definition of logical entity attributes in the data dictionary (Section 10.).

|  |  |  |
| --- | --- | --- |
| Data Type | Size | Description |
| Char | 1 | One character from ‘0’ to ‘9’, ‘a’ to ‘z’, ‘A’ to ‘Z’ or a Space. |
| Boolean | 1 | Y = Yes/True or N = No/False |
| Numeric | As defined | Any digit from 0 to 9. |
| Alphanumeric | As defined | Any printable ASCII character(s). |
| Decimal | As defined | Any digit from 0 to 9.  With implicit decimals, the number of decimal places is separately and explicitly defined.  For example, if the size 5 and number of decimal places applicable to this field is 2 then the value can be 999.99.  Range of value is from 0 to 999,999,999,999,999,999. |
| Price | 18 | Any digit from 0 to 9.  Signed number and support up to 6 decimal places by default and configurable per instrument type/class |
| Quantity | 9 | Any digit from 0 to 9.  Range of value is from 0 to 999,999,999. |
| Percentage | 9 | Any digit from 0 to 9.  With 4 implied decimal places  Range of Values is therefore from 0 to 9,999,999.  For example, 99999 means 9.9999% |
| Date | 8 | In YYYYMMDD format |
| Time | 6 | In HHMMSS format |
| Timestamp | 20 | In YYYYMMDD HHMMSSmmmuuu format |

# Data Dictionary

The following table lists all the common attributes and their properties.

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
| Data Item | Data Type | Size | Valid Value(s) | Remarks |
| Access Group By Type ID | Numeric | 5 |  |  |
| Action | Numeric | 2 | 1 = Read  2 = Write  9 = Approve |  |
| Adjustment Minutes | Numeric | 5 |  |  |
| Adjustment Ratio | Decimal | 10 |  | Capital adjustment ratio  With 6 implied decimal places |
| Admin User ID | Alphanumeric | 64 |  |  |
| Anchoring Day | Numeric | 2 | 1 = First trading day of the month  2 = Last trading day of the month  3 = First day of the month  4 = Last day of the month  5 = Fist trading day of the week  6 = Last trading day of the week |  |
| App ID | Numeric | 5 |  |  |
| App Name | Alphanumeric | 32 |  |  |
| ATID | Alphanumeric | 5 |  |  |
| Auth Mode | Numeric | 2 | 1 = No Approval Required  3 = Approval Required |  |
| Auto Combo Generation Rule Group ID | Numeric | 5 |  |  |
| Auto Combo Generation Rule ID | Numeric | 10 |  |  |
| Auto Combo Generation Rule Type | Numeric | 2 | 1 = Manual Link Rule  2 = Multiple Link Rule  3 = Banker Link Rule |  |
| Auto Event Message ID | Numeric | 5 |  |  |
| Auto Instrument Generation Rule ID | Numeric | 5 |  |  |
| Banker Month | Numeric | 2 | 1 = JAN  2 = FEB  3 = MAR  4 = APR  5 = MAY  6 = JUN  7 = JUL  8 = AUG  9 = SEP  10 = OCT  11 = NOV  12 = DEC |  |
| Banker Select Type | Char |  | R = Relative  A = Absolute |  |
| Binary Flag | Numeric | 2 | 0 = N  1 = Y |  |
| Block Trade Group ID | Numeric | 5 |  |  |
| Block Trade MVT ID | Numeric | 5 |  |  |
| Blocked Reason | Numeric | 2 | 0 = N/A  1 = Blocked by Admin |  |
| Business Parameter Name | Alphanumeric | 12 |  |  |
| CA Event ID | Numeric | 10 |  |  |
| CA Event Type | Char |  | R = Right Issue  B = Bonus Issue of Shares  W = Bonus Issue of Warrants  C = Share Consolidation  S = Share Sub-division  M = Merger (Shares and Cash)  m = Merger (Shares Only)  E = Spin-Off (E-Day)  F = Spin-Off (F-Day; with Entitlement)  D = Other Cash Distribution (Special Dividend)  X = Other CA Events |  |
| CA Instrument Class ID | Numeric | 10 |  |  |
| CA Instrument ID | Numeric | 10 |  |  |
| CA Priority | Numeric | 5 |  |  |
| CA Underlying ID | Numeric | 10 |  |  |
| Calculation Rule ID | Numeric | 5 |  |  |
| Calendar Year | Numeric | 4 |  |  |
| Cancel Hint Value | Numeric | 5 |  |  |
| Category | Numeric | 2 | 1 = Underlying  2 = Last Trading Date  3 = Free Text  4 = Short name instrument group  5 = Contract size  6 = Strike price integer part (only for Options Type)  7 = Strike price decimal part (only for Options Type)  8 = Short Name Strategy  9 = Short Name Combo Group |  |
| Chinese Contract Description | Alphanumeric |  |  |  |
| Chinese Contract Term | Alphanumeric |  |  |  |
| Chinese Header Name | Alphanumeric |  |  |  |
| Clearing Account | Alphanumeric | 10 |  |  |
| Client Order ID | Numeric | 20 |  |  |
| Combo Class ID | Alphanumeric | 14 |  |  |
| Combo Group Code | Numeric | 5 |  |  |
| Combo Group ID | Alphanumeric | 3 |  |  |
| Combo Type ID | Alphanumeric | 8 |  |  |
| Comp ID | Alphanumeric | 11 |  | Session Login ID, also referred to as Session ID |
| Company Description | Alphanumeric | 255 |  |  |
| Company ID | Numeric | 4 |  |  |
| Company Name | Alphanumeric | 150 |  |  |
| Company UUID | Alphanumeric | 36 |  |  |
| Component ID | Alphanumeric | 128 |  |  |
| Contingency Switch ID | Numeric | 2 |  |  |
| Contract Description | Alphanumeric | 64 |  |  |
| Contract Month Option | Char |  | S = Spot  N = Non-Spot  B = Both |  |
| Contract Size | Decimal | 10 |  |  |
| Contract Term | Alphanumeric | 64 |  |  |
| Contracts From Spot | Numeric | 2 | 0 – 30 |  |
| Creation Ref No | Numeric | 5 |  |  |
| Currency Code | Alphanumeric | 3 |  |  |
| Customer | Alphanumeric | 10 |  |  |
| Customer Info | Alphanumeric | 16 |  |  |
| Cycle Blocks ID | Numeric | 5 |  |  |
| Cycle Item | Alphanumeric | 10 |  |  |
| Cycle Type | Char |  | O = Options  U = Futures |  |
| Cycle Unit | Char |  | M = Monthly  W = Weekly  D = Daily |  |
| Data Source | Numeric | 2 | 0 = N/A  1 = OMD-C  2 = OMD-I |  |
| Data Source Symbol Code | Alphanumeric | 64 |  |  |
| Decimals In Price | Numeric | 2 |  |  |
| Default Account | Alphanumeric | 10 |  |  |
| Delta Days | Numeric | 2 | 0 – 31 |  |
| Description | Alphanumeric | 40 |  |  |
| Deviation Unit | Char |  | A = Absolute Value T = Number of Ticks P = Percentage |  |
| Distribution Queue Body ID | Numeric | 20 |  |  |
| Distribution Queue Header ID | Numeric | 20 |  |  |
| Distribution Status | Char | 1 | N = New A = Acked E = Executed F = Failed R = Rejected |  |
| Distribution Type | Numeric | 2 | 1 = SMTP 2 = SFTP 3 = HTTP |  |
| Display Sequence | Numeric | 5 |  |  |
| Drop Copy Group ID | Numeric | 10 |  |  |
| Duration In Days | Numeric | 4 |  |  |
| Failed Signon Attempts | Numeric | 10 |  |  |
| Email Address | Alphanumeric | 512 |  |  |
| Encrypted Password | Alphanumeric | 1024 |  |  |
| Error Code | Numeric | 10 |  |  |
| Error Description | Alphanumeric | 200 |  |  |
| Event Body | Alphanumeric | 4194304 |  |  |
| Event ID | Numeric | 20 |  |  |
| Event Status | Char |  | N = New  K = Acked  S = Submitted  E = Executed  R = Rejected  F= Failed |  |
| Event Type | Numeric | 10 |  |  |
| Exchange Code | Numeric | 3 | 1 – 255 |  |
| Exchange ID | Alphanumeric | 2 |  |  |
| Execution Status | Char |  | P = Pending  S = Scheduled  E = Executed  F = Failed  R= Rejected |  |
| Expiration | Numeric | 10 |  |  |
| Expiration Frequency | Char |  | M = Monthly  W = Weekly |  |
| Failed Reason | Alphanumeric | 254 |  |  |
| Free Text | Alphanumeric | 32 |  |  |
| Function ID | Alphanumeric | 18 |  |  |
| Function Name | Alphanumeric | 256 |  |  |
| Function No | Numeric | 5 |  |  |
| Function Type | Numeric | 2 | 1 = Internal  2 = External |  |
| Futures Group ID | Numeric | 5 |  |  |
| Give Up Information | Alphanumeric | 15 |  |  |
| Give Up Participant | Alphanumeric | 8 |  |  |
| Global Parameters ID | Numeric | 2 |  |  |
| Group ID | Alphanumeric | 10 |  |  |
| Group Type | Char |  | O = Options F = Forward U = Futures A = FRA C = Cash P = Payment E = Exchange rate S = Interest rate swap |  |
| Gateway Service Type | Char |  | O = Order Flow D = Drop Copy R = PTRM |  |
| Halt Target List ID | Numeric | 5 |  |  |
| HTTP Request Header | Alphanumeric | 254 |  |  |
| HTTP Request Body | Alphanumeric | 65535 |  |  |
| Identifier | Alphanumeric | 64 |  |  |
| Identity UUID | Alphanumeric | 36 |  |  |
| IDP Company ID | Numeric | 10 |  |  |
| IDP User ID | Alphanumeric | 32 |  |  |
| IDP User UUID | Alphanumeric | 36 |  |  |
| Inactivity Period | Numeric | 4 |  |  |
| Instrument Class ID | Alphanumeric | 14 |  |  |
| Instrument Group Code | Numeric | 3 | 1 – 255 |  |
| Instrument Group ID | Alphanumeric | 3 |  |  |
| Instrument Type ID | Alphanumeric | 8 |  |  |
| Interface Type | Alphanumeric | 2 | 01 = UI  02 = API |  |
| Interface Protocol | Char |  | B = Binary F = FIX |  |
| IP Address List ID | Numeric | 10 |  |  |
| IP Address | Alphanumeric | 15 |  | 999.999.999.999 format |
| ISIN | Alphanumeric | 12 |  |  |
| Item Action | Char |  | A = Add  U = Update  D = Delete  W = Withdraw |  |
| Item Detail | Alphanumeric | 65535 |  |  |
| Item Sequence | Numeric | 5 |  |  |
| Keep Day | Numeric | 5 |  |  |
| Leg Contracts | Numeric | 5 |  |  |
| Leg From Reference | Char |  | S = Spot  B = Banker |  |
| Leg Number | Numeric | 2 |  |  |
| Lifecycle Time Rule ID | Numeric | 5 |  |  |
| List Position | Numeric | 5 |  |  |
| Locked Reason | Char |  | <blank> = N/A  E = Password Expired  R = Password Retry Attempts Exceeded  I = Inactivity |  |
| Logical Day Indicator | Numeric | 2 | -1 = T-1 0 = T 1 = T+1 |  |
| Logical Day Num | Numeric | 2 |  |  |
| Lot Type | Numeric | 2 | 2 = Round Lot |  |
| LTD Calendar ID | Numeric | 5 |  |  |
| LTD DST Adjustment ID | Numeric | 5 |  |  |
| LTD Formula ID | Numeric | 5 |  |  |
| LTD Group | Alphanumeric | 32 |  |  |
| LTD Group Priority | Numeric | 1 | 0 – 9 |  |
| Market Code | Numeric | 3 | 1 – 255 |  |
| Market ID | Alphanumeric | 5 |  |  |
| Market Operation Tx Status | Char |  | N = New  S = Submitted  A = Acked  E = Executed  F = Failed  R = Rejected |  |
| Market Operation Tx Type | Numeric | 2 | 1 = Request  2 = Response  3 = Update |  |
| Market Operation Type | Alphanumeric | 40 |  |  |
| Market Priority Number | Numeric | 5 |  |  |
| Market Status | Numeric | 2 | 1 = SOD  2 = Normal Processing  9 = EOD |  |
| Market Type | Char |  | S = Stock F = Fixed Income U = Currency E = Power/energy C = Commodity P = Payment I = Index G = General |  |
| Max Orders Per Price Q | Numeric | 6 | 1 – 100000 |  |
| Max Password Changes Per Day | Numeric | 2 | 1 – 10 |  |
| Max Trading Hours | Numeric | 2 | 1 – 24 |  |
| Max Triggers | Numeric | 2 | 0 – 99 |  |
| ME Type | Char | 1 | O = Order Management  B = Block Trade  T = Trade Management |  |
| Message Template ID | Numeric | 5 |  |  |
| Message Content | Alphanumeric | 900 |  |  |
| Message Name | Alphanumeric | 32 |  |  |
| Message Priority | Char |  | C = Critical  I = Important  N = Normal |  |
| Message Subject | Alphanumeric | 100 |  |  |
| Message Template ID | Numeric | 5 |  |  |
| Message Triggering Event | Numeric | 2 | 1 = Change of Trading State  2 = Alert before Trading State Change  3 = Change of Underlying State  4 = Change of Instrument/Combo  5 = Quote Request  6 = Trigger VCM  7 = End of VCM  8 = Trigger Trading Halt  9 = Trigger AHT Price Limit  10 = Alert of AHT Price Limit  11 = Error Trade  13 = Trigger Trading Halt During No Resumption Period  14 = Trading Resumption  15 = Trading Halt Remaining in Effect |  |
| MIC | Alphanumeric | 8 |  |  |
| Min Time Spread | Numeric | 2 | 1 – 12 |  |
| Modifier | Numeric | 3 | 1 – 255 |  |
| Monitoring Scope | Numeric | 2 | 0 = All  1 = Reference futures only |  |
| Month Delta | Numeric | 2 | 0 – 11 |  |
| Month Selection | Numeric | 2 | 1 = All  2 = Even  3 = Odd  4 = Quarterly  5 = Half-yearly  6 = Yearly  14 = Quarterly (Skip Spot/Spot-Next Month) |  |
| Name Standard Date Format | Numeric | 2 | 1 = Year (YYYY)  2 = Year (YY)  3 = Year (Y)  4 = Month Code  5 = Month Number (NN)  6 = Month Name (MMM)  7 = Date (DD)  8 = Week Number (WW) |  |
| Name Standard ID | Numeric | 5 |  |  |
| Name Standard Type | Char |  | O = Options  U = Futures  C = Combo |  |
| Non Trading Days ID | Numeric | 5 |  |  |
| Notification ID | Numeric | 5 |  |  |
| Num Alert | Numeric | 4 |  |  |
| Num Characters | Numeric | 4 |  |  |
| Num Failed Attempts | Numeric | 4 |  |  |
| Num Instrument | Numeric | 5 |  |  |
| Num Legs | Numeric | 4 |  |  |
| Num Missing Heartbeat | Numeric | 4 |  |  |
| Num Notification ID | Numeric | 5 |  |  |
| Num Param | Numeric | 5 |  |  |
| Num Quote Entries | Numeric | 3 |  |  |
| Num Risk Group | Numeric | 5 |  |  |
| Num Session | Numeric | 5 |  |  |
| Num Shares | Decimal | 12 |  | With 6 implied decimal places |
| Num Ticks | Numeric | 5 |  |  |
| Num Tradable | Numeric | 5 |  |  |
| Num Trader ID | Numeric | 5 |  |  |
| Num User | Numeric | 5 |  |  |
| Options Style | Char |  | A = American E = European S = Asian B = Bermudan I = Knock-in O = Knock-out N = Binary R = Ratchet |  |
| Options Type | Char |  | C = Call P = Put |  |
| Options Variant | Char |  | N = Normal C = Cap F = Floor |  |
| Order ID | Numeric | 20 |  |  |
| Order Rate Limit | Numeric | 15 | 0 – 922337203685477 |  |
| Order State | Numeric | 2 |  |  |
| Order Type | Numeric | 2 | 1 = Limit Order  2 = Market Order  3 = Market To Limit Order  9 = Single Quote  10 = Mass Quote |  |
| Order Version Number | Numeric | 20 |  |  |
| Participant ID | Alphanumeric | 5 |  |  |
| Participant User Role ID | Numeric | 5 |  |  |
| Partition ID | Numeric | 2 | 1 – 99 |  |
| Password | Alphanumeric | 512 |  |  |
| Password Expiry Alert | Numeric | 2 | 0 – 99 | Advance alert on password expiry, specified in days. |
| Password Expiry Inactivity Handling | Numeric | 2 | 0 - No Action  1 - Lock Account  2 - Force Change Password |  |
| Password Length | Numeric | 3 | 1 – 24 |  |
| Password Min Characters | Numeric | 2 | 0 – 24 |  |
| Password Policy ID | Numeric | 2 | 1 – 99 |  |
| Password Policy Type | Char |  | I = Internal  E = External  S = System (development use ONLY) |  |
| Password Policy Name | Alphanumeric | 20 |  |  |
| Password Reuse Cycle | Numeric | 2 | 0 = any password can be reused,  1 = the most recent password can’t be reused;  <and so on> | Number of Historical Passwords that can’t be reused. |
| Password Salt | Alphanumeric | 24 |  | Set and used by the System for the reasons associated with password cryptography |
| Password Update Count | Numeric | 2 |  | Count for password policy  Must reset to 0 when password changed by Admin / Housekeeping |
| Password Validity Period | Numeric | 3 | 1 – 999 | Password expiry period in days |
| PDF File Name | Alphanumeric | 128 |  |  |
| Permission ID | Numeric | 20 |  |  |
| Permission Item Param | Alphanumeric | 10 |  |  |
| Permission Item Type | Alphanumeric | 10 |  |  |
| Permission Item Value | Alphanumeric | 1024 |  |  |
| Position Limit ID | Numeric | 5 |  |  |
| Position Effect | Char |  | O = Open  C - Close |  |
| Pre Launch Days | Numeric | 2 | 0 – 31 |  |
| Price Data Option | Numeric | 2 | 1 = Last traded price  2 = Previous day’s settlement price  3 - Reference price of the nearest earlier contract month  4 = Spot month last traded price + Previous day’s rollover spread  5 = Spot month last traded price + Expired spot month spread  6 = Last traded price of corresponding instrument  7 = Spot month last traded price + Previous day’s rollover spread of corresponding instrument |  |
| Price Limit Alert Rule ID | Numeric | 5 |  |  |
| Price Limit ID | Numeric | 5 |  |  |
| Price Limit Param ID | Numeric | 5 |  |  |
| Price Limit Rule ID | Numeric | 5 |  |  |
| Price Quotation Factor | Decimal | 10 |  |  |
| Price Source | Numeric | 2 | 1 = Opening Price 2 = Prev Trading Session Last Traded Price 3 = Calculated Price |  |
| Price Tick ID | Numeric | 5 |  |  |
| Price Tick Limit ID | Numeric | 5 |  |  |
| Price Type | Numeric | 2 | 1 = Settlement Price  2 = Last Traded Price of current Trading Date |  |
| Product Level | Char |  | M = Market  T = Instrument Type  t = Combo Type  C = Instrument Class  c = Combo Class |  |
| PTRM Parameter Name | Alphanumeric | 50 |  |  |
| Quantity Limit | Numeric | 19 |  |  |
| Quote Entry ID | Numeric | 3 | 1 – 250 |  |
| Range Method | Char |  | P = Percentage  S = Steps |  |
| Range Step | Numeric | 5 |  |  |
| Ratio | Numeric | 5 |  |  |
| Record Status | Char |  | A = Active  D = Delete |  |
| Ref Num | Numeric | 19 |  |  |
| Ref Price Source ID | Numeric | 2 | 1 – 99 |  |
| Regional Calendar ID | Numeric | 5 |  |  |
| Regional Calendar Name | Alphanumeric | 255 |  |  |
| Regional Calendar Type | Char | 1 | E = Exchange Trading  F = Financial Centers |  |
| Remarks | Alphanumeric | 512 |  |  |
| Request Sequence Numer | Numeric | 10 | 0 – 922337203685477 |  |
| Report Group | Char |  | D = Daily Market Report  W = Weekly Quotation Report  M = Instrument Maintenance Report Type  S = SMP Participant Exclusion List |  |
| Report Group ID | Char | 5 |  |  |
| Report Group List ID | Numeric | 5 |  |  |
| Report Header | Alphanumeric | 32 |  |  |
| Report ID | Numeric | 5 |  |  |
| Report Name | Alphanumeric | 40 |  |  |
| Report Type ID | Numeric | 2 | 1 = Day Reports - Futures with AHT  2 = Day Reports - Index Options with AHT  3 = Day Reports - TMC with AHT  4 = Night Reports - Futures with AHT  5 = Night Reports - Index Options with AHT  6 = Night Reports - TMC with AHT  7 = Stock Futures Reports  8 = Index Futures Reports  9 = Stock Options Reports  10 = Index & Currency Options Reports  11 = Flexible Index Options Reports  12 = TMC Reports  13 = Weekly Quotation Report  14 = HKFE Options Inst. Maintenance Report  15 = SEHK Options Inst. Maintenance Report  16 = SMP Participant Exclusion List |  |
| Report Type Name | Alphanumeric | 32 |  |  |
| Retry Count | Numeric | 5 |  |  |
| Risk Exposure Limit | Numeric | 15 | 0 – 922337203685477 |  |
| Risk Group ID | Alphanumeric | 32 |  |  |
| Rule Type | Numeric | 2 | 1 = Monthly Trade Day Rule  2 = Monthly Calendar Day Rule  3 = Monthly Weekday Rule  4 = Weekday Rule  5 = Weekly Trade Day Rule  6 = Delta Trade Day Rule  7 = Delta Trade Day On Holiday Rule  8 = Delta Calendar Day Rule  9 = Using Regional Calendar Rule  10 = Current Day Rule |  |
| Security ID | Alphanumeric | 32 |  |  |
| SEDOL | Alphanumeric | 7 |  |  |
| Seq | Numeric | 20 |  |  |
| Seq Key | Alphanumeric | 24 |  |  |
| Session Usage | Char |  | D = Direct Access U = UI Access |  |
| SFTP File Name | Alphanumeric | 254 |  |  |
| Short Name | Alphanumeric | 15 |  |  |
| Side | Numeric | 2 | 0 = Buy  1 = Sell |  |
| Side Binary | Numeric | 2 | 1 = Buy  2 = Sell |  |
| Side Char | Char |  | B = Buy S = Sell |  |
| Signon Count | Numeric | 10 |  |  |
| Site ID | Char |  | P = Primary  S = Secondary |  |
| SMP ID | Numeric | 9 |  |  |
| SMP ID List ID | Numeric | 5 |  |  |
| SMP ID Status | Char |  | A = Active  D = Deleted |  |
| SMP Instruction | Char |  | A = Cancel aggressive  P = Cancel passive |  |
| SMP Request Action | Char |  | C - Create SMP ID  T - Terminate SMP ID  S - Share SMP ID  R - Remove SMP ID Sharing |  |
| SMP Request Code | Alphanumeric | 10 |  |  |
| SMP Request ID | Numeric | 10 |  |  |
| SMP Request Status | Char |  | N - New  R - Ready to Submit  S - Submitted  X - Expired  F - Fulfilled  J - Rejected by HKEX  E - Error  I - Received  P - Pending Reject |  |
| SMP Request Type | Char |  | R - Request  C - Consent |  |
| Source Type | Char |  | I = Instrument Class  U = Underlying |  |
| Special Trading Days ID | Numeric | 5 |  |  |
| Status | Char |  | A = Active S = Suspended  D = Delisted |  |
| Strike Price Group | Alphanumeric | 32 |  |  |
| Strike Price Range ID | Numeric | 5 |  |  |
| Strike Price Ref ID | Numeric | 5 |  |  |
| Strike Price Table ID | Numeric | 5 |  |  |
| Sub Partition ID | Numeric | 2 | 1 – 99 |  |
| System State | Numeric | 2 | 1 = SOD  2 = Normal Processing  9 = EOD |  |
| Table Name | Alphanumeric | 64 |  |  |
| TIF | Numeric | 2 | 0 = Day  1 = GTC  3 = FAK  4 = FOK 6 = GTD  9 = At Crossing |  |
| Time Interval Second | Numeric | 5 |  |  |
| Time Interval Minute | Numeric | 5 |  |  |
| Time Spread Level | Numeric | 2 |  |  |
| Timetable ID | Numeric | 5 |  |  |
| Timetable Type | Char |  | F = Full Day Timetable  H = Half Day Timetable |  |
| TMC Expiration Period | Numeric | 2 | 1 = 1 Day  2 = 1 Week  3 = 2 Weeks  4 = 4 Weeks |  |
| TMC Strategy ID | Numeric | 5 |  |  |
| TMC Strategy Leg Condition | Numeric | 2 | 0 = Any  1 = Equal to Leg n 2 = Higher than Leg n 3 = Lower than Leg n 4 = Not equal to Leg n  5 = 2x Leg n |  |
| TMC Strategy List ID | Numeric | 5 |  |  |
| TMC Strategy Name | Alphanumeric | 32 |  |  |
| TPS | Numeric | 4 | 0 – 9999 |  |
| Tradable ID | Alphanumeric | 40 |  |  |
| Tradable List ID | Numeric | 5 |  |  |
| Trader ID | Alphanumeric | 11 |  |  |
| Trading Day Option | Numeric | 2 | 1 = Normal  2 = Last Trading Day  3 = Last Trading Day + 1 |  |
| Trading Day Type | Char |  | N = Non Trading Day T = Trading Day |  |
| Trading Days | Numeric | 5 |  | Bitmask to represent available trading days  1 - Mon  10 - Tue  100 - Wed  1000 - Thu  10000 - Fri  100000 - Sat  1000000 - Sun  For Mon to Fri, value = 31 |
| Trading Right ID | Numeric | 5 |  |  |
| Trading Session ID | Numeric | 2 | 1 = Morning 2 = Afternoon 3 = Day 4 = AHT (After Hours) |  |
| Trading State ID | Numeric | 5 |  |  |
| Trading State Name | Alphanumeric | 20 |  |  |
| Trading State Type | Numeric | 2 | 0 = SOD (a technical trading state)  1 = PREMKTACT  2 = PREOPEN  3 = PREOPENALLOC  4 = OPENALLOC  5 = UNCROSS  6 = OPEN  7 = PAUSE  8 = INTERVENTION (a technical trading state)  9 = DAYEND (a technical trading state) |  |
| Transition Mode | Numeric | 2 | 0 = Automatic 1 = Manual |  |
| TX Action | Char |  | A = Add  U = Update  D = Delete  W = Withdraw |  |
| TX ID | Alphanumeric | 36 |  |  |
| TX Identifier | Alphanumeric | 100 |  |  |
| TX Request ID | Numeric | 20 |  |  |
| TX Source | Char |  | A = Admin UI  T = Trading UI |  |
| TX Status | Char |  | P = Pending Approval  A = Approved  R = Rejected  F = Failed (for approval) |  |
| TX Type | Alphanumeric | 128 |  |  |
| Type Of Participant User | Char |  | D = Direct access (trading)  T = Trading GUI  E = PTRM GUI (trading unit)  C = PTRM GUI (risk limit manager) |  |
| UI Preference Name | Alphanumeric | 64 |  |  |
| UI Preference Value | Alphanumeric | 4194304 |  |  |
| UI System Preference Group ID | Numeric | 5 |  |  |
| UI System Preference ID | Numeric | 5 |  |  |
| UI User Preference Group ID | Numeric | 5 |  |  |
| UI User Preference ID | Numeric | 5 |  |  |
| UI User Role ID | Alphanumeric | 32 |  |  |
| UI User Role Type | Numeric | 2 | 1 = Admin  2 = Non-Admin |  |
| Underlying Code | Numeric | 10 |  |  |
| Underlying ID | Alphanumeric | 6 |  |  |
| Underlying Issuer | Alphanumeric | 6 |  |  |
| Underlying Type | Char |  | S = Stock C = Currency I = Fixed Income E = Power/Energy A = Commodity M = Metal |  |
| Until Days to LTD | Numeric | 2 | 0 – 31 |  |
| Update Type | Char |  | E = External  M = Manual  S = System (housekeeping) |  |
| URL | Alphanumeric | 254 |  |  |
| User Group ID | Alphanumeric | 100 |  |  |
| User ID | Numeric | 10 |  |  |
| User List ID | Numeric | 5 |  |  |
| User Name | Alphanumeric | 120 |  |  |
| User Type | Numeric | 2 | 1 = Admin  2 = Non-Admin |  |
| VCM ID | Numeric | 5 |  |  |
| VCM Param ID | Numeric | 5 |  |  |
| Week Number | Numeric | 2 |  |  |
| Weekday | Numeric | 2 | 1 = Monday  2 = Tuesday  3 = Wednesday  4 = Thursday  5 = Friday  6 = Saturday  7 = Sunday |  |
