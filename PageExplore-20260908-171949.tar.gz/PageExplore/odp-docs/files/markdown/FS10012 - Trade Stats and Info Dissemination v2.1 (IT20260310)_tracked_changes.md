TITLE:

**FUNCTIONAL SPECIFICATION**

***ODP-T***

***FS10012 - Trading Statistics and Information Dissemination***

AUTHOR : *IT/Markets Systems*  DATE : *24 Mar 2025*

LAST REVIEW *Derivatives Trading Business Operations* DATE : *28 Feb 2025*

**CONTENTS**

[1. Document Control 3](#__RefHeading___Toc183195836)

[1.1. Change History 3](#__RefHeading___Toc183195837)

[1.2. Document Cross-referenced 3](#__RefHeading___Toc183195838)

[1.3. Abbreviation 3](#__RefHeading___Toc183195839)

[1.4. Distribution List 3](#__RefHeading___Toc183195840)

[2. Introduction 4](#__RefHeading___Toc183195841)

[3. Trade Statistics 5](#__RefHeading___Toc183195842)

[3.1. Elements of Trade Statistics 5](#__RefHeading___Toc183195843)

[3.2. Qualified Trades for Trade Statistics Element 6](#__RefHeading___Toc183195844)

[3.3. After Hour Trading (AHT) and Trade Statistics 7](#__RefHeading___Toc183195845)

[3.4. Trade Cancellation and Trade Statistics 7](#__RefHeading___Toc183195846)

[3.5. Trade Adjustment and Trade Statistics 8](#__RefHeading___Toc183195847)

[3.6. Exchange Internal On-Behalf Enter Trade and Trade Statistics 8](#__RefHeading___Toc183195848)

# Document Control

## Change History

|  |  |  |  |
| --- | --- | --- | --- |
| Version  Number | Issue Date | Author | Abstract |
| V1.0 | 31-May-2024 | Jason Lai | Initial Version |
| V2.0 | 21-Nov-2024 | IT/Markets Systems | Repurposed to address trade statistics |
| V2.1 | 24-Mar-2025 | IT/Markets Systems | Updated according to Functional Specification Checklist |

## Document Cross-referenced

|  |  |  |
| --- | --- | --- |
| # | Document | Version |
| 1 | BRD\_DT\_0003 BRS Order Book Execution Management | 20250121 |
| 2 | BRD\_DT\_0007 ODP - NewFunctionRequest - Error Trade | 20250121 |
| 3 | BRD\_DT\_0008 ODP - NewFunctionRequest - Block Trade Facility | 20241119 |
| 4 | BRD\_DT\_0016 ODP - NewFunctionRequest - Trade Cancellation and Adjustment | 20250108 |
| 5 | BRD\_DT\_0025 NEW WISH 005 Operation Enhancement Trade Information | 20250124 |
| 5 | FS10001 - Trading Timetable | 27 Dec 2024 |
| 6 | FS10009 - Error Trade, Trade Cancellation and Adjustment | 24 Mar 2025 |

## Abbreviation

|  |  |
| --- | --- |
| AHT | After Hours Trading |
| TMC | Tailor-Made Combination |
| RHT | Regular Hour Trading |
| LET | Large-Scale Error Trade |
|  |  |

|  |  |  |
| --- | --- | --- |
|  |  |  |
|  |  |  |
|  |  |  |

Introduction

**#FS10012\_S0020\_00100**

The trading system carries and disseminates trade statistics and information (abbreviated as Trade Statistics in this document) which includes Open, High, Low, Last Price, Last Quantity, Turnover and Block Trade Turnover. These statistics are automatically updated when trades happen in the trading system. The trading system also updates the trade statistics and information accordingly when trade cancellations are handled by the trading system[[1]](#footnote-2).

Due to the complexity of handling trade cancellations, trade statistics and information are calculated by an auxiliary service within ODP-T but outside of the central order book processing.

This document intends to cover the logics used to derive the trade statistics and information.

# Trade Statistics

## Elements of Trade Statistics

#FS10012\_S0030\_00100

|  |  |
| --- | --- |
| Trade Statistics Element | Description |
| Traded High | The highest traded price transacted in the session. This is updated when a qualified trade[[2]](#footnote-3) has a price higher than the current value, or it is the first qualified trade in the session. |
| Traded Low | The lowest traded price transacted in the session. This is updated when a qualified trade has a price lower than the current value, or it is the first qualified trade in the session. |
| Open Price | The first traded price in this session. This is updated when the qualified trade is the first qualified trade in the session. |
| Last Traded Price | The latest traded price in the session. This is updated when a qualified trade has the latest timestamp in the current session. |
| Last Traded Quantity | The quantity of the latest trade in the session. This is updated when a qualified trade has the latest timestamp in the current session. |
| Total Turnover | The sum of all quantities for qualified trades in the session. This value starts from zero in the beginning of a session. Each qualified trade contributes to this value. |
| Total Block Trade Turnover | The sum of all block trade quantities for qualified trades in the session. This value starts from zero in the beginning of a session. Each qualified trade contributes to this value. |

## Qualified Trades for Trade Statistics Element

The following table describes the qualified trade statistics element for each trade type:

| Trade Type | Outright Instrument / Combo / TMC | | Trade Statistics Element Qualified for Consideration | | | | | | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Traded High | Traded Low | Open Price | Last Traded Price | Last Traded Quantity | Total Turnover | Total Block Trade Turnover |
| Auction Matching | Outright Instrument | |  |  |  |  | [[3]](#footnote-4) |  |  |
| Combo / TMC[[4]](#footnote-5) | | N/A | | | | | | |
| Explicit vs Explicit Order Matching | Outright Instrument | |  |  |  |  |  |  |  |
| Combo | Combo |  |  |  |  |  |  |  |
| Legs |  |  |  |  |  |  |  |
| TMC | TMC |  |  |  |  |  |  |  |
| Legs |  |  |  |  |  |  |  |
| Implied Matching[[5]](#footnote-6) | Outright Instrument Legs | |  |  |  |  |  |  |  |
| Combo | |  |  |  |  |  |  |  |
| Block Trade | Outright Instrument | |  |  |  |  |  |  |  |
| Combo / TMC | Combo / TMC |  |  |  |  |  |  |  |
| Legs |  |  |  |  |  |  |  |
| Exchange Internal On-Behalf Enter Trade错误: 引用源未找到 | Outright Instrument | | [[6]](#footnote-7) |  |  |  |  |  |  |
| Combo / TMC | | N/A | N/A | N/A | N/A | N/A | N/A | N/A |

## After Hour Trading (AHT) and Trade Statistics

**#FS10012\_S0030\_00300**

The trading system stores two different sets of statistics. One set for Regular Hours Trading (RHT) and another set for After Hour Trading (AHT). The trading system determines which set of statistics to update based on the trading session in which the trade is matched. Following table shows the set of statistics to be updated for different Trading Session defined in FS10001 - Trading Timetable Section 5.

| Trading Session | Trade Statistics Area | |
| --- | --- | --- |
| RHT | AHT |
| Morning |  |  |
| Afternoon |  |  |
| Day |  |  |
| AHT |  |  |

## Trade Cancellation and Trade Statistics

**#FS10012\_S0030\_00400**

For trade cancellations (including those due to Error Trade错误: 引用源未找到 and Trade Cancellation错误: 引用源未找到 initiated by DT Operations), the trading system adjusts the trade statistics when the trade cancellation is finalized in the trading system. The system adjusts the area in which the cancelled trade belongs to. (i.e. If the cancelled trade is an RHT trade, even if the trade is cancelled in AHT session, the trade statistics update due to the trade cancellation will be in the RHT area.)

For each cancelled trade, the trading system identifies the set of qualified trade statistics elements based on the trade type of the cancelled trade (refer to Section 3.2.). The trading system re-evaluates each of the corresponding statistics elements in the set based on the logic below:

| Trade Statistic Element | Trade Cancellation Logic |
| --- | --- |
| Traded High | If the cancelled trade is the current Traded High, identify the valid qualified trade with the highest price in the corresponding trading session of the cancelled trade. If found, set the value to the corresponding traded price. If no such trade is found, set the value to *<No Value>*. |
| Traded Low | If the cancelled trade is the current Traded Low, identify the valid qualified trade with the lowest price in the corresponding trading session of the cancelled trade. If found, set the value to the corresponding traded price. If no such trade is found, set the value to *<No Value>*. |
| Open Price | If the cancelled trade is the current open price, identify the valid qualified trade with the oldest timestamp in the corresponding trading session of the cancelled trade. If found, set the value to the corresponding traded price. If no such trade is found, set the value to *<No Value>*. |
| Last Traded Price | If the cancelled trade has the latest timestamp in the corresponding trading session, find the latest valid qualified trade in the corresponding trading session of the cancelled trade. If found, set the value to the corresponding traded price. If no such trade is found, set the value to *<No Value>*. |
| Last Traded Quantity | If the cancelled trade has the latest timestamp in the corresponding trading session, find the latest valid qualified trade in the corresponding trading session of the cancelled trade. If found, set the value to the corresponding traded quantity. If no such trade is found, set the value to *<No Value>*. |
| Total Turnover | The quantity of the cancelled trade would be deducted from the Total Turnover in the corresponding trading session. |
| Total Block Trade Turnover | The quantity of the cancelled trade would be deducted from the Total Block Trade Turnover in the corresponding trading session. |

## Trade Adjustment and Trade Statistics

Price Adjustment[[7]](#footnote-8) allows price adjustment of combo legs without affecting quantities for explicit Combo-vs-explicit Combo trades. As specified in Section 3.2., the leg prices are not qualified to update price related statistics (i.e. Traded High, Traded Low, Open Price and Last Price) and thus it will not affect trade statistics.

## Exchange Internal On-Behalf Enter Trade[[8]](#footnote-9) and Trade Statistics

The Exchange Internal On-Behalf Enter Trade enables DT Operations to submit a trade to the trading system and at the same time select the trade statistics elements the trade is qualified for. The logical relationship across statistic elements is not validated given the flexibility requested.

1. Refer to FS10009 - Error Trade, Trade Cancellation and Adjustment for details [↑](#footnote-ref-2)
2. To determine whether a trade is a qualified trade, one may refer to section 3.2.. [↑](#footnote-ref-3)
3. The Last Traded Quantity for Auction Matching refers to each trade happens in the auction matching. Not the total uncrossed quantity during the auction matching. [↑](#footnote-ref-4)
4. Combo/TMC do not support Pre-Open auction matching [↑](#footnote-ref-5)
5. Includes both Implied-IN and Implied-OUT. Regardless of Explicit-vs-Implied and Implied-vs-Implied. TMC does not have implied processing. [↑](#footnote-ref-6)
6. Denotes optional as specified when the trade is entered into the system by the DT Operations. [↑](#footnote-ref-7)
7. Refer to FS10009 - Error Trade, Trade Cancellation and Adjustment for details [↑](#footnote-ref-8)
8. Refer to BRS Order Book Execution Management Section 3.1.3.10 [↑](#footnote-ref-9)
