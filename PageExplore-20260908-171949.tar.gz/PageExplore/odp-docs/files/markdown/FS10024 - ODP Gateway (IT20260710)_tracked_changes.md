TITLE:

**FUNCTIONAL SPECIFICATION**

***ODP-T***

*FS10024 - ODP Gateway*

AUTHOR : *IT/Markets Systems* DATE : *17 Apr 2025*

LAST REVIEW : Derivatives Trading Business Operations DATE : *10 Jul 2026*

**CONTENTS**

[1. Document Control 3](#__RefHeading___Toc193702994)

[1.1. Change History 3](#__RefHeading___Toc193702995)

[1.2. Document Cross-referenced 3](#__RefHeading___Toc193702996)

[1.3. Abbreviation 3](#__RefHeading___Toc193702997)

[1.4. Distribution List 3](#__RefHeading___Toc193702998)

[2. Introduction 5](#__RefHeading___Toc193702999)

[3. Session Management 6](#__RefHeading___Toc193703000)

[4. Lookup Service 6](#__RefHeading___Toc193703001)

[5. Protocol, Connectivity & Infrastructure 6](#__RefHeading___Toc193703002)

[6. Gateway Features 7](#__RefHeading___Toc193703003)

[6.1. Password 7](#__RefHeading___Toc193703004)

[6.2. Message Throttling 7](#__RefHeading___Toc193703005)

[6.3. Dissemination of Reference Data 8](#__RefHeading___Toc193703006)

[6.4. IP address 8](#__RefHeading___Toc193703007)

[6.5. Failover and restart 8](#__RefHeading___Toc193703008)

[6.6. Cancel on Disconnect (COD) 8](#__RefHeading___Toc193703009)

[6.7. Monitoring 9](#__RefHeading___Toc193703010)

[6.8. Kill Switch 9](#__RefHeading___Toc193703011)

[6.9. Gateway Scalability and Topology 9](#__RefHeading___Toc193703012)

[6.10. Hardware Replacement 10](#__RefHeading___Toc193703013)

[6.11. Timestamp 10](#__RefHeading___Toc193703014)

[7. Supported Business Function 10](#__RefHeading___Toc193703015)

[8. System Parameter 11](#__RefHeading___Toc193703016)

[8.1. Maximum number of CompID 11](#__RefHeading___Toc193703017)

[8.2. Maximum number of Throttle 11](#__RefHeading___Toc193703018)

[9. Safety Features 11](#__RefHeading___Toc193703019)

[9.1. Message Retransmission Control 11](#__RefHeading___Toc193703020)

[10. Drop Copy Functionality 11](#__RefHeading___Toc193703021)

[10.1. Drop Copy Gateway 11](#__RefHeading___Toc193703022)

# Document Control

## Change History

|  |  |  |  |
| --- | --- | --- | --- |
| Version  Number | Issue Date | Author | Abstract |
| V0.1 | 20250127 | Robert Lau | Initial version |
| V0.5 | 20250228 | Robert Lau | Revise according to FS10024 Review Log comments and Traceability Mapping discussions. |
| V1.0 | 20250324 | Robert Lau | Update Cover Page, Table of Contents table, Document Cross-referenced table. |
| V1.1 | 20250417 | Jessica Chang | Update FS Tag number for Traceability mapping facilitation. |
| V1.2 | 20260113 | Robert Lau | Refine/clarify the document. |
| V1.3 | 20260710 | Robert Lau | Refine/clarify the document. |

## Document Cross-referenced

|  |  |  |
| --- | --- | --- |
| # | Document | Version |
| 1 | BRD0002 BRS Order Management | 20250109 |
| 2 | BRD0003 BRS Order Book Execution Management | 20241219 |
| 3 | BRD0006 BRS Drop Copy | 20240423 |
| 4 | BRD0022 NEW WISH 002 GATEWAY | 20240429 |
| 5 | BRD0027 NEW WISH 007 Connectivity Protocol | 20240628 |
| 6 | BRD0033 NEW WISH 013 Data distribution & transmission | 20240628 |
| 7 | BRD0039 New Wish 019 Time stamp | 20240628 |
| 8 | BRD0046 BRS SLA | 20241017 |
| 9 | BRD0049 BRS ODP Online | 20250109 |
| 10 | BRD0050 BRS\_PDMPA functions | 20250213 |
| 11 | BRD0054 Client Services | 20241230 |
| 12 | FS10002 - Order Management | 20250305 |

## Abbreviation

|  |  |
| --- | --- |
| CGW | Conventional Gateway |
| COD | Cancel on Disconnect |
| CompID | Computer ID (a.k.a. session identifier) |
| DC | Drop Copy |
| E2E | End to End |
| EP | Exchange Participant |
| ME | Matching Engine |
| MMP | Market Maker Protection |
| OBO | On Behalf Of |
| OF | Order Flow |
| OMS | Order Management System |
| PSG | Partition Specific Gateway |

## Distribution List

1. Markets / Derivatives Trading

# Introduction

This document outlines the functional requirements for ODP-T trading and drop copy gateway.

# Session Management

#FS10024\_S0030\_00100

Session management should follow FIX session protocol, and it supports the following session administrative messages and business message reject:

* Logon
* Logout
* Heartbeat
* Test Request
* Resend Request
* Reject
* Sequence Reset
* Business message reject

The message recovery/retransmission would also follow FIX protocol.

# Lookup Service

#FS10024\_S0040\_00100

The gateway provides Lookup Service that allows client system to send Lookup Request to obtain gateway IPs assigned to the client session for gateway connection and logon.

# Protocol, Connectivity & Infrastructure

#FS10024\_S0050\_00100

The gateway provides binary protocol to communicate with the EP.

The gateway will adopt standard TCP/IP point-to-point connection communicate with the EP.

#FS10024\_S0050\_00200

The gateway and ODP-T backend component will have three network infrastructure:

* Production environment, to operate the production.
* Production – like environment, to test/verify system before rollout to production.
* Conforming testing environment, a.k.a. E2E, to provide an environment for EP to verify their OMS.
* Internal operations are separated with external operations

#FS10024\_S0050\_00300

The CGW will connect to multiple (or all) ME partitions. The gateway is able to route the following message to multiple ME partitions:

* Mass cancel
* OBO mass cancel
* Kill switch
* MMP messages
* Block trade messages

The PSG will connect to one specific ME only. All transactions will route to that ME only.

# Gateway Features

## Password

#FS10024\_S0060\_00100

Client has to specify password to logon the gateway. The password shall be encrypted using use a 2048-bit RSA algorithm with OAEP padding mode. The password shall prefix the current time (UTC time).

## Message Throttling

#FS10024\_S0060\_00200

The gateway shall throttle message traffic where each Comp ID is only permitted to submit up to a specified number of business messages per second (MPS). The sawtooth mechanism should be adopted.

The throttle assignment is effective next day.

The message listed in Chapter 7 that will consume the throttle.

The number of throttles per message for all types of messages is 1.

If the number of messages exceeds, depends on the exceedance, the gateway will take following action:

* Assume the transactions per second is N.
* For message 1 – N: the message will be accepted.
* From message from (N + 1) to (Disconnect Throttle): throttle exceeds, the gateway will return business message reject where the text field will carry the time (in millisecond) to next second.
* For message at (Disconnect Throttle + 1): throttle exceeds, the gateway will log out the client by sending a Logout message

The gateway will use the following formula to calculate the Disconnect Throttle:

|  |  |
| --- | --- |
| **Throttle (N)** | **Disconnect Throttle** |
| 1 to 25 | N\* 4 (i.e. 4 times) |
| 26 to 100 | Min (N\*4, 100 + N) |
| Greater than 100 | N \* 2 (i.e. 2 times) |

Example:

|  |  |  |
| --- | --- | --- |
| **Throttle (N)** | **Disconnect Throttle** | **Formula** |
| 3 | 12 | 4 times |
| 10 | 40 | 4 times |
| 25 | 100 | 4 times |
| 26 | 104 | Min (N\*4, 100 + N) |
| 70 | 170 | Min (N\*4, 100 + N) |
| 99 | 199 | Min (N\*4, 100 + N) |
| 100 | 200 | Min (N\*4, 100 + N) |
| 110 | 220 | 2 times |
| 111 | 222 | 2 times |

The following two messages are available for client to obtain the throttle information:

* Party Entitlement Request
* Throttle Entitlement Request

## Dissemination of Reference Data

#FS10024\_S0060\_00300

The gateway will not disseminate reference data to EP. EP may obtain reference data from the market data.

## IP address

#FS10024\_S0060\_00400

Client can only connect to the gateway from a pre-defined IP address list.

The technical limit per list is 5K.

## Failover and restart

#FS10024\_S0060\_00600

Failure on the active gateway should be detected and its standby is able to take over automatically.

#FS10024\_S0060\_00700

In case the server is rebooted suddenly, the gateway can be brought up intra-day.

## Cancel on Disconnect (COD)

#FS10024\_S0060\_00800

The gateway supports COD. The detailed description of COD can be found in FS10002.

It is noted that the failure in gateway will not trigger COD.

## Monitoring

#FS10024\_S0060\_00900

The gateway can provide real-time stat figures.

* #FS10024\_S0060\_01000 The number of connections.
* #FS10024\_S0060\_01100 The number of throttle breach counts.
* #FS10024\_S0060\_01200 Alert if the number of connection counts is different to the previous average number of connection counts on the same interval.
* #FS10024\_S0060\_01300 Alert if the following exceeds pre-defined threshold:
* CPU
* Memory
* Disk
* #FS10024\_S0060\_01400 Instant turnaround latency
* #FS10024\_S0060\_01500 Provide connections details and stats on the following:
* #FS10024\_S0060\_01600 Per gateway instance level
* #FS10024\_S0060\_01700 Per client and per EP level.

#FS10024\_S0060\_01800 Above stats are able to export and print.

Note:

#FS10024\_S0060\_01810

A monitoring dashboard will be provided for the above stats/events. A single sign-on will be used for dashboard logon.

## Kill Switch

#FS10024\_S0060\_01900

The gateway can support kill switch function.

Kill switch is an emergency operation that can be used by the EP to:

* cancel all orders/quotes/unaccepted block trades; and
* disallow submission of all business messages (e.g. orders, quotes, block trades, error claim, etc, also including the this kill switch message).

Note:

* Unaccepted block trades will only be cancelled if it is to kill switch all sessions, i.e. the Kill Switch Scope is set to 4 (All sessions of this EP, including this requesting session).

The client can submit kill switch request to perform kill switch for:

* this session (who is entering this request)
* another session that belongs to the same EP
* all sessions (including this session) that belong to the same EP.

The client can resume the kill switch for other sessions.

If all clients are kill switched, no client can perform the resumption of kill switch. In this case, participant may contact HKEX if further follow-up actions are requirement.

Once triggered, the kill switch will remain in effect only for the current trading day, i.e. will not carry forward to next day.

No logout is required for the sessions that are being kill switch.

## Gateway Scalability and Topology

#FS10024\_S0060\_02000

The gateway supports horizontally scalable.

#FS10024\_S0060\_02100

The gateway supports partition specific gateway (PSG) and low frequency gateway or conventional gateway (CGW).

PSG will connect to specific ME only; while the CGW will connect to multiple (or all) MEs.

The number of PSG per ME is configurable.

## Hardware Replacement

#FS10024\_S0060\_02200

If there is hardware replacement that needs to use other new model, due to performance difference between new and old models, it might need to replace all servers using the new model.

## Timestamp

#FS10024\_S0060\_02300

ODP (backend systems and gateways) will support nanosecond precision for the timestamping.

The timestamp will be captured by the gateway and the matching engine for the in/out transaction as well as other messages like kill switch, MMP parameter update, etc.

# Supported Business Function

#FS10024\_S0070\_00100

The gateway is the connectivity point between HKEX and Exchange Participants for order submission. (Note: EP may also submit orders via ODP Trading UI).

The gateway supports the following business function:

* New Order Single
* Order Amend Request
* Order Cancel Request
* Mass Quote
* Single Quote
* Quote Request
* Quote Public Request
* Mass Cancel Request
* OBO Single Cancel Request
* OBO Mass Cancel Request
* Kill Switch Request
* Two-party Trade Request
* One-party Trade Request
* One-party Trade Cancel Request
* One-party Trade Decline Request
* Error Trade Request
* Error Trade Contra-side Consent Request
* Security Definition Request
* MMP Parameters Update Request
* MMP Parameters Enquiry
* MMP Release Request

#FS10024\_S0070\_00200

In particular, pattern-like matching should be provided in mass cancel and OBO mass cancel.

# System Parameter

## Maximum number of CompID

#FS10024\_S0080\_00100

* Define the max number of CompID for OF client. This parameter is changeable.
* Define the max number of CompID for DC client. This parameter is changeable.

## Maximum number of Throttle

#FS10024\_S0080\_00200

* Define the max throttle rate. This parameter is changeable.

# Safety Features

## Message Retransmission Control

#FS10024\_S0090\_00100

The gateway can serve message retransmission. The retransmission rate is governed by:

* Per session max
* System-wise limit

With the following formula:

Effective rate = Min[Per session max, System-wise limit/N]

Where N is the number of concurrent recovery sessions

# Drop Copy Functionality

## Drop Copy Gateway

#FS10024\_S0010\_00100

The dedicated gateway will support the drop copy feed to the EP.

This drop copy gateway will support binary protocol.

The session management and failover logic are the same as the above sections.

#FS10024\_S0010\_00200

Drop copy clients can be configured to subscribe to some or all of trading clients’s messages.
