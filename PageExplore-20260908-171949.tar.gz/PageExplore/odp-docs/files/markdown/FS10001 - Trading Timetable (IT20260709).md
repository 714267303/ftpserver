TITLE:

**FUNCTIONAL SPECIFICATION**

***ODP-TR***

*FS10001 Trading Timetable*

AUTHOR : *IT/Markets Systems*  DATE : *9 Jul 2026*

LAST REVIEW *Derivatives Trading Business Operations* DATE : *28 Feb 2025*

**CONTENTS**

[1. Document Control 4](#__RefHeading___Toc234484161)

[1.1. Change History 4](#__RefHeading___Toc234484162)

[1.2. Document Cross-referenced 4](#__RefHeading___Toc234484163)

[1.3. Abbreviation 5](#__RefHeading___Toc234484164)

[2. Introduction 6](#__RefHeading___Toc234484165)

[3. Trading Calendar 8](#__RefHeading___Toc234484166)

[3.1. Normal Trading Day 8](#__RefHeading___Toc234484167)

[3.2. Non-Trading Days 8](#__RefHeading___Toc234484168)

[3.3. Special Trading Days 8](#__RefHeading___Toc234484169)

[3.4. Examples 8](#__RefHeading___Toc234484170)

[4. Trading Timetable 10](#__RefHeading___Toc234484171)

[4.1. Trading Hours 10](#__RefHeading___Toc234484172)

[4.2. Operation Mode 10](#__RefHeading___Toc234484173)

[4.3. Trading Timetable Type 11](#__RefHeading___Toc234484174)

[5. Trading Session 12](#__RefHeading___Toc234484175)

[5.1. Trading Schedule 13](#__RefHeading___Toc234484176)

[5.2. Examples 13](#__RefHeading___Toc234484177)

[6. Trading State 15](#__RefHeading___Toc234484178)

[6.1. Technical Trading States 15](#__RefHeading___Toc234484179)

[6.2. Business Trading States 16](#__RefHeading___Toc234484180)

[6.2.1. Trading State Type 17](#__RefHeading___Toc234484181)

[6.2.2. Allowed Trading Functions 18](#__RefHeading___Toc234484182)

[6.2.3. Allowed Order Types & Validities 19](#__RefHeading___Toc234484183)

[6.2.4. Applicable Background Functions and Supervision 20](#__RefHeading___Toc234484184)

[6.2.5. Examples 21](#__RefHeading___Toc234484185)

[6.3. Trading State Publication 22](#__RefHeading___Toc234484186)

[6.4. Combo Trading State 23](#__RefHeading___Toc234484187)

[6.4.1. Examples 23](#__RefHeading___Toc234484188)

[7. Intraday Trading Timetable Changes 25](#__RefHeading___Toc234484189)

[7.1. Trading State Transition Mode 25](#__RefHeading___Toc234484190)

[7.2. Ad-hoc Change to Trading Timetable 25](#__RefHeading___Toc234484191)

[7.3. Intraday Trading Timetable Import 27](#__RefHeading___Toc234484192)

[7.4. Trading Pause 27](#__RefHeading___Toc234484193)

[7.5. Early Closing 27](#__RefHeading___Toc234484194)

[7.6. Trading Resumption 28](#__RefHeading___Toc234484195)

# Document Control

## Change History

|  |  |  |  |
| --- | --- | --- | --- |
| Version  Number | Issue Date | Author | Abstract |
| 0.1 | 21 July 2023 | IT/Markets Systems | Initial Version |
| 0.2 | 24 Aug 2023 | IT/Markets Systems | Revised based on review comments from business users |
| 0.3 | 30 Jan 2024 | IT/Markets Systems | Revised based on review comments from business users |
| 0.4 | 13 May 2024 | IT/Markets Systems | Tagging |
| 0.5 | 29 Oct 2024 | IT/Markets Systems | Revised based on review comments from business users |
| 0.6 | 26 Nov 2024 | IT/Markets Systems | Revised based on review comments from business users |
| 0.7 | 20 Dec 2024 | IT/Markets Systems | Revised based on review comments from business users |
| 0.8 | 27 Dec 2024 | IT/Markets Systems | Revised based on review comments from business users |
| 0.9 | 30 Jul 2025 | IT/Markets Systems | Break PREOPEN into 4 separate business trading states  Updated Allowed Trading Functions and Allowed Order Types & Validity  Revised based on review comments from business users |
| 0.10 | 16 Sep 2025 | IT/Markets Systems | Updated Allowed Order Types & Validity |
| 0.11 | 9 Jan 2026 | IT/Markets Systems | Revised Version |
| 0.12 | 9 Jul 2026 | IT/Markets Systems | Revised Version |

## Document Cross-referenced

|  |  |  |
| --- | --- | --- |
| # | Document | Version |
| 1 | BRD\_DT\_0001 BRS Trading Microstructure | 20241016 |
| 2 | BRD\_DT\_0015 ODP – Trading Session Handling under Exceptional Situation | 20250526 |
| 3 | BRD\_DT\_0021 NEW WISH 001 24HR | 20240430 |
| 3 | BRD\_DT\_0028 NEW WISH 008 Trading Session management | 20240429 |
| 4 | FS10002 – Order Management | 20250512 |
| 5 | FS10003 – Orderbook and Execution Management | 20250324 |
| 6 | FS10004 – Price Supervision | 20250122 |
| 7 | FS10010 – Product Structure | 20250324 |
| 8 | FS10011 – Participant Structure | 20250124 |
| 9 | FS10023 – Instrument and Combo Generation | 20250324 |

## Abbreviation

|  |  |
| --- | --- |
| AHT | After Hours Trading |
| COP | Calculated Opening Price |
| FAK | Fill And Kill |
| FOK | Fill Or Kill |
| GTC | Good Till Cancel |
| GTD | Good Till Date |
| SOD | Start Of Day |
| VCM | Volatility Control Mechanism |

# Introduction

**#FS10001\_S0020\_00100**

A trading timetable consists of series of trading sessions, where a trading session consists of a time sequenced of trading states. A timetable governs the trading pattern of an order book for a trading day. The timetable dictates when each order book opens and closes for trading, what actions can be submitted by the participants at any point in time and what functions are performed by the trading platform at any point in time.

**#FS10001\_S0020\_00200**

Business Operations are allowed to define a trading timetable and then assign to the following product levels:

1. Market
2. Instrument Type
3. Instrument Class
4. Combo Type
5. Combo Class

A trading timetable must be assigned to market level, while it is optional for instrument type, instrument class, combo type and combo class levels. The timetable assigned to the upper level of product hierarchy is inherited to the lower level by default. If there are timetables attached in different levels, the one in the lowest level will override. As in the example below, all futures instruments belonging to M1FUT inherits the timetable from market level, i.e. M1; while all options instruments belonging to M1CALL and M1PUT inherit the timetable from instrument type level, i.e. M1C and M1P respectively.

![](data:image/x-wmf;base64...)

For combo, if there is no trading timetable explicitly assigned to its combo type and combo class, its trading schedule will be inherited from its first leg.

**#FS10001\_S0020\_00300**

It should be noted that same trading timetable can be assigned to more than one product and at multiple product levels. Once assigned, the system will treat them as an independent timetable during the trading day.

# Trading Calendar

**#FS10001\_S0030\_00100**

Trading calendar defines which trading timetable should be used on a particular trading day. For example, Monday to Friday are normal trading days which operate under a normal trading timetable, New Year’s Eve is a special trading day with half day trading and New Year’s Day is a non-trading day.

## Normal Trading Day

**#FS10001\_S0030\_00200**

Normal trading days is defined by the days of week (Monday to Sunday). It is a market level configuration to decide when a normal trading timetable should be used for trading. For example, a stock futures market can be configured to open for normal trading from Monday to Friday.

A defined trading timetable can be assigned to a specified product level (i.e. Market, Instrument Type or Instrument Class) as the normal trading timetable. The assigned timetable will be used when it is a normal trading day for the market.

## Non-Trading Days

**#FS10001\_S0030\_00300**

Non-trading days is a per market configuration to define a list of days when the market is not open for trading on a normal trading day.

## Special Trading Days

**#FS10001\_S0030\_00400**

Special trading days define a list of days when special trading hours are applicable. Special trading timetable is configured per each special trading day and is allowed to assign to the specified product level. For example, a half day trading timetable is used on Christmas Eve and New Year’s Eva, while another special trading timetable is used for bank holidays in US and UK.

Special trading days override normal trading days at market level. If a particular date is configured as a special trading day but not as a non-trading day at market level, the specified product level will open for trading using the specified trading timetable. If the particular date is configured as a non-trading day at market level, the market will not open for trading and will not follow the special trading timetable.

## Examples

**#FS10001\_S0030\_00500**

Example 1 – Market M1

At market level – M1,

* Normal trading days: Monday to Friday
* Normal trading timetable: M1T
* Special trading days:
  + 27 May 2024 – M1TT (no AHT session)
  + 24 Dec 2024 – M1TH (half day trading)
  + 31 Dec 2024 – M1TH (half day trading)
* Non-trading days:
  + [Hong Kong Public Holiday]

At instrument type level – M1C and M1P

* Normal trading timetable: M1OT
* Special trading days:
  + 27 May 2024 – M1OTT (no AHT session)
  + 24 Dec 2024 – M1OTH (half day trading)
  + 31 Dec 2024 – M1OTH (half day trading)

# Trading Timetable

**#FS10001\_S0040\_00100**

The diagram below shows how a trading timetable is constituted:

![](data:image/x-wmf;base64...)

## Trading Hours

**#FS10001\_S0040\_00200**

A timetable is allowed to span across two calendar dates[[1]](#footnote-2) as illustrated below:

![](data:image/x-wmf;base64...)

The following rules apply during creation or changing of timetable by Business Operations:

* The maximum trading hours for a timetable must not be longer than a technical system parameter - “Max Trading Hours”.
* The start time of the first session must not be earlier than a technical system parameter - “Earliest Trading Start Time”.
* The end time of last session must not be later than a technical system parameter - “Latest Trading End Time”.

## Operation Mode

**#FS10001\_S0040\_00300**

The trading timetable applicable to product levels can operate in two different modes:

* In a normal scenario, a pre-defined timetable will transition through different sessions and states automatically according to the scheduled times.
* In an exceptional scenario, an intra-day override of the trading schedule can be manually applied by creating/cloning a new trading schedule and assign the same to product levels. Such a change will not be persisted to the next trading day.

## Trading Timetable Type

**#FS10001\_S0040\_00400**

There are two types of trading timetable:

* full trading day
* half trading day

There is no special rule applied to restrict the trading timetable setup based on the timetable type. The timetable type is solely used as an indicator for other specific business functions (e.g. instrument and combo generation).

# Trading Session

**#FS10001\_S0050\_00100**

A timetable consists of a series of consecutive trading sessions. There are four defined trading sessions:

* Morning session
* Afternoon session
* Day session
* AHT (after-hours trading) session

Each trading session can be employed within a timetable with the following validations:

* morning session must not be after afternoon/AHT session
* morning, afternoon and day session must not be after AHT session
* day session must not co-occur with morning/afternoon session

This trading session classification/name is used for specific business rules (e.g. VCM reference price and trigger count reset, differentiation of morning, afternoon and AHT session, and adjustment of trading timetable due to contingency scenarios).

Example 1 – Timetable with lunch break and AHT

|  |  |
| --- | --- |
| Start Time | Session |
| 08:45:00 | Morning Session |
| 12:30:00 | Afternoon Session |
| 16:32:00 | AHT Session |

Example 2 – Timetable without lunch break, but with AHT

|  |  |
| --- | --- |
| Start Time | Session |
| 08:35:00 | Day Session |
| 18:32:00 | AHT Session |

Example 3 – Timetable with lunch break and no AHT

|  |  |
| --- | --- |
| Start Time | Session |
| 09:00:00 | Morning Session |
| 12:30:00 | Afternoon Session |

Example 4 – Timetable without lunch break and no AHT

|  |  |
| --- | --- |
| Start Time | Session |
| 08:15:00 | Day Session |

Example 5 – Timetable for half day trading

|  |  |
| --- | --- |
| Start Time | Session |
| 08:45:00 | Day Session |

## Trading Schedule

**#FS10001\_S0050\_00200**

One or more trading states can be configured in a trading session. The start time of each specified trading state must be sequential, the end time of each trading state is effectively the start time of the next. If multiple sessions are employed, the states sequence validation will also be applied to the last state of a session and the first state of the next session.

For each trading state configured in the trading session, the followings are specified:

* Start logical day indicator: start logical day indicator (T-1: previous day, T: current day, T+1: next day)
* Start time: start time of the trading state with the granularity of seconds (specified in local time in system time zone)
* Trading state: business trading state (refer to Section 6.2.)
* Number of alert messages: number of alert messages before the trading state is started
* Alert interval: interval (in number of seconds) between alert messages before the trading state is started

The random interval and VCM offsets specified (refer to Section 6.2.) within a trading state will be validated such that they must be within the time duration of the trading state.

Alert interval is not restricted to be within the previous trading state. Alert messages will not be sent if the random start interval is specified in the trading state.

## Examples

**#FS10001\_S0050\_00300**

Example 1 – Morning session with pre-opening and VCM monitoring

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
| Start logical day indicator | Start time | Trading state name  (Trading state type) | Number of alerts | Alert interval |
| T | 08:45:00 | PREOPEN  (PREOPEN) | 2 | 300 |
| T | 09:09:00 | PREOPENALLOC  (PREOPENALLOC) |  |  |
| T | 09:12:00 | OPENALLOC  (OPENALLOC) |  |  |
| T | 09:14:00 | UNCROSS  (UNCROSS) |  |  |
| T | 09:15:00 | OPEN\_DPL\_VCM\_AM  (OPEN) | 1 | 60 |
| T | 12:00:00 | BREAK  (PAUSE) | 2 | 300 |

Example 2 – Afternoon session with pre-opening and VCM monitoring

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
| Start logical day indicator | Start time | Trading state name  (Trading state type) | Number of alerts | Alert interval |
| T | 12:30:00 | PREOPEN  (PREOPEN) | 1 | 60 |
| T | 12:54:00 | PREOPENALLOC  (PREOPENALLOC) |  |  |
| T | 12:57:00 | OPENALLOC  (OPENALLOC) |  |  |
| T | 12:59:00 | UNCROSS  (UNCROSS) |  |  |
| T | 13:00:00 | OPEN\_DPL\_VCM\_PM  (OPEN) | 1 | 60 |
| T | 16:30:00 | BLK\_TRADE\_ONLY  (OPEN) | 2 | 300 |
| T | 16:45:00 | CLOSE  (PAUSE) | 2 | 300 |

Example 3 – AHT session with pre-market activities

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
| Start logical day indicator | Start time | Trading state name  (Trading state type) | Number of alerts | Alert interval |
| T | 16:47:00 | AHT\_PREMKTACT  (PREMKTACT) | 1 | 60 |
| T | 17:15:00 | OPEN\_PL  (OPEN) | 1 | 60 |
| T+1 | 03:00:00 | AHT\_CLOSE  (PAUSE) | 2 | 300 |
| T+1 | 03:15:00 | DAYEND  (DAYEND) |  |  |

# Trading State

**#FS10001\_S0060\_00100**

A trading state defines the set of trading functions allowed at any point in time, and the background functions which are active in response to the trading functions.

There are two types of trading states:

* Technical trading state: pre-defined in the system
* Business trading state: defined and configured by Business Operations

## Technical Trading States

**#FS10001\_S0060\_00200**

A technical trading state is pre-defined in the system. Below is the description of each technical trading state:

|  |  |
| --- | --- |
| Trading State | Description |
| SOD (Start of Day) | The initial trading state commences before any trading activities for a trading day, and ends when the trading timetable has to transition to the first configured trading state.  Background functions:   * Prepare start of day reference data image * Load start of day reference data * For products open for trading,   + create order book for each tradable (as applicable)   + reload GTC/GTD orders persisted from previous trading day   Allowed trading functions:   * Admin order cancel for reloaded GTC/GTD orders |
| INTERVENTION | It is used for stopping the market in an extreme and emergency scenario. No trading activities is allowed from participants.  Background functions:   * Cancel all open orders, quotes and unmatched block trades by the system   Allowed trading functions:   * Admin trade cancel * Admin trade price adjustment * Internal on-behalf enter trade   It is the trading state where all trading timetables (except those already moved to DAYEND) will transit to after site failover. |
| DAYEND | It must be and can only be the last trading state configured in the trading timetable. No trading function is allowed.  Background functions:   * Persist GTD/GTC orders * Prepare for next trading day |

## Business Trading States

**#FS10001\_S0060\_00300**

A business trading state is defined based on a specified **trading state type** (refer to Section 6.2.1.). A trading state type dictates the behaviours, trading functions/order attributed allowed and background functions/supervision applicable for a trading state.

For each defined business trading state, the following attributes are specified:

1. Identity
   * Trading state ID: unique identifier
   * Trading state name: display name
   * Trading state description: description text in trading state change and alert messages
2. Trading state type
3. Flag to indicate it is a business trading state
4. Trading functions (refer to Section 6.2.2.)
5. Order types (refer to Section 6.2.3.)
6. Order validities (refer to Section 6.2.3.)
7. Background functions (refer to Section 6.2.4.)
   * Calculate AHT static price limit reference price: whether to trigger AHT static price limit reference price calculation
   * Remove all orders: whether to remove all open orders, quotes and unmatched block trades
   * Inactivate non-AHT orders: whether to move all non-AHT orders to non-public order books
8. Supervision (refer to Section 6.2.4.)
   * Static price limit supervision: whether to enable static price limit supervision
   * Dynamic price limit supervision: whether to enable dynamic price limit supervision
   * VCM monitoring: whether to enable VCM monitoring
   * VCM start offset: start offset (in number of seconds) of VCM monitoring, applicable only if the trading state enables VCM monitoring; VCM monitoring is started after the start offset from the start time of the trading state
   * VCM end offset: end offset (in number of seconds) of VCM monitoring, applicable only if the trading state enables VCM monitoring; VCM monitoring is ended before the end offset from the end time of the trading state, i.e. the start time of the next trading state

**#FS10001\_S0060\_00400**

To define a trading state with trading state type as PREOPENALLOC and OPENALLOC, the following additional attribute is specified:

1. Random start:
   * Random start interval: interval (in number of seconds) from the start time of the trading state; the trading state will be started at a randomly calculated time within this defined interval, e.g. random cut-off at pre-opening

**#FS10001\_S0060\_00500**

If same trading state is specified with same start time and random start interval, the actual start time of that specified trading state will be the same across all timetables in the system.

Example – Behaviour of random interval across trading timetable

There are 3 markets: M1, M2 and M3.

They operate under 3 different timetable: M1T, M2T and M3T.

M1T and M2T specify the same trading state (PREOPENALLOC, with random start interval = 60) at the 09:09:00, i.e.

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
| Start logical day indicator | Start time | Trading state | Number of alerts | Alert interval |
| 0 | 09:09:00 | PREOPENALLOC |  |  |

M3T specifies a different trading state (PREOPENALLOC\_15 with same pre-open allocation random interval = 60) at the 09:09:00, i.e.

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
| Start logical day indicator | Start time | Trading state | Number of alerts | Alert interval |
| 0 | 09:09:00 | PREOPENALLOC\_15 |  |  |

The actual time of M1T and M2T moving into pre-open allocation will always be the same, while the actual time of M3T entering into pre-open allocation is independent.

### Trading State Type

**#FS10001\_S0060\_00600**

A brief description of each trading state types is as follows:

|  |  |
| --- | --- |
| Trading State Type | Description |
| PREMKTACT | Orders can be amended and cancelled, but new orders cannot be placed into the market. |
| PREOPEN | Entering, amendment and cancellation of orders are allowed.  For combo orders, only cancellation is permitted and COP is not calculated. |
| PREOPENALLOC | Only entering market and market to limit orders is allowed.  No order action is allowed for combo orders. |
| OPENALLOC | No order action is allowed. |
| UNCROSS | No order action is allowed. Orders are matched according to order type, price and time priority at the COP. Unmatched market and market to limit orders are cancelled and converted into limit orders respectively.  No auction matching is performed for combo orders. |
| OPEN | Orders and quotes input, modification and cancellation are allowed. Orders are matched by the system automatically according to price time priority.  In case the order book prices are crossed when entering this state, orders will be matched before continuous matching (refer to FS10003 - Orderbook and Execution Management). |
| PAUSE | No trading activities is allowed from participants. |

### Allowed Trading Functions

**#FS10001\_S0060\_00700**

Trading functions are the functions performed by the system and the actions which can be submitted by the participants in a business trading state. The functions allowed for each trading state type are defined as below:

|  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | Allowed Trading Functions | | | | | | | | | |
|  | Business Functions | | | | | | | | | |
|  | Order Entry | Order Amend  (preserve time priority) | Order Amend  (loss of time priority) | Order Cancel | Quote Request | Single Quote | Mass Quote | Block Trade | Error Trade Claim | TMC Creation |
| Trading State Type |  |  |  |  |  |  |  |  |  |  |
| PREMKTACT |  |  |  |  |  |  |  |  |  |  |
| PREOPEN | 1 | 1 | 1 |  |  |  |  |  |  |  |
| PREOPENALLOC | 1 |  |  |  |  |  |  |  |  |  |
| OPENALLOC |  |  |  |  |  |  |  |  |  |  |
| UNCROSS |  |  |  |  |  |  |  |  |  |  |
| OPEN |  |  |  |  |  |  |  |  |  |  |
| PAUSE |  |  |  |  |  |  |  |  |  |  |

1 Not applicable for combo orders

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | Allowed Trading Functions | | | |
|  | Business Operations | | | |
|  | System/Admin Order Cancel | Admin Trade Cancel | Admin Trade Price Adjustment | Internal On-Behalf Enter Trade |
| Trading State Type |  |  |  |  |
| PREMKTACT |  |  |  |  |
| PREOPEN |  |  |  |  |
| PREOPENALLOC |  |  |  |  |
| OPENALLOC |  |  |  |  |
| UNCROSS |  |  |  |  |
| OPEN |  |  |  |  |
| PAUSE |  |  |  |  |

Remark:

* + The handling of single quote and mass quote consists of a 2 phases cancel-add process.
    - Phase 1 (cancelling existing quote) is classified as Order Cancel function.
    - Phase 2 (adding new quote) is classified as Single Quote/Mass Quote function.
  + The following are classified as Block Trade functions:
    - Submission of internal block trades
    - Submission of interbank block trades
    - Cancellation of unmatched interbank block trades
    - Decline of unmatched interbank block trades
  + The following are classified as System/Admin Order Cancel functions:
    - Unsolicited order cancellation triggered by the system
    - Unsolicited unmatched block trades cancellation triggered by the system
    - Cancellation of orders triggered by Business Operations
    - Cancellation of unmatched block trades triggered by Business Operation

Business Operations has the flexibility to disable selected business functions and business operations per defined business trading state.

### Allowed Order Types & Validities

**#FS10001\_S0060\_00800**

Allowed order types and validities govern whether an order is allowed for order entry and order amend (with loss of priority). Following lists the allowed order types and validities for each trading state type:

|  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | Allowed Order Types & Validities | | | | | | | | |
|  | Order Type | | | Order Validity | | | | | |
|  | Limit Order | Market Order | Market to Limit Order | Day | Fill and Kill (FAK) | Fill or Kill (FOK) | Good Till Cancel (GTC) | Good Till Date (GTD) | At Crossing |
| Trading State Type |  |  |  |  |  |  |  |  |  |
| PREMKTACT |  |  |  |  |  |  |  |  |  |
| PREOPEN |  |  |  |  |  |  |  |  |  |
| PREOPENALLOC |  |  |  |  |  |  |  |  |  |
| OPENALLOC |  |  |  |  |  |  |  |  |  |
| UNCROSS |  |  |  |  |  |  |  |  |  |
| OPEN |  |  |  |  |  |  |  |  |  |
| PAUSE |  |  |  |  |  |  |  |  |  |

Business Operations can customize business trading states by disabling selected order types and validities.

### Applicable Background Functions and Supervision

**#FS10001\_S0060\_00900**

Background functions are the tasks initiated automatically by the system each time a trading state is reached. These tasks are optional and applicable for certain trading state types. Business Operations can determine if any applicable background functions and supervision should be enabled when defining a business trading state.

The applicability for each trading state type is as below:

|  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- |
|  | Applicable Trading State Attributes | | | | | | |
|  | Background Functions | | | Implied | Supervision | | |
|  | Calculate AHT Static Price Limit Reference Price | Remove All Orders | Inactivate Non-AHT Orders | Implied Generation | Static Price Limit Supervision | Dynamic Price Banding Supervision | VCM Monitoring |
| Trading State Type |  |  |  |  |  |  |  |
| PREMKTACT |  |  |  |  |  |  |  |
| PREOPEN |  |  |  |  |  |  |  |
| PREOPENALLOC |  |  |  |  |  |  |  |
| OPENALLOC |  |  |  |  |  |  |  |
| UNCROSS |  |  |  |  |  |  |  |
| OPEN |  |  |  |  |  |  |  |
| PAUSE |  |  |  |  |  |  |  |

Note that the next trading state will not commence until the automatically initiated background functions enabled are completed.

If multiple background functions are enabled in a trading state, they will follow the execution sequence as below:

1. Calculate AHT Static Price Limit Reference Price *(This is for the triggering of the calculation. The next trading state may commence before the completion of reference price calculation.)*
2. Remove All Orders
3. Inactivate Non-AHT Orders

### Examples

**#FS10001\_S0060\_01000**

Example 1 – Trading state for pre-market activities

|  |  |
| --- | --- |
| Trading State Attributes | Value |
| Trading state name | PRE\_MKT\_ACT |
| Trading state description | Pre-Market Activities |
| Trading state type | PREMKTACT |

Example 2 – Trading state for continuous trading with dynamic price banding and VCM

|  |  |
| --- | --- |
| Trading State Attributes | Value |
| Trading state name | OPEN\_DPL\_VCM\_AM |
| Trading state description | Automatic matching |
| Trading state type | OPEN |
| Supervision | Dynamic price banding supervision  VCM monitoring  VCM start offset = 900  VCM end offset = 0 |

Example 3 – Trading state for continuous trading with static price limit and dynamic price banding

|  |  |
| --- | --- |
| Trading State Attributes | Value |
| Trading state name | OPEN\_DPL |
| Trading state description | Automatic matching |
| Trading state type | OPEN |
| Supervision | Static price limit supervision  Dynamic price banding supervision |

Example 4 – Trading state for lunch break

|  |  |
| --- | --- |
| Trading State Attributes | Value |
| Trading state name | BREAK |
| Trading state description | Pause |
| Trading state type | PAUSE |

Example 5 – Trading state for block trade order entry only

|  |  |
| --- | --- |
| Trading State Attributes | Value |
| Trading state name | BLK\_TRADE\_ONLY |
| Trading state description | Allow Block Trade Only |
| Trading state type | OPEN |
| Allowed trading functions | Disable all functions except Block Trade |

Example 6 – Trading state for AHT pre-market activities and non-AHT orders inactivation

|  |  |
| --- | --- |
| Trading State Attributes | Value |
| Trading state name | AHT\_ PREMKTACT |
| Trading state description | AHT Pre-Market Activities |
| Trading state type | PREMKTACT |
| Background functions | Calculate AHT Static Price Limit Reference Price  Inactivate non-AHT orders |

## Trading State Publication

**#FS10001\_S0060\_01100**

At the start of day, the system publishes the very first trading state, i.e. SOD, with the first trading session defined in the trading timetable. Whenever there is a trading state change afterwards or when the alert interval is reached before start of the next trading state, a notification message will be sent. It should be noted that no trading state change will be published at the start and end of VCM cooling off.

For the days that the market is not open for trading, the market will remain at SOD state throughout the day and the trading session will be set as Day Session.

## Combo Trading State

**#FS10001\_S0060\_01200**

Business Operations is allowed to assign a trading timetable to combo at following product levels (lower level will override upper):

1. Combo Type
2. Combo Class

If there is no trading timetable explicitly assigned to combo, combo’s trading schedule (i.e. trading calendar and trading timetable) will be inherited from its first leg.

If a timetable is assigned to combo, the combo belonging to that combo type/combo class will have their own schedule and follow the trading calendar of the market of the combo.

It should be noted the background functions and supervision applied to a combo solely depends on the combo trading state. While the trading functions, order types and attributes allowed for a combo are governed by both combo and its legs’ trading states.

### Examples

Consider below examples for illustration purpose:

Combo C consists of two legs, namely Leg 1 = X and Leg 2 = Y

Example 1 – No trading timetable assigned to combo

If no trading timetable is assigned to combo, C will follow the trading timetable of X.

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
| Time | Leg 1’s Trading State | Leg 2’s Trading State | Combo’s Trading State | Allowed trading functions for Combo |
| 08:30 | SOD | PREOPEN | SOD | No order actions allowed |
| 08:45 | PREOPEN | PREOPEN | PREOPEN | Only order cancel allowed |
| 08:54 | PREOPEN | PREOPENALLOC | PREOPEN | Only order cancel allowed |
| 08:57 | PREOPEN | OPENALLOC | PREOPEN | Only order cancel allowed |
| 08:59 | PREOPEN | UNCROSS | PREOPEN | Only order cancel allowed |
| 09:00 | PREOPEN | OPEN | PREOPEN | Only order cancel allowed |
| 09:09 | PREOPENALLOC | OPEN | PREOPENALLOC | No order actions allowed |
| 09:12 | OPENALLOC | OPEN | OPENALLOC | No order actions allowed |
| 09:14 | UNCROSS | OPEN | UNCROSS | No order actions allowed |
| 09:15 | OPEN | OPEN | OPEN | Order input, amend, cancel allowed  Order matching according to price time priority |
| 12:00 | OPEN | PAUSE | OPEN | No order actions allowed |
| 12:15 | PAUSE | PAUSE | PAUSE | No order actions allowed |

Example 2 – A trading timetable assigned to combo

If a trading timetable is assigned to combo type or combo class of C, C will follow the assigned trading timetable.

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
| Time | Leg 1’s Trading State | Leg 2’s Trading State | Combo’s Trading State | Allowed trading functions for Combo |
| 08:30 | SOD | PREOPEN | SOD | No order actions allowed |
| 08:45 | PREOPEN | PREOPEN | PREMKTACT | Only order cancel allowed |
| 09:00 | PREOPEN | OPEN | PREMKTACT | Only order cancel allowed |
| 09:09 | PREOPENALLOC | OPEN | PREMKTACT | No order actions allowed |
| 09:12 | OPENALLOC | OPEN | PREMKTACT | No order actions allowed |
| 09:14 | UNCROSS | OPEN | PREMKTACT | No order actions allowed |
| 09:15 | OPEN | OPEN | OPEN | Order input, amend, cancel allowed  Order matching according to price time priority |
| 12:00 | OPEN | PAUSE | PAUSE | No order actions allowed |
| 12:15 | PAUSE | PAUSE | PAUSE | No order actions allowed |

# Intraday Trading Timetable Changes

**#FS10001\_S0070\_00100**

Under exceptional scenarios, Business Operations may need to change the trading timetable intraday according to business rules. Any intraday trading timetable changes are applicable to that specific trading day only. These changes are not persisted and not carry to the next trading day. It should be noted that if there is a pending intraday change request at a product level, no further intraday change request at that product level will be allowed.

## Trading State Transition Mode

**#FS10001\_S0070\_00200**

Each trading state in the timetable has automatic transition set by default. Under automatic transition, the corresponding trading state starts at the specified time without any manual intervention.

**#FS10001\_S0070\_00300**

Business Operations can set the state transition mode from automatic to manual (or vice versa) for a particular trading state intraday. If the next trading state is in manual mode, the timetable will stay at current trading state. Manual triggering is required for moving from current to the next trading state.

## Ad-hoc Change to Trading Timetable

**#FS10001\_S0070\_00400**

Business Operations is allowed to modify the trading timetable which the selected product level currently follows. This includes:

* update a future trading state
* insert a new trading state with a future start time
* delete a future trading state
* move into next trading state
* change the transition mode (automatic or manual) of a future trading state

For any updates, validation rules on the change of trading timetable are applied:

* trading timetable must be within allowed trading hours (refer to Section 4.1.)
* sequence and occurrence of trading sessions must fulfil the validation rules (refer to Section 5.)
* transition mode switching are allowed for future trading state only
* trading state insertion/amendment/deletion are allowed for future trading states only

**#FS10001\_S0070\_00500**

If an ad-hoc change is requested to a product level which inherits the timetable from its upper level, a new timetable will be created. The new timetable is cloned from the one originally inherited from and adjusted with the changes made in the request. This new timetable will be assigned to that specified product level when the request is approved. In other words, its timetable will then be detached from its upper level. Once detached, the timetable will not be able to re-join to the original one.

It should be noted that if there is a pending request for modifying the inherited timetable, any requests for detaching timetable at lower level will not be allowed. Vice versa, if there is a pending request for detaching timetable, modification on the inherited timetable will not be allowed.

For example, consider below product hierarchy:

![](data:image/x-wmf;base64...)

Example 1

If an ad-hoc change is applied to market M1, the change will inherit to instrument type M1F and instrument class M1FUT, but will not affect instrument type M1C and M1P.

Example 2

Instrument class M1CALL inherits timetable from instrument type M1C. If an ad-hoc change on M1C is pending for approval, no ad-hoc change on M1CALL will be allowed.

Example 3

Instrument class M1CALL inherits timetable from instrument type M1C. If an ad-hoc change on M1CALL is pending for approval, no ad-hoc change on M1C will be allowed.

Example 4

If an ad-hoc change is applied to instrument type M1F, the timetable will be detached from market M1 onwards. Instrument class M1FUT will follow M1F. Any further ad-hoc change applied to M1 and M1F will not affect each other.

## Intraday Trading Timetable Import

**#FS10001\_S0070\_00600**

Business Operations can import trading timetables at different product levels intraday in order to make any necessary trading schedule adjustment (e.g. resuming market for trading in contingency scenarios). The import files can be prepared manually or modified from the exported timetables files. The import files can only contain trading states scheduled at a future time. The timetables to be imported are subject to the trading timetable validations.

## Trading Pause

**#FS10001\_S0070\_00700**

In the event that suspension of trading activities for all markets is required, Business Operation may pause all or selected markets at a target time through “Trading Pause” function. The default target trading state (which must be with trading state type PAUSE) for trading pause is pre-configured in system parameter – “Trading Pause – PAUSE”. The system deduces and inserts the target trading state for all applicable timetables at the target time according to the following:

|  |  |
| --- | --- |
| Type of trading state at the target pause time | Timetable Adjustment |
| SOD (technical trading state) | The transition mode of the next trading state's (i.e. the first trading state after SOD) will be set to manual. |
| PREMKTACT  PREOPEN  PREOPENALLOC  OPENALLOC UNCROSS  OPEN  PAUSE | A target trading state “Trading Pause - PAUSE” will be inserted into the timetable and its start time will be set to the target pause time.  The transition mode of the next trading state of the target trading state will be set to manual. |
| INTERVENTION | *<No change>* (it is under an extreme contingency scenario) |
| DAYEND | *<No change>* (the market has already been closed) |

Changes of the timetables will be applied after reviewed and approved by Business Operations.

## Early Closing

**#FS10001\_S0070\_00800**

In the event that the trading activities has been suspended and it is confirmed that there will be no trading for the day, Business Operations may arrange to close the markets earlier than normal trading scheduled at a target time through “Early Closing” function. The system deduces the timetables for the markets for the remaining of the day according to the following rules:

|  |  |
| --- | --- |
| Type of trading state at the target early close time | Timetable Adjustment |
| PAUSE | Except the last one (i.e. DAYEND), all future trading states will be deleted.  The transition mode of the last trading state (i.e. DAYEND) will be set to automatic. |
| INTERVENTION | *<No change>* (it is under an extreme contingency scenario) |
| DAYEND | *<No change>* (the market has already been closed) |
| Other than above | *<No change>* (the market is in an unexpected trading state, a warning is shown to indicate the market is still open for trading) |

After Business Operations reviews the revised timetables and approves, the change of the timetables will be applied.

## Trading Resumption

**#FS10001\_S0070\_00900**

In exceptional scenarios where trading can be resumed after suspension (e.g. market resumption after an exceptional event or after site failover), adjustment of trading timetables for different markets according to trading rules and/or BCP guidelines may be required.

Business Operations can follow below procedures to prepare and update the trading timetables for resumption:

* Export the current trading timetables for all markets from the system
* Generate the trading timetables based on current trading states for resumption by a scripting tool which is developed to incorporate with the defined business rules
* Review and adjust (if needed) the trading timetables by Business Operations
* Upload the prepared timetables via intraday trading timetable import function

1. Subject to system up time and maintenance window [↑](#footnote-ref-2)
