TITLE:

**FUNCTIONAL SPECIFICATION**

**ODP-T**

FS10023 - Instrument and Combo Generation

AUTHOR : IT/Markets Systems DATE : 24 Mar 2025

LAST REVIEW : Derivatives Trading Business Operations DATE : 28 Feb 2025

**CONTENTS**

[1. Document Control 4](#__RefHeading___Toc193721494)

[1.1. Change History 4](#__RefHeading___Toc193721495)

[1.2. Document Cross-referenced 4](#__RefHeading___Toc193721496)

[1.3. Abbreviation 5](#__RefHeading___Toc193721497)

[2. Introduction 6](#__RefHeading___Toc193721498)

[3. Automatic Instrument Generation 7](#__RefHeading___Toc193721499)

[3.1. Auto Generation Logic Flow Summary 7](#__RefHeading___Toc193721500)

[3.2. Auto Generation Rule 8](#__RefHeading___Toc193721501)

[3.2.1. Unit 9](#__RefHeading___Toc193721502)

[3.2.2. Until Days to Last Trading 9](#__RefHeading___Toc193721503)

[3.2.3. Pre-launch Days (And First Trading Date) 10](#__RefHeading___Toc193721504)

[3.2.3.1. One-off Pre-launch 11](#__RefHeading___Toc193721505)

[3.2.4. Last Trading Date Group 11](#__RefHeading___Toc193721506)

[3.2.4.1. Last Trading Date Group Priority 11](#__RefHeading___Toc193721507)

[3.2.4.2. Example 12](#__RefHeading___Toc193721508)

[3.2.5. Strike Price Group 12](#__RefHeading___Toc193721509)

[3.3. Cycle Blocks 12](#__RefHeading___Toc193721510)

[3.3.1. Unit 13](#__RefHeading___Toc193721511)

[3.3.2. Type 13](#__RefHeading___Toc193721512)

[3.3.3. Block Details 13](#__RefHeading___Toc193721513)

[3.3.3.1. Cycle List 13](#__RefHeading___Toc193721514)

[3.3.3.2. Strike Price Range 16](#__RefHeading___Toc193721515)

[3.3.3.3. Strike Price Reference 19](#__RefHeading___Toc193721516)

[3.4. Last Trading Date Formula 20](#__RefHeading___Toc193721517)

[3.4.1. Name 21](#__RefHeading___Toc193721518)

[3.4.2. Unit 21](#__RefHeading___Toc193721519)

[3.4.3. Rules 21](#__RefHeading___Toc193721520)

[3.4.3.1. Day Anchoring Rules 22](#__RefHeading___Toc193721521)

[3.4.3.2. Day Adjustment Rules 25](#__RefHeading___Toc193721522)

[3.4.3.3. Calendar Rules 26](#__RefHeading___Toc193721523)

[3.4.4. Regional Calendar 27](#__RefHeading___Toc193721524)

[3.4.4.1. Upload Regional Calendar 27](#__RefHeading___Toc193721525)

[3.4.5. Examples 28](#__RefHeading___Toc193721526)

[3.5. Last Trading Date Calendar 31](#__RefHeading___Toc193721527)

[3.5.1. Monthly Last Trading Date Calendar 32](#__RefHeading___Toc193721528)

[3.5.2. Weekly Last Trading Date Calendar 32](#__RefHeading___Toc193721529)

[3.6. Lifecycle Time Rule 32](#__RefHeading___Toc193721530)

[3.6.1. DST Adjustment 33](#__RefHeading___Toc193721531)

[3.6.1.1. Date Ranges 33](#__RefHeading___Toc193721532)

[3.6.1.2. Adjustment in Minutes 34](#__RefHeading___Toc193721533)

[4. Automatic Combo Generation 34](#__RefHeading___Toc193721534)

[4.1. Combo Rules 35](#__RefHeading___Toc193721535)

[4.1.1. Manual Link Rule 35](#__RefHeading___Toc193721536)

[4.1.1.1. Instrument Class 36](#__RefHeading___Toc193721537)

[4.1.1.2. Contracts from Spot and Month Selection 36](#__RefHeading___Toc193721538)

[4.1.1.3. Operation 37](#__RefHeading___Toc193721539)

[4.1.1.4. Ratio 37](#__RefHeading___Toc193721540)

[4.1.1.5. Examples 37](#__RefHeading___Toc193721541)

[4.1.2. Multiple Link Rule 38](#__RefHeading___Toc193721542)

[4.1.2.1. Instrument Class 39](#__RefHeading___Toc193721543)

[4.1.2.2. Leg Contracts 39](#__RefHeading___Toc193721544)

[4.1.2.3. Month Selection 39](#__RefHeading___Toc193721545)

[4.1.2.4. Min. Time Spread 39](#__RefHeading___Toc193721546)

[4.1.2.5. Combo Criteria 40](#__RefHeading___Toc193721547)

[4.1.2.6. Examples 40](#__RefHeading___Toc193721548)

[4.1.3. Banker Link Rule 41](#__RefHeading___Toc193721549)

[4.1.3.1. Instrument Class 41](#__RefHeading___Toc193721550)

[4.1.3.2. Banker Contracts Parameters 41](#__RefHeading___Toc193721551)

[4.1.3.3. Leg Contracts Parameters 42](#__RefHeading___Toc193721552)

[4.1.3.4. Min. Time Spread 43](#__RefHeading___Toc193721553)

[4.1.3.5. Combo Criteria 43](#__RefHeading___Toc193721554)

[4.1.3.6. Example 44](#__RefHeading___Toc193721555)

[4.2. Other Combo Attributes 44](#__RefHeading___Toc193721556)

[5. Creation Ordering 45](#__RefHeading___Toc193721557)

[6. Creation Logic 45](#__RefHeading___Toc193721558)

[7. Instrument Name Standard 46](#__RefHeading___Toc193721559)

[7.1. Examples 47](#__RefHeading___Toc193721560)

[8. Combo Name Standard 48](#__RefHeading___Toc193721561)

[8.1. Example 51](#__RefHeading___Toc193721562)

[9. Month Code 51](#__RefHeading___Toc193721563)

[Appendix I. First Trading Date Calculation 52](#__RefHeading___Toc193721564)

# Document Control

## Change History

|  |  |  |  |
| --- | --- | --- | --- |
| Version  Number | Issue Date | Author | Abstract |
| V1.0 | 20240917 | IT/Markets Systems | Initial version. |
| V1.1 | 20241008 | IT/Markets Systems | Revised based on review comments from business users |
| V2.0 | 20241029 | IT/Markets Systems | Revised based on review comments from business users |
| V2.1 | 20241115 | IT/Markets Systems | Revised based on review comments from business users |
| V2.2 | 20241121 | IT/Markets Systems | Revised based on review comments from business users |
| V3.0 | 20241127 | IT/Markets Systems | Revised based on review comments from business users |
| V3.1 | 20241227 | IT/Markets Systems | Revised based on review comments from business users |
| V3.2 | 20250324 | IT/Markets Systems | Revised based on review comments from business users |
| V3.3 | 2026XXXX | IT/Markets Systems | Revised based on Change Request on Instruments and Combos Maintenance Function v1.1 |

## Document Cross-referenced

|  |  |  |
| --- | --- | --- |
| # | Document | Version |
| 1 | BRD\_DT\_0003: 0003 BRS Order Book Execution Management | V1.6\_2025 01 21 |
| 2 | BRD\_DT\_0009: 0009 BRS\_Series Operation | 2024 10 15\_v5 |
| 3 | BRD\_DT\_0020: 0020 ODP - Trading Calendar for multi purpose | 2024 11 21 |
| 4 | FS10001 - Trading Timetable | 20241227 |
| 5 | FS10010 - Product Structure | 20250324 |
| 6 | FS10003 - Orderbook and Execution Management | 20250324 |
| 7 | Change Request on Instruments and Combo Maintenance Function | V1.1 |

## Abbreviation

|  |  |
| --- | --- |
| CA | Capital Adjustment |
| CSV | Comma Separated Value |
| DST | Daylight Saving Time |
| FS | Function Specification |
| FTD | First Trading Date |
| HKT | Hong Kong Time |
| LTD | Last Trading Date |
| MIC | Market Identifier Code |
| Ref | Reference |

# Introduction

Instrument and Combo Generation is an extension to FS10003 - Orderbook and Execution Management FS. It defines how order books can be automatic generated based on pre-defined rule set.

# Automatic Instrument Generation

#FS10023\_S0030\_00100

Automatic Instrument Generation creates Instruments based on configuration rules which describe the contract attributes. The configuration data model is shown in the following diagram.

Notes: All date and time values including those in regional calendar under automatic instrument generation scope are in system time zone (HKT).

![](data:image/x-wmf;base64...)

## Auto Generation Logic Flow Summary

#FS10023\_S0030\_00200

For each Instrument Class, the auto generation logic is summarized as follows:

|  |  |  |
| --- | --- | --- |
| **Step no.** | **Step Name** | **Reference Configuration** |
| 1 | To proceed auto generation for enabled rule only. | Instrument Class  Auto Generation Enabled. |
| 2 | If the Instrument Class is processed by CA earlier in the same day, auto generation is skipped. The generation is handled by CA Phase 2 process. | N/A |
| 3 | Determine the contract month, week or day. | Cycle Block. |
| 4 | Determine the last trading date. | Last Trading Date Formula / Last Trading Date Calendar.  Not relevant to daily. |
| 5 | Conditional skip generation based on blackout period. | Auto Generation Rule  Until Days to Last Trading. |
| 6 | Conditional skip generation based on Last Trading Date Group. | Auto Generation Rule  Last Trading Date Group. |
| 7 | Determine option strike price.  (Options only) | Options Strike Price Reference +  Options Strike Price Range. |
| 8 | Determine the First and Last trading date time. | Lifecycle Time Rule + DST Adjustment. |
| 9 | Determine to generate Pre-Launch Contract and it’s First trading date detailed in Appendix I. | Auto Generation Rule  Pre-launch Days. |
| 10 | Determine the contract name. | Instrument Name Standard +  Month Code. |
| 11 | Compare Strike Price Group for additional Strike Price.  (Options only) | Auto Generation Rule  Strike Price Group. |

## Auto Generation Rule

#FS10023\_S0030\_00301

The Auto Generation Rule is the root of the configuration. Each Auto Generation Rule can be assigned to multiple Instrument Classes.

The rule contains several entities:

* Cycle Blocks
* Last Trading Date Formula
* Last Trading Date Calendar
* Lifecycle Time Rule

And contains the following attributes:

* Unit
* Until Days to Last Trading
* Pre-launch Days
  + One-off Pre-launch
* Last Trading Date Group
  + Last Trading Date Group Priority
* Strike Price Group

### Unit

#FS10023\_S0030\_00400

The Unit attribute defined the type of contract cycle.

The contract cycle supported are “Monthly”, “Weekly” and “Daily”.

### Until Days to Last Trading

#FS10023\_S0030\_00500

Auto generation will be performed on all Instrument Class with auto generation rule enabled when it is invoked every day. The newly generated order book will be available on next trading day. This feature is applicable to Options only and not applicable to Futures or Combo.

The Until Days to Last Trading attribute define a period in trading days before the contract’s (effective) last trading date which the generation should be skipped.

Allowed values:

|  |  |
| --- | --- |
| **Unit** | **Allowed Value** |
| Monthly | 0 - 31 |
| Weekly | 0 - 7 |
| Daily | Not supported |

As illustrated in the calendar month below, when the last trading date is on day 30 of the month and the Until Days to Last Trading is set to 5 days, the auto generation rule will not generation order book for next trading day starting from day 23 of the month.

|  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- |
| **SUN** | **MON** | **TUE** | **WED** | **THU** | **FRI** | **SAT** |
|  | 1 | 2 | 3 | 4 | 5 | 6 |
| 7 | 8 | 9 | 10 | 11 | 12 | 13 |
| 14 | 15 | 16 | 17 | 18 | 19 | 20 |
| 21 | 22 | 23 | 24 | 25 | 26 | 27 |
| 28 | 29 | **30** | 31 |  |  |  |

The Trading Day is defined by Trading Calendar described in FS10001.

### Pre-launch Days (And First Trading Date)

#FS10023\_S0030\_00600

The Pre-launch Days define number of business days the contract starts trading after it is created and visible in the market.

Allowed values:

|  |  |
| --- | --- |
| **Unit** | **Allowed Value** |
| Monthly | 0 - 31 |
| Weekly | 0 - 7 |
| Daily | Not supported |

When the Pre-launch Days is 0, which is in most of the cases for existing contracts, the “First Trading Date” of newly generated contracts is the next trading date. In other words, the contract created will be visible and tradable in the market on the same day.

In the below example for monthly contract order book with Pre-launch Days “0”, when it is created on 30 Jan for next trading date, it exists and available for trading on 31 Jan.

|  |  |  |  |
| --- | --- | --- | --- |
| **29 Jan (Mon)** | **30 Jan (Tue)** | **31 Jan (Wed)** | **1 Feb (Thu)** |
|  | Creation Date | First Trading Date |  |

In another example below for weekly contract order book with Pre-launch Days “2” for trading starts from 26 Feb, it is created on 21 Feb, visible in the market from 22 Feb. The First Trading Date is “2” trading days from the day it visible in the market.

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
| **21 Feb (Wed)** | **22 Feb (Thu)** | **23 Feb (Fri)** | **24 Feb (Sat)** | **25 Feb (Sun)** | **26 Feb (Mon)** |
| Creation Date | Visible in the market, but not tradable | Visible in the market, but not tradable | Non-trading day | Non-trading day | First Trading Date |

Details on the related First Trading Date calculation refer to the Appendix I.

#### One-off Pre-launch

#FS10023\_S0030\_00700

If the Automatic Instrument Generation rule is filled with necessary attributes, the Trading System will attempt to create Instruments at the scheduled time of a day. It is generally expected that the First Trading Date of a generated Instrument is the next Trading date.

For cases when Exchange would like Participants to be notified of the upcoming tradable Instruments earlier than its First Trading Date, Trading System will “pre-launch” the to-be-tradable Instruments. The “One-off Pre-launch First Trading Date (One-off Pre-launch FTD)” attribute inside the generation rule will be used to compare against the First Trading Date. The pre-launch duration would be from the date defined in One-off Pre-launch FTD, till the date defined in First Trading Date, where One-off Pre-launch FTD must be either earlier or of the same date and not later than the First Trading Date.

### Last Trading Date Group

#FS10023\_S0030\_00800

Last Trading Date Group is a label in Auto Generation Rule. Instrument Classes with auto-generation rule having same label are in the same group, so that contracts in the same group and same last trading date are considered duplicated, only contracts with highest priority value described in the next section will be created. By default, the label is same as the name of Instrument Class and therefore each Instrument Class are different.

#### Last Trading Date Group Priority

#FS10023\_S0030\_00900

Last Trading Date Group Priority is a number from 0 to 9, where lower value means higher priority.

When creating the Instrument Class and auto-generation rule record, it is set with value 0.

When an Instrument Class is to be auto generated, all Instrument Classes having higher priority in the same Last Trading Date Group will go through a simulated auto-generation process. When those simulated generation produce contracts with same Last Trading Date as generation from this Instrument Class, contracts from this Instrument Class are skipped. Warning will be given to the auto-generation maker.

Note that

1. The lower priority Instrument Classes are skipped even though the highest priority one is not generated.
2. When there are multiple Instrument Classes having highest priority value, both will be generated.

#### Example

#FS10023\_S0030\_01000

As an example, Monthly HSI Options and Weekly HSI Options are in the same Last Trading Date Group so that the weekly options with same last trading day as monthly options will not be generated.

HSI Monthly Options

|  |  |
| --- | --- |
| **Attributes** | **Value** |
| Last Trading Date Group | HSIOPTS |
| Last Trading Date Group Priority | 0 |

HSI Weekly Options

|  |  |
| --- | --- |
| **Attributes** | **Value** |
| Last Trading Date Group | HSIOPTS |
| Last Trading Date Group Priority | 1 |

#### Determining Instrument/Combo Existence

To determine whether an Instrument/Combo has existed and only the Effective Last Trading Date needed to be updated, the system should scan all the existing Instruments/Combos (under the Instrument Class/Combo Class that the Auto Generation rule is running for) inside the database to prevent duplication.

The system will first utilise the name of the Instrument/Combo to determine its existence. For Combo, at time of creation, the legs will be sorted from Nearest to Furthest Expiry before applying the Combo Naming Standards. If no identical names have been spotted, the system will attempt to compare definitions of the Combo Legs – including the Operation and Ratio.

At the scheduled time of Automatic Instrument Generation, Last Trading Date will be calculated. If the new Instrument’s definition is identical with an existing Instrument, just that the new Instrument’s Last Trading Date is different from the existing Instrument’s Effective Last Trading Date, then the existing Instrument’s Effective Last Trading Date will be updated with the re-calculated value. Under such case, no new Instruments will be created.

A warning will be issued to Exchange Operations when there are multiple Instruments under the same Instrument Class exists in the same contract month.

### Strike Price Group

#FS10023\_S0030\_01100

Strike Price Group is a label in Auto Generation Rule so that the same label with the same last trading date will have the same strike prices.

It is done by the last step mentioned in Auto Generation Logic Flow Summary section above. It compares options contracts between Instrument Classes with the same label and creates missing strike prices which exist in others.

Contract attributes other than Instrument Class are copied from the existing one.

## Cycle Blocks

#FS10023\_S0030\_01200

Cycle Blocks contains one or multiple Block Details, up to a maximum of 10. Each Block Details mainly consists of a cycle list definition, which defines the contract month, week or day to generate contract.

Besides the Block Details, Cycle Blocks also contains Unit and Type attributes.

Cycle Blocks are for association to Auto Generation Rule with same Unit configuration.

### Unit

#FS10023\_S0030\_01300

Same definition as Unit in Auto Generation Rule. To assign a Cycle Blocks to Auto Generation Rule, their Unit must be the same.

### Type

#FS10023\_S0030\_01400

Type is either Futures or Options.

To assign a Cycle Blocks to Auto Generation Rule, the Type attribute must be same as the Product which the Auto Generation Rule belongs to.

### Block Details

#FS10023\_S0030\_01500

Block Details are numbered starting from 1 and onward. For mapping to the configuration in existing system, the first Block Details called Block 1 is used for Short-dated contracts, Block 2 is used for Long-dated contracts.

Each Block Details contains the following attributes:

* Cycle List
* Strike Price Range
* Strike Price Reference

#### Cycle List

#FS10023\_S0030\_01601

Based on the Unit attribute from Cycle Blocks, the Cycle List defines a list of contract month or week relative from the reference month, week or day for order book generation.

The maximum number of items allowed in the list is 36.

The word “ref” used in the cycle definition means reference month, week or day. The reference rollover to next unit at SOD after Last Trading Date of the Unit (month / week / day).

Each Cycle Block have their own reference:

* In the first Block, it is referring to the previous contract month, week or day at next SOD trading state.
* In Blocks other than the first one, it is referring to the last calendar month, week or day of previous Cycle Block unit.

The example below shows the Reference Month for the Block when the unit is monthly, and current date is 10 Sep 2024:

|  |  |  |  |
| --- | --- | --- | --- |
| **Block #** | **Cycle List**  **(more details on syntax below)** | **Reference Month** | **First Month (ref+1)** |
| Block 1 | ref+1, ref+2, ref+3, ref+4, ref+5, ref+6, ref+7 | Aug 2024 (assuming Aug 2024 is the immediate previous contract month for this product) | Sep 2024 |
| Block 2 | ref+1, …. | Mar 2025 | Apr 2025 |

There is an assumption that per Instrument Class, maximum 1 contract will have last trading date within a Unit of period (a month, a week or a day).

For Month Unit in Cycle Block, the cycle defines a contract month with syntax below:

|  |  |
| --- | --- |
| **List item syntax** | **Description** |
| ref + X | X refers to the number of calendar month from the reference month where a value from 1 to 36 is allowed.  For example, when the current month is February, the reference calendar month is January and “ref + 1” is February. |
| ref + Xq | X refers to the number of quarter month from the farthest calendar month within:   * Reference month (see Additional Note) * All ref + X   where a value from 1 to 40 is allowed.  A quarter month is either one of the March, June, September, or December.  For example, when the last month defined by “ref + X” is January, “ref + 1q” is March and “ref + 2q” is June.  Additional Note:  When there is no “ref + X” cycle in the Block, “ref + 1q” refers to the immediate upcoming quarter month from the reference month. If August is the reference month, the “ref + 1q” is September and “ref + 2q” is December. |
| ref + Xh | X refers to the number of half-year month from the farthest calendar month within:   * Reference month (see Additional Note) * ref + X * ref + Xq   where a value from 1 to 20 is allowed.  A half-year month is either one of the June or December.  For example, when the last month defined by “ref + X” and “ref + Xq” is March, “ref + 1h” is June and “ref + 2h” is December.  Additional Note:  When there is no “ref + X” or “ref + Xq” cycle in the Block, “ref + 1h” refers to the immediate upcoming half-year month from the reference month. If May is the reference month, the “ref + 1h” is June and “ref + 2h” is December. |
| ref + Xy | X refers to the number of December month from the farthest calendar month within:   * Reference month (see Additional Note) * ref + X * ref + Xq * ref + Xh   where a value from 1 to 10 is allowed.  For example, when the last month defined by “ref + X”, “ref + Xq” and “ref + Xh” is June, “ref + 1y” is December and “ref + 2y” is the December month in next year.  Additional Note:  When there is no “ref + X”, “ref + Xq” or “ref + Xh” cycle in the Block, “ref + 1y” refers to the immediate upcoming December month from the reference month. If November is the reference month, the “ref + 1y” is December in the same year and “ref + 2y” is December in the next year. |

With the Month Cycle List syntax above, for example with a contract having contract months definition below:

|  |  |
| --- | --- |
| Contract Months | For Short-dated Futures: Spot Month, the next three calendar months and the next three calendar quarter months (i.e. quarterly months are March, June, September and December)  For Long-dated Futures: the three months of June and December plus the next three months of December following the Contract Months specified for Short-dated Futures |

The cycle list in Block 1 for Short-dated will be:

* ref+1, ref+2, ref+3, ref+4, ref+1q, ref+2q, ref+3q

The cycle list in Block 2 for Long-dated will be:

* ref+1h, ref+2h, ref+3h, ref+1y, ref+2y, ref+3y

For Week Unit the cycle syntax is as below:

|  |  |
| --- | --- |
| **List item syntax** | **Description** |
| ref + X | X refers to the number of calendar week from the reference week where a value from 1 to 53 is allowed.  For example, when the reference calendar week is week28, “ref + 1” is week29. |

With the Week Cycle List item syntax above, for example with a contract having contract weeks definition below:

|  |  |
| --- | --- |
| Contract Weeks | Spot Week and the next week, except where the Expiry Day of the Weekly Contract is the same as the Expiry Day of the Spot Month Hang Seng Index Option Contract |

The short-dated cycle list will be:

* ref+1, ref+2

For Daily Unit the cycle syntax is as below:

|  |  |
| --- | --- |
| **List item syntax** | **Description** |
| ref + X | X refers to the number of trading days from the reference day where a value from 1 to 31 is allowed.  For example, “ref + 1” is next trading day in Block 1. |
| ref + Xc | X refers to the number of calendar days from the reference day where a value from 1 to 31 is allowed.  And Instrument will not be generated if it falls on a Non Trading Date.  For example, “ref + 1c” is next calendar day in Block 1. |
| ref + Xwl | X refers to the number of **week** from the reference day where a value from 1 to 52 is allowed. And the last Trading Date of that week will be selected.  For example, “ref + 1wl” is next week’s last trading day in Block 1. |

#### Strike Price Range

#FS10023\_S0030\_01700

The Strike Price Range is specific to options contracts. It defines a strike price range from a reference price for the contract or order book generation. It is referred from Cycle Block(s) in Auto Generation Rule.

Options Strike Price Range contains the following attributes:

* Method
* Percentage Configuration
* Steps Configuration
* Strike Price Table

##### Method

#FS10023\_S0030\_01800

The Method to define the price range. The available options are:

|  |  |
| --- | --- |
| **Method** | **Description** |
| Percentage | To define price range by percentages from reference price. |
| Steps | To define price range by number of steps in strike price table from reference price. |

##### Percentage Configuration

#FS10023\_S0030\_01900

The Percentage Configuration is available when selected Method is “Percentage”. it contains the following attributes:

|  |  |
| --- | --- |
| **Attributes** | **Description** |
| Percentage Up | The upper range price, calculated by:   1. (Rounding the Reference Price to the nearest strike price) + (Original Reference Price X Percentage Up) 2. Then rounding the calculated price away from the reference price to the next strike price when it is not aligned.   The value allowed is from 0 to 1,000.  Notes: The reference price rounding picks the lower strike price when it is at the exact mid-point. |
| Percentage Down | The lower range price, calculated by:   1. (Rounding the Reference Price to the nearest strike price) - (Original Reference price X Percentage Down) 2. Then rounding the calculated price away from the reference price to the next strike price when it is not aligned.   The value allowed is from 0 to 1,000.  Notes:   1. The reference price rounding picks the lower strike price when it is at the exact mid-point. 2. Strike price must be greater than 0. |

##### Steps Configuration

#FS10023\_S0030\_02000

The Steps Configuration is available when selected Method is “Steps”. it contains the following attributes:

|  |  |
| --- | --- |
| **Attributes** | **Description** |
| Steps Up | The upper range price, calculated by:  (Rounding the Reference Price to the nearest strike price) + (Number of price steps in Strike Price Table)  The value allowed is from 0 to 500.  Notes: The reference price rounding picks the lower strike price when it is at the exact mid-point. |
| Steps Down | The lower range price, calculated by:  (Rounding the Reference Price to the nearest strike price) - (Number of price steps in Strike Price Table)  The value allowed is from 0 to 500.  Notes:   1. The reference price rounding picks the lower strike price when it is at the exact mid-point. 2. Strike price must be greater than 0. |

##### Strike Price Table

#FS10023\_S0030\_02100

Strike Price Table together with Percentage or Steps configuration are used for Strike Price calculation.

The Strike Price Table defines price interval per price range for options strike price like the concept of Tick Size table.

The table contains a list of following attributes:

|  |  |
| --- | --- |
| **Attributes** | **Description** |
| Decimals | The number of decimal places allowed. |
| Below Price | The upper range price. |
| Price Interval | The price delta between 2 strike prices. |

Example

|  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Strike Prices | Strike Prices shall be set as follows:   |  |  | | --- | --- | | HSI (Index points)  *Short-dated Options* | Intervals | | Below 5,000 | 50 | | At or above 5,000 but below 20,000 | 100 | | At or above 20,000 | 200 | |
|  |  |

Configuration

|  |  |
| --- | --- |
| **Decimals** | 0 |

|  |  |
| --- | --- |
| **Below Price** | **Intervals** |
| 5000 | 50 |
| 20000 | 100 |
| <Empty> | 200 |

Validation on the Price Interval will be done on:

1. Below Price must be unique.
2. Below Price and Interval alignment.
3. The number of decimal places for both below price and Interval must be less than the Decimal value.

Notes: When a Strike Price Table is used in Auto Generation Rule for an Instrument Class, the number of decimals in Strike Price Table must be less than or equal to the “Decimals for Strike Price” in the Instrument Class.

#### Strike Price Reference

#FS10023\_S0030\_02200

Like Strike Price Range, the Strike Price Reference is specific to options contracts and referred from Cycle Block(s) in Auto Generation Rule. It defines the reference price for Strike Price Range calculation.

The reference price is defined by the following attributes:

|  |  |
| --- | --- |
| **Attributes** | **Description** |
| Source Type | Instrument Class / Underlying |
| Source | For Instrument Class Source Type, it is the name of the Instrument Class.  For Underlying Source Type, it is the name of the Underlying from Product Structure. |
| Price Type | Settlement / Last price of current trading date. |
| Delta Days | This is only available for Instrument Class Source Type.  It accepts value from 0 to 31 number of days.  The value is for selecting the spot contract at SOD.  Value “0” refers to current day, the current day spot contract at SOD time.  Value “1” refers to tomorrow. The spot contract at SOD tomorrow. On non-last trading date, the contract is same as the one referred by value “0”. On last trading date, it is referring to the next contract.  For example, on the last trading date of Aug, the Monthly HSI future Reference Instrument Class with value “0” refers to Aug contract and value “1” refers Sep contract. |

The following reference prices will be input to the system from external sources:

* Underlying settlement price
* Underlying last price
* Instrument settlement price
* Instrument last price (TBC)

##### Example

#FS10023\_S0030\_02300

For HSICALL:

|  |  |
| --- | --- |
| **Attributes** | **Value** |
| Source Type | Instrument Class |
| Source | HSIFUT |
| Price Type | Settlement |
| Delta Days | 1 |

### Product Discontinuation

#FS10023\_S0030\_02350

To handle product discontinuation such that:

No new instruments would be generated from the effective date of product discontinuation. At the same time, for Options contracts, the existing expiries would still have new Strike Prices introduced following the Underlying Indexes or Stock Prices change.

The following attributes can be configured in Instrument Class:

* Furthest Expiry Date
* Cycle Block Frozen Date

Both attributes are Optional. Once specified, both fields must have values.

And those attributes support intra-day add and change.

#### Furthest Expiry Date

#FS10023\_S0030\_02360

This is the date for system to check that no Instruments under the discontinued Instrument Class would have the Last Trading Date beyond this date.

Any violations of such rule would induce system alerts.

#### Cycle Block Frozen Date

#FS10023\_S0030\_02370

This is the effective date of product discontinuation. This date directs the system to ‘freeze’ the generate of new Instruments according to the “Cycle Block” settings. And the Cycle Block Frozen Date is configured in Instrument Class level.

For example, **Cycle Block Unit** is Month and **Cycle Block Frozen Date** is 15 Jan 2025.

After the Last Trading Date of Jan 25 Instrument passed, while the existing Instruments remain listing in the system, system will not generate new Instruments for new contract months.

For the existing Options Instruments remain in the system, Instruments with new Strike Prices will still be generated following the Underlying Index or Stock Prices change.

The Combo Class linking to the discontinued Instrument Class would continue to undergo Combo Generation according to the “Combo Rules” settings. During Combo Generation, system will simulate the generation of Combo as if no Cycle Block Frozen Date. When output the Combo Generation result, system will only keep the generated Combo with Combo Leg Instrument still remaining in the system.

#### Example

#FS10023\_S0030\_02380

**Business Date:** 2 Jan 2025

**Cycle Block Unit:** Month

**Cycle Block Frozen Date**: 15 Jan 25

**Cycle Block** settings:

|  |  |
| --- | --- |
| **Cycle Item** | **Generated Expiry** |
| Ref+1 (Spot) | Jan 25 |
| Ref+2 (Spot+1 month) | Feb 25 |
| Ref+3 (Spot+2 month) | Mar 25 |
| Ref+4 (Spot+3 month) | Apr 25 |
| Ref+1Q (nearest 1st quarter) | Jun 25 |
| Ref+2Q (nearest 2nd quarter) | Sep 25 |
| Ref+3Q (nearest 3rd quarter) | Dec 25 |

**Futures Instruments:**

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
| **Cycle Item** | **Generated Instruments** | | | |
| Jan 25 | Feb 25 | Mar 25 | Apr 25 |
| Ref+1  (Spot) | Jan 25 | Feb 25 | Mar 25 | Apr 25 |
| Ref+2  (Spot+1 month) | Feb 25 | Mar 25 | Apr 25 | ~~May 25~~ |
| Ref+3  (Spot+2 month) | Mar 25 | Apr 25 | ~~May 25~~ | Jun 25 |
| Ref+4  (Spot+3 month) | Apr 25 | ~~May 25~~ | Jun 25 | ~~Jul 25~~ |
| Ref+1Q  (nearest 1st quarter) | Jun 25 | Jun 25 | Sep 25 | Sep 25 |
| Ref+2Q  (nearest 2nd quarter) | Sep 25 | Sep 25 | Dec 25 | Dec 25 |
| Ref+3Q  (nearest 3rd quarter) | Dec 25 | Dec 25 | ~~Mar 26~~ | ~~Mar 26~~ |
| Remarks | frozen at this point | No new Instruments | | |

Key: ~~xxx~~ – omitted expiries due to frozen “Cycle Block

**Combo:**

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
| **Combo Rule** | **Generated Combo** | | | |
| Jan 25 | Feb 25 | Mar 25 | Apr 25 |
| Spot  /  Spot+1 month | Jan 25  /  Feb 25 | Feb 25  /  Mar 25 | Mar 25  /  Apr 25 | Apr 25  /  ~~May 25~~ |
| Spot  /  Nearest 1st quarter | Jan 25  /  Mar 25 | Feb 25  /  Jun 25 | Mar 25  /  Jun 25 | Apr 25  /  Jun 25 |
| Spot  /  Nearest 2nd quarter | Jan 25  /  Jun 25 | Feb 25  /  Sep 25 | Mar 25  /  Sep 25 | Apr 25  /  Sep 25 |
| Spot+1 month  /  Nearest 1st quarter | Feb 25  /  Mar 25 | Mar 25  /  Jun 25 | Apr  /  Jun 25 | ~~May 25~~  /  Jun 25 |
| Spot+1 month  /  Nearest 2nd quarter | Feb 25  /  Jun 25 | Mar 25  /  Sep 25 | Apr 25  /  Sep 25 | ~~May 25~~  /  Sep 25 |
| Nearest 1st quarter  /  Nearest 2nd quarter | Mar 25  /  Jun 25 | Jun 25  /  Sep 25 | Jun 25  /  Sep 25 | Jun 25  /  Sep 25 |
| Remarks | frozen at this point |  | | |

Key: ~~xxx~~ – omitted expiries due to frozen “Cycle Block”

The highlighted Combo instruments are not generated given one of the leg is no longer listed in the corresponding Instrument Class

**Options Instruments:**

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
| **Cycle Item** | **Generated Instruments** | | | |
| Jan 25 | Feb 25 | Mar 25 | Apr 25 |
| Ref+1  (Spot) | Jan 25 | Feb 25 \* | Mar 25 \* | Apr 25 \* |
| Ref+2  (Spot+1 month) | Feb 25 | Mar 25 \* | Apr 25 \* | ~~May 25~~ |
| Ref+3  (Spot+2 month) | Mar 25 | Apr 25 \* | ~~May 25~~ | Jun 25 \* |
| Ref+4  (Spot+3 month) | Apr 25 | ~~May 25~~ | Jun 25 \* | ~~Jul 25~~ |
| Ref+1Q  (nearest 1st quarter) | Jun 25 | Jun 25 \* | Sep 25 \* | Sep 25 \* |
| Ref+2Q  (nearest 2nd quarter) | Sep 25 | Sep 25 \* | Dec 25 \* | Dec 25 \* |
| Ref+3Q  (nearest 3rd quarter) | Dec 25 | Dec 25 \* | ~~Mar 26~~ | ~~Mar 26~~ |
| Remarks | frozen at this point | No new Instruments for new contract months. But new Instruments for remaining Instruments with new Strike Price. | | |

Key: ~~xxx~~ – omitted expiries due to frozen “Cycle Block

\* - Generate Instruments with new Strike Price

## Last Trading Date Formula

#FS10023\_S0030\_02401

Last Trading Date Formula is used to calculate the month or week by using formula the contract last available for trading. It is referred from Auto Generation Rule, and validation is in place to ensure matches with the Unit in Cycle Class.

The formula contains the following attributes:

* Name
* Unit
* Rules

### Name

#FS10023\_S0030\_02500

The name of the formula. It is used as identifier to reference from Auto Generation Rule in different Instrument Class.

### Unit

#FS10023\_S0030\_02600

The Unit (Monthly, Weekly, Daily) of this formula. To use the formula in Auto Generation Rule, the formula Unit must be same as the Auto Generation Rule Unit.

In addition, some of the Rules detailed in the next section are Unit specific. When the formula is defined as Monthly Unit, rules specific to Weekly Unit are not available.

### Rules

#FS10023\_S0030\_02700

Rules attribute contains a list of user defined rules. The rules in the list will be executed sequentially to calculate the Last Trading Date.

The calculated date after all rules executed must be fall on the same Unit period (Month, Week), when the calculated date is outside of the Unit period, the generation will be skipped with warning at generation time. For example, “The last trading day of the month” and then delta calendar days “-20” works for a month without holiday but not for a month with holiday.

For weekly unit, the first day of week is Monday and last day is Sunday to align with ISO 8601 standard when validating if the calculated day is outside the week.

Users are allowed to select any available rules and add to the list and defines their ordering. Maximum 20 rules are allowed in the list.

There are 3 types of rules:

* Day Anchoring Rule
* Day Adjustment Rule
* Calendar Rule

The Day Anchoring Rule specifies a specific day while the Day Adjustment Rule move forward or backward number of days.

At least one Day Anchoring Rule must be present before Day Adjustment Rule.

There is a concept of “current referencing holiday calendar”, which is by default referring to the normal trading day and non-trading date calendar from the product structure.

For both types of rules, when referring to “Trading Day”, the “current referencing holiday calendar” will be considered.

The “current referencing holiday calendar” can be changed to a specific regional calendar (e.g. China or UK) by a Calendar Rule. Regional Calendar is described in the later section.

#### Day Anchoring Rules

#FS10023\_S0030\_02800

Day Anchoring Rules specify a day within the Unit. They are further subdivided into 2 sets, with the first set support Monthly Unit while the other support Weekly Unit.

##### Monthly Rules

#FS10023\_S0030\_02900

There are 3 rules available in the Monthly Rules catalogue:

* Monthly Trade Day
* Monthly Calendar Day
* Monthly Weekday

###### Monthly Trade Day Rule

#FS10023\_S0030\_03000

The Monthly Trade Day Rule specifies a trade day within the month. It will use the “current referencing holiday calendar” to determine trade days.

The rule accepts 2 parameters:

|  |  |
| --- | --- |
| **Parameter** | **Description** |
| Month Delta | The number of months move forward from the current calendar month.  It accepts value from 0 to 11. |
| Day | There are 2 selectable values:   * The first trading day of the month * The last trading day of the month |

When selecting the last Trading Day of the calendar month immediately following the Contract Month (assume current calendar month), the parameter Month Delta will be “1” and parameter Day will be “The last trading day of the month”.

###### Monthly Calendar Day Rule

#FS10023\_S0030\_03100

The Monthly Calendar Day Rule specifies a calendar day within the month. It does not consider trading holiday.

The rule accepts 2 parameters:

|  |  |
| --- | --- |
| **Parameter** | **Description** |
| Month Delta | The number of months move forward from the current calendar month.  It accepts value from 0 to 11. |
| Day | There are 2 selectable values:   * The first day of the month * The last day of the month |

When selecting the last day of the month, the parameter Month Delta will be “0” and the parameter Day will be “The last day of the month”.

###### Monthly Weekday Rule

#FS10023\_S0030\_03200

The Monthly Weekday Rule specifics a calendar day by a weekday in a month. It does not consider trading holiday.

The rule accepts 3 parameters:

|  |  |
| --- | --- |
| **Parameter** | **Description** |
| Weekday | One of the weekdays from Monday to Sunday. |
| Occurrence in Month | The occurrence of the weekday specified from either the beginning or the end of the Month. (See “From Month End” parameter below)  It accepts value from 1st to 5th.  E.g. 2nd Sunday in the Month. |
| From Month End | A true / false attribute. When True, the “Occurrence in Month” is counted from the end of Month.  E.g. Week in Month = 2nd and From Month End is False means the 2nd Sunday in the Month. Applying this setting to June 2025, the calendar it is referring to would be June 15th 2025. |

For example, when selecting the third Friday of the Contract Month, the parameter Weekday is “Friday”, the Occurrence in Month is “3rd” and the From Month End is “false”.

##### Weekly Rules

#FS10023\_S0030\_03300

There is 1 rule available in the Weekly Rule catalogue:

* Weekday Rule
* Weekly Trade Day

###### Weekday Rule

#FS10023\_S0030\_03400

The Weekday Rule specifies a day within the week. It does not consider trading holiday.

The rule accepts 1 parameter:

|  |  |
| --- | --- |
| **Parameter** | **Description** |
| Weekday | One of the weekdays from Monday to Sunday, First and Last. |

###### Weekly Trade Day Rule

#FS10023\_S0030\_03500

The Weekly Trade Day Rule specifies a day within the week by trade day. It will use the “current referencing holiday calendar” to determine trade days.

The rule accepts 1 parameter:

|  |  |
| --- | --- |
| **Parameter** | **Description** |
| Day | There are 2 selectable values:   * The first trading day of the week * The last trading day of the week |

##### Daily Rules

#FS10023\_S0030\_03550

There is 1 rule available in the Daily Rule catalogue:

* Current Day Rule

###### Current Day Rule

#FS10023\_S0030\_03560

The Current Day Rule specifics the provided date as the starting point of the Last Trading Date calculation for Daily Instruments.

No parameters is required for this rule.

#### Day Adjustment Rules

#FS10023\_S0030\_03600

Day Adjustment Rules move forward or backward the calculating date.

There are 3 rules available in Day Adjustment Rules catalogue:

* Delta Trade Day
* Delta Trade Day on Holiday
* Delta Calendar Day

###### Delta Trade Day Rule

#FS10023\_S0030\_03700

Delta Trade Day Rule move forward or backward the calculating date by number of trading days. It will use the “current referencing holiday calendar” to determine trade days.

The rule accepts 1 parameter:

|  |  |
| --- | --- |
| **Parameter** | **Description** |
| Delta | The number of trading days to move from the calculating date.  It accepts value from -31 to +31. |

###### Delta Trade Day on Holiday Rule

#FS10023\_S0030\_03800

Delta Trade Day on Holiday Rule move forward or backward the calculating date by number of trading days when the current calculating date is a holiday in the “current reference holiday calendar”.

The rule accepts 1 parameter:

|  |  |
| --- | --- |
| **Parameter** | **Description** |
| Delta | The number of trading days to move from the calculating date when the calculating date is on holiday.  It accepts value from -31 to +31. |

###### Delta Calendar Day Rule

#FS10023\_S0030\_03900

Delta Trade Day Rule move forward or backward the calculating date by number of calendar days. It does not consider trading holiday.

The rule accepts 1 parameter:

|  |  |
| --- | --- |
| **Parameter** | **Description** |
| Delta | The number of calendar days to move from the calculating date.  It accepts value from -31 to +31. |

#### Calendar Rules

#FS10023\_S0030\_04000

Calendar Rules change the “current referencing holiday calendar”.

There is 1 rule available in Calendar Rule catalogue:

* Using Regional Calendar

###### Using Regional Calendar Rule

#FS10023\_S0030\_04100

Using Regional Calendar Rule change the “current referencing holiday calendar” to a regional calendar.

The rule accepts 1 parameter:

|  |  |
| --- | --- |
| **Parameter** | **Description** |
| Regional Calendar | The name of the Regional Calendar configuration. The configuration contains both normal trading weekdays and holidays definition.  The value can be empty to remove reference to any Regional Calendar, and Product Calendar is selected. |
| Product Calendar | A true / false attribute to include trading calendar from product structure.  When true, a date is considered a trading day only when it is both a trading day in the Regional Calendar and from the product calendar. Otherwise, the product calendar is ignored.  Notes: When Regional Calendar is Empty, Product Calendar must be true. |

### Regional Calendar

#FS10023\_S0030\_04200

The Regional Calendar configuration defines trading date for a specific regional. It consists of 2 attributes:

|  |  |
| --- | --- |
| **Attributes** | **Description** |
| Normal Trading Weekdays | The weekdays of trading days.  E.g.   |  |  |  |  |  |  |  |  | | --- | --- | --- | --- | --- | --- | --- | --- | |  | **Mon** | **Tue** | **Wed** | **Thu** | **Fri** | **Sat** | **Sun** | | **Trade**  **Day** | √ | √ | √ | √ | √ |  |  | |
| Holiday List | A list of holidays.  E.g.   |  | | --- | | **Holidays** | | 1 Jan 2024 | | 1 Jan 2025 | | 1 Jan 2026 | | ….. | |
| MIC Codes | A list of MIC codes relevant to the regional calendar.  The list is for a file upload function to automatically input holidays to the regional calendar based on Exchange (by MIC) holidays. |

#### Upload Regional Calendar

#FS10023\_S0030\_04250

An upload file function is provided to allow exchange operation to import non-trading date for Regional Calendar.

The file should be in CSV format, 1 non-trading date per line, with the following columns:

* MIC code
* Date (non-trading date)

After the file is accepted and before submitting the changes to ODP, user can preview / export the following:

1. Changes of non-trading dates.
2. Last trading date per contract.

### Examples

#FS10023\_S0030\_04300

Example 1

|  |  |
| --- | --- |
| Last Trading Day | The second last Trading Day of the Contract Month |

Configuration

|  |  |  |
| --- | --- | --- |
| **Num** | **Rule** | **Parameters** |
| 1 | Monthly Trade Day | Month Delta = 0  Day = The last trading day of the month |
| 2 | Delta Trade Day | Delta = -1 |

Example 2

|  |  |
| --- | --- |
| Last Trading Day | The third Friday of the Contract Month and if it is not a Trading Day, the Last Trading Day shall be the preceding Trading Day |

Configuration

|  |  |  |
| --- | --- | --- |
| **Num** | **Rule** | **Parameters** |
| 1 | Monthly Weekday | Weekday = Friday  Week in Month = 3rd  From Month End = false |
| 2 | Delta Trade Day on Holiday | Delta = -1 |

Example 3

|  |  |
| --- | --- |
| Last Trading Day | The last Thursday of the Contract Month and if it is not a Trading Day or not a business day in India, the Last Trading Day will be the preceding Trading Day which is also a business day in India |

Configuration

|  |  |  |
| --- | --- | --- |
| **Num** | **Rule** | **Parameters** |
| 1 | Monthly Weekday | Weekday = Thursday  Week in Month = 1st  From Month End = true |
| 2 | Using Regional Calendar | Regional Calendar = India  Product Calendar = true |
| 3 | Delta Trade Day on Holiday | Delta = -1 |

Example 4

|  |  |
| --- | --- |
| Last Trading Day | The last Trading Day of the Contract Month. If the Last Trading Day falls on a Malaysia public holiday, the Last Trading Day will be the preceding Trading Day which is also a business day in Malaysia |

Configuration

|  |  |  |
| --- | --- | --- |
| **Num** | **Rule** | **Parameter** |
| 1 | Monthly Trade Day | Month Delta = 0  Day = The last trading day of the month |
| 2 | Using Regional Calendar | Regional Calendar = Malaysia  Product Calendar = true |
| 3 | Delta Trade Day on Holiday | Delta = -1 |

Example 5

|  |  |
| --- | --- |
| Last Trading Day | The Last Trading Day of a Contract shall be two Trading Days before the third (3rd) Wednesday of the Contract Month |

Configuration

|  |  |  |
| --- | --- | --- |
| **Num** | **Rule** | **Parameters** |
| 1 | Monthly Weekday | Weekday = Wednesday  Week in Month = 3rd  From Month End = false |
| 2 | Delta Trade Day | Delta = -2 |

Example 6

|  |  |
| --- | --- |
| Expiry Day | The last Trading Day of the Contract Week |

Configuration

|  |  |  |
| --- | --- | --- |
| **Num** | **Rule** | **Parameters** |
| 1 | Weekly Trade Day | Day = The last trading day of the week |

Example 7

|  |  |
| --- | --- |
| Last Trading Day | The second last Trading Day of the Contract Month, provided that it is a common business day on which all component stocks of the index are open for trading. If the Last Trading Day is not a common business day, the Last Trading Day shall be the preceding Trading Day which is a common business day |

Configuration

|  |  |  |
| --- | --- | --- |
| **Num** | **Attribute** | **Value** |
| 1 | Using Regional Calendar | Regional Calendar = Index Common Calendar  Product Calendar = true |
| 2 | Monthly Trade Day | Month Delta = 0  Day = The last trading day of the month |
| 3 | Delta Trade Day | Delta = -1 |

Example 8

|  |  |
| --- | --- |
| Last Trading Day | The Last Trading Day determined by The London Metal Exchange for its Aluminium Futures Contract, which is two London Business Days before the third Wednesday of the Spot Month  If it is not a Trading Day, the Last Trading Day shall be the immediately preceding Trading Day |

Configuration

|  |  |  |
| --- | --- | --- |
| **Num** | **Rule** | **Parameters** |
| 1 | Using Regional Calendar | Regional Calendar = London  Product Calendar = false |
| 2 | Monthly Weekday | Weekday = Wednesday  Week in Month = 3rd  From Month End = false |
| 3 | Delta Trade Day | Delta = -2 |
| 4 | Using Regional Calendar | Regional Calendar = Empty  Product Calendar = true |
| 5 | Delta Trade Day on Holiday | Delta = -1 |

Example 9

|  |  |
| --- | --- |
| Last Trading Day | 30 calendar days prior to the second last Trading Day of the calendar month immediately following the Contract Month. If it is not a Trading Day, the Last Trading Day shall be the immediately preceding Trading Day |

Configuration

|  |  |  |
| --- | --- | --- |
| **Num** | **Rule** | **Parameters** |
| 1 | Monthly Trade Day | Month Delta = +1  Day = The last trading day of the month |
| 2 | Delta Trade Day | Delta = -1 |
| 3 | Delta Calendar Day | Delta = -30 |
| 4 | Delta Trade Day on Holiday | Delta = -1 |

## Last Trading Date Calendar

#FS10023\_S0030\_04400

Last Trading Date Calendar provides another way to define last trading date by manual assignment. It is alternative to Last Trading Date Formula and no calculation is involved. It can be used for cases where the contract term is not supported by Last Trading Date Formula.

Daily cycle is not supported.

There are 2 types of calendars, configuration is allowed to either one of them:

* Monthly
* Weekly

### Monthly Last Trading Date Calendar

#FS10023\_S0030\_04500

For Monthly Last Trading Date Calendar, a table of [Year x Month] is presented for input day of month in each calendar month. All day inputs are optional, generation on month without value will be skipped and give warning.

Example:

|  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| **Year** | **Jan** | **Feb** | **Mar** | **Apr** | **May** | **Jun** | **Jul** | **Aug** | **Sep** | **Oct** | **Nov** | **Dec** |
| 2024 | 30 | 28 | 27 | 29 | 30 | 27 | 30 | 29 | 27 | 30 | 28 | 30 |
| 2025 | 27 | 27 | 28 | 29 | 29 | 27 | 30 | 28 | 29 | 30 | 27 | 30 |
| … | … | … | … | … | … | … | … | … | … | … | … | … |
| 2029 | - | - | - | - | - | - | - | - | - | - | - | 28 |

### Weekly Last Trading Date Calendar

#FS10023\_S0030\_04600

For Weekly Last Trading Date Calendar, a default and a list of specific [Week number] is presented for input weekday in each week per year.

Example:

|  |  |
| --- | --- |
| **Attributes** | **Value** |
| Year | 2024 |
| Default | Friday |
| Specific | |  |  | | --- | --- | | **Week** | **Weekday** | | 41 | Thursday | | … | … | |

## Lifecycle Time Rule

#FS10023\_S0030\_04700

The Lifecycle Time Rule defines the time moment the order book started trading on the First trading date and time moment the order book stopped trading on the Last trading date.

It includes the following attributes:

|  |  |
| --- | --- |
| **Attributes** | **Description** |
| Normal Trading Day Last Trading Time | It defines the time (exclusive) on last trading date the order book stopped trading when it is a normal trading day in product timetable.  The time format is in HH:mm:ss, e.g. 16:00:00. |
| Normal Trading Day DST Enabled | A true / false attribute. When true, DST adjustment applies to Normal Day Last Trading Time. Otherwise, DST Adjustment does not apply. |
| Half Trading Day Last Trading Time | It defines the time (exclusive) on last trading date the order book stopped trading when it is a half trading day in product timetable.  The time format is in HH:mm:ss, e.g. 12:00:00. |
| Half Trading Day DST Enabled | A true / false attribute. When true, DST adjustment applies to Half Trading Day Last Trading Time. Otherwise, DST Adjustment does not apply. |
| First Trading Time | It defines the time moment (inclusive) on first trading date the order book started trading.  The attribute is optional, it accepts a time value of format “HH:mm:ss”. When it is empty, it means to start trading according to trading timetable just like the other days. |
| DST Adjustment | A reference to Last Trading Time DST configuration for this rule detailed in next section. |

### DST Adjustment

#FS10023\_S0030\_04800

DST adjustment configuration defines day ranges per year to adjust Last Trading Time on Last Trading Date.

The configuration attributes are:

* Date Ranges
* Adjustment in Minutes

#### Date Ranges

#FS10023\_S0030\_04900

Date Ranges define the From Date and To Date in a year. The adjustment is effective when the system date fall between them.

A table is presented for input the day range per year illustrated below:

|  |  |  |
| --- | --- | --- |
| **Year** | **From Date** | **To Date** |
| 2024 | 31 March | 27 Oct |
| 2025 | 30 March | 26 Oct |
| … | … | … |
| 2029 | … | … |

#### Adjustment in Minutes

#FS10023\_S0030\_05000

Adjustment in Minutes defines the number of minutes plus or minus to the Last Trading Time.

For example, when Normal Trading Day Last Trading Time is 16:00:00, -60 minutes adjustment will result in 15:00:00. All time values are in system time (HKT).

# Automatic Combo Generation

#FS10023\_S0040\_00100

Automatic Combo Generation creates Combos based on configuration rules which describe leg contracts. The configuration data model is shown in the following diagram.

Note that, Futures contracts are supported only.

![](data:image/x-wmf;base64...)

Auto Combo Generation consist of a list of Rule Groups, and each of them contains a set of rules to generate combo contract. The max number of Rule Groups support is 5,000.

In the Rule Group, the following attributes serves the same purpose as the one from Auto Instrument Generation.

* Unit
* Until Days to Last Trading
* Pre-launch Days
  + One-off Pre-launch

The Unit supports Monthly only.

The Until Days to Last Trading concerns on Last Trading Date of all leg contracts, and Pre-launch Days concerns on the First Trading Date of all leg contracts.

Aside from the above similarity to Auto Instrument Generation, the Rule Group has the following attributes:

* Name – for identification.
* List of Combo Rule – to generate combo contracts.
* Enabled – A On/Off switch for the Rule Group.

The Enabled switch allows enable or disable the whole group of combo rules.

## Combo Rules

#FS10023\_S0040\_00200

Combo Rules contains a list of user defined rules. The rules in the list will be executed sequentially and each of them will select combo leg contracts to form a single or multiple combo contracts.

Maximum 20 rules are allowed in the list.

There are 3 available rules for configuration:

* Manual Link Rule
* Multiple Link Rule
* Banker Link Rule

### Manual Link Rule

#FS10023\_S0040\_00300

The Manual Link Rule defines a single combo contract by manually specify leg contracts relative to the spot month. It supports

The rule contains 3 parameters:

* Description
* Combo Class
* Multiple leg contracts

The Combo Class is the parent node of the Combo in Product Structure.

The max number of leg contracts allowed is same to the limit from Product Structure, which is 2. Standard Combo should always only be composed of 2 leg contracts.

For each leg contract, 5 parameters are required as follows:

* Instrument Class
* Contracts from Spot
* Month Selection
* Operation
* Ratio

#### Instrument Class

#FS10023\_S0040\_00400

Instrument Class of leg contracts.

#### Contracts from Spot and Month Selection

#FS10023\_S0040\_00500

Contracts from Spot defines the number of existing contracts from current month ordered by last trading date. By default, it is counting all existing contracts.

It accepts value from 0 to 30, the value of “0” means the current contract, value “1” means the next contract.

In the example below, 2 contracts from the current month in September 2024 and the Instrument Class is AAAFUT is AAAZ4.

|  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | **Sep** | **Oct** | **Nov** | **Dec** | **Jan** | **Feb** | **Mar** | **Apr** | **May** | **Jun** |
| **Contracts** | AAAU4 | AAAV4 |  | AAAZ4 |  |  | AAAH5 |  |  | AAAM5 |

The Month Selection controls what contract to count. The available values for Month Selection are listed below:

|  |  |
| --- | --- |
| **Value** | **Description** |
| All Month | Every single contract is considered. |
| Even Month | Only contracts in even months are considered. |
| Odd Month | Only contracts in odd months are considered. |
| Quarterly Month | This option is available to Monthly Unit only.  Only contracts in Mar, Jun, Sep and Dec are considered. |
| Half-yearly Month | This option is available to Monthly Unit only.  Only contracts in Jun and Dec are considered. |
| Yearly Month | This option is available to Monthly Unit only.  Only contracts in Dec are considered. |

#### Operation

#FS10023\_S0040\_00600

The operation attribute allows value of either “Buy” or “Sell”.

* Buy – Buying the leg contract when buy the combo instrument. Vice versa, selling the leg contract when sell the combo instrument.
* Sell – Selling the leg contract when buy the combo instrument. Vice versa, buying the leg contract when sell the combo instrument.

#### Ratio

#FS10023\_S0040\_00700

The Ratio attribute allows value of positive number. The ratio of X on a leg contract means buying or selling 1 quantity of the combo instrument will result in buying or selling X quantity of leg contracts.

#### Examples

#FS10023\_S0040\_00800

For a combo with monthly leg contracts configuration:

|  |  |
| --- | --- |
| **Leg** | **Configuration** |
| 1 | |  |  | | --- | --- | | Instrument Class | AAAFUT | | Contracts from Spot | 1 | | Month Selection | All Month | | Operation | Buy | | Ratio | 1 | |
| 2 | |  |  | | --- | --- | | Instrument Class | AAAFUT | | Contracts from Spot | 0 | | Month Selection | All Month | | Operation | Sell | | Ratio | 1 | |
| 3 | Empty |
| 4 | Empty |

With the spot contract month Sep 2024 and the following existing leg contracts:

|  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | **Sep** | **Oct** | **Nov** | **Dec** | **Jan** | **Feb** | **Mar** | **Apr** | **May** | **Jun** |
| **Contracts** | AAAU4 | AAAV4 |  | AAAZ4 |  |  | AAAH5 |  |  | AAAM5 |

The result will be:

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
| **Item No.** | **Instrument Name** | **Leg 1** | **Leg 2** | **First Trading Date Time from Contract** | **Last Trading Date Time from Contract** |
| 1 | AAAU4/V4 | AAAV4 | AAAU4 | AAAV4 | AAAU4 |

Note: Details on First / Last Trading Date / Time refer to Other Attributes section below.

### Multiple Link Rule

#FS10023\_S0040\_00900

The Multiple Link Rule create 2 legs time spread combo contracts by choosing futures contracts nearest to the current month and link them up with all possible combination. Only Monthly Unit is supported.

The parameters required in Multiple Link Rule:

* Description
* Instrument Class
* Leg Contracts
* Month Selection
* Min. Time Spread

#### Instrument Class

#FS10023\_S0040\_01000

Instrument Class of leg contracts.

#### Leg Contracts

#FS10023\_S0040\_01100

The number of contracts selected that nearest to the current month ordered by last trading date under the Instrument Class.

It accepts value from 2 to 30, or empty. Empty value means selecting all available contracts.

#### Month Selection

#FS10023\_S0040\_01200

The Month Selection defines which existing contracts to select same as the one in Manual Link Rule.

#### Min. Time Spread

The Min. Time Spread allows the combo rule to select Combo Class for generated contracts. It specifies the minimum time interval (in months) for the type of contract generated by this rule.

When a contract is generated, the rule calculates time spread level by the last trading date (LTD) difference in months between the 2 legs and divided by Min. Time Spread value.

For example, with Min Time Spread 1 and a generated contract with Leg 1 LTD in Nov-2025 and Leg 2 LTD in Sep-2025, the time spread level is 2. A combo class with combo group having time spread level 2 will be selected.

The possible values available to Min Time Spread is related to the selection of Month Selection. They are listed as below:

|  |  |
| --- | --- |
| **Month Selection** | **Possible values for Min. Time Spread** |
| ALL Month | 1 |
| Even Month | 1, 2 |
| Odd Month | 1, 2 |
| Quarter Month | 1, 3 |
| Half-yearly Month | 1, 3, 6 |
| Yearly Month | 1, 3, 6, 12 |

#### Combo Criteria

#FS10023\_S0040\_01300

The system follows a set of rules below to choose the leg contracts for the combo:

* Only 2 leg contracts are supported.
* The 2 leg contracts must be having different Last Trading Date.
* The combo must be unique; All combos are having different leg contracts combination.
* The contract with earlier Last Trading Date is marked as Leg 2, while the contract with later Last Trading Date is marked as Leg 1.
* The operation of the Leg 2 is Sell, while the Leg 1 is Buy.
* Leg ratio is 1.

#### Examples

#FS10023\_S0040\_01400

For Multiple Link Rule configuration as below:

|  |  |
| --- | --- |
| **Configuration** | **Value** |
| Instrument Class | HSIFUT |
| Linking Range | 5 |
| Month Selection | All Month |

And the contract’s cycle list configuration as below:

|  |  |
| --- | --- |
| **Configuration** | **Value** |
| Cycle List in Cycle Class | Block 1: ref+1, ref+2, ref+3, ref+4, ref+1q, ref+2q, ref+3q  Block 2: ref+1h, ref+2h, ref+3h, ref+1y, ref+2y, ref+3y |

When spot contract month is June 2024 (the ref+1 cycle in Block 1), contracts selected for the combo are as below:

|  |  |
| --- | --- |
| **Contract No.** | **Month** |
| 1 | June |
| 2 | July |
| 3 | August |
| 4 | September |
| 5 | December |

The combo contracts generated according to the rule will be:

|  |  |  |  |
| --- | --- | --- | --- |
| **Combo No.** | **Contract No. Combination** | **Leg 1 Contract Month** | **Leg 2 Contract Month** |
| 1 | 1-2 | July | June |
| 2 | 1-3 | August | June |
| 3 | 1-4 | September | June |
| 4 | 1-5 | December | June |
| 5 | 2-3 | August | July |
| 6 | 2-4 | September | July |
| 7 | 2-5 | December | July |
| 8 | 3-4 | September | August |
| 9 | 3-5 | December | August |
| 10 | 4-5 | December | September |

### Banker Link Rule

#FS10023\_S0040\_01500

The Banker Link Rule create 2 leg combo contracts by using banker contract(s) to link up with a list of other contracts. Only Monthly Unit is supported.

The parameters required in Banker Link Rule:

* Description
* Instrument Class
* Banker Contracts Parameters
* Leg Contracts Parameters
* Min. Time Spread

#### Instrument Class

#FS10023\_S0040\_01600

Instrument Class of leg contracts.

#### Banker Contracts Parameters

#FS10023\_S0040\_01700

Banker Contract Parameters defines parameters to select banker contract(s).

##### Selection Type

#FS10023\_S0040\_01800

Selection Type defines how to choose the Banker Contract(s). It accepts either “Relative” or “Absolute” and each of them are described in next sections.

##### Relative Parameters

#FS10023\_S0040\_01900

Relative Parameters are for “Relative” Selection Type. It allows selecting the banker contract by the following input:

* Contract From Spot
* Month Selection

Their definitions are same as the one from Manual Link Rule. Maximum 1 contract will be selected.

For Relative Banker Contract, the choice of Min. Time Spread is the overlapped choice based on the Month Selection of Banker Contract and Leg Contract.

**Example 1.**
- Banker Contract is defined as:
Selection Type = Relative; Contracts from Spot = 1 of “Quarter Month” (1, 3)
-Leg Contract is defined as:
Month Selection = Half Year (1, 3, 6).

The available choice of Min. Time Spread is (1, 3).

**Example 2.**
- Banker Contract is defined as:
Selection Type = Relative; Contracts from Spot = 1 of “Even Month” (1, 2)
-Leg Contract is defined as:
Month Selection = Quarter (1, 3).

The available choice of Min. Time Spread is (1).

##### Absolute Parameters

#FS10023\_S0040\_02000

Absolute Parameters are for “Absolute” Selection Type. It allows selecting the banker contract by the following input:

* Month

The Month parameter selects contracts in specific Month. All contracts having Last Trading Date in the specified Month are selected. When there is more than one contract in different years with the same month, all of them are selected.

For Absolute Banker Contract, the choice of Min. Time Spread is the overlapped choice based on type of Month of Banker Contract and Leg Contract.

**Example 1.**
- Banker Contract is defined as:
Type is default as Absolute, Month = Sep; September can align with Quarter month (1,3).
- Leg Contract is defined as:
Month Selection = Half Year (1, 3, 6).

The available choice of Min. Time Spread is (1, 3).

**Example 2.**
- Banker Contract is defined as:
Type is default as Absolute, Month = Apr; April can only align to All Month (1).
- Leg Contract is defined as:
Month Selection = Quarter (1).

The available choice of Min. Time Spread is (1).

#### Leg Contracts Parameters

#FS10023\_S0040\_02100

The Other Contracts Parameters defines contracts that link with banker contract(s).

There are 3 parameters required:

* Leg Contracts
* From Contract
* Month Selection

##### Leg Contracts

#FS10023\_S0040\_02200

The number of nearest contracts ordered by last trading date, from “From Reference” mentioned in next section.

The selected contracts are each link up with the banker contract to form a 2 legs combo.

It accepts value from 2 to 30, or empty. Empty value means selecting all available contracts.

##### From Reference

#FS10023\_S0040\_02300

The From Reference allows either Spot or Banker.

* When Spot is selected, nearest contracts from current month are selected.
  + In case of multiple Banker contracts, they are linked up to the same set of selected leg contracts.
* When Banker is selected, nearest contracts after the Banker contract(s) are selected.
  + In case of multiple Banker contracts, they are linked up to their individual set of next nearest contracts.

##### Month Selection

#FS10023\_S0040\_02400

Month Selection controls what contract to count same as the one from Manual Link Rule.

#### Min. Time Spread

The Min. Time Spread is same as the one in Multiple Link Rule.

#### Combo Criteria

#FS10023\_S0040\_02500

The Combo Criteria are same as the one in Multiple Link Rule.

#### Example

#FS10023\_S0040\_02600

For Banker Link Rule configuration as below:

|  |  |
| --- | --- |
| **Configuration** | **Value** |
| Instrument Class | HSIFUT |
| Banker Contracts Section | |
| Selection Type | Relative |
| Contracts from Spot | 0 |
| Month Selection | All Month |
| Leg Contracts Section | |
| Leg Contracts | 2 |
| From Reference | Banker |
| Month Selection | All Month |

And the contract’s cycle list configuration as below:

|  |  |
| --- | --- |
| **Configuration** | **Value** |
| Cycle List in Cycle Class | Block 1: ref+1, ref+2, ref+3, ref+4, ref+1q, ref+2q, ref+3q  Block 2: ref+1h, ref+2h, ref+3h, ref+1y, ref+2y, ref+3y |

When spot contract month is June 2024 (the ref+1 cycle in Block 1):

The banker contract selected is as below:

|  |  |
| --- | --- |
| **Contract No.** | **Month** |
| B1 | June |

The Leg contracts selected are as below:

|  |  |
| --- | --- |
| **Contract No.** | **Month** |
| L1 | July |
| L2 | August |

The combo contracts generated according to the rule will be:

|  |  |  |  |
| --- | --- | --- | --- |
| **Combo No.** | **Contract No. Combination** | **Leg 1 Contract Month** | **Leg 2 Contract Month** |
| 1 | B1-L1 | July | June |
| 2 | B1-L2 | August | June |

## Other Combo Attributes

#FS10023\_S0040\_02700

|  |  |
| --- | --- |
| **Attributes** | **Value** |
| First Trading Date | The latest First Trading Date from both legs. |
| First Trading Time | The First Trading Time from the leg having latest First Trading Date. When both legs are having same First Trading Date, the latest First Trading Time from both legs is selected. |
| Last Trading Date | The earliest Last Trading Date from both legs. |
| Last Trading Time | The Last Trading Time from the leg having earliest Last Trading Date. When both legs are having same Last Trading Date, the earliest Last Trading Time from both legs is selected. |

# Creation Ordering

#FS10023\_S0050\_00100

For either auto generation or file upload, new order books are created in the following ordering:

![](data:image/x-wmf;base64...)

Notes: Futures Combos are created at last so that all referred leg contracts already exist.

# Creation Logic

#FS10023\_S0060\_00100

New order books creation is triggered by operation user.

For Auto Generation, the system follows the below steps for new order books:

1. Generate order books for ALL Instrument Class with Auto Generation Rule attached.
2. Reduce those that already exist in the system.
   1. The system uses Instrument Name attribute as key to determine the Instrument existence. In case the Instrument exists but has a different Last Trading Date, an update action will be done.
3. Show the final list of order books for maker submission.
4. Show the submitted order books for checker approval.

For File Upload, the steps are similar except that the source of order books are from file upload instead of generation from rules:

1. Parse CSV file uploaded for order books.
2. Same as Auto Generation.
3. Same as Auto Generation.
4. Same as Auto Generation.

# Instrument Name Standard

#FS10023\_S0070\_00100

The instrument name standard ensures that each instrument has a unique name by combining various properties. The choice of which properties to include is optional, with common ones being underlying asset, last trading date and strike price. The instrument name is limited to 32 characters, and the order of properties is determined by their assigned position. The standard allows for flexibility across different instrument types and promotes clarity and consistency in instrument identification.

**Instrument Name Type**It specifies the Instrument Group type of the Instrument Name in Futures or Options. Its purpose is to predefine the available categories and ensure that the name standard has been accurately assigned to the instrument group.

**Instrument Name Field**The Instrument Name defined by a category list with corresponding properties according to the sequence of position.

|  |  |
| --- | --- |
| **Attributes** | **Description** |
| Position | The sequence of the category composited in the Instrument Name |
| Category | The available category and it’s corresponding properties   * Underlying Refer to the corresponding Underlying of the Instrument and specify the leftmost number of characters to be used from the Underlying. 0 characters means using entire Underlying name. Max. 6 characters allowed. When Underlying is shorter than the specified value, the Underlying length is used. * Last Trading Date Refer to the Last Trading Date of the contract and specify the \*date format for the Instrument Name. * Strike price integer part (only for Options Type) Refer to the integer part of the strike price and specify the number of characters to truncate from the end of the strike price. 0 characters means no truncating. Max. 17 characters to truncate is allowed. When the price is shorter than or equals to the truncate length, all but the leftmost digits is truncated. * Strike price decimal part (only for Options Type) Refer to the strike price decimal part displayed with the number of most significant decimals specified. When using this property, the decimals will always be displayed, even if there are no decimals in the Strike price. Min. 0 to max. 18 characters allowed. When 0 is specify, the number of decimals follows Decimals for Strike Price attribute in Instrument Class, when the value is higher than the number of digits in strike price decimal part, digit 0 is filled to the right. * Free text Specific a free text or special sign in the Instrument Name. Min. 1 to max. 32 characters allowed. * Short name instrument group Refer to the short name of the instrument group as defined in the Instrument Type. 0 characters means using entire short name. Max. 15 characters allowed. When short name is shorter than the specified value, the short name length is used. * Contract size Refer to the Contract size defined in the corresponding Instrument Class and no properties needed to be specified.   \* Date Formats available:   * Year(YYYY): Displayed as 2000-2999. * Year(YY) : Reference from the last 2 digit in Year and display as 00-99. * Year(Y): Reference from the last digit in Year and display as 0-9. * Month code: Translate from Period Codes defined in the Month Code. * Month number(NN): Displayed as 01-12. * Month name(MMM): Displayed as JAN-DEC. * Date(DD): Displayed as 01-31. * Week number(WW): Displayed as 01-53. |

## Examples

#FS10023\_S0070\_00200

HSI Futures

|  |  |  |  |
| --- | --- | --- | --- |
| **ID** | | FUT | |
| **Name Type** | | * Futures | |
|  | | | |
| **Position** | **Category** | **Properties** | |
|  | * Underlying | Number of Character | 3 |
|  | * Last Trading Date | Date Format | * Month Code |
|  | * Last Trading Date | Date format | * Year (Y) |

STOCK Options

|  |  |  |  |
| --- | --- | --- | --- |
| **ID** | | S\_OPT | |
| **Name Type** | | * Options | |
|  | | | |
| **Position** | **Category** | **Properties** | |
|  | * Underlying | Number of Character | 3 |
|  | * Strike price integer part | Number of Character | 0 |
|  | * Free Text | . | |
|  | * Strike price decimal part | Number of Decimal | 2 |
|  | * Last Trading Date | Date format | * Month Code |
|  | * Last Trading Date | Date format | * Year (Y) |

Weekly Stock Options

|  |  |  |  |
| --- | --- | --- | --- |
| **ID** | | WIO | |
| **Name Type** | | * Options | |
|  | | | |
| **Position** | **Category** | **Properties** | |
|  | * Underlying | Number of Character | 3 |
|  | * Strike price integer part | Number of Character | 0 |
|  | * Last Trading Date | Date Format | * Month Code |
|  | * Last Trading Date | Date format | * Year (Y) |
|  | * Free Text | W | |
|  | * Last Trading Date | Date format | * Date (DD) |

Options with Negative Strike Price

|  |  |  |  |
| --- | --- | --- | --- |
| **ID** | | ??? | |
| **Name Type** | | * Options | |
|  | | | |
| **Position** | **Category** | **Properties** | |
|  | * Underlying | Number of Character | 3 |
|  | * Strike price integer part | Number of Character | 0 |
|  | * Free Text |  | - |
|  | * Last Trading Date | Date Format | * Month Code |
|  | * Last Trading Date | Date format | * Year (Y) |

# Combo Name Standard

#FS10023\_S0080\_00100

The name standard ensures that each Combo instrument has a unique name by combining various properties. The choice of which properties to include is optional, with common ones being underlying asset, last trading date and strike price. The Combo name is limited to 32 characters, and the order of properties is determined by their assigned position. The standard allows for flexibility across different Combo types and promotes clarity and consistency in Combo identification.

**Combo Name Type**

It’s pre-defined as Combo and the categories for combo are available in the categories and used for validating the name standard when assigned to the instrument group.

|  |  |
| --- | --- |
| **Attributes** | **Description** |
| Position | The sequence of the properties composited in the Instrument Name |
| Category | The available category and it’s corresponding properties. The information refers to the Leg Number contract defined in the combo contract.   * Underlying Refer to the corresponding Underlying of the Leg contract and specify the number of characters to be used from the Underlying. 0 characters means using entire Underlying name. Max. 6 characters allowed. When Underlying is shorter than the specified value, the Underlying length is used. * Last Trading Date Refer to the Last Trading Date of the contract and specify the \*date format for the Instrument Name. * Free text Specific a free text or special sign in the Instrument Name. Min. 1 to max. 32 characters allowed. * Short name instrument group Refer to the short name of the instrument group as defined in the Instrument Type. 0 characters means using entire short name. Max. 15 characters allowed. When short name is shorter than the specified value, the short name length is used. * Contract size Refer to the Contract size defined in the corresponding Instrument Class and no properties needed to be specified. * Short name strategy The short name of the strategy as defined in the Strategy. 0 characters means using entire short name. Max. 15 characters allowed. When short name is shorter than the specified value, the short name length is used. * Short name combo group Refer to the short name of the corresponding combo group. 0 characters means using entire short name. Max. 15 characters allowed. When short name is shorter than the specified value, the short name length is used. * Strike price integer part Refer to the integer part of the strike price and specify the number of characters to truncate from the end of the strike price. 0 characters means no truncating. Max. 17 characters to truncate is allowed. When the price is shorter than or equals to the truncate length, all but the leftmost digits is truncated. * Strike price decimal part Refer to the strike price decimal part displayed with the number of decimals specified. When using this property, the decimals will always be displayed, even if there are no decimals in the Strike price. Min. 0 to max. 18 characters allowed. When 0 is specify, the number of decimals follows Decimals for Strike Price attribute in Instrument Class, when the value is higher than the number of digits in strike price decimal part, digit 0 is filled to the right.   \* Date Formats available:   * Year(YYYY): Displayed as 2000-2999. * Year(YY) : Reference from the last 2 digit in Year and display as 00-99. * Year(Y): Reference from the last digit in Year and display as 0-9. * Month code: Translate from Period Codes defined in the Month Code. * Month number(NN): Displayed as 01-12. * Month name(MMM): Displayed as JAN-DEC. * Date(DD): Displayed as 01-31. * Week number(WW): Displayed as 01-53. |
| Instrument Leg Number | The Leg number is the designated identifier for a specific category reference.  For example, if the Leg 2 corresponds to the last trading date category, it signifies the last trading date of the Combo contract’ Instrument contract for Leg 2.  Leg Number does not applicable to Free text and Short name strategy category. |

## Example

Example for standard combo:

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
| **ID** | | FTS | | |
| **Name Type** | | * Combo | | |
|  | | | | |
| **Position** | **Category** | **Properties** | | **Leg Number** |
|  | * Underlying | Number of Character | 3 | 1 |
|  | * Last Trading Date | Date Format | * Month code | 2 |
|  | * Last Trading Date | Date Format | * Year (Y) | 2 |
|  | * Free Text | / | | N/A |
|  | * Last Trading Date | Date Format | * Month code | 1 |
|  | * Last Trading Date | Date Format | * Year (Y) | 1 |

Example for TMC:

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
| **ID** | | TMC | | |
| **Name Type** | | * Combo | | |
|  | | | | |
| **Position** | **Category** | **Properties** | | **Leg Number** |
|  | * Free Text | TMC\_ | | N/A |
|  | * Underlying | Number of Character | 3 | 1 |

Notes: The system will append a “/” and followed by a 3 – 5 digits per underlying TMC sequence number to the end of TMC name.

# Month Code

#FS10023\_S0090\_00100

It is for defining the period code for the Instrument Name Standard to translate from Month to specific code.

The definition is defined as below:

|  |  |  |  |
| --- | --- | --- | --- |
|  | **Futures** | **Calls** | **Puts** |
| **Jan** | F | A | M |
| **Feb** | G | B | N |
| **Mar** | H | C | O |
| **Apr** | J | D | P |
| **May** | K | E | Q |
| **Jun** | M | F | R |
| **Jul** | N | G | S |
| **Aug** | Q | H | T |
| **Sep** | U | I | U |
| **Oct** | V | J | V |
| **Nov** | X | K | W |
| **Dec** | Z | L | X |

# Appendix I. First Trading Date Calculation

#FS10023\_S0100\_00100

First Trading Date (FTD) Formula

FTD = MAX (LTD (Spot Contract Month / Week - 1) + 1, Next Trade Date)

Example 1

Cycle Unit: Monthly

Cycle List: Spot, Spot+1

Last Trading Dates (LTD) of Monthly Contract: 26-Apr, 29-May, 26-Jun, 29-Jul (2024)

Pre-launch Days: +3

|  |  |  |  |
| --- | --- | --- | --- |
| **Trading Date** | **Spot Contract Month** | **Spot cycle** | **Spot + 1 cycle** |
| 23-May | May | Generate for next trade date (24-May):  LTD = 29-May  FTD = MAX (LTD (May - 1) + 1, 24-May)  = MAX (29-Apr, 24-May)  = 24-May  =================================  Generate for pre-launch (29-May):  LTD = 29-May  (No generation needed for same LTD) | Generate for next trade date (24-May):  LTD = 26-Jun  FTD = MAX (LTD (May - 1) + 1, 24-May)  = MAX (29-Apr, 24-May)  = 24-May  =================================  Generate for pre-launch (29-May):  LTD = 26-Jun  (No generation needed for same LTD) |
| 24-May | May | Generate for next trade date (27-May):  LTD = 29-May  FTD = MAX (LTD (May - 1) + 1, 27-May)  = MAX (29-Apr, 27-May)  = 27-May  =================================  Generate for pre-launch (30-May):  LTD = 26-Jun  FTD = MAX (LTD (Jun - 1) + 1, 27-May)  = MAX (30-May, 27-May)  = 30-May | Generate for next trade date (27-May):  LTD = 26-Jun  FTD = MAX (LTD (May - 1) + 1, 27-May)  = MAX (29-Apr, 27-May)  = 27-May  =================================  Generate for pre-launch (30-May):  LTD = 29-Jul  FTD = MAX (LTD (Jun - 1) + 1, 27-May)  = MAX (30-May, 27-May)  = 30-May |
| 27-May | May | Generate for next trade date (28-May):  LTD = 29-May  FTD = MAX (LTD (May - 1) + 1, 28-May)  = MAX (29-Apr, 28-May)  = 28-May  =================================  Generate for pre-launch (31-May):  LTD = 26-Jun  FTD = MAX (LTD (Jun - 1) + 1, 28-May)  = MAX (30-May, 28-May)  = 30-May | Generate for next trade date (28-May):  LTD = 26-Jun  FTD = MAX (LTD (May - 1) + 1, 28-May)  = MAX (29-Apr, 28-May)  = 28-May  =================================  Generate for pre-launch (31-May):  LTD = 29-Jul  FTD = MAX (LTD (Jun - 1) + 1, 28-May)  = MAX (30-May, 28-May)  = 30-May |
| 28-May | May | Generate for next trade date (29-May):  LTD = 29-May  FTD = MAX (LTD (May - 1) + 1, 29-May)  = MAX (29-Apr, 29-May)  = 29-May  =================================  Generate for pre-launch (3-Jun):  LTD = 26-Jun  FTD = MAX (LTD (Jun - 1) + 1, 29-May)  = MAX (30-May, 29-May)  = 30-May | Generate for next trade date (29-May):  LTD = 26-Jun  FTD = MAX (LTD (May - 1) + 1, 29-May)  = MAX (29-Apr, 29-May)  = 29-May  =================================  Generate for pre-launch (3-Jun):  LTD = 29-Jul  FTD = MAX (LTD (Jun - 1) + 1, 29-May)  = MAX (30-May, 29-May)  = 30-May |
| 29-May (LTD) | May | Generate for next trade date (30-May):  LTD = 26-Jun  FTD = MAX (LTD (Jun - 1) + 1, 30-May)  = MAX (30-May, 30-May)  = 30-May  =================================  Generate for pre-launch (4-Jun):  LTD = 26-Jun  (No generation needed for same LTD) | Generate for next trade date (30-May):  LTD = 29-Jul  FTD = MAX (LTD (Jun - 1) + 1, 30-May)  = MAX (30-May, 30-May)  = 30-May  =================================  Generate for pre-launch (4-Jun):  LTD = 29-Jul  (No generation needed for same LTD) |
| 30-May | June | Generate for next trade date (31-May):  LTD = 26-Jun  FTD = MAX (LTD (Jun - 1) + 1, 31-May)  = MAX (30-May, 31-May)  = 31-May  =================================  Generate for pre-launch (5-Jun):  LTD = 26-Jun  (No generation needed for same LTD) | Generate for next trade date (31-May):  LTD = 29-Jul  FTD = MAX (LTD (Jun - 1) + 1, 31-May)  = MAX (30-May, 31-May)  = 31-May  =================================  Generate for pre-launch (5-Jun):  LTD = 29-Jul  (No generation needed for same LTD) |
| 31-May | June | … | … |
| 3-Jun | June | … | … |
| 4-Jun | June | … | … |

Example 2

Cycle Unit: Weekly

Cycle List: Spot, Spot+1

Last Trading Dates (LTD) of Monthly Contract: 20-Dec (Week51), 27-Dec (Week52), 3-Jan (Week1), 10-Jan (Week2) (2024/2025)

Pre-launch Days: +1

|  |  |  |  |
| --- | --- | --- | --- |
| **Trading Date** | **Spot Contract Week** | **Spot cycle** | **Spot + 1 cycle** |
| 23-Dec | Week52 | Generate for next trade date (24-Dec):  LTD = 27-Dec  FTD = MAX (LTD (Week52 - 1) + 1, 24-Dec)  = MAX (23-Dec, 24-Dec)  = 24-Dec  =================================  Generate for pre-launch (27-Dec):  LTD = 27-Dec  (No generation needed for same LTD) | Generate for next trade date (24-Dec):  LTD = 3-Jan  FTD = MAX (LTD (Week52 - 1) + 1, 24-Dec)  = MAX (23-Dec, 24-Dec)  = 24-Dec  =================================  Generate for pre-launch (27-Dec):  LTD = 3-Jan  (No generation needed for same LTD) |
| 24-Dec | Week52 | Generate for next trade date (27-Dec):  LTD = 27-Dec  FTD = MAX (LTD (Week52 - 1) + 1, 27-Dec)  = MAX (23-Dec, 27-Dec)  = 27-Dec  =================================  Generate for pre-launch (30-Dec):  LTD = 3-Jan  FTD = MAX (LTD (Week1 - 1) + 1, 27-May)  = MAX (30-Dec, 27-May)  = 30-Dec | Generate for next trade date (27-Dec):  LTD = 3-Jan  FTD = MAX (LTD (Week52 - 1) + 1, 27-Dec)  = MAX (23-Dec, 27-Dec)  = 27-Dec  =================================  Generate for pre-launch (30-Dec):  LTD = 10-Jan  FTD = MAX (LTD (Week1 - 1) + 1, 27-May)  = MAX (30-Dec, 27-May)  = 30-Dec |
| 27-Dec (LTD) | Week52 | Generate for next trade date (30-Dec):  LTD = 3-Jan  FTD = MAX (LTD (Week1 - 1) + 1, 30-Dec)  = MAX (30-Dec, 30-Dec)  = 30-Dec  =================================  Generate for pre-launch (31-Dec):  LTD = 3-Jan  (No generation needed for same LTD) | Generate for next trade date (30-Dec):  LTD = 10-Jan  FTD = MAX (LTD (Week1 - 1) + 1, 30-Dec)  = MAX (30-Dec, 30-Dec)  = 30-Dec  =================================  Generate for pre-launch (31-Dec):  LTD = 10-Jan  (No generation needed for same LTD) |
| 30-Dec | Week1 | Generate for next trade date (31-Dec):  LTD = 3-Jan  FTD = MAX (LTD (Week1 - 1) + 1, 31-Dec)  = MAX (30-Dec, 31-Dec)  = 31-Dec  =================================  Generate for pre-launch (2-Jan):  LTD = 3-Jan  (No generation needed for same LTD) | Generate for next trade date (31-Dec):  LTD = 10-Jan  FTD = MAX (LTD (Week1 - 1) + 1, 31-Dec)  = MAX (30-Dec, 31-Dec)  = 31-Dec  =================================  Generate for pre-launch (2-Jan):  LTD = 10-Jan  (No generation needed for same LTD) |
| 31-Dec | Week1 | … | … |
| 2-Jan | Week1 | … | … |
