TITLE:

**FUNCTIONAL SPECIFICATION**

***ODP-T***

*FS10015 Conformance Test Portal*

AUTHOR : *IT/Markets Systems*  DATE : *06 Jul 2026*

LAST REVIEW *Derivatives Trading Business Operations* DATE : *28 Feb 2025*

**CONTENTS**

[1. Document Control 3](#__RefHeading___Toc193705842)

[1.1. Change History 3](#__RefHeading___Toc193705843)

[1.2. Document Cross-referenced 3](#__RefHeading___Toc193705844)

[1.3. Abbreviation 3](#__RefHeading___Toc193705845)

[2. Introduction 4](#__RefHeading___Toc193705846)

[3. Test Environment 5](#__RefHeading___Toc193705847)

[3.1. Product 5](#__RefHeading___Toc193705848)

[3.2. Participant 5](#__RefHeading___Toc193705849)

[3.3. Trading Timetable 5](#__RefHeading___Toc193705850)

[4. Test Portal 7](#__RefHeading___Toc193705851)

[4.1. Test Portal User 7](#__RefHeading___Toc193705852)

[4.2. Test Session 7](#__RefHeading___Toc193705853)

[4.3. Test Case 8](#__RefHeading___Toc193705854)

[4.3.1. Test Case Scenario 8](#__RefHeading___Toc193705855)

[4.3.2. Test Case Status 9](#__RefHeading___Toc193705856)

[4.3.3. Test Case Execution 9](#__RefHeading___Toc193705857)

[4.3.4. Test Result Verification 9](#__RefHeading___Toc193705858)

[4.3.5. Exemption for Mandatory Test Case 10](#__RefHeading___Toc193705859)

[4.3.6. Supplementary Test Case 10](#__RefHeading___Toc193705860)

[4.4. Self-Service Functions 10](#__RefHeading___Toc193705861)

[4.5. Test Records Search 11](#__RefHeading___Toc193705862)

# Document Control

## Change History

|  |  |  |  |
| --- | --- | --- | --- |
| Version  Number | Issue Date | Author | Abstract |
| 0.1 | 8 Oct 2024 | IT/Markets Systems | Initial Version |
| 0.2 | 22 Nov 2024 | IT/Markets Systems | Revised based on review comments from business users |
| 0.3 | 6 Dec 2024 | IT/Markets Systems | Revised based on review comments from business users |
| 0.4 | 16 Dec 2024 | IT/Markets Systems | Added tagging |
| 0.5 | 06 Jul 2026 | IT/Markets Systems | Revised based on clarifications from business users |

## Document Cross-referenced

|  |  |  |
| --- | --- | --- |
| # | Document | Version |
| 1 | BRD\_DT\_0041 BRS Conformance Test | 20241220 |
| 2 | FS10001 – Trading Timetable | 20241126 |
| 3 | FS10010 – Product Structure | 20241127 |
| 4 | FS10011 – Participant Structure | 20241127 |
| 5 | FS10023 – Instrument and Combo Generation | 20241127 |

## Abbreviation

|  |  |
| --- | --- |
| DCG | Drop Copy Gateway |
| EP | Exchange Participant |
| HSTN | Hosting Service Testing Network |
| OFG | Order Flow Gateway |

# Introduction

**#FS10015\_S0020\_00100**

Conformance test is conducted in a testing environment. It acts as a functional verification test on Exchange Participants’ (EPs’)/software vendors’ program ability to connect to the trading system for conducting trading activities.

**#FS10015\_S0020\_00200**

Test portal is a secured web-based application for EPs/software vendors to manage the execution of tests. EPs/software vendors should use test portal to record the test results while use SDNet/2 testing circuit or HSTN to access to the testing environment to conduct the test cases.

# Test Environment

**#FS10015\_S0030\_00100**

Conformance test is conducted in a test environment. EPs are required to access the testing environment via SDNet/2 or HSTN. The conformance test environment should have similar setup as the production environment with necessary adjustments to facilitate for testing activities and operational purposes.

## Product

**#FS10015\_S0030\_00200**

Product reference data can be exported from the production or production-like environment and imported to the conformance test environment.

**#FS10015\_S0030\_00300**

The instrument and combo can be generated automatically according to the configured generation rules (refer to FS10023 – Instrument and Combo Generation). To facilitate the options strike generation, a utility tool will be provided for uploading the reference settlement price and underlying price.

## Participant

**#FS10015\_S0030\_00400**

Participants, sessions and GUI access setup should be maintained manually as per needed basis.

**#FS10015\_S0030\_00500**

As per current practice, the name conventions of sessions (i.e. Comp ID) and GUI user IDs are not restricted to be the same as the production environment.

**#FS10015\_S0030\_00600**

A utility tool will be provided to resume/suspend participants and unblock/block sessions and GUI users according to the list who are registered for testing. Password of sessions and GUI users will be reset upon unblock, The list should be prepared and uploaded manually before start of a trading day.

**#FS10015\_S0030\_00650**

To facilitate easier setup of participant trading rights, a utility tool will also be provided to grant trading rights of a specified product to all existing participants.

## Trading Timetable

**#FS10015\_S0030\_00700**

Trading timetable related reference data can be exported from the production or production-like environment and imported to the conformance test environment.

**#FS10015\_S0030\_00800**

The trading days and timetable can be adjusted manually according to the operational needs. For example, the test environment may open for testing during weekends or the market may be closed at an earlier time schedule.

# Test Portal

**#FS10015\_S0040\_00101**

Test portal is a SDNet/2 testing circuit and HSTN facing , secured web-based application. It allows EPs/software vendors to

* record test case execution time
* get the test results right after each test case execution
* submit test results online after all test cases pass the verification
* retrieve historical test results
* perform self-service admin actions (e.g. account unlock with password reset) to trigger related test cases

The diagram below illustrates the interaction between EPs, conformance testing environment and test portal:

![](data:image/x-wmf;base64...)

**#FS10015\_S0040\_00150**

It should be noted that the application of conformance test and the booking of conformance testing environment is not in the scope of test portal.

## Test Portal User

**#FS10015\_S0040\_00200**

EP/software vendor to access test portal are required to login with a test portal user account. The following should be provided during account registration:

* name of EP/software vendor
* name of program

Upon first time login or password reset, user is required to change password. The new password must fulfil the pre-defined password policy. A user account will be locked after a pre-defined consecutive unsuccessful login attempts.

## Test Session

**#FS10015\_S0040\_00300**

Test session contains a collection of test suites where a test suite is a group of test cases based on functional area.

**#FS10015\_S0040\_00400**

When EP/software vendor registers for a conformance test, the following should be specified:

* version of program
* direct order flow sessions (Comp ID)
* drop copy sessions (Comp ID) if applicable
* scope of functional area to be tested/covered

A test session will be created accordingly with applicable test suites under its test portal user account.

**#FS10015\_S0040\_00500**

EP/software vendor can view the details of the test session including

* name and version of program
* direct order flow sessions/drop copy sessions (Comp ID)
* start time
* end time
* completion progress
* list of test suites assigned
* description and status of each test cases in the test suites

via the test portal.

**#FS10015\_S0040\_00600**

All test cases in a test session must be completed in a specified time frame. If it is failed to complete all test cases, the test session will be expired and marked as failed.

**#FS10015\_S0040\_00700**

When all test cases are completed, EP/software vendor is required to submit the test results to confirm the test session is completed via the test portal. A test summary report will then be generated and available for EP/software vendor to download.

**#FS10015\_S0040\_00800**

The details of the test session are kept in the test portal for X days after the test session is completed. While the test session summary and the test report are stored and available for retrieval for Y days. All test reports can be downloaded by internal users for internal reference.

## Test Case

### Test Case Scenario

**#FS10015\_S0040\_00900**

Test case scenarios and the test case grouping (i.e. test suites) in the test portal are defined by Derivatives Trading.

*<To discuss, if there is any test case requires automated interaction to response to EP/software vendor input>*

### Test Case Status

**#FS10015\_S0040\_01000**

Test portal maintains the status of each test case as below:

|  |  |
| --- | --- |
| Test Case Status | Description |
| Not Yet Started | Test case is not yet started. |
| Started | Test case is marked as started (by EP/software vendor). EP/software vendor can execute the test case in the conformance test environment.  Test case’s status will be reset to Not Yet Started if the test case result is not submitted within a trading day. |
| Submitted (Verification in Progress) | Test case result is submitted (by EP/software vendor). Test portal is verifying the result in progress. |
| Verified | Test case result is verified by test portal and pending for EP/software vendor acknowledgement. |
| Completed and Acknowledged | Test case result is reviewed and acknowledged (by EP/software vendor). Once the result is acknowledged, the test case cannot be rerun. |
| Failed | Test case is failed. EP/software vendor can rerun the test case. |

### Test Case Execution

**#FS10015\_S0040\_01100**

To execute a test case, EP/software vendor

1. identifies the test case in the test suite
2. marks the test case as started in test portal
3. executes the test case in the conformance test environment using the specified sessions (Comp ID)
4. marks the test case as submitted and inputs the answers (if required for the test case) in test portal when the test is done
5. waits for the verification result
6. reviews and acknowledges the result if passed, or reruns the test if failed

### Test Result Verification

**#FS10015\_S0040\_01200**

Test portal retrieves the gateway (i.e. OFG/DCG) interface message log files from the conformance test environment to perform the test result verification.

Test portal periodically polls the status of test cases. When a test case is marked as submitted, the test output (i.e. corresponding message log segment) and the test answers (if provided) will be passed to a marking engine for result verification.

The marking engine extracts the test result from the test output log and validate the test result by pattern matching. The verification result and the extracted test result will be recorded and available for EP/software vendor to review.

It should be noted that the automation of test case verification is implemented per test case basis. In general principles, the verification of test cases can be automated if below conditions are fulfilled:

* test case solely depends on the input of EP/software vendor, without interaction with other direct order flow sessions (Comp ID)
* test case result can be captured in the interface message log files
* the pattern of test case result can be pre-defined

For other test cases, it should be evaluated on a case by case basis.

### Exemption for Mandatory Test Case

**#FS10015\_S0040\_01300**

Test portal allows EP/software vendor to request for mandatory test case exemption. The exemption is subject to approval from Derivatives Trading.

### Supplementary Test Case

**#FS10015\_S0040\_01400**

Supplementary test cases are optional for execution. Test portal allows EP/software vendor to declare not to execute a single test case.

## Self-Service Functions

**#FS10015\_S0040\_01500**

Test portal provides below self-service functions for EPs/software vendors to execute by their own:

|  |  |
| --- | --- |
| Self-service Functions | Description |
| Password expiry warning | Update direct order flow session or drop copy session (Comp ID) password expiry days to 5 days such that password warning message will be received upon next logon request. |
| Password immediate expiry | Set direct order flow session or drop copy session (Comp ID) password expired immediately such that password expired error will be received upon next logon request. |
| Unlock account & reset password | Unlock direct order flow session or drop copy session (Comp ID) and reset logon password. A dialog box with password information will be shown. |
| Reset MSN to 1 | Reset the sequence number of direct order flow session or drop copy session. Session will be automatically disconnected upon sequence number reset. |

## Test Records Search

**#FS10015\_S0040\_01600**

Test portal stores all test records for Z days. The following can be searched by internal users and shown in the test portal:

* list of test portal users and their latest conformation test completion date for a specified EP or using a specified program
* details of a specified test portal user
* details of a specified test session
* list of test portal users that have passed a specified test case
* list of test session completed within a specified time range
* list of programs that have passed the test within a specified time range
* *<to be discussed>*
