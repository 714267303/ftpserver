TITLE:

**FUNCTIONAL SPECIFICATION**

***ODP-T

 FS10006 – Block Trade***

AUTHOR: *IT / Markets Systems* DATE: *30 Jun 2026*

LAST REVIEW: *Derivatives Trading Business Operations* DATE: *28 Feb 2025*

**CONTENTS**

[1. Document Control 3](#_Toc235088817)

[2. Introduction 6](#_Toc235088818)

[3. Block Trade Type 6](#_Toc235088819)

[4. Block Trade Attributes 9](#_Toc235088820)

[5. Block Trade Matching 12](#_Toc235088821)

[6. Validation 13](#_Toc235088822)

[7. Trade Price, Quantity and AHT Flag 21](#_Toc235088823)

[8. Trade Statistics 21](#_Toc235088824)

[9. Cancel and Decline Request 21](#_Toc235088825)

[10. Automatic Cancelation of Pending Block Trade 22](#_Toc235088826)

[11. Appendix 23](#_Toc235088827)

# Document Control

## Change History

|  |  |  |  |
| --- | --- | --- | --- |
| Version  Number | Issue Date | Author | Abstract |
| 1.0 | 14 Mar, 2024 | IT/Markets Systems | Initial Version |
| 1.1 | 27 Jun, 2024 | IT/Markets Systems | Updated based on BRS v4 |
| 1.2 | 14 Oct, 2024 | IT/Markets Systems | Updated based on lockdown section and FS review log |
| 1.2.1 | 6 Nov, 2024 | IT/Markets Systems | Updated based on FS review log on 20241023 |
| 1.2.2 | 27 Nov, 2024 | IT/Markets Systems | Updated section 1.2 Document Cross-referenced. |
| 1.3 | 24 Mar, 2025 | IT/Markets Systems | Updated section 1.3, 4 and 10. Update Cover Page. |
| 1.3.1 | 10 Apr, 2025 | IT/Markets System | Updated section 4.6, 4.7, 4.10, 6.11 and 10 |
| 1.4 | 7 Jul, 2025 | IT/Markets System | Updated section 1.2 and 6.10 |
| 1.5 | 14 Jan, 2025 | IT/Markets System | Updated section 3.2 and 4.6 to remove counterparty user attribute from interbank block trade according to requirement.  Removed block trade action attribute, it is covered by cancel and decline request.  Updated section 5 according to requirement.  Updated section 6 to reflect the most current reference data field name in the examples.  Updated section 9 to add notification flow for cancel and decline request. |
| 1.6 | 30 Jun, 2026 | IT/Markets System | Update section 6. Intraday update function is mentioned in Admin GUI FS.  Update BCAN format according to latest requirement.  Updated section 5 to remove the requirement to disallow matching of block trade from the same user as requested by business.  Updated section 6 to add and clarify validations on Block Trade Size Limit and Minimum Volume Thresholds. Supplement conditions on Eligible User and Eligible Contract. Agreed to use seconds for Admin GUI input for validation on Trade Conclusion Date and Time.  Updated section 10 to update, clarify and align with other FS’s on Automatic Cancelation of Pending Block Trade. |

## Document Cross-referenced

|  |  |  |
| --- | --- | --- |
| # | Document | Version |
| 1 | 0008 ODP - NewFunctionRequest - Block Trade Facility | 2025 06 04 |
| 2 | (Review Log) FS10006- Block Trade Handling (Trade Report) | DT240917 |
| 3 | 0003 BRS Order Book Execution Management | 2024 11 21 |
| 4 | 0005 BRS Trading Operations | 2024 11 22 |

## Abbreviation

|  |  |
| --- | --- |
| AHT | After Hours Trading |
|  |  |
|  |  |

# Introduction

#FS10006\_S0020\_00100

In ODP-T, block trade is handled by a dedicated process named Block Trade Matching Engine, which provides a single interface for participants to input block trade across multiple matching engine partitions. Both binary protocol and Trading GUI support block trade features.

# Block Trade Type

#FS10006\_S0030\_00100

ODP-T supports three types of block trade:

* Internal Block Trade (two-party trade report)
* Interbank Block Trade
* On-Behalf Block Trade **(Day 2 Feature)**

#FS10006\_S0030\_00200

Each block trade supports up to 8 legs, and each leg must be an Instrument or Standard Combo. Legs are allowed to span across matching engine partitions.

## Internal Block Trade

#FS10006\_S0030\_00300

Internal block trade contains price, quantity, buyer, and seller information for each leg. It is used to facilitate block trade within a participant, therefore both buyer and seller must be the submitter.

When an internal block trade order is submitted and passed all validation (Section 6), block trade matching engine registers trades for each leg immediately and disseminates trades information to the submitter.

## Interbank Block Trade

#FS10006\_S0030\_00401

Interbank block trade is to facilitate block trade within same participant or between two participants. It contains only one side of information for each leg. The submitter must specify price, quantity, and side for each leg. The transaction must be conducted exclusively with a single counterparty, identified by participant code.

Whenever an interbank block trade is submitted and passed all validation (Section 6), it is subjected to block trade matching (Section 5).

Trade for each leg is immediately registered when the block trade is matched. Trades information is then disseminated to both users who submitted the matched interbank block trade requests.

#FS10006\_S0030\_00501

When there is no pending interbank block trade can be matched, the submitted interbank block trade is stored in block trade matching engine as pending interbank block trade. Two messages are sent out in this case.

One message is an acknowledgement, it is sent to the submitter to notify interbank block trade request is accepted and pending for execution.

Another message is a notification, it is sent to all trading sessions of the counterparty to inform the party that there is a pending interbank block trade for execution. In the case that the counterparty participant is the same as the participant to which the submitter belongs, an acknowledgement is sent to the submitting trading session while notifications are sent to other trading sessions (i.e. all trading sessions of the participants excluding the submitting trading session) of the participant.

The notification includes all legs’ information and the submitting EP ID is provided as counterparty EP ID.

Below is an example for a pending interbank block trade and corresponding notification:

|  |  |  |
| --- | --- | --- |
|  | **Pending interbank block trade from Part 1** | **Notification to Part 2** |
| **Leg 1** | Buy A 100@10 | Buy A 100@10 |
| **Leg 2** | Sell B 1@20 | Sell B 1@20 |
| **Leg 3** | Buy C/D 1@0 | Buy C/D 1@0 |
| **Counterparty** | Part 2 | Part 1 |

#FS10006\_S0030\_00600

Receiver can construct an interbank block trade request based on the notification and then submit it to match the pending block trade.

## On-Behalf Block Trade (Day 2 Feature)

#FS10006\_S0030\_00700

**Please note that On-Behalf block trade is a day 2 feature and will not be implemented on day 1.**

On-behalf block trade contains price, quantity, buyer, and seller information for each leg. It is used to facilitate block trade proposals from a third party to buyer and seller, therefore both buyer and seller must not be the submitter (proposer). The buyer and seller can be a single username or a participant code.

#FS10006\_S0030\_00800

Whenever an on-behalf block trade is submitted (proposed) and passed all validation (Section 6), block trade matching engine sends out 2 types of notifications.

One type of notification is sent to the submitter to notify that on-behalf block trade request is accepted and pending for execution.

Another type of notification is sent to both buyer and seller to inform them that there is a pending on-behalf block trade for acceptance. The notification included all legs’ information only and specified the proposer as the counterparty. This notification is directed to the designated user if username is given, or to all users of buyer/seller if participant code is given.

#FS10006\_S0030\_00900

Buyer and seller can submit a confirmation to accept the proposal with reference to the notification and corresponding leg information. Once both buyer and seller have submitted the confirmation and both confirmations have passed all validation (Section 6), the block trade matching engine registered trades for each leg immediately.

#FS10006\_S0030\_01000

Trades information is then disseminated to buyer user and seller user who sent out the confirmation request. Counterparty information is excluded from the trade information.

#FS10006\_S0030\_01100

A matched notification is sent to the submitter to notify that the on-behalf block trade request is executed.

# Block Trade Attributes

#FS10006\_S0040\_00102

A block trade request is composed of the following attributes. Each attribute can be specified at a specific granularity level which is indicated the following level:

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
| **Attribute** | | | **Granularity** | | |
| **Request** | **Leg** | **Instrument-Side[[1]](#footnote-2)** |
| Block Trade Type | | | ✓ |  |  |
| Entering Trader | | | ✓ |  |  |
| Executing Trader | | | ✓ |  |  |
| Executing Participant | | | ✓ |  |  |
| Counterparty User | | | ✓ |  |  |
| Counterparty Participant | | | ✓ |  |  |
| Enable Price Warning | | | ✓ |  |  |
| Special Indicator | | | ✓ |  |  |
| Trade Conclusion Date & Time | | | ✓ |  |  |
| Aggregated Trade | | | ✓ |  |  |
| BCAN | | | ✓ |  |  |
| ATID | | | ✓ |  |  |
| **Array of Leg (up to 8 legs)** | | | | | |
|  | Contract ID | |  | ✓ |  |
|  | Price | |  | ✓ |  |
|  | Quantity | |  | ✓ |  |
|  | Bid/Ask | |  | ✓ |  |
|  | **Array of Instrument-Side** | | | | |
|  |  | Free Text |  |  | ✓ |
|  |  | Give-up Firm |  |  | ✓ |
|  |  | Give-up Information |  |  | ✓ |
|  |  | Position Effect |  |  | ✓ |

## Block Trade Type

#FS10006\_S0040\_00200

Specify the type for this request. The available options are Internal and Interbank. On-Behalf option will be available on day 2.

#FS10006\_S0040\_00300

[Revoked]

## Entering Trader

#FS10006\_S0040\_00400

This attribute is only required for on-behalf block trade to specify the proposer. Default is the submitter.

## Executing Trader

#FS10006\_S0040\_00500

This attribute is only required for on-behalf block trade to specify the username of seller.

## Executing Participant

#FS10006\_S0040\_00600

This attribute is only required for on-behalf block trade to specify the participant code of seller.

## Counterparty User

#FS10006\_S0040\_00702

This attribute is only required for on-behalf block trade. Indicate the counterparty username to which this block trade request should be matched. For proposing an on-behalf block trade, it should be the buy side[[2]](#footnote-3).

## Counterparty Participant

#FS10006\_S0040\_00801

This attribute is only required for Interbank and on-behalf block trade. Indicate the participant code of the counterparty to which this block trade request should be matched. For proposing an on-behalf block trade, it should be the buy side2.

## Enable Price Warning

#FS10006\_S0040\_00900

This Boolean value indicates the price warning (Section 6.4) is applicable to this block trade. By default, it is set to TRUE.

## Special Indicator

#FS10006\_S0040\_01000

This is an optional and pass-through attribute. Available options are N/A, BTIC and PPR2. The default value is N/A. This field is excluded in proposal request message for on-behalf block trade.

## Trade Conclusion Date and Time

#FS10006\_S0040\_01101

This is an optional attribute. The date and time of the transaction that represented by this block trade.

## Aggregated Trade

#FS10006\_S0040\_01200

Aggregated trade is a pass-through attribute. It is a Boolean value to servers as an indicator for surveillance purpose only. The default value is FALSE. This field is excluded in proposal request message for on-behalf block trade.

## BCAN

#FS10006\_S0040\_01210

17 ASCII character long text identifying the investor. For details, please refer to BCAN section in FS10002 – Order Management..

## Active Trader ID

#FS10006\_S0040\_01220

This is an optional and pass-through attribute in Alphanumeric format to indicate client incentive scheme for downstream systems.

## Array of Leg

#FS10006\_S0040\_01300

An array of legs. Can specify multiple, up to 8. Each leg includes below attributes:

### Contract ID

#FS10006\_S0040\_01400

Instrument/Standard Combo ID

### Price

#FS10006\_S0040\_01500

Traded price of the contract.

### Quantity

#FS10006\_S0040\_01600

Traded quantity of the contract.

### Bid/Ask

#FS10006\_S0040\_01700

Executed side for the Executing Trader of the contract.

### Array of Instrument Sides

#FS10006\_S0040\_01800

Each side information array includes the attributes below. This Instrument Sides information is excluded in proposal request message for on-behalf block trade:

#### Free Text

#FS10006\_S0040\_01900

15 ASCII character long text, an optional and pass-through attribute.

#### Give-up Firm

#FS10006\_S0040\_02100

This is an optional and pass-through attribute for clearing procedure.

#### Give-up Information

#FS10006\_S0040\_02201

This is an optional and pass-through attribute for clearing procedure.

#### Position Effect

#FS10006\_S0040\_02300

Specify position effect for clearing. The available options are Open and Close. An optional and pass-through attribute for clearing. The default value is Open.

For interbank block trade and accepting on-behalf block trade, only the instrument side for submitter is required. Therefore, the array size must be 1.

For internal, side information for both buyer and seller are required. Therefore, the array size must be 2.

# Block Trade Matching

#FS10006\_S0050\_00101

ODP-T allows block trade matching, where two parties separately submit their own side of the trade. A valid block trade matches a pending block trade based on these criteria:

1. The participant code of submitter for the incoming block trade matches the participant code indicated in the counterparty participant attribute of pending block trade.
2. The participant code of submitter for the pending block trade matches the participant code indicated in the counterparty participant attribute of incoming block trade.
3. Incoming block trade and the pending block trade have the same set of instruments including repetition if is allowed.
4. For each leg in the incoming block trade and the pending block trade:
   1. Have the same instrument/Standard Combo ID
   2. Have the same price.
   3. Have the same quantity.
   4. Opposite side.

The matching of block trade is carried out in First-in-First-out (FIFO) manner. The incoming block trade always matches with the first (i.e. oldest) pending block trade fulfilling the above-mentioned criteria. Please refer to the example in the Appendix for details.

#FS10006\_S0050\_00201

For internal block trade, in which a user reports trade having both buyer and seller within the same participant, no matching is required, and the trade is confirmed immediately after the block trade validation check (Section 6).

# Validation

#FS10006\_S0060\_00101

ODP-T offers different kinds of validation for the submitted block trade requests, which are described below. If any validation fails, the whole block trade request will be rejected.

|  |  |
| --- | --- |
| **Validation** | **Validation on Leg Level** |
| Eligible Trading State |  |
| Eligible Contract | ü |
| Block Trade Tick Size | ü |
| Price Warning | ü |
| Block Trade Size Limits | ü |
| Static Price Limits | ü |
| Eligible User |  |
| Eligible Counterparty |  |
| Duplicated Contract |  |
| Minimum Volume Thresholds |  |
| Trade Conclusion Date and Time |  |
| Maximum Number of Legs |  |

## Eligible Trading State

#FS10006\_S0060\_00200

To determine whether the current trading state is allowed for block trade. Only the trading state which is enabled Block Trade function can pass this validation for each leg in the block trade.

Please refer to section “Applicable Background Functions and Supervision” in “FS - Trading Timetable” for details configuration.

## Eligible Contract

#FS10006\_S0060\_00300

To determine whether the Instrument/Standard Combo of submitted leg is allowed for block trade. Only permitted Instrument/Standard Combo can pass this validation. This validation process is carried out for each submitted leg.

For Standard Combo, the validation only applies to the Combo as a whole and not to its individual legs of Combo. Hence, this validation will pass if the Combo is permitted for block trade, even if its legs are not permitted for block trade.

Business Operations are allowed to configure this validation at following product levels (lower level will override upper):

1. Instrument Type and Combo Type: Allow Block Trade / Not Allow Block Trade (default value)
2. Instrument Class and Combo Class: Allow Block Trade / Not Allow Block Trade / Follow Upper Level (default value)

For example:

**Instrument Type:**

|  |  |
| --- | --- |
| **Instrument Type Name** | **Block Trade Option** |
| HHIF | Not Allow |
| HHIC | Allow |
| HHIP | Allow |

**Instrument Class:**

|  |  |  |
| --- | --- | --- |
| **Instrument Class Name** | **Instrument Type** | **Block Trade Option** |
| HHIFUT | HHIF | Allow |
| HHICALL | HHIC | Follow Upper Level |
| HHIPUT | HHIP | Follow Upper Level |
| MCHFUT | HHIF | Follow Upper Level |
| MCHCALL | HHIC | Not Allow |
| MCHPUT | HHIP | Not Allow |

According to above configuration,

* HHIFUT, HHICALL, and HHIPUT is allowed for block trade.
* MCHFUT, MCHCALL and MCHPUT is not allowed for block trade.

In addition, the following validations will be done:

1. The contract is not blocked at any product level for the specific EP. (#FS10011\_S0040\_00300)
2. The underlying of the contract is not suspended (i.e. Effective Status of the underlying is Active) . (#FS10010\_S0030\_00600)
3. The contract is not suspended (i.e. Status of the contract is Active). (#FS10010\_S0030\_00600)
4. The contract is not expired (i.e. Before the Effective Last Trading Date and if applicable the Last Trading Time.)
5. The contract does not belong to a PTRM Tradable that is breached for the PTRM Risk Group and the corresponding Base Risk Group. (#FS10005\_S0070\_00101)
6. The contract belongs to the affected Instrument Class that has the AHT Trading Halt triggered.

## Block Trade Tick Size

#FS10006\_S0060\_00400

This validation only can be passed when the price of submitted leg is aligned to tick size and within the boundary of price tick table for block trade. This validation process is carried out for each submitted leg.

Beside price tick table for normal order, there is a separate price tick table for block trade. Please refer to section “Price Tick” in “FS – Price Supervision” for details configuration.

Please note that any changes on tick table for block trade only support next day effective.

## Price Warning

#FS10006\_S0060\_00500

The validation is to verify that the price of the submitted leg meets the price warning band of its corresponding Instrument. This validation process is carried out for each submitted leg.

The price warning band is defined by lower limit and upper limit. Both limits are calculated by best bid offer, best ask offer, high and low value in matching engine as below:

* Lower limit = MIN (Best Bid, Best Ask, High, Low)
* Upper limit = MAX (Best Bid, Best Ask, High, Low)

The validation can only be passed under one of below conditions:

* The submitted block trade specified FALSE in “Enable Price Warning” attribute (Section 4.8).
* The price of the submitted leg is within or equal to the price warning band.
* Limit cannot be determined (i.e. Three or all candidate values are missing).

As this validation is controlled by the “Enable Price Warning” attribute during submission, therefore Business Operations are **NOT** allowed to configure it.

For the Trading GUI, the “Enable Price Warning” attribute is set to TRUE for initial submissions and cannot be modified. When validation fails, a pop-up dialog with the message "The price of {Leg Name} is outside the current price range. Continue to submit the block trade?" will be displayed to the user instead of a rejection message. The block trade is then resubmitted with the “Enable Price Warning” attribute set to FALSE once the user confirms to proceed.

Please be advised that if multiple legs fall outside the specified range, only the first leg identified as being outside the range will be displayed in the message. For instance, if HSIZ4, HSIF5, and HSIG5 are all outside the range, only HSIZ4 will be shown in the message.

## Block Trade Size Limits

#FS10006\_S0060\_00600

To pass this validation, quantity of submitted leg must be less than or equal to the block trade size limit for block trade of submitter on corresponding Instrument/Standard Combo and the maximum number of block trade size at system level. This validation process is carried out for each submitted leg.

For Standard Combo, the validation only applies to the Combo as a whole and not to its individual legs of Combo. Hence, this validation will pass if the quantity is less than or equal to block trade size limit of Combo, even it is greater than block trade size limit of Combo legs.

The configuration for Block Trade Size Limit - including the available product levels, user level and effective setting rules - is identical to the order size limit for normal order. Please refer to “Quantity” under “Order Attributes” section in “FS – Order Management” for details configuration.

For a trading user (Comp ID) with trading rights across multiple Access Group by Types that cover the same Instrument Type or Combo Type, the lowest Block Trade Size Limit among those groups will apply. If a Block Trade Size Limit is set to zero for any Access Group by Type, it is treated as the smallest value. The final limit applied is determined based on the Effective Value defined in FS – Participant Structure (FS10011\_S0030\_01800), where no specific value is defined at the Comp ID (Trader ID) level.

## Static Price Limits

#FS10006\_S0060\_00800

The validation is to verify that the price of the submitted leg meets the static price limit of its corresponding Instrument. This validation process is carried out for each submitted leg.

The validation can only be passed under one of below conditions:

* Static price limit is not activated for current trading state of submitted leg.
* Static price limit is activated for the current trading state of submitted leg and the leg price is within or equal to the current static price band.

Business Operations are allowed to enable or disable this validation at Instrument Class level.

## Eligible User

#FS10006\_S0060\_01001

To determine whether the submitter is allowed for specified block trade type. Only allowed user with active status can pass this validation.

Business Operations are allowed to create “Allowed Block Trade Group” to specify allowed block trade types and then set the group into below participant/user levels to specify the privilege (lower level will override upper):

1. System default (i.e. not allowed)
2. Exchange Participant level
3. Participant User Role level

For example:

**Allowed Block Trade Group:**

|  |  |
| --- | --- |
| **Group Name** | **Allowed Type** |
| All | Internal, Interbank, On-behalf |
| On-behalf-only | On-behalf |

**Participant:**

|  |  |
| --- | --- |
| **Participant ID** | **Allowed Block Trade Group** |
| AKN4MM | All |
| CGSA |  |

**Participant User Role:**

|  |  |
| --- | --- |
| **Participant User Role** | **Allowed Block Trade Group** |
| PTPW |  |
| Agent | On-behalf-only |

**Trader:**

|  |  |  |
| --- | --- | --- |
| **Trader ID** | **Participant ID** | **Participant User Role** |
| P\_AKNMM11111 | AKNMM | PTPW |
| AKNMM\_AGENT | AKNMM | Agent |
| BU\_CGSA\_AGENT | CGSA | Agent |
| BU\_CGSA222 | CGSA | PTPW |

According to above configuration,

* P\_AKNMM11111 is not allowed for block trade. (Rule 2)
* AKNMM\_AGENT is only allowed for On-behalf block trade. (Rule 3)
* BU\_CGSA\_AGENT is only allowed for On-behalf block trade. (Rule 3)
* BU\_CGSA222 is not allowed for block trade. (Rule 1)

In addition, the following validations will be done:

1. The corresponding submitter (i.e. Trading Session/Comp ID) is not blocked.
2. The corresponding EP the submitter belongs to is not suspended.
3. The Trading Kill Switch of the submitter
4. The PTRM Risk Group the user belongs to and the base risk group of the EP are not blocked.

## Eligible Counterparty

#FS10006\_S0060\_01010

This validation only applies to interbank. It will be applied to on-behalf block trade type on day 2.

For interbank block trade, the participant code specified in counterparty field must be an active participant (i.e. not in suspended state).

For on-behalf block trade, the participant code / participant code of user ID which is specified in buyer and seller field must be an active participant (i.e. not in suspended state).

## Duplicated Contract

#FS10006\_S0060\_01100

This validation only can be passed when there are no duplicated Instrument/Standard Combo within a single block trade.

For Standard Combo, the validation only applies to the Combo as a whole and not to its individual legs of Combo. Hence, this validation will pass if two or more block trade legs within single block trade are sharing a common Combo leg.

For example,

**Assume below 3 block trade requests are submitted.**

|  |  |  |  |
| --- | --- | --- | --- |
|  | **Request 1** | **Request 2** | **Request 3** |
| **Leg 1** | Buy A/B 1@0 | Buy A/B 1@0 | Buy A 1@10 |
| **Leg 2** | Buy A/C 1@0 | Buy A/B 1@0 | Buy A 1@10 |
| **Leg 3** | Buy A 1@10 |  |  |

* Request 1 can pass the duplicated contract validation, even A is common leg.
* Request 2 is rejected due to duplicated Combo ID.
* Request 3 is rejected due to duplicated Instrument ID.

Business Operations are allowed to enable or disable this validation at system level.

## Minimum Volume Thresholds (MVT)

#FS10006\_S0060\_01201

To pass this validation, at least one leg’s quantity within single block trade must be greater than or equal to the MVT of corresponding contract.

MVT for instrument is specified as form of a table, and it can be assigned to Market level or Instrument Class level (lower level will override upper). If no MVT table is assigned, the validation always passes. The MVT configuration only supports the next day effective change.

The following attributes are specified for each table row:

* Expiration To: Upper bound of this expiry range. The value must be larger than the value specified in the preceding expiry range and serves as the lower bound for succeeding expiry range. The last row must be blank which means the largest possible value.

The unit of this value is in terms of expiry (last trading date and effective last trading date) available for trading at SOD for an Instrument Class. 1 means the nearest expiry available for trading at SOD, 2 means the next available expiry for trading at SOD and so on. Instruments created intraday are assigned to the next closest expiration value if the corresponding expiry does not present in the Instrument Class. (e.g. if the instrument created has the last trading date between the spot and the one next to the spot, it will be assigned to use the MVT of value as if it is of value 2. Note that it will not shift the expiration of the existing instrument. To be clear, if another instrument is created with last trading date between the instrument above and the next to spot instrument at SOD, it too will be assigned to use the MVT of value as if it is of value 2).

* MVT: The minimum volume thresholds of this expiry range.

For example,

**HSI (Market):**

|  |  |
| --- | --- |
| **Expiration To** | **MVT** |
|  | 50 |

**HSIFUT (Instrument Class):**

|  |  |
| --- | --- |
| **Expiration To** | **MVT** |
| **4** | 100 |
|  | 0 |

**HSWCALL (Instrument Class):**

|  |  |
| --- | --- |
| **Expiration To** | **MVT** |
| **1** | 90 |
| **3** | 45 |
|  | 25 |

According to above configuration,

* MVT for HSI options are 50 (No configuration for HSI option class, use market’s configuration)
* MVT for 1st to 4th expiries of HSIFUT (i.e. spot, next month, next 2 months and next quarter) are 100.
* MVT for 5th onwards expiries of HSIFUT are 0, that means always pass the validation.
* Regardless of strike price, MVT of all HSI weekly options that will expire in current week are 90.
* Regardless of strike price, MVT of all HSI weekly options that will expire in next week and next 2 weeks are 45.
* MVT of 4th onward expiries and intraday-created expiries for HSI weekly options are 25.

For Combo, MVT value can be assigned to Combo Class level. The validation only applies to the Combo as a whole and not to its individual legs of Combo. Hence, this validation will pass if the quantity is greater than or equal to MVT of Combo, even it is less than MVT of Combo legs.

For example,

**HSIFUT (Instrument Class):**

|  |  |
| --- | --- |
| **Expiration To** | **MVT** |
|  | 100 |

**MVT of HSITS01 (Combo Class) = 50**

According to above configuration,

* A single leg block trade request to buys HSIN5/Q5 50@0 can pass the MVT validation, even the quantity is less than MVT of Combo leg N5 and U5.

When the same contract appears multiple times within a multi-leg block trade, this validation is applied independently to each individual leg. Quantities from separate legs must not be aggregated for validation.

For example,

**HSIFUT (Instrument Class):**

|  |  |
| --- | --- |
| **Expiration To** | **MVT** |
|  | 100 |

**Assume duplicated contract is allowed and below block trade request is submitted.**

|  |  |
| --- | --- |
| **Leg 1** | Buy HSIZ4 99@20000 |
| **Leg 2** | Buy HSIZ4 1@20000 |
| **Leg 3** | Buy HSIZ4 1@20001 |
| **Leg 4** | Buy HSIZ4/Z5 1@0 |

* The above multiple block trade will be rejected because MVT validation has failed for all legs.

Business Operations are allowed to enable or disable this validation at system level.

## Trade Conclusion Date and Time

#FS10006\_S0060\_01301

To pass this validation, the trade conclusion date and time which is reported in a block trade must meet all below conditions:

* The trade conclusion date and time attribute are not empty[[3]](#footnote-4).
* Less than or equal to current system time.
* Greater than or equal to allowed conclusion time (i.e. current system time – allowed conclusion time).

Business Operations are allowed to configure the allowed conclusion time in second in Admin GUI at system level. The default value is empty value (i.e. turned off) which means no validation will be carried out on Trade Conclusion Date and Time.

## Maximum Number of Legs

#FS10006\_S0060\_01400

This validation only can be passed when number of legs in a single block trade is equal to or less than the backend configuration.

Business Operations are allowed to configure the maximum number of legs at system level. The available value is 1 to 8. The default value is 8.

# Trade Price, Quantity and AHT Flag

#FS10006\_S0070\_00100

Besides the normal Match ID and Trade ID which is generated by matching engine, a unique set of Match ID and Trade ID for block trade is assigned by block trade matching engine for every block trade and corresponding legs.

The trade price and quantity are the same as the submitted price and quantity for Instrument.

For Combo, price and quantity for combo leg is calculated by corresponding matching engine when the pending block trade is matched or an internal block trade is submitted, according to submitted price (combo spread) and combo quantity. Please refer to section “Combo Order Book Matching” in “FS – Orderbook and Execution Management” for details calculation.

There is an AHT flag and timestamp in every trade to specify the session and time that the trade is registered by the matching engine. Please refer to “FS – Orderbook and Execution Management” for details.

# Trade Statistics

#FS10006\_S0080\_00100

Whenever a block trade is registered for an Instrument, the total turnover and total block trade turnover of the Instrument are updated correspondingly. Open, High, Low and Last price remain unchanged.

For Combo, the total turnover and total block trade turnover are updated on both Combo and corresponding legs. Open, High, Low and Last price remain unchanged.

# Cancel and Decline Request

#FS10006\_S0090\_00100

An interbank pending block trade can be cancelled by the initiating party through a cancel request or rejected by the opposing party with a decline request.

#FS10006\_S0090\_00200

An on-behalf pending block trade can be cancelled by the proposer through a cancellation request or rejected by buyer or seller with a decline request.

#FS10006\_S0090\_00301

Cancel and decline requests are subject to validation on eligible trade state and eligible user. User pending block trade cancel and declining a block trade are allowed only when the corresponding trading states allow block trade entry. Once validations are passed, the specified pending block trade is instantly cancelled. Following this, a cancellation notification is sent out according to the nature of the triggering request:

If the cancellation is triggered by a cancel request, a cancellation notification is issued to all users belonging to the participant identified in the counterparty participant attribute of the pending block trade. This notification is intended to inform the relevant counterparty users of the cancellation. For interbank block trade with counterparty participant being the same participant of the submitting user, acknowledgment of block trade cancel request instead of cancellation notification is be sent to the submitting user.

When the cancellation results from a decline request, the cancellation notification is distributed to all other users associated with the same participant as the submitter of the decline request, as well as to the original submitter of the pending block trade. This approach ensures that both the decline request participant and the trade submitter are notified of the cancellation event.

# Automatic Cancelation of Pending Block Trade

#FS10006\_S0100\_00102

Pending block trades are cancelled by ODP-T automatically under following situations:

* End of the trade day.
* Submitter of Interbank Block Trade is suspended on participant.
* Trading Kill Switch on the EP is triggered (i.e. Scope of the Kill Switch is all Comp IDs of the EP).
* PTRM Mass Cancel/PTRM Kill Switch is triggered on the Risk Group the submitter belongs to.
* The underlying of a Block Trade Leg or the instrument/standard combo are suspended.
* Proposer/Buyer/Seller of On-Behalf Block Trade is suspended on participant or user level.
* Site failover

It should be noted that automatic cancellation of pending block trade will only be carried out when the corresponding trading state of each block trade leg allows Admin Order Cancel. It should be noted that when an instrument is expired (after LTT), no order actions (including cancellation of orders) is allowed including pending block trade.

#FS10006\_S0100\_00202

Participant/user level suspension on Counterparty of Interbank Block Trade and Cancel on Disconnect (COD) is not applicable to automatic cancelation, all pending block trade is retained in the system.

When a pending block trade is cancelled due to EP suspension, trading kill switch, PTRM actions, suspension of underlying/instrument, a notification is then disseminated to all involved party.

# Appendix

## Example for Block Trade Matching

**Background:**

* Participant 1 has users 1A and 1B.
* Participant 2 has users 2C, 2D and 2E.
* User 1A negotiated a block trade buy HSIZ4 100@20000 with 2C.
* User 1B negotiated a block trade buy HSIZ4 100@20000 with 2D, the block trade content is exactly same as above block trade.

**Sequence of Event:**

At T0, User 1A submitted an interbank block trade and put Participant 2 as counterparty participant.

At T1, User 2C, 2D and 2E received a pending block trade notification, the requester is 1A.

At T2, User 1B submitted an interbank block trade and put Participant 2 as counterparty participant.

At T3, User 2C, 2D and 2E received a pending block trade notification, the requester is 1B.

At T4, both user 2D and 2E attempted to match the pending block trade that was requested by user 1B and received at T3. They simultaneously submitted an interbank block trade and put Participant 1 as counterparty participant.

When the block trade request from 2D is handled by the block trade matching engine, it matches with the pending block trade submitted by 1A since all matching criteria are satisfied and it predates the pending block trade submitted by 1B. Consequently, the trade information is disseminated to 1A and 2D.

After that, the block trade request from 2E is matched with pending block trade that submitted by 1B, and trade information is then disseminated to 1B and 2E. No more pending block trade exists in the matching engine now.

At T5, user 2C submitted an interbank block trade with Participant 1 as the counterparty. The user attempted to match the pending block trade sent by 1A. Since there was no pending block trade in the matching engine, this request was handled as a new one, and a pending notification was subsequently sent to both 1A and 1B for their information.

1. Instrument-Side means that a block trade request can specify different value for each side of a contract included in the block trade. It is particularly used for Internal Block Trade in which a block trade request specified both sides but could have different values. [↑](#footnote-ref-2)
2. When a third party proposes an on-behalf block trade, buyer and seller do not need to provide the counterparty information when they submit their block trade request to complete the proposal. They only need to refer to the notification they received from the third-party. [↑](#footnote-ref-3)
3. When the Trade Conclusion Date and Time is marked as mandatory in the Trading Gateway Binary Specification, empty value will be rejected by the Gateway even if the validation is turned off to conform with the interface specification. [↑](#footnote-ref-4)
