TITLE:

**FUNCTIONAL SPECIFICATION**

***OTP-D - PTRM GUI***

AUTHOR: *IT/Markets Systems*  DATE: *23 OCT 2024*

LAST REVIEW DATE: *23 OCT 2024*

**CONTENTS**

[1. Document Control 4](#_Toc207280263)

[1.1. Change History 4](#_Toc207280264)

[1.2. Document Cross-referenced 5](#_Toc207280265)

[1.3. Abbreviation 5](#_Toc207280266)

[1.4. Distribution List 6](#_Toc207280267)

[2. Introduction 7](#_Toc207280268)

[3. Screen Design 7](#_Toc207280269)

[3.1. Data Type 7](#_Toc207280270)

[3.1.1. UI Widget Mapping by Data Type 9](#_Toc207280271)

[3.2. Content Assistant 10](#_Toc207280272)

[3.3. Application Layout 11](#_Toc207280273)

[3.4. System Time and Client Local Time 11](#_Toc207280274)

[3.5. User Workspace 12](#_Toc207280275)

[3.6. Record Status 12](#_Toc207280276)

[3.6.1. Case 1 - No Planned Changes 13](#_Toc207280277)

[3.6.2. Case 2 - Add New Record 13](#_Toc207280278)

[3.6.3. Case 3 - Update record 14](#_Toc207280279)

[3.6.4. Case 4 - Delete Record 16](#_Toc207280280)

[3.7. Type of Functions 17](#_Toc207280281)

[3.7.1. Permanent Function 17](#_Toc207280282)

[3.7.2. Exchange User Function 18](#_Toc207280283)

[3.7.3. Common Utility of function 18](#_Toc207280284)

[3.8. Request Status 18](#_Toc207280285)

[3.9. Request Action 19](#_Toc207280286)

[3.10. Current Record and Request Record 20](#_Toc207280287)

[3.10.1. Current Record 20](#_Toc207280288)

[3.10.2. Request a Change 21](#_Toc207280289)

[3.10.3. Change Request Indicator 23](#_Toc207280290)

[3.10.4. Amend a Change Request 23](#_Toc207280291)

[3.10.5. Request Record 24](#_Toc207280292)

[3.10.6. Effective Date of the Change Request (Permanent Functions) 26](#_Toc207280293)

[3.11. Authorization Flow 27](#_Toc207280294)

[3.11.1. Countersign Request 27](#_Toc207280295)

[3.11.2. Authorization Request Detail Screen 29](#_Toc207280296)

[3.12. User Preferences 37](#_Toc207280297)

[3.13. Inheritance 37](#_Toc207280298)

[3.14. Permissions 37](#_Toc207280299)

[4. PTRM Functions 37](#_Toc207280300)

[4.1. Common 37](#_Toc207280301)

[4.1.1. Function Type 37](#_Toc207280302)

[4.1.2. Change History 38](#_Toc207280303)

[4.1.3. Common Attributes 38](#_Toc207280304)

[4.1.4. Common Permission Behaviour 38](#_Toc207280305)

[4.1.5. Common Actions 39](#_Toc207280306)

[4.1.6. Common Validation 39](#_Toc207280307)

[4.1.7. Common Notification 39](#_Toc207280308)

[4.1.8. Common Sorting 40](#_Toc207280309)

[4.2. Maintain Functions 40](#_Toc207280310)

[4.2.1. Maintain Risk Group 40](#_Toc207280311)

[4.2.2. Maintain Risk Order Coefficient 53](#_Toc207280312)

[4.2.3. Maintain Position Limit 56](#_Toc207280313)

[4.2.4. Maintain Tradable List 61](#_Toc207280314)

[4.2.5. Maintain Risk Group User 69](#_Toc207280315)

[4.2.6. Maintain Risk Group Notification 73](#_Toc207280316)

[4.3. Control and Monitoring Functions 77](#_Toc207280317)

[4.3.1.1. Control Risk Group 77](#_Toc207280318)

[5. Appendix 84](#_Toc207280319)

# Document Control

## Change History

|  |  |  |  |
| --- | --- | --- | --- |
| Version  Number | Issue Date | Author | Abstract |
| 0.0.7 | 31 Oct 2024 | IT/Markets Systems | * Initial Version |
| 0.0.8 | 27 Dec 2024 | IT/Markets Systems | * Updated effective in function type section * Updated for delete tomorrow handling in common actions section * Supplemented description for default risk group in maintain risk group section * Added maintain tradable list section * Updated attributes table for each function * Updated record count for each function |
| 0.0.9 | 17 Jan 2025 | IT/Markets System | * Renamed size to length in attributes table * Updated length in attribute table * Supplemented warning and notice colour in Maintain Risk Group and Control Risk Group section |
| 0.0.10 | 23 Jan 2025 | IT/Markets System | * Added 3.4 System Time and Client Local Time section * Updated length 20 to 21 for long/short exposure negative number case in Maintain Risk Group and Control Risk Group sections * Renamed PTLG to Risk Group for all sections * Updated UI Layout screens for renaming PTLG to Risk Group * Updated retention period of change history to 7 years |
| 0.0.11 | 18-Feb-2025 | IT/Markets System | * Updated emergency button actions in Control Risk Group section * Updated numeric description in date type section * Updated sound alert in Maintain Risk Group and Control Risk Group |
| 0.0.12 | 28-May-2025 | IT/Markets System | * Update data type section for negative numeric length * Fallback length 21 to 20 for long/short exposure negative number case in Maintain Risk Group and Control Risk Group sections * Update email length in Maintain Risk Group Notification |
| 0.0.13 | 21-Aug-2025 | IT/Markets System | * Remove clone from withdraw and reject in 3.10.5 - Request Record section * Remove 3.10.6 - Resubmit a Rejected / Withdrawn Change Request section * Update 4.1.1 - function type * Remove import in 4.1.5 - common actions * Update Risk Order Coefficient only editable in new record in 4.2.1 Maintain Risk Group * Update tree table to search table in 4.2.1 Maintain Risk Group * Remove real-time figures and sub table in 4.2.1 Maintain Risk Group Detail * Remove No. of Users in Maintain Risk Group * ⁠Update ID length in 4.2.1 and  4.3.1.1 attributes table * ⁠Include Supported Import Function and Supported Import Attribute Key and CSV Content Format in 4.2.1 - Import Page * Update layout standard for all search pages and detail pages * Align RDB schema column name |
| 0.0.14 | 13-Jan-2026 | IT/Markets System | * Remove tradable description in Attributes table * Remove maintain function redirection in more actions of maintain risk group search page * Update notice threshold is required to lower than warning threshold * Update notice threshold and warning threshold range * Delete risk group for tomorrow menu item will be hidden when risk group is base group and other non-base risk group existed in PTRM. * Update email description in maintain risk group notification * Add maximum row number validation for add button in tradable, user and notification detail pages * Display - and non-editable if the tradable is selected from combo type/combo class in maintain position limit detail page * Update – display description in maintain tradable list detail page * Update Alphanumeric to align Trading Admin * Mention “A risk group user is only allowed to add in one risk group” in maintain risk group user detail page * Mention risk group user is required to under sponsored participant risk group in maintain risk group user * Update User ID to Comp ID in maintain risk group user detail page, and mention unassigned Comp ID handling in base risk group * Remove editable in name field for all pages |
| 0.0.15 | 16-Mar-2026 | IT/Markets System | * Update allowed character input for Char in section 3.1 Data Type * Refer to common attribute for Max value * Update ASAP for adding and deleting in risk group user and only editable for new row * UAT#689, Update ASAP for adding email and Update Tomorrow for deleting email in risk group notification and only editable for new row * UAT#690 Update notice and warning from 0 to 99, notice is required to lesser than warning except 0 * Update Risk Group field to Risk Group ID field to align Trading Admin * UAT#710, Update risk group suffix length from 20 to 16 for exchange ID reservation * Update accessing function for all maintain and control functions * Update and Add product type in CSV content template for import risk group * Update Control risk group layout by replacing tree table to normal table * UAT#726, only display non-dummy market in adding tradable page * UAT#728, update max order size and max block trade size from MAX to 2,147,483,647 |
| 0.0.16 | 20-Apr-2026 | IT/Markets System | * QA#91, update email format in 4.2.6 Maintain Risk Group Notification * QA#93, correct Utilization % in control risk group * QA#105, remove editable for control risk group * Update realtime for control risk group figures * QA#106, update default to 0 instead of Max for control risk group figures * UAT#757, update Control Risk Group Layout |
| 0.0.17 | 26-May-2026 | IT/Markets System | * Update the Execution Throttle Period (Sec) from 300 – 600 to 1 – 300 * Update the default Execution Throttle Period (Sec) to 300 * Remove the Req Status and Req Action columns from the Control Risk Group table * UAT#874, add "HKD Eqv" to Intraday Exposure Risk Limits and Execution Throttle Risk Limits |
| 0.0.18 | 28-May-2026 | IT/Markets System | * Revert the Execution Throttle Period (Sec) from 1 - 300 to 300 – 600 * Revert the default Execution Throttle Period (Sec) to 600 * UAT#724, update the column names from "Buy" and "Sell" to "Open Buy" and "Open Sell" * Add PTRM Validation Logics in Appendix |
| 0.0.19 | 08-Jun-2026 | IT/Markets System | * QA#21, remove accessing function for risk order coefficient , position limit, tradable list, risk group user and risk group notification detail page * QA#122, update class/type to type/class, and update type/class and tradable to optional * QA#125, update action button behavior for maintain risk group * QA#131, update outdated risk group ID length from 12 to 32 * QA#133, add back product level in position limit and tradable list detail * Withdraw selected is applicable to external user * QA#126, update UI layout for ASAP and TMR in notification detail * QA#127, update validation logic file to set max email is 10 * QA#128, update validation logic file to set max user is 500 * QA#137, update notice, warning and breach to optional in risk group detail page |
| 0.0.20 | 25-Jun-2026 | IT/Markets System | * UAT#874, add (HKD Eqv) to all Intraday Exposure Risk Limits and Execution Throttle Risk Limits |
| 0.0.21 | 16-Jul-2026 | IT/Markets System | * QA#165, remove length for utilization percentage |

## Document Cross-referenced

|  |  |  |
| --- | --- | --- |
| # | Document | Version |
| 1 | PTRM GUI | 20231031 |

## Abbreviation

|  |  |
| --- | --- |
| OTP-D | Orion Trading Platform - Derivatives Market |
| PTRM | Pre Trade Risk Management |
| Tradables | The Market, Instrument Type or Class defined for Position Limits, Block Trade Limits, Maximum Order Size and Block Trade Size Risk Check |
| M/O | Mandatory or Optional |

## Distribution List

|  |  |  |
| --- | --- | --- |
| # | Name | Role |
|  |  |  |
|  |  |  |

# Introduction

#FS10014b\_S0020\_00100

The section provides an overview of the OTP-D PTRM Graphical User Interface (also referred to as PTRM GUI). The PTRM GUI is a web-interface based application, which facilitates all Product, Participant and Trading functionality configuration and management of risk group activities.

Basically, the functions can be separated into maintain functions and control & monitoring functions. Each function will cover the following sections:

* Description
* Scope of the data
* Permission Behaviour
* Notification
* Pages
  + Accessing the Function
  + Filtering Criteria
  + UI Layout
  + Attributes
  + Actions
  + Validation

# Screen Design

#FS10014b\_S0030\_00100

## Data Type

#FS10014b\_S0030\_00200

The table below describes the internal Data Type used in the definition of logical entity attributes in the Data Dictionary.

| # | Data Type | Size | Description |
| --- | --- | --- | --- |
|  | Char | 1 | One character input and the following is allowed:   * A-Z * a-z * 0-9 * ~#$%^()\_+-=[]\{};:,./ * Space |
|  | Boolean | 1 | Y = Yes/True or N = No/False |
|  | Numeric | As defined | Any digit from 0 to 9 and “-“, the following length are allowed:   * 3, possible value from 0 to 255 * 4, possible value from –127 to 127 * 5, possible value from 0 to 65534 * 6, possible value from -32767 to 32767 * 10, possible value from 0 to 232 - 2 * 11, possible value from - 231 + 1 to 231 - 1 * 20, possible value from 0 to 264 - 2 * 20, possible value from - 263 to 263 - 1 |
|  | Alphanumeric | As defined | Multiple characters input and the following are allowed:   * A-Z * a-z * 0-9 * ~#$%^()\_+-=[]\{};:,./ * Space   Remarks: ID field will support:   * A-Z * a-z * 0-9 * ./\_ |
|  | Decimal | As defined | Any digit from 0 to 9.  With implicit decimals, the number of decimal places is separately and explicitly defined.  For example, if the size 5 and number of decimal places applicable to this field is 2 then the value can be 999.99.  Range of value is from 0 to 999,999,999,999,999,999. |
|  | Price | 18 | Any digit from 0 to 9.  Signed number and support up to 6 decimal places by default and configurable per instrument type/class |
|  | Quantity | 9 | Any digit from 0 to 9.  Range of value is from 0 to 999,999,999. |
|  | Percentage | 9 | Any digit from 0 to 9.  Support up to 4 decimal places |
|  | Date | 8 | In universal time (UTC) and UI displays as DD-MMM-YYYY format |
|  | Time | 8 | In universal time (UTC) and UI displays as HH:MM:SS format |

Note the following:

1. Local Hong Kong time is used and displayed to client, while communication between Server and GUI is in Coordinated Universal Time (UTC) time
2. For Price and Percentage, size and number of decimal places are implicit
3. In the user interface, data conversion will be done on behalf of the user. For example:

**Decimal (Explicit Decimal Places)**

A1. User types in Call Price = 1.23, it is converted into “Call Price” = 123 & “Decimals in Call Price” = 2 and sent to the backend.

A2. User types in Call Price = 1.234567980123, it is not allowed in the UI and is rejected.

A3. User types in Call Price = 123456798012345678.9, it is not allowed in the UI and is rejected.

**Percentage (Max 4 decimal places)**

B1. User types in IOMP Tolerance % = 4.56, it is converted into “IOMP Tolerance %” = 45600 and sent to the backend. During screen enquiry or report generation, it will show “4.5600”.

B2. User types in IOMP Tolerance % = 4.56890123, it is not allowed in the UI and is rejected.

B3. User types in IOMP Tolerance % = 45689012.3, it is not allowed in the UI and is rejected.

B4. User enters 99.9 to represent 99.9% for IOMP Tolerance %.

B5. User enters 999 to represent 999% for IOMP Tolerance %.

**Price (Max 6 decimal places)**

C1. User types in Minimum Price = 3.45, it is converted into “Minimum Price” = 3450000 and sent to the backend. During screen enquiry / report generation, it will show “3.450000”.

C2. User types in Minimum Price = 3.45234234, it is not allowed in the UI and is rejected.

C3. User types in Minimum Price = 345234123234567890.1, it is not allowed in the UI and is rejected.

### UI Widget Mapping by Data Type

#FS10014b\_S0030\_00300

The following session list out the general mapping of Data Type and UI Widget for display and update purpose, however they can be different in some specific functions which the user requirement may require a special display behaviour.

| # | Data Type | UI Widget | Description |
| --- | --- | --- | --- |
|  | Char | Text Input or Table Cell | Simple input text field to allow single character |
|  | Boolean | Toggle button or Checkbox | Either dropdown (Default) or checkbox or radio button to support the following:  Y = Yes/True or N = No/False |
|  | Numeric | Text Input  Table Cell | Simple input text field to allow any digit from 0 to 9 |
|  | Alphanumeric | Text Input  Table Cell  Content Assist | Simple input text field to allow any printable ASCII character(s). |
|  | Decimal | Text Input  Table Cell | Simple input text field to allow any digit from 0 to 9.  With implicit decimals, the number of decimal places is separately and explicitly defined.  For example, if the size 5 and number of decimal places applicable to this field is 2 then the value can be 999.99.  Range of value is from 0 to 999,999,999,999,999,999. |
|  | Price | Spinner  Table Cell | An input text field with an upward and a downward arrow button and shows the next value when it is pressed. The next value is configurable, it can be based on a pre-defined delta portion.  This input text field allows any digit from 0 to 9.  Signed number and support up to 6 decimal places. |
|  | Quantity | Spinner or Text Input or Table Cell | Simple input text field to allow any digit from 0 to 9.  Range of value is from 0 to 999,999,999. |
|  | Percentage | Text Input or Table Cell | Simple input text field to allow any digit from 0 to 9.  With implicit decimals, the number of decimal places is separately and explicitly defined.  For example, if the size 5 and number of decimal places applicable to this field is 2 then the value can be 999.99.  Support up to 4 decimal places |
|  | Date | Date selection Drop Down or  Text Input (Read-only) | Simple input text field to display date formatted value. (Default as DD-MMM-YYYY) And it is allowed to select date value in drop down |
|  | Time | Time Selection Drop Down or  Text Input (Read-only) | Simple input text field to display time formatted value. (Default as HH:MM:SS) And it is allowed to select time value in drop down.  For read-only display field, it can be supported up to 9 nano-of-second (e.g. HH:MM:SS.nnnnnnnnn) |

## Content Assistant

#FS10014b\_S0030\_00400

Content assist is used to list out those matched values based on a partially entered text from input box. It performs an implicit query to backend server and displays the corresponding result into a dropdown menu (but limited to 10 items at a time). User can either select the desired value or navigate around these values by mouse or arrow up/down key.

Entered text followed by question mark (?) matches zero or one occurrence in the result. And entered text followed by star (\*) matches zero or more occurrence.

By default it lists out all **Pending**, **Approved** and **Active** items of the system without considering user permission, backend processes take the responsibility to perform the validation. But it depends on that requirement of each screen, listed items could be adjusted.

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

## Application Layout

#FS10014b\_S0030\_00500

The following session describe the application layout of Trading UI which consists of 4 major components: Header Bar, Side Bar, Footer Bar and Content Area.

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

4

3

2

1

| Callout | Remarks |
| --- | --- |
| 1 | Header bar displays the application name, user profile menu and Workspace Menu. User can select available workspace in Workspace Menu and select available user actions in user profile menu. |
| 2 | Side bar displays the available function of current user in a system workspace, corresponding function is opened in Content Area after clicking on a menu item. |
| 3 | Footer bar displays the copyright information, privacy policy, disclaimer and help to user |
| 4 | Content area displays those opened function to user |

## System Time and Client Local Time

#FS10014b\_S0030\_00550

The Hong Kong Local Time UTC/GMT +8 Hours is used as the system time for UI display, communication and processing.

Selection of date/time in GUI screen relies on Client Local PC time to provide an accurate current time of Hong Kong and user can further adjust the time to target date or time when required, for example user can target a scheduled event at 16:30 PM Hong Kong Local Time in a GUI drop down while the client UK local time is 9:30 AM.

In case of the Client Time is far away from our expected system time, a user notification is prompted to highlight the gap between client time and system time right after a successful user login. Client should follow up with their local admin to resolve it and login again.

The following system notification setting is defined:

| Absolute( Client UTC Time – Server UTC Time ) | System Notification Level |
| --- | --- |
| More than 1 minutes | INFO |
| More than 2 minutes | WARNING |
| More than 5 minutes | ERROR |

## User Workspace

#FS10014b\_S0030\_00600

PTRM Users can only manage the colour theme and font size in the application, and these setting persist into user profile individually. And user has a flexibility to decide if he/she wants to save this information during user logout.

## Record Status

#FS10014b\_S0030\_00700

There are seven record status available in the system as follow:

| **#** | **Record Status** | **Description** |
| --- | --- | --- |
|  | New | Newly create record before submitting for approval.  (Only available in the Request Record Card in the Detail Page during data input.) |
|  | Pending | Newly create record in pending state. |
|  | Approved | Record is approved and it will become effective based on the target effective date or time. |
|  | Active | Record is effective in the system. |
|  | Rejected | New/Update/Delete request is rejected by Approver/Requester. |
|  | Deleted | Record is marked as deleted in the system and it is irreversible.  Those deleted records will be physically removed as part of the housekeeping start of the day reload which depends on the retention period setting. |
|  | Withdraw | An approved record had been withdrawn before effective. |

The record status can be found in the Search Page and Detail Page. Here is the illustration of the record status under different cases:

* + 1. Case 1 - No Planned Changes

#FS10014b\_S0030\_00800

This section includes the scenarios when there are no planned changes.

**Search Page**

In the search page, the current image’s record status is shown in the **Status** column. It should be either **Active** or **Deleted**. And the Change Request Indicator is **No Plan**.

![](data:image/png;base64...)

**Detail Page**

In the detail page, the Current Record’s status should be either **Active** or **Deleted**.

And the Request Record’s status is **No Plan**.

| **#** | **Scenario** | **Status of Current Record** | **Status of Request Record** |
| --- | --- | --- | --- |
|  | A deleted record. Change is not allowed. | Deleted | No Plan |
|  | Active record without any planned change. | Active | No Plan |

* + 1. Case 2 - Add New Record

#FS10014b\_S0030\_00900

This section includes the scenarios related to Add New Record action.

When adding new record, there is no active record available in the system, so the display in Search Page and Detail Page is a bit different.

**Search Page**

As the Current Record doesn’t exist in the system, so the Search Page will display the content of Request Record instead of the Current Record. And the **Status** column reflects the record status of the Request Record.

At the same time, the Change Request Indicator show the status of the planned change.

Once the request had been approved and effective, Current Record’s status will be displayed in the **Status** column. and Change Request Indicator will become **No Plan**.

If there is any failure during Approve/Reject, the Change Request Indicator will become **Failed**.

![A screenshot of a chat  Description automatically generated](data:image/png;base64...)

**Detail Page**

As the current record doesn’t exist in the system, so the Current Record’s status is **No Record**. And the Request Record’s status will be updated throughout the Approval process.

Once the new record had been approved and effective, the Current Record’s status will become **Active** and Request Record’s status will become **No Plan**.

| **#** | **Scenario** | **Status of Current Record** | **Status of Request Record** |
| --- | --- | --- | --- |
|  | Inputting a new record but haven’t submitted for approval yet.  *(This scenario is only applicable to Detail Page)* | No Record | New |
|  | New record pending for approval. | No Record | Pending |
|  | New record had been approved but not effective yet. | No Record | Approved |
|  | New record request is approved and effective. | Active | No Plan |
|  | New record had been rejected by Approver. | No Record | Rejected |
|  | New record request failed to Approve/Reject. | No Record | Failed 1 |
|  | New record with a Withdraw request *(on an approved but new record is not effective yet)* pending for approval. | No Record | Approved |
|  | New record with a withdraw request approved.  *(Before the new record is effective.)* | No Record | Withdraw |
|  | New record with a withdraw request rejected.  *(Before the new record is effective.)* | No Record | Approved |
|  | New record with a withdraw request failed to Approve/Reject. | No Record | Failed 2 |

Remark 1: If a new record request is failed to approve/reject, there will be no change to the system. Users need to submit another new record request if necessary.

Remark 2: If the withdraw request failed to approve, the corresponding to-be-withdraw approved change will remain in the system. Users need to raise another withdraw request if necessary.

* + 1. Case 3 - Update record

#FS10014b\_S0030\_01000

This section includes the scenarios related to Update Record action.

As update should be performed on an Active record, so the Current Image should be always Active.

**Search Page**

In the search page, the Current Record’s record status is shown in the **Status** column. As update can be performed on Active record only, so the Status column should remain **Active**.

At the same time, the Change Request Indicator reflects the status of the planned change.

Once the new record had been approved and effective, the Change Request Indicator will be displayed as **No Plan**.

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

**Detail Page**

In the detail page, as update can be performed on Active record only, so Current Record’s status should remain “Active”.

And the Request Record’s will be updated throughout the Approval process.

Once the new record had been approved and effective, the Request Record’s status will become **No Plan**.

| **#** | **Scenario** | **Status of Current Record** | **Status of Request Record** |
| --- | --- | --- | --- |
|  | Inputting an update of an Active record but haven’t submitted for approval yet.  *(This scenario is only applicable to Detail Page)* | Active | New |
|  | Active record with an update pending for approval. | Active | Pending |
|  | Active record with an approved update but not effective yet. | Active | Approved |
|  | Update record request is approved and effective. | Active | No Plan |
|  | Active record with an update rejected by Approver. | Active | Rejected |
|  | Active record with an update request failed to Approve/Reject. | Active | Failed 1 |
|  | Active record with a Withdraw request *(on an approved but update is not effective yet)* pending for approval. | Active | Approved |
|  | Active record with a withdraw request approved.  *(Before the update is effective.)* | Active | Withdraw |
|  | Active record with a withdraw request rejected.  *(Before the update is effective.)* | Active | Approved |
|  | Active record with a withdraw request failed to Approve/Reject. | Active | Failed 2 |

Remark 1: If an update record request is failed to approve/reject, there will be no change to the system. Users need to submit another update record request if necessary.

Remark 2: If the withdraw request failed to approve, the corresponding to-be-withdraw approved change will remain in the system. Users need to raise another withdraw request if necessary.

* + 1. Case 4 - Delete Record

#FS10014b\_S0030\_01100

This section includes the scenarios related to Delete Record action.

As delete should be performed on an Active record, so the Current Image should remain **Active** until the request had been approved and effective.

**Search Page**

In the search page, the current image’s record status is shown in the **Status** column. As update can be performed on Active record only, so the Status column should remain **Active** until the request had been approved and effective.

At the same time, the Change Request Indicator reflects the status of the planned change.

Once the request had been approved and effective, the Change Request Indicator will be displayed as **No Plan** and the Status will become **Deleted**.

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

**Detail Page**

In the detail page, as update can be performed on Active record only, so Current Record’s status should remain **Active** until the request had been approved and effective.

And the Request Record’s will be updated throughout the Approval process.

Once the new record had been approved and effective, the Request Record will be displayed as **No Plan** and Current Record will become **Deleted**.

| **#** | **Scenario** | **Status of Current Record** | **Status of Request Record** |
| --- | --- | --- | --- |
|  | Scheduling a delete of an Active record but haven’t submitted for approval yet.  *(This scenario is only applicable to Detail Page)* | Active | New |
|  | Active record with a delete pending for approval. | Active | Pending |
|  | Active record with an approved delete request but not effective yet. | Active | Approved |
|  | Delete record request is approved and effective. | Deleted | No Plan |
|  | Active record with a delete request rejected by Approver. | Active | Rejected |
|  | Active record with a delete request failed to Approve/Reject. | Active | Failed 1 |
|  | Active record with a withdraw request *(on an approved but deletion is not effective yet)* pending for approval. | Active | Approved |
|  | Active record with a withdraw request approved.  *(Before the deletion is effective.)* | Active | Withdraw |
|  | Active record with a withdraw request rejected.  *(Before the deletion is effective.)* | Active | Approved |
|  | Active record with a withdraw request failed to Approve/Reject. | Active | Failed 2 |

Remark 1: If a delete record request is failed to approve/reject, there will be no change to the system. Users need to submit another delete record request if necessary.

Remark 2: If the withdraw request failed to approve, the corresponding to-be-withdraw approved change will remain in the system. Users need to raise another withdraw request if necessary.

* 1. Type of Functions

#FS10014b\_S0030\_01200

There are three types of UI functions in Admin GUI as follows:

### Permanent Function

#FS10014b\_S0030\_01300

Permanent function represents a change request of a function which could be effective as soon as possible, or effective in tomorrow, these data are stored in a separate Admin Database and Trading Database.

Approved update to the database is persisted to both Admin Database and Trading Database if it is effective as soon as possible / from today and remain effective till further update in future.

On the other hand, approved update is persisted into Admin Database only if it is effective from tomorrow and remain effective till further update in future. System housekeeping jobs at the end of day prepare essential reference data and administrative data to Trading Database based upon the Admin Database.

And approved update can be withdrawn before effective via a new change request. If the approved update is already effective, it will no longer allowed to withdraw.

### Exchange User Function

#FS10014b\_S0030\_01400

Refer to OTP-D FS - Market Operation Admin GUI

### Common Utility of function

#FS10014b\_S0030\_01500

| **#** | **Name** | **Description** |
| --- | --- | --- |
|  | Export Data | Provide export data to csv file from table |
|  | Import Data | Provide import csv file to table |
|  | Search Filter | User can narrow down search result by selecting pre-defined filter criteria and value. |

## Request Status

#FS10014b\_S0030\_01600

Whenever a change in the system requires 4-eye Change Confirmation, an authorization request will be created.

The status of the authorization request can be transit as below:

![A diagram of a process  Description automatically generated](data:image/png;base64...)

| **#** | **Request Status** | **Description** |
| --- | --- | --- |
|  | Pending | When Requester submit the change for approval, the request will become PENDING status. |
|  | Approved | Once the request had been approved by Approver, it will become APPROVED. |
|  | Rejected | If the request had been rejected by Approver, it will become REJECTED. |
|  | Failed | If Approver tires to approve/reject the request, but the execution failed due to error, the request will become FAILED. |

## Request Action

#FS10014b\_S0030\_01700

The following actions are available to change the records in the system.

| **#** | **Request Action** | **Description** |
| --- | --- | --- |
|  | Add | This action is to create new records into the system.  Requester can request an “Add” action by clicking the New Record button in the Search pages. |
|  | Update | This action is to update the attribute of an existing record in the system.  It can be performed on Active records only.  Requester can request a “Update” action by scheduling a change on an active current record in the Detail pages. |
|  | Delete | This action is to delete an existing record from the system.  It can be performed on Active records only.  Requester can request a “Delete” action by scheduling a delete on an active current record in the Detail pages. |
|  | Withdraw | This action is to withdraw an approved change.  Approved changes can be withdrawn only when they’re not effective yet.  Users with “Write” permission are allowed to withdraw an approved change. |

The availability of Request Action depends on user’s permission and the nature of the functions.

## Current Record and Request Record

#FS10014b\_S0030\_01800

In the Record Detail Screen, there are two cards at the top of the screen. They represent the Current effective image and the Change Request image of this record respectively.

The Current Record in the left-hand side represents the record that is currently effective in the System.

The Request Record in the right-hand side represents the change request of the record. Including a request which is pending approval / approved / rejected / withdrawn, etc.

User can toggle between Current and Request Record by clicking on the cards. And the content of the Record Detail Screen will be refreshed accordingly.

![A screenshot of a phone  Description automatically generated](data:image/png;base64...)

* + 1. Current Record

#FS10014b\_S0030\_01900

The Current Record represents the record that is currently effective in the System.

Changes with Update as soon as possible will be reflected in Current Record once it’s approved and effective.

A Current Record card contains the following information:

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

| **#** | **Field** | **Description** |
| --- | --- | --- |
| **Card Header** | | |
|  | Title | Current Record. Indicate that it’s representing the current record that is currently effective in the system. |
|  | Status | Status of the Current Record.  **No plan -** There is no current record in the system.  **Active -** The current record is active.  **Deleted -** The current record is deleted. |
|  | Menu | Menu includes the choices for requesting a change.  For detail, please refer to “**Request a Change**” section.  The menu will be enabled only if   * Current Record is in **Active** status and Request Record is in **No plan / Rejected / Withdraw** status. * And, User have Write Permission.   If the menu is disabled, the Menu will mark as grey and no popup menu available. |
| **Card Body** | | |
|  | Approved by | The approver who approved the change of the current record. |
|  | Last updated date | Last update date of the current record. |
|  | Effective date | The effective date of the record. |
|  | Effective until | The effective end date of the record.  For permanent records, Effective until is **Forever**. |

* + 1. Request a Change

#FS10014b\_S0030\_02000

User with write permission can schedule a change by selecting the desired request type from the menu of the Current Record. Changes can be requested on Active records only. No changes are allowed on Deleted records.

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

These are the possible types of requests for Permanent Functions:

| **#** | **Request Type** | **Description** |
| --- | --- | --- |
|  | Update for Tomorrow | Request an update to be effective since Tomorrow. |
|  | Update for as soon as possible | Request an update and effective as soon as possible. |
|  | Delete for Tomorrow | Request a deletion to be effective since Tomorrow. |
|  | Delete for as soon as possible | Request a deletion and effective as soon as possible. |

If the record already has a change request pending for approval or approved but not effective yet, then the system will prohibit user from requesting another change.

The menu at Current Record Card will be disabled.

![A screenshot of a screenshot of a phone  Description automatically generated](data:image/png;base64...)

Users should reject the pending change request or withdraw the approved change before submitting another change.

If a Delete Tomorrow is planned, all as soon as possible change request for the associated risk group parameters will be for today change only. In case the Delete Tomorrow has been withdrawn, the existing change will NOT carry forward to tomorrow.

**Example:** If a Delete Tomorrow is planned for a risk group, and the maximum order size is changed from 10 to 50 with request type as soon as possible, this change will be for today only. If the Delete Tomorrow is withdrawn before the end of the day, the maximum order size will revert to 10 the next day.

* + 1. Change Request Indicator

#FS10014b\_S0030\_02100

In the Search Screen of each function, there is a column indicate whether the record has any planned change.

Here is the possible value of the indicator:

| **#** | **Change Request Indicator** | **Description** |
| --- | --- | --- |
|  | ![](data:image/png;base64...) | There are no planned changes. |
|  | ![](data:image/png;base64...) | There is a change pending Approver’s approval.  Or a withdraw request pending Approver’s approval. |
|  | ![](data:image/png;base64...) | There is an approved change. But it’s not effective yet.  Or a withdraw request had been approved. |
|  | ![](data:image/png;base64...) | There is a change/withdraw request rejected by Approver.  Or the change/withdraw request failed to approve/reject. |

* + 1. Amend a Change Request

#FS10014b\_S0030\_02200

**Reject a Pending change**

To amend a pending change, Requester or Approver should reject the pending change in the **Authorization Request Detail Screen** and resubmit a new change for approval.

**Withdraw an Approved but not effective change**

To amend a planned change (approved but not effective yet), User should submit a withdraw request to withdraw the planned change. Once the withdraw request is approved, then users can resubmit the change request for approval again.

The withdraw request can be initiated from an approved request as below:

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

It can only be triggered on a request which is approved but not yet effective yet. For example, a change scheduled to be effective tomorrow.

Users can also submit the withdraw request via Search Pages. They can select one or more approved records in Search Pages and submit withdraw request in one click.

* + 1. Request Record

#FS10014b\_S0030\_02300

When SOD, Request Record and Current Record are identical. And the status of Request Record is **No Plan**.

Once a change request is submitted, the change will be reflected in the Request Record.

A Request Record card contains the following information:

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

| **#** | **Field** | **Description** |
| --- | --- | --- |
| **Card Header** | | |
|  | Title | Indicate the Request Action.  **New Record** - Add a new record.  **Update Record** - Update an existing record.  **Delete Record** - Delete an existing record. |
|  | Status | Status of the request Record.  **No Plan** - No planned change.  **New** - Input of new change.  **Pending** - Request is pending for approval.  **Approved** - Request had been approved by Approver but not effective yet.  **Rejected** - Request had been rejected by Approver.  **Withdraw** -An approved request had been withdrawn. |
|  | Menu | Menu includes the choices for Withdrawn changes. |
| **Card Body** | | |
|  | Updated by  Approved by  Rejected by | This field will be updated according to the status of the Request Record.  **New / Pending status:**  This field will be displayed as **Updated by**. Indicate the user who made/submitted the request.  **Approved / Withdraw status:**  This field will be displayed as **Approved by.** Indicate the user who approved the change/withdrawal request.  **Rejected status:**  This field will be displayed as **Rejected by.** Indicate the user who rejected the request. |
|  | Last updated date | Last update date of the request record. This field will be updated whenever there is change to the status of the record. |
|  | Effective date | Effective Date Time of the request.  If the request is to execute as soon as possible, the effective date will be today.  If the request is to executed at tomorrow, the effective date will be tomorrow. |
|  | Effective until | The effective end date of the record.  For permanent records, Effective until is **Forever**. |

And the status of the Request Record should transit according to the following Matrix.

|  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- |
| To  From | No Plan | New | Pending | Approved | Rejected | Withdraw |
| No Plan |  | Requester start to request for a new change.  *(Before Submit)* |  |  |  |  |
| New |  |  | Requester submitted the change for approval. |  |  |  |
| Pending |  |  |  | Approver approved the change. | Approver rejected the change. |  |
| Approved | The approved change is effective. |  |  |  |  | Approver approved the withdraw of an approved change. |
| Rejected |  | Requester start to request a new change.  *(Before Submit)* |  |  |  |  |
| Withdraw |  | Requester start to request a new change.  *(Before Submit)* |  |  |  |  |

Users can click on the Current Record Card / Request Record Card to view the content before and after the change. When Users click on the Request Record Card, the changed value will be highlighted for easy reference.

![](data:image/png;base64...)

* + 1. Effective Date of the Change Request (Permanent Functions)

#FS10014b\_S0030\_02500

For Permanent Functions, once the change is effective, it will remain effective till further update in the future. These are the effective dates according to the type of the request.

**Effective as soon as possible**

Once Requester submitted the change to system and Approver had approved the change (if approval is required), the change will be effective as soon as possible and remain effective till further update in future.

This behaviour applies to the following schedule type:

* New record for as soon as possible
* Update for as soon as possible
* Delete for as soon as possible

**Effective tomorrow**

Once Requester submitted the change to system and Approver had approved the change (if approval is required), the change will be scheduled in the system. It will be effective since the SOD of the next trading date and remain effective till further update in future.

This behaviour applies to the following schedule type:

* New record for tomorrow
* Update for tomorrow
* Delete for tomorrow
  1. Authorization Flow

#FS10014b\_S0030\_02600

For request operations that are effective as soon as possible (For Exchange User functions), or effective today with a scheduled tomorrow (Permanent functions), a standard authorisation flow is adopted.

After Market Operation user complete their changes in edit/create/delete, user can press the “Submit” button to submit the request. According to the level of authorization required, it has following behaviours:

* No Authorization Required

Requester can submit a change and apply it to the system directly.

* Confirmation Required

A change confirmation will be prompted for requester, he/she needs to accept the change before submitting and apply into the system.

* 4-eye Change Confirmation Required (Requester / Approver)

A change request will be submitted as pending state and wait for approver to review and provide the approval. Requester and Approver must be different person.

Before the approval is made, Requester can check the current state of the request and reject it if it is no longer valid.

If Approver or Requester rejects the change, it is marked as “Rejected”.

It should be noted that as part of the end of day housekeeping job, remaining pending requests are discarded and a report will be generated along with the request detail. And pending change request with as soon as possible will be rejected by system if it cannot be approved.

* + 1. Countersign Request

#FS10014b\_S0030\_02700

The screen allows user to view request of today and search change request by Function Name, Requester, Status, etc. The search screen will display all the change request in the system. User can further view the detail of the Request if they have the write/approve permission of the corresponding Function.

**Screen Layout**

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

**Attributes**

| **Screen Label** | **Type** | **Size** | **Remarks** |
| --- | --- | --- | --- |
| Req Status | Alphanumeric  **Table Cell** | 10 | Status of authorization request.  Domain values:  **Pending**  **Approved**  **Failed**  **Rejected** |
| Req Action | Alphanumeric  **Table Cell** | 8 | Request Action to be performed.  Domain values:  **Add -** Add a new Record  **Update -** Update a Record  **Delete -** Delete a Record  **Withdraw -** Withdraw a planned change |
| Req ID | Numeric  **Table Cell** | 10 | A unique identifier for the change request to be authorised. |
| Received At | Date and Time  **Table Cell** | 14 | Request submit time in DD-MMM-YYYY HH:MM:SS. |
| Function Name | Alphanumeric  **Table Cell** | 80 | Function name that the request is going to perform the change on. |
| Requester | Alphanumeric | 120 | Name of requester. |
| Effective Date | Date  **Table Cell** | 8 | The date that the request will be effective in DD-MMM-YYYY. |

**Validation**

For Approve Action

* Check Approver is not the Requester.
* Check whether the approver has the rights to approve the request.
* Check whether the change request has been approved/rejected.
* Check whether the request effective date is passed.

For Reject Action

* Make sure the original requester and approver can reject the request.
* Check whether the approver has the rights to reject the request.
* Check whether the change request has been approved/rejected.

**Available Actions**

| **Action** | **Description** |
| --- | --- |
| Screen Open | Trigger a query to display all request of today |
| Search | Trigger a query based on selected request type and status |
| Double Click a row | Same as above |
| Approve Authorization Request | Approve the selected requests. User can approve one or more request at a time. |
| Approve all Pending Authorization Request | Approve all the Pending requests at one go. (Except the Pending requests raised by the user). |
| Export summaries to CSV file | Export the summaries of the selected Authorization Requests as a CSV file. |
| Export all summaries to CSV file | Export the summaries of all Authorization Requests as a CSV file based on the filtering criteria. |
| Export details to CSV file | Export the detail of the selected Authorization Request as a CSV file. |
| Export all details to CSV file | Export the detail all Authorization Request as a CSV file based on the filtering criteria. |
| Reject Authorization Request | Reject the selected requests. User can approve one or more request at a time. |
| Reject all Pending Authorization Request | Reject all the Pending requests at one go. |

* + 1. Authorization Request Detail Screen

#FS10014b\_S0030\_02800

This screen allows user to view the detail of a request and performs approve/reject if he/she is authorized to do.

Requesters are allowed to Reject the Authorization Request that was raised by themselves.

Approvers are allowed to Approve the Authorization Request if they have the approval permission of the corresponding Request Type. And Approver should be a different person from the Requester of the Authorization Request.

Change Detail is available only when User have Read rights of the corresponding Function.

**Screen Layout**

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

**Attributes**

Generate Information Section display the general information of the request. This section should be common to all requests.

| **Column** | **Type** | **Size** | **Remarks** |
| --- | --- | --- | --- |
| **General Information** | | | |
| Request ID | Numeric  **Text Input** | 10 | A unique identifier for the change request to be authorized. |
| Requester | Alphanumeric  **Text Input** | 120 | Name of the User who raise the request. |
| Request Status | Alphanumeric  **Text Input** | 10 | Status of authorization request.  Domain values:  **Pending**  **Approved (Highlighted in green)**  **Failed**  **Rejected (Highlighted in red)** |
| Function Name | Alphanumeric  **Text Input** | 80 | Function name that the request is going to perform the change on. |
| Request Action | Alphanumeric  **Text Input** | 10 | Request Action to be performed.  Domain values:  **Add -** Add a new Record  **Update -** Update a Record  **Delete -** Delete a Record  **Withdraw -** Withdraw a planned change |
| Received At | Alphanumeric  **Text Input** | 19 | Request submit date and time in YYYY-MM-DD HH:MM:SS |
| Update At | Alphanumeric  **Text Input** | 19 | The time that the request status is updated. |
| Effective Date | Date | 8 | The date that the request will be effective in DD-MMM-YYYY. |
| Approver | Alphanumeric  **Text Input** | 120 | Name of the User who approve the request. |
| Rejecter | Alphanumeric  **Text Input** | 120 | Name of the User who rejected the request. |

Request Detail Section displays the detail of the Action.

| **Column** | **Type** | **Size** | **Remarks** |
| --- | --- | --- | --- |
| **Change Detail** | | | |
| Action | Alphanumeric  **Table Cell** | 10 | Action to be performed on the Attribute.  **Add -** Add new value to the Attribute  **Update -** Update the value of the Attribute  **No change -** No change to the Attribute  **Delete -** Record to be deleted  **Withdraw -** Value to withdraw |
| Record Type | Alphanumeric  **Table Cell** | 30 | Underlying Record Type of the Record involved in this change. |
| Attribute | Alphanumeric  **Table Cell** | TBC | Attributes of the Record.  If there are more than one record with the same Record Type, a prefix “**Record X -** “will be added to the Attribute in order to distinguish between records. |
| Value | Alphanumeric  **Table Cell** | TBC | The value of the Attribute. The meaning of the field depends on the **Action**:  **When Action is “Add”:**  Value to be inserted to DB  **When Action is “Delete”:**  Record ID of the record to be delete  **When Action is “Withdraw”:**  Value to be withdraw  **When Action is “No Change”:**  Show the current value in DB  **\* This field is empty when Action is “Update”.** |
| From | Alphanumeric  **Table Cell** | TBC | The value of the Attribute before the change.  Display the existing value in Database.  **\* This field only applicable when Action is “Update”** |
| To | Alphanumeric  **Table Cell** | TBC | The value of the Attribute after the change.  **\* This field only applicable when Action is “Update”** |

**Examples**

Add New Record

When creating a new Record, the action of all the attributes should be **Add**. **From** column should be empty and **To** column shows the target values to be insert to database.

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

Update a Record

When updating a Record, the unchanged field of the Record will be displayed as **No Change** for user to identify which record is being updated.

And the action of the attribution being changed is showing as **Update**. The existing value and target value are displayed in the **From** and **To** column respectively.

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

Delete a Record

When delete a Record, the key field of the Record to be deleted will be displayed as **Delete** for user to identify which record is being deleted.

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

Withdraw a change request

When withdrawing a change request, the Action of the attributes are all **Withdraw**.

The original Request’s action will show up on the Changes Detail table. And follow with the original Request’s change detail to indicate the detail to be withdrawn.

Here is the sample:

1. Withdraw an “Add” request

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

1. Withdraw an “Update” request

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

1. Withdraw a “Delete” request

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

**Validation**

For Approve Action

* Check Approver is not the Requester.
* Check whether the approver has the rights to approve the request.
* Check whether the change request has been approved/rejected.
* Check whether the request effective date is passed.

For Reject Action

* Make sure the original requester and approver can reject the request.
* Check whether the approver has the rights to reject the request.
* Check whether the change request has been approved/rejected.

**Available Actions**

| **Action** | **Description** |
| --- | --- |
| Screen Open | Display request detail to screen. |
| Export to CSV file | Export request detail in CSV file. |
| Approve | Approve the Authorization Request.  It should be enabled only when the request is in **Pending**/**Failed** status, user should have the permission to approve and user is not the Requester of the request. |
| Reject | Reject the Authorization Request.  It should be enabled only when the request is in **Pending**/**Failed** status or user should have the permission to reject. |

## User Preferences

#FS10014b\_S0030\_02900

Re-order/Resize column in search page will not be saved as user preferences.

## Inheritance

#FS10014b\_S0030\_03000

If any field inherits from the upper-level, the checkbox of the field will be checked, and the field will be disabled and show value loaded from the upper-level current active record of the system, regardless of when (Tomorrow and ASAP) the record will take effect.

When creating new record, inheritable fields will inherit from upper-level automatically in UI. It is allowed to uncheck the checkbox to change the value.

## Permissions

#FS10014b\_S0030\_03100

User who has read ONLY permission is disallowed to create, change or clone; related functions will be disabled.

# PTRM Functions

#FS10014b\_S0040\_00100

## Common

#FS10014b\_S0040\_00200

### Function Type

#FS10014b\_S0040\_00300

Perm: changes will be carried forward to Tomorrow

For functions support Perm ONLY, the supported operation will be Tomorrow ONLY.

| Combination | Function Type | Supported Operation |
| --- | --- | --- |
| Tomorrow ONLY | Perm | Tomorrow |
| Perm | Perm | Tomorrow |
| ASAP + Tomorrow |

The function is listed in the table below.

| Function Group | Function | Perm | |
| --- | --- | --- | --- |
| Tomorrow | Intraday |
| Maintain Functions | Maintain Risk Group - New/Delete | Y | N |
| Maintain Risk Group Detail - Update | N | Y |
| Maintain Risk Group - Import | Y  (Depends on import item) | Y  (Depends on import item) |
| Maintain Risk Order Coefficient Detail - Update | Y | N |
| Maintain Position Limit Detail - Update | N | Y |
| Maintain Tradable List Detail - Update | Y | N |
| Maintain Risk Group User Detail - Update | Y  (Add and Delete) | N |
| Maintain Risk Group Notification Detail - Update | Y  (Delete) | Y  (Add) |
| Control & Monitoring Functions | Control Risk Group | N | Y |

### Change History

#FS10014b\_S0040\_00400

Change History dialog can be opened from Detail screen per record individually and display up to 7 years.

### Common Attributes

#FS10014b\_S0040\_00500

| Attribute | Type | Size | Domain Value |
| --- | --- | --- | --- |
| Date Format | Alphanumeric | 12 | Year (YYYY)  Year (YY)  Year (Y)  Month Code  Month Number (NN)  Month Name (MMM)  Date (DD)  Week Number (WW) |
| Max | Numeric | 8 | 922337203685477 |

### Common Permission Behaviour

#FS10014b\_S0040\_00600

| User | Permission | Description |
| --- | --- | --- |
| Read ONLY | Read | All attributes are read ONLY |
| Maker | Read + Write | User can submit changes, reject changes created by the maker, and withdraw all approved changes which have not taken effect |
| Checker | Read + Write + Approval | User can review change request, approve and reject |

### Common Actions

#FS10014b\_S0040\_00700

Perm:

| Action | Description |
| --- | --- |
| Screen Open | Trigger a query to display all records |
| Apply | Trigger a query of records based on input filters |
| Reset Filter | Reset all filters to default: All |
| New Record | New Tomorrow Change: create new record for Tomorrow |
| New ASAP Change: create new record for ASAP and Tomorrow |
| Update Record | Update Tomorrow Change: update record for Tomorrow |
| Update ASAP Change: update record for ASAP and Tomorrow |
| Delete Record | Delete Tomorrow Change: delete record for Tomorrow |
| Delete ASAP Change: delete record for ASAP and Tomorrow |
| Withdraw Selected | Withdraw selected record which Records Status is Active and without withdraw history |
| Export | Export all Records from GUI current page table to CSV file |
| Confirm | Confirm the change and submit to backend, disabled with Read Only permission and view mode |
| Cancel | Cancel all changes, disabled with Read Only permission and view mode |

### Common Validation

#FS10014b\_S0040\_00800

| Event | Validation Rule | Validation Message |
| --- | --- | --- |
| New Request | Unique identifier must be unique | Duplicated identifier |
| Update Request | Unique identifier cannot be updated | Unique identifier cannot be updated |
| New/Update Request | Any mandatory field is empty | Invalid Input |
| Invalid value input | Invalid Input |

### Common Notification

#FS10014b\_S0040\_00900

| Event | Notification |
| --- | --- |
| New Request | Pop up a notification to indicate that a new record has been created |
| Update/Delete Request | Pop up concurrent notification if any concurrent update/delete occurred |

### Common Sorting

#FS10014b\_S0040\_01000

All data columns in the search page are sortable, with a maximum of three columns being sorted concurrently.

## Maintain Functions

#FS10014b\_S0040\_01100

### Maintain Risk Group

#FS10014b\_S0040\_01201

#### Description

The risk group allows for configurable parameters in the Pre-Trade Risk Management (PTRM) system.

This function is applicable to both External and Internal.

1. External

This window enables users to manage their own risk groups within the Maintain risk group section. Users can add or delete non base risk groups, and maintain limits, position limits, users, and notifications.

1. Internal

This window displays the risk groups of all participants in PTRM. Users can add or delete risk groups, and maintain limits, position limits, users, and notifications on behalf of clients if required. These actions require second-user approval.

Risk group can be categorized into base risk groups, and non-base risk groups.

Both internal/external users have the capability to import/export the data in CSV file format.

#### Scope of the data

The table of Maintain Risk Group search page and import page can display up to 60,000 records. (TBC)

The records displayed in this window is different between External and Internal:

1. External

This window is used to display and manage a user’s own risk groups within the company. The Maintain Risk Group table displays all the risk groups managed by the participant to whom the user belongs.

1. Internal

This window is used to display risk group of all participants that currently existed in PTRM.

#### Permission Behaviour (Ref: [Common Permission Behaviour](#_Common_Permission_Behaviour))

#### Notification (Ref: [Common Notification](#_Common_Notification))

#### Search Page

#FS10014b\_S0040\_01300

##### Accessing the Function

The “Maintain Risk Group” window can be opened through the Maintain Menu.

Only internal users and sponsoring participants are permitted to use this function. Internal users can access all data, while sponsoring participants are limited to accessing their own data.

##### Filtering Criteria

Following filter field is available for criteria search.

| **Filtering Criteria** | **Type** |
| --- | --- |
| Sponsoring /Sponsored /Risk Group | Text Input (with Content Assist) |

##### UI Layout

![](data:image/png;base64...)

More Actions

![](data:image/png;base64...)

##### Attributes

#FS10014b\_S0040\_01400

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| **Identity** | | | | | |
| Sponsoring Participant | Alphanumeric  **Table Cell** | 5 | M | - | Participants can be categorized as sponsoring participants |
| Sponsored Participant | Alphanumeric  **Table Cell** | 5 | M | - | Participants can be categorized as sponsored participants |
| Risk Group ID | Alphanumeric  **Table Cell** | 32 | M | - | A unique ID representing the risk group, it can be categorized as base risk group, and non-base risk group |
| **Order Rate** | | | | | |
| Period | Numeric  **Real-time**  **Table Cell** | 3  (1 – 300) | M | 300 | A period to determine number of orders entered by the Sponsored Users |
| Limit | Numeric  **Real-time**  **Table Cell** | 20  (0 – Max) | M | Max  (Refer to section Common Attribute) | Allowed number of orders within the order rate period  A zero value would lead to immediate blocking of the risk group |

##### Actions (Ref: [Common Actions](#_Common_Actions))

#FS10014b\_S0040\_01500

| Action | Description |
| --- | --- |
| Maintain Risk Group Detail | Double click the expanded base or non-base risk group row to open “Maintain Risk Group Detail” dialog window |
| New Record for tomorrow | Users can click the “New Record” button, select new record for tomorrow to open the Maintain Risk Group Detail dialog |
| Clone Record for tomorrow | Users can click the “Clone Record” button, select clone record for tomorrow to open the Maintain Risk Group Detail dialog  The button is disabled by default and will be enabled once a risk group row is selected  This action is used to clone record and automatically input the non-unique fields for new record |
| Import record | User can click the “Import record” in toolbar button |
| Withdraw selected | This action is used to withdraw request |
| Export | The button is disabled by default and will be enabled once sponsored, base group or non base group participant selected, it is used to export the selected participant’s details, the exported CSV can be used for importing risk group. |

##### Validation (Ref: [Common Validation](#_Common_Validation))

#### Detail Page

#FS10014b\_S0040\_01600

Record Status (Ref: [Current Record and Request Record](#_Current_Record_and))

##### Accessing the Function

The “Maintain Risk Group Detail” window can be opened by either double-clicking the specific risk groups in the “Maintain Risk Group” section or by select specific risk groups and clicking “New Record for Tomorrow” toolbar button or the “New Record for Tomorrow” in toolbar button.

Only internal users and sponsoring participants are permitted to use this function. Internal users can access all data, while sponsoring participants are limited to accessing their own data.

##### Filtering Criteria

N/A

##### UI Layout

New Record

![](data:image/png;base64...)

Update Record

![](data:image/png;base64...)

Update Record - Record Card Actions

![](data:image/png;base64...)

##### Attributes

#FS10014b\_S0040\_01700

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| **Identity** | | | | | |
| Sponsoring Participant | Alphanumeric  **Content Assist** | 5 | M | - | Refer to Maintain Risk Group attributes |
| Sponsored Participant | Alphanumeric  **Content Assist** | 5 | M | - | Refer to Maintain Risk Group attributes |
| Risk Group Suffix | Alphanumeric  **Text Input** | 16 | M | - | Suffix of Risk Group |
| Risk Group ID | Alphanumeric  **Text Input** | 32 | M | - | Refer to Maintain Risk Group attributes  When first risk group of sponsored participant created, it will be treated as the base risk group. The risk group will have ‘\_BASE’ appended to their names, and the field is non-editable.  It will be combined by Sponsoring Participant, Sponsored Participant, Risk Group Suffix with underscore. |
| Default Risk Group | Boolean  **Checkbox** | 1 | M | - | When first risk group of sponsored participant created, it will be treated as the base risk group. The default risk group will be on, and the field is non-editable.  The default risk group cannot be removed until all non-default risk groups are removed. Non-default risk groups can be removed by the sponsoring participant, but only an internal user can remove the default risk group. |
| Position Limit ID | Numeric  **Text Input** | 5 | M | - | A system-generated ID for position limit update for each risk group, which will only be displayed after the risk group is created. |
| Tradable List ID | Numeric  **Text Input** | 5 | M | - | A system-generated ID for tradable insertion or deletion for each risk group, which will only be displayed after the risk group is created |
| User List ID | Numeric  **Text Input** | 5 | M | - | A system-generated ID for risk group user list maintenance for each risk group, which will only be displayed after the risk group is created. |
| Notification ID | Numeric  **Text Input** | 5 | M | - | A system-generated ID for risk group notification maintenance for each risk group, which will only be displayed after the risk group is created. |
| **General Parameters** | | | | | |
| Position Limit Notice Threshold (%) | Numeric  **Editable**  **Text Input** | 3  (0 – 99) | M | 50 | A threshold to notify users when the risk group limits reach a specified percentage  Notice threshold is required to lower than warning threshold except 0 |
| Position Limit Warning Threshold (%) | Numeric  **Editable**  **Text Input** | 3  (0 – 99) | M | 75 | A threshold to warn users when the risk group limits reach a specified percentage |
| **Order Rate** | | | | | |
| Order Rate Period (Sec) | Numeric  **Editable**  **Text Input** | 3  (1- 300) | M | 300 | Refer to Maintain Risk Group attributes |
| Order Rate Limit | Numeric  **Editable**  **Text Input** | 20  (0 – Max) | M | Max  (Refer to section Common Attribute) | Refer to Maintain Risk Group attributes |
| **Intraday Exposure Check - Text Input** | | | | | |
| Futures Order Coefficient (%) | Numeric  **Editable**  **Text Input** | 3  (0 – 100) | M | 100 | The field is only editable for new records and will be effective tomorrow.  **#FS10005\_S0050\_20509** |
| Options Order Coefficient (%) | Numeric  **Editable**  **Text Input** | 3  (0 – 100) | M | 100 | The field is only editable for new records and will be effective tomorrow.  **#FS10005\_S0050\_20510** |
| Exposure Notice Threshold (%) | Numeric  **Editable**  **Text Input** | 3  (0 – 99) | M | 50 | A threshold to notify users when the risk group limits reach a specified percentage for intraday exposure check  Notice threshold is required to lower than warning threshold |
| Exposure Warning Threshold (%) | Numeric  **Editable**  **Text Input** | 3  (1 – 99) | M | 75 | A threshold to warn users when the risk group limits reach a specified percentage for intraday exposure check |
| Gross Futures Exposure Limit (HKD Eqv) | Numeric  **Editable**  **Text Input** | 20  (0 – Max) | M | Max  (Refer to section Common Attribute) | Allowed Risk Exposure consumed by the sponsored user within the risk group |
| Net Futures Exposure Limit (HKD Eqv) | Numeric  **Editable**  **Text Input** | 20  (0 – Max) | M | Max  (Refer to section Common Attribute) | Allowed Risk Exposure consumed by the sponsored user within the risk group |
| Gross Options Exposure Limit (HKD Eqv) | Numeric  **Editable**  **Text Input** | 20  (0 – Max) | M | Max  (Refer to section Common Attribute) | Allowed Risk Exposure consumed by the sponsored user within the risk group |
| Net Options Exposure Limit (HKD Eqv) | Numeric  **Editable**  **Text Input** | 20  (0 – Max) | M | Max  (Refer to section Common Attribute) | Allowed Risk Exposure consumed by the sponsored user within the risk group |
| **Execution Throttle Check – Text Input** | | | | | |
| Period (Sec) | Numeric  **Editable**  **Text Input** | 3  (300 – 600) | M | 600 | A period to determine number of orders entered for  Execution Throttle period  The counter will be reset to zero once updated |
| Execution Notice Threshold (%) | Numeric  **Editable**  **Text Input** | 3  (0 – 99) | M | 50 | A threshold to notify users when the risk group limits reach a specified percentage for execution throttle check  Notice threshold is required to lower than warning threshold |
| Execution Warning Threshold (%) | Numeric  **Editable**  **Text Input** | 3  (1 – 99) | M | 75 | A threshold to warn users when the risk group limits reach a specified percentage for execution throttle check |
| Gross Futures Execution Throttle Limit (HKD Eqv) | Numeric  **Editable**  **Text Input** | 20  (0 – Max) | M | Max  (Refer to section Common Attribute) | Allowed Execution Exposure consumed in a defined period by the sponsored users within the risk group  The counter will be reset to zero once updated |
| Gross Options Execution Throttle Limit (HKD Eqv) | Numeric  **Editable**  **Text Input** | 20  (0 – Max) | M | Max  (Refer to section Common Attribute) | Allowed Execution Exposure consumed in a defined period by the sponsored users within the risk group  The counter will be reset to zero once updated |
| **Email Notification** | | | | | |
| Notice | Boolean  **Toggle Button** | 1 | O | Y | This flag enables notice level monitoring |
| Warning | Boolean  **Toggle Button** | 1 | O | Y | This flag enables warning level monitoring |
| Breach | Boolean  **Toggle Button** | 1 | O | Y | This flag enables breach level monitoring |

Refer to FS10005 - PTRM FS APPENDIX II – Risk Check Parameters attributes for the details

##### Actions (Ref: [Common Actions](#_Common_Actions))

#FS10014b\_S0040\_01800

| Action | Description |
| --- | --- |
| Update for as soon as possible | This action is used to update record and effective as soon as possible, second-user approval is required for internal users. |
| Delete for tomorrow | This action is used to delete record and effective tomorrow second-user approval is required for internal users.  The button will be hidden when risk group is base group and other non-base risk group existed in PTRM. |
| Confirm | The button is disabled by default and will be enabled once record card status selected, it is used to save and persist the changes in backend |
| Cancel | It is used to close the current window, the unsaved changes will be discarded if record card status selected |

##### Validation (Ref: [Common Validation](#_Common_Validation))

| Event | Notification |
| --- | --- |
| Confirm | All mandatory fields cannot be empty |

#### Import Page

#FS10014b\_S0040\_01900

##### Accessing the Function

The “Import Record” window can be opened by clicking “Import Record” toolbar button, this function is used to maintain risk group record with details (risk group, order coefficient and tradable) by uploading CSV file, only one risk group with details with intraday or tomorrow change can be supported during each import action.

Only internal users and sponsoring participants are permitted to use this function. Internal users can access all data, while sponsoring participants are limited to accessing their own data.

Supported Import Function

| Function | Perm | |
| --- | --- | --- |
| Tomorrow | Intraday |
| Maintain Risk Group Detail - Update | N | Y |
| Maintain Risk Order Coefficient Detail - Update | Y | N |
| Maintain Position List Detail - Update | N | Y |
| Maintain Tradable List Detail - Add/Delete | Y | N |

Supported Import Attribute Key

| Function | Type |
| --- | --- |
| Maintain Risk Group Detail - Update | order\_rate\_period |
| order\_rate\_limit |
| pos\_limit\_notice\_threshold |
| pos\_limit\_warning\_threshold |
| net\_futures\_exposure\_limit |
| gross\_futures\_exposure\_limit |
| net\_options\_exposure\_limit |
| gross\_options\_exposure\_limit |
| exposure\_notice\_thres |
| exposure\_warning\_thres |
| gross\_futures\_exec\_throttle\_unit |
| gross\_options\_exec\_throttle\_unit |
| exec\_throttle\_period |
| exec\_notice\_thres |
| exec\_warning\_thres |
| is\_enable\_notice\_email |
| is\_enable\_warning\_email |
| is\_enable\_breach\_email |
| Maintain Risk Order Coefficient Detail - Update | futures\_order\_coefficient |
| options order\_coefficient |
| Maintain Tradable List Detail - Add/Delete/Update  Note:  Add Tradable: All corresponding position limit parameters must already exist and be available. The request will be rejected if any required position limit parameter is missing.  Delete Tradable: The tradable ID must be provided.  Update Tradable: Only the position limit parameters explicitly provided in the request will be updated; all other existing parameters will remain unchanged. | open\_buy\_limit |
| open\_sell\_limit |
| traded\_bought\_limit  traded\_sold\_limit |
| total\_buy\_limit |
| total\_sell\_limit |
| total\_net\_buy\_limit |
| total\_net\_sell\_limit |
| block\_trade\_bought\_limit |
| block\_trade\_sold\_limit |
| max\_order\_size |
| max\_block\_trade\_size |

CSV Content Format

To update **Risk Group**, **Risk Order Coefficient** and **Position Limits**, performing **Tradables** maintainactions (add/delete), the following fields are mandatory: **Risk Group ID**, **Parameter Type**, and **Parameter Value**.

Additionally, for **Position Limits** updates and **Tradables** maintenance actions (add/delete), **Tradable ID** and **Tradable Change Type** are required.

| Field | M/O | Example |
| --- | --- | --- |
| Risk Group ID | M | HKCZZZ\_HKZZZ\_BASE |
| Parameter Type | M | max\_order\_size |
| Parameter Value | M | 300 |
| Tradable ID | O | 134 |
| Product Type | O | M - Market  T – Instrument Type  t – Combo Type  C – Instrument Class  c – Combo Class |
| Tradable Change Type | O | ADD/UPD/DEL |

##### Filtering Criteria

N/A

##### UI Layout

Import CSV – Succeed

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

Import CSV – Failed

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

Submit CSV - Succeed

![A screenshot of a computer  AI-generated content may be incorrect.](data:image/png;base64...)

##### Attributes

#FS10014b\_S0040\_02000

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| **Import** | | | | | |
| Import Type | Alphanumeric  **Text Input** | 12 | M | Risk Group | A label in import dialog |
| Activation Type | Alphanumeric  **Editable**  **Dropdown** | 20 | M | As soon as possible | A dropdown menu for selecting ‘as soon as possible’ or ‘tomorrow’, and user must select before clicking the Import button.  It will be disabled after imported CSV file. |
| Filename | Alphanumeric  **Text Input** | 80 | M | - | Filename of CSV |
| **Import Preview** | | | | | |
| Number | Numeric  **Table Cell** | - | M | - | Line number of data in CSV |
| Req Action | Alphanumeric  **Table Cell** | 5 | M | Add | - |
| Status | Alphanumeric  **Table Cell** | 10 | M | New | - |
| Rej Reason | Alphanumeric  **Table Cell** | 255 | O | - | Reject reason for each failed data |
| Risk Group ID | Alphanumeric  **Table Cell** | 32 | M | - | Refer to Maintain Risk Group Attributes |
| Type | Alphanumeric  **Table Cell** | 255 | M | - | A risk group import attribute key for matching data in PTRM |
| Value | Alphanumeric  **Table Cell** | 255 | M | - | A value for the risk group import attribute key |
| Delete | Alphanumeric  **Table Cell** | 1 | O | N/A | A flag to determine delete case for position limit |
| Tradable | Alphanumeric  **Table Cell** | 12 | O | N/A | Refer to Maintain Position Limit Attributes |

##### Actions (Ref: [Common Actions](#_Common_Actions))

#FS10014b\_S0040\_02100

| Action | Description |
| --- | --- |
| Import | It is a button to import the CSV file, attribute validation will be performed, and the status result will be displayed in the preview table. |
| Reset | It is a button to clear the imported CSV file and the preview table when the preview table is required for further updates. |
| Export | It is a button to export the imported data along with the status result for further updates. |
| Cancel | It is a button to close the dialog, the button will be disabled after submission |
| Confirm | It is a button to confirm and submit the preview table to PTRM, the button will be disabled after submission or if attribute validation fails after import. |

##### Validation (Ref: [Common Validation](#_Common_Validation))

| Event | Notification |
| --- | --- |
| Import - Import Validation | All fields must be follow attributes and function type |
| Import – Confirm Validation | All imported data must be validated by PTRM |

### Maintain Risk Order Coefficient

#FS10014b\_S0040\_02200

#### Description

This function is applicable to both External and Internal.

1. External

This window allows users to manage the risk order coefficient in PTRM

1. Internal

This window allows users to manage the risk order coefficient in PTRM on behalf of clients if required. These actions require second-user approval.

#### Scope of the data

The records displayed in this window is different between External and Internal:

1. External

This window is used to manage the Risk Order Coefficient of a user’s own risk groups within the company, including intraday exposure check.

1. Internal

This window is used to display the Risk Order Coefficient of all participants’ risk groups currently existing in PTRM. Any update action requires second-user approval.

#### Permission Behaviour (Ref: [Common Permission Behaviour](#_Common_Permission_Behaviour))

#### Notification (Ref: [Common Notification](#_Common_Notification))

#### Search Page

#FS10014b\_S0040\_02300

##### Accessing the Function

The “Maintain Risk Order Coefficient” window can be opened through the Maintain Menu.

Only internal users and sponsoring participants are permitted to use this function. Internal users can access all data, while sponsoring participants are limited to accessing their own data.

##### Filtering Criteria

Following filter field is available for criteria search.

| **Filtering Criteria** | **Type** |
| --- | --- |
| Risk Group ID | Text Input (with Content Assist) |

##### UI Layout

![](data:image/png;base64...)

##### Attributes

#FS10014b\_S0040\_02400

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| **Identity** | | | | | |
| Risk Group ID | Alphanumeric  **Table Cell /Text Input** | 32 | M | - | base risk group and non-base risk group |
| **Intraday Exposure Check** | | | | | |
| Futures Order Coefficient (%) | Numeric  **Table Cell /Editable Text Input** | 3  (0 – 100) | M | 100 | The figure is only applicable for updates and will be effective tomorrow |
| Options Order Coefficient (%) | Numeric  **Table Cell /Editable Text Input** | 3  (0 – 100) | M | 100 | The figure is only applicable for updates and will be effective tomorrow |

Refer to FS10005 - PTRM FS APPENDIX II – Risk Check Parameters attributes for the details

##### Actions (Ref: [Common Actions](#_Common_Actions))

#FS10014b\_S0040\_02500

| Action | Description |
| --- | --- |
| Maintain Risk Order Coefficient Detail | Double click the risk order coefficient row to open “Maintain Risk Order Coefficient Detail” dialog window |

##### Validation (Ref: [Common Validation](#_Common_Validation))

#### Detail Page

#FS10014b\_S0040\_02600

Record Status (Ref: [Current Record and Request Record](#_Current_Record_and))

##### Accessing the Function

The “Maintain Risk Order Coefficient Detail” window can be opened by double-clicking the specific risk groups in the “Maintain Risk Order Coefficient” section.

Only internal users and sponsoring participants are permitted to use this function. Internal users can access all data, while sponsoring participants are limited to accessing their own data.

##### Filtering Criteria

N/A

##### UI Layout

![](data:image/png;base64...)

Record Card Actions

![A screenshot of a computer  Description automatically generated](data:image/png;base64...)

##### Attributes

#FS10014b\_S0040\_02700

Rerer to Search Page attributes

##### Actions (Ref: [Common Actions](#_Common_Actions))

#FS10014b\_S0040\_02800

| Action | Description |
| --- | --- |
| Update for tomorrow | This action is used to update record and effective for tomorrow, second-user approval is required for internal users. |
| Confirm (Next Day) | The button is disabled by default and will be enabled once record card status selected, it is used to save and persist the changes in backend |
| Cancel | It is used to close the current window, the unsaved changes will be discarded if record card status selected |

##### Validation (Ref: [Common Validation](#_Common_Validation))

| Event | Notification |
| --- | --- |
| Confirm (Next Day) | All mandatory fields cannot be empty |

### Maintain Position Limit

#FS10014b\_S0040\_02900

#### Description

This function is applicable to both External and Internal.

1. External

This window allows users to update the position limit by selecting specific risk groups in PTRM.

1. Internal

This window allows users to update the position limit by selecting specific risk groups in PTRM on behalf of clients if required. These actions require second-user approval.

#### Scope of the data

The table of Maintain Position Limit search page and detail page can display up to 60,000 and 2,000 records respectively. (TBC)

The records displayed in this window is different between External and Internal:

1. External

This window is used to manage the position limit of a user’s own risk groups within the company, including tradable details.

1. Internal

This window is used to display the position limit of all participants’ risk groups currently existing in PTRM. Any update action requires second-user approval.

#### Permission Behaviour (Ref: [Common Permission Behaviour](#_Common_Permission_Behaviour))

#### Notification (Ref: [Common Notification](#_Common_Notification))

#### Search Page

#FS10014b\_S0040\_03000

##### Accessing the Function

The “Maintain Position Limit” window can be opened through the Maintain Menu.

Only internal users and sponsoring participants are permitted to use this function. Internal users can access all data, while sponsoring participants are limited to accessing their own data.

##### Filtering Criteria

Following filter field is available for criteria search.

| **Filtering Criteria** | **Type** |
| --- | --- |
| Position Limit ID | Text Input (with Content Assist) |

##### UI Layout

![](data:image/png;base64...)

##### Attributes

#FS10014b\_S0040\_03100

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| **Identity** | | | | | |
| Position Limit ID | Numeric  **Table Cell** | 5 | M | - | Refer to Maintain Risk Group detail page Attributes |
| Name | Alphanumeric  **Table Cell** | 50 | M |  | - |
| Description | Alphanumeric  **Table Cell** | 40 | O | - | - |

##### Actions (Ref: [Common Actions](#_Common_Actions))

#FS10014b\_S0040\_03200

| Action | Description |
| --- | --- |
| Maintain Position Limit Detail | Double click the position limit row to open “Maintain Position Limit Detail” dialog window |

##### Validation (Ref: [Common Validation](#_Common_Validation))

#### Detail Page

#FS10014b\_S0040\_03300

Record Status (Ref: [Current Record and Request Record](#_Current_Record_and))

##### Accessing the Function

The “Maintain Position Limit Detail” window can be opened by double-clicking the specific risk groups in the “Maintain Position Limit” section.

Only internal users and sponsoring participants are permitted to use this function. Internal users can access all data, while sponsoring participants are limited to accessing their own data.

##### Filtering Criteria

N/A

##### UI Layout

![](data:image/png;base64...)

Record Card Actions

![](data:image/png;base64...)

##### Attributes

#FS10014b\_S0040\_03400

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| **Identity** | | | | | |
| Position Limit ID | Numeric  **Text Input** | 5 | M | - | Refer to Maintain Risk Group detail page Attributes |
| Name | Alphanumeric  **Text Input** | 50 | M | - | - |
| Description | Alphanumeric  **Editable Text Input** | 40 | O | - | - |
| **Position Limit** | | | | | |
| Tradable | Alphanumeric  **Table Cell** | 32 | M | - | - |
| Product Level | Alphanumeric | 16 | M | - | Market  Instrument Type  Instrument Class  Combo Type  Combo Class |
| Max Order Size | Numeric  **Editable**  **Table Cell**  **Text Input** | 20  (0 – 2,147,483,647) | M | 2,147,483,647 | **-** |
| Max Block Trade Size | Numeric  **Editable**  **Table Cell**  **Text Input** | 20  (0 – 2,147,483,647) | M | 2,147,483,647 | Display “-“ and non-editable if the tradable is selected from combo type/combo class |
| Breached | Boolean  **Read-only** | 1 | M | N | It is a hidden field and will be enabled when the tradable row is breached. The row data will be highlighted in red when the breach flag is enabled |
| **Position Limit - Open** | | | | | |
| Open Buy | Numeric  **Editable**  **Table Cell**  **Text Input** | 20  (0 – Max) | M | Max  (Refer to section Common Attribute) | Display “-“ and non-editable if the tradable is selected from combo type/combo class |
| Open Sell | Numeric  **Editable**  **Table Cell**  **Text Input** | 20  (0 – Max) | M | Max  (Refer to section Common Attribute) | Display “-“ and non-editable if the tradable is selected from combo type/combo class |
| **Position Limit - Traded** | | | | | |
| Traded Bought | Numeric  **Editable**  **Table Cell**  **Text Input** | 20  (0 – Max) | M | Max  (Refer to section Common Attribute) | Display “-“ and non-editable if the tradable is selected from combo type/combo class |
| Traded Sold | Numeric  **Editable**  **Table Cell**  **Text Input** | 20  (0 – Max) | M | Max  (Refer to section Common Attribute) | Display “-“ and non-editable if the tradable is selected from combo type/combo class |
| Traded Net | Numeric  **Editable**  **Table Cell**  **Text Input** | 20  (0 – Max) | M | Max  (Refer to section Common Attribute) | Display “-“ and non-editable if the tradable is selected from combo type/combo class |
| **Position Limit - Total** | | | | | |
| Total Buy | Numeric  **Editable**  **Table Cell**  **Text Input** | 20  (0 – Max) | M | Max  (Refer to section Common Attribute) | Display “-“ and non-editable if the tradable is selected from combo type/combo class |
| Total Sell | Numeric  **Editable**  **Table Cell**  **Text Input** | 20  (0 – Max) | M | Max  (Refer to section Common Attribute) | Display “-“ and non-editable if the tradable is selected from combo type/combo class |
| Total Net Buy | Numeric **Editable**  **Table Cell**  **Text Input** | 20  (0 – Max) | M | Max  (Refer to section Common Attribute) | Display “-“ and non-editable if the tradable is selected from combo type/combo class |
| Total Net Sell | Numeric **Editable**  **Table Cell**  **Text Input** | 20  (0 – Max) | M | Max  (Refer to section Common Attribute) | Display “-“ and non-editable if the tradable is selected from combo type/combo class |
| **Position Limit - Block Trade** | | | | | |
| Block Trade Bought | Numeric **Editable**  **Table Cell**  **Text Input** | 20  (0 – Max) | M | Max  (Refer to section Common Attribute) | Display “-“ and non-editable if the tradable is selected from combo type/combo class |
| Block Trade Sold | Numeric **Editable**  **Table Cell**  **Text Input** | 20  (0 – Max) | M | Max  (Refer to section Common Attribute) | Display “-“ and non-editable if the tradable is selected from combo type/combo class |

Refer to FS10005 - PTRM FS APPENDIX II – Risk Check Parameters attributes for the details

##### Actions (Ref: [Common Actions](#_Common_Actions))

#FS10014b\_S0040\_03500

| Action | Description |
| --- | --- |
| Update for as soon as possible | This action is used to update record and effective as soon as possible, only applicable for updating existing record, second-user approval is required for internal users. |
| Update | The column cell can be updated by double-clicking the existing tradable row |
| Confirm | The button is disabled by default and will be enabled once record card status selected, it is used to save and persist the changes in backend |
| Cancel | It is used to close the current window, the unsaved changes will be discarded if record card status selected |

##### Validation (Ref: [Common Validation](#_Common_Validation))

| Event | Notification |
| --- | --- |
| Confirm | All mandatory fields cannot be empty |

### Maintain Tradable List

#FS10014b\_S0040\_03510

#### Description

This function is applicable to both External and Internal.

1. External

This window allows users to add or delete the tradable by selecting specific risk groups in PTRM.

2. Internal

This window allows users to add or delete the tradable by selecting specific risk groups in PTRM on behalf of clients if required. These actions require second-user approval.

#### Scope of the data

The table of Maintain Tradable List search page and detail page can display up to 60,000 and 2,000 records respectively. (TBC)

The records displayed in this window is different between External and Internal:

1. External

This window is used to manage the tradable list of a user’s own risk groups within the company, including tradable details.

2. Internal

This window is used to display the tradable list of all participants’ risk groups currently existing in PTRM. Any update action requires second-user approval.

#### Permission Behaviour (Ref: [Common Permission Behaviour](#_Common_Permission_Behaviour))

#### Notification (Ref: [Common Notification](#_Common_Notification))

#### Search Page

#FS10014b\_S0040\_03520

##### Accessing the Function

The “Maintain Tradable” window can be opened through the Maintain Menu.

Only internal users and sponsoring participants are permitted to use this function. Internal users can access all data, while sponsoring participants are limited to accessing their own data.

##### Filtering Criteria

Following filter field is available for criteria search.

| **Filtering Criteria** | **Type** |
| --- | --- |
| Tradable List ID | Text Input (with Content Assist) |

##### UI Layout

![](data:image/png;base64...)

##### Attributes

#FS10014b\_S0040\_03530

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| **Identity** | | | | | |
| Tradable List ID | Numeric  **Table Cell** | 5 | M | - | Refer to Maintain Risk Group detail page Attributes |
| Name | Alphanumeric  **Table Cell** | 50 | M |  | - |
| Description | Alphanumeric  **Table Cell** | 40 | O | - | - |

##### Actions (Ref: [Common Actions](#_Common_Actions))

#FS10014b\_S0040\_03540

| Action | Description |
| --- | --- |
| Maintain Tradable List Detail | Double click the tradable list row to open “Maintain Tradable List Detail” dialog window |

##### Validation (Ref: [Common Validation](#_Common_Validation))

#### Detail Page

#FS10014b\_S0040\_03550

Record Status (Ref: [Current Record and Request Record](#_Current_Record_and))

##### Accessing the Function

The “Maintain Tradable List Detail” window can be opened by double-clicking the specific risk groups in the “Maintain Tradable List” section.

Only internal users and sponsoring participants are permitted to use this function. Internal users can access all data, while sponsoring participants are limited to accessing their own data.

##### Filtering Criteria

N/A

##### UI Layout

![](data:image/png;base64...)

Record Card Actions

![](data:image/png;base64...)

##### Attributes

#FS10014b\_S0040\_03560

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| **Identity** | | | | | |
| Tradable List ID | Numeric  **Text Input** | 5 | M | - | Refer to Maintain Risk Group detail page Attributes |
| Name | Alphanumeric  **Text Input** | 50 | M | - | Alphanumeric  **Text Input** |
| Description | Alphanumeric  **Editable Text Input** | 40 | O | - | Alphanumeric  **Editable Text Input** |
| **Tradables** | | | | | |
| Tradable | Alphanumeric  **Table Cell** | 32 | M | - | - |
| Product Level | Alphanumeric | 16 | M | - | Market  Instrument Type  Instrument Class  Combo Type  Combo Class |
| Max Order Size | Numeric  **Table Cell** | 20  (0 – 2,147,483,647) | M | 2,147,483,647 | The cell value is only displayed for newly added tradables. For existing records, it will be shown as - |
| Max Block Trade Size | Numeric  **Table Cell** | 20  (0 – 2,147,483,647) | M | 2,147,483,647 | The cell value is only displayed for newly added instrument type/class tradables. For existing records and combo type/class tradable, it will be shown as - |
| **Tradable – Open** | | | | | |
| Open Buy | Numeric  **Table Cell** | 20  (0 – Max) | M | Max  (Refer to section Common Attribute) | The cell value is only displayed for newly added instrument type/class tradables. For existing records and combo type/class tradable, it will be shown as - |
| Open Sell | Numeric  **Table Cell** | 20  (0 – Max) | M | Max  (Refer to section Common Attribute) | The cell value is only displayed for newly added instrument type/class tradables. For existing records and combo type/class tradable, it will be shown as - |
| **Tradable – Traded** | | | | | |
| Traded Bought | Numeric  **Table Cell** | 20  (0 – Max) | M | Max  (Refer to section Common Attribute) | The cell value is only displayed for newly added instrument type/class tradables. For existing records and combo type/class tradable, it will be shown as - |
| Traded Sold | Numeric  **Table Cell** | 20  (0 – Max) | M | Max  (Refer to section Common Attribute) | The cell value is only displayed for newly added instrument type/class tradables. For existing records and combo type/class tradable, it will be shown as - |
| Traded Net | Numeric  **Table Cell** | 20  (0 – Max) | M | Max  (Refer to section Common Attribute) | The cell value is only displayed for newly added instrument type/class tradables. For existing records and combo type/class tradable, it will be shown as - |
| **Tradable - Total** | | | | | |
| Total Buy | Numeric  **Table Cell** | 20  (0 – Max) | M | Max  (Refer to section Common Attribute) | The cell value is only displayed for newly added instrument type/class tradables. For existing records and combo type/class tradable, it will be shown as - |
| Total Sell | Numeric  **Table Cell** | 20  (0 – Max) | M | Max  (Refer to section Common Attribute) | The cell value is only displayed for newly added instrument type/class tradables. For existing records, it will be shown as - |
| Total Net Buy | Numeric  **Table Cell** | 20  (0 – Max) | M | Max  (Refer to section Common Attribute) | The cell value is only displayed for newly added instrument type/class tradables. For existing records and combo type/class tradable, it will be shown as - |
| Total Net Sell | Numeric  **Table Cell** | 20  (0 – Max) | M | Max  (Refer to section Common Attribute) | The cell value is only displayed for newly added instrument type/class tradables. For existing records and combo type/class tradable, it will be shown as - |
| **Tradable - Block Trade** | | | | | |
| Block Trade Bought | Numeric **Editable**  **Table Cell**  **Text Input** | 20  (0 – Max) | M | Max  (Refer to section Common Attribute) | The cell value is only displayed for newly added instrument type/class tradables. For existing records and combo type/class tradable, it will be shown as - |
| Block Trade Sold | Numeric **Editable**  **Table Cell**  **Text Input** | 20  (0 – Max) | M | Max  (Refer to section Common Attribute) | The cell value is only displayed for newly added instrument type/class tradables. For existing records and combo type/class tradable, it will be shown as - |

Refer to FS10005 - PTRM FS APPENDIX II – Risk Check Parameters attributes for the details

##### Actions (Ref: [Common Actions](#_Common_Actions))

#FS10014b\_S0040\_03570

| Action | Description |
| --- | --- |
| Update for tomorrow | This action is used to update record and effective for tomorrow, second-user approval is required for internal users |
| Add | This button is used to add tradable into tradable list |
| Delete | This button is used to delete tradable from tradable list |
| Confirm | The button is disabled by default and will be enabled once record card status selected, it is used to save and persist the changes in backend |
| Cancel | It is used to close the current window, the unsaved changes will be discarded if record card status selected |

##### Validation (Ref: [Common Validation](#_Common_Validation))

| Event | Notification |
| --- | --- |
| Confirm | All mandatory fields cannot be empty |
| Add | The Maximum number of rows is 1000 (TBC) |

#### Add Tradable Page

##### Accessing the Function

The “New Tradable” window can be opened by clicking the “Add” button in the “Maintain Tradable List Detail” window.

Only internal users and sponsoring participants are permitted to use this function. Internal users can access all data, while sponsoring participants are limited to accessing their own data.

##### Filtering Criteria

N/A

##### UI Layout

![](data:image/png;base64...)

##### Attributes

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| **Tradables** | | | | | |
| Market | Alphanumeric  **Editable Dropdown** | 5 | M | - | Domain values:  **All non-dummy markets defined in Market Operation Admin GUI** |
| Type / Class | Alphanumeric  **Editable Dropdown** | 14 | O | - | All option is provided, tradable will be selected as market when the type/class selected as all  Domain values:  **All**  **Instrument Type**  **Instrument Class**  **Combo Type**  **Combo Class** |
| Tradable | Alphanumeric  **Editable Dropdown** | 32 | O | - | Domain values:  **It is a dynamic dropdown list based on the selected market and instrument/combo class/type**. |
| **Max Size** | | | | | |
| Max Order Size | Numeric  **Read-only or**  **Editable**  **Text Input** | 20  (0 – 2,147,483,647) | M | 2,147,483,647 | The text input will be read-only or editable, with the default parameter defined by system preferences of user maintenance in the trading admin GUI. |
| Max Block Trade Size | Numeric  **Read-only or**  **Editable**  **Text Input** | 20  (0 – 2,147,483,647) | M | 2,147,483,647 | The text input will be read-only or editable, with the default parameter defined by system preferences of user maintenance in the trading admin GUI. |
| **Open** | | | | | |
| Open Buy | Numeric  **Read-only or**  **Editable**  **Text Input** | 20  (0 – Max) | M | Max  (Refer to section Common Attribute) | The text input will be read-only or editable, with the default parameter defined by system preferences of user maintenance in the trading admin GUI. |
| Open Sell | Numeric  **Read-only or**  **Editable**  **Text Input** | 20  (0 – Max) | M | Max  (Refer to section Common Attribute) | The text input will be read-only or editable, with the default parameter defined by system preferences of user maintenance in the trading admin GUI. |
| **Traded** | | | | | |
| Traded Bought | Numeric  **Read-only or**  **Editable**  **Text Input** | 20  (0 – Max) | M | Max  (Refer to section Common Attribute) | The text input will be read-only or editable, with the default parameter defined by system preferences of user maintenance in the trading admin GUI. |
| Traded Sold | Numeric  **Read-only or**  **Editable**  **Text Input** | 20  (0 – Max) | M | Max  (Refer to section Common Attribute) | The text input will be read-only or editable, with the default parameter defined by system preferences of user maintenance in the trading admin GUI. |
| Traded Net | Numeric  **Read-only or**  **Editable**  **Text Input** | 20  (0 – Max) | M | Max  (Refer to section Common Attribute) | The text input will be read-only or editable, with the default parameter defined by system preferences of user maintenance in the trading admin GUI. |
| **Total** | | | | | |
| Total Buy | Numeric  **Read-only or**  **Editable**  **Text Input** | 20  (0 – Max) | M | Max  (Refer to section Common Attribute) | The text input will be read-only or editable, with the default parameter defined by system preferences of user maintenance in the trading admin GUI. |
| Total Sell | Numeric  **Read-only or**  **Editable**  **Text Input** | 20  (0 – Max) | M | Max  (Refer to section Common Attribute) | The text input will be read-only or editable, with the default parameter defined by system preferences of user maintenance in the trading admin GUI. |
| Total Net Buy | Numeric  **Read-only or**  **Editable**  **Text Input** | 20  (0 – Max) | M | Max  (Refer to section Common Attribute) | The text input will be read-only or editable, with the default parameter defined by system preferences of user maintenance in the trading admin GUI. |
| Total Net Sell | Numeric  **Read-only or**  **Editable**  **Text Input** | 20  (0 – Max) | M | Max  (Refer to section Common Attribute) | The text input will be read-only or editable, with the default parameter defined by system preferences of user maintenance in the trading admin GUI. |
| **Block Trade** | | | | | |
| Block Trade Bought | Numeric  **Read-only or**  **Editable**  **Text Input** | 20  (0 – Max) | M | Max  (Refer to section Common Attribute) | The text input will be read-only or editable, with the default parameter defined by system preferences of user maintenance in the trading admin GUI. |
| Block Trade Sold | Numeric  **Read-only or**  **Editable**  **Text Input** | 20  (0 – Max) | M | Max  (Refer to section Common Attribute) | The text input will be read-only or editable, with the default parameter defined by system preferences of user maintenance in the trading admin GUI. |

##### Actions (Ref: [Common Actions](#_Common_Actions))

#FS10014b\_S0040\_03570

| Action | Description |
| --- | --- |
| Confirm | The button is disabled by default and will be enabled once record card status selected, it is used to save and persist the changes in backend |
| Cancel | It is used to close the current window, the unsaved changes will be discarded if record card status selected |

##### Validation (Ref: [Common Validation](#_Common_Validation))

| Event | Notification |
| --- | --- |
| Confirm | All mandatory fields cannot be empty |

### Maintain Risk Group User

#FS10014b\_S0040\_03600

#### Description

This function is applicable to both External and Internal.

1. External

This window allows users to manage the risk group user by selecting specific risk groups in PTRM.

1. Internal

This window allows users to manage the risk group user by selecting specific risk groups in PTRM on behalf of clients if required. These actions require second-user approval.

#### Scope of the data

The table of Maintain Risk Group User search page and detail page can display up to 60,000 and 1000 records. (TBC)

The records displayed in this window is different between External and Internal:

1. External

This window is used to manage the risk group user of a user’s own risk groups within the company.

1. Internal

This window is used to display the risk group user of all participants’ risk groups currently existing in PTRM. Any update action requires second-user approval.

#### Permission Behaviour (Ref: [Common Permission Behaviour](#_Common_Permission_Behaviour))

#### Notification (Ref: [Common Notification](#_Common_Notification))

#### Search Page

#FS10014b\_S0040\_03700

##### Accessing the Function

The “Maintain Risk Group User” window can be opened through the Maintain Menu.

Only internal users and sponsoring participants are permitted to use this function. Internal users can access all data, while sponsoring participants are limited to accessing their own data.

##### Filtering Criteria

Following filter field is available for criteria search.

| **Filtering Criteria** | **Type** |
| --- | --- |
| User List ID | Text Input (with Content Assist) |

##### UI Layout

![](data:image/png;base64...)

##### Attributes

#FS10014b\_S0040\_03800

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| **Identity** | | | | | |
| User List ID | Numeric  **Table Cell** | 5 | M | - | Refer to Maintain Risk Group detail page Attributes |
| Name | Alphanumeric  **Table Cell** | 50 | M | - | - |
| Description | Alphanumeric  **Table Cell** | 40 | O | - | - |

##### Actions (Ref: [Common Actions](#_Common_Actions))

#FS10014b\_S0040\_03900

| Action | Description |
| --- | --- |
| Maintain Risk Group User Detail | Double click the risk group user row to open “Maintain Risk Group User Detail” dialog window |

##### Validation (Ref: [Common Validation](#_Common_Validation))

#### Detail Page

#FS10014b\_S0040\_04000

Record Status (Ref: [Current Record and Request Record](#_Current_Record_and))

##### Accessing the Function

The “Maintain Risk Group User Detail” window can be opened by double-clicking the specific risk groups in the “Maintain Risk Group User” section.

Only internal users and sponsoring participants are permitted to use this function. Internal users can access all data, while sponsoring participants are limited to accessing their own data.

##### Filtering Criteria

N/A

##### UI Layout

![](data:image/png;base64...)

Record Card Actions

![](data:image/png;base64...)

##### Attributes

#FS10014b\_S0040\_04100

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| **Identity** | | | | | |
| User List ID | Numeric  **Text Input** | 5 | M | - | Refer to Maintain Risk Group detail page Attributes |
| Name | Alphanumeric  **Text Input** | 50 | M | - | - |
| Description | Alphanumeric  **Editable**  **Text Input** | 40 | O | - | - |
| **User List** | | | | | |
| Comp ID | Alphanumeric  **Editable is Only applicable for new row**  **Table Cell**  **Content Assist** | 10 | M | - | User under the sponsored participant of the risk group  For base risk group, all orphan comp ID (including not yet effective) will be listed, and unassigned comp ID under sponsored participants will be counted in base group calculation  For non-base risk group, only orphan comp ID can be selected  A risk group user is only allowed to add in one risk group |

##### Actions (Ref: [Common Actions](#_Common_Actions))

#FS10014b\_S0040\_04200

| Action | Description |
| --- | --- |
| Update for tomorrow | This action is used to update record and effective for tomorrow, second-user approval is required for internal users |
| Add | The button is only visible for non base group risk group, it is used to add user into direct order flow sessions/trading GUI users |
| Delete | The button is only visible for non base group risk group, it is used to delete user from direct order flow sessions/trading GUI users |
| Confirm | The button is disabled by default and will be enabled once record card status selected, it is used to save and persist the changes in backend |
| Cancel | It is used to close the current window, the unsaved changes will be discarded if record card status selected |

##### Validation (Ref: [Common Validation](#_Common_Validation))

| Event | Notification |
| --- | --- |
| Confirm | All mandatory fields cannot be empty |
| Add | The Maximum number of rows is 500 (TBC) |

### Maintain Risk Group Notification

#FS10014b\_S0040\_04300

#### Description

This function is applicable to both External and Internal.

1. External

This window allows users to manage the risk group notification by selecting specific risk groups in PTRM.

1. Internal

This window allows users to manage the risk group notification by selecting specific risk groups in PTRM on behalf of clients if required. These actions require second-user approval.

#### Scope of the data

The table of Maintain Risk Group Notification search page and detail page can display up to 60,000 and 20 records. (TBC)

The records displayed in this window is different between External and Internal:

1. External

This window is used to manage the risk group notification of the company’s own risk groups within the company, including notice, warning and breach enablement and email list maintenance.

1. Internal

This window is used to display the risk group notification of all participants’ risk groups currently existing in PTRM. Any update action requires second-user approval.

#### Permission Behaviour (Ref: [Common Permission Behaviour](#_Common_Permission_Behaviour))

#### Notification (Ref: [Common Notification](#_Common_Notification))

#### Search Page

#FS10014b\_S0040\_04400

##### Accessing the Function

The “Maintain Risk Group Notification” window can be opened through the Maintain Menu.

Only internal users and sponsoring participants are permitted to use this function. Internal users can access all data, while sponsoring participants are limited to accessing their own data.

##### Filtering Criteria

Following filter field is available for criteria search.

| **Filtering Criteria** | **Type** |
| --- | --- |
| Notification ID | Text Input (with Content Assist) |

##### UI Layout

![](data:image/png;base64...)

##### Attributes

#FS10014b\_S0040\_04500

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| **Identity** | | | | | |
| Notification ID | Numeric  **Table Cell** | 5 | M | - | Refer to Maintain Risk Group detail page Attributes |
| Name | Alphanumeric  **Table Cell** | 50 | M | - | - |
| Description | Alphanumeric  **Table Cell** | 40 | O | - | - |

##### Actions (Ref: [Common Actions](#_Common_Actions))

#FS10014b\_S0040\_04600

| Action | Description |
| --- | --- |
| Maintain Risk Group Notification Detail | Double click the risk group notification row to open “Maintain Risk Group Notification Detail” dialog window |

##### Validation (Ref: [Common Validation](#_Common_Validation))

#### Detail Page

#FS10014b\_S0040\_04700

Record Status (Ref: [Current Record and Request Record](#_Current_Record_and))

##### Accessing the Function

The “Maintain Risk Group Notification Detail” window can be opened by double-clicking the specific risk groups in the “Maintain Risk Group Notification” section.

Only internal users and sponsoring participants are permitted to use this function. Internal users can access all data, while sponsoring participants are limited to accessing their own data.

##### Filtering Criteria

N/A

##### UI Layout

Update for tomorrow

![](data:image/png;base64...)

Update for as soon as possible

![](data:image/png;base64...)

Record Card Actions

![](data:image/png;base64...)

##### Attributes

#FS10014b\_S0040\_04800

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| **Identity** | | | | | |
| Notification ID | Numeric  **Text Input** | 5 | M | - | Refer to Maintain Risk Group detail page Attributes |
| Name | Alphanumeric  **Text Input** | 50 | M | - | - |
| Description | Alphanumeric  **Editable**  **Text Input** | 40 | O | - | - |
| **Email** | | | | | |
| Email | Alphanumeric  **Editable is Only applicable for new row**  **Table Cell**  **Text Input** | 254 | M | - | A valid email address format (local-part@domain)  local-part allow a-z, A-Z, 0-9, full stop (.), underscore (\_) and hyphen (-).  domain allow a-z, A-Z, 0-9, full stop (.), hyphen (-). Hyphen is allowed if it is not the first or last character. |

##### Actions (Ref: [Common Actions](#_Common_Actions))

#FS10014b\_S0040\_04900

| Action | Description |
| --- | --- |
| Update for tomorrow | This action is used to update record (delete email) and effective for tomorrow, second-user approval is required for internal users |
| Update for as soon as possible | This action is used to update record (add email) and effective for as soon as possible, second-user approval is required for internal users |
| Add | This button is used to add email into notification |
| Delete | This button is used to delete email from position notification |
| Confirm | The button is disabled by default and will be enabled once record card status selected, it is used to save and persist the changes in backend |
| Cancel | It is used to close the current window, the unsaved changes will be discarded if record card status selected |

##### Validation (Ref: [Common Validation](#_Common_Validation))

| Event | Notification |
| --- | --- |
| Confirm | All mandatory fields cannot be empty |
| Add | The Maximum number of rows is 10 (TBC) |

## Control and Monitoring Functions

#FS10014b\_S0040\_05000

### Control Risk Group

#FS10014b\_S0040\_05101

#### Description

This function is applicable to both External and Internal.

1. External

This window allows users to control and monitor the risk group record in PTRM including risk group and position limit, and performing emergency actions, such as stop button, mass order cancellation, unstop button, unblock order rate, intraday exposure, execution throttle and position limit.

1. Internal

This window allows users to control and monitor the risk group record in PTRM, and perform emergency actions on behalf of clients if required. These actions require second-user approval.

#### Scope of the data

The table of Control Risk Group and Position Limits Panel can display up to 60,000 and 2,000 records respectively. (TBC)

The records displayed in this window is different between External and Internal:

1. External

This window is used to control and monitor the risk group record of own risk groups within the company.

1. Internal

This window is used to control and monitor the risk group record of all participants’ risk groups currently existing in PTRM. second-user approval is required.

In addition, both internal/external users can view the number of users, alert summaries, and order rates for the expanded risk group in real-time, on a best-effort basis. Any breached, warning, or notice risk group record will be highlighted in red, orange, or yellow color with corresponding sound alert respectively.

#### Permission Behaviour (Ref: [Common Permission Behaviour](#_Common_Permission_Behaviour))

#### Notification (Ref: [Common Notification](#_Common_Notification))

#### Control Risk Group Page

#FS10014b\_S0040\_05200

##### Accessing the Function

The “Control Risk Group” window can be opened through the Control and Monitoring Menu.

Internal users, sponsoring participants and sponsored participants are permitted to use this function. Internal users can access all data, sponsoring participants are limited to accessing their own data, while sponsored participants are only allowed to view their own data and conduct stop risk group, mass order cancellation and kill switch.

##### Filtering Criteria

Following filter field is available for criteria search.

| **Filtering Criteria** | **Type** |
| --- | --- |
| Sponsoring /Sponsored /Risk Group | Text Input (with Content Assist) |

##### UI Layout

![](data:image/png;base64...)

More Actions

![](data:image/png;base64...)

##### Attributes

#FS10014b\_S0040\_05300

| Column | Type | Length | M/O | Default | Remarks |
| --- | --- | --- | --- | --- | --- |
| **Control Risk Group - Identity** | | | | | |
| Sponsoring Participant | Alphanumeric  **Table Cell** | 5 | M | - | Participants can be categorized as sponsoring participants |
| Sponsored Participant | Alphanumeric  **Table Cell** | 5 | M | - | Participants can be categorized as sponsored participants |
| Risk Group ID | Alphanumeric  **Table Cell** | 32 | M | - | A unique ID representing the risk group, it can be categorized as base risk group, and non-base risk group |
| **Control Risk Group -Alert Summary** | | | | | |
| Breaches | Numeric  **Real-time**  **Table Cell** | - | M | - | A real time figure calculated by PTRM |
| Warnings | Numeric  **Real-time**  **Table Cell** | - | M | - | A real time figure calculated by PTRM |
| Notices | Numeric  **Real-time**  **Table Cell** | - | M | - | A real time figure calculated by PTRM |
| **Control Risk Group - Order Rate** | | | | | |
| Period | Numeric  **Real-time**  **Table Cell** | 3  (1 – 300) | M | 300 | A period to determine number of orders entered by the Sponsored Users |
| Limit | Numeric  **Real-time**  **Table Cell** | 20  (0 – Max) | M | 0 | Allowed number of orders within the order rate period  A zero value would lead to immediate blocking of the risk group |
| Rate | Numeric  **Real-time**  **Table Cell** | - | M | - | A real time figure calculated by PTRM |
| **Risk Limits Panel - Intraday Exposure Check** | | | | | |
| Intraday Exposure | Alphanumeric  **Real-time**  **Table Cell** | N/A | M | - | Label of Net Futures/Gross Futures/Net Options/Gross Options |
| Risk Limit (HKD Eqv) | Numeric  **Real-time**  **Table Cell** | 20  (0 – Max) | M | 0 | Allowed Risk Exposure consumed by the sponsored user within the risk group |
| Long Exposure | Numeric  **Real-time**  **Table Cell** | 20 | M | 0 |  |
| Utilization % | Numeric  **Real-time**  **Table Cell** | - | M | 0 |  |
| Short Exposure | Numeric  **Real-time**  **Table Cell** | 20 | M | 0 |  |
| Utilization % | Numeric  **Real-time Table Cell** | - | M | 0 |  |
| **Risk Limits Panel - Execution Throttle Check** | | | | | |
| Execution Throttle | Alphanumeric  **Real-time**  **Table Cell** | N/A | M | - | Label of Gross Futures Per Time/Net Futures Per Time |
| Risk Limit (HKD Eqv) | Numeric  **Real-time**  **Table Cell** | 20  (0 – Max) | M | 0 | Allowed Execution Exposure consumed in a defined period by the sponsored users within the risk group |
| Long Exposure | Numeric  **Real-time**  **Table Cell** | 20 | M | 0 |  |
| Utilization % | Numeric  **Real-time**  **Table Cell** | - | M | 0 |  |
| Short Exposure | Numeric  **Real-time**  **Table Cell** | 20 | M | 0 |  |
| Utilization % | Numeric  **Real-time**  **Table Cell** | - | M | 0 |  |
| **Risk Limits Panel – Order Exposure Reference** | | | | | |
| Intraday Exposure | Alphanumeric  **Real-time**  **Table Cell** | N/A | M | - | Label of Gross Futures/Gross Options |
| Long Exposure | Numeric  **Real-time**  **Table Cell** | 20  (0 – Max) | M | 0 |  |
| Short Exposure | Numeric  **Real-time**  **Table Cell** | 20  (0 – Max) | M | 0 |  |
| **Position Limits Panel – Position Limits** | | | | | |
| Tradable | Alphanumeric  **Real-time**  **Table Cell** | 32 | M | - |  |
| Breached | Boolean  **Read-only** | 1 | M | N | It is a hidden field and will be enabled when the tradable row is breached. The row data will be highlighted in red when the breach flag is enabled |
| **Position Limits Panel – Open** | | | | | |
| Open Buy | Numeric  **Real-time**  **Table Cell** | 20  (0 – Max) | M | 0 |  |
| Open Sell | Numeric  **Real-time**  **Table Cell** | 20  (0 – Max) | M | 0 |  |
| **Position Limits Panel – Traded** | | | | | |
| Traded Bought | Numeric  **Real-time**  **Table Cell** | 20  (0 – Max) | M | 0 |  |
| Traded Sold | Numeric  **Real-time**  **Table Cell** | 20  (0 – Max) | M | 0 |  |
| Traded Net | Numeric  **Real-time**  **Table Cell** | 20  (0 – Max) | M | 0 |  |
| **Position Limits Panel – Total** | | | | | |
| Total Buy | Numeric  **Real-time**  **Table Cell** | 20  (0 – Max) | M | 0 |  |
| Total Sell | Numeric  **Real-time**  **Table Cell** | 20  (0 – Max) | M | 0 |  |
| Total Net Buy | Numeric  **Real-time**  **Table Cell** | 20  (0 – Max) | M | 0 |  |
| Total Net Sell | Numeric  **Real-time**  **Table Cell** | 20  (0 – Max) | M | 0 |  |
| **Position Limits Panel – Block Trade** | | | | | |
| Block Trade Bought | Numeric  **Real-time**  **Table Cell** | 20  (0 – Max) | M | 0 |  |
| Block Trade Sold | Numeric  **Real-time**  **Table Cell** | 20  (0 – Max) | M | 0 |  |

##### Actions (Ref: [Common Actions](#_Common_Actions))

#FS10014b\_S0040\_05400

| Action | Description |
| --- | --- |
| Stop Risk Group | The button is disabled by default and will be enabled once a sponsoring participant, sponsored participant or risk group row is selected. |
| Mass Order Cancellation | The button is disabled by default and will be enabled once a sponsoring participant, sponsored participant or risk group row is selected. |
| Kill Switch | The button is disabled by default and will be enabled once a sponsoring participant, sponsored participant or risk group row is selected. |
| Unstop Risk Group | The button is disabled by default and will be enabled if the unstop criteria is fulfilled.  Refer to FS10005 PTRM FS corresponding risk check unstop specification. |
| Unblock Order Rate | The button is disabled by default and will be enabled if the unblock criteria is fulfilled.  Refer to FS10005 PTRM FS corresponding risk check unblock specification. |
| Unblock Intraday Exposure | The button is disabled by default and will be enabled if the unblock criteria is fulfilled.  Refer to FS10005 PTRM FS corresponding risk check unblock specification. |
| Unblock Execution Throttle | The button is disabled by default and will be enabled if the unblock criteria is fulfilled.  Refer to FS10005 PTRM FS corresponding risk check unblock specification. |
| Unblock Position Limit | The button is disabled by default and will be enabled if the unblock criteria is fulfilled.  Refer to FS10005 PTRM FS corresponding risk check unblock specification. |

##### Validation (Ref: [Common Validation](#_Common_Validation))

| Event | Notification |
| --- | --- |
| Confirm | All mandatory fields cannot be empty |

# Appendix

* PTRM Validation Logics ![](data:image/x-emf;base64...)
