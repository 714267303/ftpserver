TITLE:

**FUNCTIONAL SPECIFICATION**

***ODP-T

FS10016 – System Monitoring and Alerts***

AUTHOR : *IT/Markets Systems*  DATE : *27 May 2025*

LAST REVIEW Derivatives Trading Business Operations DATE : *28 Feb 2025*

**CONTENTS**

[1. Document Control 4](#_Toc193730548)

[1.1. Change History 4](#_Toc193730549)

[1.2. Document Cross-referenced 4](#_Toc193730550)

[1.3. Abbreviation 4](#_Toc193730551)

[2. Introduction 6](#_Toc193730552)

[2.1. Introduction to SPDB 6](#_Toc193730553)

[2.2. Scope 6](#_Toc193730554)

[2.3. Primary Users 7](#_Toc193730555)

[2.4. Retention & Restoration 7](#_Toc193730556)

[3. Order & Trade Activities Statistics 8](#_Toc193730557)

[3.1. Matching Engine Based 8](#_Toc193730558)

[3.2. Market Based 8](#_Toc193730559)

[3.3. Participant Based 9](#_Toc193730560)

[3.4. Trade Statistics – Instrument Based 9](#_Toc193730561)

[3.5. Trade Statistics – Participant Based 10](#_Toc193730562)

[4. Order Flow Gateway Statistics 11](#_Toc193730563)

[4.1. Order Flow Gateway Latency 11](#_Toc193730564)

[4.2. Gateway Statistics 11](#_Toc193730565)

[4.3. Order Flow Gateway Logon Information 13](#_Toc193730566)

[4.4. Order Book Investigation 13](#_Toc193730567)

[5. Trade Session Information 14](#_Toc193730568)

[5.1. Trade Session Configuration 14](#_Toc193730569)

[5.2. Trade Session Events 14](#_Toc193730570)

[6. Technical Operations Monitoring and Alerts 15](#_Toc193730571)

[6.1. Server Statistics Monitoring & Alerts 15](#_Toc193730572)

[6.2. Hardware Events Alerts for Attention 15](#_Toc193730573)

[6.3. Application Control Manager 15](#_Toc193730574)

[7. Business Alerts Function 16](#_Toc193730575)

[7.1. SPDB Alerts 16](#_Toc193730576)

[7.2. Price Limit Alerts 16](#_Toc193730577)

[8. Use of ECW for System Monitoring 17](#_Toc193730578)

[8.1. External Circuit Watch System 17](#_Toc193730579)

[8.2. Configuration Setup by Business Operations 17](#_Toc193730580)

[8.3. System Monitoring Usage 17](#_Toc193730581)

[8.4. ECW Startup and Shutdown 18](#_Toc193730582)

[9. Appendix – Non Day 1 19](#_Toc193730584)

# Document Control

## Change History

|  |  |  |  |
| --- | --- | --- | --- |
| Version  Number | Issue Date | Author | Abstract |
| 0.1 | 22 Nov 2024 | IT/Markets Systems | Initial Version |
| 0.2 | 27 Dec 2024 | IT/Markets Systems | Revised according to FS10016 Review Log comments. |
| 0.3 | 23 Jan 2025 | IT/Markets Systems | Revised according to Traceability Mapping discussion agreements. |
| 1.0 | 24 Mar 2025 | IT/Markets Systems | Cover Page (System Name, Document ID, Last Modified/Reviewed Date), Version Number and Document Cross-Referenced table update. |
| 1.1 | 27 May 2026 | IT/Markets Systems | Added reference to MRT |

## Document Cross-referenced

|  |  |  |
| --- | --- | --- |
| # | Document | Version |
|  | BRD\_DT\_0012 ODP - Cross-check system timer.docx | 20241017 |
|  | BRD\_DT\_0014 ODP - NewFunctionRequest Connectivity Monitoring.docx | Revision 2 (2024-04-26) |
|  | BRD\_DT\_0029 NEWS WISH Monitoring & Analytics for system health.docx | 20241017 |
|  | BRD\_DT\_0030 NEW WISH 010 System Health Diagnostics.docx | 20241017 |
|  | BRD\_DT\_0047 ODP - NewFunctionRequest - System Monitoring & Alerts.docx | Revision 2 (2024-04-26) |

## Abbreviation

|  |  |
| --- | --- |
| MAD | Market Activity Dashboard |
| ODP-T | Orion Derivatives Platform - Trading |
| OTP-D | Orion Trading Platform for Derivatives |
| SPDB | System Performance Dashboard |
| UAT | User Acceptance Test |
| ITD | Information Technology Division |
| SIEM | Security Information Event Management |
| ESO | Enterprise System Operations |
| ECW | External Circuit Watch |
| MRT | Message Recovery Manager using TCP/Unicast |
| Collector | A component of SPDB to consume messages from MRT |

# Introduction

This document covers the information and data provided by ODP-T to facilitate the system monitoring and alerts. The actual display of the information and alert mechanism is not in the scope of this specification.

## Introduction to SPDB

#FS10016\_S0020\_00100

As further describes in upcoming sections, one major part of the monitoring is in System Performance Dashboard (SPDB). Also known as Market Activity Dashboard (MAD) in Derivatives Operations. In this document, the term SPDB is used. In SPDB, screens can be defined and data can be exported into CSV. SPDB is considered as a supporting system component outside ODP-T.

## Scope

#FS10016\_S0020\_00200

This document only describes what ODP-T data is produced in this raw form to support monitoring by SPDB. After SPDB collects the data, there are further configurations to setup the display and alerts. The statistical data described in this document shall allow foreseeable analysis be performed based on these data without further changing ODP-T since SPDB configurations provide flexibility in setting up display as well as simple mathematical analysis.

#FS10016\_S0020\_00300

Setting up SPDB is not considered as changes in ODP as it is not a component in the core trading path. In such cases, User Acceptance Tests are still required on SPDB but not necessary on ODP-T if there is no corresponding changes in ODP-T. On the other hand, shall there be need to change the ODP components for future statistics or monitoring, IT would limit the scope change as much as possible to reduce the possible risks to ODP.

#FS10016\_S0020\_00400

However, it cannot be guaranteed those changes would not impact the core business flow as it is not known what future changes would be raised. UAT is inevitable in such cases and IT would provide impact analysis for Business to plan for the UAT.

For Business operations, the front end and analysis part are covered in SPDB, the changes in SPDB is not in scope of this document.

#FS10016\_S0020\_00500

SPDB data retention period would be maintained before and after ODP-T is launched.

#FS10016\_S0020\_00600

For Technical Operation, the display and analysis tools are based on the IT standard which is used at the time of the production environment. Those tools are outside the scope of this document.

#FS10016\_S0020\_00700

Businesses use the following tools for monitoring. Below describes functions that would be implemented in the ODP Tools:

Market Activity Dashboard (MAD) – in fact this is SPDB. The changes to the configuration & development of the interfaces to SPDB are covered as part of the scope of ODP

Market Place Assistant (MPA) & Product Design (PD) – these tools are third party products and therefore they are not available in ODP. Equivalent functions are available in Internal Admin GUI, please refer to the Admin GUI Functional Specification.

Decterm – this tool is not available in ODP. The corresponding functions are splitted into Internal Admin GUI & SPDB.

SMARTS – the functions in SMARTS is provided as is. ODP does not cover the functional changes in SMARTS.

## Primary Users

The primary users of the monitoring and alerts mentioned in this document is Business Operations unless otherwise stated.

## Retention & Restoration

#FS10016\_S0020\_00800

The statistical data in SPDB would keep online for 14 calendar days. The data would then be archived. The restoration of the archived data would follow the general defined IT administration and approval flow at the time of the restoration.

# Order & Trade Activities Statistics

#FS10016\_S0030\_00100

Below are the data provided to SPDB sourcing from Message Recovery Manager (MRT) :

## Matching Engine Based

#FS10016\_S0030\_00201

|  |  |  |  |
| --- | --- | --- | --- |
| **Field** | **Data Type** | **Description** | **Data Source (MRT)** |
| Time | Timestamp | Timestamp that the metric is captured |  |
| **Key** | | |  |
| Partition | String | Matching engine partition ID | Tag by Collector |
| Instance | String | Identifier of an application instance  0 - Active in primary data center  1 - Standby in primary data center | Set to 1 after receiving “I am active” message from MRT |
| **Data** | | |  |
| numOrders | Integer | Total number of created by ME  Each side of quote is considered as one order. | Counting of “Order Added” and “Order Reloaded” (GTC) |
| numOpenOrders | Integer | Current number of open order in order books | numOrders, less “cancelled orders”, “Order Restated” and fully filled orders. |
| numReject | Integer | Total number of reject on order, quotes and BlkTrd by ME validation.  Please note that rejection by gateway is not included here | Sum of rejected transactions: Order Rejected, Order Amend Rejected, Order Cancel Rejected, Quote Rejected, and Block Trade (Rejected). |
| numTrade | Integer | Total number of trade, include BlkTrd | Sum all Explicit Trade, plus the Block Trade – matched, and on-behalf trade  Note: 2-side trade count as 1 |
| numTradeCancel | Integer | Total number of trade cancelled | Sum of “Trade Cancelled” |
| numProc | Integer | Total number of message processed~~, excludes the rejected message~~  Please note that rejection by gateway is not included here | Sum of “messages processed” |
| numOBC | Integer | Total number of OBC | Sum of transactions: numOrders, Order Cancelled, Order Amended, Order Restated, Aggregated Implied Volume, Explicit Trade, plus the Block Trade – matched, and on-behalf trade |

## Market Based

#FS10016\_S0030\_00301

|  |  |  |  |
| --- | --- | --- | --- |
| **Field** | **Data Type** | **Description** | **Data Source (MRT)** |
| Time | Timestamp | Timestamp that the metric is captured |  |
| **Key** | | |  |
| Partition | String | Matching engine partition ID | Tag by Collector |
| Market Code | String | Market Code | Extract from field “Order Data Block 1” |
| **Data** | | |  |
| numOrders | Integer | Total number of created by ME  Each side of quote is considered as one order. | Counting of “Order Added” and “Order Reloaded” (GTC) and “Order Restated” messages |
| numOpenOrders | Integer | Current number of open order in order books | numOrders, less “cancelled orders”, “Order Restated” and fully filled orders. |
| numReject | Integer | Total number of reject on order, quotes and BlkTrd by ME validation.  Please note that rejection by gateway is not included here | Sum of rejected transactions: Order Rejected, Order Amend Rejected, Order Cancel Rejected, Quote Rejected, and Block Trade (Rejected). |
| numTrade | Integer | Total number of trade, include BlkTrd | Sum all Explicit Trade, plus the Block Trade – matched, and on-behalf trade  Note: 2-side trade count as 1 |
| numTradeCancel | Integer | Total number of trade cancelled | Sum of “Trade Cancelled” |
| numProc | Integer | Total number of message processed  Please note that rejection by gateway is not included here | Sum of messages processed |
| numOBC | Integer | Total number of OBC | Sum of transactions: numOrders, Order Cancelled, Order Amended, Order Restated, Aggregated Implied Volume |

## Participant Based

#FS10016\_S0030\_00401

|  |  |  |  |
| --- | --- | --- | --- |
| **Field** | **Data Type** | **Description** | **Data Source (MRT)** |
| Time | Timestamp | Timestamp that the metric is captured |  |
| **Key** | | |  |
| Partition | String | Matching engine partition ID | Tag by Collector |
| Exchange Participant ID | String | Identifier of participant | Extract and map from field “Comp ID Ref” |
| **Data** | | |  |
| numOrders | Integer | Total number of created by ME  Each side of quote is considered as one order. | Counting of “Order Added” and “Order Reloaded” (GTC) and “Order Restated” messages |
| numOpenOrders | Integer | Current number of open order in order books | numOrders, less “cancelled orders”, “Order Restated” and fully filled orders. |
| numReject | Integer | Total number of reject on order, quotes and BlkTrd by ME validation.  Please note that rejection by gateway is not included here | Sum of rejected transactions: Order Rejected, Order Amend Rejected, Order Cancel Rejected, Quote Rejected, and Block Trade (Rejected). |
| numTrade | Integer | Total number of trade, include BlkTrd | Sum all Explicit Trade, plus the Block Trade – matched, and on-behalf trade  Note: 2-side trade count as 1 |
| numTradeCancel | Integer | Total number of trade cancelled | Sum of “Trade Cancelled” |
| numProc | Integer | Total number of message processed  Please note that rejection by gateway is not included here | Sum of messages processed |
| numOBC | Integer | Total number of OBC | Sum of transactions: numOrders, Order Cancelled, Order Amended, Order Restated, Aggregated Implied Volume |

## Trade Statistics – Instrument Based

#FS10016\_S0030\_00501

|  |  |  |  |
| --- | --- | --- | --- |
| **Field** | **Data Type** | **Description** | **Data Source (MRT)** |
| Time | Timestamp | Timestamp that the metric is captured |  |
| **Key** | | |  |
| Instrument ID | String | Instrument ID | Extract and map from field “Security ID Ref” |
| **Data** | | |  |
| Traded Volume | Double | Aggregate Trade Volume | Extract from TSTAT “Tradeable Instrument Open/High/Low” |

## Trade Statistics – Participant Based

#FS10016\_S0030\_00601

|  |  |  |  |
| --- | --- | --- | --- |
| **Field** | **Data Type** | **Description** | **Data Source (MRT)** |
| Time | Timestamp | Timestamp that the metric is captured |  |
| **Key** | | |  |
| Exchange Participant ID | String | Identifier of participant | Extract and map from field “Comp ID Ref” |
| **Data** | | |  |
| Traded Volume | Double | Aggregate Trade Volume | **[N/A]** |

# Order Flow Gateway Statistics

Below are the data provided to SPDB:

## Order Flow Gateway Latency

#FS10016\_S0040\_00100

Order Flow Gateway Latency stores the average and max order response time from the exchange per gateway partition. The average and max latency are calculated by the order flow gateway using data in past 1 second.

|  |  |  |
| --- | --- | --- |
| **Field** | **Data Type** | **Description** |
| Time | Timestamp | Timestamp that the metric is captured in gateway |
| **Key** | | |
| Partition | String | Gateway partition ID (1-9) |
| Instance | String | Identifier of an application instance (0-4)  0 - Active in primary data center  1 & 2 - Standby in primary data center  3 & 4 - Standby in DR data center (if available) |
| Protocol | String | B – Binary |
| **Data** | | |
| avgForwardLatency | Integer | Instant gateway internal average forward latency for protocol sessions. |
| avgBackwardLatency | Integer | Instant gateway internal average backward latency for protocol sessions. |
| internalPeakLatency | Integer | Instant Internal Peak latency for protocol sessions. |
| turnaroundLatency | Integer | Instant Average Turnaround latency for protocol sessions. |
| turnaroundPeakLatency | Integer | Instant Turnaround Peak latency for protocol sessions. |

## Gateway Statistics

#FS10016\_S0040\_00200

Gateway statistics includes the aggregated connection and message statistics per gateway partition.

|  |  |  |
| --- | --- | --- |
| **Field** | **Data Type** | **Description** |
| Time | Timestamp | Timestamp that the metric is captured in gateway |
| **Key** | | |
| Partition | String | Gateway partition ID (1-9) |
| Instance | String | Identifier of an application instance (0-4)  0 - Active in primary data center  1 & 2 - Standby in primary data center  3 & 4 - Standby in DR data center |
| **Data** | | |
| totalClients | Integer | Total number of clients |
| loggedOnClients | Integer | Total number of logged-on clients |
| disconnectedClients | Integer | Total number of disconnected clients |
| notConnectedClients | Integer | Total number of not connected clients |
| clientCurrentInputRate | Integer | Current input message rate from client |
| clientCurrentOutputRate | Integer | Current output message rate from client |
| clientTotalInput | Integer | Total number of input messages from client |
| clientTotalOutput | Integer | Total number of output messages from client |
| clientNew | Integer | Total number of New Orders from client |
| clientAmend | Integer | Total number of Amend Orders from client |
| clientCancel | Integer | Total number of Cancel Requests from client |
| clientMassQuote | Integer | Total number of Mass Quote from client |
| clientSingleQuote | Integer | Total number of Single Quote from client |
| clientMassCancel | Integer | Total number of Mass Cancel Orders from client. |
| clientOboMassCancel | Integer | Total number of Obo Mass Cancel Orders from client. |
| clientBlockTrade | Integer | Total number of Block Trade from client |
| BMR | Integer | Total number of business messages rejected to client |
| BMR (Throttle) | Integer | Total number of business messages rejected due to throttle to client by GW |
| mktTrade | Integer | Total number of BL/Quote Trade from ODP-T |
| mktOrderRejected | Integer | Total number of Order Rejected from ODP-T |
| mktOrderCancelRejected | Integer | Total number of Order Cancel Rejected from ODP-T |
| mktOrderAmendRejected | Integer | Total number of Order Amend Rejected from ODP-T. |
| mktOrderAccepted | Integer | Total number of order/quote accepted from ME |
| mktOrderCancelled | Integer | Total number of order/quote cancelled from ME  (Including all cancel methods, i.e. by cancel request, mass cancel, etc.) |
| mktOrderAmended | Integer | Total number of order/quote amended from ME. |

## Order Flow Gateway Logon Information

#FS10016\_S0040\_00300

Please refer to Internal Admin GUI Function Specification.

## Order Book Investigation

#FS10016\_S0040\_00400

Please refer to Internal Admin GUI Function Specification.

# Trade Session Information

Before the start of a Market, the following information containing the setup of the Trading Schedule are available to SPDB.

## Trade Session Configuration

#FS10016\_S0050\_00101

|  |  |  |  |
| --- | --- | --- | --- |
| **Field** | **Data Type** | **Description** | **Data Source  (Load from SOD RefData)** |
| Trading Date | Timestamp | Date of the Trade Session |  |
| **Key** | | |  |
| Market Code | String | Market Code | **(Load from SOD RefData)** |
| **Data** | | |  |
| Trading Schedule ID | Integer |  | **(Load from SOD RefData)** |
| Trading Session ID | Integer |  | **(Load from SOD RefData)** |
| Trading State ID | Integer |  | **(Load from SOD RefData)** |
| Trading State Type | Integer | Business Trading State | **(Load from SOD RefData)** |
| Start Time | Timestamp | Trading State Start Time | **(Load from SOD RefData)** |
| End Time | Timestamp | Trading State End Time | [N/A] |

## Trade Session Events

#FS10016\_S0050\_00201

Below are the trade session event sent when triggered during a trading day –

|  |  |  |  |
| --- | --- | --- | --- |
| **Field** | **Data Type** | **Description** | **Data Source (MRT) -  Trading State Change Alert (MT=809)** |
| Trading Date | Timestamp | Date of the Trade Session |  |
| Event Time | Timestamp |  |  |
| **Key** | | |  |
| Market Code | String | Market Code | Extract and map from field “Product Hierarchy” |
| **Data** | | |  |
| Trading Session ID | Integer |  | Extract from field “Trading Session ID” |
| Trading State ID | Integer |  | Extract from field “Trading State ID” |
| Trading State Type | Integer | Business Trading State | Extract from field “Trading State Type” |
| Start Time | Timestamp | Trading State Start Time | Extract from field “Actual Start Time” |
| End Time | Timestamp | Trading State End Time | Extract from field “End Time” |

#FS10016\_S0050\_00300

In SPDB, a table can be display to show the current trading session.

#FS10016\_S0050\_00400

In SPDB, alerts can be set based on the Trade Session Configuration versus Trade Session Events for that particular market on that Trading date.

# Technical Operations Monitoring and Alerts

This section covers the monitoring of the servers in the HKEX data centre by ITD. The primary users are the Enterprise System Operations.

## Server Statistics Monitoring & Alerts

#FS10016\_S0060\_00100

|  |  |  |
| --- | --- | --- |
| Statistics Type | Warning Threshold | ALERT Threshold |
| CPU Utilization | 90% | 95% |
| Memory Utilization | 80% | 90% |
| Storage Utilization | 80% | 90% |

Upon the statistics reaches the Thresholds, alerts are generated and sent to the Enterprise System Operations.

In low latency server setup, CPU is kept to 100% as soon as the system is up. In such cases the CPU Utilization alerts would not be raised.

## Hardware Events Alerts for Attention

#FS10016\_S0060\_00200

There are hardware events that would require attentions are monitored by ITD, for example, memory checksum errors, power supply failures etc. These alerts are sent to Enterprise System Operations.

## Application Control Manager

#FS10016\_S0060\_00300

ODP-T core backend components are developed upon OTP framework. The component lifetime is controlled by a process called Application Control Manager (ACM). A component lifetime includes the startup, shutdown, promote to active etc. The state of the core backend components are monitored by the Application Control Manager (ACM) on top of the hardware monitoring mentioned above. ACM monitors the components on the processing level. If the main processing thread is stalled, ACM would generate alerts. The generated alerts are sent to ESO. If the main processing thread is stalled for a pro-longed period configured, ACM would stop the stalled component and promote its standby process if one is configured.

Should the ACM have issues on itself, ESO has the authority to terminate the problem ACM.

# Business Alerts Function

## SPDB Alerts

#FS10016\_S0070\_00100

SPDB provided alert functions based on the provided data. The alerts are setup upon the setup of SPDB.

## Price Limit Alerts

#FS10016\_S0070\_00201

|  |  |  |  |
| --- | --- | --- | --- |
| **Field** | **Data Type** | **Description** | **Data Source (MRT)** |
| DateTime | Timestamp | Alert Time |  |
| **Key** | | |  |
| Instrument ID | String | Market Code | Extract and map from field “Security ID Ref” |
| **Data** | | |  |
| Triggering Price | Long |  |  |
| Reference Price | Long |  | VCM: Collect from “VCM Cooling Off Triggered” msg DPL: Collect from “Current Dynamic Price Limit” msg |
| Triggering Type | Integer | 0 – VCM  1 – DPL | Extract from the Reject ReasonCode of Order Rejected, Order Amend Rejected, and Quote Rejected |

# Use of ECW for System Monitoring

This section describes the capabilities of External Circuit Watch (ECW) to assist the system monitoring.

## External Circuit Watch System

#FS10016\_S0075\_00100

External Circuit Watch is a system that sit in a HKEX managed market zone where a typical participant is located. ECW has accessibilities to ODP-T order gateways and OMDD through both SDNet and HSN.

#FS10016\_S0075\_00200

In ECW, a client order simulator with text-based user interface is built enabling Business Operations to input orders, receive order acknowledgment (or rejects) and trades to / from ODP-T order gateways.

## Configuration Setup by Business Operations[[1]](#footnote-1)

#FS10016\_S0075\_00300

For the monitoring usage of ECW, it requires Business Operations to setup Dummy Markets and tradable Dummy Instruments in ODP-T together with proper trade sessions, price limit & safeguards. Accessibility, entitlements and throttles of the order gateways is also required be setup.

## System Monitoring Usage

#FS10016\_S0075\_00401

Through the ECW Client Order simulator, Business Operations would be able to inject orders into the ODP-T order gateways and get the responses.

#FS10016\_S0075\_00500

Such order injection is treated as normal orders by a normal EP. Hence, the order is going through the core data flow path which are the core system components of ODP Trading. When the responses such as order acknowledgement messages are successfully returning back to the Client Order Simulator, it indicates the healthiness of the system.

#FS10016\_S0075\_00600

Since this is treated as a regular EP, the order gateway connection status with the order statistics are showing up in the Trading Admin GUI. The corresponding order statistics would also be shown in SPDB.

## ECW Startup and Shutdown

#FS10016\_S0075\_00700

The monitoring methodology by ECW is by sending orders into the system and get the responses. Such methodology is consider as intrusive. The concern on causing market confusions remains even with this approach. In order to reduce the chance of misuse of the system and to reduce the anxiety generating by the concern, by default ECW is down during trading hours. Business Operations and/or IT Manager with appropriate approval rights can send request to IT to bring it up for monitoring. While there is no Service Level Agreement to bring up ECW during trading hours, when such a request is coming to IT, it normally indicates a potential issue to the system. It is expected such request be treated with priority by IT unless there are other higher priority tasks come before it. Shall there be initiative to have ECW be up during trading hours on a regular basis, a thorough risk assessment as well as management approval should be conducted. Such arrangement is outside the scope of this Functional Specification.

# Appendix – Non Day 1

#FS10016\_S0080\_00100

A FS tag for non-day1 features for Traceability matrix

1. This document only describes the capability and possibility of using Dummy Markets and Dummy Instruments to assist in the monitoring. The risk assessment of such usage is not in scope of this Functional Specification. For the usage mentioned here, there should be adequate risk assessments and discussions before the decision is made. Same applies to open up the Dummy Market & Instruments to EP to access. [↑](#footnote-ref-1)
