TITLE:

**FUNCTIONAL SPECIFICATION**

**ODP-T**

FS10010 - Product Structure

AUTHOR : IT/Markets Systems DATE : 12 Jan 2026

LAST REVIEW : Derivatives Trading Business Operations DATE : 28 Feb 2025

**CONTENTS**

[1. Document Control 3](#__RefHeading___Toc204411219)

[1.1. Change History 3](#__RefHeading___Toc204411220)

[1.2. Document Cross-referenced 4](#__RefHeading___Toc204411221)

[1.3. Abbreviation 4](#__RefHeading___Toc204411222)

[2. Introduction 6](#__RefHeading___Toc204411225)

[3. Product Structure 7](#__RefHeading___Toc204411226)

[3.1. Exchange 7](#__RefHeading___Toc204411227)

[3.2. Market 8](#__RefHeading___Toc204411228)

[3.3. Instrument Group 10](#__RefHeading___Toc204411229)

[3.4. Instrument Type 12](#__RefHeading___Toc204411230)

[3.5. Underlying 13](#__RefHeading___Toc204411231)

[3.6. Instrument Class 15](#__RefHeading___Toc204411232)

[3.7. Instrument 19](#__RefHeading___Toc204411233)

[3.8. Combo Group 22](#__RefHeading___Toc204411256)

[3.9. Combo Type 23](#__RefHeading___Toc204411257)

[3.10. Combo Class 25](#__RefHeading___Toc204411258)

[3.11. Combo 28](#__RefHeading___Toc204411259)

[3.11.1. TMC Number 31](#__RefHeading___Toc204411260)

[4. Instrument/Combo Identifier 32](#__RefHeading___Toc204411261)

[4.1. Instrument ID/Combo ID 32](#__RefHeading___Toc204411262)

[4.2. Legacy Instrument ID 32](#__RefHeading___Toc204411263)

[5. Product Maintenance 33](#__RefHeading___Toc204411264)

[5.1. Creation and Modification 33](#__RefHeading___Toc204411265)

[5.2. Handling of Instrument ID Update 33](#__RefHeading___Toc204411266)

# Document Control

## Change History

|  |  |  |  |
| --- | --- | --- | --- |
| Version  Number | Issue Date | Author | Abstract |
| V1.0 | 20240909 | IT/Markets Systems | Initial version. |
| V1.1 | 20241016 | IT/Markets Systems | Revised based on review comments from business users |
| V2.0 | 20241031 | IT/Markets Systems | Revised based on review comments from business users |
| V2.1 | 20241106 | IT/Markets Systems | Revised based on review comments from business users |
| V2.2 | 20241120 | IT/Markets Systems | Revised based on review comments from business users |
| V2.3 | 20241122 | IT/Markets Systems | Revised based on review comments from business users |
| V2.4 | 20241126 | IT/Markets Systems | Revised based on review comments from business users |
| V3.0 | 20241127 | IT/Markets Systems | Revised based on review comments from business users |
| V3.1 | 20241206 | IT/Markets Systems | Revised based on review comments from business users |
| V3.2 | 20241227 | IT/Markets Systems | Revised based on review comments from business users |
| V3.3 | 20250324 | IT/Markets Systems | Revised based on review comments from business users |
| V3.4 | 20250724 | IT/Markets Systems | Revised based on review comments from business users |
| V3.5 | 20260112 | IT/Markets Systems | Revised based on review comments from business users |

## Document Cross-referenced

|  |  |  |
| --- | --- | --- |
| # | Document | Version |
| 1 | FS10001 - Trading Timetable | 20250722 |
| 2 | FS10003 - Orderbook and Execution | 20250324 |
| 3 | FS10004 - Price Supervision | 20250122 |
| 4 | FS10006 - Block Trade | 20250707 |
| 5 | FS10007 - Self Match Prevention | 20250324 |
| 6 | FS10008 - Market Maker Protection | 20250615 |
| 7 | FS10011 - Participant Structure | 20250603 |
| 8 | FS10013 – Market Operation Admin GUI | 20250725 |
| 9 | FS10023 - Instrument and Combo Generation | 20250617 |
| 10 | BRD\_DT\_0001: 0001 BRS Trading Microstructure | 2024 10 16 |
| 11 | BRD\_DT\_0002: 0002 BRS Order Management | v2.4 2025 01 09 |
| 12 | BRD\_DT\_0003: 0003 BRS Order Book Execution Management | V1.6\_2025 01 21 |
| 13 | BRD\_DT\_0004: 0004 BRS Market Integrity Safeguards | v1.8 - 2025 1 15 |
| 14 | BRD\_DT\_0005: 0005 BRS Trading Operations | v2.7\_ 2024 12 06 |
| 15 | BRD\_DT\_0008: 0008 ODP - NewFunctionRequest - Block Trade Facility | 2024 11 19 |
| 16 | BRD\_DT\_0009: 0009 BRS\_Series Operation | 2024 10 15\_v5 |
| 17 | BRD\_DT\_0010: 0010 ODP - Automation of Price Limit Monitoring and Handling | 2024 06 06 |
| 18 | BRD\_DT\_0018: 0018 ODP - NewFunctionRequest - Capital Adjustment | 20241015 |
| 19 | BRD\_DT\_0037: 0037 Purple Ticket - Reference Data \_ Content | v6 |
| 20 | BRD\_DT\_0050: 0050 BRS\_PDMPA functions in ODP | v1.3 2025 01 14 |
| 21 | BRD\_DT\_0052: 0052 ODP - NewFunctionRequest - Product Setup | 20240517 |

## Abbreviation

|  |  |
| --- | --- |
| CA | Capital Adjustment |
| EP | Exchange Participant |
| GTC | Good Till Cancel |
| GTD | Good Till Date |
| ID | Identifier |
| ISO | International Organization for Standardization |
| MMP | Market Maker Protection |
| MVT | Minimum Volume Thresholds |
| TMC | Tailor Made Combo |

# Introduction

Product structure describes the trading product hierarchy and their attributes at different levels in the system.

# Product Structure

#FS10010\_S0030\_00100

Tradable instruments are arranged in a hierarchical structure based on their belonging market, contract type, and underlying instrument.

The hierarchical structure allows specific attributes or settings which will be described individually in later sections to be inherited from upper-level to lower-level entities. For example, there is a Normal Day Timetable ID in Market, all the entities under the Market can share the Normal Day Timetable ID, or it can specifically has its own Normal Day Timetable ID to override the upper-level configuration.

The diagram below shows a summary of the product structure arrangement.

![](data:image/x-wmf;base64...)

Unless specified, the attributes of the entities described in this section are mandatory.

## Exchange

#FS10010\_S0030\_00200

The Exchange is the top-level entity in the hierarchy. It contains attributes listed in the table below:

Exchange attributes:

|  |  |  |
| --- | --- | --- |
| **Attribute** | **Ref to Entity** | **Description** |
| Exchange ID | N | A unique ID representing the exchange.  E.g. HK |
| Description | N | A complete name of the exchange. The attribute is optional and for informational only. |
| Exchange Code | N | A unique number representing the exchange.  It is a component of legacy Instrument ID and Combo ID.  The value cannot be changed. |
| Short Name | N | A unique short name of the exchange. |

## Market

#FS10010\_S0030\_00300

The Market defines the default normal trading days, non-trading days, special trading days and normal trading days timetable for instruments under the market. The day entities and timetable are detailed in FS10001, the market also contains attributes listed in the table below:

![](data:image/x-wmf;base64...)

Market Attributes:

|  |  |  |
| --- | --- | --- |
| **Attribute** | **Ref to Entity** | **Description** |
| Market ID | N | A unique ID representing the market. |
| Description | N | Description of the market. The attribute is optional and informational only. |
| Market Code | N | A unique number representing the market.  It is a component of legacy Instrument ID and Combo ID.  The system internally supports up to 65,535 markets. For backward compatibility, Admin GUI and interface protocol to downstream systems will restrict the maximum limit of Market Code to 255.  The value cannot be changed. |
| Exchange ID | Y | The ID of the exchange this market belongs to.  The value cannot be changed. |
| MIC | N | A Market Identifier Code according to the ISO 10383 standard.  This attribute is optional for informational only. |
| Market Type | N | The type of products to connect to the market. The valid values are:   * Stock * Fixed income * Currency * Power/energy * Commodity * Payment * Index * General   This attribute is for informational only. |
| Index? | N | A flag indicates if this is an index market, an index of the market type.  For example, when the Market Type is “Stock” and the Index is “Y”, it is a Stock Index Market.  This attribute is for informational only. |
| Dummy? | N | A flag indicates if this is a dummy market. |
| Traded? | N | A flag indicates if the market is visible to EP and available for trading. |
| Normal Trading Days | N | The Weekdays for Normal Trading Days. Details in FS10001. |
| Non-Trading Days ID | Y | The ID of Non-trading Days configuration. Details in FS10001.  This attribute is optional. |
| Special Trading Days ID | Y | The ID of Special Trading Days configuration. Details in FS10001.  This attribute is optional. |
| Normal Day Timetable ID | Y | The ID of Normal Day Timetable configuration. Details in FS10001. |
| Block Trade MVT ID | Y | The ID of Block Trade MVT configuration. Details in FS 10006.  This attribute is optional. |
| Priority Number | N | A lower value indicates higher priority for the ordering of auction matching. Details in FS10003 section - Order Book Ordering. |

## Instrument Group

#FS10010\_S0030\_00400

The Instrument Group is a classification of instruments to trade, for example futures and options. It contains attributes listed in the table below:

Instrument Group Attributes:

|  |  |  |
| --- | --- | --- |
| **Attribute** | **Ref to Entity** | **Description** |
| Instrument Group ID | N | A unique ID representing the instrument group. |
| Description | N | Description of the instrument group. The attribute is optional and informational only. |
| Short Name | N | A unique short name of the instrument group.  It is used to name instruments in Name Standard. |
| Instrument Group Code | N | A unique number representing the instrument group. The number cannot exist in Combo Group Code.  It is a component of legacy Instrument ID.  The value cannot be changed. |
| Group Type | N | The classification of instruments under this group. The valid values are:   * Options * Forward * Futures * FRA * Cash * Payment * Exchange rate * Interest rate swap   When Options is selected, options specific configuration in this group and instruments under the groups are available. |
| Physical delivery? | N | A flag indicates if instruments under this group are physically delivered.  This attribute is for informational only. |
| Maturity? | N | A flag indicates if instruments under this group are having maturity date.  This attribute is for informational only. |
| Options Type | N | The type of options contracts under this instrument group. The valid values are:   * Call * Put   It is used to name instruments in Name Standard.  This attribute is available only when Group Type is Options. |
| Options Style | N | The exercise style of options contracts under this instrument group. The valid values are:   * American * European * Asian * Bermudan * Knock-in * Knock-out * Binary * Ratchet   This attribute is available only when Group Type is Options.  It is for informational only. |
| Options Variant | N | The variant of the options specifies the condition on turnover. The valid values are:   * Cap – a limit of max turnover. Deep in-the-money options are settled to the cap level. * Floor – a limit of min turnover. In-the-money options are settled at least the floor level. * Normal – neither cap nor floor limit apply.   This attribute is available only when Group Type is Options.  It is for informational only. |
| Futures Styled Options? | N | A flag indicates if instruments under this group are Futures Styled Options. When true, the premium is paid mark-to-market each day. Otherwise, it is paid when the trade is executed.  This attribute is available only when Group Type is Options.  It is for informational only. |

## Instrument Type

#FS10010\_S0030\_00500

The Instrument Type is an entity that groups a Market and an Instrument Group. It contains attributes and references to other configuration entities listed in the table below:

![](data:image/x-wmf;base64...)

Instrument Type Attributes:

|  |  |  |
| --- | --- | --- |
| **Attribute** | **Ref to Entity** | **Description** |
| Instrument Type ID | N | A unique ID representing the instrument type.  The ID must be unique across Instrument Type and Combo Type. |
| Description | N | Description of the instrument type. The attribute is optional and informational only. |
| Market ID | Y | The ID of the market this instrument type belongs to.  The value cannot be changed.  The Instrument Type can be uniquely identified by Market ID together with Instrument Group ID. |
| Instrument Group ID | Y | The ID of the Instrument Group this instrument type belongs to.  The value cannot be changed.  The Instrument Type can be uniquely identified by Market ID together with Instrument Group ID. |
| Traded? | N | A flag indicates if the instrument type is visible to EP and available for trading.  When the Traded attribute in any one of the upper levels is false, this value has no effect, instruments under this Instrument Type are not visible to EP and not available for trading. |
| Special Trading Days ID | Y | The ID of Special Trading Days configuration overrides market level. Details in FS10001. |
| Normal Day Timetable ID | Y | The ID of Normal Day Timetable configuration overrides market level. Details in FS10001. |
| Block Trade Eligible? | N | A flag indicates if instruments under this Instrument Type are eligible for block trade. Details in FS10006. |
| Identify in Quote Request? | N | A flag indicates if Quote Requests for Instrument under this Instrument Type forwarded to market will include EP ID of the request sender. |
| Default Order Size Limit | N | Default order size limit when granting trading right to an EP. Details in FS10011. It overrides the value in Global parameters. |
| Default Block Trade Size Limit | N | Default block trade size limit when granting trading right to an EP. Details in FS10011. It overrides the value in Global parameters. |
| Maximum Order Size Limit By EP | N | The maximum order size limit configurable by EP for Instruments under this Instrument Type. It overrides the value in Global parameters. |
| Maximum Block Trade Size Limit By EP | N | The maximum block trade size limit configurable by EP for Instruments under this Instrument Type. It overrides the value in Global parameters. |

## Underlying

#FS10010\_S0030\_00600

The Underlying defines an instrument which derivative contracts derived from. It contains attributes listed in the table below:

Underlying Attributes:

|  |  |  |  |
| --- | --- | --- | --- |
| **Attribute** | **Ref to Entity** | **Description** |  |
| Underlying ID | N | A unique ID representing the underlying. |  |
| Description | N | A complete name of the underlying. The attribute is optional and informational only. |  |
| Underlying Code | N | A unique number representing the underlying.  It is a component of legacy Instrument ID and Combo ID.  The value cannot be changed. |  |
| Status | N | The underlying status, valid values are:   * Active – The instruments with this underlying are available for trading. * Suspended – The instruments with this underlying are suspended from trading. |  |
| Effective Status | N | This is a display-only / read-only field.  This field shows the effective status by combining the Underlying Status and Underlying Data Source Status.  The value determination follows the below rules sequentially:   1. Either one is suspended: Suspended. 2. Active. |  |
| Underlying Type | N | The type of underlying. The valid values are:   * Stock * Currency * Fixed income * Power/energy * Commodity * Metal   This attribute is for informational only. |  |
| Index? | N | A flag indicates if the underlying is an index.  This attribute is for informational only. |  |
| Underlying Issuer | N | The issuer company short name for the underlying.  This attribute is used for choosing associated Instrument for Capital Adjustment. Details in FS10003.  The value cannot be changed. |  |
| MMP Enabled? | N | A flag indicates if MMP feature is enabled for this underlying. Details in FS10008. |  |
| Minimum MMP Quantity | N | The minimum quantity for MMP quantity protection and delta protection on this underlying. Details in FS10008.  This attribute is available only when MMP feature is enabled for this underlying. |  |
| Price Decimals | N | The decimal places of price stored in the system for this underlying.  E.g. last price, settlement price. |  |
| Currency | N | The ISO 4217 currency code.  This attribute is for informational only. |  |
| CA Spin-off In-Progress? | N | This is a read-only field, it indicates the state of spin-off Capital Adjustment. Details in FS10003. |  |
| CA Created? | N | This is a read-only field. A flag indicates if the underlying is created by CA process.  A CA created underlying with all Instrument / Combo passed last trading date is subject to be reused.  Reuse of CA created underlying is described in FS10003 - Capital Adjustment - Phase 1 - New Underlying. |  |
| CA Reuse Cool-off Date | N | This is a read-only field and used for CA created underlying only. The field is empty for manually created underlying.  When the underlying is CA Created and all relevant instruments are passed last trading date, a day end batch job will mark the cool-off date based on the CA re-use cool-off period. CA process will not reuse this underlying on or before this date.  CA Re-use Cool-off Period is described in FS10003 - Capital Adjustment - Phase 1 - New Underlying. |  |
| Data Source | N | The type of data source. The valid values are:   * OMD-C (Securities Market) * OMD-I (HSI Index Feed) | |
| Data Source Symbol Code | N | The corresponding symbol code from the data source.  For Data Source = OMD-C:  1 - 99999  For Data Source = OMD-I:  ASCII characters with max length = 11 | |
| Data Source Status | N | This is a read-only field, it indicates the status of the symbol from the data source, valid values are:   * Active * Suspended | |
| Last Traded Price | N | The reference last traded price for the underlying. The value will be updated when the closing price of the symbol is received from the data source. | |

### Data Source and Data Source Symbol

Each Underlying is allowed to associate with a Data Source and a corresponding Data Source Symbol Code. The same data source and data symbol code can be associated with more than one underlying.

The status and the closing price of the symbol from the data source is being monitored. When there are updates from the data source, the changes will be populated to the associated underlying.

For example, if the underlying is a stock in Securities Market, its data source will be configured as OMD-C and its symbol code will be the stock code. When the stock is suspended or resumed, the underlying data source status will be updated automatically by the system.

## Instrument Class

#FS10010\_S0030\_00700

The Instrument Class defines instruments of a specific instrument type on an underlying by associating an instrument type and an underlying entity. For example, when associating with an Instrument Type of HIBOR Futures with an Underlying 1-Month HIBOR Strips, the Instrument Class represents a 1-Month HIBOR Futures. It contains attributes and references to other configuration entities listed in the table below:

![](data:image/x-wmf;base64...)

Instrument Class Attributes:

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
| **Attribute** | | **Ref to Entity** | | **Description** |
| Instrument Class ID | | N | | A unique ID representing the Instrument Class.  The ID must be unique across Instrument Class and Combo Class. |
| Description | | N | | Description of the Instrument Class. The attribute is optional and informational only. |
| Instrument Type ID | | Y | | The ID of the Instrument Type this Instrument Class belongs to.  The value cannot be changed.  The Instrument Class can be uniquely identified by Instrument Type ID together with Underlying ID. |
| Underlying ID | | Y | | The ID of the Underlying this Instrument Class associates with.  The value cannot be changed.  The Instrument Class can be uniquely identified by Instrument Type ID together with Underlying ID. |
| Traded? | | N | | A flag indicates if the instrument class is visible to EP and available for trading.  When the Traded attribute in any one of the upper levels is false, this value has no effect, instruments under this Instrument Class are not visible to EP and not available for trading. |
| Currency | | N | | The ISO 4217 currency code.  This attribute is for informational only. |
| Settlement Currency | N | | The ISO 4217 currency code.  This attribute is for informational only. | |
| Price Tick ID | | Y | | The ID of Price Tick configuration that assigns to instruments under this Instrument Class for minimum price fluctuation. Details in FS10004. |
| Price Tick Limit ID | | Y | | The ID of Price Tick Limit configuration that assigns to instruments under this Instrument Class. Details in FS10004.  This attribute is available only when Auto Price Tick Limit update is enabled. |
| Auto Price Tick Limit Update? | | N | | A flag indicates if the Auto Price Tick Limit update is enabled. Details in FS10004. |
| Corresponding Instrument Class For Price Tick | | Y | | A reference to another Instrument Class representing the Corresponding Instrument Class for Price Tick Limit calculation. Details in FS10004.  This attribute is available only when Auto Price Tick Limit update is enabled and the upper-level instrument group is defined as options. |
| Price Limit ID | | Y | | The ID of Price Limit configuration that assigns to instruments under this Instrument Class. Details in FS10004.  This attribute is optional. |
| VCM ID | | Y | | The ID of VCM configuration that assigns to instruments under this Instrument Class. Details in FS10004.  This attribute is optional. |
| AHT Reference Price Futures Group ID | | Y | | The ID of AHT Reference Price Futures Group configuration that assigns to instruments under this Instrument Class. Details in FS10004.  This attribute is optional and is available only when the upper-level instrument group is defined as futures. |
| Corresponding Instrument Class For AHT Reference Price | | Y | | A reference to another Instrument Class representing the Corresponding Instrument Class for AHT Reference Price calculation. Details in FS10004.  This attribute is optional and is available only when AHT Reference Price Futures Group ID is set. |
| Price Quotation Factor | | N | | The contract multiplier to underlying index in price value of instruments under this Instrument Class.  E.g. 50 for HK$50 per index point.  Capital Adjustment may modify the value detailed in FS10003. |
| Contract Size | | N | | The number of underlying shares per contract for instruments under this Instrument Class.  E.g. 500 for 500 stock shares of underlying instrument for 1 contract.  Capital Adjustment may modify the value detailed in FS10003. |
| Decimals for Contract Size and PQF | | N | | The number of decimals for price quotation factor and contract size. |
| Decimals for Strike Price | | N | | The number of decimals for strike price. |
| Special Trading Days ID | | Y | | The ID of Special Trading Days configuration. It overrides the value in upper levels. Details in FS10001. |
| Normal Day Timetable ID | | Y | | The ID of Normal Day Timetable configuration. It overrides the value in upper levels. Details in FS10001. |
| Block Trade Eligible? | | N | | A flag indicates if instruments under this Instrument Class are eligible for block trade. It overrides the value in upper level. Details in FS10006. |
| Block Trade MVT ID | | Y | | The ID of Block Trade MVT configuration. Details in FS 10006.  This attribute is available only when block trade is eligible. |
| Block Trade Static Price Limits? | | N | | A flag indicates if Static Price Limits apply to Instrument under this Instrument Class. Details in FS10006.  This attribute is available only when block trade is eligible. |
| Lot Size | | N | | The round lot size (number of contracts) in order entry quantity for instruments under this instrument class. |
| Name Standard ID | | Y | | A reference to Name Standard configuration for instruments under this Instrument Class. |
| Auto Generation? | | N | | A flag indicates if instrument automatic generation for this instrument class is enabled. Details in FS10023. |
| Auto Instrument Generation Rule ID | | Y | | The ID of Auto Instrument Generation Rule configuration. This is a read-only field. |
| Last CA Effective Date | | N | | This is a read-only field, it indicates the effective date of the last CA Phase 2 process.  This attribute is used to identify an Instrument Class went through CA Phase 2, the Instruments for next trading date are already generated. Auto generation will be skipped. Details in FS10003 Capital Adjustment section. |

## Instrument

#FS10010\_S0030\_00800

The Instrument defines the exact contract specification of a tradable instrument. It inherits attributes from the parent Instrument Class with additional attributes. As instruments are usually created by automatic generation, the attributes are automatic assigned by either copied from upper levels or auto generation rule. They are listed in table below:

Instrument Attributes:

|  |  |  |
| --- | --- | --- |
| **Attribute** | **Ref to Entity** | **Description** |
| Instrument ID | N | A unique ID representing the instrument (aka Security ID). It is used as an instrument identifier for order entry.  The ID must be unique across Instrument and Combo.  The assignment of value by automatic generation refers to FS10023. |
| Instrument Class ID | Y | The ID of the Instrument Class this Instrument belongs to.  The value cannot be changed. |
| Strike Price | N | The strike price of the options instrument. The attribute is available only when the upper-level instrument group is defined as options. For the non-options instrument, the strike price is set to 0 (default value).  The assignment of value by automatic generation refers to FS10023.  It is a component of legacy Instrument ID.  The value cannot be changed.  The Instrument can be uniquely identified by Instrument Class ID + Strike Price + Last Trading Date + Modifier. |
| Traded? | N | A flag indicates if the instrument is visible to EP and available for trading.  When the Traded attribute in any one of the upper levels is false, this value has no effect, the instrument is not visible to EP and not available for trading.  Unless specified explicitly, new instruments are set to visible to market and available for trading. |
| Effective Date | N | The date that this instrument is effective in the system.  If the instrument creation is immediately effective and the current calendar date is a trading date, the value will be the current date. Otherwise, it will be the next trading date. |
| Status | N | The Instrument status, valid values are:   * Active – The instrument is available for trading. * Suspended – The instrument is suspended. The Instrument is not available for trading.   For an instrument to be effectively allowed for trading, it must be Active in both:   * Instrument Status (this attribute) and, * Effective Underlying Status.   Unless specified explicitly, new instruments are having value Active. |
| Effective Status | N | This is a display-only / read-only field.  This field shows the effective status by combining the effective Underlying Status and Instrument Status.  The value determination follows the below rules sequentially:   1. Either one is suspended: Suspended. 2. Active. |
| Last Trading Date | N | The final day the instrument can be traded.  It is a component of legacy Instrument ID.  This attribute cannot be modified.  The Instrument can be uniquely identified by Instrument Class ID + Strike Price + Last Trading Date + Modifier. |
| Effective Last Trading Date | N | As the Last Trading Date is a component of legacy Instrument ID, and ID should not be amended due to Last Trading Date changes.  This attribute will be used for Last Trading Date reference for both EP, downstream systems and trading system instrument operation.  Unless specified explicitly, new instruments are having the Effective Last Trading Date same as Last Trading Date. To adjust the final day the instrument can be traded, this attribute should be changed. |
| Last Trading Time | N | The final time on the last trading date the instrument can be traded.  This attribute is optional. If it is not set, the instrument will end trading according to the trading timetable. |
| First Trading Date | N | The first day the instrument can be traded.  This attribute is optional. If it is not set, the instrument will start trading from the effective date.  The first trading date and first trading time cannot be changed once the instrument started trading. |
| First Trading Time | N | The beginning time on the first trading date the instrument can be traded.  This attribute is optional. If it is not set, the instrument will start trading according to the trading timetable.  The first trading date and first trading time cannot be changed once the instrument started trading. |
| Modifier | N | It is a component of legacy Instrument ID.  New instruments are having value 0. Capital Adjustment on the instrument will have the value increased by 1. Details in FS10003.  This attribute cannot be modified.  The Instrument can be uniquely identified by Instrument Class ID + Strike Price + Last Trading Date + Modifier. |
| Price Quotation Factor | N | The contract multiplier to underlying index in price value of the instrument. It overrides the value in Instrument Class level.  Capital Adjustment may modify the value detailed in FS10003. |
| Contract Size | N | The number of underlying shares per contract for the instrument. It overrides the value in Instrument Class level.  Capital Adjustment may modify the value detailed in FS10003. |
| ISIN | N | ISIN of the Instrument. A 12-character alphanumeric code.  The field is optional and will be left blank when the instrument is created by automatic generation. |
| SEDOL | N | SEDOL of the Instrument. A seven-character alphanumeric code.  The field is optional and will be left blank when the instrument is created by automatic generation. |

## Combo Group

#FS10010\_S0030\_01100

The Combo Group is a classification of combo to trade. It contains attributes listed in the table below:

Combo Group Attributes:

|  |  |  |
| --- | --- | --- |
| **Attribute** | **Ref to Entity** | **Description** |
| Combo Group ID | N | A unique ID representing the combo group. |
| Combo Group Code | N | A unique number representing the combo group. The number cannot exist in Instrument Group Code.  It is a component of legacy Instrument ID.  This attribute cannot be modified. |
| Short Name | N | A unique short name of the combo group.  It is used to name combo in Name Standard. |
| Description | N | Description of the combo group. The attribute is optional and informational only. |
| Tailor Made Only? | N | A flag indicates if combos under this combo group are TMC only.  At most one combo group is allowed to have this flag set.  The value cannot be changed if there exists combo type linked with this combo group. |
| Time Spread Level | N | A number representing the time spread level of combo under this Combo Group. The time spread level must be unique when defined.  It is used for selecting Combo Class in Automatic Generation for Combo.  This is an optional field. |

## Combo Type

#FS10010\_S0030\_01200

The Combo Type is an entity that groups a Market and a Combo Group. It contains attributes and references to other configuration entities listed in the table below:

![](data:image/x-wmf;base64...)

Combo Type Attributes

|  |  |  |
| --- | --- | --- |
| **Attribute** | **Ref to Entity** | **Description** |
| Combo Type ID | N | A unique ID representing the combo type.  The ID must be unique across Instrument Type and Combo Type. |
| Description | N | Description of the combo type. The attribute is optional and informational only. |
| Market ID | Y | The ID of the market this combo type belongs to.  This attribute cannot be modified.  The Combo Type can be uniquely identified by Market ID together with Combo Group ID. |
| Combo Group ID | Y | The ID of the Combo Group this combo type belongs to.  This attribute cannot be modified.  The Combo Type can be uniquely identified by Market ID together with Combo Group ID. |
| Allow Different Price Quotation Factor? | N | A flag indicates if combos under the Combo Type allow leg instruments with different price quotation factor.  The attribute is informational only. |
| Special Trading Days ID | Y | The ID of Special Trading Days configuration overrides Leg 1 setting. Details in FS10001. |
| Normal Day Timetable ID | Y | The ID of Normal Day Timetable configuration overrides Leg 1 setting. Details in FS10001. |
| Block Trade Eligible? | N | A flag indicates if combos under this Combo Type are eligible for block trade. Details in FS10006. |
| TMC Strategy List ID | Y | The ID of the TMC Strategy List for combos under this combo type. Details in FS10003.  When the value is 0, it means no restriction strategy.  The attribute is available only when the upper-level combo group is for TMC only. |
| TMC Allow Cross Market? | N | A flag indicates if TMC leg instruments allowed in different Market.  The attribute is available only when the upper-level combo group is for TMC only. |
| TMC Max Ratio | N | The max ratio allowed amongst all TMC combo legs for combos under this Combo Type.  The attribute is available only when the upper-level combo group is for TMC only. |
| TMC Max Ratio Difference | N | The max ratio difference allowed between TMC combo legs for combos under this Combo Type.  The attribute is available only when the upper-level combo group is for TMC only. |
| TMC Number Retention Days | N | The number of blackout days until the TMC number can be reused. Details in Name Standard for TMC section.  The attribute is available only when the upper-level combo group is for TMC only. |
| TMC Expiration Period | N | The valid period of TMC. Details in FS10003 – Tailor Made Combination (TMC).  The attribute is available only when the upper-level combo group is for TMC only. |
| Name Standard ID | Y | A reference to Name Standard configuration for combos under this Combo Type.  This attribute is optional. |
| Identify In Quote Request? | N | A flag indicates if Quote Requests for Combo under this Combo Type forwarded to market will include EP ID of the request sender. |
| Allow GTC and GTD Order? | N | A flag indicates if order time validity GTC and GTD are allowed for combos under this Combo Type. |

## Combo Class

#FS10010\_S0030\_01300

The Combo Class defines instruments of a specific combo type on an underlying by associating a combo type and an underlying entity.

![](data:image/x-wmf;base64...)

Combo Class Attributes:

|  |  |  |
| --- | --- | --- |
| **Attribute** | **Ref to Entity** | **Description** |
| Combo Class ID | N | A unique ID representing the combo class.  The ID must be unique across Instrument Class and Combo Class. |
| Description | N | Description of the combo class. The attribute is optional and informational only. |
| Combo Type ID | Y | The ID of the Combo Type this Combo Class belongs to.  This attribute cannot be modified.  The Combo Class can be uniquely identified by Combo Type ID together with Underlying ID. |
| Underlying ID | Y | The ID of the Underlying for Leg 1.  Leg 1 is defined by the first leg after sorting by the name (alphabetical) of Instrument Class Name.  This attribute cannot be modified.  The Combo Class can be uniquely identified by Combo Type ID together with Underlying ID. |
| Traded? | N | A flag indicates if the combo class is visible to EP and available for trading.  When the Traded attribute in any one of the upper levels is false, this value has no effect, Combo under this Combo Class are not visible to EP and not available for trading. |
| Implied? | N | A flag indicates if implied order generation is enabled. |
| Currency | N | The ISO 4217 currency code.  This attribute is for informational only. |
| Price Tick ID | Y | The ID of Price Tick configuration that assigns to combos under this Combo Class for minimum price fluctuation. Details in FS10004. |
| Price Tick Limit ID | Y | The ID of Price Tick Limit configuration that assigns to combos under this Combo Class. Details in FS10004.  This attribute is available only when Auto Price Tick Limit update is enabled. |
| Auto Price Tick Limit Update? | N | A flag indicates if the Auto Price Tick Limit update is enabled. Details in FS10004. |
| Special Trading Days ID | Y | The ID of Special Trading Days configuration. It overrides the value in upper levels. Details in FS10001. |
| Normal Day Timetable ID | Y | The ID of Normal Day Timetable configuration. It overrides the value in upper levels. Details in FS10001. |
| Block Trade Eligible? | N | A flag indicates if combos under this Combo Class are eligible for block trade. It overrides the value in upper level. Details in FS10006. |
| Block Trade Minimum Volume Thresholds | N | The minimum volume thresholds for Block Trade. It overrides the value in upper levels. Details in FS 10006.  This attribute is optional and only available when block trade is eligible. |
| Lot Size | N | The lot size (number of contracts) for combos under this combo class. |
| Price Tick Limit ID | Y | The ID of Price Tick Limit configuration that assigns to instruments under this Combo Class. Details in FS10004. |
| TMC Expiration Period | N | The valid period of TMC. Details in FS10003 – Tailor Made Combination (TMC). It overrides the value in upper levels.  The attribute is available only when the upper-level combo group is for TMC only. |
| Name Standard ID | Y | A reference to Name Standard configuration for combos under this Combo Class. |
| Auto Generation | N | A flag indicates if automatic generation for this combo class is enabled. Details in FS10023. |

## Combo

#FS10010\_S0030\_01500

The Combo defines the exact contract spec of a combination/strategy tradable instrument. It inherits attributes from the parent Combo Class with additional attributes listed in table below:

Combo Attributes

|  |  |  |
| --- | --- | --- |
| **Attribute** | **Ref to Entity** | **Description** |
| Combo ID | N | A unique ID representing the combo (aka Instrument ID or Security ID). It is used as an instrument identifier for order entry.  The ID must be unique across Instrument and Combo.  The assignment of value by automatic generation refers to FS10023. |
| Combo Class ID | Y | The ID of the Combo Class this Combo belongs to. |
| Ref Num | N | The TMC number (refer to Section 3.11.1.). The attribute is available only when the upper-level combo group is for TMC only. For the standard combo, this attribute is set to 0 (default value).  It is a component of legacy Instrument ID.  The value cannot be changed.  The Combo can be uniquely identified by Combo Class ID + Ref Num + Last Trading Date + Modifier. |
| Status | N | The Combo status, valid values are:   * Active – The combo is available for trading. * Suspended – The combo is suspended. The Combo is not available for trading. * Delisted – The combo is delisted. The Combo is not available for trading and appears as if it does not exist. This status is available to TMC only.   For a combo to be effectively allowed for trading, it must be Active in both:   * Combo Statue (this attribute) and, * Instrument Status on all legs.   Unless specified explicitly, new combos are having value Active. |
| Effective Status | N | This is a display-only / read-only field.  This field shows the effective status by combining the Combo Status and Instrument Status on all legs.  The value determination follows the below rules sequentially:   1. Combo is delisted: Delisted. 2. Either one is suspended: Suspended. 3. Active. |
| Effective Date | N | The date that this combo is effective in the system.  If the combo creation is immediately effective and the current calendar date is a trading date, the value will be the current date. Otherwise, it will be the next trading date. |
| Last Trading Date | N | The final day the combo can be traded.  It is a component of legacy Instrument ID.  This attribute cannot be modified.  The Combo can be uniquely identified by Combo Class ID + Ref Num + Last Trading Date + Modifier. |
| Effective Last Trading Date | N | As the Last Trading Date is a component of legacy Instrument ID, and ID should not be amended due to Last Trading Date changes.  This attribute will be used for Last Trading Date reference for both EP, downstream systems and trading system instrument operation.  To adjust the final day the combo can be traded, this attribute should be changed.  The effective last trading date and time must be earlier than or equal to the earliest effective last trading date and time in any one of the legs. |
| Last Trading Time | N | The final time on the last trading date the combo can be traded.  The effective last trading date and time must be earlier than or equal to the earliest effective last trading date and time in any one of the legs.  This attribute is optional. If it is not set, the combo will end trading according to the trading timetable. |
| First Trading Date | N | The first day the instrument can be traded.  The first trading date and time must be later than or equal to the latest first trading date and time in any one of the legs.  This attribute is optional. If it is not set, the combo will start trading from the effective date.  The first trading date and first trading time cannot be changed once the combo started trading. |
| First Trading Time | N | The beginning time on the first trading date the combo can be traded.  The first trading date and time must be later than or equal to the latest first trading date and time in any one of the legs.  This attribute is optional. If it is not set, the combo will start trading according to the trading timetable.  The first trading date and first trading time cannot be changed once the combo started trading. |
| Modifier | N | It is a component of legacy Instrument ID.  New combos are having value 0. Capital Adjustment on the combo will have the value increased by 1. Details in FS10003.  This attribute cannot be modified.  The Combo can be uniquely identified by Combo Class ID + Ref Num + Last Trading Date + Modifier. |
| Legs 1 | N | |  |  |  | | --- | --- | --- | | **Leg Attribute** | **Ref to Entry** | **Description** | | Operation | N | The operation of Leg 1. The valid values are:   * Buy – Buy the leg instrument when buying the Combo. * Sell – Sell the leg instrument when buying the Combo. | | Ratio | N | The ratio of the Leg. | | Instrument ID | Y | The ID of instrument for Leg 1. | |
| Legs 2 | N | |  |  |  | | --- | --- | --- | | **Leg Attribute** | **Ref to Entry** | **Description** | | Operation | N | The operation of Leg 2. | | Ratio | N | The ratio of Leg 2. | | Instrument ID | Y | The ID of instrument for Leg 2. | |
| Legs 3 | N | |  |  |  | | --- | --- | --- | | **Leg Attribute** | **Ref to Entry** | **Description** | | Operation | N | The operation of Leg 3. | | Ratio | N | The ratio of Leg 3. | | Instrument ID | Y | The ID of instrument for Leg 3. | |
| Legs 4 | N | |  |  |  | | --- | --- | --- | | **Leg Attribute** | **Ref to Entry** | **Description** | | Operation | N | The operation of Leg 4. | | Ratio | N | The ratio of Leg 4. | | Instrument ID | Y | The ID of instrument for Leg 4. | |

Notes: Instrument ID for legs in Combo cannot be duplicated.

### TMC Number

#FS10010\_S0030\_01400

The TMC Number is a reference sequence number per underlying from 1 to 99,999. When a TMC is created, the next smallest available TMC Number starting from 1 is assigned automatically. Once a TMC Number is assigned, it is occupied. An occupied TMC Number is not available for subsequent assignment.

TMC Combo ID is defined by the TMC Name Standard which contains 2 parts:

* Name Standard.
* Suffixed with a “/” character and followed by a TMC Number (in a 3 to 5 digits number, from “001” to “99999”).

The Name Standard details are described in FS10023 – Combo Name Standard section.

TMC Combo ID has a configurable retention period after the Effective Last Trading Date of the Instrument. Within this period, the TMC Number is still occupied. After the retention period, the TMC Combo ID is removed from the system and the TMC Number becomes available for assignment again.

# Instrument/Combo Identifier

#FS10010\_S0030\_00900

There are 2 IDs in the instrument/combo, both are assigned upon creation:

* Security ID (aka Instrument ID or Combo ID).
* Legacy Instrument ID.

Both IDs are present in the reference data to the downstream systems.

## Security ID

The Security ID is the key attribute of the instrument/combo and is used by the system as a unique identifier to tradable instruments. This ID is either manually assigned from Admin GUI, file upload, or generated by Auto Instrument/Combo Generation Rule based on Name Standard.

## Legacy Instrument ID

The Legacy Instrument ID is created for downstream systems for backward compatibility reasons.

The Legacy Instrument ID is defined based on the attributes in different parts of Product Structure listed below:

* Exchange – Exchange Code
* Market – Market Code
* Instrument Group – Instrument Group Code; Combo Group – Combo Group Code
* Underlying – Underlying Code
* Instrument – Last Trading Date; Combo – Last Trading Date
* Instrument – Strike Price; Combo – Ref Num
* Instrument – Modifier; Combo - Modifier

# Product Maintenance

## Creation and Modification

#FS10010\_S0040\_00100

In operation perspective, entities in the product structure can be setup and maintained via individual Admin GUI functions. Details in FS10013.

New setup of multiple entities in different levels with dependency can be done together before approval in Admin GUI. For example, Business Operations can create a new Market then a new Instrument Type associated to the new Market without having the Market approved beforehand, and then on the same day at later time approve them all one by one.

Except specified as below, creations and updates of product structure entities and their attributes are effective in next trading day.

The following are the entities supported intra-day creation with immediate effective:

|  |  |
| --- | --- |
| **Entity** | **Description** |
| Instrument | Instrument can be created in Admin GUI. |
| Combo | Combo can be created in Admin GUI (both standard combo and TMC) or by Exchange Participant (TMC only). |

The following are the entities and their attributes supported intra-day modification with immediate effective:

|  |  |  |
| --- | --- | --- |
| **Entity** | **Attribute** | **Description** |
| Underlying | Status  MMP Enabled?  Minimum MMP Quantity | Underlying attributes in the list can be updated in Admin GUI. |
| Instrument | Status  Effective Last Trading Date  Last Trading Time  First Trading Date  First Trading Time | Instrument attributes in the list can be updated in Admin GUI. |
| Combo | Status  Effective Last Trading Date  Last Trading Time  First Trading Date  First Trading Time | Combo attributes in the list can be updated in Admin GUI. |

## Handling of Instrument ID Update

#FS10010\_S0030\_01000

In rare situations where the Instrument ID/Combo ID is required to be updated, Business Operations will suspend the existing instrument/combo and then create a new one with the updated Instrument ID/Combo ID. Downstream systems will receive the original instrument/combo updated to suspended status and then a new instrument/combo record with new Instrument ID/Combo ID and original attributes.

Business operations might further delete the suspended instrument/combo record which will be effective in next trading day.

When the component of the Legacy Instrument ID is required to be updated (for example, strike price), Business Operations could follow the same procedure for Instrument ID/Combo ID update as described above.
