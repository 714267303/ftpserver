TITLE:

**FUNCTIONAL SPECIFICATION**

**ODP-T**

FS10007 - Self Match Prevention

AUTHOR : IT/Markets Systems DATE : 18 Jun 2026

LAST REVIEW : Derivatives Trading Business Operations DATE : 06 Jan 2026

**CONTENTS**

[1. Document Control 3](#__RefHeading___Toc193720408)

[1.1. Change History 3](#__RefHeading___Toc193720409)

[1.2. Document Cross-referenced 3](#__RefHeading___Toc193720410)

[1.3. Abbreviation 4](#__RefHeading___Toc193720411)

[2. Introduction 5](#__RefHeading___Toc193720412)

[3. Self-Match Prevention - SMP 6](#__RefHeading___Toc193720413)

[3.1. ID Based SMP 6](#__RefHeading___Toc193720414)

[3.1.1. SMP ID Sharing Feature 7](#__RefHeading___Toc193720415)

[3.1.2. SMP ID Format 7](#__RefHeading___Toc193720416)

[3.1.3. SMP ID Creation and Sharing Request 8](#__RefHeading___Toc193720417)

[3.1.4. SMP ID Stop Sharing Request 9](#__RefHeading___Toc193720418)

[3.1.5. SMP ID Update Request 9](#__RefHeading___Toc193720419)

[3.1.6. SMP ID Removal Request 10](#__RefHeading___Toc193720420)

[3.1.7. SMP ID Request Approval Period 10](#__RefHeading___Toc193720421)

[3.1.8. Manual Administration 11](#__RefHeading___Toc193720422)

[3.1.9. Order and Quote Handling 11](#__RefHeading___Toc193720423)

[3.1.10. Match Processing 12](#__RefHeading___Toc193720424)

[3.1.11. GTC/GTD Orders Reload Handling 14](#__RefHeading___Toc193720425)

[3.1.12. Disabling ID Based SMP 15](#__RefHeading___Toc193720426)

[3.1.13. SMP ID Status 15](#__RefHeading___Toc193720427)

[3.2. Session Based SMP 15](#__RefHeading___Toc193720428)

[3.2.1. Match Processing 16](#__RefHeading___Toc193720429)

[3.2.2. GTC/GTD Order Reload Handling 17](#__RefHeading___Toc193720430)

[3.2.3. Manual Administration 17](#__RefHeading___Toc193720431)

[3.2.4. Disabling Session Based SMP 17](#__RefHeading___Toc193720432)

[3.3. Switching Between ID Based SMP and Session Based SMP 17](#__RefHeading___Toc193720433)

[3.4. Remove Orders Violating the Internal Crossing Rule 18](#__RefHeading___Toc193720434)

[3.4.1. Order Removal Example 19](#__RefHeading___Toc193720435)

[3.5. Contingency Switch 20](#__RefHeading___Toc193720436)

[3.5.1. Turn OFF switch 20](#__RefHeading___Toc193720437)

[3.6. SMP ID Generation 21](#__RefHeading___Toc193720438)

[3.6.1. 5 Characters SMP IDs 21](#__RefHeading___Toc193720439)

[3.6.2. 9 Digits SMP IDs 21](#__RefHeading___Toc193720440)

[3.7. Records Deletion 21](#__RefHeading___Toc193720441)

[3.8. Reports 21](#__RefHeading___Toc193720442)

[3.8.1. SMP ID File Submission Status Report 22](#__RefHeading___Toc193720443)

[3.8.2. SMP ID Full Image Report 22](#__RefHeading___Toc193720444)

[3.8.3. SMP ID Delta Change Report 22](#__RefHeading___Toc193720445)

[3.8.4. SMP ID Master Report 22](#__RefHeading___Toc193720446)

[3.8.5. SMP ID ECP Submission Status Report 22](#__RefHeading___Toc193720447)

[3.8.6. SMP ID All Submission Status Report 22](#__RefHeading___Toc193720448)

[3.8.7. Housekeeping report 23](#__RefHeading___Toc193720449)

[3.8.8. SMP ID Activities Report 23](#__RefHeading___Toc193720450)

# Document Control

## Change History

|  |  |  |  |
| --- | --- | --- | --- |
| Version  Number | Issue Date | Author | Abstract |
| V0.1 | 20231221 | IT/Markets Systems | Initial version. |
| V0.2 | 20240119 | IT/Markets Systems | Revised based on review comments from business users |
| V0.3 | 20240201 | IT/Markets Systems | Revised based on review comments from business users |
| V0.4 | 20240228 | IT/Markets Systems | Revised based on review comments from business users |
| V1.0 | 20240927 | IT/Markets Systems | Revised based on review comments from business users |
| V2.0 | 20241031 | IT/Markets Systems | Revised based on review comments from business users |
| V3.0 | 20241126 | IT/Markets Systems | Revised Section 1.2 Document Cross-referenced table. |
| V3.1 | 20250324 | IT/Markets Systems | Revised based on review comments from business users |
| V3.2 | 20260106 | IT/Markets Systems | Refine/clarify the document. |
| V3.3 | 20260618 | IT/Markets Systems | Refine/clarify the document. |

## Document Cross-referenced

|  |  |  |
| --- | --- | --- |
| # | Document | Version |
| 1 | BRD\_DT\_0002: 0002 BRS Order Management | v2.4 2025 01 09 |
| 2 | BRD\_DT\_0004: 0004 BRS Market Integrity Safeguards | v1.8 - 2025 1 15 |
| 3 | BRD\_DT\_0044: 0044 BRS BAU Support | V1.6\_20250103 |
| 4 | BRD\_DT\_0049: 0049 BRS ODP Online | V2.8 - 2025-01-09 |
| 5 | BRD\_DT\_0050: 0050 BRS\_PDMPA functions in ODP | v1.3 2025 01 14 |
| 6 | FS10002 Order Management | 20260602 |
| 7 | FS10003 Orderbook and Execution Management | 20260602 |

## Abbreviation

|  |  |
| --- | --- |
| AHT | After Hours Trading |
| CA | Cancel Aggressive |
| CP | Cancel Passive |
| ECP | Electronic Communication Platform |
| FaK | Fill and Kill |
| FS | Function Specification |
| FoK | Fill or Kill |
| GTC | Good Till Cancel |
| GTD | Good Till Date |
| GUI | Graphical User Interface |
| ID | Identifier |
| PDF | Portable Document Format |
| SMP | Self-Match Prevention |
| UI | User Interface |
| VCM | Volatility Control Mechanism |

# Introduction

To define the function specification for the SMP feature in ODP trading system including how it is setup, how it affects order matching behavior and reporting.

# Self-Match Prevention - SMP

#FS10007\_S0030\_00100

SMP is a feature for exchange participants to prevent inadvertent self-trades at exchange level. With the feature enabled, matching engine will not allow self-orders to match against each other.

#FS10007\_S0030\_00200

#FS10007\_S0030\_00201 (As agreed by DT and IT, the Session Based (User Based) SMP functionality is considered as not necessary for ODP. User will raise a request in the future if it is required again.)

ODP provides the ID based ~~and session based~~ SMP mechanisms.

~~The 2 SMP mechanisms cannot co-exist for an exchange participant.~~ When a SMP ID is created for or shared to an exchange participant, ID based SMP feature will be enabled for this exchange participant. To enable session based SMP, an exchange participant must not own or shared with a SMP ID.

#FS10007\_S0030\_00300

By default, newly created exchange participants do not have SMP feature enabled.

#FS10007\_S0030\_00350

SMP feature does not apply to implied orders and block trades.

## ID Based SMP

#FS10007\_S0030\_00400

ID based SMP feature allows exchange participant to tag their orders so that orders with same ID will not be matched against each other. When 2 orders with the same ID tagged have potential to match, one of them will be cancelled.

#FS10007\_S0030\_00500

There are 2 types of cancellation method for ID based SMP, cancel aggressive (CA) and cancel passive (CP). #FS10007\_S0030\_00600 It is an attribute of the SMP ID, changes can be done effective on the next trading day. Details on how the attribute affects order matching will be described in the Section 3.1.10..

#FS10007\_S0030\_00700

SMP IDs are created on-demand per request from an exchange participant (ID owner). When an ID is created, it needs to be explicitly assigned to the ID owner before the orders can be tagged with the created ID. When an ID is removed (i.e. marked as deleted, refer to Section 3.7. for details), the ID is not effective in the system.

#FS10007\_S0030\_00800

As SMP IDs are assigned to exchange participant level, all order flow sessions under the exchange participant are allowed to tag orders with those assigned IDs. On the other hand, exchange participants without SMP ID assigned are not allowed to tag any value to the SMP ID field of their orders, such orders will be rejected by the system.

#FS10007\_S0030\_00900

Each exchange participant in ODP is allowed to have up to 600 SMP IDs assigned. The amount of SMP ID assignments include the (1) SMP IDs requested by the exchange participant itself and (2) sharing SMP IDs from other exchange participants.

When an EP had SMP ID assigned, his ID based SMP feature is enabled. Vice versa, the ID based SMP feature is disabled for EPs do not have any SMP ID.

### SMP ID Sharing Feature

#FS10007\_S0030\_01000

Aside from being an ID owner to acquire SMP ID, exchange participant can also share an ID from another ID owner when permissions from both parties are given. In this case, the same SMP ID can be used by both exchange participants and their orders tagged with the same ID will not cross.

#FS10007\_S0030\_01100

When an SMP ID is sharing to other exchange participants and being marked as deleted in the system, the ID is not effective for all sharing exchange participants.

#FS10007\_S0030\_01200

The maximum number of exchange participants to share an ID is 3000.

#FS10007\_S0030\_01300

An ID shared from other exchange participants count towards the 600 IDs assignment limited mentioned in previous section.

### SMP ID Format

#FS10007\_S0030\_01400

(As agreed by DT and IT, the 5 Characters ID Format is considered as not necessary for ODP.)

ODP supports the following ID format.

* ~~#FS10007\_S0030\_01500 5 alphanumeric characters. 1 digit checksum + 4 alphanumeric characters, the ID must include at least 1 letter and at least 1 digit. This is the existing system ID format.~~
* #FS10007\_S0030\_01600 9 numeric digits. 8 numeric digits + 1 digit checksum with 8 numeric digits part starts from 21,001,000.

#### 5 Characters ID Format

#FS10007\_S0030\_01700

(As agreed by DT and IT, the 5 Characters ID Format is considered as not necessary for ODP.)

~~Existing system is using SMP ID with 5 characters format. ODP will support the 5 characters ID so that exchange participants do not have to change their IDs when ODP launch and within the stabilization period. Newly created IDs within the period will also be in 5 characters format.~~

#### 9 Digits ID Format

#FS10007\_S0030\_01800

All SMP IDs in existing system (5 digits) will be migrated to ODP by padding zeros “0” as the leftmost significant digits and therefore the numeric value is no change. For example, the ID 10019 in existing system will become 000010019, effectively the same value 10019. New SMP ID generated by ODP will starts from 21,001,000 and a check digit (refer to Section 3.6. for details).

### SMP ID Creation and Sharing Request

#FS10007\_S0030\_02300

The SMP ID creation involves exchange participant to submit a SMP Maintenance Request via ECP. The system downloads the request form from ECP and parses the form data to generate an ID creation request pending for business operations to review and confirm. The confirmed request will then be pending for approver review and approval.

#FS10007\_S0030\_02400

Once the request is approved, a new ID record will be created and assigned to the requesting exchange participant as ID owner with the following information associated:

1. Application form reference number.
2. The ID owner participant.
3. Cancellation method.
4. Description. A free text field for an individual SMP ID allows 48 characters. The content can be manipulated by Manual Administration GUI.
5. Date time of form submission.
6. Active Status.

#FS10007\_S0030\_02500

The newly generated SMP ID will be communicated to exchange participant by a report files, and it will be effective the next trading day.

#FS10007\_S0030\_02600

The sharing of SMP ID requires both ID owner and the sharing exchange participant raise request to share an existing ID by submitting SMP Maintenance Request via ECP. The request form from both parties must be submitted within a configurable number of days. Once request forms from both sides are received, the sharing request will be pending for business operations to review and confirm. The confirmed request will then be pending for approver review and approval. An approved ID sharing request will add the ID to the sharing participant.

#FS10007\_S0030\_02700

Same as ID creation, the ID sharing will be communicated to both exchange participants by report files, the sharing will be effective intra-day or the next trading day.

#FS10007\_S0030\_02800

Aside from report files showing changes, a daily report will show all exchange participants their assigned SMP IDs.

### SMP ID Stop Sharing Request

#FS10007\_S0030\_02900

Stop sharing a SMP ID can be done by submitting a SMP Maintenance Request via ECP from the ID owner. #FS10007\_S0030\_03000 ID sharing participants cannot stop sharing by themselves.

#FS10007\_S0030\_03050

The system downloads the request form from ECP and parses the form data to generate an ID sharing request pending for business operations to review and confirm. The confirmed request will then be pending for approver review and approval.

#FS10007\_S0030\_03100

Once the stop sharing request is approved, the ID is removed from the sharing participant effective on the next trading day. Both the ID owner and sharing participant will receive updated status from status report files.

#FS10007\_S0030\_03200

Stop sharing an ID will effectively remove the ID from the sharing participant. Removing SMP ID will result in GTC/GTD orders tagged with the ID cancelled with details described in GTC/GTD Orders Reload Handling section.

### SMP ID Update Request

#FS10007\_S0030\_03300

ID owner can update the cancellation instruction of their SMP ID by submitting a SMP Maintenance Request via ECP The system downloads the request form and parses the form data to generate an cancellation instruction update request for business operations review and confirmed. The confirmed request will then be pending for approver review and approval.

#FS10007\_S0030\_03400

ID updates are effective on the next trading day. Both the ID owner and sharing exchange participant will receive updated status from status report files.

### SMP ID Removal Request

#FS10007\_S0030\_03500

ID owner can remove their SMP IDs by submitting a SMP Maintenance Request via ECP. The system downloads the request form and parses the form data to generate an ID removal request for business operations to review and confirm. The confirmed request will then be pending for approver review and approval.

#FS10007\_S0030\_03600

An approved request will result in removing the SMP ID from all sharing exchange participants and ID owner, and the SMP ID will be no longer in-use effective on the next trading day. Removal status will be communicated to all relevant exchange participants by status report files.

#FS10007\_S0030\_03700

Removing SMP ID will result in GTC/GTD orders tagged with the ID cancelled with details described in GTC/GTD Orders Reload Handling section.

#FS10007\_S0030\_03900

The ID will be removed at day end batch job from the ID owner and all other sharing exchange participants when the ID owner ceases trading.

#FS10007\_S0030\_04000

It should be noted that all ID removals are logically deletion. The process involves marking the ID record status to deleted state. #FS10007\_S0030\_04100 Business operations can query those deleted IDs via Admin GUI.

### SMP ID Request Approval Period

#FS10007\_S0030\_04200

Generated SMP maintenance requests including add, sharing, stop sharing and removal are open to approval for a configurable number of days (approval period) which is configured in global parameter.

#FS10007\_S0030\_04300

(a) An unapproved ID creation request, (b) an unapproved ID sharing request pair, (c) an unapproved stop sharing request and (d) an unapproved ID removal request that left in the system over the approval period are considered obsoleted and rejected at day end batch job automatically.

#FS10007\_S0030\_04400

A single side ID sharing request without counterparty request is having another global parameter configuration for number of days before obsoletion.

### Manual Administration

#FS10007\_S0030\_04500

Business operations are allowed to query or maintain SMP ID records via Admin GUI. SMP IDs can be manually added, shared, updated, suspended and removed.

#FS10007\_S0030\_04550

ID creation, sharing, stop sharing, suspension and removal can be

1. Intraday effective immediate and #FS10007\_S0030\_04600 retained on the next trading day onward, or
2. On the next trading day.

ID update (e.g. change cancellation method) is effective on the next trading day.

The behavior for intraday SMP ID creation, sharing, stop sharing, suspension and removal:

|  |  |  |
| --- | --- | --- |
| **Action** | **New Order/Quote** | **Existing Order** |
| Create | The system accepts the newly created SMP ID | N/A |
| Share with Firm B | The system allows Firm B to tag the shared SMP ID, and executes SMP-related functions associated with that shared SMP ID. | N/A |
| Stop sharing with Firm B | The system rejects the shared SMP ID if it is entered by Firm B. | * Existing orders of Firm B that already tagged with this SMP ID still retain the ID but will not have any SMP-related functions applied. * For reload of GTC/GTD, refer to section 3.1.11. |
| Suspend | The system rejects the suspended SMP ID. | * Existing orders that already tagged with this SMP ID still retain the ID but will not have any SMP-related functions applied. * For reload of GTC/GTD, refer to section 3.1.11. |
| Remove | The system rejects the deleted SMP ID. | * Existing orders of Firm B that already tagged with this SMP ID still retain the ID but will not have any SMP-related functions applied. * For reload of GTC/GTD, refer to section 3.1.11. |

When a SMP ID is suspended or removed from the ID owner intraday, the ID is retained in participant’s outstanding orders and relevant subsequence order update messages but without SMP function. #FS10007\_S0030\_04800 In addition, the participant is no longer allowed to input new orders with the ID.

#FS10007\_S0030\_04900

When a SMP ID is removed (i.e. marked as deleted), the ID is not effective for the ID owner and all sharing exchange participants.

#FS10007\_S0030\_05000

In a situation where an ID is shared between the ID owner and other exchange participants, when the ID removal is done only to one of the sharing participants and effective intraday, it is effectively ID stop sharing. #FS10007\_S0030\_05100 The tagged orders from that unshared participant can cross with tagged orders from others. #FS10007\_S0030\_05200 As the ID still exists under ID owner and other sharing participants, their tagged orders do not cross.

### Order and Quote Handling

#FS10007\_S0030\_05250

When an order is having SMP ID present, it is subject to SMP monitored. Otherwise, SMP feature will not apply.

#FS10007\_S0030\_05300

The system does not calculate or validate the checksum digit. When an order is inputted with SMP ID tagged, gateway pass-through the ID to matching engine. Matching engine does exact match the whole ID against active SMP IDs assigned to exchange participant. The order is accepted when the SMP ID exist under the exchange participant, otherwise it is rejected.

#FS10007\_S0030\_05400

For quotes, the same SMP ID is tagged to both side of the quote entry.

#FS10007\_S0030\_05500

SMP ID field of outstanding orders or quotes can be amended (add / change / remove SMP ID) by order / quote amendment feature described in FS10002 – Order Management. Amendment to SMP ID will result in loss of priority.

#FS10007\_S0030\_05600

The SMP ID field is dedicated for SMP feature usage. When an exchange participant does not have SMP ID assigned but tagging orders with the SMP ID field, their orders will be rejected.

### Match Processing

#FS10007\_S0030\_05700

SMP ID check will be done before each order matching. When the 2 orders being matched having same SMP ID tagged, matching engine will immediately cancel one of them to prevent trade execution. #FS10007\_S0030\_05800 When cancellation method of the SMP ID is CA, the aggressive order will be cancelled. #FS10007\_S0030\_05900 If it is CP, the passive order will be cancelled.

The definition of aggressive order and passive order are defined in FS10003 – Orderbook and Execution Management.

#FS10007\_S0030\_06000

When 2 orders match and hit the criteria for triggering both VCM and SMP, SMP order cancellation will be triggered first. In case of CP cancellation method, the aggressive order continue match with the next order in the book and another round “2 orders match” repeats.

#FS10007\_S0030\_06050

Similar behavior applies AHT Trading Halt, when 2 orders match and hit the criteria for triggering both AHT Trading Halt and SMP, SMP order cancellation will be triggered first.

#### FOK Order Handling

#FS10007\_S0030\_06100

FOK order matching is done in a 2 phases scan-and-match process. The first phase ensures enough resting volume to cross with the whole FOK order by scan through the prevailing order book. The second phase does the actual order matching.

#FS10007\_S0030\_06200

In the first phase when the FOK order is tagged with a CA SMP ID and hit a resting order with same ID, the FOK order is cancelled with SMP CA reason and do not perform the second phase matching.

#FS10007\_S0030\_06300

When the FOK order is tagged with a CP SMP ID, the first phase is to scan all resting orders, excluding those having same SMP ID. If sufficient volume is found to fill up the FOK order entirely, the system will put the FOK order into the order book and carry out the matching. During the matching, resting orders with same SMP ID will be cancelled. Otherwise, the FOK order is rejected, due to insufficient matching order quantity #FS10007\_S0030\_06400 and the order book will not be changed.

#### Auction Matching

#FS10007\_S0030\_06500

In auction matching, the SMP ID tagged with orders are ignored. Orders with same SMP ID can cross each other.

#### Examples

##### Cancel Aggressive Example

#FS10007\_S0030\_06600

Order Book.

|  |  |  |  |
| --- | --- | --- | --- |
| **SMP ID** | **BID** | **ASK** | **SMP ID** |
|  | (ID101) 100 @ 11.00 |  |  |
| CA:210010008 | (ID102) 200 @ 11.00 |  |  |
|  | (ID103) 100 @ 11.00 |  |  |

When an aggressive ASK **limit or FaK order** (ID104) 200 @ 11.00 with SMP ID (CA:210010008) inputted.

|  |  |  |
| --- | --- | --- |
| **Action** | **Order** | **Cancel Reason** |
| Match | (ID101) 100 @ 11.00 |  |
| Cancel | (ID104) 100 @ 11.00 | SMP CA |

When an aggressive ASK **FoK order** (ID105) 200 @ 11.00 with SMP ID (CA:210010008) inputted.

|  |  |  |
| --- | --- | --- |
| **Action** | **Order** | **Cancel Reason** |
| Cancel | (ID105) 200 @ 11.00 | SMP CA |

Aggressive **market order’s** CA SMP behaviour is same as **FaK order** shown above.

##### Cancel Passive Example

#FS10007\_S0030\_06700

Order Book.

|  |  |  |  |
| --- | --- | --- | --- |
| **SMP ID** | **BID** | **ASK** | **SMP ID** |
|  | (ID101) 100 @ 11.00 |  |  |
| CP:210010019 | (ID102) 200 @ 11.00 |  |  |
|  | (ID103) 100 @ 11.00 |  |  |

When an aggressive ASK **limit or FaK order** (ID106) 200 @ 11.00 with SMP ID (CP:210010019) inputted.

|  |  |  |
| --- | --- | --- |
| **Action** | **Order** | **Cancel Reason** |
| Match | (ID101) 100 @ 11.00 |  |
| Cancel | (ID102) 200 @ 11.00 | SMP CP |
| Match | (ID103) 100 @ 11.00 |  |

When an aggressive ASK **FoK order** (ID107) 200 @ 11.00 with SMP ID (CP:210010019) inputted.

|  |  |  |
| --- | --- | --- |
| **Action** | **Order** | **Cancel Reason** |
| Match | (ID101) 100 @ 11.00 |  |
| Cancel | (ID102) 200 @ 11.00 | SMP CP |
| Match | (ID103) 100 @ 11.00 |  |

When an aggressive ASK **FoK order** (ID108) 300 @ 11.00 with SMP ID (CP:210010019) inputted.

|  |  |  |
| --- | --- | --- |
| **Action** | **Order** | **Cancel Reason** |
| Cancel | (ID108) 300 @ 11.00 | Insufficient quantity for FOK order |

#FS10007\_S0030\_06800

Aggressive **market order’s** CP SMP behaviour is same as **FaK order** shown above.

### GTC/GTD Orders Reload Handling

#FS10007\_S0030\_06900

GTD/GTC orders are reloaded into the system with all attributes including SMP ID retained during system startup.

#FS10007\_S0030\_07000

There are 2 cases where orders will be unsolicited cancelled due to SMP ID:

* The SMP ID tagged to the order is not owned or shared to the exchange participant.
* With “Remove orders violating the internal crossing rule” enabled, the same SMP ID exists on both side of the book and their prices are either locked or crossed. The cancellation details are described in the “Remove Orders Violating the Internal Crossing Rule” section.

#FS10007\_S0030\_07100

In either case, an order status update of cancellation will be sent to the relevant order flow session.

### Disabling ID Based SMP

#FS10007\_S0030\_07200

Disable ID based SMP from an exchange participant involves removing all his owned SMP IDs and stop sharing his IDs to other participants. The SMP IDs those other exchange participants shared to him will also be removed.

### SMP ID Status

#FS10007\_S0030\_07210

|  |  |
| --- | --- |
| **Status Type** | **Description** |
| Status | The status of the SMP ID.  Possible values: Active, Deleted, Suspended   * Active - The SMP ID is effective. Newly created SMP IDs are in Active status. * Deleted - the SMP ID is logically deleted, and not effective. The record is waiting for physically deletion by housekeeping process. Details in Records Deletion section. * Suspended - the SMP ID is marked as suspended by manual administration function and not effective.   Notes: A SMP ID is “not effective” means SMP feature will consider it is an invalid ID. Orders with invalid ID will match. |

## Session Based SMP

#FS10007\_S0030\_07201 (As agreed by DT and IT, the Session Based (User Based) SMP functionality is considered as not necessary for ODP. User will raise a request in the future if it is required again.)

~~Session Based SMP supports the SMP v1.0 function in existing system. When it is chosen, exchange participant cannot tag their orders with SMP ID, otherwise they will be rejected.~~

~~Session Based SMP feature allows 2 options configured per user session:~~

1. ~~Session cannot cross.~~
2. ~~Session can cross with all (The default setting).~~

### ~~Match Processing~~

~~With option (a) session cannot cross, orders from the enabled user session cannot be matched with other orders either from the same user session or another user session under the same participant. When it happens, the aggressive order will be cancelled (Like CA in ID based SMP) with reason “Order deleted because trader is not allowed to trade with himself”.~~

~~With option (b) session can cross with all, orders from the user session can be matched with other orders from the same participant if that order owner’s session based SMP setting is also “session can cross with all”. In case the order on the other side is from a user session with “session cannot cross” enabled, the matching will not be allowed and this order as aggressive one will be cancelled with reason described in option (a).~~

~~In summary, when matching orders which both sides came from the same participant and either one of them are from a user session with session based SMP “session cannot cross” enabled, the aggressive order will be cancelled by the system to prevent self-match.~~

~~Same as CA of ID based SMP, when pre-trade validation check failed on both VCM and SMP, SMP cancellation will be triggered only.~~

#### ~~FOK Order Handling~~

~~The FOK order handling is like ID based SMP. Instead of examining the SMP ID, originating participant and session based SMP user session configuration are used to prevent trade.~~

#### ~~Auction Matching~~

~~Like ID based SMP, auction matching will match orders regardless session based SMP user session configuration. SMP feature does not effective in auction matching.~~

#### ~~Example~~

~~For a participant P1, enabled session based SMP feature, and he has 3 sessions P1A, P1B and P1C having follow configuration:~~

* ~~P1A - Session cannot cross.~~
* ~~P1B - Session cannot cross.~~
* ~~P1C - Session can cross with all.~~

~~There is another participant P2 without SMP feature enabled. He has 1 session:~~

* ~~P2A - SMP feature not enabled.~~

The following table shows orders from sessions match with orders from other sessions, both sides with varies configuration.

|  |  |  |
| --- | --- | --- |
| **~~Aggressive Order~~** | **~~Allow to match~~** | **~~Passive Order~~** |
| ~~P1A~~ | ~~×~~ | ~~P1A~~ |
| ~~P1A~~ | ~~×~~ | ~~P1B~~ |
| ~~P1A~~ | ~~×~~ | ~~P1C~~ |
| ~~P1A~~ | **~~~~** | ~~P2A~~ |
|  |  |  |
| ~~P1C~~ | **~~~~** | ~~P1C~~ |
| ~~P1C~~ | ~~×~~ | ~~P1B~~ |
| ~~P1C~~ | ~~×~~ | ~~P1A~~ |
| ~~P1C~~ | **~~~~** | ~~P2A~~ |

### ~~GTC/GTD Order Reload Handling~~

~~Like validation from ID based SMP, orders from participant with session based SMP and failed validation check are unsolicited cancelled:~~

* ~~Orders with SMP ID tagged. It happens when(1) the participant changed from ID based SMP to session based SMP and (2) SMP ID tagged in contingency situation described in later section.~~
* ~~With “Remove orders violating the internal crossing rule” enabled. Session based SMP enabled user session having orders in the order book and their prices are either locked or crossed with orders from the same participant. The cancellation details are described in the later section.~~

### ~~Manual Administration~~

~~Administration UI is provided to query or maintain session based SMP configuration. For a participant already having session based SMP enabled, changing session configuration between “session cannot cross” and “session can cross with all” are effective intra-day and changes will be retained on the next trading day and onward.~~

### ~~Disabling Session Based SMP~~

~~Disable session based SMP involves removing all session based SMP related configuration from the participant.~~

## Switching Between ID Based SMP and Session Based SMP

#FS10007\_S0030\_07202 (As agreed by DT and IT, the Session Based (User Based) SMP functionality is considered as not necessary for ODP. User will raise a request in the future if it is required again.)

~~Exchange participants changing from Session based SMP to ID based SMP will be effective on the next trading day, with all session based SMP configuration cleared. GTC/GTD orders originated from user session with session based SMP enabled will lose SMP protection as they are not SMP ID tagged.~~

~~Exchange participants do not allow to switch from ID Based SMP to Session Based SMP feature.~~

~~Based on the configuration from ID Based and Session Based SMP, there will be a 3-stages switch presented to user with position OFF, Session Based ON and ID Based ON per participant and it is by default at position OFF.~~

~~[Scenario 1] When an exchange participant subscribes to ID Based SMP (2.0)~~

~~Operation user (Maker) will see the switch changes from previous state (either OFF or Session Based) to ID Based position and at the same time requesting a new SMP ID plus removing all Session Based SMP configuration in a single request. Vice versa, when an exchange participant decided to remove his last SMP ID and effectively unsubscribe his SMP feature, the operation user (Maker) will see the removal of the SMP ID from the exchange participant and the switch changing to OFF position in a single request.~~

~~Sharing an ID to a SMP OFF exchange participant will also enable his ID Based SMP feature.~~

~~[Scenario 2] When an exchange participant subscribes to Session Based SMP (1.0)~~

~~One of their sessions should have “Session cannot cross” chosen. Operation user (Maker) will see the switch change from previous state (either OFF or ID Based) to Session Based position, the specific session with “Session cannot cross” enabled plus (if any) all SMP ID removed. On the other hand, setting all sessions under a participant to “Session can cross with all” will result in unsubscribing Session Based SMP and the 3-stages switch will turn to OFF position.~~

~~Based on the 3-stages switch presentation, an exchange participant can either subscribe to ID Based or Session Based SMP but not both. It is worth to note that an exchange participant cannot have Session Based SMP enabled and share a SMP ID from another exchange participant under the ID Based SMP mechanism.~~

## Remove Orders Violating the Internal Crossing Rule

#FS10007\_S0030\_07300

There is a flag in global parameter to enable or disable the removal of order due to SMP violation at system SOD trading state.

#FS10007\_S0030\_07500

When the flag is enabled, orders will be removed based on the SMP ID cancellation type CA or CP for participants with ID based SMP.

#FS10007\_S0030\_07501 (As agreed by DT and IT, the Session Based (User Based) SMP functionality is considered as not necessary for ODP. User will raise a request in the future if it is required again.)

~~For exchange participants with session based SMP, orders from SMP enabled session are examined with CA cancellation.~~

#FS10007\_S0030\_07600

ID based internal crossing violation orders are determined per SMP ID, and only orders with the specific SMP ID will be considered. For example, when working on SMP ID 1, only orders with SMP ID 1 will be loaded to a special purpose order book to check for potential internal crossing.

#FS10007\_S0030\_07650

After all GTC/GTD orders are reloaded in the order book, order removal due to the same SMP ID is done by comparing the orders with highest priority (price, time) from both sides of the book. After one of them is removed, the remaining one continues to compare with the next order on the other side until the book is no longer crossed.

#FS10007\_S0030\_07601 (As agreed by DT and IT, the Session Based (User Based) SMP functionality is considered as not necessary for ODP. User will raise a request in the future if it is required again.)

Session based internal crossing violation orders are determined per exchange participant. When one of the user sessions from an exchange participant having user based SMP enabled, all orders from the exchange participant are loaded to a special purpose order book for potential internal crossing check.

### Order Removal Example

#FS10007\_S0030\_07700

The following examples illustrate the orders to be removed. (T) is the timestamp with smaller number indicating earlier order entry time. The timestamp is used to determine aggressive and passive roles between orders during matching. Orders highlighted in RED are to be removed.

#FS10007\_S0030\_07800

For ID based SMP, when examinate orders with SMP ID1 (CA) with the below GTC orders loaded into orderbook.

|  |  |  |
| --- | --- | --- |
| **Bid** | **price** | **Ask** |
|  | 14 | Order (SMP ID1, T7) |
| Order (SMP ID1, T6) | 13 |  |
| Order (SMP ID1, T5) | 12 | Order (SMP ID1, T2) |
| Order (SMP ID1, T4) | 11 | Order (SMP ID1, T1) |
| Order (SMP ID1, T3) | 10 |  |

After the orderbook is loaded:

1. Comparing T6 and T1, T6 is removed.
2. Comparing T5 and T1, T5 is removed.
3. Comparing T4 and T1, T4 is removed.

#FS10007\_S0030\_07900

For ID based SMP, when examinate orders with SMP ID2 (CP) with the below GTC orders loaded into orderbook:

|  |  |  |
| --- | --- | --- |
| **Bid** | **price** | **Ask** |
|  | 14 | Order (SMP ID2, T7) |
| Order (SMP ID2, T6) | 13 |  |
| Order (SMP ID2, T5) | 12 | Order (SMP ID2, T2) |
| Order (SMP ID2, T4) | 11 | Order (SMP ID2, T1) |
| Order (SMP ID2, T3) | 10 |  |

After the orderbook is loaded:

1. Comparing T6 and T1, T1 is removed.
2. Comparing T6 and T2, T2 is removed.

#FS10007\_S0030\_07901 (As agreed by DT and IT, the Session Based (User Based) SMP functionality is considered as not necessary for ODP. User will raise a request in the future if it is required again.)

~~For session based SMP, when examinate orders from P1A user session of exchange participant P1 which having the session-based feature enabled and session cannot cross:~~

|  |  |  |
| --- | --- | --- |
| **~~Bid~~** | **~~price~~** | **~~Ask~~** |
|  | ~~14~~ | ~~P1 Order (T7)~~ |
|  | ~~13~~ | ~~P1 Order (T5)~~ |
| ~~P1 Order (T3)~~ | ~~12~~ | ~~P1 Order (T1)~~ |
| ~~P1 Order (T4)~~ | ~~11~~ | ~~P1 Order (T2)~~ |
| ~~P1 Order (T6)~~ | ~~10~~ |  |

~~After the orderbook is loaded:~~

1. ~~Comparing T3 and T2, T3 is removed.~~
2. ~~Comparing T4 and T2, T4 is removed.~~

## Contingency Switch

#FS10007\_S0030\_08000

A contingency switch administration function is provided to disable the SMP feature in all matching engine partitions so that both ID based SMP and # session based SMP are not effective. Thus, cancelling aggressive or passive orders when potential self-crossing will not happen, and the trade will occur. In contingency scenario, Business operations is allowed to disable the SMP feature via Admin GUI intra-day. Once the SMP is disabled, it cannot be re-enabled intra-day and the disabled status will be retained on the next trading day and onward.

#FS10007\_S0030\_08100

When the SMP feature is off, the validation on SMP ID field in order transaction for ID based SMP is disabled. Exchange participants can input any value to the field and tag to their order or quote without being validated regardless their SMP configuration. As an example, an exchange participant without either ID based, # or session based SMP feature enabled can also tag their orders. GTD / GTC orders with unvalidated SMP ID are persisted at day end and reloaded on the next trading day same as regular handling.

### #FS10007\_S0030\_08200

Business operations can re-enable the SMP feature via Admin GUI and it will be effective on the next trading day. Following regular GTD / GTC order reload handling, orders tagged with invalid / unexpected SMP ID are unsolicited cancelled.

## SMP ID Generation

### 5 Characters SMP IDs

#FS10007\_S0030\_08300

(As agreed by DT and IT, the 5 Characters ID Format is considered as not necessary for ODP.)

~~It is applied during stabilization period, the SMP ID follows the same format as before migration, with a check digit added at the beginning of the ID followed by 4-character ID. The check digit is calculated based on the 4-character ID. #FS10007\_S0030\_08400 When a new SMP ID registration is received, it continues the sequential ordering from the existing IDs prior to migration. #FS10007\_S0030\_08500 Each subsequent ID is incremented to ensure sequential order is maintained, which allows for fallback capability.~~

### 9 Digits SMP IDs

#FS10007\_S0030\_08600

The first 8 digits is a sequence number starting from 21,001,000 and the last digit is a check digit calculated using Damm algorithm. The generation keeps track of the highest sequence number and assigns the next number.

## Records Deletion

#FS10007\_S0030\_08700

All requests coming from exchange participants will result in either approved or rejected (manually or automatically due to timeout without submission or approval) as final state. Those request records are considered in completed state, they are retained in the system for a configurable number of days and then removed from the system (Physical deleted) in the housekeeping process.

#FS10007\_S0030\_08800

SMP ID in deleted state (Logical deleted) are retained in the system for a configured number of days and then removed from the system (Physical deleted) in the housekeeping process. When the ID is physical deleted, the ID will also be cleaned up from the ID owner and all sharing exchange participants.

#FS10007\_S0030\_08900

Before SMP IDs are physical deleted, Admin UI can query the SMP IDs with logical state “Deleted” and change back to “Active”. When it is the last SMP ID, the ID Based SMP feature for the exchange participant is also switched to OFF state, changing the SMP ID back to "Active" involve enabling ID Based SMP.

#FS10007\_S0030\_09000

The period between logical deleted and physical deleted is configurable in number of days in global parameter with max limit 30 days.

## Reports

#FS10007\_S0030\_09100

SMP report files listed below are generated automatically without the need of manual triggering or approval. The detailed report content and format are in FS10017.

### SMP ID File Submission Status Report

#FS10007\_S0030\_09200

Exchange participants submitted requests including creation, sharing and removal are accepted in ODP as request records. The request status (Completed / Rejected / In Progress) will be reported back to the originating exchange participant in the submission status report. This report will not cover changes made by Manual Administration.

### SMP ID Full Image Report

#FS10007\_S0030\_09300

The SMP ID full image report contains all CA and CP SMP IDs and their attributes per individual participant for the coming trading day. This report will cover changes made by Manual Administration.

### SMP ID Delta Change Report

#FS10007\_S0030\_09400

The SMP ID delta change report contains changed SMP IDs per individual participant for the coming trading day. This report will cover changes made by Manual Administration.

### SMP ID Master Report

#FS10007\_S0030\_09420

The SMP ID Mater Report contains all SMP ID exists in the system together with their attributes. This report is for HKEX internal use. This report will cover changes made by Manual Administration.

### SMP ID ECP Submission Status Report

#FS10007\_S0030\_09440

The SMP ID ECP Submissions Status Report contains (1) all outstanding / in-progress SMP ID requests including creation, sharing and removal, and (2) today’s completed or rejected records submitted by exchange participants. This report is for HKEX internal use. This report will not cover changes made by Manual Administration.

### SMP ID All Submission Status Report

#FS10007\_S0030\_09460

The SMP ID All Submission Status Report contains all SMP ID requests both outstanding, completed and rejected submitted by exchange participants. Records in this report will not be removed. This report is for HKEX internal use. This report will not cover changes made by Manual Administration.

### Housekeeping report

#FS10007\_S0030\_09500

Records being housekeeping clean up are presented in the housekeeping report. They include requests and deleted IDs which are over retention period and physically removed from the system. This report is for HKEX internal use.

### SMP ID Activities Report

#FS10007\_S0030\_09600

The content in SMP ID ECP Submission Status Report plus changes by Manual Administration. This report is for HKEX internal use.
