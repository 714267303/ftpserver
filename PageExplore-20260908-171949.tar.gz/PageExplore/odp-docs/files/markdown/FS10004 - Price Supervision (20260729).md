TITLE:

**FUNCTIONAL SPECIFICATION**

***ODP-T***

*FS10004 Price Supervision*

AUTHOR : *IT/Markets Systems*  DATE : *29 Jul 2026*

LAST REVIEW *Derivatives Trading Business Operations* DATE : *28 Feb 2025*

**CONTENTS**

[1. Document Control 5](#__RefHeading___Toc232605459)

[1.1. Change History 5](#__RefHeading___Toc232605460)

[1.2. Document Cross-referenced 5](#__RefHeading___Toc232605461)

[1.3. Abbreviation 5](#__RefHeading___Toc232605462)

[2. Introduction 7](#__RefHeading___Toc232605463)

[3. Price Tick 8](#__RefHeading___Toc232605464)

[3.1. Price Tick Table 8](#__RefHeading___Toc232605465)

[3.2. Price Tick Limits 10](#__RefHeading___Toc232605466)

[3.3. Automation of Price Tick Limits Update 11](#__RefHeading___Toc232605467)

[3.3.1. Triggering of Calculation 11](#__RefHeading___Toc232605468)

[3.3.2. Calculation Rule 11](#__RefHeading___Toc232605469)

[3.3.3. Reports 13](#__RefHeading___Toc232605470)

[3.3.4. Configuration 14](#__RefHeading___Toc232605471)

[3.4. Intra-day Price Tick Limits Update 14](#__RefHeading___Toc232605472)

[4. Price Limit 15](#__RefHeading___Toc232605473)

[4.1. Price Limit Calculation 15](#__RefHeading___Toc232605474)

[4.1.1. Static Price Limit 16](#__RefHeading___Toc232605475)

[4.1.2. Dynamic Price Limit 17](#__RefHeading___Toc232605476)

[4.2. Price Limit Check 19](#__RefHeading___Toc232605477)

[4.3. Handling of Market and Market to Limit Orders 20](#__RefHeading___Toc232605478)

[4.4. Implied Generation 20](#__RefHeading___Toc232605479)

[4.5. Intra-day Reference Price and Price Limit Changes 20](#__RefHeading___Toc232605480)

[4.6. Price Limit Configuration 22](#__RefHeading___Toc232605481)

[4.6.1. Price Limit Rule 22](#__RefHeading___Toc232605482)

[4.7. Contingency Off Switch 23](#__RefHeading___Toc232605483)

[4.8. AHT Static Price Limit Reference Price Calculation 24](#__RefHeading___Toc232605484)

[4.8.1. Futures Group 24](#__RefHeading___Toc232605485)

[4.8.2. Calculation Rule 25](#__RefHeading___Toc232605486)

[4.8.3. Triggering of Reference Price Calculation 27](#__RefHeading___Toc232605487)

[4.8.4. Logging and Alerts 27](#__RefHeading___Toc232605488)

[4.8.5. Configuration 28](#__RefHeading___Toc232605489)

[4.8.6. Contingency Handling 28](#__RefHeading___Toc232605490)

[4.9. Monitoring on Last Traded Price against Reference Price 28](#__RefHeading___Toc232605491)

[4.9.1. Triggering of Last Traded Price monitoring 29](#__RefHeading___Toc232605492)

[4.9.2. Logging and Alerts 29](#__RefHeading___Toc232605493)

[4.9.3. Configuration 30](#__RefHeading___Toc232605494)

[5. Trading Halt Mechanism 31](#__RefHeading___Toc232605495)

[5.1. Monitoring of Reference Futures 31](#__RefHeading___Toc232605496)

[5.2. Target Instruments List 32](#__RefHeading___Toc232605497)

[5.3. Triggering of Trading Halt 32](#__RefHeading___Toc232605498)

[5.4. Cooling-off Period 32](#__RefHeading___Toc232605499)

[5.5. Resumption of Trading Halt 34](#__RefHeading___Toc232605500)

[5.6. No Resumption Period 35](#__RefHeading___Toc232605501)

[5.7. THM Notification 36](#__RefHeading___Toc232605502)

[5.8. Exceptional Handling and Manual Halt 37](#__RefHeading___Toc232605503)

[5.9. THM Configuration 38](#__RefHeading___Toc232605504)

[6. Volatility Control Mechanism 39](#__RefHeading___Toc232605505)

[6.1. VCM Price Limit Calculation 39](#__RefHeading___Toc232605506)

[6.2. Determination of VCM Reference Price 39](#__RefHeading___Toc232605507)

[6.3. VCM Monitoring and Cooling-off Period 43](#__RefHeading___Toc232605508)

[6.4. Post VCM Cooling-off Period 44](#__RefHeading___Toc232605509)

[6.5. Implied Generation 46](#__RefHeading___Toc232605510)

[6.6. VCM Notification 46](#__RefHeading___Toc232605511)

[6.7. Intra-day Reference Price and Price Limit Changes 47](#__RefHeading___Toc232605512)

[6.8. VCM Configuration 47](#__RefHeading___Toc232605513)

[6.9. Contingency Off Switch 48](#__RefHeading___Toc232605514)

# Document Control

## Change History

|  |  |  |  |
| --- | --- | --- | --- |
| Version  Number | Issue Date | Author | Abstract |
| 0.1 | 4 Dec 2023 | IT/Markets Systems | Initial Version |
| 0.2 | 12 Jan 2024 | IT/Markets Systems | Revised Version |
| 0.3 | 15 Mar 2024 | IT/Markets Systems | Updated to address review log items |
| 0.4 | 14 Jun 2024 | IT/Markets Systems | Added Price Tick Section  Tagging |
| 0.5 | 13 Aug 2024 | IT/Markets Systems | Revised Version |
| 0.6 | 29 Oct 2024 | IT/Markets Systems | Revised Version |
| 0.7 | 19 Nov 2024 | IT/Markets Systems | Revised Version |
| 0.8 | 26 Nov 2024 | IT/Markets Systems | Revised Version |
| 0.9 | 22 Jan 2025 | IT/Markets Systems | Revised Version |
| 0.10 | 31 Jul 2025 | IT/Markets Systems | Revised Version |
| 0.11 | 9 Jan 2026 | IT/Markets Systems | Revised Version |
| 0.12 | 17 Jun 2026 | IT/Markets Systems | Updates for Trading Halt Resumption |
| 0.13 | 29 Jul 2026 | IT/Markets Systems | Revised Version |

## Document Cross-referenced

|  |  |  |
| --- | --- | --- |
| # | Document | Version |
| 1 | BRD\_DT\_0004 BRS Market Integrity Safeguards | 20250115 |
| 2 | BRD\_DT\_0009 BRS Series Operation | 20241015 |
| 3 | BRD\_DT\_0010 ODP – Automation of Price Limit Monitoring and Handling | 20240606 |
| 4 | BRD\_DT\_0011 Automation of Static Price Limits Market Message and Email | 20240801 |
| 5 | FS10006 – Block Trade | 20241127 |
| 6 | FS10019 – Market Messages and Circulars | 20241127 |
| 7 | FS10022 – Implied Logic | 20241127 |

## Abbreviation

|  |  |
| --- | --- |
| AHT | After Hours Trading |
| BBO | Best Bid Offer |
| COP | Calculated Opening Price |
| THM | Trading Halt Mechanism |
| TMC | Tailor Made Combination |
| RHT | Regular Hours Trading |
| VCM | Volatility Control Mechanism |

# Introduction

**#FS10004\_S0020\_00100**

In order to control the risk of rapid price fluctuation leading to market instability, and prevent orders from entering and trades from occurring at erroneous prices, following price supervision mechanisms are implemented in ODP Trading:

* Price Tick
* Price Limit
* Trading Halt Mechanism (THM)
* Volatility Control Mechanism (VCM)

# Price Tick

**#FS10004\_S0030\_00100**

Price Tick is a fundamental configuration to define the lowest and the highest allowable prices, the decimal place allowed and valid price interval (i.e. tick size) per price range allowed for a product.

## Price Tick Table

**#FS10004\_S0030\_00200**

Price tick table defines the decimal place allowed and tick size for different price ranges. It is assigned to instrument class and combo class. Incoming orders, quotes and block trades will be rejected if the price is not on a valid tick. It should be noted that price tick table cannot be changed intra-day.

Below attributes are specified per price tick table:

* Decimals: decimal place allowed; implied decimal place in price format
* Default lower limit: lowest price allowed; overridden by the price tick lower limit at instrument class/combo class level (if specified)
* Default upper limit: highest price allowed; overridden by the price tick lower limit at instrument class/combo class level (if specified)

Valid tick size is specified as form of a table, the following are specified for each table row:

* To price: upper limit of price of this price range, must be larger than the value specified in the preceding price range; effectively lower limit of order price of the succeeding price range; the last row must be blank which means the largest possible value
* Tick size: smallest price interval of this price range

Valid tick size must be specified for orders and quotes. For block trades, a separate valid tick size can be specified. If it is not specified, block trades will follow the valid tick size as orders and quotes.

**#FS10004\_S0030\_00300**

Example 1 – Uniform Price Tick Table

Decimals = 2

Default lower limit = 0

Default upper limit = 100000

Block trades follow orders? = Yes

Orders and Quotes

|  |  |
| --- | --- |
| To price | Tick size |
| <blank> | 0.05 |

Block Trades

|  |  |
| --- | --- |
| To price | Tick size |
| <not specified> | <not specified> |

For orders, quotes and block trades, the valid tick size is 0.05 from 0 to 100000

Example 2 – Variable Price Tick Table

Decimals = 4

Default lower limit = -1000

Default upper limit = 1000

Block trades follow orders? = Yes

Orders and Quotes

|  |  |
| --- | --- |
| To Price | Tick size |
| -500 | 0.001 |
| 500 | 0.0005 |
| <blank> | 0.001 |

Block Trades

|  |  |
| --- | --- |
| To Price | Tick size |
| <not specified> | <not specified> |

For orders, quotes and block trades, the valid tick size is

* 0.001 from -1000 to -500
* 0.0005 from -500 to 500
* 0.001 from 500 to 1000

Example 3 – Different Price Tick For Orders and Block Trades

Decimals = 5

Default lower limit = -1000

Default upper limit = 1000

Block trades follow orders? = No

Orders and Quotes

|  |  |
| --- | --- |
| To price | Tick size |
| -500 | 0.001 |
| 500 | 0.0005 |
| *<blank>* | 0.001 |

Block Trades

|  |  |
| --- | --- |
| To price | Tick size |
| -500 | 0.0005 |
| 500 | 0.00005 |
| *<blank>* | 0.0005 |

For orders and quotes, the valid tick size is

* 0.001 from -1000 to -500
* 0.0005 from -500 to 500
* 0.001 from 500 to 1000

For block trades, the valid tick size is

* 0.0005 from -1000 to -500
* 0.00005 from -500 to 500
* 0.0005 from 500 to 1000

## Price Tick Limits

**#FS10004\_S0030\_00400**

Price tick limits define the upper and the lower limit of allowable prices per instrument class and combo class. If not specified, default upper and lower limits defined in price tick table will be used. Incoming orders, quotes and block trades will be rejected if the price is outside the price tick limits.

The limits are configured at instrument class and combo class level with below attributes:

* Price tick lower limit: lowest price allowed for current trading day
* Price tick upper limit: highest price allowed for current trading day
* Price tick reference price: price tick reference price for current trading day
* Next day price tick lower limit: lower price allowed for next trading day
* Next day price tick upper limit: highest price allowed for next trading day
* Next day price tick reference price: price tick reference price for next trading day

**#FS10004\_S0030\_00600**

If the automated update of price tick limits is enabled (refer to Section 3.3.), the new calculated price tick limits and the reference price will be updated to next day price tick lower/upper limits and next day price tick reference price.

Next day price tick lower/upper limits and /reference price will then be rolled to price tick lower/upper limits and reference price at EOD batch job for the preparation of next trading day. That is, the new calculated price tick limits will be effective on the next trading day and remain effective throughout the day (unless there is a manual intra-day update).

**#FS10004\_S0030\_00700**

Business Operations can review, update, regenerate (re-triggering of the calculation) and export the current and next day price tick limits via Admin GUI.

If the automated update of price tick limits is not enabled, the rollover of next day price tick lower/upper limits and reference price will be disabled as well. Business Operations can manually assign the price tick lower/upper limits and the updates will be persisted to next trading day.

## Automation of Price Tick Limits Update

**#FS10004\_S0030\_00500**

Automation of price tick limits update is supported in ODP-T. If the automated update is enabled, the price tick limits will be calculated and updated by the system at a pre-defined time (refer to Section 3.3.1.) according to the defined calculation rule (refer to Section 3.3.2.).

### Triggering of Calculation

**#FS10004\_S0030\_00800**

The price tick limits will be calculated and updated on a daily basis at a pre-defined time. It is allowed to define multiple batches such that the price tick limits of different instrument classes and combo classes can be triggered at different time schedules. It should be noted that the triggering time should be scheduled after the expected arrival time of settlement price. If today settlement price is not available when calculating the price tick limits, an exception will be written to the exception report (refer to Section 3.3.3.).

### Calculation Rule

**#FS10004\_S0030\_00900**

For Futures Instrument Class

The price tick limits are calculated based on

* reference price
* unit of deviation parameter, either in percentage (%, 2 decimal places) or number of ticks
* deviation parameter

Reference price is the settlement price of spot month instrument (i.e. the futures instrument under the instrument class with the nearest future last trading date at SOD of current trading day). If current trading day is the last trading day of spot month instrument, the settlement price of spot next instrument will be used. If current trading day is a holiday for the concerned product, the settlement price of previous trading day will be used. If the reference price is not on tick, it will be rounded up to the nearest tick. If reference price is not available, an exception will be written to the exception report (refer to Section 3.3.3.) and there will be no calculated price limits for next trading day.

If the unit of deviation parameter is in percentage:

* Upper Price Limit = Reference Price + Upper Deviation Parameter (%) \* |Reference Price|
* Lower Price Limit = Reference Price – Lower Deviation Parameter (%) \* |Reference Price|

If the unit of deviation parameter is in ticks:

* Upper Price Limit = Reference Price + Deviation Parameter (number of ticks)
* Lower Price Limit = Reference Price – Deviation Parameter (number of ticks)

**#FS10004\_S0030\_01000**

For Options Instrument Class

The price tick limits are calculated as below

* Upper Price Limit = Upper Price Limit of the corresponding Futures Instrument Class
* Lower Price Limit = Default Lower Limit of the Price Tick Table

**#FS10004\_S0030\_01100**

For Combo Class

Price tick limits calculation is only supported for a combo class where all its legs are belonging to the same futures instrument class.

The price tick limits are calculated based on

* reference price of its first leg’s instrument class (refer to the reference price for futures instrument class above)
* unit of deviation parameter, either in percentage (%, 2 decimal places) or number of ticks
* deviation parameter

If the unit of deviation parameter is in percentage:

* Upper Price Limit = Reference Price of its first Leg’s Instrument Class + Upper Deviation Parameter (%) \* |Reference Price|
* Lower Price Limit = Reference Price of its first Leg’s Instrument Class – Lower Deviation Parameter (%) \* |Reference Price|

If the unit of deviation parameter is in ticks:

* Upper Price Limit = Reference Price of its first Leg’s Instrument Class + Deviation Parameter (number of ticks)
* Lower Price Limit = Reference Price of its first Leg’s Instrument Class – Deviation Parameter (number of ticks)

**#FS10004\_S0030\_01200**

For any instrument class and combo class, if the calculated value is not on tick, the value will be adjusted to the nearest tick. Upper price limit is rounded down to the nearest price tick, while lower price limit is rounded up to the nearest price tick. The calculated price limits always override the default upper and lower limits defined in price tick table no matter the calculated range is inside the default range. An exception will be written to the exception report (refer to Section 3.3.3.) if the calculated limits are outside the default range.

Example 1 – Effective tick table

For a defined tick table as below:

Decimals = 4

Default lower limit = -1000

Default upper limit = 1000

Block trades follow orders? = Yes

Orders and Quotes

|  |  |
| --- | --- |
| To Price | Tick size |
| -500 | 0.001 |
| 500 | 0.0005 |
| <blank> | 0.001 |

Block Trades

|  |  |
| --- | --- |
| To Price | Tick size |
| <not specified> | <not specified> |

If the calculated upper price limit is 3000 and the calculated lower limit is -2000, the valid tick size will be

* 0.001 from -2000 to -500
* 0.0005 from -500 to 500
* 0.001 from 500 to 3000

### Reports

**#FS10004\_S0030\_01300**

Price Tick Limits Report and Exception Report will be generated for Business Operations to review after the calculation of the price tick limits. If multiple batches are scheduled, reports will be generated after each batch and include the calculation results of that batch.

**#FS10004\_S0030\_01400**

Price Tick Limits Report contains the list of instrument classes and combo classes and their corresponding calculated upper and lower price tick limits.

**#FS10004\_S0030\_01500**

When there are exceptions or errors encountered during the calculation, the instrument classes/combo classes together with the exception/error are logged in Exception Report. The following are the list of exceptions/errors:

* Today settlement price is not yet available
* The calculated upper limit is larger than the default upper limit in the defined price tick table
* The calculated lower limit is smaller than the default lower limit in the defined price tick table
* The change of today and the previous day settlement prices is larger than the configured exception deviation
* The change of the calculated and the current upper limit is larger than the configured exception deviation
* The change of the calculated and the current lower limit is larger than the configured exception deviation

### Configuration

**#FS10004\_S0030\_01600**

For automation of price tick limits update, below attributes are configured at instrument class and combo class level:

* Auto update: whether to enable calculation and update of the price tick limits by the system
* Limit deviation unit: deviation unit either in *percentage* (%) with 2 decimal places or *number of ticks*; must be specified when auto update is enabled
* Deviation: deviation parameter (in deviation unit specified); applicable for futures instrument class and combo class only
* Exception Deviation: deviation parameter (in deviation unit specified) for exception report; must be specified when auto update is enabled
* Corresponding futures instrument class: corresponding futures instrument class; applicable for options instrument class only

For futures instrument class, “deviation” must be specified when “auto update” is enabled.

For options instrument class, “corresponding futures instrument class” must be specified when “auto update” is enabled.

For combo class, “auto update” can be enabled only if it does not belong to a TMC combo group. If “auto update” is enabled, “deviation” must be specified.

## Intra-day Price Tick Limits Update

**#FS10004\_S0030\_01700**

Business Operations are allowed to update the price tick limits via Admin UI intra-day with immediate effect.

**#FS10004\_S0030\_01701**

When the update is applied, all resting orders and quotes and unmatched block trades outside the new price tick limits will not be affected and can still be matched. For new incoming orders, quotes and block trades, the price will be checked again the new price tick limits.

# Price Limit

**#FS10004\_S0040\_00100**

Price limit is a mechanism which aims to protect exchange participants and the exchange from unintended executions due to erroneous input price. The system will monitor and reject orders, quotes and block trades if their price is outside the defined price limits. Implied orders generated for outright order books are also monitored by price limit function and price alignment with price limit for implied orders will be applied if needed.

## Price Limit Calculation

**#FS10004\_S0040\_00200**

Price limit is derived based on

* reference price
* unit of deviation parameter, either in absolute value (4 decimal places) or in percentage (%, 2 decimal places)
* upper deviation parameter
* lower deviation parameter

**#FS10004\_S0040\_00300**

If the unit of deviation parameter is in absolute value:

* Upper Price Limit = Reference Price + Upper Deviation Parameter
* Lower Price Limit = Reference Price – Lower Deviation Parameter

**#FS10004\_S0040\_00400**

If the unit of deviation parameter is in percentage:

* Upper Price Limit = Reference Price + Upper Deviation Parameter (%) \* |Reference Price|
* Lower Price Limit = Reference Price – Lower Deviation Parameter (%) \* |Reference Price|

**#FS10004\_S0040\_00500**

If the calculated value is not on a valid price tick, the value will be adjusted to the nearest tick. Upper price limit is rounded down to the nearest price tick, while lower price limit is rounded up to the nearest price tick. It should be noted that if the reference price is 0 and the unit of deviation parameter is in percentage, both upper and lower price limit will become 0 and 0 will be the only valid price within order price limit.

**#FS10004\_S0040\_00600**

Example 1 – Reference price > 0

Reference price = 98 and tick size = 1

If upper and lower deviation parameter = 4.5 (absolute value),

* Upper price limit = 98 + 4.5 = 102.5  round down to 102
* Lower price limit = 98 – 4.5 = 93.5  round up to 94

If upper deviation parameter = 2.5 and lower deviation parameter = 3.5 (absolute value),

* Upper price limit = 98 + 2.5 = 100.5  round down to 100
* Lower price limit = 98 – 3.5 = 94.5  round up to 95

If upper and lower deviation parameter = 5%,

* Upper price limit = 98 + 5%\*98 = 102.9  round down to 102
* Lower price limit = 98 - 5%\*98 = 93.1  round up to 94

If upper deviation parameter = 3% and lower deviation parameter = 4%

* Upper price limit = 98 + 3%\*98 = 100.94  round down to 100
* Lower price limit = 98 - 4%\*98 = 94.08  round up to 95

Example 2 – Reference price = 0

Reference price = 0 and tick size = 1

If upper and lower deviation parameter = 4.5 (absolute value),

* Upper price limit = 0 + 4.5 = 4.5  round down to 4
* Lower price limit = 0 – 4.5 = -4.5  round up to -4

If upper and lower deviation parameter = 5%,

* Upper price limit = 0 + 5%\*0 = 0
* Lower price limit = 0 - 5%\*0 = 0

Example 3 – Reference price < 0

Reference price = -98 and tick size = 1

If upper and lower deviation parameter = 4.5 (absolute value),

* Upper price limit = -98 + 4.5 = -93.5  round down to -94
* Lower price limit = -98 – 4.5 = -102.5  round up to -102

If upper and lower deviation parameter = 5%,

* Upper price limit = -98 + 5%\*98 = -93.1  round down to -94
* Lower price limit = -98 - 5%\*98 = -102.9  round up to -102

### Static Price Limit

**#FS10004\_S0040\_00700**

Static price limit is designed to limit price volatility during a trading state. Orders, quotes and block trades can only be submitted within a pre-defined price range during the trading state concerned.

**#FS10004\_S0040\_00800**

It is configurable that if resting orders, quotes and unmatched block trades outside the price range should be removed due to static price limit change during the trading state (“remove orders outside limit”).

**#FS10004\_S0040\_00900**

Static upper and lower price limit are calculated based on the static reference prices configured in the reference price source table. The static reference price can be

* opening price for current trading day, i.e. the first matched price of the day including the matched Calculated Opening Price (COP)
* Matching Engine last traded price in RHT session at current trading day; applicable to static price limit in AHT session only
* reference price calculated by the system (refer to Section 4.8.)

**#FS10004\_S0040\_01000**

In additional to the configured reference price, Business Operations is allowed to manually input the reference price via Admin UI.
 **#FS10004\_S0040\_01001**
If more than one reference prices are available, the reference price with the latest timestamp will be used for the static upper and lower price limit calculation. If none of the configured reference price is available, static price limit validation will not be performed until there is a new reference price.

### Dynamic Price Limit

**#FS10004\_S0040\_01100**

Dynamic price limit (aka dynamic price banding) is a facility to prevent order and quote entries at a price that deviates a lot from existing market prices. Orders and quotes cannot be input outside the floating price band. It should be noted that dynamic price limit is not applied to block trades.

**#FS10004\_S0040\_01200**

Dynamic upper and lower price limit are calculated based on the Matching Engine last traded price (exclude combo vs. combo trades, TMC trades and block trades) as the reference price. Trade cancellation has no impact on dynamic price limit reference price. When the dynamic price limit supervision starts, the immediate valid last traded price will establish the last traded reference price. It should be noted that COP from auction matching is considered as a valid last traded price. For each trade matched, the last traded price is compared with the last traded reference price. If the traded price deviates more than the configured update parameter, the last traded reference price will be adjusted to the last traded price. Dynamic upper and lower price limit will be recalculated only after an order or a quote item execution is fully processed, including any executions linked via implied trading. The last traded reference price will be reset when the dynamic price limit supervision ends.

**#FS10004\_S0040\_01300**

Business Operations is allowed to manually update the last traded reference price. The input price will be considered as the last trade reference price for dynamic price limit regardless of the configured update parameter, but it will not be disseminated externally and affect any trade statistics. If a new last traded price (which deviates from the last traded reference price more than the configured update parameter) is established later, the last traded reference price will be updated.

**#FS10004\_S0040\_01400**

If last traded reference price is not available, there will be no dynamic price limit validation until the first valid trade occurs or the last traded reference price is inputted by Business Operations.

**#FS10004\_S0040\_01500**

Example 1 – COP established from auction matching

During pre-opening, orders are matched at COP = 100.

Update parameter (%) is set to 1%.

|  |  |  |
| --- | --- | --- |
| Time | Traded Price | Reference Price for Dynamic Price Limit |
| T1 | COP = 100 |  |
| T2 | Start of dynamic price limit supervision | 100 (last traded price) |
| T3 | 101 | 100 |
| T4 | 101.1 | 101.1 (updated) |
| T5 | 102 | 101.1 |
| T6 | End of dynamic price limit supervision |  |

Example 2 – No COP established from auction matching

No order is matched during pre-opening, i.e. no COP is established.

Update parameter (%) is set to 1%.

|  |  |  |
| --- | --- | --- |
| Time | Traded Price | Reference Price for Dynamic Price Limit |
| T1 | No COP |  |
| T2 | Start of dynamic price limit supervision |  |
| T3 | 100.5 | 100.5 (first trade) |
| T4 | 101.5 | 100.5 |
| T5 | 102 | 102 (updated) |

Example 3 – Multiple dynamic price limit supervision period

During pre-opening, orders are matched at COP = 100.

Update parameter (%) is set to 1%.

|  |  |  |
| --- | --- | --- |
| Time | Traded Price | Reference Price for Dynamic Price Limit |
| T1 | COP = 100 |  |
| T2 | 100.5 |  |
| T3 | Start of dynamic price limit supervision | 100.5 (last traded price) |
| T4 | 102 | 102 (updated) |
| T5 | End of dynamic price limit supervision |  |
| T6 | 101.5 |  |
| T7 | Start of dynamic price limit supervision | 101.5 (last traded price) |

Example 4 – Manual update on last traded reference price

Update parameter (%) is set to 1%.

|  |  |  |
| --- | --- | --- |
| Time | Traded Price | Reference Price for Dynamic Price Limit |
| T1 | COP = 100 | 100 (first trade) |
| T2 | 100.5 | 100 |
| T3 | Manual update on last traded reference price = 100.5 | 100.5 (updated regardless of update parameter) |
| T4 | 101.5 | 100.5 |
| T5 | 102 | 102 (updated) |

## Price Limit Check

**#FS10004\_S0040\_01600**

During a trading state with static and/or dynamic price limit supervision attributes enabled, if an instrument class is configured with the corresponding price limit at that trading state, the following validations will apply:

|  |  |  |
| --- | --- | --- |
| Price Limit | Applicable Incoming Action | Validation |
| Static | * Order Entry * Order Amendment * Quote Entry * Quote Amendment * Block Trade | * Bid price cannot be higher than static upper price limit * Ask price cannot be lower than static lower price limit |
| Dynamic | * Order Entry * Order Amendment * Quote Entry * Quote Amendment | * Bid price cannot be higher than dynamic upper price limit * Ask price cannot be lower than dynamic lower price limit |

The incoming request will be rejected if the above validation fails.

Remark:

* For order and quote amendment, the request will be subject to price limit check even if the price is not changed. If the validation fails, the incoming amendment request will be rejected and the original order or quote will still remain in the order book.
* Each leg (except combo) in block trades will be subject to static price limit check. This validation can be disabled per leg at instrument class level. Please refer to Functional Specification “FS10006 – Block Trade” for the details.
* All orders, quotes and block trades for combo and TMC are not subject to price limit check

If “remove orders outside limit” is configured, resting orders and quotes and unmatched block trades which failed static price limit validations will be removed by the system.

Example 1 – Price limit validation

Static price limit: upper price limit = 104, lower price limit = 94

Dynamic price limit: upper price limit = 102, lower price limit = 92

|  |  |  |
| --- | --- | --- |
| Side | Price | Validation Result |
| Bid | 90 | Success |
| Bid | 93 | Success |
| Bid | 98 | Success |
| Bid | 102 | Success |
| Bid | 103 | Fail (higher than dynamic upper price limit) |
| Bid | 105 | Fail (higher than both static and dynamic upper price limit) |
| Ask | 90 | Fail (lower than both static and dynamic lower price limit) |
| Ask | 93 | Fail (lower than static lower price limit) |
| Ask | 94 | Success |
| Ask | 98 | Success |
| Ask | 103 | Success |
| Ask | 105 | Success |

## Handling of Market and Market to Limit Orders

**#FS10004\_S0040\_01700**

For a Market order with time validity Fill and Kill (FaK), the potential execution price will be checked first. It will match against orders and quotes on the opposite side within the static and dynamic price limits; any remaining quantity of the Market order, due to no more order on the opposite side or potential execution price falls outside price limit, will be cancelled.

**#FS10004\_S0040\_01800**

For a Market order with time validity Fill or Kill (FoK), the potential execution price will be checked first. If the execution price is going to be outside the static and/or dynamic price limits, the whole Market order will be rejected.

**#FS10004\_S0040\_01900**

For a Market to Limit (M2L) order, if the potential execution price is outside the static and/or dynamic price limits, the whole M2L order will be rejected.

## Implied Generation

Implied generation considers both static and dynamic price limits. Please refer to Functional Specification “FS10022 – Implied Logic” for the details.

## Intra-day Reference Price and Price Limit Changes

**#FS10004\_S0040\_02000**

Reference price, price limit configurations, upper price limit and lower price limit for static and dynamic price limit can be monitored via Admin UI. Business Operations are allowed to manually adjust the reference price, the unit of deviation parameter, the upper deviation parameter and the lower deviation parameter per individual instruments intra-day. Once the adjustment is applied, the upper and lower price limit will be recalculated. It should be noted that the change of the unit of deviation parameter, the upper deviation parameter and the lower deviation parameters will not be persisted to next trading day.

Example 1 – Intra-day deviation parameters update

Trading timetable for a concerned instrument as follows:

|  |  |
| --- | --- |
| Start Time | Trading State |
| 09:00:00 | OPEN\_DPL1 |
| 11:30:00 | OPEN\_DPL2 |
| 12:00:00 | BREAK |
| 13:00:00 | OPEN\_DPL1 |

Its upper deviation parameter is updated to 5% and 6% at 10:00:00 (during OPEN\_DPL1) and 11:45:00 (OPEN\_DPL2) respectively. The following illustrates the value deviation parameters within current trading day:

Case 1: Order price limit configuration is applied for all trading states. The upper and lower deviation parameters = 3%.

|  |  |  |  |
| --- | --- | --- | --- |
| Time | Trading State | Upper Deviation Parameter | Lower Deviation Parameter |
| 09:00:00 | OPEN\_DPL1 | 3% | 3% |
| 10:00:00  (intra-day update) | OPEN\_DPL1 | 5% | 3% |
| 11:30:00 | OPEN\_DPL2 | 5% (carry forward to next trading state) | 3% |
| 11:45:00  (intra-day update) | OPEN\_DPL2 | 6% | 3% |
| 12:00:00 | BREAK | 6% (carry forward to next trading state) | 3% |
| 13:00:00 | OPEN\_DPL1 | 6% (carry forward to next trading state) | 3% |

Case 2: Order price limit configuration is applied per trading state. The upper and lower deviation parameters for OPEN\_DPL1 = 3.5%. The upper and lower deviation parameters for OPEN\_DPL2 = 4.5%.

|  |  |  |  |
| --- | --- | --- | --- |
| Time | Trading State | Upper Deviation Parameter | Lower Deviation Parameter |
| 09:00:00 | OPEN\_DPL1 | 3.5% | 3.5% |
| 10:00:00  (intra-day update) | OPEN\_DPL1 | 5% | 3.5% |
| 11:30:00 | OPEN\_DPL2 | 4.5% (not carry forward to other trading states) | 4.5% |
| 11:45:00  (intra-day update) | OPEN\_DPL2 | 6% | 4.5% |
| 12:00:00 | BREAK | N/A | N/A |
| 13:00:00 | OPEN\_DPL1 | 5% (carry forward intra-day update for OPEN\_DPL1) | 3.5% |

## Price Limit Configuration

**#FS10004\_S0040\_02100**

Order price limit can be configured per instrument class per trading state.

**#FS10004\_S0040\_02200**

For static price limit, the following attributes should be specified:

* Price limit rule (refer to Section 4.6.1.): price limit rule for static price limit
* Reference price source: list of reference prices used for static price limit (refer to Section 4.1.1. for reference price applicable for static price limit)
* Remove orders outside limit: whether to remove orders, quotes and block trades outside price limit due to static price limit change

**#FS10004\_S0040\_02300**

For dynamic price limit, the following attributes should be specified:

* Price limit rule (refer to Section 4.6.1.): price limit rule for dynamic price limit
* Update parameter unit: deviation unit either in *absolute value* with 4 decimal places or in *percentage* (%) with 2 decimal places; must be the same as deviation unit specified in price limit rule
* Update parameter: deviation (in update parameter unit specified) of last traded price from the last traded reference price; the last traded reference price will be adjusted to last traded price if the deviation value is larger than the calculated value of last traded reference price multiplied by Update parameter; if not specified (default value = 0), every valid trade price will be updated as the last traded reference price; if specified, the value must be smaller than lower deviation and upper deviation specified in price limit rule.

Price limit validation is performed only when price limit configuration is set for the instrument and during a trading state in which the trading state itself with price limit supervision attribute enabled.

### Price Limit Rule

**#FS10004\_S0040\_02400**

Price limit rule is a table to define different price limit ranges depending the expiration of the instrument.

The attribute(s) below are specified per price limit rule table:

* Limit deviation unit: deviation unit either in *absolute value* with 4 decimal places or in *percentage* (%) with 2 decimal places

For each table row, the following are specified:

* Near expiration: expiration from when the specified price limit range is applicable.
* Far expiration: expiration up to when the specified price limit range is applicable.
* Lower deviation: deviation parameter (in deviation unit specified) for lower limit
* Upper deviation: deviation parameter (in deviation unit specified) for upper limit

Expiration is specified in term of:

* 0 = not specified
* 1 = spot (i.e. the instrument under the instrument class with the nearest future effective last trading date at SOD of current trading day)
* N = next N-1 expiration from spot (e.g. 2 = next from spot, i.e. spot-next)

When an instrument created intraday, if there exists an instrument with the same effective last trading date, the same expiration value will be assigned to the new instrument. Otherwise, the next closest expiration value in the Instrument Class will be assigned. For example, if an instrument is created with the same effective last trading date as the spot, its expiration value will be 1. If an instrument has the effective last trading date between the spot and the spot-next, its expiration value will be 2.

**#FS10004\_S0040\_02500**

Example 1 – Price limit rule for all instruments

Deviation Unit = %

|  |  |  |  |
| --- | --- | --- | --- |
| Near Expiration | Far Expiration | Lower Deviation | Upper Deviation |
| 0 | 0 | 5 | 5 |

Upper and lower deviation parameters (%) are 5% for all

Example 2 – Price limit rule for all instruments (in absolute value)

Deviation Unit = absolute value

|  |  |  |  |
| --- | --- | --- | --- |
| Near Expiration | Far Expiration | Lower Deviation | Upper Deviation |
| 0 | 0 | 10.15 | 10.15 |

Upper and lower deviation parameters (absolute value) are 10.15 for all

Example 3 – Price limit rule for spot and spot-next only

Deviation Unit = %

|  |  |  |  |
| --- | --- | --- | --- |
| Near Expiration | Far Expiration | Lower Deviation | Upper Deviation |
| 1 | 2 | 5 | 5 |

Upper and lower deviation parameters (%) are 5% for spot and spot-next only

Example 4 – Price limit rule for spot and spot-next with different price limit deviation

Deviation Unit = %

|  |  |  |  |
| --- | --- | --- | --- |
| Near Expiration | Far Expiration | Lower Deviation | Upper Deviation |
| 1 | 1 | 3 | 3 |
| 2 | 2 | 5 | 5 |

Upper and lower deviation parameters (%) are 3% for spot

Upper and lower deviation parameters (%) are 5% for spot-next

## Contingency Off Switch

**#FS10004\_S0040\_02600**

In contingency scenario, Business Operations is allowed to disable static price limit and/or dynamic price limit for all instruments via Admin UI intra-day. Once the price limit function is disabled, it cannot be re-enabled intra-day. The disabled status will also be persisted. Business Operations is required to explicitly re-enable the function via Admin UI and the function will be effective in next trading day.

## AHT Static Price Limit Reference Price Calculation

**#FS10004\_S0040\_02700**

The static price limit reference price for AHT session of eligible futures contracts can be determined and calculated by the system. The eligible futures contracts are those contracts which are valid for trading (i.e. within first trading date/time and last trading date/time). A futures group (refer to Section 4.8.1.) contains a set of calculation rules and is attached to the concerned futures instrument class. A corresponding instrument class can be specified for linking the concerned instrument class with another futures instrument class if it needs to refer to the price from that reference instrument class. For example, the standard HSI futures is the corresponding instrument class for mini HSI futures.

### Futures Group

**#FS10004\_S0040\_02800**

A futures group consists of one or more calculation rules (refer to Section 4.8.2.) with the specification of the contract month and the trading day. Each item (i.e. the combination of Contract Month option, Trading Day option and Calculation rule, as defined in the logical data model) inside the futures group can correspond to one and only one calculation rule. When Contract Month option “Both” has been configured, no further futures group item can be defined for “Spot Month” and “Non-spot Month” option.

There are 3 contract month (scope of instruments) options:

|  |  |
| --- | --- |
| Contract Month | Description |
| **Spot Month** | The eligible futures instrument under the instrument class with the nearest future last trading date/time  *\* It should be noted that the last trading time is considered for the determination of “spot month”. This is specific to AHT static price limit reference price calculation only.* |
| **Non-spot Month** | All eligible futures instruments under the instrument class except the spot month instrument |
| **Both** | All eligible futures instruments under the instrument class (i.e. Spot Month + Non-spot Month) |

There are 3 trading day options:

|  |  |
| --- | --- |
| Contract Month | Description |
| **Last Trading Day** | Current trading day is the last trading day of the spot month instrument |
| **Last Trading Day + 1** | Current trading day is the next trading day of the concerned product in which the previous spot month instrument has expired |
| **Normal** | Current trading day is other than Last Trading Day or Last Trading Day + 1 |

**#FS10004\_S0040\_02900**

Example 1 – One calculation rule for all

|  |  |  |
| --- | --- | --- |
| Contract Month | Trading Day | Calculation Rule |
| Both | Normal | Calculation Rule 1 |
| Both | Last Trading Day | Calculation Rule 1 |
| Both | Last Trading Day + 1 | Calculation Rule 1 |

Calculation Rule 1 will always be used for AHT static price limit reference price calculation.

Example 2 – Different calculation rules for Last Trading Day and Last Trading Day + 1

|  |  |  |
| --- | --- | --- |
| Contract Month | Trading Day | Calculation Rule |
| Both | Normal | Calculation Rule 1 |
| Both | Last Trading Day | Calculation Rule 2 |
| Spot month | Last Trading Day + 1 | Calculation Rule 3 |
| Non-spot month | Last Trading Day + 1 | Calculation Rule 4 |

HSI Aug 2023, last trading date/time = 30 Aug 2023 16:00

HSI Sep 2023, last trading date/time = 29 Sep 2023 16:00

HSI Oct 2023, last trading date/time = 30 Oct 2023 16:00

|  |  |  |
| --- | --- | --- |
| Trading Day | Instrument | Calculation Rule Used |
| 29 Aug 2023 | HSI Aug 2023 (spot month)  HSI Sep 2023  HSI Oct 2023 | Calculation Rule 1 |
| 30 Aug 2023 | HSI Aug 2023 (spot month)  HSI Sep 2023  HSI Oct 2023 | Calculation Rule 2 |
| 31 Aug 2023 | HSI Sep 2023 (spot month) | Calculation Rule 3 |
| HSI Oct 2023 | Calculation Rule 4 |

### Calculation Rule

**#FS10004\_S0040\_03000**

A calculation rule is a defined sequence of reference price data options to be used for deducing AHT static price limit reference price. If the first reference price data option is not available, the system will proceed to the next option and so on, until all options are exhausted.

**#FS10004\_S0040\_03100**

The reference price data options available are listed below:

|  |  |
| --- | --- |
| Reference Price Data Option | Description |
| **Last traded price** | The last traded price of the instrument in question |
| **Previous day’s settlement price** | The previous day’s settlement price of the instrument in question |
| **Reference price of the nearest earlier contract month** | The (calculated) reference price of the nearest earlier contract month instrument to the instrument in question |
| **Spot month last traded price + Previous day’s rollover spread** | The sum of spot month instrument last traded price and previous day’s settlement price spread between the instrument in question and the spot month instrument  (i.e. the spread = previous day’s settlement price of instrument in question – previous day’s settlement price of spot month instrument) |
| **Spot month last traded price + Expired spot month spread** | The sum of spot month instrument last traded price and previous day’s settlement price spread between the nearest earlier contract month instrument to the instrument in question and the recently expired spot month instrument  (i.e. the spread = previous day’s settlement price of nearest earlier contract month instrument to the instrument in question – previous day’s settlement price of recently expired spot month instrument)  This option is applicable for “Last Trading Day + 1” only |
| **Last traded price of corresponding instrument** | The last traded price of corresponding contract month instrument which is configured as the corresponding instrument class of the instrument class in question |
| **Spot month last traded price + Previous day’s rollover spread of corresponding instrument** | The sum of spot month instrument last traded price and previous day’s settlement price spread between the corresponding contract month instrument in question and the corresponding spot month instrument  (i.e. the spread = previous day’s settlement price of the corresponding contract month instrument which is configured as the corresponding instrument class of the instrument class in question in question – previous day’s settlement price of the corresponding spot month instrument) |

Remarks:

**#FS10004\_S0040\_03200**

* Last traded price refers to valid traded price excluding combo vs combo trades, TMC trades and block trades

**#FS10004\_S0040\_03300**

* As the last trading time is considered for the determination of “spot month”, spot month contract may change during trading day, i.e. on the last trading day of the spot month contract, if the last trading time of current spot month contract has passed, the spot next month contract will become the spot month contract

**#FS10004\_S0040\_03400**

* Previous day’s settlement price refers to previous trading day where the concerned product is opened for trading

**#FS10004\_S0040\_03500**

Example 1 – Previous day’s settlement price

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | 21/12  (Thu) | 22/12  (Fri) | 25/12 (Mon) | 26/12 (Tue) | 27/12 (Wed) |
| Trading Day |  |  |  |  |  |

On 22/12, the previous day’s settlement price is the settlement price on 21/12.

On 27/12, the previous day’s settlement price is the settlement price on 22/12 (previous trading day that the product is open for trading).

### Triggering of Reference Price Calculation

**#FS10004\_S0040\_03600**

Triggering of AHT static price limit reference price calculation is a background function associated with a business trading state. When this function is enabled in a business trading state, the triggering of reference price calculation will be initiated automatically by the system each time that trading state is reached. It should be noted that the next trading state should not be scheduled too close. Otherwise, the trading state could move to the next one before the completion of reference price calculation. It should also be noted that there is no restriction that the triggering of calculation must be in AHT session.

**#FS10004\_S0040\_03700**

The reference price calculation is allowed to be triggered multiple times in a trading day according to the setup of the trading timetable. If a calculation is triggered before the previous one is completed, the newly triggered calculation will be queued up and be performed after the completion of the previous one.

### Logging and Alerts

**#FS10004\_S0040\_03800**

Business Operations can search all instruments under a specified underlying or futures group and monitor the calculated AHT static price limit reference price via Admin UI. The calculated value is allowed to be overridden manually intra-day.

**#FS10004\_S0040\_03900**

For audit trail purpose, the system records the calculated reference price value and the corresponding reference price data options for each eligible instrument in application log files.

**#FS10004\_S0040\_04000**

In the event that the system fails to deduce the AHT static price limit reference price for an instrument, an alert message will be generated and reported to IT Computer Operations.

### Configuration

**#FS10004\_S0040\_04100**

A futures group is defined with one or multiple rows of the combinations of below attributes:

* Contract month: Spot, Non-Spot month or Both
* Trading day: Normal, Last Trading Day or Last Trading Day + 1
* Calculation rule: a defined calculation rule

There must be one and only one calculation rule assigned to each eligible instruments with the specification of the trading day.

A futures group can be attached to multiple futures instrument class, while a futures instrument class can only be associated with one futures group. It should be noted that attaching a futures group to a non futures instrument class is not allowed.

**#FS10004\_S0040\_04200**

A calculation rule is defined with a sequence of reference price data options. The options available are listed in Section 4.8.2.. A calculation rule can be assigned to multiple futures groups.

### Contingency Handling

**#FS10004\_S0040\_04400**

In contingency scenario, Business Operations is allowed to trigger AHT static price limit reference price calculation per market, instrument type, instrument class and instrument levels via Admin UI.

## Monitoring on Last Traded Price against Reference Price

**#FS10004\_S0040\_04500**

Monitoring the last traded price is a mechanism being introduced to alert the regulators that a last traded price has deviated from the established reference price more than the defined deviation.

**#FS10004\_S0040\_04600**

Each futures instrument class can have one alert rule being configured for monitoring purposes. Each futures instrument can have multiple alert rule items being configured.

**#FS10004\_S0040\_04700**

Each alert threshold (i.e. calculated upper value and calculated lower value respectively from an alert rule item) of each futures instrument can be triggered once for the entire trading day, despite the changes in reference price would result in a different alert threshold value. The deviation can either be defined in percentage or in absolute value, details can be found in Section 4.9.3.

**#FS10004\_S0040\_04800**

Each time when an alert threshold has been breached, a system-generated market message will be shared with the regulators via email (i.e. not intended for the Exchange Participants). Note that although this monitoring mechanism is intended to supervise the futures instruments price movements in AHT Session, there is no restriction that the triggering of an alert market message must be in AHT session. Details of the when the last traded price monitoring will be triggered can be found in Section 4.9.1.

### Triggering of Last Traded Price monitoring

**#FS10004\_S0040\_04900**
When a reference price for a futures instrument has successfully been calculated or be updated intra-day via Admin GUI, and the price is consumed then disseminated by the Matching Engine component, the monitoring of the last traded price against the confirmed calculated price will begin.

Whether the Matching Engine component will disseminate the confirmed reference price is based on the following criteria:

* When current Trading State of the Instrument Class which the futures instrument belongs allows Static Price Limit supervision, and
* When there is a valid configuration of Static Price Limit Rule for the corresponding Trading State and Instrument Class.

**#FS10004\_S0040\_05000**
The last traded price included in the monitoring coverage is identical to the definition of qualified trade statistics element for each trade type inside *FS10012 – Trade Stats and Info Dissemination* (Section 3.2). If an Exchange On-Behalf Trade Entry has been specified by Business Operations that “last traded price” element will update the trade statistics area, then last traded price of this trade will be included in the monitoring coverage.

**#FS10004\_S0040\_05100**
Until the next confirmed reference price has been disseminated by the Matching Engine component, all last traded price monitoring will be based on the prior confirmed reference price.

### Logging and Alerts

**#FS10004\_S0040\_05200**
For audit trail purpose, the system records the following in the application log file:

* Confirmed reference price, calculated upper value and calculated lower value per alert rule item per futures Instrument.
* Last traded price and the alert threshold which is breached, regardless of whether the market message will be disseminated to other components or not.

### Configuration

**#FS10004\_S0040\_05300**
A price limit alert rule is defined with the combination of below attributes:

* Monitoring scope: all or reference futures only
* Limit deviation unit: deviation unit either in *absolute value* with 4 decimal places or in *percentage* (%) with 2 decimal places

Each price limit alert rule is defined with one or multiple rows of the combinations of below attributes:

* Upper limit: upper limit (in limit deviation unit specified)
* Lower limit: lower limit (in limit deviation unit specified)

# Trading Halt Mechanism

**#FS10004\_S0050\_00100**

Trading Halt Mechanism (THM) is a mechanism to avoid potential extreme options price movement during AHT session. When the BBO (best bid offer) of a reference futures reaches its static price limit, trading of the corresponding target instruments will be halted. The trading of halted instruments will be resumed when the resumption criteria is met.

## Monitoring of Reference Futures

**#FS10004\_S0050\_00200**

Trading halt mechanism is configured under static price limit of the reference futures instrument class.

**#FS10004\_S0050\_00300**

When both static price limit and THM are enabled, the BBO of the reference month futures will be monitored. The reference futures is the eligible futures instrument (i.e. valid for trading) under the instrument class with the nearest future last trading date/time. It should be noted that the reference futures is determined at the start of every trading state where THM is applicable, thus it may change during the trading day. If no single reference futures is determined, THM will not be active.

**#FS10004\_S0050\_00400**

THM will be triggered if one of the following criteria is fulfilled:

* Both best bid price (including orders, quotes and implied orders) and static upper price limit exist, and best bid price is the same as the static upper price limit
* Both best ask price (including orders, quotes and implied orders) and static lower price limit exist, and best ask price is the same as the static lower price limit

If static price limit is updated intra-day, any resting order or quote fulfilling one of the above criteria will trigger THM.

**#FS10004\_S0050\_00500**

It should be noted that the traded price of the reference futures is not one of the triggering criteria, i.e. THM will not be triggered if there is a trade executed at the static price limit.

**#FS10004\_S0050\_00600**

Example 1 – Change of reference futures during the trading day

Consider the following:

* HSI Aug 2023, last trading date/time = 30 Aug 2023 16:00
* HSI Sep 2023, last trading date/time = 29 Sep 2023 16:00

On 30 Aug 2023, HSI Aug 2023 is the reference futures at the start of trading day. When entering into AHT session (after 16:00), the reference becomes HSI Sep 2023.

## Target Instruments List

**#FS10004\_S0050\_00600**

The target instruments list allows Business Operations to specify the list of instrument classes subjected to trading halt when THM is triggered.

**#FS10004\_S0050\_00700**

The instrument classes in the list can be belonging to the same or different market of the reference futures (e.g. the reference futures is HSI futures; the target instruments list are HSI options, HSI weekly options and mini-HSI options).

**#FS10004\_S0050\_00800**

It should be noted that the target instrument class can belong to different Matching Engine partition of the reference futures. However, there may be a time delay after THM is triggered and the target instrument class is effectively halted, i.e. it is not an atomic operation. In the meantime, the system still accepts orders and matches trades for the target instruments.

## Triggering of Trading Halt

**#FS10004\_S0050\_00900**

When THM is triggered, all of the target instruments will be marked as halted. It should be noted that a combo or TMC will be considered as halted if one of its legs is marked as halted.

When an instrument, a combo or TMC is halted,

* incoming orders, quotes and block trades will be rejected
* TMC creation request, in which the halted instrument is one of the legs, will be rejected
* on-behalf enter trades will be rejected
* resting orders and quotes and unmatched block trades will not be cancelled but cannot be matched

Under halted condition, the following can still be performed by exchange participants:

* amend resting orders (which would not result in loss of time priority)
* cancel resting orders
* cancel resting orders and quotes using mass cancel
* cancel or decline unmatched block trades

## Cooling-off Period

**#FS10004\_S0050\_01300**

After the target instruments are halted, a cooling-off period for a configured time duration (N seconds, where N ≥ 60) will commence. Upon the end of cooling-off period, the following conditions will be checked to determine if the cooling-off period needs to be extended:

|  |  |
| --- | --- |
| Condition | Extension of Cooling-off Period |
| THM condition currently holds | Cooling-off period will be extended by N seconds |
| THM condition is met again (since last check), but is no longer present | Cooling-off period will be extended to N second from the most recent time that THM condition is lift |
| THM condition is not met (since last check) | Cooling-off period will not be extended, i.e. will be ended |

**#FS10004\_S0050\_01400**

It should be noted that if trading halt is still in effect while entering a THM enabled trading state, the cooling-off period will also commence.

Example 1 – THM condition is lift after 60s

Cooling-off period is set to 600s

|  |  |  |
| --- | --- | --- |
| Time | THM condition | Cooling-off Period |
| 20:00:00 | THM condition is met  (Best bid price is the same as the static upper price limit) | Cooling-off period commences |
| 20:01:00 | THM condition is lift  (Best bid price is lower than the static upper price limit) |  |
| 20:10:00 |  | Cooling-off period extends to 20:01:00 + 600s |
| 20:11:00 |  | Cooling-off period ends |

Example 2 – THM condition is lift after 1000s

Cooling-off period is set to 600s

|  |  |  |
| --- | --- | --- |
| Time | THM condition | Cooling-off Period |
| 20:00:00 | THM condition is met  (Best bid price is the same as the static upper price limit) | Cooling-off period commences |
| 20:10:00 |  | Cooling-off period extends by 600s |
| 20:15:00 | THM condition is lift  (Best bid price is lower than the static upper price limit) |  |
| 20:20:00 |  | Cooling-off period extends to 20:15:00 + 600s |
| 20:25:00 |  | Cooling-off period ends |

Example 3 – THM condition is lift after 60s and is met again

Cooling-off period is set to 600s

|  |  |  |
| --- | --- | --- |
| Time | THM condition | Cooling-off Period |
| 20:00:00 | THM condition is met  (Best bid price is the same as the static upper price limit) | Cooling-off period commences |
| 20:01:00 | THM condition is lift  (Best bid price is lower than the static upper price limit) |  |
| 20:02:00 | THM condition is met again  (Best bid price is the same as the static upper price limit) |  |
| 20:10:00 |  | Cooling-off period extends by 600s |
| 20:15:00 | THM condition is lift  (Best bid price is lower than the static upper price limit) |  |
| 20:20:00 |  | Cooling-off period extends to 20:15:00 + 600s |
| 20:25:00 |  | Cooling-off period ends |

## Resumption of Trading Halt

**#FS10004\_S0050\_01500**

After the cooling-off period, if the resumption criteria are met, the halted target instruments will be resumed immediately by the system. In case, THM condition is met again before the resumption, the cooling-off period will recommence.

The resumption criteria are:

* there is at least one trade matched since the most recent THM condition is lift, and
* the Matching Engine last traded price is lower or equal to the upper resumption level, and
* the Matching Engine last traded price is higher or equal to the lower resumption level

where:

* Upper Resumption Level = Static Price Limit Reference Price + Upper Resumption Level Parameter (%) \* |Static Price Limit Reference Price|
* Lower Resumption Level = Static Price Limit Reference Price – Lower Resumption Level Parameter (%) \* |Static Price Limit Reference Price|

**#FS10004\_S0050\_01600**

The upper and lower resumption level parameters are configured in percentage. It is assumed the same unit (i.e. percentage) is used for static price limit calculation. If static price limit is not configured as percentage-based or the resumption level parameters are not configured, the cooling-off and resumption of trading halt will be disabled.

Example 1 – Trading Resumption when Cooling-off Period ends

Cooling-off period is set to 600s

Upper/Lower Resumption Level is configured as 4%

Static Reference Price = 10000

|  |  |  |
| --- | --- | --- |
| Time | Description | Last Traded Price |
| 20:00:00 | THM is triggered  Cooling-off period commences |  |
| 20:02:00 | THM condition is lift |  |
| 20:10:00 | Cooling-off period extends |  |
| 20:10:30 | A traded is matched at 10300 | 10300 (20:10:30) |
| 20:12:00 | Cooling-off period ends  Trading is resumed | 10300 (20:10:30) |

Example 2 – Trading Resumption after Cooling-off Period

Cooling-off period is set to 600s

Upper/Lower Resumption Level is configured as 4%

Static Reference Price = 10000

|  |  |  |
| --- | --- | --- |
| Time | Description | Last Traded Price |
| 20:00:00 | THM is triggered  Cooling-off period commences |  |
| 20:02:00 | THM condition is lift |  |
| 20:03:00 | A traded is matched at 10300 | 10300 (20:03:00) |
| 20:04:00 | THM condition is met again | 10300 (20:03:00) |
| 20:05:00 | THM condition is lift | 10300 (20:03:00) |
| 20:10:00 | Cooling-off period extends | 10300 (20:03:00) |
| 20:15:00 | Cooling-off period ends  (Trading is not resumed as the last traded timestamp is earlier than the time that the recent THM condition is lift) | 10300 (20:03:00) |
| 20:15:30 | A traded is matched at 10350  Trading is resumed | 10350 (20:15:30) |

Example 3 – Cooling-off Period recommences before Trading Resumption

Cooling-off period is set to 600s

Upper/Lower Resumption Level is configured as 4%

Static Reference Price = 10000

|  |  |  |
| --- | --- | --- |
| Time | Description | Last Traded Price |
| 20:00:00 | THM is triggered  Cooling-off period commences |  |
| 20:02:00 | THM condition is lift |  |
| 20:10:00 | Cooling-off period extends |  |
| 20:12:00 | Cooling-off period ends |  |
| 20:12:30 | THM condition is met again  Cooling-off period commences |  |
| 20:22:30 | Cooling-off period extends |  |

## No Resumption Period

**#FS10004\_S0050\_01700**

No resumption period is a configured time window (in second) prior to the end of current trading state. The start time of the no resumption period is determined at the start of current trading state and will not be adjusted even the start time of the next trading date is changed later. If the next trading state is set as manual mode, its original planned start time will be used to derive the start time of the no resumption period.

**#FS10004\_S0050\_01800**

If THM is triggered during the no resumption period, cooling-off period will not commence and there will not be resumption of trading halt before the end of current trading state. If trading halt is in effect when entering this period, the cooling-off period will stop (if during cooling-off) and trading will not be resumed during this period.

## THM Notification

**#FS10004\_S0050\_01900**

When THM is triggered, a notification message will be published. The message contains the following information:

* instrument concerned
* target instrument classes
* trading halt trigger time
* trading halt trigger order side
* static price limit reference price
* static price limit lower deviation
* static price limit upper deviation
* static price limit deviation unit
* no resumption period start time
* no resumption period duration

**#FS10004\_S0050\_02000**

When the trading of the halted instruments is resumed, a notification message will be published. The message includes the following information:

* instrument concerned
* target instrument classes
* resumption time

**#FS10004\_S0050\_02100**

When entering no resumption period while trading halt is in effect, a notification message with the following information will be published:

* instrument concerned
* target instrument classes
* no resumption period start time
* no resumption period duration

Please refer to Functional Specification “FS10019 – Market Messages and Circulars” for the notification message templates.

**#FS10004\_S0050\_02200**

It should be noted that no notification message will be published for the following events:

* cooling-off period commences
* cooling-off period extends
* cooling-off period ends
* cooling-off period recommences
* THM condition is met again while trading halt is still in effect

## Exceptional Handling and Manual Halt

**#FS10004\_S0050\_02300**

In the scenarios of manual update of trading state while trading halt is in effect, the target instruments will remain as halted. The cooling-off period will recommence when entering a THM enabled trading state.

**#FS10004\_S0050\_01000**

Trading halt is a non-persistent trading condition. All halted instruments are resumed from trading halt at the start of next trading day. In an exceptional scenario where system intra-day restart is required, all halted instruments will be lifted after restart.

**#FS10004\_S0050\_01100**

Business Operations is allowed to manually halt an instrument or resume an halted instrument (not applicable for combo or TMC where its status is deduced from its legs automatically as mentioned in Section 5.3.) via Admin UI.

**#FS10004\_S0050\_02400**

Cooling-off and trading resumption will not be triggered by manual halt.

**#FS10004\_S0050\_02500**

It should be noted that when trading halt is triggered or resumed, all the instruments under the instrument classes in the target instrument list will be affected even the instrument was manually halted or resumed by Business Operations.

Example 1 – Manual Halt

Instrument A and B are under the same targe instrument class C

|  |  |  |
| --- | --- | --- |
| Time | Description | Is Halted? |
| 20:00:00 | Trading halt is triggered (target Instrument Class: C)  Cooling-off commences | Instrument A = Yes  Instrument B = Yes |
| 20:05:00 | Business Operations manually unhalt Instrument A | Instrument A = No  Instrument B = Yes |
| 20:12:00 | Trading is resumed (target Instrument Class: C) | Instrument A = No  Instrument B = No |
| 21:00:00 | Business Operations manually halt Instrument A | Instrument A = Yes  Instrument B = No |
| 21:05:00 | Business Operations manually unhalt Instrument A | Instrument A = No  Instrument B = No |
| 21:10:00 | Trading halt is triggered (target Instrument Class: C)  Cooling-off commences | Instrument A = Yes  Instrument B = Yes |
| 21:20:00 | Trading is resumed (target Instrument Class: C) | Instrument A = No  Instrument B = No |

## THM Configuration

**#FS10004\_S0050\_01200**

THM can be configured per reference futures instrument class per trading state with below attributes specified:

* Target instrument lists: list of instrument classes subjected to trading halt; THM will be disabled if no instrument class is specified in the list
* Cooling-off interval (in second): duration of the cooling-off period for the resumption in seconds
* No resumption period (in second): duration of no resumption period in seconds prior to the end of trading state
* Lower resumption level: deviation parameter (in percentage) for lower resumption level; applicable only if static price limit deviation unit is configured as percentage; trading resumption will be disabled if it is not configured
* Upper resumption level: deviation parameter (in percentage) for upper resumption level; applicable only if static price limit deviation unit is configured as percentage; trading resumption will be disabled if it is not configured

THM is enabled only when static price limit configuration is set for the instrument and during a trading state in which the trading state itself with static price limit supervision attribute enabled.

# Volatility Control Mechanism

**#FS10004\_S0060\_00100**

Volatility Control Mechanism (VCM) is designed to protect the market from disorderliness caused by extreme price volatility. If the potential matched price deviates more than a pre-defined percentage within a specific time frame, it will trigger a cooling-off period in which trading is allowed at or within a fixed price band. After the cooling-off period, trading will resume to normal with VCM monitoring. VCM is allowed to be triggered multiple times per a trading session.

## VCM Price Limit Calculation

**#FS10004\_S0060\_00200**

VCM price limit is derived based on

* VCM reference price
* unit of deviation parameter, either in absolute value (4 decimal places) or in percentage (%, 2 decimal places)
* upper deviation parameter
* lower deviation parameter

**#FS10004\_S0060\_00300**

If the unit of deviation parameter is in absolute value:

* VCM Upper Price Limit = VCM Reference Price + Upper Deviation Parameter
* VCM Lower Price Limit = VCM Reference Price – Lower Deviation Parameter

**#FS10004\_S0060\_00400**

If the unit of deviation parameter is in percentage:

* VCM Upper Price Limit = VCM Reference Price + Upper Deviation Parameter (%) \* |VCM Reference Price|
* VCM Lower Price Limit = VCM Reference Price – Lower Deviation Parameter (%) \* |VCM Reference Price|

**#FS10004\_S0060\_00500**

If the calculated value is not on a valid price tick, VCM upper price limit will be rounded down to the nearest price tick while VCM lower price limit will be rounded up to the nearest price tick. It should be noted that if VCM reference price is 0, both VCM upper and lower price limit will be 0.

## Determination of VCM Reference Price

**#FS10004\_S0060\_00600**

VCM reference price is the Matching Engine last traded price established at the configured delay time (in second) ago.

**#FS10004\_S0060\_00700**

The last traded price is an execution price from order book matching. Traded price from combo vs combo, TMC trades and block trades are not counted. Trade cancellation has no impact on VCM reference price.

**#FS10004\_S0060\_00800**

If the delay time is configured as 0, the system will use every real time last traded price (exclude combo vs. combo trades, TMC trades and block trades) as VCM reference price. If the configured delay time is larger than 0, VCM reference price will be updated at the end of each one second interval. If more than one last traded price established during an interval, the last one will be used for VCM reference price update.

**#FS10004\_S0060\_00900**

When VCM monitoring starts, the first VCM reference price will be taken from a valid last traded price in the interval of the configured delay time ago.

**#FS10004\_S0060\_01000**

If there is no valid trades executed in that interval, the system will scan backward to the previous interval and so on until the start of the current trading session. COP from auction matching is considered as a valid traded price. If there is still no valid traded price, the system will scan forward until the interval right before the start of VCM monitoring.

**#FS10004\_S0060\_01100**

In case there is no valid traded price available, VCM monitoring will be disabled until there exists a valid traded price. This new valid traded price will then be used as VCM reference price and VCM monitoring will be effective immediately.

**#FS10004\_S0060\_01200**

It should be noted that for a trading day with multiple trading sessions, VCM reference price of previous session will not be carried forward to next session. In the scenarios of site failover, system restart or system fallback, VCM reference price will be reset.

**#FS10004\_S0060\_01300**

Business Operations can manually update VCM reference price via Admin UI. The manual update will be immediately effective irrelevant to any value set for the configured delay time. Any traded price established before the effective of the manual update will not override the manual update, while the traded price established after the manual update will become effective and replace the manual update price according to the configured delay time.

**#FS10004\_S0060\_01400**

Example 1 – More than one trade in the same second

Delay time (in second) is set to 300.

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
| Time | Traded Price | Delayed Last Traded Price | Manual Update | VCM Reference Price |
| 09:24:59 | 100 |  |  |  |
| Start of VCM Monitoring (09:30:00) | | | | |
| 09:30:00 |  | 100 (LTP at 09:24:59) |  | 100 |
| 10:00:05.12 | 100 | 100 |  | 100 |
| 10:00:05.99 | 102 | 100 |  | 100 |
| 10:00:06.00 | 103 | 100 |  | 100 |
| 10:00:06.01 | 105 | 100 |  | 100 |
| 10:05:06 |  | 102 (LTP at 10:00:05.99) |  | 102 |
| 10:05:07 |  | 105 (LTP at 10:00:06.01) |  | 105 |

Example 2 – No trade in delay time when VCM monitoring starts

Delay time (in second) is set to 300.

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
| Time | Traded Price | Delayed Last Traded Price | Manual Update | VCM Reference Price |
| 09:24:00 | 100 |  |  |  |
| 09:26:59 | 101 |  |  |  |
| 09:28:59.00 | 102 |  |  |  |
| 09:28:59.01 | 103 |  |  |  |
| Start of VCM Monitoring (09:30:00) | | | | |
| 09:30:00 |  | 100 (LTP at 09:24:00) |  | 100 |
| 09:30:05 | 105 | 100 |  | 100 |
| 09:32:00 |  | 101 (LTP at 09:26:59) |  | 101 |
| 09:34:00 |  | 103 (LTP at 09:28:59.01) |  | 103 |
| 09:35:06 |  | 105 (LTP at 09:30:05) |  | 105 |
| 09:36:00 | 106 | 105 |  | 105 |

Example 3 – No trade in or before delay time, except trades at auction matching

Delay time (in second) is set to 300.

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
| Time | Traded Price | Delayed Last Traded Price | Manual Update | VCM Reference Price |
| 09:14:00 | COP = 100 |  |  |  |
| 09:26:59 | 101 |  |  |  |
| Start of VCM Monitoring (09:30:00) | | | | |
| 09:30:00 |  | 100 (COP at 09:14:00) |  | 100 |
| 09:30:05 | 105 | 100 |  | 100 |
| 09:32:00 |  | 101 (LTP at 09:26:59) |  | 101 |
| 09:35:06 |  | 105 (LTP at 09:30:05) |  | 105 |

Example 4 – No trade in or before delay time

Delay time (in second) is set to 300.

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
| Time | Traded Price | Delayed Last Traded Price | Manual Update | VCM Reference Price |
| 09:28:58 | 100 |  |  |  |
| 09:28:59.00 | 101 |  |  |  |
| 09:28:59.01 | 102 |  |  |  |
| Start of VCM Monitoring (09:30:00) | | | | |
| 09:30:00 |  | 100 (LTP at 09:28:58) |  | 100 |
| 09:30:05 | 105 | 100 |  | 100 |
| 09:34:00 |  | 102 (LTP at 09:28:59.01) |  | 102 |
| 09:35:06 |  | 105 (LTP at 09:30:05) |  | 105 |

Example 5 – No trade from the start of current trading session

Delay time (in second) is set to 300.

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
| Time | Traded Price | Delayed Last Traded Price | Manual Update | VCM Reference Price |
| Start of VCM Monitoring (09:30:00) | | | | |
| 09:30:00 |  | N/A |  | N/A |
| 09:30:59.00 | 105 | 105 (first trade at 09:30:59) |  | 105 |
| 09:30:59.01 | 106 | 105 |  | 105 |
| 09:36:00 |  | 106 (LTP at 09:30:59.01) |  | 106 |

Example 6 – Manual update VCM reference price

Delay time (in second) is set to 300.

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
| Time | Traded Price | Delayed Last Traded Price | Manual Update | VCM Reference Price |
| 09:24:59 | 100 |  |  |  |
| Start of VCM Monitoring (09:30:00) | | | | |
| 09:30:00 |  | 100 (LTP at 09:24:59) |  | 100 |
| 09:32:59.10 | 102 | 100 |  | 100 |
| 09:32:59.20 |  | 100 | 105 (update at 09:32:59.20) | 105 |
| 09:38:00 |  | 102 (LTP at 09:32:59.10) | 105 | 105 (no update as manual update timestamp is later then delayed last traded price timestamp |
| 09:42:59.20 |  | 102 | 108 (update at 09:42:59.20) | 108 |
| 09:42:59.30 | 103 | 102 | 108 | 108 |
| 09:48:00 |  | 103 (LTP at 09:32:59.30) | 105 | 103 (update to delayed last traded price as its timestamp is later then manual update timestamp) |

## VCM Monitoring and Cooling-off Period

**#FS10004\_S0060\_01500**

VCM monitoring is only applicable to orders and quotes during continuous matching trading state (i.e. trading state type is OPEN) with VCM monitoring attribute enabled. The start and end offset of monitoring period within the trading state is allowed to be configured in the trading timetable.

**#FS10004\_S0060\_01600**

For example, the start offset can be 15 minutes in morning and afternoon trading session such that no monitoring is applied at the first 15 minutes to allow free price discovery after a trading break. The end offset can 20 minutes in afternoon session in order to ensure that there is an uninterrupted trading period (not interfered by a cooling-off period) during the last 15 minutes.

**#FS10004\_S0060\_01700**

During the VCM monitoring period, the potential trade price of a VCM applicable instrument will be continuously checked against the dynamic VCM price limit. If there is potential execution with price outside VCM price limit, VCM will be triggered. The instrument will enter into a cooling-off period for a configured time duration (in second). For example, if the cooling-off period starts at 11:48:22.30 and the duration is 300 seconds, the cooling-off period will be ended after 11:53:22.99.

**#FS10004\_S0060\_01800**

When VCM cooling-off period is triggered, the order and quote handling is as following:

|  |  |
| --- | --- |
| Triggered By | Handling |
| Incoming order or quote  (matches with an existing order or quote in order book) | * The incoming order or quote can be partially executed to the extent that the trade prices are at or within limit. The remaining part of the order or quote with potential trade price exceeds the limit will not be executed and will be cancelled * Existing bid orders and quotes with price higher than VCM upper price limit will be cancelled * Existing ask orders and quotes with price lower than VCM lower price limit will be cancelled |

**#FS10004\_S0060\_01900**

Below is the validation of price against VCM price limit during cooling-off period:

|  |  |
| --- | --- |
| Side | Validation |
| Bid | Price cannot be higher than VCM upper price limit |
| Ask | Price cannot be lower than VCM lower price limit |

**#FS10004\_S0060\_02000**

It should be noted that for an incoming order with time validity Fill or Kill (FoK), the potential execution price will be checked first. If the execution price is going to be outside VCM price limit, the whole order will be rejected and VCM will be triggered.

**#FS10004\_S0060\_02100**

During the cooling-off period, VCM reference price will not be updated. Trading will continue within the fixed VCM price limit. Any incoming orders and quotes violating VCM price limit will be rejected, while the incoming orders and quotes satisfying VCM price limit will still be accepted to allow building liquidity. Specifically, for a FaK Market order, it will match against resting orders within VCM price limit, any remaining quantity will be cancelled. For a FoK Market order or a Market to Limit (M2L) order, if the execution price is going to be outside VCM limit, the whole order will be rejected.

**#FS10004\_S0060\_02200**

After the cooling-off period, trading will resume to normal. It should be noted that if according to the trading timetable configuration, transition to the next trading state takes place before the end of a cooling-off period, the remaining time of the cooling-off period will not be brought forward. For example, if the cooling-off period is expected to be ended at 12:01 while the trading state moves into lunch break at 12:00, the cooling-off period will be ended at 12:00.

**#FS10004\_S0060\_02210**

It should also be noted that during the cooling-off period, Business Operations can manually end the cooling-off period of an instrument immediately via Admin GUI.

## Post VCM Cooling-off Period

**#FS10004\_S0060\_02300**

Business Operations is allowed to configure the number of VCM cooling-off period can be triggered per instrument per trading session. If the number of triggers reaches the limit, VCM monitoring will be stopped after the cooling-off period.

**#FS10004\_S0060\_02400**

Assume VCM is allowed to be triggered again, if there is valid trade executed during the cooling-off period, VCM monitoring will continue after the cooling-off period. VCM reference price will be the last traded price at the configured delay time ago and VCM price limit will then be recalculated.

**#FS10004\_S0060\_02500**

In case there is no trade concluded, VCM monitoring will be disabled until there is a new valid trade (and the traded price will become VCM reference price) or a new VCM reference price is updated by Business Operations via Admin UI.

**#FS10004\_S0060\_02600**

While the default behavior under the case where no valid trades have been concluded during VCM cooling-off period would disable VCM monitoring, Business Operations has the flexibility to configure whether VCM should be automatically re-enabled after the VCM cooling-off period (“automatic VCM re-enable”).

**#FS10004\_S0060\_02700**

Example 1 – VCM reference price after cooling-off period, trades executed during cooling-off period

VCM upper and lower deviation parameter (%) is 10%

Delay time (in second) is set to 300.

Cooling-off period (in second) is set to 300.

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
| Time | Traded Price | Delayed Last Traded Price | Manual Update | VCM Reference Price |
| 09:24:59 | 100 |  |  |  |
| Start of VCM Monitoring (09:30:00) | | | | |
| 09:30:00 |  | 100 (LTP at 09:24:59) |  | 100 |
| 09:59:00 | 102 | 100 |  | 100 |
| 10:00:00 | (potential trade at 112) | 100 |  | 100 |
| Start of cooling-off period (10:00:00) | | | | |
| 10:00:00 |  | 100 |  | 100 |
| 10:00:59 | 101 | 100 |  | 100 |
| 10:02:00 | 102 | 100 |  | 100 |
| 10:04:00 |  | 100 (no update during cooling-off period) |  | 100 |
| End of cooling-off period (10:05:01) | | | | |
| 10:05:00 |  | 102 (LTP at 09:59:00) |  | 102 |
| 10:06:00 |  | 101 (LTP at 10:00:59) |  | 101 |

Example 2 – VCM reference price after cooling-off period, no trade during cooling-off period

VCM upper and lower deviation parameter (%) is 10%

Delay time (in second) is set to 300.

Cooling-off period (in second) is set to 300.

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
| Time | Traded Price | Delayed Last Traded Price | Manual Update | VCM Reference Price |
| 09:24:59 | 100 |  |  |  |
| Start of VCM Monitoring (09:30:00) | | | | |
| 09:30:00 |  | 100 (LTP at 09:24:59) |  | 100 |
| 09:59:00 | 102 | 100 |  | 100 |
| 10:00:00 | (potential trade at 112) | 100 |  | 100 |
| Start of cooling-off period (10:00:00) | | | | |
| 10:00:00 |  | 100 |  | 100 |
| End of cooling-off period (10:05:01) | | | | |
| 10:05:00 |  | N/A |  | N/A |
| 10:05:05 | 105 | 105 (first trade at 10:05:05) |  | 105 |

Example 3 – VCM reference price after cooling-off period, no trade during cooling-off period

VCM upper and lower deviation parameter (%) is 10%

Delay time (in second) is set to 300.

Cooling-off period (in second) is set to 300.

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
| Time | Traded Price | Delayed Last Traded Price | Manual Update | VCM Reference Price |
| 09:24:59 | 100 |  |  |  |
| Start of VCM Monitoring (09:30:00) | | | | |
| 09:30:00 |  | 100 (LTP at 09:24:59) |  | 100 |
| 09:59:00 | 102 | 100 |  | 100 |
| 10:00:00 | (potential trade at 112) | 100 |  | 100 |
| Start of cooling-off period (10:00:00) | | | | |
| 10:00:00 |  | 100 |  | 100 |
| End of cooling-off period (10:05:01) | | | | |
| 10:05:00 |  | N/A |  | N/A |
| 10:05:05 |  | N/A | 105 | 105 |

## Implied Generation

Implied generation takes VCM into consideration. Please refer to Functional Specification “FS10022 – Implied Logic” for the details.

## VCM Notification

**#FS10004\_S0060\_02800**

When VCM is triggered, a notification message will be published. The message contains the following information:

* instrument concerned
* VCM trigger time, i.e. start time of the cooling-off period
* VCM reference price
* VCM upper price limit
* VCM lower price limit
* end time of the cooling-off period

**#FS10004\_S0060\_02900**

When VCM cooling-off period is ended, a notification message will be published. The message includes the following information:

* instrument concerned
* end time of the cooling-off period

**#FS10004\_S0060\_03000**

When VCM reference price or price limit deviation parameters is updated manually by Business Operation during the cooling-off period, a notification message with the following information will be published:

* instrument concerned
* VCM trigger time, i.e. start time of the cooling-off period
* updated VCM reference price
* updated VCM upper price limit
* updated VCM lower price limit
* end time of the cooling-off period

Please refer to Functional Specification “FS10019 – Market Messages and Circulars” for the notification message templates.

## Intra-day Reference Price and Price Limit Changes

**#FS10004\_S0060\_03100**

VCM reference price and price limit can be monitored via Admin UI. Business Operations is allowed to manually adjust the reference price, the unit of deviation parameter, the upper deviation parameter and the lower deviation parameter per individual instrument intra-day. The manual update will be immediately effective.

**#FS10004\_S0060\_03200**

If the update is applied during VCM monitoring or cooling period, the upper and lower price limit will be recalculated. Any existing bid orders and quotes with price higher than VCM upper price limit and ask orders and quotes with price lower than VCM lower price limit will be removed. But the duration of VCM cooling-off period will not be extended. It should be noted that the change of the unit of deviation parameter, the upper deviation parameter and the lower deviation parameter will not be persisted to next trading day.

## VCM Configuration

**#FS10004\_S0060\_03300**

VCM can be configured per instrument class per trading state with below attributes specified:

* Price limit rule (refer to Section 4.6.1.): price limit rule for VCM price limit
* Delay time (in second): seconds back the last traded price is taken from as VCM reference price
* Cooling-off interval (in second): duration of the cooling-off period in seconds
* Allowed trigger times: number of VCM can be triggered per instrument per trading session; 0 means no limitation on the number of triggers
* Automatic VCM re-enable: re-enable VCM monitoring regardless of any trade executed during the cooling-off period

VCM is supervised only when VCM configuration is set for the instrument and during the trading state with VCM supervision attribute enabled.

## Contingency Off Switch

**#FS10004\_S0060\_03400**

In contingency scenario, Business Operations is allowed to disable VCM function for all instruments via Admin UI intra-day. Once VCM function is disabled, it cannot be re-enabled intra-day. The disabled status will also be persisted. Business Operations is required to explicitly re-enable VCM via Admin UI and the function will be effectively in next trading day.

For those instruments under the cooling-off period, the cooling-off period will be ended once VCM function is disabled.
