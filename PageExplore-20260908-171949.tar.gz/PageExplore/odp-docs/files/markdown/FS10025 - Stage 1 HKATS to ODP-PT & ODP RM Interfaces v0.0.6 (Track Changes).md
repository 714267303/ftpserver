TITLE:

**FUNCTIONAL SPECIFICATION**

***ODP Stage 1***

***HKATS to ODP-PT & ODP RM Interfaces***

**Version** **0.0.6**

AUTHOR: *IT-Markets Systems* DATE: 10 Jun 2026

LAST REVIEW: DATE: 24 Jun 2026

**CONTENTS**

[1 Document Control 4](#_Toc233104759)

[1.1 Change History 4](#_Toc233104760)

[1.2 Document Cross-referenced 4](#_Toc233104761)

[1.3 Abbreviation 4](#_Toc233104762)

[1.4 Distribution List 5](#_Toc233104763)

[2 Introduction 6](#_Toc233104764)

[3 Scope 6](#_Toc233104765)

[4 Configuration Requirements 7](#_Toc233104766)

[5 Supported Feature 8](#_Toc233104767)

[5.1 Original Trade 8](#_Toc233104768)

[5.1.1 Identification 8](#_Toc233104769)

[5.1.2 Output 9](#_Toc233104770)

[5.1.3 Conversion Logic 9](#_Toc233104771)

[5.2 Block Trade 19](#_Toc233104772)

[5.2.1 Identification 19](#_Toc233104773)

[5.2.2 Output 19](#_Toc233104774)

[5.2.3 Conversion Logic 19](#_Toc233104775)

[5.3 Trade Cancellation 28](#_Toc233104776)

[5.3.1 Identification 28](#_Toc233104777)

[5.3.2 Output 28](#_Toc233104778)

[5.3.3 Conversion Logic 28](#_Toc233104779)

[5.4 Trade Adjustment 31](#_Toc233104780)

[5.4.1 Identification 31](#_Toc233104781)

[5.4.2 Output 32](#_Toc233104782)

[5.4.3 Conversion Logic 32](#_Toc233104783)

[5.5 Intraday New Instrument 36](#_Toc233104784)

[5.5.1 Identification 36](#_Toc233104785)

[5.5.2 Output 36](#_Toc233104786)

[5.5.3 Conversion Logic 36](#_Toc233104787)

[5.6 Capital Adjustment 44](#_Toc233104792)

[5.6.1 Identification 44](#_Toc233104793)

[5.6.2 Output 44](#_Toc233104794)

[5.6.3 Conversion Logic 45](#_Toc233104795)

[5.7 Start of Day Reference Data 51](#_Toc233104796)

[5.7.1 Identification 51](#_Toc233104797)

[5.7.2 Output 51](#_Toc233104798)

[5.7.3 Conversion Logic 52](#_Toc233104799)

[6 Recovery from OAPI 52](#_Toc233104800)

[A. Appendix 53](#_Toc233104801)

[A.1. Example of Trading Cancellation 53](#_Toc233104802)

[A.2. Example of Trading Adjustment 54](#_Toc233104803)

# Document Control

## Change History

| Version Number | Issue Date | Author | Abstract |
| --- | --- | --- | --- |
| 0.0.1 | 07/03/2025 | IT-Markets Systems | - First draft release |
| 0.0.2 | 10/04/2025 | IT-Markets Systems | Updated with DT comments |
| 0.0.3 | 17/04/2025 | IT-Markets Systems | Updated with DT comments |
| 0.0.4 | 07/05/2025 | IT-Markets Systems | Updated with DT comments |
| 0.0.5 | 29/05/2026 | IT-Markets Systems | Update field mapping in section 5.1.3.1  Add section for 5.2 and 5.3  As per discussion with Clearing |
| 0.0.6 | 03/06/2026 | IT-Markets Systems | As per discussion with Clearing |

## Document Cross-referenced

| # | Document Name | Version |
| --- | --- | --- |
| 1 | ODP-T - ODP-CLR Interface FIX Specification | 0.0.3 |
| 2 | ODP-T - ODP-CLR Interface Reference Data File Spec | 0.0.6 |
| 3 | NDAQ\_OMN\_Interface\_MessRef\_HKEX | va4 |
| 4 | NDAQ\_OMN\_Interface\_MessRef\_Internal\_HKEX | va12 |
| 5 | ODP-T - ODP-RM Interface Reference Data File Spec | 0.0.6 |
|  |  |  |

## Abbreviation

Terms and abbreviations referred to in this document are tabulated as follows:

| Abbreviation/Term | Description |
| --- | --- |
| FIX | Financial Information Exchange – an industry standard |
| ME | Matching Engine – a processing component of ODP-T |
| CA | Capital Adjustment |
|  |  |

## Distribution List

| Name | Role |
| --- | --- |
| HKEX IT – Markets Systems | Initial draft, review and implementation from ODP-TR side  Post-launch maintenance |
| HKEX IT – Post-Trade Systems | Review and implementation from ODP-PT side  Post-launch maintenance |

#

# Introduction

#FS10025\_S0020\_00100

The migration of ODP to production will be implemented via a two-phase strategy. Stage 1 will be the migration of ODP-PT & ODP-RM(hereafter refer as The Destinations), while trading activities will continue to be operate on HKATS. In Stage 2, ODP-TR will be migrated.

During Stage 1, HKATS and DCASS will operate concurrently with ODP-PT & ODP-RM. The HKATS to ODP-PT & ODP-RM interfaces are responsible for transforming and distributing essential trading data and reference data to the Destinations.

This document outlines the interfaces for converting HKATS & DCASS data to The Destinations.

# Scope

This HKATS to ODP-PT & ODP-RM interface covers the mainly Trades (also refer as original trade) generated from DCASS and Products and Participant Data. There are two interfaces to The Destination. The first one is the FIX Interface as per defined as for Stage 2 including the connectivity, session management and message format; which covers Trades intraday and intraday series and combo creation. For further information, please refer to the “ODP-T - ODP-CLR Interface FIX Specification.”

And another is a file interface which covers the Start of Day Reference Data. For further information, please refer to “ODP-T - ODP-CLR Interface Reference Data File Spec” and “ODP-T - ODP-RM Interface Reference Data File Spec”. Both interfaces are generally referred to as “The Interface” in this document.

Detailed scope is covered in Section 5 below. Data entities not mentioned are not covered.

*This document contains information proprietary to HKEX and therefore shall not be shared with parties external to HKEX.
Where needed, relevant information can be extracted and presented separately to such parties as the need may be.*

# Configuration Requirements

The Interface utilizes OAPI to gather HKATS and DCASS data. An OAPI account with the following permissions is required be granted by Derivative Business:

* BD6
* CQ/CA10
* DQ/DA3
* DQ/DA7
* DQ/DA8
* DQ/DA24
* BU/DQ/DA120
* BU/DQ/DA122
* BU/DQ/DA124
* BU/DQ/DA126
* DQ/DA2052
* DQ/DA2053
* DQ/DA2054
* DQ/DA2055
* DQ/DA2062
* UQ/UA12

Since the reference data file uses ODP format and includes new fields and tables like Company, external files are needed to support conversion for compiling reference data files. An operation menu is provided to upload following external files:

* Company configuration
* Company and Participant Mapping

These files are prepared and upload by Derivative Business.

# Supported Feature

#FS10025\_S0030\_00100

The FIX interface would cover following events and disseminating through the FIX interface:

* Original Trade
* Trade Cancellation
* Trade Adjustment
* Intraday New Instrument
* Intraday New Combo
* Block Trade
* Capital Adjustment

The file interface would cover the following:

* Start of Day Reference Data

The Interface operates by referencing the identification section to determine the corresponding event. Once an event is identified, the event would be transformed as per detailed in the conversion logic section. This process involves mapping relevant fields, adjusting data attributes, and ensuring compatibility between the source format and the defined Stage 2 Interfaces to Post Trade.

## Original Trade

#FS10025\_S0030\_00200

### Identification

Real-time BD6 is the source of the event, and the BD6 is identified as an original trade when all below conditions are met:

* In struct CL\_TRADE\_BASE\_API (3), trade\_type\_c = 1 (i.e. Standard trade)
* In struct CL\_TRADE\_BASE\_API (3), deal\_source\_c != 3 (i.e. Inter-Bank block trade) and != 5 (i.e. Internal block trade)
* In struct CL\_TRADE\_BASE\_API (3), execution\_timestamp >= current business date

### Output

Trade Capture Report Message (message type AE) – Explicit vs Explicit

### Conversion Logic

BD6 is an one-sided record (i.e. it only contains either buyer or seller information), and it is different to the ODP-Clearing FIX which is a two-sided record (i.e. contains both buyer and seller information).

Whenever orders are matched in HKATS, executions are sent to DCASS where in turn BD6 are returned. In the BD6, only information of executed order are included and no information about the opposite order. The Interface converts each BD6 regardless of the deal source (e.g. Block Trade or Implied Trade) into an Explicit vs Explicit trade capture report in form of two-sided record by filling in **HKEX** as execution information for the opposite orders.

For example,

Five BD6 for a Many-to-Many match during pre-open:

| Trade No. | Instrument | Quantity | Price | EP | Side |
| --- | --- | --- | --- | --- | --- |
| 50007 | HSIM5 | 20 | 25,200 | G | Buy |
| 50008 | HSIM5 | 34 | 25,200 | H | Buy |
| 50009 | HSIM5 | 26 | 25,200 | I | Sell |
| 50010 | HSIM5 | 10 | 25,200 | J | Sell |
| 50011 | HSIM5 | 18 | 25,200 | K | Sell |

**The Interface converts it into:**

| Trade No. | Instrument | Quantity | Price | Buyer | Seller |
| --- | --- | --- | --- | --- | --- |
| 50007 | HSIM5 | 20 | 25,200 | G | **HKEX** |
| 50008 | HSIM5 | 34 | 25,200 | H | **HKEX** |
| 50009 | HSIM5 | 26 | 25,200 | **HKEX** | I |
| 50010 | HSIM5 | 10 | 25,200 | **HKEX** | J |
| 50011 | HSIM5 | 18 | 25,200 | **HKEX** | K |

#### Field mapping logic between FIX tag and BD6

| FIX Tag | FIX Field Name | OAPI Struct | Field Name in Struct | Mapping Logic | |
| --- | --- | --- | --- | --- | --- |
| 571 | TradeReportID | N/A | | | Generated by The Interface |
| 487 | TradeReportTransType | N/A | | | Must be:   * 0 = New |
| 1003 | TradeID | CL\_TRADE\_BASE\_API (3) | trade\_number\_i | Since trade\_number\_i is unique only within instrument type, The Interface must prepend market code and instrument group code to the trade number for global uniqueness.  The value is composed in below format:  MarketCode/InstGroupCode/trade\_number\_i  For example, a trade for HSIZ6 with trade number 201 will be converted to 34/4/201 | |
| 828 | TrdType | CL\_TRADE\_BASE\_API (3) | big\_attention\_u | The 31st bit of big\_attention\_u is NOT set:   * 0 = Regular Trade (T session)   The 31st bit of big\_attention\_u is set:   * 10 = After Hours Trade (Regular Trade during T+1) | |
| 829 | TrdSubType | N/A | | | Must be:   * 1011 = Explicit Order vs Explicit Order |
| 574 | MatchType | CL\_TRADE\_BASE\_API (3) | deal\_source\_c | Convert deal\_source\_c as below:   * 20: 5 = Cross Auction (i.e., during PREOPEN uncrossing) * Other values: 4 = Auto-Match (i.e., OPEN trading state) | |
| 150 | ExecType | N/A | | | Must be:   * F = Trade |
| 880 | TrdMatchID | MATCH\_ID | match\_group\_nbr\_u |  | |
| 820 | TradeLinkID | CL\_TRADE\_BASE\_API (3) | deal\_number\_i | Since deal\_number\_i is unique only within instrument type, The Interface must prepend market code and instrument group code to the trade number for global uniqueness.  The value is composed in below format:  MarketCode/InstGroupCode/deal\_number\_i | |
| 31 | LastPx | CL\_TRADE\_BASE\_API (3) | deal\_price\_i | Execution Price. | |
| 32 | LastQty | CL\_TRADE\_BASE\_API (3) | trade\_quantity\_i | Execution Size. | |
| 60 | TransactTime | CL\_TRADE\_BASE\_API (3) | execution\_timestamp | Execution Time of the Trade. | |
| 75 | TradeDate | N/A |  | | Set to current business date, The Interface query it from HKATS on start of day. |
| Component Block <**Instrument**> | |  | | | |
| 48 | SecurityID | CL\_TRADE\_BASE\_API (3) | series | Get from reference data:   * Get ins\_id\_s under instrument by series | |
| 22 | SecurityIDSource | N/A | | | Must be:   * 8 = Exchange Symbol |
| 207 | SecurityExchange | SERIES | market\_c | Get from reference data:   * Get mic\_code\_s under market by market\_c | |
| End Component Block <**Instrument**> | |  | | | |
| Component Block <**TrdInstrmtLegGrp**> | |  | | | |
| 555 | NoLegs | N/A | | | The Interface does not support this field. BD6 send leg trade only. |
| Component Block <**TrdInstrmtLeg**> | |  | | | |
| 602 | LegSecurityID | N/A | | | The Interface does not support this field. BD6 send leg trade only. |
| 603 | LegSecurityIDSource | N/A | | | The Interface does not support this field. BD6 send leg trade only. |
| 616 | LegSecurityExchange | N/A | | | The Interface does not support this field. BD6 send leg trade only. |
| 624 | LegSide | N/A | | | The Interface does not support this field. BD6 send leg trade only. |
| End Component Block <**TrdInstrmtLeg**> | |  | | | |
| 637 | LegLastPx | N/A | | | The Interface does not support this field. BD6 send leg trade only. |
| 1418 | LegLastQty | N/A | | | The Interface does not support this field. BD6 send leg trade only. |
| 990 | LegReportID | N/A | | | The Interface does not support this field. BD6 send leg trade only. |
| End Component Block <**TrdInstrmtLegGrp**> | |  | | | |
| Component Block <**TrdCapRptSideGrp**> | |  | | | |
| 552 | NoSides | N/A | | | Must be:   * 2 = Two-sided   The first side is the resting order side. |
| 54 | Side | CL\_TRADE\_BASE\_API (3) | bought\_or\_sold\_c | | For the explicit side:  Value associated with the designated attribute.   * 1 = Buy * 2 = Sell * For the **HKEX** side, value is set to opposite of the designated attribute. |
| Component Block <**Parties**> | |  | | | |
| 453 | NoPartyIDs | N/A | | | Number of party identifiers. The value in this field should be 3 to 5.  For the **HKEX** side, value is 3. |
| 448 | PartyID | TRADING\_CODE | ex\_customer\_s | For the explicit side:  Value associated with the designated attribute.  For the **HKEX** side, value is set to EP ID of HKEX. | |
| 447 | PartyIdSource | Must be:   * D = Proprietary/Custom Code | |
| 452 | PartyRole | Must be:   * 1 = Executing Firm (i.e., Exchange Participant identifier) | |
| 448 | PartyID | TRADING\_CODE | ex\_customer\_s + user\_id\_s | For the explicit side:  Value associated with the designated attribute.  For the **HKEX** side, value is set to Trader ID of HKEX. | |
| 447 | PartyIdSource | Must be:   * D = Proprietary/Custom Code | |
| 452 | PartyRole | Must be:   * 12 = Executing Trader (EP’s Trader/Broker identifier) | |
| 448 | PartyID | TRADING\_CODE | ex\_customer\_s + user\_id\_s | For the explicit side:  Value associated with the designated attribute.  For the **HKEX** side, value is set to Comp ID of HKEX. | |
| 447 | PartyIdSource | Must be:   * D = Proprietary/Custom Code | |
| 452 | PartyRole | Must be:   * 55 = Session ID (i.e., Comp ID of the EP – the owner of this trade) | |
| 448 | PartyID | ACCOUNT | account\_id\_s | For the explicit side:  Value associated with the designated attribute.  For the **HKEX** side, value is absent. | |
| 447 | PartyIdSource | Must be:   * D = Proprietary/Custom Code | |
| 452 | PartyRole | Must be:   * 83 = Clearing Account | |
| 448 | PartyID | GIVE\_UP\_MEMBER (50002) | ex\_customer\_s | For the explicit side:  Value associated with the designated attribute.  For the **HKEX** side, value is absent. | |
| 447 | PartyIdSource | Must be:   * D = Proprietary/Custom Code | |
| 452 | PartyRole | Must be:   * 97 = Give Up Clearing Firm | |
| Component Block < **PtysSubGrp** > | |  | | | |
| 802 | NoPartySubIDs | HKEX\_EXCHANGE\_INFO | give\_up\_info\_s | Number of Party Sub IDs present.  Applicable only if *PartyRole (452)* = 97  If present, always be 1 to represent Give-up Info. | |
| 523 | PartySubID | For the explicit side:  Value associated with the designated attribute.  For the **HKEX** side, value is absent. | |
| 803 | PartySubIDType | Must be:   * 4001 = Give-up Info | |
| End Component Block < **PtysSubGrp** > | |  | | | |
| End Component Block <**Parties**> | |  | | | |
| Component Block <**TradeReportOrderDetail**> | |  | | | |
| 37 | OrderID | CL\_TRADE\_BASE\_API (3) | order\_number\_u | For the explicit side:  Value associated with the designated attribute.  For the **HKEX** side, value is set to 0. | |
| 11 | ClOrdID | CL\_TRADE\_BASE\_API (3) | order\_number\_u | Same value as FIX tag 37 OrderID | |
| 40 | OrdType | N/A | | | BD6 does not contain order type information, The Interface set it to limit order by default.  Must be:   * 2 = Limit |
| Component Block <**OrderAttributeGrp**> | |  | | | |
| 2593 | NoOrderAttributes | N/A | | | The Interface does not support this field. |
| 2594 | OrderAttributeType | N/A | | | The Interface does not support this field. |
| 2595 | OrderAttributeValue | N/A | | | The Interface does not support this field. |
| End Component Block <**OrderAttributeGrp**> | |  | | | |
| End Component Block <**TradeReportOrderDetail**> | |  | | | |
| 1057 | AggressorIndicator | CL\_TRADE\_BASE\_API (3) | big\_attention\_u | For the explicit side:  The 5th bit of big\_attention\_u is NOT set:   * N = Order initiator is passive (Default)   The 5th bit of big\_attention\_u is set:   * Y = Order initiator is aggressor   For the **HKEX** side, value is set to opposite of explicit side | |
| 77 | PositionEffect | CL\_TRADE\_BASE\_API (3) | open\_close\_req\_c | Convert open\_close\_req\_c as below:   * 0, 1, 4: O = Open (Default) * Others: C = Close   For the **HKEX** side, value is C = Close. | |
| 1115 | OrderCategory | N/A | | | BD6 does not contain order type information, The Interface set it to order by default.  Must be:   * 1 = Order |
| 58 | Text | CL\_TRADE\_BASE\_API (3) | customer\_info\_s | customer\_info\_s in HKATS is served in 2 purposes - first for free text and second for incentive schema. The Interface directly copies customer\_info\_s into this FIX tag.  For the **HKEX** side, value is absent. | |
| End Component Block <**TrdCapRptSideGrp**> | |  | | | |
| 1180 | ApplID | N/A | | | The Interface does not support this field. |

## Block Trade

#FS10025\_S0030\_00250

### Identification

Real-time BD6 is the source of the event, and the BD6 is identified as a block trade when all below conditions are met:

* In struct CL\_TRADE\_BASE\_API (3), trade\_type\_c = 1 (i.e. Standard trade)
* In struct CL\_TRADE\_BASE\_API (3), deal\_source\_c = 3 (i.e. Inter-Bank block trade) or 5 (i.e. Internal block trade)
* In struct CL\_TRADE\_BASE\_API (3), execution\_timestamp >= current business date

### Output

Trade Capture Report Message (message type AE) – Matched Block Trade

### Conversion Logic

#### Field mapping logic between FIX tag and BD6

Same as the original trade, the BD6 for block trade also is an one-side record without information about the opposite order. The Interface converts BD6 trade cancellation in form of two-sided record by filling in **HKEX** as execution information for the opposite orders.

| FIX Tag | FIX Field Name | OAPI Struct | Field Name in Struct | Mapping Logic | |
| --- | --- | --- | --- | --- | --- |
| 571 | TradeReportID | N/A | | | Generated by The Interface |
| 487 | TradeReportTransType | N/A | | | Must be:   * 0 = New |
| 1003 | TradeID | CL\_TRADE\_BASE\_API (3) | trade\_number\_i | Since trade\_number\_i is unique only within instrument type, The Interface must prepend market code and instrument group code to the trade number for global uniqueness.  The value is composed in below format:  MarketCode/InstGroupCode/trade\_number\_i  For example, a trade for HSIZ6 with trade number 201 will be converted to 34/4/201 | |
| 828 | TrdType | CL\_TRADE\_BASE\_API (3) | big\_attention\_u | The 31st bit of big\_attention\_u is NOT set:   * 1 = Block Trade (T session)   The 31st bit of big\_attention\_u is set:   * 38 = Block Trade (Block Trade during T+1) | |
| 829 | TrdSubType | CL\_TRADE\_BASE\_API (3) | deal\_source\_c | Convert deal\_source\_c as below:   * 5 (T1 or T2): 1003 = Two Party Trade Report (i.e., Internal Block Trade) * 3 (T4): 1004 = One Party Trade Report (i.e., Inter-Bank Block Trade) | |
| 150 | ExecType | N/A | | | Must be:   * F = Trade |
| 880 | TrdMatchID | MATCH\_ID | match\_group\_nbr\_u |  | |
| 820 | TradeLinkID | CL\_TRADE\_BASE\_API (3) | deal\_number\_i | Since deal\_number\_i is unique only within instrument type, The Interface must prepend market code and instrument group code to the trade number for global uniqueness.  The value is composed in below format:  MarketCode/InstGroupCode/deal\_number\_i | |
| 31 | LastPx | CL\_TRADE\_BASE\_API (3) | deal\_price\_i | Execution Price. | |
| 32 | LastQty | CL\_TRADE\_BASE\_API (3) | trade\_quantity\_i | Execution Size. | |
| 60 | TransactTime | CL\_TRADE\_BASE\_API (3) | execution\_timestamp | Execution Time of the Trade. | |
| 75 | TradeDate | N/A | | | Set to current business date, The Interface query it from HKATS on start of day. |
| 748 | TotNumTradeReports | N/A | | | Must be:   * 1 |
| 2490 | TradeNumber | N/A | | | Must be:   * 1 |
| Component Block <**Instrument**> | |  | | | |
| 48 | SecurityID | CL\_TRADE\_BASE\_API (3) | series | Get from reference data:   * Get ins\_id\_s under instrument by series | |
| 22 | SecurityIDSource | N/A | | | Must be:   * 8 = Exchange Symbol |
| 207 | SecurityExchange | SERIES | market\_c | Get from reference data:   * Get mic\_code\_s under market by market\_c | |
| End Component Block <**Instrument**> | |  | | | |
| Component Block <**TrdInstrmtLegGrp**> | |  | | | |
| 555 | NoLegs | N/A | | | The Interface does not support this field. BD6 send leg trade only. |
| Component Block <**TrdInstrmtLeg**> | |  | | | |
| 602 | LegSecurityID | N/A | | | The Interface does not support this field. BD6 send leg trade only. |
| 603 | LegSecurityIDSource | N/A | | | The Interface does not support this field. BD6 send leg trade only. |
| 616 | LegSecurityExchange | N/A | | | The Interface does not support this field. BD6 send leg trade only. |
| 624 | LegSide | N/A | | | The Interface does not support this field. BD6 send leg trade only. |
| End Component Block <**TrdInstrmtLeg**> | |  | | | |
| 637 | LegLastPx | N/A | | | The Interface does not support this field. BD6 send leg trade only. |
| 1418 | LegLastQty | N/A | | | The Interface does not support this field. BD6 send leg trade only. |
| 990 | LegReportID | N/A | | | The Interface does not support this field. BD6 send leg trade only. |
| End Component Block <**TrdInstrmtLegGrp**> | |  | | | |
| Component Block <**TrdCapRptSideGrp**> | |  | | | |
| 552 | NoSides | N/A | | | Must be:   * 2 = Two-sided   The first side is the reporting side, second side is the **HKEX** side |
| 54 | Side | CL\_TRADE\_BASE\_API (3) | bought\_or\_sold\_c | | For the explicit side:  Value associated with the designated attribute.   * 1 = Buy * 2 = Sell * For the **HKEX** side, value is set to opposite of the designated attribute. |
| Component Block <**Parties**> | |  | | | |
| 453 | NoPartyIDs | N/A | | | Number of party identifiers. The value in this field should be 3 to 5.  For the **HKEX** side, value is 3. |
| 448 | PartyID | TRADING\_CODE | ex\_customer\_s | For the explicit side:  Value associated with the designated attribute.  For the **HKEX** side, value is set to EP ID of HKEX. | |
| 447 | PartyIdSource | Must be:   * D = Proprietary/Custom Code | |
| 452 | PartyRole | Must be:   * 1 = Executing Firm (i.e., Exchange Participant identifier) | |
| 448 | PartyID | TRADING\_CODE | ex\_customer\_s + user\_id\_s | For the explicit side:  Value associated with the designated attribute.  For the **HKEX** side, value is set to Trader ID of HKEX. | |
| 447 | PartyIdSource | Must be:   * D = Proprietary/Custom Code | |
| 452 | PartyRole | Must be:   * 12 = Executing Trader (EP’s Trader/Broker identifier) | |
| 448 | PartyID | TRADING\_CODE | ex\_customer\_s + user\_id\_s | For the explicit side:  Value associated with the designated attribute.  For the **HKEX** side, value is set to Comp ID of HKEX. | |
| 447 | PartyIdSource | Must be:   * D = Proprietary/Custom Code | |
| 452 | PartyRole | Must be:   * 55 = Session ID (i.e., Comp ID of the EP – the owner of this trade) | |
| 448 | PartyID | ACCOUNT | account\_id\_s | For the explicit side:  Value associated with the designated attribute.  For the **HKEX** side, value is absent. | |
| 447 | PartyIdSource | Must be:   * D = Proprietary/Custom Code | |
| 452 | PartyRole | Must be:   * 83 = Clearing Account | |
| 448 | PartyID | GIVE\_UP\_MEMBER (50002) | ex\_customer\_s | For the explicit side:  Value associated with the designated attribute.  For the **HKEX** side, value is absent. | |
| 447 | PartyIdSource | Must be:   * D = Proprietary/Custom Code | |
| 452 | PartyRole | Must be:   * 97 = Give Up Clearing Firm | |
| Component Block < **PtysSubGrp** > | |  | | | |
| 802 | NoPartySubIDs | HKEX\_EXCHANGE\_INFO | give\_up\_info\_s | Number of Party Sub IDs present.  Applicable only if *PartyRole (452)* = 97  If present, always be 1 to represent Give-up Info. | |
| 523 | PartySubID | For the explicit side:  Value associated with the designated attribute.  For the **HKEX** side, value is absent. | |
| 803 | PartySubIDType | Must be:   * 4001 = Give-up Info | |
| End Component Block < **PtysSubGrp** > | |  | | | |
| End Component Block <**Parties**> | |  | | | |
| Component Block <**TradeReportOrderDetail**> | |  | | | |
| 11 | ClOrdID | CL\_TRADE\_BASE\_API (3) | order\_number\_u | For the explicit side:  Value associated with the designated attribute.  For the **HKEX** side, value is set to 0. | |
| Component Block <**OrderAttributeGrp**> | |  | | | |
| 2593 | NoOrderAttributes | N/A | | | The Interface does not support this field. |
| 2594 | OrderAttributeType | N/A | | | The Interface does not support this field. |
| 2595 | OrderAttributeValue | N/A | | | The Interface does not support this field. |
| End Component Block <**OrderAttributeGrp**> | |  | | | |
| End Component Block <**TradeReportOrderDetail**> | |  | | | |
| 77 | PositionEffect | CL\_TRADE\_BASE\_API (3) | open\_close\_req\_c | Convert open\_close\_req\_c as below:   * 0, 1, 4: O = Open (Default) * Others: C = Close   For the **HKEX** side, value is C = Close. | |
| 58 | Text | CL\_TRADE\_BASE\_API (3) | customer\_info\_s | customer\_info\_s in HKATS is served in 2 purposes - first for free text and second for incentive schema. The Interface directly copies customer\_info\_s into this FIX tag.  For the **HKEX** side, value is absent. | |
| End Component Block <**TrdCapRptSideGrp**> | |  | | | |
| 1180 | ApplID | N/A | | | The Interface does not support this field. |

## Trade Cancellation

#FS10025\_S0030\_00300

### Identification

Real-time BD6 is the source of the event, and the BD6 is identified as trade cancellation when all below conditions are met:

* In struct CL\_TRADE\_BASE\_API (3), trade\_type\_c = 4 (Reversing)
* In struct CL\_TRADE\_BASE\_API (3), the 18th bit (deal\_cancelled) is set in big\_attention\_u
* In struct CL\_TRADE\_BASE\_API (3), execution\_timestamp >= current business date

### Output

Trade Capture Report Message (message type AE) – Trade Cancellation

### Conversion Logic

#### Field mapping logic between FIX tag and BD6

Same as the original trade, the BD6 for trade cancellation also is an one-side record without information about the opposite order. The Interface converts BD6 trade cancellation in form of two-sided record by filling in **HKEX** as execution information for the opposite orders.

| FIX Tag | FIX Field Name | OAPI Struct | Field Name in Struct | Mapping Logic |
| --- | --- | --- | --- | --- |
| 571 | TradeReportID | N/A | | Generated by The Interface |
| 487 | TradeReportTransType | N/A | | Must be:   * 1 = Cancel |
| 1003 | TradeID | CL\_TRADE\_BASE\_API (3) | orig\_trade\_number\_i | Since orig\_trade\_number\_i is unique only within instrument type, The Interface must prepend market code and instrument group code to the trade number for global uniqueness.  The value is composed in below format:  MarketCode/InstGroupCode/trade\_number\_i  For example, a trade for HSIZ6 with trade number 201 will be converted to 34/4/201 |
| 150 | ExecType | N/A | | Must be:   * L = Cancelled by the Exchange |
| 60 | TransactTime | CL\_TRADE\_BASE\_API (3) | execution\_timestamp | Execution Time of the Trade. |
| 75 | TradeDate | N/A | | Set to current business date, The Interface query it from HKATS on start of day. |
| Component Block <**Instrument**> | |  | | |
| 48 | SecurityID | CL\_TRADE\_BASE\_API (3) | series | Get from reference data:  Get ins\_id\_s under instrument by series |
| 22 | SecurityIDSource | N/A | | Must be:   * 8 = Exchange Symbol |
| 207 | SecurityExchange | SERIES | market\_c | Get from reference data:  Get mic\_code\_s under market by market\_c |
| End Component Block <**Instrument**> | |  | | |
| Component Block <**TrdCapRptSideGrp**> | |  | | |
| 552 | NoSides | N/A | | Must be:   * 2 = Two-sided |
| 54 | Side | CL\_TRADE\_BASE\_API (3) | bought\_or\_sold\_c | For the explicit side:  Value set to opposite of the bought\_or\_sold as below:   * 1 (Buy): 2 = Sell * 2 (Sell): 1 = Buy   For the **HKEX** side, value is set to designated attribute. |
| Component Block <**Parties**> | |  | | |
| 453 | NoPartyIDs | N/A | | Number of party identifiers. The value in this field should be 1. |
| 448 | PartyID | TRADING\_CODE | ex\_customer\_s | For the explicit side:  Value associated with the designated attribute.  ex\_customer\_s in BD6 for original trade is the EP ID but it will be changed to CP ID in BD6 for reversing. The Interface directly copies the CP ID into this field.  Refer to example in appendix A.1. for details  For the **HKEX** side, value is set to EP ID of HKEX. |
| 447 | PartyIdSource | Must be:   * D = Proprietary/Custom Code |
| 452 | PartyRole | Must be:   * 1 = Executing Firm (i.e., Exchange Participant identifier) |
| End Component Block <**Parties**> | |  | | |
| End Copmponent Block <**TrdCapRptSideGrp**> | |  | | |
| 1180 | ApplID | N/A | | The Interface does not support this field. |

## Trade Adjustment

#FS10025\_S0030\_00400

### Identification

Real-time BD6 is the source of the event, and the BD6 is identified as trade adjustment when all below conditions are met:

* In struct CL\_TRADE\_BASE\_API (3), trade\_type\_c = 3 (Overtaking)
* In struct CL\_TRADE\_BASE\_API (3), the 26th bit (rct\_price\_change) is set in big\_attention\_u
* In struct CL\_TRADE\_BASE\_API (3), execution\_timestamp >= current business date

### Output

Trade Capture Report Message (message type AE) – Trade Adjustment

### Conversion Logic

In BD6, adjusting a trade generates a new trade ID to clearly indicate the modification, while maintaining a link to the original trade through the “original trade number” field (orig\_trade\_number\_i within struct cl\_trade\_base\_api).

Conversely, ODP manages trade adjustment by updating only the original trade without generates any new trade, so trade adjustment message includes only the original trade ID.

Due to these fundamental differences, the Interface can only transfer the “original trade number” from BD6 when forming the ODP trade adjustment message. Although this does not affect standard trade adjustments, it prevents the Interface from supporting further adjustments on trades that have already been adjusted. Please refer to Appendix A.2 for details.

#### Field mapping logic between FIX tag and BD6

Same as the original trade, the BD6 for trade cancellation also is an one-side record without information about the opposite order. The Interface converts BD6 trade cancellation in form of two-sided record by filling in **HKEX** as execution information for the opposite orders.

| FIX Tag | FIX Field Name | OAPI Struct | Field Name in Struct | Mapping Logic | |
| --- | --- | --- | --- | --- | --- |
| 571 | TradeReportID | N/A | | | Generated by The Interface |
| 487 | TradeReportTransType | N/A | | | Must be:   * 2 = Replace |
| 1003 | TradeID | CL\_TRADE\_BASE\_API (3) | orig\_trade\_number\_i | Since orig\_trade\_number\_i is unique only within instrument type, The Interface must prepend market code and instrument group code to the trade number for global uniqueness.  The value is composed in below format:  MarketCode/InstGroupCode/trade\_number\_i  For example, a trade for HSIZ6 with trade number 201 will be converted to 34/4/201 | |
| 150 | ExecType | N/A | | | Must be:   * G = Trade Correct |
| 31 | LastPx | CL\_TRADE\_BASE\_API (3) | deal\_price\_i | Execution Price. | |
| 32 | LastQty | CL\_TRADE\_BASE\_API (3) | trade\_quantity\_i | Execution Size. | |
| 60 | TransactTime | CL\_TRADE\_BASE\_API (3) | execution\_timestamp | Execution Time of the Trade. | |
| 75 | TradeDate | N/A |  | | Set to current business date, The Interface query it from HKATS on start of day. |
| Component Block <**Instrument**> | |  | | | |
| 48 | SecurityID | CL\_TRADE\_BASE\_API (3) | series | Get from reference data:   * Get ins\_id\_s under instrument by series | |
| 22 | SecurityIDSource | N/A | | | Must be:   * 8 = Exchange Symbol |
| 207 | SecurityExchange | SERIES | market\_c | Get from reference data:   * Get mic\_code\_s under market by market\_c | |
| End Component Block <**Instrument**> | |  | | | |
| Component Block <**TrdCapRptSideGrp**> | |  | | | |
| 552 | NoSides | N/A | | | Must be:   * 2 = Two-sided   The first side is the resting order side. |
| 54 | Side | CL\_TRADE\_BASE\_API (3) | bought\_or\_sold\_c | | For the explicit side:  Value associated with the designated attribute.   * 1 = Buy * 2 = Sell   For the **HKEX** side, value is set to opposite of the designated attribute. |
| Component Block <**Parties**> | |  | | | |
| 453 | NoPartyIDs | N/A | | | Number of party identifiers. The value in this field should be 1. |
| 448 | PartyID | TRADING\_CODE | ex\_customer\_s | For the explicit side:  Value associated with the designated attribute.  For the **HKEX** side, value is set to EP ID of HKEX. | |
| 447 | PartyIdSource | Must be:   * D = Proprietary/Custom Code | |
| 452 | PartyRole | Must be:   * 1 = Executing Firm (i.e., Exchange Participant identifier) | |
| End Component Block <**Parties**> | |  | | | |
| Component Block <**TrdInstrmtLegGrp>** | |  | | | |
| 555 | NoLegs | N/A | | | The Interface does not support this field. BD6 send leg trade only. |
| Component Block <**TrdInstrmtLeg**> | |  | | | |
| 602 | LegSecurityID | N/A | | | The Interface does not support this field. BD6 send leg trade only. |
| 603 | LegSecurityIDSource | N/A | | | The Interface does not support this field. BD6 send leg trade only. |
| 616 | LegSecurityExchange | N/A | | | The Interface does not support this field. BD6 send leg trade only. |
| End Component Block <**TrdInstrmtLeg**> | |  | | | |
| 637 | LegLastPx | N/A | | | The Interface does not support this field. BD6 send leg trade only. |
| 1418 | LegLastQty | N/A | | | The Interface does not support this field. BD6 send leg trade only. |
| 990 | LegReportID | N/A | | | The Interface does not support this field. BD6 send leg trade only. |
| End Component Block <**TrdInstrmtLegGrp**> | |  | | | |
| 1180 | ApplID | N/A | | The Interface does not support this field. | |

## Intraday New Instrument

#FS10025\_S0030\_00500

### Identification

Real-time BU124 is the source of the event, and the BU124 is identified as new instrument when all below conditions are met:

* Struct NS\_INST\_SERIES\_BASIC (37301) can be found in BU124 sub item
* Instrument group type of the instrument is Option or Future

### Output

Each identified sub item is converted into a Security Definition Update Report Message (message type BP)

### Conversion Logic

#### Field mapping logic between FIX tag and BU124

| FIX Tag | FIX Field Name | OAPI Struct | Field Name in Struct | | | Mapping Logic |
| --- | --- | --- | --- | --- | --- | --- |
| 964 | SecurityReportID | N/A | | | Generated by The Interface | |
| 980 | SecurityUpdateAction | N/A | | | Must be:   * A = Add | |
| Component Block <**Instrument**> | |  | | | | |
| 48 | SecurityID | NS\_INST\_SERIES\_BASIC (37301) | | ins\_id\_s | Value associated with the designated attribute. | |
| 22 | SecurityIDSrc | N/A | | | Must be:   * 8 = Exchange Symbol | |
| 207 | SecurityExchange | SERIES | | market\_c | Get from reference data:   * Get mic\_code\_s under market by market\_c | |
| 167 | SecurityType | SERIES | | instrument\_group\_c | Get from reference data:   * Get group\_type\_c under instrument group by instrument\_group\_c   Convert group\_type\_c as below:   * 1(Option): OPT = Option * 3 (Future): FUT= Future | |
| 2400 | EffectiveBusinessDate | NS\_INST\_SERIES\_BASIC\_SINGLE (37302) | | date\_notation\_s | Value associated with the designated attribute. | |
| 1151 | SecurityGroup | NS\_INST\_SERIES\_BASIC (37301) | | series | Get instrument class name by series code | |
| Component Block <**EventGrp**> | |  | | | | |
| 864 | NoEvents | N/A | | | Must be:   * 1 to 3. | |
| 865 | EventType | NS\_INST\_SERIES\_BASIC (37301) | | date\_first\_trading\_s  time\_first\_trading\_s | Must be:   * 101 = First Trading Date & Time | |
| 866 | EventDate | Value associated with the designated attribute. | |
| 1145 | EventTime | Value associated with the designated attribute. | |
| 865 | EventType | SERIES | | expiration\_date\_n | Must be:   * 102 = Last Trading Date & Time | |
| 866 | EventDate | Value associated with the designated attribute. | |
| 1145 | EventTime | Value associated with the designated attribute. | |
| 865 | EventType | NS\_INST\_SERIES\_BASIC (37301) | | date\_last\_trading\_s  time\_last\_trading\_s | Must be:   * 103 = Effective Last Trading Date | |
| 866 | EventDate | Value associated with the designated attribute. | |
| 1145 | EventTime | Value associated with the designated attribute. | |
| End Component Block <**EventGrp**> | |  | | | | |
| 202 | StrikePrice | SERIES | | strike\_price\_i |  | |
| End Component Block <**Instrument**> | |  | | | | |
| Component Block <**InstrumentExtension**> | |  | | | | |
| Component Block <**AttrbGrp**> | |  | | | | |
| 870 | NoInstrAttrib | N/A | | | Must be:   * 3 to 6 | |
| 871 | InstrAttribType | N/A | | | Must be:   * 101 = ME-OM Partition ID | |
| 872 | InstrAttribValue | Must be:   * 0 | |
| 871 | InstrAttribType | N/A | | | Must be:   * 102 = ME-BT Partition ID | |
| 872 | InstrAttribValue | Must be:   * 0 | |
| 871 | InstrAttribType | N/A | | | Must be:   * 103 = ME-TM Partition ID | |
| 872 | InstrAttribValue | Must be:   * 0 | |
| 871 | InstrAttribType | SERIES | | modifier\_c | Must be:   * 111 = Modifier | |
| 872 | InstrAttribValue | Value associated with the designated attribute. | |
| 871 | InstrAttribType | NS\_INST\_SERIES\_BASIC\_SINGLE (37302) | | price\_quot\_factor\_i | Must be:   * 112 = Price Quotation Factor | |
| 872 | InstrAttribValue | Value associated with the designated attribute. | |
| 871 | InstrAttribType | NS\_INST\_SERIES\_BASIC\_SINGLE (37302) | | contract\_size\_i | Must be:   * 113 = Contract Size | |
| 872 | InstrAttribValue | Value associated with the designated attribute. | |
| End Component Block <**AttrbGrp**> | |  | | | | |
| End Component Block <**InstrumentExtension**> | |  | | | | |

## Capital Adjustment

#FS10025\_S0030\_00700

The Interfaces offers an operational menu enabling trading operation actions to initiate CA conversion. This process must be manually executed once CA has been completed in HKATS. Upon activation, The Interface transmits queries via OAPI to obtain necessary information, records it into a set of data files designated for CA, and subsequently issues a news message to inform ODP-PT of the availability of CA data files. ODP-PT is expected to leverage this notification to access the data through an alternative medium, which falls outside the scope of this functional specification.

### Identification

Manually execute via operation menu

### Output

A set of reference data files for each CA:

* CA Event
* CA Underlying Mapping
* CA Instrument Class Mapping
* CA Instrument Mapping
* Underlying
* Instrument Class
* Instrument

News Message (msg type B) to notify ODP-PT about CA related data files are ready

### Conversion Logic

Specified the flow and logic

Send DQ2052 first, the OAPI response DA2052 contains a list of CA Event ID

For each CA Event ID in DA2052

Get data from DA2052 and write into data file CA Event and CA Underlying Mapping

Send DQ2053, get data from DA2053 and write it into data file CA Instrument Class Mapping and CA Instrument Mapping

Send DQ2054, get data that corresponds to this CA Event ID from DA2054 and write it into data file Underlying

Send DQ2055, get data that corresponds to this CA Event ID from DA2055 and write it into data file Instrument Class

Send DQ2062, get data that corresponds to this CA Event ID from DA2062 and write it into data file Instrument

After all data files are ready, send a News Message (msg type B) to notify ODP-PT.

#### Field mapping logic between file for CA Event and DA2052

| Field No. | Field Name | OAPI Struct | Field Name in Struct | Mapping Logic |
| --- | --- | --- | --- | --- |
| 1 | Record Type | N/A | | Must be:   * 1 = Data Record |
| 2 | CA Event ID | ANSWER\_UNDERLYING\_ADJ\_INT | adjust\_ident\_n | Value associated with the designated attribute. |
| 3 | Adjustment Ratio | ANSWER\_UNDERLYING\_ADJ\_INT | und\_price\_mod\_factor\_i | Convert und\_price\_mod\_factor\_i from 7 to 6 implied decimal place |
| 4 | Effective Adjustment Date | ANSWER\_UNDERLYING\_ADJ\_INT | date\_adjust\_s | Value associated with the designated attribute. |

#### Field mapping logic between file for CA Underlying Mapping and DA2052

| Field No. | Field Name | OAPI Struct | Field Name in Struct | Mapping Logic |
| --- | --- | --- | --- | --- |
| 1 | Record Type | N/A | | Must be:   * 1 = Data Record |
| 2 | CA Event ID | ANSWER\_UNDERLYING\_ADJ\_INT | adjust\_ident\_n | Value associated with the designated attribute. |
| 3 | Original Underlying ID | ANSWER\_UNDERLYING\_ADJ\_INT | commodity\_n | Get from reference data:   * Get com\_id\_s under underlying by commodity\_n |
| 4 | Adjusted Underlying ID | ANSWER\_UNDERLYING\_ADJ\_INT | new\_commodity\_n | Send DQ2054 with new\_commodity\_n and get com\_id\_s from DA2054 |

#### Field mapping logic between file for CA Instrument Class Mapping and DA2053

| Field No. | Field Name | OAPI Struct | Field Name in Struct | Mapping Logic |
| --- | --- | --- | --- | --- |
| 1 | Record Type | N/A | | Must be:   * 1 = Data Record |
| 2 | CA Event ID | ANSWER\_CONVERTED\_SERIES | adjust\_ident\_n | Value associated with the designated attribute. |
| 3 | Original Instrument Class ID | ANSWER\_CONVERTED\_SERIES | old\_series | Set modifier\_c field in old\_series to 0, send with DQ2055 and get inc\_id\_s from DA2055.  Duplicated inc\_id\_s only write once into the data file. |
| 4 | Adjusted Instrument Class ID | ANSWER\_CONVERTED\_SERIES | new\_series | Set modifier\_c field in new\_series to 0, send with DQ2055 and get inc\_id\_s from DA2055.  Duplicated inc\_id\_s only write once into the data file. |

#### Field mapping logic between file for CA Instrument Mapping and DA2053

| Field No. | Field Name | OAPI Struct | Field Name in Struct | Mapping Logic |
| --- | --- | --- | --- | --- |
| 1 | Record Type | N/A | | Must be:   * 1 = Data Record |
| 2 | CA Event ID | ANSWER\_CONVERTED\_SERIES | adjust\_ident\_n | Value associated with the designated attribute. |
| 3 | Original Instrument ID | ANSWER\_CONVERTED\_SERIES | old\_series | Send DQ2062 with old\_series and get ins\_id\_s from DA2062 |
| 4 | Adjusted Instrument ID | ANSWER\_CONVERTED\_SERIES | new\_series | Send DQ2062 with new\_series and get ins\_id\_s from DA2062 |

#### Field mapping logic between file for Underlying and DA2054

| Field No. | Field Name | OAPI Struct | Field Name in Struct | Mapping Logic |
| --- | --- | --- | --- | --- |
| 1 | Record Type | N/A | | Must be:   * 1 = Data Record |
| 2 | Underlying ID | ANSWER\_UNDERLYING | com\_id\_s | Value associated with the designated attribute. |
| 3 | Description | ANSWER\_UNDERLYING | name\_s | Value associated with the designated attribute. |
| 4 | Underlying Code | ANSWER\_UNDERLYING | commodity\_n | Value associated with the designated attribute. |
| 5 | Underlying Type | ANSWER\_UNDERLYING | underlying\_type\_c | Convert underlying\_type\_c as below:   * 1 (Stock), 7 (Stock Index): S = Stock * 2 (Currency), 8 (Currency Index): C = Currency * 3 (Interest Rate), 9 (Interest Rate Index): I = Fixed Income * 4 (Energy), 10 (Energy Index): E = Power/Energy * 5 (Soft and Agrics), 11 (Aofts and Agrics Index): A = Commodity * 6 (Metal), 12 (Metal Index): M = Metal |
| 6 | Underlying Issuer | ANSWER\_UNDERLYING | Underlying\_issuer\_s | Value associated with the designated attribute. |
| 7 | Price Decimals | ANSWER\_UNDERLYING | dec\_in\_price\_n | Value associated with the designated attribute. |
| 8 | Currency | ANSWER\_UNDERLYING | base\_cur\_s | Value associated with the designated attribute. |

#### Field mapping logic between file for Instrument Class and DA2055

| Field No. | Field Name | OAPI Struct | Field Name in Struct | Mapping Logic |
| --- | --- | --- | --- | --- |
| 1 | Record Type | N/A | | Must be:   * 1 = Data Record |
| 2 | Instrument Class ID | ANSWER\_INSTRUMENT\_CLASS | inc\_id\_s | Value associated with the designated attribute. |
| 3 | Description | ANSWER\_INSTRUMENT\_CLASS | name\_s | Value associated with the designated attribute. |
| 4 | Instrument Type ID | ANSWER\_INSTRUMENT\_CLASS | series | Send DQ3 with series and get int\_id\_s from DA3 |
| 5 | Underlying ID | ANSWER\_INSTRUMENT\_CLASS | series | Send DQ2054 with series and get com\_id\_s from DA2054 |
| 6 | Currency | ANSWER\_INSTRUMENT\_CLASS | base\_cur\_s | Value associated with the designated attribute. |
| 7 | Settlement Currency | ANSWER\_INSTRUMENT\_CLASS | settl\_cur\_id\_s | Length of settl\_cur\_id\_s is 12, truncate it to 3 |
| 8 | Price Tick ID | ANSWER\_INSTRUMENT\_CLASS | series | Get the old\_series from mapping table by series, set modifier\_c field in old\_series to 0, send with DQ2055 and get inc\_id\_s (Instrument Class ID) from DA2055.  Load ODP reference data, use inc\_id\_s to get the Price Tick ID. |
| 9 | Price Quotation Factor | ANSWER\_INSTRUMENT\_CLASS | price\_quot\_factor\_i | Value associated with the designated attribute. |
| 10 | Contract Size | ANSWER\_INSTRUMENT\_CLASS | contract\_size\_i | Value associated with the designated attribute. |
| 11 | Decimals For Contract Size & PQF | ANSWER\_INSTRUMENT\_CLASS | dec\_in\_contr\_size\_n | Value associated with the designated attribute. |
| 12 | Decimals For Strike Price | ANSWER\_INSTRUMENT\_CLASS | dec\_in\_strike\_price\_n | Value associated with the designated attribute. |
| 13 | Special Trading Days ID | ANSWER\_INSTRUMENT\_CLASS | series | Get the old\_series from mapping table by series, set modifier\_c field in old\_series to 0, send with DQ2055 and get inc\_id\_s (Instrument Class ID) from DA2055.  Load ODP reference data, use inc\_id\_s to get the Special Trading Days ID. |

#### Field mapping logic between file for Instrument and DA2062

| Field No. | Field Name | OAPI Struct | Field Name in Struct | Mapping Logic |
| --- | --- | --- | --- | --- |
| 1 | Record Type | N/A | | Must be:   * 1 = Data Record |
| 2 | Instrument ID | ANSWER\_SERIES\_INT | ins\_id\_s | Value associated with the designated attribute. |
| 3 | Instrument Class ID | ANSWER\_SERIES\_INT | series | Set modifier\_c field in series to 0, send with DQ2055 and get inc\_id\_s from DA2055. |
| 4 | Strike Price | SERIES | strike\_price\_i | Value associated with the designated attribute. |
| 5 | Underlying Code | SERIES | commodity\_n | Value associated with the designated attribute. |
| 6 | Effective Date | ANSWER\_SERIES\_INT | date\_notation\_s | Value associated with the designated attribute. |
| 7 | Last Trading Date | SERIES | expiration\_date\_n | Value associated with the designated attribute. |
| 8 | Effective Last Trading Date | ANSWER\_SERIES\_INT | date\_last\_trading\_s | Value associated with the designated attribute. |
| 9 | Last Trading Time | ANSWER\_SERIES\_INT | time\_last\_trading\_s | Value associated with the designated attribute. |
| 10 | First Trading Date | ANSWER\_SERIES\_INT | date\_first\_trading\_s | Value associated with the designated attribute. |
| 11 | First Trading Time | ANSWER\_SERIES\_INT | time\_first\_trading\_s | Value associated with the designated attribute. |
| 12 | Modifier | SERIES | modifier\_c | Value associated with the designated attribute. |
| 13 | Price Quotation Factor | ANSWER\_SERIES\_INT | price\_quot\_factor\_i | Value associated with the designated attribute. |
| 14 | Contract Size | ANSWER\_SERIES\_INT | contract\_size\_i | Value associated with the designated attribute. |
| 15 | Market Code | SERIES | market\_c | Value associated with the designated attribute. |
| 16 | Instrument Group Code | SERIES | instrument\_group\_c | Value associated with the designated attribute. |
| 17 | Exchange Code | SERIES | country\_c | Value associated with the designated attribute. |

## Start of Day Reference Data

#FS10025\_S0030\_00800

Following the completion of the Night Batch for HKATS and DCASS, The Interface generates a suite of reference data files. The methodology employed for converting these reference data files is outlined in the Conversion section. For comprehensive information regarding the data file format, please refer to the “ODP-T - ODP-CLR Interface Reference Data File Specification” and “ODP-T - ODP-RM Interface Reference Data File Spec”.

### Identification

HKATS and DCASS night batch is completed.

### Output

Data files for system start of day and market start of day. Please refer to the section “Reference Data File Schedule” in “ODP-T - ODP-CLR Interface Reference Data File Specification” and “ODP-T - ODP-RM Interface Reference Data File Spec“ for details.

### Conversion Logic

The Interface retrieves the start-of-day reference data from PD and writes it to the reference data files as output. The detailed conversion logic for each data field is documented in the attached spreadsheet file below.

![](data:image/x-emf;base64...)

# Recovery from OAPI

The interface would have recovery capability to recover data from Genium upon failure.

1. Appendix
   1. Example of Trading Cancellation

When a reversing trade is issued, the ex\_customer\_s field in TRADING\_CODE is updated from OPTMM to CMPF. The Interface directly copies this field into the FIX message:

For the Trade Capture Report Message (message type AE) – Explicit vs Explict (i.e. the original trade), OPTMM serves as the PartyID for the Executing Firm

Whereas in the Trade Capture Report Message (message type AE) – Trade Cancellation (i.e. the reversing trade), CMPF is used.

| BD6 Field | Original Trade Content | | Reversing Trade Content | |
| --- | --- | --- | --- | --- |
| SERIES | DHSZ8 | DHSZ8 | |
| trade\_number\_i | 223 | 229 | |
| deal\_price\_i | 45000 | 45000 | |
| trade\_quantity\_i | 1 | 1 | |
| bought\_or\_sold\_c | 2 (Sell) | 1 (Buy) | |
| order\_number\_u | 6E472703:000CE4DE | 6E472703:000CE4DE | |
| trade\_type\_c | 1 (Standard) | 4 (Reversing) | |
| TRADING\_CODE |  |  | |
| country\_id\_s | HK | HK | |
| **ex\_customer\_s** | **OPTMM** | **CMPF** | |
| user\_id\_s | 4344 | XXXXX | |
| ACCOUNT |  |  | |
| country\_id\_s | HK | HK | |
| ex\_customer\_s | CMPF | CMPF | |
| account\_id\_s | R+OPTMM | R+OPTMM | |
| USER\_CODE |  |  | |
| country\_id\_s | HK | HK | |
| ex\_customer\_s | OPTMM | HKEX | |
| user\_id\_s | 4344 | CERCC | |

* 1. Example of Trading Adjustment

When an overtaking trade is initiated, it assigns an original trade number (i.e., orig\_trade\_number\_i) to connect the new transaction with the original trade.

| BD6 Field | Original Trade Content | 1st Overtaking Content | 2nd Overtaking Content |
| --- | --- | --- | --- |
| SERIES | DHSZ8 | DHSZ8 | DHSZ8 |
| trade\_number\_i | **185** | **186** | 187 |
| deal\_price\_i | 40010 | 40111 | 40222 |
| trade\_quantity\_i | 1 | 1 | 1 |
| bought\_or\_sold\_c | 1 (Buy) | 1 (Buy) | 1 (Buy) |
| order\_number\_u | 6E472703:000C6113 | 6E472703: 000C61113 | 6E472703: 000C61113 |
| trade\_type\_c | 1 (Standard) | 3 (Overtaking) | 3 (Overtaking) |
| orig\_trade\_number\_i | 0 | **185** | **186** |
| country\_id\_s | HK | HK | HK |
| ex\_customer\_s | CCL | CCCL | CCCL |
| user\_id\_s | 3160 | XXXXX | XXXXX |

After converted into FIX, only the orig\_trade\_number\_i can be carried. This is no impact to 1st trade adjustment, the original trade and the adjusted trade can be linked.

However, in the 2nd trade adjustment, the trade ID **186** is never disseminated before. Therefore the connection between 1st and 2nd trade adjustment is loss, and prevents the Interface from supporting further adjustments on trades that have already been adjusted.

| FIX Tag | AE – Explicit vs Explicit | 1st AE – Trade Adjustment | 2nd AE – Trade Adjustment |
| --- | --- | --- | --- |
| SecurityID (48) | DHSZ8 | DHSZ8 | DHSZ8 |
| TradeID (1003) | **185** | **185** | **186** |
| LastPx (31) | 40010 | 40111 | 40222 |
| LastQty (32) | 1 | 1 | 1 |
| NoSides (552) | 2 | 2 | 2 |
| Side (54) | 1 (Buy) | 1 (Buy) | 1 (Buy) |
| PartyID (448) | CCL | CCCL | CCCL |
| PartyIdSource (447) | D | D | D |
| PartyRole (452) | 1 | 1 | 1 |
| OrderID (37) | 6E472703:000C6113 | 6E472703:000C6113 | 6E472703:000C6113 |
| Side (54) | 2 (Sell) | 2 (Sell) | 2 (Sell) |
| PartyID (448) | HKEX | HKEX | HKEX |
| PartyIdSource (447) | D | D | D |
| PartyRole (452) | 1 | 1 | 1 |
| OrderID (37) | 00000000:00000000 | 00000000:00000000 | 00000000:00000000 |
