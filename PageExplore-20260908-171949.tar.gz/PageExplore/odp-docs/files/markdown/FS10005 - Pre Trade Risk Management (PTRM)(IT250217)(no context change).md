TITLE:

**FUNCTIONAL SPECIFICATION**

**ODP-T**

*FS10005 - Pre Trade Risk Management*

AUTHOR : *IT / Markets Systems* DATE : *11 Apr 2025*

LAST REVIEW Derivatives Trading Business Operations DATE : *28 Feb 2025*

**CONTENTS**

[1. Document Control 4](#__RefHeading___Toc188296711)

[1.1. Change History 4](#__RefHeading___Toc188296712)

[1.2. Document Cross-referenced 4](#__RefHeading___Toc188296713)

[1.3. Abbreviation 5](#__RefHeading___Toc188296714)

[1.4. Distribution List 5](#__RefHeading___Toc188296715)

[2. Introduction 6](#__RefHeading___Toc188296716)

[2.1. System Objectives 6](#__RefHeading___Toc188296717)

[2.2. Scopes 6](#__RefHeading___Toc188296718)

[2.3. Principal Users 6](#__RefHeading___Toc188296719)

[3. Pre Trade Risk Management 7](#__RefHeading___Toc188296720)

[**3.1.** **Account Structure** 7](#__RefHeading___Toc188296721)

[3.2. Pre Trade Limits Group 8](#__RefHeading___Toc188296722)

[3.2.1. Base Group 8](#__RefHeading___Toc188296723)

[3.2.2. Non-Base Group 8](#__RefHeading___Toc188296724)

[3.3. Sponsored user list 8](#__RefHeading___Toc188296725)

[3.3.1. Existing users 9](#__RefHeading___Toc188296726)

[3.3.2. New users 9](#__RefHeading___Toc188296727)

[3.4. Access Structure 10](#__RefHeading___Toc188296728)

[3.4.1. Trading identify access 10](#__RefHeading___Toc188296729)

[3.4.2. Sponsoring participant identify access 10](#__RefHeading___Toc188296730)

[3.4.3. Exchange identify access 10](#__RefHeading___Toc188296731)

[4. Operations 12](#__RefHeading___Toc188296732)

[4.1. Add / Remove Pre Trade Limits Group 12](#__RefHeading___Toc188296733)

[4.2. Emergency Buttons 12](#__RefHeading___Toc188296734)

[4.2.1. Stop / Unstop 13](#__RefHeading___Toc188296735)

[4.2.2. Mass Cancel 13](#__RefHeading___Toc188296736)

[4.2.3. Kill Switch 14](#__RefHeading___Toc188296737)

[4.2.4. Breach / Unblock 14](#__RefHeading___Toc188296738)

[4.3. Monitoring alerts 14](#__RefHeading___Toc188296739)

[4.3.1. Notification Level (Notice and Warning %) 14](#__RefHeading___Toc188296740)

[4.3.2. Event Notification List 15](#__RefHeading___Toc188296741)

[4.3.3. Audible Alerts 16](#__RefHeading___Toc188296742)

[5. Risk Checks 17](#__RefHeading___Toc188296743)

[5.1. Order Rate 17](#__RefHeading___Toc188296744)

[5.1.1. Included / Excluded Order attributes 17](#__RefHeading___Toc188296745)

[5.1.2. Breach behavior 17](#__RefHeading___Toc188296746)

[5.1.3. Parameters 18](#__RefHeading___Toc188296747)

[5.2. Intraday Exposure 19](#__RefHeading___Toc188296748)

[5.2.1. Unit Margin Check 19](#__RefHeading___Toc188296749)

[5.2.2. Included / Excluded Order attributes 19](#__RefHeading___Toc188296750)

[5.2.3. Breach behavior 19](#__RefHeading___Toc188296751)

[5.2.4. Margin Coefficient 20](#__RefHeading___Toc188296752)

[5.2.5. Exposure Risk Check parameters and Formula 21](#__RefHeading___Toc188296753)

[5.3. Execution Throttle Exposure 23](#__RefHeading___Toc188296754)

[5.3.1. Margin Coefficient 23](#__RefHeading___Toc188296755)

[5.3.2. Included / Excluded Order attributes 23](#__RefHeading___Toc188296756)

[5.3.3. Breach behavior 23](#__RefHeading___Toc188296757)

[5.3.4. Risk Check parameters and Formula 24](#__RefHeading___Toc188296758)

[5.4. Order Exposure Reference 26](#__RefHeading___Toc188296759)

[5.4.1. Margin Coefficient 26](#__RefHeading___Toc188296760)

[5.4.2. Included / Excluded Order attributes 26](#__RefHeading___Toc188296761)

[5.4.3. Breach behavior 26](#__RefHeading___Toc188296762)

[5.4.4. Risk Check parameters and Formula 26](#__RefHeading___Toc188296763)

[5.5. Position Limits 27](#__RefHeading___Toc188296764)

[5.5.1. Tradables attributes 27](#__RefHeading___Toc188296765)

[5.5.2. Included / Excluded Order attributes 27](#__RefHeading___Toc188296766)

[5.5.3. Breach behavior 27](#__RefHeading___Toc188296767)

[5.5.4. RiskCheck parameters and Formula 28](#__RefHeading___Toc188296768)

[5.6. Order Size 31](#__RefHeading___Toc188296769)

[5.6.1. Tradables attributes 31](#__RefHeading___Toc188296770)

[5.6.2. Included / Excluded Order attributes 31](#__RefHeading___Toc188296771)

[5.6.3. Breach behavior 31](#__RefHeading___Toc188296772)

[5.6.4. Parameters 32](#__RefHeading___Toc188296773)

[5.7. Block Trade Size 33](#__RefHeading___Toc188296774)

[5.7.1. Tradables attributes 33](#__RefHeading___Toc188296775)

[5.7.2. Included / Excluded Order attributes 33](#__RefHeading___Toc188296776)

[5.7.3. Breach behavior 33](#__RefHeading___Toc188296777)

[5.7.4. Parameters 33](#__RefHeading___Toc188296778)

[6. Reports 34](#__RefHeading___Toc188296779)

[6.1. Audit Reports 34](#__RefHeading___Toc188296780)

[6.2. Utilization Reports 36](#__RefHeading___Toc188296781)

[7. Disable PTRM 38](#__RefHeading___Toc188296782)

[APPENDIX I – Risk Checks behavior in Normal and Blocked state 39](#__RefHeading___Toc188296783)

[APPENDIX II – Risk Check Parameters attributes 40](#__RefHeading___Toc188296784)

[APPENDIX III – Order Rate vs Time Period 41](#__RefHeading___Toc188296785)

[APPENDIX IV – Day2 requirements 44](#__RefHeading___Toc188296786)

# Document Control

## Change History

|  |  |  |  |
| --- | --- | --- | --- |
| Version  Number | Issue Date | Author | Abstract |
| 0.1 | 25 Sep 2023 | IT/Markets Systems | Initial Version |
| 1.2 | 21-Sep-2024 | IT/Markets Systems | * Add Tagging * Added session for Margin Rate File operations * Added Market level in Position Limit, Max order size, and Block trade size * Updated the handling of Block Trades Exposure |
| 1.3 | 23-Oct-2024 | IT/Markets Systems | * Updated as per FS review 1029(IT) |
| 1.4 | 10-Jan-2025 | IT/Markets Systems | * Update for BlockTrade counting towards Base PTLG |
| 1.5 | 14-Jan-2025 | IT/Markets Systems | * Sync terminology of PTLG to Risk Goup * Supplement on describing the behavior on order amendment and order validity condition * Supplement for Block Trade counting towards Base PTLG |
| 1.6 | 23-Jan-2025 | IT/Markets Systems | * Updated the BRS Tag in FS Tag * Updated 5.1.1 for Order Rate breach behavior on Block Trade |
| 1.7 | 27-Jan-2025 | IT/Markets Systems | * Updated The BRS Tag in FS Tag |
| 1.8 | 17-Feb-2025 | IT/Markets Systems | * Supplemented the suspend participant description. * Updated BRS Tag in FS Tag |
| 1.9 | 24-Mar-2025 | IT/Markets Systems | * Updated Cover page |
| 2.0 | 11-Apr-2025 | IT/Markets Systems | * Update FS Tag number *(There was duplicated #FS10005\_S0050\_05000 in Section 5.2.5 and 5.5.4. The former duplicated tag was adjusted into #FS10005\_S0050\_02150 to prevent this confusion. Original #FS10005\_S0050\_08000 in 5.2* Intraday Exposure is amended into \_00800.) |

## Document Cross-referenced

|  |  |  |
| --- | --- | --- |
| # | Document | Version |
| 1 | BRS\_Pre Trade Risk Management | 20250110 v6.0 |
|  |  |  |

## Abbreviation

|  |  |
| --- | --- |
| PTRM | Pre Trade Risk Management |
| Tradables | The Market, Instrument Type or Class defined for Position Limits, Block Trade Limits, Maximum Order Size and Block Trade Size Risk Check |

## Distribution List

Derivatives Trading Business Operations

Introduction

## System Objectives

**#FS10005\_S0020\_00100** The system objectives for the Pre-Trade Limits Group (PTLG) and associated operations in the Pre-Trade Risk Management (PTRM) system are to allow configurable parameters for risk management and control. Risk Group enable more granular application of risk limits, representing different parts of a business with specific limits. The system provides operations such as stop/unstop, mass cancel, and kill switch to manage Risk Group effectively. Additionally, the system monitors breach events and sends notifications based on notice and warning levels defined for each risk check. Overall, the system aims to ensure pre-trade risk management, enforce limits, and provide timely alerts for risk-related events in trading activities.

## Scopes

**#FS10005\_S0020\_00200** The overall scope of the system is to provide comprehensive pre-trade risk management and control capabilities in the context of trading activities. The system allows for the configuration of Risk Group, which represent different parts of a business and enable the application of specific risk limits. Each Risk Group consists of User IDs connected to a Sponsored Participant, allowing for granular control over risk parameters.

**#FS10005\_S0020\_00300** The system supports various operations to manage Risk Group effectively. The stop/unstop functionality allows both sponsoring and sponsored participants to block or unblock sponsored users from placing orders and quotes within a Risk Group or participant. The mass cancel operation enables the cancellation of all outstanding orders and pending trade reports within a Risk Group or participant. The kill switch combines the stop functionality with mass cancel to block and clear orders and pending trade reports.

**#FS10005\_S0020\_00400** The system also includes monitoring capabilities with notification levels for risk checks. Notifications are sent via broadcast or email when risk check values breach notice or warning thresholds. The system maintains different types of risk checks, including order rate, intraday exposure, execution throttle exposure, position limits, block trade limits, and maximum order and block trade size. Each risk check assesses specific aspects of trading activities and applies predefined limits to ensure risk control.

**#FS10005\_S0020\_00500** Overall, the system's functional scope covers the configuration and management of Risk Group, blocking and cancelling operations, breach monitoring, and notification alerts for different risk checks. It aims to provide comprehensive pre-trade risk management capabilities to mitigate risks and ensure compliance in trading activities.

**#FS10005\_S0020\_00600** All existing parameters will be migrated to the PTRM in ODP.

## Principal Users

**#FS10005\_S0020\_00700** The Derivatives Trading end-users, Sponsoring Participants and Sponsored Participants, are the key users of the system who rely on its features to configure risk limits, perform blocking and cancelling operations, and monitor breach events. Together, these principal users contribute to the successful implementation and utilization of the system in supporting comprehensive pre-trade risk management and control.

# Pre Trade Risk Management

**#FS10005\_S0030\_00100** The Pre-Trade Risk Management (PTRM) service allows Sponsoring Participants to manage the risk of Sponsored Participants they are responsible for. Sponsoring Participants set limits on trading behavior for one or more Sponsored Participants, who are entities engaged in trading activities.

## **Account Structure**

* **#FS10005\_S0030\_00200** Exchange
* **#FS10005\_S0030\_00300** Sponsoring Participant refers to a participant who manages the risk of one or more Sponsored Participants by setting limits on trading behavior.

Each Sponsoring Participant can manage multiple Sponsored Participants.

(e.g. Sponsoring Participant - CXXX)

**#FS10005\_S0030\_00301** In Trading system, suspending the participant will also suspend all associated user logins. If the Sponsoring Participant has been suspended in the Clearing System but needs to continue operating the PTLG for their Sponsored Participant, the trading operation users can suspend the Sponsoring Participant through the internal Admin GUI once they receive confirmation from the Sponsoring Participant that access to the Trading System is no longer needed.

Example:

* CXXX is a sponsoring participant with a PTRM GUI user ID: P\_CXXX1234.
* YYYMM is a sponsored participant with a PTRM GUI user ID: P\_YYYMM2345.

Explanation:

1. Suspending CXXX in the Clearing System:
   * When CXXX is suspended in the Clearing System, the user ID P\_CXXX1234 will not be affected in the Trading System. This means P\_CXXX1234 will not be suspended or forced logout from the Trading System.
2. Suspending YYYMM in the Trading System:
   * When YYYMM is suspended in the Trading System, all associated sessions (binary and GUI users), including P\_YYYMM2345, will be affected as the below ways -
     (a) for already logged in case, the PTRM user will be forced logout
     (b) for not yet logged in case, the PTRM user will be suspended for login

The forcing logout and suspending login of PTRM GUI user would not affect the PTRM functions (i.e. the PTRM system continues to operate and calculates the relevant risk limit).

* **#FS10005\_S0030\_00400** Sponsored Participant refers to an entity that is engaged in trading.

Each Sponsored Participant can only be managed by one Sponsoring Participant.

(e.g. Trading Participant - XXX)

* **#FS10005\_S0030\_00500** Base Group – the Pre-Trade Limits Group created by default
  (e.g. HKCXXX\_HKXXX\_BASE)
* **#FS10005\_S0030\_00600** non-Base Group – optionally created Pre-Trade Limits Group
  (e.g. HKCXXX\_HKXXX\_YYY)
* **#FS10005\_S0030\_00700** Sponsored user IDs
  (e.g. Trading user IDs – XXX1234)

**#FS10005\_S0030\_00800** The structure hierarchy is as below:

Exchange

Sponsoring Participant A

Sponsoring Participant B

Sponsored Participant AX

Sponsored Participant AY

Sponsored Participant BZ

Base Group HKCA\_HKAX\_BASE

Non-Base Group HKCA\_HKAX\_1

Base Group HKCA\_HKAY\_BASE

User ID AX1

User ID AX2

Base Group HKCB\_HKBZ\_BASE

User ID AY1

User ID AY2

## Pre Trade Limits Group

**#FS10005\_S0030\_00900** The Risk Group allows for configurable parameters in the Pre-Trade Risk Management (PTRM) system. A Risk Groupconsists of User IDs connected to a Sponsored Participant ID, enabling more granular application of PTRM parameters. Each Risk Group can represent different parts of a business with specific limits. A Sponsoring Participant can have multiple Risk Groups, but each Risk Group can only be connected to one Sponsoring Participant. Additionally, a User ID can only be associated with one Risk Group.

### Base Group

**#FS10005\_S0030\_01001** A Risk Group creates for each sponsored participant by default which cannot be deleted by the external participant. For those Sponsored user ID have not been assigned to any Risk Group , the Risk Check will be counted by the sponsored participant’s Base Group. The At-Trade Risk Check on Block trade will be monitored by it’s participant’s Base Risk Group who submit and accept the Block Trade

### Non-Base Group

**#FS10005\_S0030\_01100** A Risk Group created by participant optionally. It only monitors the user id defined in the sponsored user list.

## Sponsored user list

**#FS10005\_S0030\_01200** Each PTLG contains a Sponsored user list. The Risk Group monitors the User ID assigned in the list. **#FS10005\_S0030\_01300** The list must contain at least one sponsored user. **#FS10005\_S0030\_01400** The user id can only be assigned to one of the non-Base Group under the sponsored participant. **#FS10005\_S0030\_01500** Add or remove sponsored user to the Non-Base Group would be next day effective.

**#FS10005\_S0030\_01501** If the assigned sponsored user is about to be removed, a reminder will be displayed indicating the Risk Group to which the user was assigned.

### Existing users

**#FS10005\_S0030\_01600** It can be assigned to any of the Non-Base Group. **#FS10005\_S0030\_01700** For any user id have not been assigned to any Risk Group, it would be assigned to Base Group automatically.

### New users

**#FS10005\_S0030\_01800** For a new user intraday created, it will automatically fall into the Base Group Sponsored User list as following the same handling as user id have not been assigned to any Risk Group. The user will be monitored by the Base Group immediately. For example, order placement will be rejected if the Base Group has breached any Risk Check or Stopped.

**#FS10005\_S0030\_01900** To assign it into a Non-Base Group, it can be done with next day effective or remains unchanged to keep it in Base Group going forward.

## Access Structure

### Trading identify access

**#FS10005\_S0030\_02100** It provides access for Self-Clearing Exchange Participant (“EP”) to monitor the Risk Checks counters and limits of its own participant’s Risk Group. **#FS10005\_S0030\_02200** This type of user cannot edit any parameters and unblock the Risk Group, but they can execute the following emergency buttons.

* Stop Button
* Mass Order Cancellation
* Kill Switch

### Sponsoring participant identify access

**#FS10005\_S0030\_02300** It provides full access for General Clearing Participant (“GCP”) to control all Risk Checks andmanage the Risk Group of the Sponsored participant under the Sponsoring participant. This type of user can create and remove the non-base risk group and control.

* Add / remove Non-Base Risk Group
* Add / Remove Sponsored User ID
* Add / remove Event Notification list
* Add / Remove Tradables
* Change Risk Check Parameter limits
* Execute all Emergency buttons

### Exchange identify access

**#FS10005\_S0030\_02400** It provides full access as Sponsoring Participant identify access, but able to control all Sponsoring and Sponsored Participants.

The following table summarizes the allowable actions for each Access Identity.

|  |  |  |  |
| --- | --- | --- | --- |
| **Actions** | **Access Identity** | | |
| **Trading** | **Sponsoring** | **Exchange** |
| Show all Risk Groups from Sponsored Participant Level | ü | ü | ü |
| Show all Risk Groups from Sponsoring Participant Level | X | ü | ü |
| Show all Risk Groups from Exchange level | X | X | ü |
| **Emergency Buttons** |  | | |
| Stop Risk Group | ü | ü | ü |
| Unstop Risk Group | X | ü | ü |
| Mass Order Cancellation | ü | ü | ü |
| Kill Switch | ü | ü | ü |
| Unstop Breached Risk Check | X | ü | ü |
| **Parameter update** |  | | |
| Add / Remove Sponsored User ID | X | ü | ü |
| Add / remove Event Notification list | X | ü | ü |
| Add / Remove Tradables | X | ü | ü |
| Change Risk Check Parameter limits | X | ü | ü |

# Operations

## Add / Remove Pre Trade Limits Group

**#FS10005\_S0040\_00100**

When a new non-base group is created, the group will be constructed with the following initial condition,

* All parameters are created in its corresponding default value.
  + Adjustable before submission.
* Empty sponsored user id list.
  + At least one user must be assigned.
* Empty Event Notification list
  + If any notification in Breach, Warning and Notice is enabled, at least one notification user ID or Email address must be assigned.
* Empty Risk Check Tradable list for Position Limit, Maximum order size and block trade size.
  + The list can be empty.

The user can modify the group before submitting to the PTRM.

**#FS10005\_S0040\_00200** The default base group is not allowed to be deleted. Adding and removing non-base group support next day effective. For removing a non-base group, the sponsored user IDs on the list will follow the handling in section 3.3.1 Existing users.

## Emergency Buttons

**#FS10005\_S0040\_00250**

The emergency buttons allow the user to control the Risk Group in different circumstances.

**Legends**
[User induced behavior]
A = Allowed
R = Rejected
[System induced behavior]
Y = Yes
N = No
N/A = Not applicable

|  |  |  |  |
| --- | --- | --- | --- |
| Sponsored Participant /Risk Group /Sponsored User State | Normal State | Block State (triggered by **Stop Button**) | Block State (triggered by **Kill Switch**) |
| **User induced behavior** | | | |
| Order/Quote Entry | A | R | R |
| Order/Quote Amendment | A | R | R |
| Order/Quote Cancellation | A | A | A |
| Block Trade submit / accept | A | R1 | R1 |
| Block Trade Amendment\* | A | R | R |
| Block Trade Cancellation\* | A | A | A |
| Query action | A | A | A |
| Manual state reset required | N/A | Y | Y after fulfilled unblock requirement |
| **System induced behavior** | | | |
| Cancel Outstanding Orders/Quotes | A | A | A |
| Cancel Block Trade\* | A | A | A |
| Receiving Broadcast | A | A | A |
| Automatic reset at day-end | A | A | A |

\*Applicable to Pending Block Trades only

1 When the Base Risk Group is in Block State, all block trade submitted by any user under the sponsored participant will be rejected.

### Stop / Unstop

**#FS10005\_S0040\_00301**

It is a toggle button that Stop Button allows both Sponsoring and Sponsored participant users to block the sponsored users place orders and quotes per Risk Group or participant.

**Stop Button**

* Stop button will change the Risk Group from Normal to Block state.
* No system-induced order cancellation action
* Reject all order placement, order amendment with or without losing pirority, market-making quotes, mass quotes actions sent from the Sponsored User under the Risk Group.
* When the Base Risk Group is stopped, all Block Trades sent from any user under the Sponsored participant will be rejected.
* Order, quotes and trade report cancellation are still allowed in Block state
* The blocking state would be reset when the PTRM has been restarted or dayend batch.

**Unstop Button**

* Unstop button will change the Risk Group from Block to Normal state.
* If any Risk Check is still breached, the Block State behavior of the corresponding Risk Check is still applicable.

### Mass Cancel

**#FS10005\_S0040\_00400** Mass cancel button allows the user to cancel all outstanding orders and pending trade reports per Risk Group or participant.

* The state of the Risk Group remains unchanged.
* Cancel all open orders, quotes and pending trade report sent by the sponsored user under the Risk Group.

### Kill Switch

**#FS10005\_S0040\_00500** It is a combo action of Stop Button and Mass Cancel. It can be executed per Risk Group and participant.

* The PTRM will execute Stop Button to change the Risk Group to Block state first, then execute the Mass Cancel to clear the orders and pending trade reports sent by the sponsored users.
* Follows the attributes of Stop Button and Mass Cancel.

### Breach / Unblock

**#FS10005\_S0040\_00600**

**Breach**

The Risk Group would be breached automatically once the corresponding Risk Check limit(s) has (have) been breached. Multiple breach events can be triggered if more than one Risk Check are breached. Each Risk Check has its own breach behavior, please refer to the corresponding Risk Check’s Breach Behavior sections.

**Unblock**

Once the Risk Check has been breached, the Risk Group can’t be unblocked until it fulfills the unblock criteria of each individual Risk Check.

## Monitoring alerts

### Notification Level (Notice and Warning %)

Each Risk Check Limit has it’s own notice and warning level in percentage.

**#FS10005\_S0040\_00700 Notice %**

It is triggered by the current Risk Check value larger than the Notice % level. The notice notification will be sent according to the Event Notification list defined in the Risk Group. The notification would only be sent once, until the value has been lowered below the Notice % or the Notice % parameter updated.

* In percentage between 0 and 99 inclusive (default in 50)
* Must be less than the **Warning %**
* Supports intraday change.

**#FS10005\_S0040\_00800 Warning %**

It is triggered by the current Risk Check value larger than the Warning % level. The warning notification will be sent according to the Event Notification list defined in the Risk Group. The notification would only be sent once, until the value has been lowered below the Notice % or the Notice % parameter updated.

* In percentage between 0 and 99 inclusive (default in 75)
* Must be larger than the **Notice %**
* Supports intraday change.

### Event Notification List

**#FS10005\_S0040\_00900**

The PTRM will inform participants when specific events occur.Notifications can be sent via email using the email address provided in the Risk Group. However, it should be noted that email delivery is not guaranteed. Additionally, user have the options to choose whether or not to receive notification for each individual event. The following cases shows the scenario when the notification is triggered.

* The first Notice % reached on the individual Risk Check.

It won’t be sent again until the Notice % has been modified or the Risk Group had been breached by any risk check.

* The first Warning % reached on the individual Risk Check.
* It won’t be sent again until the Warning % has been modified or the Risk Group had been breached by any risk check.
* Any Risk Check has been breached.
* **E**mergency buttons (STOP, Mass Cancel, Kill Switch) executed

The following example demonstrates the Event notification triggered against with the utilization variation.

![](data:image/png;base64...)

The Notice% is 50% and Warning% is 70%.

|  |  |  |
| --- | --- | --- |
| Actions | Utilization % | Event Notification |
| Place Order 1 | 45% |  |
| Place Order 2 | **55%** | NOTICE event notification triggered |
| Place Order 3 | **65%** |  |
| Place Order 4 | **75%** | WARNING event notification Triggered |
| Cancel Order 2 | **65%** | No event notification is triggered for the level changed from Warning to Notice |
| Cancel Order 3 | **55%** |  |
| Cancel Order 4 | 45% |  |
| Place Order 5 | **85%** | No event notification is triggered for the level changed to Warning again |
| Place Order 6 | **95%** |  |
| Place Order 7 | **105%** | Risk Group Breached and BREACH event notification triggered |
| Cancel Order 7 | **95%** | No event notification is triggered while the Risk Group is still in Block state |
| Unblock the Risk Group | **95%** | WARNING event notification Triggered |
| Cancel order 5 | **55%** | NOTICE event notification triggered |
| Cancel Order 6 | 45% |  |
| Place Order 8 | **105%** | Risk Group Breached and only the BREACH event notification triggered |

**#FS10005\_S0040\_01000** The attributes of the notification list are as below:

* Add notification user ID and Email Address supports intraday effective.
* Remove notification user ID and Email Address supports next day effective.
* Enable or disable notification on individual even supports next day effective.

### Audible Alerts

**#FS10005\_S0040\_01100**

When a notification event is caused, a sound alert will be triggered to notice the user.

# Risk Checks

Risk checks are designed to assess the potential risks associated with each trade or order. They typically involve calculation and validations to determine if a trade breaches any predefined risk thresholds or violates any regulatory requirements.

**#FS10005\_S0050\_00100 At Trade Risk Checks**

At Trade Risk Checks are performed after the orders have been submitted to the system. Ideally, these risk checks should be triggered immediately after the order in submitted to the system. However, due to various factors such as system latency or high order volumes, there can be delays in initiating the risk checks. This means that some orders may slip into the system and start executing before the breach calculation and valuation processes are triggered.

## Order Rate

**#FS10005\_S0050\_00200**

The order rate is a measure of the number of new orders received within a specific time period, which can be set between 1 second and 300 seconds. The order rate limit is configurable for each Risk Group and share across to all sponsored users within the Risk Group.

To implement the time interval functionality, a series of time buckets is used for each Risk Group. These buckets store the orders received within a given time interval. Specifically, there are 10 consecutive time buckets, and the length of each bucket is determined by dividing the time interval by 10.

The order rate limit check is performed by examining the sum of the most recent 9 completed time buckets, along with the number of orders in the current bucket. This sum is compared against the specified limit to determine if the limit has been exceeded. The check is carried out for each incoming transaction, as it is assigned to the current time bucket.

Examples have been illustrated in **Appendix III - Order Rate vs Time Period**

### Included / Excluded Order attributes

**#FS10005\_S0050\_00300**

* Count for order placement, quotes
* Each side of a quote will count as one new order towards the order rate.
  e.g. two side quote will be counted as 2 orders.
* Fill-or-Kill (“FoK”) and Fill-and-Kill (“FaK”) order types would be counted only if the orders are executed during OPEN trading state
* Mass Quotes will not be counted.

### Breach behavior

**#FS10005\_S0050\_00400 Breach Event**

* A breach will occur when the sum of the eligible transactions received in the most recent 10 time buckets across all users of the Risk Group exceeds the specified limit. The Risk Group will be in the Block state. The same handling applicable to the limit is set as zero and Risk Group would be breached.
* After the Risk Group is blocked by order rate limit, only order cancellation, trade report deletion are allowed. Other order placement, quotes and block trade would be rejected.
* If the Base group has breached, all block trade sent by the Sponsored Participant would be rejected.
* When the Risk Group is breached, only the order and quotes from the Sponsored User of the breached Risk Group would be rejected.
* The blocking state would be reset when the PTRM has been restarted or dayend batch.

#FS10005\_S0050\_00401

* If the Base Risk Group breached the Order Rate Limit:
  + All users within the Sponsored Participant are prohibited from performing Block Trade actions. Additionally, users in the base risk group are restricted from order and quote actions.
* If the Non-Base Risk Group breached the Order Rate Limit:
  + The order placement, order amendment, market-making quotes, mass quotes, and Block Trade actions from the Sponsored users in that specific Risk Group would be rejected.

**#FS10005\_S0050\_00500 Unblock Order Rate**

* Adjust the Order Rate Period (which effectively resets the Order Rate counter)
* Set the Order Rate Limit value to be greater than the consumed Order Rate counter.
* Manually unblock is required.

### Parameters

**#FS10005\_S0050\_00600 Order Rate Period**

It defines the time period to determine number of orders entered by the Sponsored Users.

* Adjusting the Order Rate Period would reset the Order Rate counter.
* Unit in seconds between 1 and 300
* The default value is 300
* Support Intraday change.

**#FS10005\_S0050\_00700 Order Rate Limit**

Itdefines the allowed number of orders within the order rate period.

* Unit in number of order
* between 0 and 922337203685477.
* The default value is the maximum value
* Zero value in the order rate limit would lead to immediate blocking of the Risk Group.
* Support Intraday change.

## Intraday Exposure

**#FS10005\_S0050\_00800** It is a Risk Check for monitoring and controlling accumulated exposure in futures and options trading. There are eight Risk Checks performed after order book validation. The checks include net and gross calculations for futures and options, both long and short positions. A Single risk limit applies to both long and short positions. Each trading group has coefficients for futures and options open orders, which are used as multipliers for calculating exposure.

### Unit Margin Check

**#FS10005\_S0050\_00900** To determine whether the margin check by Futures or Options calculation rule, it depends on Instrument Group setup in FS10010 - OTP-D FS - Product Structure.

### Included / Excluded Order attributes

**#FS10005\_S0050\_01001**

* Count for all order actions – order placement, order amendment with or without losing pirority, market-making quotes, mass quotes, Block Trades actions.
* For Internal Block Trades, it counts immediately when the corresponding block trade is accepted.
* For Interbank Block Trades, it counts when the corresponding block trade is matched.
* Decrement count for order cancellation.
* All trade reports are counted towards the Sponsored Participant’s Base Risk Group of the respective buyer and seller.
* Implied Orders will not be included.
* Combo and TMC legs will be counted separately into the respective risk counters.
* order amendment with or without losing pirority would lead to counting towards the Risk Group that the amendment initiator belongs to

### Breach behavior

**#FS10005\_S0050\_01100 Warnings**

There are two levels of warnings, notification, and warning level in percentage, before a breach limit is reached. Participant can set the thresholds for these levels for each Risk Group.

**#FS10005\_S0050\_01201 Breach Event**

* If the margin consumed exceeds the limit for any of the 8 Exposure Risk Checks, a breach event will be triggered. When the matching engine receives the breach event for the Risk Group, all subsequent orders, quotes, and modification, including block trades, will be rejected. However, orders already on the orderbook and the pending interbank block trade can still be matched. Users in the relevant Risk Group can still view and cancel their outstanding orders.
* The blocking state would be reset, and the Exposure Risk Check would be recalculated when the PTRM has been restarted or dayend batch.
* Unexpired orders carried forward by Genium (GTC, GTD, etc.) will be counted in the Risk Checks. If a breach occurs during reloading of these orders, the remaining carried forward orders (still in the process of being loaded) will be accepted, while new orders entered once the market is opened will be rejected.
* When the Base Risk Group is breached, all Block Trade under the sponsored participant would be rejected.

**#FS10005\_S0050\_01300 Unblock Intraday Risk Exposure**

* Can only be unblocked when the breached exposure Risk Check is smaller than the risk limit.

e.g. if the breach was triggered by **Net Futures Long** value greater than the **Net Futures Exposure Limit,** the Risk Group can be unblocked by either increase the **Net Futures Exposure Limit** or delete the Futures outstanding orders.

* Manually unblock is required.

### Margin Coefficient

**#FS10005\_S0050\_01400**

Margin Coefficients (ML – buy coefficient and MS – Sell coefficient) are uploaded by a Unit Margin Rate file in comma separated format. Each instrument has margin coefficients for buy and sell orders. The coefficient is a positive whole number with 4 implicit decimals.

These coefficients are loaded during the start of day and able to be manually updated if needed. New series created during trading hours without margin rate references are excluded from the calculation. Unit margin Risk Checks are based on information received after orders are inserted into the orderbook, so it’s possible for orders above the configured limit to be accepted and placed in the orderbook.

**I**n start of day, the unit margin rate file is generated. The PTRM retrieves the margin coefficient from the file. If the unit margin rate file is not generated by the expected time, the task to load the file will timeout and trigger an alert in the system monitoring console indicating that the file is unavailable. In this situation, the most recent version of the unit margin rate file can be uploaded manually by the data center operation menu to proceed with the PTRM initialization. On holiday (e.g. First day of new year and weekend) a pre-defined unit margin rate file would be loaded and the margin coefficient for all instruments are zero.

If the margin coefficient needs to be updated after the initialization is completed, a new unit margin rate file containing the updated coefficient can be uploaded to PTRM. The new margin coefficient will take effect for the next order and trade activities. The previously calculated margin consumption will not be re-calculated.

For intraday created Instrument, there will be no Margin Coefficient for the newly created series until it appears in the Unit Margin Rate file in the next trading day.

### Exposure Risk Check parameters and Formula

**#FS10005\_S0050\_01500 Intraday Exposure check formula**

|  |  |
| --- | --- |
| Exposure Risk Checks parameters | Formula |
| Net Futures Long | ∑(OpenBuyFuturesQuantityi × FC × MLi) + ∑(TradedBoughtFuturesQuantityi × MLi) - ∑(TradedSoldFuturesQuantityi × MSi) |
| Net Futures Short | ∑(OpenSellFuturesQuantityi × FC × MSi) + ∑(TradedSoldFuturesQuantityi × MSi) - ∑(TradedBoughtFuturesQuantityi × MLi) |
| Gross Futures Long | ∑(OpenBuyFuturesQuantityi × FC × MLi) + ∑(TradedBoughtFuturesQuantityi × MLi) |
| Gross Futures Short | ∑(OpenSellFuturesQuantityi ×F C × MSi) + ∑(TradedSoldFuturesQuantityi × MSi) |
| Net Options Long | ∑(OpenBuyCallQuantityi × OC × MLi) + ∑(OpenSellPutQuantityi × OC × MSi) + ∑(TradedBoughtCallQuantityi × MLi) - ∑(TradedSoldCallQuantityi × MSi) + ∑(TradedSoldPutQuantityi × MSi) - ∑(TradedBoughtPutQuantityi × MLi) |
| Net Options Short | ∑(OpenSellCallQuantityi × OC × MSi) + ∑(OpenBuyPutQuantityi × OC × MLi) + ∑(TradedSoldCallQuantityi × MSi) - ∑(TradedBoughtCallQuantityi × MLi) + ∑(TradedBoughtPutQuantityi × MLi) - ∑(TradedSoldPutQuantityi × MSi) |
| Gross Options Long | ∑(OpenBuyCallQuantityi × OC × MLi) + ∑(OpenSellPutQuantityi × OC × MSi) + ∑(TradedBoughtCallQuantityi × MLi) + ∑(TradedSoldPutQuantityi × MSi) |
| Gross Options Short | ∑(OpenSellCallQuantityi × OC × MSi) + ∑(OpenBuyPutQuantityi × OC × MLi) + ∑(TradedSoldCallQuantityi × MSi) + ∑(TradedBoughtPutQuantityi × MLi) |

**#FS10005\_S0050\_01600 Futures Order Coefficient (FC)**

It serves as a multiplier for the value of open futures orders in relation to consumption.

* In percentage between 0 and 100 (default in 100)
* Supports next day change.

**#FS10005\_S0050\_01700 Options Order Coefficient (OC)**

It serves as a multiplier for the value of open options orders in relation to consumption.

* In percentage between 0 and 100 (default in 100)
* Supports next day change.

**#FS10005\_S0050\_01800 Net Futures Exposure Limit**

It is the limit of Net Futures Long Risk Check and Net Futures Short Risk Check, either one of the Risk Check value larger than the limit would trigger the breach in Intraday Exposure Risk Check.

**#FS10005\_S0050\_01900 Gross Futures Exposure Limit**

It is the limit of Gross Futures Long Risk Check and Gross Futures Short Risk Check, either one of the Risk Check value larger than the limit would trigger the breach in Intraday Exposure Risk Check.

**#FS10005\_S0050\_02000 Net Options Exposure Limit**

It is the limit of Net Options Long Risk Check and Net Options Short Risk Check, either one of the Risk Check value larger than the limit would trigger the breach in Intraday Exposure Risk Check.

**#FS10005\_S0050\_02100 Gross Options Exposure Limit**

It is the limit of Gross Options Long Risk Check and Gross Options Short Risk Check, either one of the Risk Check value larger than the limit would trigger the breach in Intraday Exposure Risk Check.

**#FS10005\_S0050\_02150** The following attributes apply to those 4 exposure limits.

* Units in HKD between 0 and 922,337,203,685,477.
* The default value is the maximum value.
* Set to 0 will breach the Risk Group immediately.
* Supports intraday change.
* Across all user IDs under the same Risk Group
* Accumulated for the whole business day
* Reset to zero during system startup
* Reloaded GTC/GTD orders will contribute to the credit consumption

**#FS10005\_S0050\_02200 Notice %**

**#FS10005\_S0050\_02300 Warning %**

Applies to each Exposure Risk Check and follows the attributes in section *4.3.1. Notification Level (Notice and Warning %)*

## Execution Throttle Exposure

**#FS10005\_S0050\_02400** The execution throttle Risk Check specifically monitor the Gross Options Long / Short Per Time and Gross Futures Long / Short Per Time. **#FS10005\_S0050\_02500** As like Order Rate Limit, the consumption for the execution throttle checks only includes values within the most recent execution throttle period, which will be divided into a 10 bucket moving window. Consumption per bucket is accumulated, with total consumption consisting of the consumption in the current bucket, plus the sum of the consumption in the 9 previous buckets.

### Margin Coefficient

**#FS10005\_S0050\_02600** Refer to 5.2.3 Margin coefficient for Intraday Exposure

### Included / Excluded Order attributes

**#FS10005\_S0050\_02700**

* Trade triggered by order actions – order placement, order amendment with or without losing pirority, market-making quotes, mass quotes actions.
* FOK and FAK orders are included when traded during OPEN trading state
* On-behalf trades and trades from internal transactions
* Single Party trade reports and two party trade reports are excluded.

### Breach behavior

**Warnings**

**#FS10005\_S0050\_02800** There are two levels of warnings, notification, and warning level in percentage, before a breach limit is reached. Participant can set the thresholds for these levels for each Risk Group.

**Breach Event**

* **#FS10005\_S0050\_02900** If the Execution throttle exceeds the limit for any of the Risk Checks, a breach event will be triggered. When the matching engine receives the breach event for the Risk Group, all subsequent orders, quotes, and modification, including block trades, will be rejected. However, orders already on the orderbook can still be matched. Users in the relevant Risk Group can still view and cancel their outstanding orders.
* **#FS10005\_S0050\_03000** The blocking state would be reset when the PTRM has been restarted or dayend batch.

**#FS10005\_S0050\_03001**

* If the Base Risk Group breached the Execution Throttle Limit:
  + All users within the Sponsored Participant are prohibited from performing Block Trade actions. Additionally, users in the base risk group are restricted from order and quote actions.
* If the Non-Base Risk Group breached the Execution Throttle Limit:
  + The order placement, order amendment, market-making quotes, mass quotes, and Block Trade actions from the Sponsored users in that specific Risk Group would be rejected.

**Unblock Execution Throttle Exposure**

**#FS10005\_S0050\_03100**

* Can only be unblocked when the breached execution throttle Risk Check is smaller than the risk limit.
* Adjust the execution throttle Period (which effectively resets the throttle counter)
* Set the Limit value to be greater than the consumed throttle counter.
* Manually unblock is required.

### Risk Check parameters and Formula

**#FS10005\_S0050\_03200 Execution Throttle** **check formula**

|  |  |
| --- | --- |
| Execution Throttle Risk Checks parameters | Formula |
| Gross Futures Long Per Time | ∑(TradedBoughtFuturesQuantityi × MLi) |
| Gross Futures Short Per Time | ∑(TradedSoldFuturesQuantityi × MSi) |
| Gross Options Long Per Time | ∑(TradedBoughtCallQuantityi × MLi) + ∑(TradedSoldPutQuantityi × MSi) |
| Gross Options Short Per Time | ∑(TradedSoldCallQuantityi × MSi) + ∑(TradedBoughtPutQuantityi × MLi) |

**#FS10005\_S0050\_03300 Gross Futures Execution Throttle Limit**

It is the limit of Gross Futures Long Per Time and Gross Futures Short Per Time, either one of the throttle value larger than the limit would trigger the breach in Execution Throttle Risk Check.

**#FS10005\_S0050\_03400 Gross Options Execution Throttle Limit**

It is the limit of Gross Options Long Per Time and Gross Options Short Per Time, either one of the throttle value larger than the limit would trigger the breach in Execution Throttle Risk Check.

**#FS10005\_S0050\_03500** The following attributes apply to those 2 execution throttle limits.

* Units in HKD between 0 and 922,337,203,685,477.
* The default value is the maximum value.
* Set to 0 will breach the Risk Group immediately.
* Changing the value would reset the throttle counter to zero.
* Across all user IDs under the same Risk Group
* Supports intraday change.

**#FS10005\_S0050\_03600** **Execution Throttle Period**

It defines the time in second to determine the executed Gross Futures / Options within the period.

* Adjusting the Execution Throttle Period would reset the throttle counter.
* Unit in seconds between 300 and 600
* The default value is 600
* Support Intraday change.

**#FS10005\_S0050\_03700 Execution Throttle Per Time Notice %**

**#FS10005\_S0050\_03800 Execution Throttle Per Time Warning %**

Applies to each Execution Throttle Risk Check and follows the attributes in section *4.3.1. Notification Level (Notice and Warning %)*

## Order Exposure Reference

**#FS10005\_S0050\_03900** There are 4 risk counters in Gross Futures Long/Short and Gross Options Long/Short Risk Checks. The counters only consumed with open orders. They are read-only and no limit are set for these counters.

### Margin Coefficient

Refer to 5.2.3 Margin coefficient for Intraday Exposure

### Included / Excluded Order attributes

**#FS10005\_S0050\_04000**

* Increment or decrement count for all order actions – order placement, order amendment with or without losing pirority, market-making quotes, mass quotes actions.
* Decrement count for order cancellation.
* Implied Orders will not be included.
* Combo legs will be counted separately into the respective risk counters.

### Breach behavior

Not applicable

### Risk Check parameters and Formula

**#FS10005\_S0050\_04100 Order Exposure Reference Counter formula**

|  |  |
| --- | --- |
| Order Exposure Reference counters | Formula |
| Gross Futures Long (Open) | ∑(OpenBuyFuturesQuantityi) x **MLi** |
| Gross Futures Short (Open) | ∑(OpenSellFuturesQuantityi) x **MSi** |
| Gross Options Long (Open) | ∑(OpenBuyCallQuantityi) x **MLi** + ∑(OpenSellPutQuantityi) x **MSi** |
| Gross Options Short (Open) | ∑(OpenSellCallQuantityi) x **MSi** + ∑(OpenBuyPutQuantityi) x **MLi** |

## Position Limits

**#FS10005\_S0050\_04200** The Position Limits control two types of parameters, order & trade position and block trade.

### Tradables attributes

**#FS10005\_S0050\_04301**

* Can be defined per all available Instrument Class, Instrument Type and Market
* For Market Tradables, it aggregates all Instrument Class, Instrument Type, Combo Class and Combo Type positions.
* The tradables will associate with maximum order size, maximum block trade size and all position limit parameters.
* Add or remove tradable supports next day effective.

### Included / Excluded Order attributes

**Order & Trade position**

**#FS10005\_S0050\_04400**

* It counts for order placement, order amendment with or without losing pirority, market-making quote and mass quote.
* Reloading the GTC or GTD orders will not be re-validated with the limit.
* For combination series, it will count separately to its respective legs.

*For example, a combo series with quantity 1 would count as 1 for open buy order and 1 for open sell order respectively.*

* Implied orders will not be validated against with the leg series.

**Block Trade**

**#FS10005\_S0050\_04501**

* For Block trade counters, it counts for Internal Trade Report, Combo Trade Report and Interbank Trade Report
* It is counted into the sponsored participant’s Base Risk Group which contains the sponsored user who submit the block trade.
* The pending Interbank Trade Report will not be counted until it’s been accepted by the counterparty.
* For interbank Trade Report, it is counted into the sponsored participant’s Base Risk Group which contains the sponsored user who submit and accept the block trade
* Support Intraday created series.

### Breach behavior

**Warnings

#FS10005\_S0050\_04600**

There are two levels of warnings, notification, and warning level in percentage, before a breach limit is reached. Participant can set the thresholds for these levels for each Risk Group.

**Breach Event**

**#FS10005\_S0050\_04701**

* If any of the counter exceeds its corresponding limit, a breach event will be triggered on the specific tradable. Only the subsequent orders, quotes, and modification, including block trades, on the breached tradable will be rejected. However, orders already on the orderbook can still be matched. Users in the relevant Risk Group can still view and cancel their outstanding orders.

*For example, if position limit has been breached by HSI Futures tradable, all HSI Futures orders, quotes, and modification, including block trades will be rejected. Transactions in other instruments (e.g. HSI Options, MHI Futures and other tradables) would not be rejected.*

* If either the market, instrument type or instrument class of the same underlying di defined and a breach occurs in any of the tradables, the order in this underlying will be rejected as a result of the breach.
* For One-sided Trade Report, if the counterparty’s trade report limit has already been breached, the trade report transaction will not be rejected, but the counterparty cannot accept the pending trading report until it’s been unblocked.

*For example, SHK’s base group has breached HSI Futures trade report limit. KGI can still send a one-side Trade report on HSI Futures with counterparty as SHK. If SHK accepts the pending trade report, it would be rejected by the breached trade report limit.*

* The blocking state would be reset after the dayend batch.

if any position limit counter for a specific product in the Base Risk Group is breached, no Block Trades will be allowed from any users within the same Sponsored Participant for that particular market, instrument type, or instrument class.

**Unblock Position Limit**

**#FS10005\_S0050\_04800**

* Can only be unblocked when all the breached tradable’s counters are smaller than the limit.
* Set the Limit value to be greater than the consumed limit counter.
* Manually unblock is required.

### RiskCheck parameters and Formula

**#FS10005\_S0050\_04900** Position Limit Counters formula

|  |  |
| --- | --- |
| **Position Limit Counters** | **Formula** |
| Open Buy | ∑(OpenBuyOrdersQuantityi) |
| Open Sell | ∑(OpenSellOrdersQuantityi) |
| Traded Bought | ∑(TradedBoughtQuantityi) |
| Traded Sold | ∑(TradedSoldQuantityi) |
| Total Buy | ∑(OpenBuyOrdersQuantityi) + ∑(TradedBoughtQuantityi) |
| Total Sell | ∑(OpenSellOrdersQuantityi) + ∑(TradedSoldQuantityi) |
| Traded Net | | ∑(TradedBoughtQuantityi) - ∑(TradedSoldQuantityi) | |
| Total Net Buy | ∑(TradedBoughtQuantityi) - ∑(TradedSoldQuantityi) + ∑(OpenBuyOrdersQuantityi) |
| Total Net Sell | ∑(TradedSoldQuantityi) - ∑(TradedBoughtQuantityi) + ∑(OpenSellOrdersQuantityi) |
| Block Trade Bought | ∑(TradedBoughtBlockTradeQuantityi) |
| Block Trade Sold | ∑(TradedSoldBlockTradeQuantityi) |

Note:

∑(TradedBoughtQuantityi)does not include Block Trade Bought quantity.

∑(TradedSoldQuantityi) does not include Block Trade Sold quantity.

**#FS10005\_S0050\_05000**

Each tradable contains the following position limit parameters:

**Open Buy Limit**

**Open Sell Limit**

**Traded Bought Limit**

**Traded Sold Limit**

**Total Buy Limit**

**Total Sell Limit**

**Traded Net Limit**

**Total Net Buy Limit**

**Total Net Sell Limit**

**Block Trade Bought Limit**

**Block Trade Sold Limit**

The following attributes apply to those limits.

* Units in quantity between 0 and 922,337,203,685,477.
* The default value is the maximum value.
* Set to 0 will breach the corresponding tradable’s position Limit immediately.
* Across all user IDs under the same Risk Group.
* Modify the limit value supports Intraday change.
* Add / Remove tradable support next day change.
* Can be updated and imported in a comma separated format file.

**#FS10005\_S0050\_05100 Notice %**

**#FS10005\_S0050\_05200 Warning %**

Applies to Position Limits and follows the attributes in section *4.3.1. Notification Level (Notice and Warning %)*

**#FS10005\_S0050\_05300 Pre Trade Risk Checks**

It is conducted prior to order and trade execution and ensure that the order meets the necessary criteria. The order violates the risk check requirements would be rejected by the system immediately, before placed into the orderbook.

## Order Size

**#FS10005\_S0050\_05400** It is the maximum order quantity Risk Check to determine on a per Risk Group basis for each defined tradable (Market / Instrument type / Instrument class / Combo Type / Combo Class). When an order or quote is entered through a Risk Group, the PTRM system checks the limits set for the corresponding type and class of the order book, which is determined by the smaller of the two limits. The order or quote will be rejected if the quantity exceeds either of these limits.

### Tradables attributes

**#FS10005\_S0050\_05500**

* Can be defined per Market, Instrument Class, Instrument Type, Combo Class and Combo Type.
* The tradables will associate with the order size limit parameter.
* Add or remove tradable supports next day effective.

### Included / Excluded Order attributes

**#FS10005\_S0050\_05600**

* Count for order placement, order amendment with or without losing pirority, market-making quote, and mass quote
* Reloading the GTC or GTD orders will not be re-validated with the limit.
* Combo order would only check against the combo maximum order size.
* Implied orders will not be validated against with the leg series.

### Breach behavior

**#FS10005\_S0050\_05700**

* Orders with quantity exceeding the limit would be rejected
* It is applied to each order separately and will NOT trigger a breach.
* ejection of one order does not affect the validation of subsequent orders, which are evaluated independently.
* If either the buy or sell side quote’s quantity breached the limit, both sides will be rejected. However, mass quote for other instrument will still be accepted as long as they pass all validation criteria.

e.g. The order size limit of HSI Futures is set as 50 and HHI Futures is set as 100 for user XYZ001’s Risk Group.

User XYZ001 place a mass quote in

* + HSIU3 BUY 10 SELL 60
  + HHIU3 BUY 50 and SELL 80.

The quote for HSIU3 would be rejected by the Order size limit breached, but HHIU3 is accepted.

* The Instrument and Combination are monitored separately.

e.g. Combo order would only check against the combo maximum order size limit. The Net exposure of legs will not be validated against the specified limit in the Market / Instrument type / class tradable.

* The more restrictive setting would be applied when Market, Instrument Type, Instrument Class, Combo Type and Combo Class tradable are defined.

### Parameters

**Maximum Order Size (per tradable)**

**#FS10005\_S0050\_05800**

* Units in quantity between 0 and 922,337,203,685,477.
* The default value is maximum value. It would be applied when adding a new tradable.
* Value 0 will cause rejection for any order and quote from the corresponding tradable.
* Modify the limit value supports Intraday change.
* Add / Remove tradable support next day change.
* Can be updated and imported in a comma separated format file.

## Block Trade Size

**#FS10005\_S0050\_05900** It is a distinct process where block trade transactions are identified separately and subjected to validation against the maximum block trade size, while normal orders and quotes are exempted from this validation. Once the Base Risk Group is breached, the Block Trade transaction will be rejected before the Max Block Trade Size validation.

### Tradables attributes

**#FS10005\_S0050\_06000**

* Can be defined per Market, Instrument Class and Instrument Type
* The tradables will associate with the block Trade size limit parameter.
* Add or remove tradable supports next day effective.

### Included / Excluded Order attributes

**#FS10005\_S0050\_06100**

* Count for block trade transactions only.
* Block trade size controls for combos is not supported
* Count into the submitter and accepter’s Risk Group

### Breach behavior

**#FS10005\_S0050\_06200**

* The limit is controlled and counted by the submitter and accepter’s Risk Group
* Trade quantity exceeding the limit would be rejected
* It is applied to each block trade separately, and will NOT trigger a breach.
* Multi-leg Block Trades would be rejected if any one of the legs fails the limit check
* Breached on a whichever is lower basis given either Market, instrument type and instrument class are set as tradables
* Cross party Block Trade would be rejected if the quantity inputted by the counterparty is greater than the set limit
* The more restrictive setting would be applied when Market, Instrument Type, Instrument Class, Combo Type and Combo Class tradable are defined.

### Parameters

**Maximum Block Trade Size (per tradable)**

**#FS10005\_S0050\_06300**

* Units in quantity between 0 and 922,337,203,685,477.
* The default value is maximum value. It would be applied when adding a new tradable.
* Value 0 will cause rejection for any block trade from the corresponding tradable.
* Modify the limit value supports Intraday change.
* Add / Remove tradable support next day change.
* Can be updated and imported in a comma separated format file.

# Reports

## Audit Reports

**#FS10005\_S0060\_00100**

A daily report is generated in real-time that logs all actions and events per Sponsoring Participant and Exchange. The audit event will include the time stamp, event type, involved Risk Group and user id.

The following event types will be shown in the report.

* Add or remove non-base Risk Group
* Risk Group parameter updated
* Breach Event Triggered
* Emergency Button executed
* Any order, quote or trade report transaction rejected by max order size and block trade size (first n )

**#FS10005\_S0060\_00200**

The audit report specification is as below:

| **Column** | **Description** | **Value** |
| --- | --- | --- |
| Timestamp | Generation Time | YYYYMMDD-HH:MM:SS |
| Sponsoring Participant | Participant Code | e.g. HKCJPM |
| Sponsoed Participant | Participant Code | e.g. HKJPMMB |
| Risk Group | Risk Group ID | e.g. HKCJPM\_HKJPM\_BASE |
| Category | A Risk Group is Breached | BREACH |
| A Risk Group is Unbreached | UNBREACH |
| Order rejected by PTRM | REJECT |
| Emergency button executed | SUPERVISORY ACTION |
| Parameters update | REF DATA |
| User | The user ID triggered the audit event | e.g. KGI161 will be recorded, if it sent an order to breach a Risk Check or the order rejected by PTRM. P\_CKGI1234 will be recoreded if it executed the emergency button or updated a parameter |
| Action | Record "UPDATE" when it is a parameter update | UPDATE |
| Effective | The effective day of the event | INTRADAY or TOMORROW |
| Item | A Risk Group is breached or Unbreached | Blank due to not applicable for this event |
| Order rejected by PTRM | Blank due to not applicable for this event |
| Emergency button executed | STOP |
| UNSTOP |
| MASS CANCEL |
| Parameters update | Risk Check Parameter (Tradable if applicable) e.g.  NET\_FUTURES\_LONG OPEN\_BUY (HSIF) |
| Old Value | Value before update, only applicable to Parameters update Category | 0 to 922337203685477 |
| New Value | Value after update, only applicable to Parameters update Category | e.g. MAX\_BLOCK\_TRADE\_SIZE OPEN\_BUY (HSIF) |
| Event Level | Only applicable when the Risk Group is breached | BREACH |
| Event Risk Check | The breached Risk Check Type. Only applicable when the Risk Group is breached | e.g. BLOCK\_TRADE\_BOUGHT GROSS\_FUTURES\_LONG\_PER\_TIME |
| Event Order ID | The order ID triggered the breach event.  Only applicable when the Risk Group is breached | Order ID |
| Event Side | The bid or ask side of the order triggered the breach event.  Only applicable when the Risk Group is breached | BUY or SELL |
| Series Name | Series name of the order triggered the breach event.  Only applicable when the Risk Group is breached | e.g. HSIZ3 |
| Reject Code | Reject reason to reject the order Only applicable for REJECT category | e.g. RX\_PRETRADE\_USER\_BLOCKED |

Note:

**#FS10005\_S0060\_00300**

To prevent excessively large report sizes caused by logging a high volume of reject orders, a configurable limit will be implemented to record the total number of rejected orders in each audit report. This limit can be adjusted, allowing for efficient and manageable auditing of rejected orders without overwhelming the system with an excessively large report.

When the limit is reached, the system would generate a warning log in the backend and warning message in the PTRM GUI to alert the user large number of reject orders have been rejected. Then, the audit event would be continued in a new log file with a new version in the report file name. e.g.

From RX\_AUDIT\_-\_\_000-HK-CWLG\_-241019.LIS to RX\_AUDIT\_-\_\_001-HK-CWLG\_-241019.LIS

## Utilization Reports

**#FS10005\_S0060\_01000**

A daily reports generates the utilization statistic of risk limits for each Risk Group. The report is generated per Sponsoring Participant and Exchange in dayend state. For each risk check, the following utilization will be shown in the report.

* Maximum value of the day
* The timestamp of the order to hit the maximum value occurred
* The percentage of the maximum utilization in the risk check limit
* For Position Limit, Order Size, and Block Trade limits, the utilization is shown in each parameter limit per tradable.

The utilization report specification is as below:

| **Column** | **Description** | **Value** |
| --- | --- | --- |
| Timestamp | Generation Time | YYYYMMDD-HH:MM:SS |
| Sponsoring Participant | Participant Code | e.g. HKCJPM |
| Sponsored Participant | Participant Code | e.g. HKJPMMB |
| Risk Group | Risk Group ID | e.g. HKCJPM\_HKJPM\_BASE |
| Risk Check Level | Position Limit | Shows in Tradable ID. E.g. HSIF, SOMC |
| Block Trade Limit |
| Order Size |
| Block Trade |
| Order Rate | Shows as GROUP |
| Intraday Exposure |
| Execution Throttle Exposure |
| Order Exposure Reference |
| Risk Check | Parameters in Order Rate | ORDER\_RATE |
| Parameters in Intraday Exposure | GROSS\_FUTURES\_LONG |
| GROSS\_FUTURES\_SHORT |
| GROSS\_OPTIONS\_LONG |
| GROSS\_OPTIONS\_SHORT |
| NET\_FUTURES\_LONG |
| NET\_FUTURES\_SHORT |
| NET\_OPTIONS\_LONG |
| NET\_OPTIONS\_SHORT |
| Parameters in Execution Throttle Exposure | GROSS\_FUTURES\_LONG\_PER\_TIME |
| GROSS\_FUTURES\_SHORT\_PER\_TIME |
| GROSS\_OPTIONS\_LONG\_PER\_TIME |
| GROSS\_OPTIONS\_SHORT\_PER\_TIME |
| Parameters in Order Exposure Reference | OPEN\_GROSS\_FUTURES\_LONG |
| OPEN\_GROSS\_FUTURES\_SHORT |
| OPEN\_GROSS\_OPTIONS\_LONG |
| OPEN\_GROSS\_OPTIONS\_SHORT |
| Parameters in Position Limit | OPEN\_BUY |
| OPEN\_SELL |
| ORDER\_RATE |
| RiskType |
| TOTAL\_BUY |
| TOTAL\_NET\_BUY |
| TOTAL\_NET\_SELL |
| TOTAL\_SELL |
| TRADED\_BOUGHT |
| TRADED\_NET |
| TRADED\_SOLD |
| Parameters in Block Trade Limit | BLOCK\_TRADE\_BOUGHT |
| BLOCK\_TRADE\_SOLD |
| Parameters in Block Trade Size | MAX\_BLOCK\_TRADE\_SIZE |
| Parameters in Order Size | MAX\_SIZE |
| Max Utilization | The maximum value from SOD to EOD | 0 to 922337203685477 |
| Max Utilization % | % | 0 to 100% |
| Max Utilization Time | The maximum value happening time | HH:MM:SS or N/A if the utilization is 0 |

# Disable PTRM

**#FS10005\_S0070\_01000**

There is a switch to isolate the PTRM from the matching engine in case of any unrecoverable issues with the PTRM. Once this isolation switch is activated, the matching engine will disregard all PTRM checks and messages. This switch takes effect immediately and remains active until the end-of-day batch

# APPENDIX I – Risk Checks behavior in Normal and Blocked state

#FS10005\_S0070\_00101

|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | **At Trade Risk Checks** | | | | | | | | | | **Pre Trade Risk Checks** | | | |
| **Order Rate** | | **Intraday Exposure** | | **Execution Throttle** | | **Position Limit** | | **Block Trade Limit** | | **Order Size** | | **Block Trade Size** | |
| **Normal** | **Breach/  Blocked** | **Normal** | **Breach/  Blocked** | **Normal** | **Breach/  Blocked** | **Normal** | **Breach/  Blocked** | **Normal** | **Breach/  Blocked** | **Normal** | **Breach/  Blocked** | **Normal** | **Breach/  Blocked** |
| Order/Quote Entry | Y | R | Y | R | Y1 | R | Y | R2 | N |  | Y | N/A | N | N/A |
| Order/Quote Amendment | N | R | Y | R | Y1 | R | Y | R2 | N |  | Y | N |
| Order/Quote Cancellation | Y | A | Y | A | N | A | Y | A | N |  | N | N |
| Trade Report Entry | N | R1 | Y | R1 | N | R1 | N | R1 | Y | R1 | N | Y (SG) |
| Combo Trade Report Entry | N | R1 | Y | R1 | N | R1 | N | R1 | Y | R1 | N | Y (SG) |
| Interbank Trade Report - one side | N | R1 | Y1 | R1 | N | R1 | N | R1 | Y2 | R1 | N | Y(SG) |

Y - Count by the Risk Check

Y1 - Count after Matched

Y2 - Count for the Trade report sender's Participant’s Base Risk Group . The counterparty's Risk Group won't be checked until the counterparty send the accept transaction

N - Not count by the Risk Check

A - Accept the transaction

R - Reject the transaction

R1 - Reject the orders either the Sponsored user's Risk Group or the Base Group is blocked.

R2 - Reject the orders in corresponding tradable instrument

SG - Sponsored user's non Base Group

BG - Sponsored Part. Base Group

# APPENDIX II – Risk Check Parameters attributes

#FS10005\_S0070\_00200

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
| **Risk Check** | **Parameters** | **Unit** | **Range** | **Default** | **Intraday?** |
| Order Rate | Order Rate Period | second | 1 - 300 | 300 | Y |
| Order Rate Limit | per Txn | 0 - Max | Max | Y |
| Intraday Exposure | Futures Order Coefficient | % | 0 - 100 | 100 | N |
| Options Order Coefficient | % | 0 - 100 | 100 | N |
| Net Futures Exposure Limit | HKD | 0 - Max | Max | Y |
| Gross Futures Exposure Limit | HKD | 0 - Max | Max | Y |
| Net Options Exposure Limit | HKD | 0 - Max | Max | Y |
| Gross Options Exposure Limit | HKD | 0 - Max | Max | Y |
| Notice% | % | 0 - 100  (< Warning%) | 50 | Y |
| Warning% | % | 0 - 100  (> Notice%) | 75 | Y |
| Execution Throttle | Gross Futures Execution Throttle Limit | HKD | 0 - Max | Max | Y |
| Gross Options Execution Throttle Limit | HKD | 0 - Max | Max | Y |
| Execution Throttle Period | second | 300 - 600 | 600 | Y |
| Notice% | % | 0 - 100 | 50 | Y |
| Warning% | % | 0 - 100 | 75 | Y |
| Tradables\* | Add / Remove | N/A | | | N |
| Position Limit  (Per Tradable) | Open Buy Limit | Quantity | 0 - Max | Max | Y |
| Open Sell Limit | Quantity | 0 - Max | Max | Y |
| Traded Bought Limit | Quantity | 0 - Max | Max | Y |
| Traded Sold Limit | Quantity | 0 - Max | Max | Y |
| Total Buy Limit | Quantity | 0 - Max | Max | Y |
| Total Sell Limit | Quantity | 0 - Max | Max | Y |
| Traded Net Limit | Quantity | 0 - Max | Max | Y |
| Total Net Buy Limit | Quantity | 0 - Max | Max | Y |
| Total Net Sell Limit | Quantity | 0 - Max | Max | Y |
| Block Trade Limit (Per Tradable) | Block Trade Bought Limit  (applicable to base group only**)** | Quantity | 0 - Max | Max | Y |
| Block Trade Sold Limit  (applicable to base group only**)** | Quantity | 0 - Max | Max | Y |
| Notice%  (Share between Position & Block Trade Limit) | % | 0 - 100 | 50 | Y |
| Warning% (Share between Position & Block Trade Limit) | % | 0 - 100 | 75 | Y |
| Order Size (Per Tradable) | Maximum Order Size | Quantity | 0 - Max | Max | Y |
| Block Trade Size (Per Tradable) | Maximum Block Trade Size | Quantity | 0 - Max | Max | Y |

Max = 922337203685477

Tradable\* - Applicable to Position Limit, Block Trade Limit, Order Size and Block Trade Size

# APPENDIX III – Order Rate vs Time Period

![](data:image/png;base64...)

| **Time** | **Order Rate Limit** | **Order Rate Period** | **Num of Txn** | **Order Rate** | **State** | **Event** |
| --- | --- | --- | --- | --- | --- | --- |
| 9:30:00 | 30 | 60 | 4 | 4 | NORMAL |  |
| 9:30:06 | 30 | 60 | 8 | 12 | NORMAL |  |
| 9:30:12 | 30 | 60 | 1 | 13 | NORMAL |  |
| 9:30:18 | 30 | 60 | 3 | 16 | NORMAL |  |
| 9:30:24 | 30 | 60 | 0 | 16 | NORMAL |  |
| 9:30:30 | 30 | 60 | 2 | 18 | NORMAL |  |
| 9:30:36 | 30 | 60 | 4 | 22 | NORMAL |  |
| 9:30:42 | 30 | 60 | 1 | 23 | NORMAL |  |
| 9:30:48 | 30 | 60 | 2 | 25 | NORMAL |  |
| 9:30:54 | 30 | 60 | 2 | 27 | NORMAL |  |
| 9:31:00 | 30 | 60 | 4 | 27 | NORMAL |  |
| 9:31:06 | 30 | 60 | 25 | 44 | BREACH | Order Rate Breach Triggered |
| 9:31:12 | 30 | 60 | 0 | 43 | BREACH |  |
| 9:31:18 | 50 | 60 | 0 | 0 | BREACH | Change Order Rate Limit to 50 |
| 9:31:24 | 50 | 60 | 0 | 0 | NORMAL | Unbreach Order Rate |
| 9:31:30 | 50 | 60 | 2 | 2 | NORMAL |  |
| 9:31:36 | 50 | 60 | 13 | 15 | NORMAL |  |
| 9:31:42 | 50 | 60 | 11 | 26 | NORMAL |  |
| 9:31:48 | 50 | 60 | 18 | 44 | NORMAL |  |
| 9:31:54 | 50 | 60 | 22 | 66 | BREACH |  |
| 9:32:00 | 50 | 60 | 0 | 66 | BREACH |  |
| 9:32:06 | 50 | 60 | 0 | 66 | BREACH |  |
| 9:32:12 | 50 | 60 | 0 | 66 | BREACH |  |
| 9:32:18 | 50 | 60 | 0 | 66 | BREACH |  |
| 9:32:24 | 50 | 60 | 0 | 66 | BREACH |  |
| 9:32:30 | 50 | 60 | 0 | 64 | BREACH |  |
| 9:32:36 | 50 | 60 | 0 | 51 | BREACH |  |
| 9:32:42 | 50 | 60 | 0 | 40 | NORMAL | Unbreach Order Rate |
| 9:32:48 | 50 | 60 | 0 | 22 | NORMAL |  |
| 9:32:54 | 50 | 60 | 0 | 0 | NORMAL |  |
| 9:33:00 | 50 | 60 | 12 | 12 | NORMAL |  |
| 9:33:06 | 50 | 60 | 23 | 35 | NORMAL |  |
| 9:33:12 | 50 | 60 | 10 | 45 | NORMAL |  |
| 9:33:15 | 50 | 30 | 2 | 2 | NORMAL | Change Order Rate Period to 30 |
| 9:33:18 | 50 | 30 | 2 | 4 | NORMAL |  |
| 9:33:21 | 50 | 30 | 4 | 8 | NORMAL |  |
| 9:33:24 | 50 | 30 | 8 | 16 | NORMAL |  |
| 9:33:27 | 50 | 30 | 12 | 28 | NORMAL |  |
| 9:33:30 | 50 | 30 | 2 | 30 | NORMAL |  |
| 9:33:33 | 50 | 30 | 12 | 42 | NORMAL |  |
| 9:33:36 | 50 | 30 | 4 | 46 | NORMAL |  |
| 9:33:39 | 50 | 30 | 1 | 47 | NORMAL |  |
| 9:33:42 | 50 | 30 | 1 | 48 | NORMAL |  |
| 9:33:45 | 50 | 30 | 15 | 61 | BREACH | Order Rate Breach Triggered |
| 9:33:48 | 50 | 30 | 0 | 59 | BREACH |  |
| 9:33:51 | 50 | 30 | 0 | 55 | BREACH |  |
| 9:33:54 | 50 | 30 | 0 | 47 | BREACH |  |
| 9:33:57 | 50 | 30 | 0 | 35 | BREACH |  |
| 9:34:00 | 50 | 30 | 0 | 33 | BREACH |  |
| 9:34:03 | 50 | 30 | 0 | 21 | BREACH |  |
| 9:34:06 | 50 | 30 | 0 | 17 | BREACH |  |
| 9:34:09 | 50 | 30 | 0 | 16 | BREACH |  |
| 9:34:12 | 50 | 30 | 0 | 15 | BREACH |  |
| 9:34:15 | 50 | 30 | 0 | 0 | BREACH |  |

# APPENDIX IV – Day2 requirements

The following requirements will be covered in ODP Day2.

* **#FS10005\_S0070\_00300** Application Programming Interface (API) Implementation
* **#FS10005\_S0070\_00400** Multiple Clearer Model
* **#FS10005\_S0070\_00500** Enhancement of Exposure Counting
* **#FS10005\_S0070\_00600** Order Rate Count of More Transaction
* **#FS10005\_S0070\_00700** Price Deviation Check
* **#FS10005\_S0070\_00800** Clearing Account Level Monitoring
* **#FS10005\_S0070\_00900** Improved Handling of Block Trades Exposure
