TITLE:

**FUNCTIONAL SPECIFICATION**

**ODP-T**

FS10003 - Orderbook and Execution Management

AUTHOR : IT/Markets Systems DATE : 24 Mar 2025

LAST REVIEW : Derivatives Trading Business Operations DATE : 28 Feb 2025

**CONTENTS**

[1. Document Control 4](#__RefHeading___Toc193719560)

[1.1. Change History 4](#__RefHeading___Toc193719561)

[1.2. Document Cross-referenced 4](#__RefHeading___Toc193719562)

[1.3. Abbreviation 5](#__RefHeading___Toc193719563)

[2. Introduction 6](#__RefHeading___Toc193719569)

[3. Order Book 7](#__RefHeading___Toc193719570)

[3.1. Order Book Lifecycle 7](#__RefHeading___Toc193719571)

[3.2. Order Book Creation and Maintenance 7](#__RefHeading___Toc193719572)

[3.2.1. Automatic Generation 8](#__RefHeading___Toc193719573)

[3.2.2. File Upload 8](#__RefHeading___Toc193719574)

[3.2.3. Admin UI 13](#__RefHeading___Toc193719575)

[3.3. Capital Adjustment 13](#__RefHeading___Toc193719576)

[3.3.1. Assumptions 13](#__RefHeading___Toc193719577)

[3.3.2. Manual Input Parameters 14](#__RefHeading___Toc193719578)

[3.3.3. Phase 1 – Adjustment 16](#__RefHeading___Toc193719579)

[3.3.4. Phase 2 – Recreate Standard Contracts 23](#__RefHeading___Toc193719580)

[4. Order Priority 24](#__RefHeading___Toc193719581)

[4.1. Market Order and Market-to-Limit Orders 25](#__RefHeading___Toc193719582)

[4.2. Order And Quote Amendment 26](#__RefHeading___Toc193719583)

[4.3. Order Reload 26](#__RefHeading___Toc193719584)

[5. Order Matching and Trade 26](#__RefHeading___Toc193719585)

[5.1. Auction Matching 27](#__RefHeading___Toc193719586)

[5.1.1. Order Book Ordering 27](#__RefHeading___Toc193719587)

[5.1.2. Aggressive and Passive Order 27](#__RefHeading___Toc193719588)

[5.1.3. Trade Timestamp 28](#__RefHeading___Toc193719589)

[5.1.4. Calculated Opening Price (COP) and Volume 28](#__RefHeading___Toc193719590)

[5.1.5. Trade Dissemination 30](#__RefHeading___Toc193719591)

[5.2. Continuous Matching 31](#__RefHeading___Toc193719592)

[5.2.1. Aggressive and Passive Order 32](#__RefHeading___Toc193719593)

[5.2.2. Trade Timestamp 32](#__RefHeading___Toc193719594)

[5.2.3. Trade Price 32](#__RefHeading___Toc193719595)

[5.2.4. Trade Dissemination 32](#__RefHeading___Toc193719596)

[5.3. Trade Transaction for Explicit Order matches Explicit Order 33](#__RefHeading___Toc193719597)

[5.3.1. Transaction Header 33](#__RefHeading___Toc193719598)

[5.3.2. Trading State 34](#__RefHeading___Toc193719599)

[5.3.3. Trade data 34](#__RefHeading___Toc193719600)

[5.3.4. Order Data 34](#__RefHeading___Toc193719601)

[5.3.5. Trade Leg Prices 34](#__RefHeading___Toc193719602)

[5.3.6. Examples Highlight Various ID in Trade Transaction 35](#__RefHeading___Toc193719603)

[5.4. Exchange On-Behalf Trade 45](#__RefHeading___Toc193719604)

[6. Combo Order Book Matching 46](#__RefHeading___Toc193719605)

[6.1. Ordering of Leg Price Calculation 46](#__RefHeading___Toc193719606)

[6.2. Leg BBO Prices 46](#__RefHeading___Toc193719607)

[6.3. Leg Price Calculation Algorithm 48](#__RefHeading___Toc193719608)

[6.3.1. Calculate Combo Order Book Theoretical BBO Prices 48](#__RefHeading___Toc193719609)

[6.3.2. Calculate Combo Net Price Proportion Percentage in the BBO Spread 49](#__RefHeading___Toc193719610)

[6.3.3. Calculate Leg Trade Price 50](#__RefHeading___Toc193719611)

[6.3.4. Adjust Combo Net Price 51](#__RefHeading___Toc193719612)

[6.3.5. Next Leg Calculation 51](#__RefHeading___Toc193719613)

[6.3.6. The Last Leg Price 51](#__RefHeading___Toc193719614)

[7. Tailor Made Combination (TMC) 53](#__RefHeading___Toc193719615)

[7.1. Restrictions 55](#__RefHeading___Toc193719616)

[7.1.1. Pre-defined Strategy List 56](#__RefHeading___Toc193719617)

[7.1.2. No restriction strategy 61](#__RefHeading___Toc193719618)

[7.2. TMC Creation 61](#__RefHeading___Toc193719619)

[7.2.1. Definition Request 61](#__RefHeading___Toc193719620)

[7.2.2. Leg Definitions 61](#__RefHeading___Toc193719621)

[7.3. Last Trading Time 62](#__RefHeading___Toc193719622)

[Appendix I. CA Type Formula 62](#__RefHeading___Toc193719623)

# Document Control

## Change History

|  |  |  |  |
| --- | --- | --- | --- |
| Version  Number | Issue Date | Author | Abstract |
| V1.0 | 20240718 | IT/Markets Systems | Initial version. |
| V1.1 | 20241018 | IT/Markets Systems | Revised based on review comments from business users |
| V2.0 | 20241031 | IT/Markets Systems | Revised based on review comments from business users |
| V2.1 | 20241111 | IT/Markets Systems | Revised based on review comments from business users |
| V2.2 | 20241122 | IT/Markets Systems | Revised based on review comments from business users |
| V3.0 | 20241127 | IT/Markets Systems | Revised based on review comments from business users |
| V3.1 | 20241227 | IT/Markets Systems | Revised based on review comments from business users |
| V3.2 | 20250324 | IT/Markets Systems | Revised based on review comments from business users |
| V3.3 | 20260404 | IT/Markets Systems | Revised based on review comments from business users |

## Document Cross-referenced

|  |  |  |
| --- | --- | --- |
| # | Document | Version |
| 1 | BRD\_DT\_0002: 0002 BRS Order Management | v2.4 2025 01 09 |
| 2 | BRD\_DT\_0003: 0003 BRS Order Book Execution Management | V1.6\_2025 01 21 |
| 3 | BRD\_DT\_0009: 0009 BRS\_Series Operation | 2024 10 15\_v5 |
| 4 | BRD\_DT\_0018: 0018 ODP - NewFunctionRequest - Capital Adjustment | 20241015 |
| 5 | BRD\_DT\_0044: 0044 BRS BAU Support | V1.6\_20250103 |
| 6 | BRD\_DT\_0050: 0050 BRS\_PDMPA functions in ODP | v1.3 2025 01 14 |
| 7 | BRD\_DT\_0052: 0052 ODP - NewFunctionRequest - Product Setup | 20240517 |
| 8 | FS10001 - Trading Timetable | 241227 |
| 9 | FS10002 - Order Management | 20250324 |
| 10 | FS10010 - Product Structure | 20250324 |
| 11 | FS10022 - Implied Logic | v1.1.1 (IT241127) |
| 12 | FS10023 - Instrument and Combo Generation | 20250324 |

## Abbreviation

|  |  |
| --- | --- |
| AHT | After Hours Trading |
| BBO | Best Bid Offer |
| BSFactor | Buy Sell Factor |
| BSRatio | Buy Sell Ratio |
| CA | Capital Adjustment |
| CompID | Trading Session ID |
| COP | Calculated Opening Price |
| CSV | Comma Separated Value |
| FaK | Fill and Kill |
| FS | Function Specification |
| FoK | Fill or Kill |
| GTC | Good Till Cancel |
| GTD | Good Till Date |
| GUI | Graphical User Interface |
| ID | Identifier |
| QTY | Quantity |
| SMP | Self-Match Prevention |
| ThSpTicks | Theoretical Spread Ticks |
| TMC | Tailor Made Combo |
| UI | User Interface |

# Introduction

To define the function specification as how order books are managed, order books lifecycle and how trades are created in ODP trading system.

# Order Book

#FS10003\_S0030\_00100

An order book is the electronic list of the orders within a single tradable instrument, which is arranged by OTP-D according to price, side of market and order priority as defined by the trading rules.

Orders can be entered into an order book as an explicit order or quote using the order entry and quoting functionality. Orders can also be synthetically created by ODP implying orders from combination order books, the mechanism is covered in FS10022.

Order book statistics such as best prices, total trade volume or trade count etc will be published to downstream throughout the day.

## Order Book Lifecycle

#FS10003\_S0030\_00200

There are 4 major moments in the lifecycle of an order book. They are (a) the creation date, (b) the first trading datetime, (c) capital adjustment and (d) the last trading datetime.

1. The creation date is the date the order book is created and exists in the system. It is either:
   1. The trading day after the creation request approved in the system with effective on the next trading day option.
   2. The current trading day with effective immediately option.
2. The first trading datetime is the moment at which the order book is started available for trading. It must be on or after the creation date.
3. Capital adjustment is an event where the derivative terms must be changed due to changes from the underlying.
4. The last trading datetime is the moment at which the order book is no longer available for trading. It must be after the first trading datetime.

Trading on an order book is available only from the first trading datetime (inclusive) to last trading datetime (exclusive) and subject to the associated trading timetable and instrument effective status.

## Order Book Creation and Maintenance

#FS10003\_S0030\_00300

Order books are in the system available for trading in the following ways:

1. At SOD trading state, order books that are available for trading in the previous trade day and their last trading date is on or after the current business date are maintained. Order books with the last trading date earlier than the current business date are no longer available after SOD trading state.
2. New order books created through maker/checker approval procedures by operations from below methods are available for trading after SOD trading state (subject to first trading datetime, timetable and effective status):
   1. Automatic instrument generation + Automatic combo generation.
   2. File upload.
   3. Admin UI.

![](data:image/png;base64...)

Note that the new order books generated from either automatic generation, file upload or Admin UI will go through the same maker/checker approval procedures before effective in the system. Both maker and checker will review the finalized list of order books to be effective.

### Automatic Generation

#FS10003\_S0030\_00400

Automatic instrument generation and automatic combo generation are covered in FS10023 - Instrument and Combo Generation.

### File Upload

#FS10003\_S0030\_00500

File Upload accepts files with records having all order book parameters. The mechanism can be used for case like Flexible options, ad-hoc, or temporary basis creation.

The file will be in CSV format with the following fields for each order book record:

|  |  |
| --- | --- |
| **Fields** | **Description** |
| Instrument Class | The Instrument Class associated in the system. |
| Instrument Name | The name of trading instrument.  This is an optional field.  When there is no input, it will be determined automatically based on the Instrument Name Standard.  When there is input, it will be check against the Instrument Name Standard. Any discrepancy will result in warning. |
| First Trading Date | The first trading date. In yyyy-MM-dd format.  This is an optional field.  When there is no input, the system assumes next trading date. |
| First Trading Time | The first trading time. In HH:mm:ss format.  This is an optional field. |
| Enable Auto Last Trading Date | Enable automatic last trading date calculation.  Accepted value:  Y – Enable automatic last trading date calculation.   * The Auto Last Trading Date Year must be present. * Either one of these must be present:   + Auto Last Trading Date Month, or   + Auto Last Trading Date Week. * The Last Trading Date must be empty.   N – Disable automatic last trading date calculation.   * The Auto Last Trading Date Year must be empty. * The Auto Last Trading Date Month must be empty. * The Auto Last Trading Date Week must be empty. * The Last Trading Date must be present. |
| Auto Last Trading Date Year | The year for Last Trading Date calculation.  This field is mandatory when Enable Auto Last Trading Date is “Y”. Otherwise, it must be empty.  The calculation is done according to Automatic Instrument Generation configuration. If the configuration is not present, the record will be rejected.  The value format is YYYY. |
| Auto Last Trading Date Month | The month for monthly contract Last Trading Date calculation.  This field is mandatory when:   * Enable Auto Last Trading Date is “Y”, and * Auto Last Trading Date Week is empty.   Otherwise, it must be empty.  The calculation is done according to Automatic Instrument Generation configuration. If the configuration is not present or the rule is not for Monthly contract, the record will be rejected.  The value format is MMM, e.g. Jan, Feb etc… |
| Auto Last Trading Date Week | The week for weekly contract Last Trading Date calculation.  This field is mandatory when:   * Enable Auto Last Trading Date is “Y”, and * Auto Last Trading Date Month is empty.   Otherwise, it must be empty.  The calculation is done according to Automatic Instrument Generation configuration. If the configuration is not present or the rule is not for Weekly contract, the record will be rejected.  The value format is wXX, e.g. w12 indicates week 12 of the year. |
| Last Trading Date | The last trading date. In yyyy-MM-dd format.  This field is mandatory when Enable Auto Last Trading Date is “N”. Otherwise, it must be empty.  Last Trading Date / Time must be later than First Trading Date / Time. |
| Last Trading Time | The last trading time. In HH:mm:ss format.  This is an optional field.  When there is no input and Auto Generation Rule exist in the Instrument Class, the value will be determined based on Auto Generation Rule.  When there is no input and Auto Generation Rule is not present, the record will be rejected.  Last Trading datetime must be later than First Trading datetime. |
| Options Strike Price | Options strike price for options contracts.  Based on the Instrument Class, instrument type other than Options with this field specified will be reject. |

Aside from the data records, additional control records like header and trailer will be detailed in separated file format spec.

When the Instrument Name is not compliance to Instrument Name Standard, warning will be issue in GUI when processing the file.

#### Combo Order Book

#FS10003\_S0030\_00600

For Combos file upload, only futures combo is supported. The file format is different with the order book record fields below:

|  |  |
| --- | --- |
| **Fields** | **Description** |
| Combo Class | The Combo Class associated in the system. |
| Combo Name | The name of combo order book.  This is an optional field.  When there is no input and Combo Name Standard is available, it will be determined automatically based on the Combo Name Standard.  When there is input, it will be check against the Combo Name Standard if available. Any discrepancy will result in warning. |
| First Trading Date | The first trading date. In yyyy-MM-dd format.  This is an optional field.  When there is no input, the system will determine the date by the latest First Trading Date from both legs.  When there is input, it must not be earlier than the auto determined value above. Otherwise, it will be rejected. |
| First Trading Time | The first trading time. In HH:mm:ss format.  This is an optional field.  When there is no input and all leg instruments are having First Trading Time defined, the system will determine the time by picking the First Trading Time from the leg having latest First Trading Date. When both legs are having same First Trading Date, the latest First Trading Time from both legs is selected. In case not all leg instruments are having First Trading Time defined, the field will be left empty.  When there is input, the value cannot be earlier than the auto determined value above or it will be rejected. In case the auto determination is not possible due to empty value in any one of the leg instruments, the input will be accepted as is. |
| Last Trading Date | The last trading date. In yyyy-MM-dd format.  This is an optional field.  When there is no input, the system will determine the date by the earliest Last Trading Date from both legs.  When there is input, it must not be later than the auto determined value above. Otherwise, it will be rejected. |
| Last Trading Time | The last trading time. In HH:mm:ss format.  This is an optional field.  When there is no input, the system will determine the time by picking the Last Trading Time from the leg having earliest Last Trading Date. When both legs are having same Last Trading Date, the earliest Last Trading Time from both legs is selected.  When there is input, the value cannot be later than the auto determined value above or it will be rejected. |
| Leg 1 Operation | The operation of Leg 1.  Allowed value: Buy or Sell. |
| Leg 1 Ratio | The ratio of Leg 1.  Allowed value: 1 – 4. |
| Leg 1 Instrument ID | The Instrument Name for Leg 1. |
| Leg 2 Operation | The operation of Leg 2.  Allowed value: Buy or Sell. |
| Leg 2 Ratio | The ratio of Leg 2.  Allowed value: 1 – 4. |
| Leg 2 Instrument ID | The Instrument Name for Leg 2. |

### Admin UI

#FS10003\_S0030\_00700

Admin UI instrument creation will be covered in Admin UI FS.

## Capital Adjustment

#FS10003\_S0030\_01000

When capital adjustment on an underlying issuer occurs, a series of changes happens within the system on associated contracts summarized in 2 phases:

1. Adjustment - Updates existing contracts with new contract terms according to capital adjustment.
2. Recreate Standard Contracts - Create a new set of contracts for the standard contract term with original underlying.

The CA event will be assigned a system generated unique numeric ID and associates to all adjustment and re-creation records when communicate to downstream system. The date of the CA event will be recorded.

All related TMC are removed from the system at DAYEND trading state.

All related outstanding orders (GTC/GTD) are removed from the system at DAYEND trading state.

### Assumptions

#FS10003\_S0030\_01101

There are assumptions to the Instrument setup listed below, capital adjustment will be rejected if anyone of them is violated.

|  |  |
| --- | --- |
| **Attributes** | **Assumption** |
| Instrument Class | Instrument Class name must contain the Underlying name. The CA process will name the new instrument class by replacing the original underlying name with the new one.  e.g.  Instrument Class: HKGFUT, HKGCALL  Underlying: HKG |
| Instrument Name | Instrument Name must contain the Underlying name. The CA process will name the new instrument by replacing the original underlying name with the new one.  e.g.  Instrument Name: HKGG4  Underlying: HKG |
| Combo Class | Combo Class name must contain the Underlying name. The CA process will name the new combo class by replacing the original underlying name with the new one.  If the Combo Class is a TMC related Combo Class, the Combo Class name must start with *TMC\_<Underlying ID>*, so CA process will name the new Combo class by replacing the original Underlying name with the new one. And the new Combo Class name will be *TMC\_<new underlying ID>*. |
| Combo Name | Combo Name should also contain the Underlying name. (It aligns with *Section 3.3.3.4 Adjust Combo*) |
| Combo Underlying | Combo with a leg Instrument having underlying being capital adjusted must have all legs with same underlying. |
| Options Strike Price | Recreate Standard Contracts for options requires strike price reference and strike price range configuration in auto-generation feature.  Missing configurations are warned at marker submission step and recreation of standard options are skipped. |

Besides, capital adjustment must be effective on the next trading date. When adjustment is required on the ex-date (E Day). Users must submit and approve CA to the system on E-1 day.

### Manual Input Parameters

#FS10003\_S0030\_01200

To start the CA process, operation user should input the following parameters:

|  |  |
| --- | --- |
| **Parameters** | **Description** |
| Underlying | The underlying being capital adjusted. |
| CA Type | The type of capital adjustment. |
| CA Type Specific Parameters | The parameters required specific to the type of capital adjustment. |
| New Price Decimal | The price decimal for the adjusted instrument class. |

#### Underlying

#FS10003\_S0030\_01300

By the Underlying input, the system will determine the relevant Underlying Issuer. The Underlying Issuer is an attribute in the Underlying, details refer to FS10010 – Product Structure. The Underlying Issuer is used to choose all relevant Underlying for capital adjustment, in case of multiple Underlying having the Underlying Issuer, all of them will be processed with ordering starts from the lowest number Priority as show below:

Situation: The Underlying name is XXA, and the Underlying Issuer name is XXA.

On Day 1, Underlying Issuer XXA is capital adjusted. Then, new underlaying is created as below:

|  |  |  |
| --- | --- | --- |
| **Step** | **Original** | **Newly Created** |
| 1 | XXA (Priority 1) | XXB (Priority 2) |

On Day 2, Underlying Issuer XXA is capital adjusted again. Then new underlying is created again as below:

|  |  |  |
| --- | --- | --- |
| **Step** | **Original** | **Newly Created** |
| 1 | XXA (Priority 1) | XXC (Priority 3) |
| 2 | XXB (Priority 2) | XXD (Priority 4) |

On Day 3, Underlying Issuer XXA is capital adjusted again. Then new underlying is created again as below:

|  |  |  |
| --- | --- | --- |
| **Step** | **Original** | **Newly Created** |
| 1 | XXA (Priority 1) | XXE (Priority 5) |
| 2 | XXB (Priority 2) | Skipped as no Instrument associated. See Phase 1 – Adjustment for details. |
| 3 | XXC (Priority 3) | XXF (Priority 6) |
| 4 | XXD (Priority 4) | XXG (Priority 7) |

#### CA Type

#FS10003\_S0030\_01400

CA Type defined how the underlying issuer being capital adjusted. There are several types of capital adjustment listed below where each of them is having different specific parameters described in the next section.

1. Right Issue
2. Bonus Issue of Shares
3. Bonus Issue of Warrants
4. Share Consolidation
5. Share Sub-division
6. Merger (Shares + Cash)
7. Merger (Shares Only)
8. Privatisation / Merger (Cash Only) \*not required to be handled by OTP-D\*
   * Notes: This CA type is here for the sake of completeness. It is not in trading system scope and will not be implemented in OTP-D. It will not be included in the CA Type list in the user interface.
9. Spin-Off (E-Day)
10. Spin-Off (F Day; with Entitlement)
11. Other Cash Distribution, e.g. Special Dividend
12. Other CA Events

#### CA Type Specific Parameters

#FS10003\_S0030\_01500

With the CA Type chosen, varies CA Type Specific Parameters input are further required. The CA Type Specific Parameters are used to calculate the Adjustment Ratio (AR). The AR value will be displayed to user and for subsequence calculation to adjust Instrument attributes.

The CA Type Specific Parameters for all CA Types are listed under the Specific Parameters table column in Appendix II – CA Type Formula. All rounding to specific decimal place is done with “Rounding half away from zero”. For example, when round to the 0 decimal, 23.5 gets rounded to 24, and -23.5 gets rounded to -24.

### Phase 1 – Adjustment

#FS10003\_S0030\_01600

In Phase 1 – Adjustment, the system will create New Underlying, Instrument Classes and Combo Classes for adjusted Instruments and Combos. Their relationship is described in FS10010 – Product Structure.

Notes:

1. Instruments passed the last trading datetime at SOD after CA Day are excluded from the CA process.
2. When there is no Instrument associated with the underlying or all instruments with the underlying are either on or passed last trading date, the Underlying and corresponding Instrument Classes will not be handled.
3. Instruments those pre-launched / before their First trading date are included in the CA process.

#### New Underlying

#FS10003\_S0030\_01700

The new Underlying will have attributes copied from the original underlying with the following changes:

|  |  |
| --- | --- |
| **Attributes** | **Value** |
| Name | In general, the name will target to have the last character changed to capital letter “A”. If the target name is either in-use or reserved for another underlying issuer, the next ASCII letter will be targeted until either an available one is found, or capital letter “Z” is reached, and it is not available.  For example, the original underlying is named “WEB”, “WEA” will be targeted as the name for the new underlying. If “WEA” is in-use or reserved, the next target will be “WEC”. If it is also not available, “WED” is targeted etc.  The system will suggest a name candidate to be used based on the above rules and the user can optionally override the value. When the system unable to choose a name based on the rules, user must provide one.  In extreme case, when no underlying name is available (all character combination not limited to change of the last character are in-use or reserved), the capital adjustment is rejected.  Once an available name is chosen, the name will be reserved for the underlying issuer forever. No other underlying issuer can use the underlying name.  A reserved underlying name will be available to re-use after an IT configurable cool-off period in number of days (assume 90 for now). |
| Description | The description will be copied from the original underlying description with simple string token replacement from original underlying name to new underlying name. |
| Underlying Code | The underlying code will be the next available number in an IT configurable code range for CA.  The system will suggest an underlying code candidate to be used and the user can optionally override the value. User is allowed to override the value to outside of the configurable code range.  In extreme case, when all underlying code in data type allowed range are in-use or reserved, the capital adjustment will be rejected.  Once the number is chosen, it is associated to the underlying name forever. When the reserved underlying name is re-used by the underlying issuer, the same underlying code will be used. |
| Suspended / Status | The status will be copied from the original underlying for all CA types, but Spin-Off (E Day) / (F-Day) detailed in Special Arrangement for Spin-Off section. |

#### New Instrument Class

#FS10003\_S0030\_01800

The new Instrument Class will be associated with the new Underlying and subsequently associated with the capital adjusted Instruments. The attributes are copied from the original Instrument Class with the following changes:

|  |  |
| --- | --- |
| **Attributes** | **Value** |
| Name | The name will be copied from the original Instrument Class with simple string token replacement from original underlying name to new underlying name.  E.g. when the original underlying name is WEB, the new underlying name is WEA, and the original instrument class name is WEBFUT, the new Instrument Class will be named WEAFUT.  When the name is already in-use, the capital adjustment will be rejected. |
| Auto Generation Rule | Disabled. |
|  |  |
| Price Decimal | From input parameter. |

#### Adjust Instrument

#FS10003\_S0030\_01900

Capital adjusted instruments are re-associated to the newly created Instrument Class. Attributes are keeping their original value with some of them changed as below:

|  |  |
| --- | --- |
| **Attributes** | **Value** |
| Name | The name will be updated by simple string token replacement from original value with new underlying name.  In case of options instrument, the price part will be updated to the Adjusted Exercise Price.  E.g. when the original underlying name is WEB, the new underlying name is WEA, and the original instrument name is WEBG4, it will be updated to WEAG4. For options instrument example, original name WEB10.00B4 will be updated to WEA5.00B4 (Assume the adjusted exercise price is 5.00).  When the name is already in-use, the capital adjustment will be rejected. |
| Contracted Price | The attribute is only value for futures contract.  Refer to the Appendix II – Futures Contracts table, this attribute will be updated as the Adjusted Contracted Price (ACP). |
| Contract Multiplier | The attribute is only value for futures contract.  Refer to the Appendix II – Futures Contracts table, this attribute will be updated as the Adjusted Contract Multiplier (ACM). |
| Exercise Price | The attribute is only value for options contract. It is the strike price of the options.  Refer to the Appendix II – Options Contracts table, this attribute will be updated as the Adjusted Exercise Price (AEP). |
| Contract Size | The attribute is only value for options contract.  Refer to the Appendix II – Options Contracts table, this attribute will be updated as the Adjusted Contract Size (ACS). |
| Modifier | Increase 1. |

#### Adjust Combo

#FS10003\_S0030\_02000

Combos associated with the capital adjusted instrument are potentially re-associated to another Combo Class. According to the FS10010 – Product Structure, Combo association to Combo Class is based on one of the combo legs selected by rule, the association will be re-determined after capital adjustment.

The relationship to instruments does not change, as the contract terms of those instruments are already updated. The combo attributes are updated as below:

|  |  |
| --- | --- |
| **Attributes** | **Value** |
| Name | The name will be updated by simple string token replacement from original value with new underlying name.  E.g. when the original underlying name is WEB, the new underlying name is WEA, and the original combo name is WEBF4/G4, it will be updated to WEAF4/G4.  When the name is already in-use, the capital adjustment will be rejected. |

Outstanding orders (GTC / GTD) in the adjusted order book are cleared without explicit message notification to market participants.

Aside from updating the contracts, their original attributes are saved for standard contracts re-creation in Phase 2.

When all contracts are updated, there will be no contract associated with the original Underlying or Instrument Class.

#### New MMP Configuration

#FS10003\_S0030\_02100

New MMP configurations are duplicated for the original Underlying with each participant and associate with the new Underlying.

#### Special Arrangement for Spin-Off

#FS10003\_S0030\_02200

Spin-Off is a 2 steps process, and they are not in the same day. The first day named “E Day” and the second day named “F Day”, the F Day must be after the E Day.

E Day adjustment is submitted on E-1 Day. Like other CA Types, a new underlying is created for the adjusted Instruments and Combos but with the SUSPENDED status and are marked with E Day in-progress state. With the SUSPENDED status in Underlying, these adjusted Instruments and Combos are visible to the market but not opened for trading.

F Day adjustment is submitted on F Day. Underlying with the inputted underlying issuer name and marked as E Day in-progress are chosen to process. The newly created Underlying are having SUSPENDED status removed. The adjusted Instruments and Combos are open for trading on next trading day.

#### Examples

#FS10003\_S0030\_02300

Instrument Example:

|  |  |  |  |
| --- | --- | --- | --- |
| **Attributes** | **Action** | **Original Contract** | **Adjusted Contract** |
| Instrument Class | Updates to new Instrument Class with new Underlying. | Futures: HKGFUT  Options: HKGCALL | Futures: HKAFUT  Options: HKACALL |
| Instrument Name | Updates to new Underlying and Adjusted Options Strike Price. | Futures: HKGG4  Options: HKG10.00B4 | Futures: HKAG4  Options: HKA5.00B4 |
| First Trading Date & Time  Last Trading Date & Time | No Change | / | / |
| Options Strike Price | Update with calculated or manual input AR.  (e.g. AR = 0.5) | Futures: N/A  Options: 10.00 | Futures: N/A  Options: 10.00 x 0.5 = 5.00 |

Combo Example:

|  |  |  |  |
| --- | --- | --- | --- |
| **Attributes** | **Action** | **Original Contract Example** | **Updated Contract Example** |
| Combo Class | Update with new Underlying | Futures: HKGFUT | Futures: HKAFUT |
| Combo Name | Update with new Underlying and Legs | Futures: HKGF4/G4 | Futures: HKAF4/G4 |
| Leg 1 | Update with new Underlying and original Contract Month | Futures: HKGG4 | Futures: HKAG4 |
| Leg 2 | Update with New Underlying and original Contract Month | Futures: HKGF4 | Futures: HKAF4 |

#### Adjustment Report

#FS10003\_S0030\_02400

After capital adjustment is submitted (maker procedure) to the system, CSV files include all (a) exercise price and contract size changes for options and (b) contract multiplier changes for futures are generated for CIRCULAR preparation.

##### Options CSV file

#FS10003\_S0030\_02500

The information included:

|  |  |  |  |
| --- | --- | --- | --- |
| #E-1 Day / F Day | | | |
| #CA Event ID | | | |
| #Options | | | |
| #CA Type | | | |
| #AR | | | |
| #Old Underlying | | New Underlying | |
| Old Exercise Price | Old Contract Size | Adjusted Exercise Price | Adjusted Contract Size |
| Old Exercise Price | Old Contract Size | Adjusted Exercise Price | Adjusted Contract Size |
| … | … | … | … |
| #Num of records | | | |

Example:

|  |
| --- |
| #20240625  #2024000001  #Options  #Bonus Issue of Shares  #0.7692 #YZC,YZB 8.00,2000,6.15,2601.6260  8.25,2000,6.35,2598.4252  8.50,2000,6.54,2599.3884  …  #128 |

##### Futures CSV file

#FS10003\_S0030\_02600

The information included:

|  |  |  |  |
| --- | --- | --- | --- |
| #E-1 Day / F Day | | | |
| #CA Event ID | | | |
| #Futures | | | |
| #CA Type | | | |
| #AR | | | |
| #Old Underlying | | | New Underlying |
| Contract Month | Old Contracted Price | Old Contract Multiplier | Adjusted Contract Multiplier |
| Contract Month | Old Contracted Price | Old Contract Multiplier | Adjusted Contract Multiplier |
| … | … | … | … |
| #Num of records | | | |

Example:

|  |
| --- |
| #20240625  #2024000001  #Futures  #Bonus Issue of Shares  #0.7692 #YZC,YZB June 2024,15.39,2000,2599.6622  July 2024,15.44,2000,2599.3266  August 2024,15.43,2000,2599.8315  September 2024,16.30,2000,2599.6810  December 2024,16.65,2000,2599.5316  …  #128 |

### Phase 2 – Recreate Standard Contracts

#FS10003\_S0030\_02700

In Phase 2 – Recreate Standard Contracts, all instruments and combos under the original Instrument Classes and Combo Classes that exist before Phase 1 – Adjustment are recreated based on the saved attributes (except options strike price).

Options strike prices will be re-determined by the adjusted closing price of underlying and strike range from automation generation setting. When the automation generation setting is not available, the Phase 2 will be skipped for those options and show warning to user in maker and checker step.

These recreated instruments and combos are effective the next trading day.

Re-creation is always done, there is no “Until Days to Last Trading” restriction.

CA is expected to be done before auto-generate related Instruments for the next trading day. The system will mark Instrument Classes that went through CA Phase 2 process, subsequence Auto Instrument Generation on the same day will skip processing these Instrument Classes.

#### Capital Adjustment on Capital Adjusted Underlying

#FS10003\_S0030\_02800

As mentioned in the previous Underlying Issuer section, it is possible an underlying issuer capital adjusted twice which results in multiple Underlying being adjusted in the second adjustment and onward. In this case, only the first underlying (labelled with priority 1 in the example) will have standard contracts recreated.

#### Special Arrangement for Spin-Off

#FS10003\_S0030\_02900

For F Day adjustment, E Day created Instrument Classes and Combo Classes will not have standard contract recreated.

#### Examples

#FS10003\_S0030\_03000

Standard contracts are recreated with saved attributes in Phase 1 except:

|  |  |
| --- | --- |
| **Fields** | **Source** |
| Options Strike Price | Based on adjusted settlement / closing price of underlying + strike range from automatic generation configuration. |

Standard combos are recreated with saved attributes in Phase 1 except:

|  |  |
| --- | --- |
| **Fields** | **Source** |
| Leg 1 | Saved Instrument Name which will be referring to the newly created Instrument. |
| Leg 2 | Saved Instrument Name which will be referring to the newly created Instrument. |
| Leg 3 | Saved Instrument Name which will be referring to the newly created Instrument. |
| Leg 4 | Saved Instrument Name which will be referring to the newly created Instrument. |

# Order Priority

#FS10003\_S0040\_01000

Orders in the order book are arranged according to Price-Time priority, which prioritizes orders based firstly on the price and secondly by the time (with nanosecond resolution) the order is accepted.

Orders having different limit prices are prioritized by price, better price orders have higher priority. For the bid side, a higher limit price order is better price than a lower limit price order. For the ask side, a lower limit price order is better price than a higher limit price order.

Orders having the same price are prioritized by time, earlier orders have higher priority. Every order is assigned a timestamp when it is received in matching engine and the timestamp is used to determine the time priority.

There is a BID queue and an ASK queue in the order book. Orders are added to either one of them based on the Side attribute, with higher priority orders placed closer to the front and the highest priority one placed at the head of the queue. The head of the queue is also called the top of the book.

For example, a list of orders below is added to an empty order book.

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
| **Time** | **Order ID** | **Side** | **Order Type** | **Qty @ Price** |
| 10:00:00.000 (T1) | 101 | BID | Limit | 100 @ 10.00 |
| 10:00:00.100 (T2) | 102 | BID | Limit | 100 @ 11.00 |
| 10:00:00.200 (T3) | 103 | BID | Limit | 100 @ 10.00 |
| 10:00:01.000 (T4) | 104 | ASK | Limit | 100 @ 13.00 |
| 10:00:01.100 (T5) | 105 | ASK | Limit | 100 @ 12.00 |

The orders are arranged in the order book as below.

|  |  |
| --- | --- |
| **BID** | **ASK** |
| (ID102 | T2) 100 @ 11.00 | 100 @ 12.00 (ID105 | T5) |
| (ID101 | T1) 100 @ 10.00 | 100 @ 13.00 (ID104 | T4) |
| (ID103 | T3) 100 @ 10.00 |  |

## Market Order and Market-to-Limit Orders

#FS10003\_S0040\_01100

During OPEN trading state, all orders in the order book must be priced. Market Orders will not be added to order books and Market-to-Limit Orders are priced by ODP according to order management FS before added to order books.

In PRE-MARKET trading state, order books accept Market Orders and Market-to-Limit Orders waiting for auction matching. These 2 types of orders without price have higher price priority than other orders with price, thus they are queued ahead of other orders. Among the 2 types of orders, they are equal priority by price therefore will be prioritized by time.

For example, a list of orders below is added to an empty order book in pre-market.

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
| **Time** | **Order ID** | **Side** | **Order Type** | **Qty @ Price** |
| 9:00:00.000 (T1) | 101 | BID | Limit | 100 @ 10.00 |
| 9:00:00.100 (T2) | 102 | BID | Limit | 100 @ 11.00 |
| 9:00:00.200 (T3) | 103 | BID | M2L | 100 @ M2L |
| 9:00:01.000 (T4) | 104 | BID | Market | 100 @ MKT |
| 9:00:01.100 (T5) | 105 | BID | Limit | 100 @ 11.00 |
| 9:00:01.200 (T6) | 106 | BID | Market | 100 @ MKT |
| 9:00:01.300 (T7) | 107 | ASK | Limit | 50 @ 11.00 |

The orders are arranged in the order book in the pre-market session as below.

|  |  |
| --- | --- |
| **BID** | **ASK** |
| (ID103 | T3) 100 @ M2L | (ID107 | T7) 50 @ 11.00 |
| (ID104 | T4) 100 @ MKT |  |
| (ID106 | T6) 100 @ MKT |  |
| (ID102 | T2) 100 @ 11.00 |  |
| (ID105 | T5) 100 @ 11.00 |  |
| (ID101 | T1) 100 @ 10.00 |  |

After auction matching, the remaining Market Orders are removed from the order book. Remaining Market-to-Limit Orders are converted to Limit Orders with limit price according to Order Management FS and time priority with timestamp assigned when the order received.

The order book after auction matching will be as below and goes into OPEN trading session.

|  |  |
| --- | --- |
| **BID** | **ASK** |
| (ID102 | T2) 100 @ 11.00 |  |
| (ID103 | T3) 50 @ 11.00 |  |
| (ID105 | T5) 100 @ 11.00 |  |
| (ID101 | T1) 100 @ 10.00 |  |

## Order And Quote Amendment

#FS10003\_S0040\_01200

Orders will be assigned a new timestamp and therefore having lower time priority when it is amended with either one of the following conditions:

1. Order Price has changed.
2. Order Quantity has increased.
3. SMP ID has changed.

Any other changes to orders will not result in a new timestamp assignment, and the order priority is retained.

For quotes, any changes will have a new timestamp assigned to them and lower time priority.

The table below illustrates a new timestamp assigned together with the time priority changed when an order increased quantity.

|  |  |  |
| --- | --- | --- |
| **Order Book BID Side** | | |
| **Before** |  | **After** |
| (ID102 | T2) 100 @ 11.00 | Amend order ID103 to quantity 110 and a new timestamp T6 assigned | (ID102 | T2) 100 @ 11.00 |
| (ID103 | T3) 100 @ 11.00 | (ID105 | T5) 100 @ 11.00 |
| (ID105 | T5) 100 @ 11.00 | (ID103 | T6) 110 @ 11.00 |
| (ID101 | T1) 100 @ 10.00 | (ID101 | T1) 100 @ 10.00 |

## Order Reload

#FS10003\_S0040\_01300

Order reloads restore GTC and GTD orders into order book at the SOD trading state (the beginning of trading day), their attributes including priority are same as the previous trading day.

# Order Matching and Trade

#FS10003\_S0050\_01000

OTP-D supports 2 types of matching model, Auction Matching and Continuous Matching. In both cases, order matching is done by comparing a BID order with an ASK order. When all order attributes from both sides are fulfilled, equal amount of volume is removed from them, and a trade is made with the removed volume. When the order in the order book had all volume removed, the order is removed from the order book.

## Auction Matching

#FS10003\_S0050\_01100

In the PRE-MARKET opening, ODP will operate in an auction matching model.

Orders for both sides are collected in order books from market participants without matching, order books are allowed to be crossed. When the order book is crossed and at each order entry, amendment, or cancellation, a calculation of Calculated Opening Price (COP) is done based on the crossed orders. The best Bid and Ask price and volume together with the COP and opening volume are disseminated.

If the order book is not crossed, COP cannot be calculated, and no matching will be done.

When auction matching starts, the order book and COP is finalized without further changes. Matching is done at COP as trade price, beginning from the highest priority order. Orders participant in auction matching are market orders, market-to-limit orders and limit orders those with price equal or better than COP.

FoK orders are not allowed in PRE-MARKET OPENING / Auction Matching.

### Order Book Ordering

#FS10003\_S0050\_01200

When auction matching starts, the ordering of matching process is depicted as below, and such orderings apply to the uncrossing trading state only.

1. If uncrossing trading states with different levels happen at the same time, process them in the following order:
2. Instrument class
3. Instrument type
4. Market
5. Combo class (Note: does not have uncrossing trading state, putting down here for completeness and for future)
6. Combo type (Note: does not have uncrossing trading state, putting down here for completeness and for future)
7. If multiple instrument classes are present (i.e. uncross at the same time), sort by market with market priority number and then instrument class ID in ascending order.
8. If multiple instrument types are present, sort by sort by market with market priority number instrument type ID in ascending order.
9. If multiple markets are present, sort by market priority number (lowest value first).
10. If multiple combo classes are present, sort by sort by market (with market priority number), combo class ID in ascending order.
11. If multiple combo types are present, sort by sort by market (with market priority number), combo type ID in ascending order.
12. Within a Market, sort by Futures, Call and then Put.
13. Within an Instrument Type, sort by the underlying ID in ascending order.
14. Within an Instrument Class, sort by Last Trading Date with nearer first and then by strike price with lower first.

Aggressive and Passive Order

#FS10003\_S0050\_01300

During Auction Matching, orders on both sides of trade are not defined as either aggressive or passive.

### Trade Timestamp

#FS10003\_S0050\_01400

The timestamp of trades made from Action Matching are the same as the beginning time of Auction Matching.

### Calculated Opening Price (COP) and Volume

#FS10003\_S0050\_01500

COP and volume are the price and volume trades to be made in Auction Matching, it is calculated and disseminated starting from SOD when order book is crossed. The COP also serves as the opening price for OPEN trading state session.

GTC/GTD orders carried forward from the previous day would be considered as effective and included in the COP calculation during the PRE-MARKET Opening Period. The COP would be updated continuously once it is determined.

#FS10003\_S0050\_01600

The COP is calculated according to the rules sequentially defined below:

(In the below examples, crossed price levels are highlighted with green, with best level underscored. The yellow highlights are selected price and reason)

1. The COP cannot fall outside the best bid and offer of unfilled orders, though it can be equal to the bid or offer. It is not possible to calculate the COP when no crossing limit orders exist. There must also be at least one order on either side of the order book for the price to be selected.

Based on the 1st rule, 20.0 is selected for COP in the book below.

|  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- |
| **Bid side** | | **Price** | **Ask side** | | **Match** | **Imbalance** | **Associated** |
| Total | Qty |  | Qty | Total | Qty | Qty | Qty |
|  | 10 | MKT |  |  |  |  |  |
|  |  | 20.2 |  |  |  |  |  |
|  |  | 20.1 | 10 | 30 |  |  |  |
| 70 | 60 | 20.0 | 20 | 20 | 20 | 50 | 70 |
| 80 | 10 | 19.9 |  |  |  |  |  |
|  |  | 19.8 |  |  |  |  |  |
|  |  | MKT |  |  |  |  |  |

1. If more than one price satisfy rules 1 above, the COP will be the price with the number of matched contracts is maximized.

Based on the 2nd rule, 20.1 is selected for COP in the book below.

|  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- |
| **Bid side** | | **Price** | **Ask side** | | **Match** | **Imbalance** | **Associated** |
| Total | Qty |  | Qty | Total | Qty | Qty | Qty |
|  | 10 | MKT |  |  |  |  |  |
| 20 | 10 | 20.2 | 20 | 90 | 20 | 70 | 90 |
| 70 | 50 | 20.1 | 40 | 60 | 60 | 10 | 70 |
|  |  | 20.0 |  |  |  |  |  |
| 80 | 10 | 19.9 | 20 | 20 | 20 | 60 | 80 |
| 90 | 10 | 19.8 |  |  |  |  |  |
|  |  | MKT |  |  |  |  |  |

1. If more than one price satisfy the rules 1 & 2 above, the COP will be the price at which the normal order imbalance is the lowest.

Based on the 3rd rule, 20.1 is selected for COP in the book below.

|  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- |
| **Bid side** | | **Price** | **Ask side** | | **Match** | **Imbalance** | **Associated** |
| Total | Qty |  | Qty | Total | Qty | Qty | Qty |
|  | 20 | MKT |  |  |  |  |  |
|  |  | 20.2 |  |  |  |  |  |
| 40 | 20 | 20.1 |  | 30 | 30 | 10 | 40 |
| 70 | 30 | 20.0 | 20 | 30 | 30 | 40 | 70 |
| 80 | 10 | 19.9 |  |  |  |  |  |
|  |  | 19.8 |  |  |  |  |  |
|  |  | MKT | 10 |  |  |  |  |

1. If more than one price satisfy the rules 1 - 3 above, the COP shall be the price at which the associated crossed quantity is the highest. For the purposes of this procedure, associated crossed quantity shall be determined as follows:

(i) If there is a bid order at that price, the associated crossed quantity shall be the aggregate number of contracts comprising all bid Auction Orders and bid Limit Orders at or above that price;

(ii) If there is an ask order at that price, the associated crossed quantity shall be the aggregate number of contracts comprising all ask Auction Orders and ask Limit Orders at or below that price;

(iii) If an order is present in both the bid and ask queues, the associated crossed quantity shall be the higher of the quantities determined under paragraphs (i) and (ii).

Based on the 4th rule, 20.0 is selected for COP in the book below.

|  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- |
| **Bid side** | | **Price** | **Ask side** | | **Match** | **Imbalance** | **Associated** |
| Total | Qty |  | Qty | Total | Qty | Qty | Qty |
|  |  | MKT |  |  |  |  |  |
|  |  | 20.2 | 20 | 60 |  |  |  |
| 30 | 30 | 20.1 |  | 40(Note 1) | 30 | 10 | 30 |
| 30 |  | 20.0 | 40 | 40 | 30 | 10 | 40 |
| 50 | 20 | 19.9 |  |  |  |  |  |
|  |  | 19.8 |  |  |  |  |  |
|  |  | MKT |  |  |  |  |  |

Note:

1. The 40 cannot be the associated crossed quantity as there is not ask order at this price.
2. If more than one price satisfy 1 - 4 above and there is COP reference price:

(i) The COP will be the price closest to the COP reference price.

(ii) If COP reference price is in middle of the potential COP prices, the higher price will be chosen.

The COP reference price referred in the morning session is previous settlement price. In the afternoon session, it refers to the last trade price in morning session. If no last trade price in the morning session, it refers to previous settlement price.

Based on the 5th rule, 20.0 is selected for COP in morning session as below.

**Last Settlement Price: 19.9 - Price closest to the COP reference price:**

|  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- |
| **Bid side** | | **Price** | **Ask side** | | **Match** | **Imbalance** | **Associated** |
| Total | Qty |  | Qty | Total | Qty | Qty | Qty |
|  |  | MKT |  |  |  |  |  |
|  |  | 20.2 | 20 | 60 |  |  |  |
| 40 | 40 | 20.1 |  | 40 | 40 | 0 | 40 |
| 40 |  | 20.0 | 40 | 40 | 40 | 0 | 40 |
| 50 | 10 | 19.9 |  |  |  |  |  |
|  |  | 19.8 |  |  |  |  |  |
|  |  | MKT |  |  |  |  |  |

**Last Settlement Price: 19.5 - COP reference price is in the middle of potential COP prices:**

|  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- |
| **Bid side** | | **Price** | **Ask side** | | **Match** | **Imbalance** | **Associated** |
| Total | Qty |  | Qty | Total | Qty | Qty | Qty |
|  |  | MKT |  |  |  |  |  |
|  |  | 20.2 | 20 | 60 |  |  |  |
| 40 | 40 | 20.1 |  | 40 | 40 | 0 | 40 |
| 40 |  | 20.0 | 40 | 40 | 40 | 0 | 40 |
| 50 | 10 | 19.9 |  |  |  |  |  |
|  |  | 19.8 |  |  |  |  |  |
|  |  | MKT |  |  |  |  |  |

1. If there is no previous settlement price in Rule 5, the highest price will be chosen.

Based on the 6th rule, 20.1 is selected for COP in the book below.

**Last Settlement Price: N/A**

|  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- |
| **Bid side** | | **Price** | **Ask side** | | **Match** | **Imbalance** | **Associated** |
| Total | Qty |  | Qty | Total | Qty | Qty | Qty |
|  |  | MKT |  |  |  |  |  |
|  |  | 20.2 | 20 | 60 |  |  |  |
| 40 | 40 | 20.1 |  | 40 | 40 | 0 | 40 |
| 40 |  | 20.0 | 40 | 40 | 40 | 0 | 40 |
| 50 | 10 | 19.9 |  |  |  |  |  |
|  |  | 19.8 |  |  |  |  |  |
|  |  | MKT |  |  |  |  |  |

### Trade Dissemination

#FS10003\_S0050\_01700

Trade transactions are disseminated immediately from the Matching Engine when 2 orders are matched with COP. There will be 1 trade transaction / message per each matched order pair. When a BID order matches with 2 ASK orders, there will be a total of 2 transactions, the first one for the BID order with the first ASK order, and second one for the BID order with the second ASK order.

As trade transactions are disseminated as soon as the trade occurred, the trade transaction ordering follows the order matching ordering.

Book Example 1.

|  |  |
| --- | --- |
| **BID** | **ASK** |
| (BID 1) 100 @ 11.00 | 100 @ 11.00 (ASK 1) |
| (BID 2) 200 @ 11.00 | 70 @ 11.00 (ASK 2) |
| (BID 3) 100 @ 11.00 |  |

Trades at COP 11.00.

|  |  |  |
| --- | --- | --- |
| **Num** | **Trade** | **Remark** |
| 1 | (BID 1) x (ASK 1), 100 @ 11.00 | (BID 1) and (ASK 1) removed from book. |
| 2 | (BID 2) x (ASK 2), 70 @ 11.00 | (BID 2) remains 130 qty, (ASK 2) removed from book. |

Book Example 2.

|  |  |
| --- | --- |
| BID | ASK |
| (BID 1) 150 @ 11.00 | 100 @ 11.00 (ASK 1) |
| (BID 2) 200 @ 11.00 | 70 @ 11.00 (ASK 2) |
| (BID 3) 100 @ 11.00 | 200 @ 11.00 (ASK 3) |

Trades at COP 11.00.

|  |  |  |
| --- | --- | --- |
| **Num** | **Traded Order** | **Remark** |
| 1 | (BID 1) x (ASK 1), 100 @ 11.00 | (BID 1) remains 50 qty, (ASK 1) removed from book. |
| 2 | (BID 1) x (ASK 2), 50 @ 11.00 | (BID 1) removed from book, (ASK 2) remains 20 qty. |
| 3 | (BID 2) x (ASK 2), 20 @ 11.00 | (BID 2) remains 180 qty, (ASK 2) removed from book. |
| 4 | (BID 2) x (ASK 3), 180 @ 11.00 | (BID 2) removed from book, (ASK3) remains 20 qty. |
| 5 | (BID 3) x (ASK 3), 20 @ 11.00 | (BID 3) remains 80 qty, (ASK 3) removed from book. |

## Continuous Matching

#FS10003\_S0050\_01800

During continuous trading, ODP will operate in the continuous matching model where an aggressive order matches with passive orders from the other side of the book one-by-one starting from the one with highest priority and matches as much quantity as possible. If the passive order volume is exhausted and removed from the book, the next book order in the queue becomes the highest priority and continues matching.

The order matching is complete when the price of the aggressive order does not fulfill book orders. If the aggressive order has quantity remaining, it will be added to the order book and become a passive order in subsequent matching.

Aggressive orders with time validity Fill-or-Kill (FoK) will start matching only when the total quantity can be matched immediately.

Order book will not accept FoK and Fill-And-Kill (FaK) orders in continuous trading, they can only match with passive orders in order book. Any remaining quantity after matching will be unsolicited cancelled. If FoK or FaK orders are in order book outstanding when entering continuous matching, they will be unsolicited cancelled by the system immediately.

Order books will not result in order price crossed from each side during Continuous Matching. In case the order book prices are already crossed and start continuous matching, Auction Matching with COP will be done immediately. Crossed order book can be happened for instrument without PRE-MARKET opening and non AHT GTC/GTD orders crossed with AHT GTC/GTD orders.

For Combo orders, order matching can be done in either combo order book or leg order books, it depends on which price is better:

* If the derived price from leg order books is better than the combination order book, the matching is done with leg orders. Details in FS10022.
* If the combination order book price is better, the matching is done in the combination order book. Details in Combo Order Book Matching section.
* If they are equal, the matching is done in the combination order book.

### Aggressive and Passive Order

#FS10003\_S0050\_01900

For explicit order matching, the aggressive order or the aggressor is determined by the later timestamp between the 2 orders.

The timestamp for explicit orders is the one mentioned in the Order Priority section.

Once an aggressive order finishes matching with book orders and residual volume remains, the order will be added to the order book if time validity is allowed and becomes a passive order being matched by subsequence aggressive orders.

For combo associated implied order matching, it is covered in FS10022.

### Trade Timestamp

#FS10003\_S0050\_02000

The timestamp of the trades is the time the aggressive order transaction reaches matching engine or processing of scheduled event like the start of continuous matching.

### Trade Price

#FS10003\_S0050\_02100

For explicit order matching, the trade price is determined by the price of passive order. In the case of two orders being matched having price crossed, the aggressive order benefits from price improvement.

### Trade Dissemination

#FS10003\_S0050\_02200

Trade transactions are disseminated immediately from the Matching Engine when a new incoming order matches with orders in orderbook, 1 trade transaction / message per each matched order pair.

Book Example 1.

|  |  |
| --- | --- |
| **BID** | **ASK** |
| (BID 1) 100 @ 11.00 | 100 @ 12.00 (ASK 1) |
| (BID 2) 200 @ 11.00 | 70 @ 12.00 (ASK 2) |
| (BID 3) 100 @ 10.00 |  |

When an ASK order (ASK 3) 350 @ 11.00 is entered, the following trade transactions are disseminated.

|  |  |  |
| --- | --- | --- |
| **Num** | **Trade** | **Remark** |
| 1 | (BID 1) x (ASK 3), 100 @ 11.00 | (BID 1) is removed from book, (ASK 3) remains 250 qty. |
| 2 | (BID 2) x (ASK 3), 200 @ 11.00 | (BID 2) is removed from book, (ASK 3) remains 50 qty and inserted at the top of the book on ASK side. |

The following example shows the aggressive order trade through the best price level.

Book Example 2.

|  |  |
| --- | --- |
| **BID** | **ASK** |
| (BID 1) 100 @ 11.00 | 100 @ 12.00 (ASK 1) |
| (BID 2) 200 @ 11.00 | 70 @ 12.00 (ASK 2) |
| (BID 3) 100 @ 10.00 |  |

When an ASK order (ASK 3) 350 @ 10.00 is entered, the following trade transactions are disseminated.

|  |  |  |
| --- | --- | --- |
| **Num** | **Trade** | **Remark** |
| 1 | (BID 1) x (ASK 3), 100 @ 11.00 | (BID 1) is removed from book, (ASK 3) remains 250 qty. |
| 2 | (BID 2) x (ASK 3), 200 @ 11.00 | (BID 2) is removed from book, (ASK 3) remains 50 qty. |
| 3 | (BID 3) x (ASK 3), 50 @ 10.00 | (BID 3) remains 50 qty, (ASK 3) is filled with no remaining qty. |

## Trade Transaction for Explicit Order matches Explicit Order

#FS10003\_S0050\_02300

Trade transactions disseminated contains categories of information listed below:

* Transaction Header
* Trading State
* Trade data
* Order data from both sides.
* Trade Leg Prices

### Transaction Header

Transaction Header includes timestamp information:

|  |  |
| --- | --- |
| **Attributes** | **Description** |
| Business Time | Wall clock timestamp |

### Trading State

Trading State includes various trading state ID when the trade occurs:

|  |  |
| --- | --- |
| **Attributes** | **Description** |
| Trading State ID | The ID of the trading state. E.g. 3 (Open) |
| Trading Sub State ID | The ID of sub state. E.g. 4 (Uncross) in pre-market. |
| Trading Session ID | The ID of trading session. E.g. 2 (Morning) |
| Trading State Control | The state change triggering source. E.g. 0 (Auto) |

### Trade data

Trade data includes information on the matching as listed below:

|  |  |
| --- | --- |
| **Attributes** | **Description** |
| Match ID | The ID of the matching for a pair of orders. It is unique in a business day across all market. |
| Match Group ID | The ID of the matching with implied orders. Details in FS10022. |
| Match Event ID | The ID of the matching in a single transaction. It is unique in a business day across all market. |
| Other Trade specific attributes | E.g. Trade price, Trade quantity etc.… |
| Trade Side Block 1 | |
| Side | The side of this trade side block. 0 for Bid, 1 for Ask. |
| Side Trade ID | The trade ID of the trade leg. |
| Other Trade Side specific attributes | E.g. Aggressive flag, order or quote etc. |
| Trade Side Block 2 (Optionally repeat the above order attributes for other side) | |

### Order Data

Order data includes information reference to the orders involved. The referenced order can be an outright order or implied order.

### Trade Leg Prices

Trade Leg Prices contains leg prices when the matching involves 2 combo orders as listed below:

|  |  |
| --- | --- |
| **Attributes** | **Description** |
| Num Legs | The number of leg price block following this field. |
| Leg Price Block 1 | |
| Leg Security ID Ref | The identifier of the instrument of the combo leg. |
| Leg Side | The side of the combo leg. |
| Leg Price | The trade price of the combo leg. |
| Leg Quantity | The trade quantity of the combo leg. |
| Leg Match ID | The ID of the matching for the combo leg. |
| Trade Side Block 2 (Repeat the above Leg Price Block attributes) | |
| Trade Side Block 3 (Optional, Repeat the above Leg Price Block attributes) | |
| Trade Side Block 4 (Optional, Repeat the above Leg Price Block attributes) | |
| Trade Side Block 5 (Optional, Repeat the above Leg Price Block attributes) | |

### Examples Highlight Various ID in Trade Transaction

#### Outright Order matches Outright Order

When an outright order matches another outright order, 1 trade transaction is disseminated.

Trade Transaction:

|  |  |
| --- | --- |
| **Attributes** | **Value** |
| Trade Data | |
| Match ID | 50000002 |
| Match Group ID | 10000002 |
| Match Event ID | 70000002 |
| Other Attributes | -- |
| Trade Side Block 1 | |
| Side | 0 (Bid) |
| Side Trade ID | 30000002 |
| Other Attributes | -- |
| Trade Side Block 2 | |
| Side | 1 (Ask) |
| Side Trade ID | 40000002 |
| Other Attributes | -- |

#### Outright Order matches 2 Outright Orders

When an outright order matches 2 outright orders, 2 transactions is disseminated.

Trade Transaction 1:

|  |  |
| --- | --- |
| **Attributes** | **Value** |
| Trade Data | |
| Match ID | 50000002 |
| Match Group ID | 10000002 |
| Match Event ID | 70000002 |
| Other Attributes | -- |
| Trade Side Block 1 | |
| Side | 0 (Bid) |
| Side Trade ID | 30000002 |
| Other Attributes | -- |
| Trade Side Block 2 | |
| Side | 1 (Ask) |
| Side Trade ID | 40000002 |
| Other Attributes | -- |

Trade Transaction 2:

|  |  |
| --- | --- |
| **Attributes** | **Value** |
| Trade Data | |
| Match ID | 50000003 |
| Match Group ID | 10000003 |
| Match Event ID | 70000002 (Same ID as Trade Transaction 1) |
| Other Attributes | -- |
| Trade Side Block 1 | |
| Side | 0 (Bid) |
| Side Trade ID | 30000003 |
| Other Attributes | -- |
| Trade Side Block 2 | |
| Side | 1 (Ask) |
| Side Trade ID | 40000003 |
| Other Attributes | -- |

#### Combo Order matches Combo Order

For a combo order matches another combo order, 1 trade transaction is disseminated.

Trade Transaction (assume combo with 2 legs):

|  |  |
| --- | --- |
| **Attributes** | **Value** |
| Trade Data | |
| Match ID | 50000002 |
| Match Group ID | 10000002 |
| Match Event ID | *70000002* |
| Other Attributes | -- |
| Trade Side Block 1 | |
| Side | 0 (Bid) |
| Side Trade ID | 30000002 |
| Other Attributes | -- |
| Trade Side Block 2 | |
| Side | 1 (Ask) |
| Side Trade ID | 40000002 |
| Other Attributes | -- |
| Leg Prices 0 | |
| Leg Match ID | 80000002 |
| Other Attributes | -- |
| Leg Prices 1 | |
| Leg Match ID | 20000002 |
| Other Attributes | -- |

#### Outright Order matches Implied Order

Under the following situation, based on outright orders in Book A and B, an imply order (GREEN color) is generated into Book A/B. When a new order (RED color) entered Book A/B and matching occurs, there will be 3 trade transactions.

|  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Outright Book A | |  | Combo Book A/B | |  | Outright Book B | |
| BID | ASK |  | BID | ASK |  | BID | ASK |
| 10@185 |  |  | 3@5 |  |  |  | 3@180 |

↓

|  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Outright Book A | |  | Combo Book A/B | |  | Outright Book B | |
| BID | ASK |  | BID | ASK |  | BID | ASK |
| 10@185 |  |  | 3@5 | 5@MKT |  |  | 3@180 |

Trade Transaction 1 for Book A/B:

|  |  |
| --- | --- |
| **Attributes** | **Value** |
| Trade Data | |
| Match ID | 50000002 |
| Match Group ID | 10000002 |
| Match Event ID | *70000002* |
| Other Attributes | -- |
| Trade Side Block 1 | |
| Side | 1 (Ask) |
| Side Trade ID | 30000002 |
| Other Attributes | -- |
| Leg Prices 0 | |
| Leg Match ID | 80000002 |
| Other Attributes | -- |
| Leg Prices 1 | |
| Leg Match ID | 20000002 |
| Other Attributes | -- |

Trade Transaction 2 for Book A:

|  |  |
| --- | --- |
| **Attributes** | **Value** |
| Trade Data | |
| Match ID | 50000003 |
| Match Group ID | 10000002 (Same ID as Trade Transaction 1) |
| Match Event ID | 70000002 (Same ID as Trade Transaction 1) |
| Other Attributes | -- |
| Trade Side Block 1 | |
| Side | 0 (Bid) |
| Side Trade ID | 30000003 |
| Other Attributes | -- |

Trade Transaction 3 for Book B:

|  |  |
| --- | --- |
| **Attributes** | **Value** |
| Trade Data | |
| Match ID | 50000004 |
| Match Group ID | 10000002 (Same ID as Trade Transaction 1) |
| Match Event ID | 70000002 (Same ID as Trade Transaction 1) |
| Other Attributes | -- |
| Trade Side Block 1 | |
| Side | 1 (Ask) |
| Side Trade ID | 30000004 |
| Other Attributes | -- |

#### Outright Order matches Implied Order with 2 Parents

Under the following situation, based on outright orders in Book A and B, an imply order (GREEN color) is generated into Book A/B. When a new order (RED color) entered Book A/B and matching occurs, there will be 6 transactions.

|  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Outright Book A | |  | Combo Book A/B | |  | Outright Book B | |
| BID | ASK |  | BID | ASK |  | BID | ASK |
| 2@185 |  |  | 3@5 |  |  |  | 3@180 |
| 5@185 |  |  |  |  |  |  |  |

↓

|  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Outright Book A | |  | Combo Book A/B | |  | Outright Book B | |
| BID | ASK |  | BID | ASK |  | BID | ASK |
| 2@185 |  |  | 3@5 | 5@MKT |  |  | 3@180 |
| 5@185 |  |  |  |  |  |  |  |

Trade Transaction 1 for Book A/B:

|  |  |
| --- | --- |
| **Attributes** | **Value** |
| Trade Data | |
| Match ID | 50000002 |
| Match Group ID | 10000002 |
| Match Event ID | *70000002* |
| Other Attributes | -- |
| Trade Side Block 1 | |
| Side | 1 (Ask) |
| Side Trade ID | 30000002 |
| Other Attributes | -- |
| Leg Prices 0 | |
| Leg Match ID | 80000002 |
| Other Attributes | -- |
| Leg Prices 1 | |
| Leg Match ID | 20000002 |
| Other Attributes | -- |

Trade Transaction 2 for Book A:

|  |  |
| --- | --- |
| **Attributes** | **Value** |
| Trade Data | |
| Match ID | 50000003 |
| Match Group ID | 10000002 (Same ID as Trade Transaction 1) |
| Match Event ID | 70000002 (Same ID as Trade Transaction 1) |
| Other Attributes | -- |
| Trade Side Block 1 | |
| Side | 0 (Bid) |
| Side Trade ID | 30000003 |
| Other Attributes | -- |

Trade Transaction 3 for Book B:

|  |  |
| --- | --- |
| **Attributes** | **Value** |
| Trade Data | |
| Match ID | 50000004 |
| Match Group ID | 10000002 (Same ID as Trade Transaction 1) |
| Match Event ID | 70000002 (Same ID as Trade Transaction 1) |
| Other Attributes | -- |
| Trade Side Block 1 | |
| Side | 1 (Ask) |
| Side Trade ID | 30000004 |
| Other Attributes | -- |

Trade Transaction 4 for Book A/B:

|  |  |
| --- | --- |
| **Attributes** | **Value** |
| Trade Data | |
| Match ID | 50000005 |
| Match Group ID | 10000003 (changed for another parent order) |
| Match Event ID | 70000002 (Same ID as Trade Transaction 1) |
| Other Attributes | -- |
| Trade Side Block 1 | |
| Side | 1 (Ask) |
| Side Trade ID | 30000005 |
| Other Attributes | -- |
| Leg Prices 0 | |
| Leg Match ID | 80000003 |
| Other Attributes | -- |
| Leg Prices 1 | |
| Leg Match ID | 20000003 |
| Other Attributes | -- |

Trade Transaction 5 for Book A:

|  |  |
| --- | --- |
| **Attributes** | **Value** |
| Trade Data | |
| Match ID | 50000006 |
| Match Group ID | 10000003 (Same ID as Trade Transaction 4) |
| Match Event ID | 70000002 (Same ID as Trade Transaction 1) |
| Other Attributes | -- |
| Trade Side Block 1 | |
| Side | 0 (Bid) |
| Side Trade ID | 30000006 |
| Other Attributes | -- |

Trade Transaction 6 for Book B:

|  |  |
| --- | --- |
| **Attributes** | **Value** |
| Trade Data | |
| Match ID | 50000007 |
| Match Group ID | 10000003 (Same ID as Trade Transaction 4) |
| Match Event ID | 70000002 (Same ID as Trade Transaction 1) |
| Other Attributes | -- |
| Trade Side Block 1 | |
| Side | 1 (Ask) |
| Side Trade ID | 30000007 |
| Other Attributes | -- |

#### Implied Order matches Implied Orders

Under the following situation, there are 2 implied orders in Book Z5. The first one and its parent orders are indicated in GREEN color, the second one and its parent orders are indicated in Purple color.

When a new order entered Book Q4, with orders in Book Q4/Z5, an implied order is generated into Book Z5 both indicated in RED color and matching occurs with 10 transactions.

|  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Outright  Book Q4 | |  |  | |  |  | |  |  | |  | Combo Book Q4/Z5 | |
| BID | ASK |  |  |  |  |  |  |  |  |  |  | BID | ASK |
|  |  |  |  |  |  |  |  |  |  |  |  | 6@  0 |  |

|  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | |  |  | |  | Outright  Book Z5 | |  |  | |  |  | |
|  |  |  |  |  |  | BID | ASK |  |  |  |  |  |  |
|  |  |  |  |  |  |  | 3@  18000 |  |  |  |  |  |  |
|  |  |  |  |  |  |  | 2@  18001 |  |  |  |  |  |  |

|  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Outright Book U4 | |  | Outright Book Z4 | |  |  | |  | Combo Book Z4/Z5 | |  | Combo Book U4/Z5 | |
| BID | ASK |  | BID | ASK |  |  |  |  | BID | ASK |  | BID | ASK |
|  | 6@  18005 |  |  | 2@  18005 |  |  |  |  |  | 2@  -4 |  |  | 3@  -5 |

↓

|  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Outright  Book Q4 | |  |  | |  |  | |  |  | |  | Combo Book Q4/Z5 | |
| BID | ASK |  |  |  |  |  |  |  |  |  |  | BID | ASK |
| 7@  18001 |  |  |  |  |  |  |  |  |  |  |  | 6@  0 |  |

|  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | |  |  | |  | Outright  Book Z5 | |  |  | |  |  | |
|  |  |  |  |  |  | BID | ASK |  |  |  |  |  |  |
|  |  |  |  |  |  | 6@  18001 | 3@  18000 |  |  |  |  |  |  |
|  |  |  |  |  |  |  | 2@  18001 |  |  |  |  |  |  |

|  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Outright Book U4 | |  | Outright Book Z4 | |  |  | |  | Combo Book Z4/Z5 | |  | Combo Book U4/Z5 | |
| BID | ASK |  | BID | ASK |  |  |  |  | BID | ASK |  | BID | ASK |
|  | 6@  18005 |  |  | 2@  18005 |  |  |  |  |  | 2@  -4 |  |  | 3@  -5 |

Trade Transaction 1 for Book Z5:

|  |  |
| --- | --- |
| **Attributes** | **Value** |
| Trade Data | |
| Match ID | 50000002 |
| Match Group ID | 10000002 |
| Match Event ID | 70000002 |
| Other Attributes | -- |
| Trade Side Block 1 | |
| Side | 0 (Bid) |
| Side Trade ID | 40000002 |
| Other Attributes | -- |
| Trade Side Block 2 | |
| Side | 1 (Ask) |
| Side Trade ID | 30000002 |
| Other Attributes | -- |

Trade Transaction 2 for Book U4:

|  |  |
| --- | --- |
| **Attributes** | **Value** |
| Trade Data | |
| Match ID | 50000003 |
| Match Group ID | 10000002 (Same ID as Trade Transaction 1) |
| Match Event ID | 70000002 (Same ID as Trade Transaction 1) |
| Other Attributes | -- |
| Trade Side Block 1 | |
| Side | 1 (Ask) |
| Side Trade ID | 30000003 |
| Other Attributes | -- |

Trade Transaction 3 for Book U4/Z5:

|  |  |
| --- | --- |
| **Attributes** | **Value** |
| Trade Data | |
| Match ID | 50000004 |
| Match Group ID | 10000002 (Same ID as Trade Transaction 1) |
| Match Event ID | 70000002 (Same ID as Trade Transaction 1) |
| Other Attributes | -- |
| Trade Side Block 1 | |
| Side | 1 (Ask) |
| Side Trade ID | 40000003 |
| Other Attributes | -- |
| Leg Prices 0 | |
| Leg Match ID | 80000003 |
| Other Attributes | -- |
| Leg Prices 1 | |
| Leg Match ID | 20000003 |
| Other Attributes | -- |

Trade Transaction 4 for Book Q4:

|  |  |
| --- | --- |
| **Attributes** | **Value** |
| Trade Data | |
| Match ID | 50000005 |
| Match Group ID | 10000002 (Same ID as Trade Transaction 1) |
| Match Event ID | 70000002 (Same ID as Trade Transaction 1) |
| Other Attributes | -- |
| Trade Side Block 1 | |
| Side | 0 (Bid) |
| Side Trade ID | 30000004 |
| Other Attributes | -- |

Trade Transaction 5 for Book Q4/Z5:

|  |  |
| --- | --- |
| **Attributes** | **Value** |
| Trade Data | |
| Match ID | 50000006 |
| Match Group ID | 10000002 (Same ID as Trade Transaction 1) |
| Match Event ID | 70000002 (Same ID as Trade Transaction 1) |
| Other Attributes | -- |
| Trade Side Block 1 | |
| Side | 0 (Bid) |
| Side Trade ID | 40000004 |
| Other Attributes | -- |
| Leg Prices 0 | |
| Leg Match ID | 80000004 |
| Other Attributes | -- |
| Leg Prices 1 | |
| Leg Match ID | 20000004 |
| Other Attributes | -- |

Trade Transaction 6 for Book Z5:

|  |  |
| --- | --- |
| **Attributes** | **Value** |
| Trade Data | |
| Match ID | 50000007 |
| Match Group ID | 10000003 |
| Match Event ID | 70000002 (Same ID as Trade Transaction 1) |
| Other Attributes | -- |
| Trade Side Block 1 | |
| Side | 0 (Bid) |
| Side Trade ID | 40000005 |
| Other Attributes | -- |
| Trade Side Block 2 | |
| Side | 1 (Ask) |
| Side Trade ID | 30000005 |
| Other Attributes | -- |

Trade Transaction 7 for Book Z4:

|  |  |
| --- | --- |
| **Attributes** | **Value** |
| Trade Data | |
| Match ID | 50000008 |
| Match Group ID | 10000003 (Same ID as Trade Transaction 6) |
| Match Event ID | 70000002 (Same ID as Trade Transaction 1) |
| Other Attributes | -- |
| Trade Side Block 1 | |
| Side | 1 (Ask) |
| Side Trade ID | 30000006 |
| Other Attributes | -- |

Trade Transaction 8 for Book Z4/Z5:

|  |  |
| --- | --- |
| **Attributes** | **Value** |
| Trade Data | |
| Match ID | 50000008 |
| Match Group ID | 10000003 (Same ID as Trade Transaction 6) |
| Match Event ID | 70000002 (Same ID as Trade Transaction 1) |
| Other Attributes | -- |
| Trade Side Block 1 | |
| Side | 1 (Ask) |
| Side Trade ID | 40000006 |
| Other Attributes | -- |
| Leg Prices 0 | |
| Leg Match ID | 80000005 |
| Other Attributes | -- |
| Leg Prices 1 | |
| Leg Match ID | 20000005 |
| Other Attributes | -- |

Trade Transaction 9 for Book Q4:

|  |  |
| --- | --- |
| **Attributes** | **Value** |
| Trade Data | |
| Match ID | 50000009 |
| Match Group ID | 10000003 (Same ID as Trade Transaction 6) |
| Match Event ID | 70000002 (Same ID as Trade Transaction 1) |
| Other Attributes | -- |
| Trade Side Block 1 | |
| Side | 0 (Bid) |
| Side Trade ID | 30000007 |
| Other Attributes | -- |

Trade Transaction 10 for Book Q4/Z5:

|  |  |
| --- | --- |
| **Attributes** | **Value** |
| Trade Data | |
| Match ID | 50000010 |
| Match Group ID | 10000003 (Same ID as Trade Transaction 6) |
| Match Event ID | 70000002 (Same ID as Trade Transaction 1) |
| Other Attributes | -- |
| Trade Side Block 1 | |
| Side | 0 (Bid) |
| Side Trade ID | 40000007 |
| Other Attributes | -- |
| Leg Prices 0 | |
| Leg Match ID | 80000006 |
| Other Attributes | -- |
| Leg Prices 1 | |
| Leg Match ID | 20000006 |
| Other Attributes | -- |

## Exchange On-Behalf Trade

#FS10003\_S0050\_02400

Aside from order matching, trade can be input by exchange internal staff on behalf of Exchange Participants from Admin UI.

The following parameters are required:

* Instrument ID
* Price
* Quantity
* Buy Side Participant and CompID
* Buy Side Clearing Account
* Buy Side Position Effect
* Buy Side Customer Information
* Sell Side Participant and CompID
* Sell Side Clearing Account
* Sell Side Position Effect
* Sell Side Customer Information

When the system receives the trade input, individual trade message will be sent to the relevant Exchange Participant by the CompID order session.

Beside the parameters above, exchange internal staff can also select to update the following statistic:

* Last Traded Price
* Last Traded Quantity
* High Price
* Low Price
* Open Price
* Volume

The Exchange On-Behalf Trade is disseminated to downstream system the same way as trade made by Matching Engine.

# Combo Order Book Matching

#FS10003\_S0060\_01000

When combo order matches with combo order, trades are made from combo leg order books. The trade price for each individual leg is calculated with the price calculation algorithm. The calculated leg trade price may fall outside of the order book BBO price where it is equivalent to existing system with setting allow leg price to be outside of BBO.

## Ordering of Leg Price Calculation

#FS10003\_S0060\_01100

The trade prices of combo legs are calculated one-by-one in the following ordering:

1. Start with legs where there is no spread; The BID and ASK price are the same (BID and ASK prices are determined based on the Leg BBO Price in the next section).
2. Then, take legs in the order of their tick size, starting with the largest tick size.
3. For legs with the same tick size,
   1. Choose legs with firm BBO first and then in the ordering of their spread, starting from smallest spreads. Those with same spread are ordered by the ordering defined in the combo contract.
   2. Choose remaining legs which without firm BBO, in the ordering of their spread, starting from smallest spreads. Same spread legs are ordered by the ordering in combo contract.

## Leg BBO Prices

#FS10003\_S0060\_01200

Leg BBO prices are taken directly from the top of the book.

* If both BBO prices exist, they will be taken as the leg BBO prices.

|  |
| --- |
| **BID** = Best BID price in the order book  **ASK** = Best ASK price in the order book |

When they are not available, the Theoretical BBO Prices will be calculated with Theoretical Spread Ticks (ThSpTicks). The ThSpTicks is calculated with the following formula:

|  |
| --- |
| **ThSpTicks** = The largest existing spread ticks for any of the legs, if none of the legs has a current BBO, then set to 20 ticks. |

For legs without BBO prices:

* If ASK is not available but BID exists, then assume the leg order book has largest existing spread ticks from all legs.

|  |
| --- |
| **BID** = Best BID price in the order book  **ASK** = BID + ThSpTicks \* TickSize |

* If BID is not available but ASK exists, then assume BBO spread with same method as missing ASK above.

|  |
| --- |
| **BID** = ASK - ThSpTicks \* TickSize  **ASK** = Best ASK price in the order book |

* If both BID and ASK are not available, and the last cancelled order was a BID order.

|  |
| --- |
| **BID** = The last cancelled order price  **ASK** = BID + ThSpTicks \* TickSize |

* If both BID and ASK are not available, and the last cancelled order was an ASK order.

|  |
| --- |
| **ASK** = The last cancelled order price  **BID** = ASK - ThSpTicks \* TickSize |

* If both BID and ASK are not available and no previously cancelled order, then assume the leg order book has maximum BBO spread with reference price as mid-point.

|  |
| --- |
| **Reference Price** = The last updated price amongst the following:   * Last trade price. * Previous settlement price. * Reference price received from external source. * Manually entered by business operations. * Last auction price.   **BID** = Reference Price - RoundUp(ThSpTicks / 2) \* TickSize  **ASK** = Reference Price + RoundUp(ThSpTicks / 2) \* TickSize  -----  Notes:  RoundUp means round up to the nearest integer. |

* If both BID, ASK and reference price are not available:

|  |
| --- |
| **BID** = Lowest tick in price tick table  **ASK** = BID + ThSpTicks \* tick size |

Notes:

1. The theoretical BBO prices are limited to order book tick table range.
2. When the calculated price is does not align to tick table due to different tick size between price range, round up to nearest tick price for ASK price and round down to nearest tick price for BID price.

## Leg Price Calculation Algorithm

#FS10003\_S0060\_01300

The algorithm calculates combo leg trade prices by assigning the price with proportion percentage in the BBO spread same as or as close as possible to the proportion percentage of the Combo Net price in BBO spread and aligns the price to the price tick table.

The following sections describe the calculation step-by-step, and they are repeated for every combo leg.

### Calculate Combo Order Book Theoretical BBO Prices

#FS10003\_S0060\_01400

The Theoretical BBO Prices of combo order book is calculated by summing up all the legs’ BBO prices. Orders in the combo order book are not considered in the calculation.

|  |  |  |
| --- | --- | --- |
| **Combo A/B** | | |
| Calculated  Best BID |  | Calculated  Best ASK |

|  |  |  |
| --- | --- | --- |
| ↑ | Combo BBO are calculated  from  All combo legs’ BBO prices | ↑ |

|  |  |  |
| --- | --- | --- |
| **Order Book B (Leg 1)** | | |
| Order Book  Best BID |  | Order Book  Best ASK |

+

|  |  |  |
| --- | --- | --- |
| **Order Book A (Leg 2)** | | |
| Order Book  Best BID |  | Order Book  Best ASK |

Each leg has a contribution ratio to the combo according to the combo specification. For example, Combo A/B defined as

* Buy 1 qty of B (Leg 1) (BBO 7 – 8) and,
* Sell 2 qty of A (Leg 2) (BBO 4 – 5).

(Note: Both combo and legs are having tick size 1)

The **Leg** **Ratio** of B (Leg 1) is 1, and A (Leg 2) is 2.

On top of leg ratio, the combo contract also defines the side for each leg. To factor-in the side attribute, “Buy Sell Ratio” (BSRatio) is defined as following:

|  |
| --- |
| For BUY leg:  **BSFactor** = 1  For SELL leg:  **BSFactor** = -1  **BSRatio** = BSFactor \* Leg Ratio  **Leg 1 BSRatio** = 1  **Leg 2 BSRatio** = -2 |

With BSRatio and Leg BBO prices available, Combo BBO price can be calculated by finding the lowest and highest net price to buy and sell all not yet calculated legs:

|  |
| --- |
| **Theoretical Combo Best BID (TCB)**  = SUM (Buy Legs Best BID x BSRatio) + SUM (Sell Legs Best ASK x BSRatio)  **Theoretical Combo Best ASK (TCA)**  = SUM (Buy Legs Best ASK x BSRatio) + SUM (Sell Legs Best BID x BSRatio)  **ComboA/B Theoretical Best BID** = 7 + (5 \* (-2)) = -3  **ComboA/B Theoretical Best ASK** = 8 + (4 \* (-2)) = 0 |

### Calculate Combo Net Price Proportion Percentage in the BBO Spread

#FS10003\_S0060\_01500

With Theoretical BBO price of Combo order book, the proportion percentage of Combo Net price within the BBO can be calculated.

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
| **Combo A/B** | | | | |
| Calculated  Best BID | ** % ** | Net  Price |  | Calculated  Best ASK |

The formula is as below:

|  |
| --- |
| **Combo Net Proportion %** = (Combo Net – Calculated Combo BID) / (Calculated Combo ASK – Calculated Combo BID)  **Example 1: Proportion % for Combo Net of (-2)**  Combo matching (1@-2) will be used in examples in subsequence sections.  = ((-2) - (-3)) / (0 - (-3))  = 0.333333 or 33.3333%  **Example 2: Proportion % for Combo Net of (-5)**  = ((-5) - (-3) / (0 - (-3))  = -0.666667 or -66.6667% |

### Calculate Leg Trade Price

#FS10003\_S0060\_01600

Leg trade price is calculated by using same proportion percentage as combo Net price relative to the BBO spread and then aligns to the tick table.

Based on the calculation ordering rule in section 6.1, Leg 1 will be calculated before Leg 2 based on the leg number in combo order book definition.

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
| **Leg 1** | | | | |
| Order Book  Best BID | ** % ** | Trade  Price |  | Order Book  Best ASK |

The leg trade price is calculated with the formula below:

|  |
| --- |
| **Leg Price for Buy Legs (BSRatio > 0)**  = RoundUp( Leg Bid Price + Percent x (Leg Ask Price - Leg Bid Price) )  **Leg Price for Sell Legs (BSRatio < 0)**  = RoundDown( Leg Ask Price - Percent x (Leg Ask Price - Leg Bid Price) )  **Leg Quantity** = Combo Quantity x Leg Ratio  **Example:**  **Leg 1 (BUY leg) Price** = RoundUp( 7 + 0.333333 \* (8 - 7) ) = 8  **Leg 1 (BUY leg) Quantity** = 1 x 1 = 1  -----  Notes:  RoundUp means round up to the nearest tick price.  RoundDown means round down to the nearest tick price.  When the resulting price is lower than the price tick table lowest limit, the resulting price is adjusted to the lowest limit. Vice versa, when the resulting price is higher than the price tick table upper limit, the resulting price is adjusted to the upper limit. |

### Adjust Combo Net Price

#FS10003\_S0060\_01700

With the trade price of current leg calculated, the Combo Net price is adjusted for subsequence legs calculation by removing the contribution of the current leg trade price.

|  |
| --- |
| **New Combo Net**  = Combo Net - (Leg Trade Prices x BSRatio)  **Example New Combo Net**  = (-2) - (8 x 1)  = -10 |

### Next Leg Calculation

#FS10003\_S0060\_01800

If there are more than 1 leg outstanding to be calculated after the current leg, the New Combo Net will serve as Combo Net for next leg’s calculation from section 6.3.1.

Otherwise, the last leg is calculated in following section with New Combo Net serve as Combo Net.

### The Last Leg Price

#FS10003\_S0060\_01900

The last leg is calculated by making the New Combo Net equals zero.

|  |
| --- |
| **Last Leg Price** = Absolute( Combo Net ) / Leg Ratio  **Last Leg Quantity** = Combo Quantity x Leg Ratio  **Example:**  **Leg 2 (SELL Leg) Price** = Absolute(-10) / 2 = 5  **Leg 2 (SELL Leg) Quantity** = 1 x 2 = 2 |

#### Tick Table Alignment

#FS10003\_S0060\_02000

When the last leg price does not align to the price tick table and the leg quantity is more than 1, the last leg with be split into 2 trades with the formula below:

|  |
| --- |
| **Trade 1 Price** = RoundDown ( Absolute( Combo Net ) / Leg Ratio )  **Trade 1 Quantity** = Combo Quantity x ( Leg Ratio - 1 )  **Price2** = Absolute( Combo Net ) - **Trade 1 Price** x ( Leg Ratio - 1 )  **Quantity2** = Combo Quantity  -----  Notes:  RoundDown means round down to nearest tick price. |

For example:

* Combo trade on order book A/B:
  + qty 2 @ price 181.
* The combo specification:
  + Buy 2 qty of B (Leg 1) (BBO 100 – 120), tick size 1 and,
  + Sell 3 qty of A (Leg 2) (BBO 20 – 40), tick size 0.2.

|  |
| --- |
| **ComboA/B Theoretical Best BID (TCB)** = (100 x 2) + (40 x -3) = 80  **ComboA/B Theoretical Best ASK (TCA)** = (120 x 2) + (20 x -3) = 180  **Leg Ordering** = Leg1, Leg2  **Combo Net Proportion %** = (181 - 80) / (180 - 80) = 1.01 or 101%  **Leg 1 (BUY Leg) Price** = RoundUp( 100 + 1.01 x (120 - 100) ) = 121  **Leg 1 (BUY Leg) Quantity** = 2 x 2 = 4  **New Combo Net** = 181 - ( 121 x 2 ) = -61  Last Leg (Leg 2)  **Combo Net = New Combo Net**  **Leg 2 (SELL Leg) Price** = Absolute( -61 ) / 3 = 20.33333  Not align to tick table  Split last leg into 2 Trades  **Trade 1 Price** = RoundDown( 20.33333 ) = 20.2  **Trade 1 Quantity** = 2 x ( 3 - 1 ) = 4  **Trade 2 Price** = Absolute( -61 ) - 20.2 x ( 3 - 1 ) = 20.6  **Trade 2 Quantity** = 2 |

#### Unaligned Price Tick Handling

#FS10003\_S0060\_02100

There is a catch-all policy when the price of last leg unable to align with the price tick table, the whole combo vs combo matches will not be performed. In continuous matching, the aggressive combo order will be unsolicited cancelled with specific reason. Some of the reason the unaligned leg price situation happens are:

* Extreme Combo Net price where leg prices are outside of price tick table range.
* Unusual tick size configuration. For example, the Leg1 is 0.3 and Leg2 is 0.2.

When the unaligned price tick happens in auction matching, orders from both sides involved in auction matching will be unsolicited cancelled.

# Tailor Made Combination (TMC)

#FS10003\_S0070\_01001

TMC function allows Exchange Participants to define Combination for trading through Order Flow Session or Trading GUI. TMC can only be requested to be created by Exchange Participants and neither by Business Operations nor any parties within HKEX.

#FS10003\_S0070\_01010

In Systems Parameter setting, Business Operations can configure the maximum allowed TMC records (of both ***Active*** and ***Delisted*** status) inside the system, and the maximum allowed TMC created per Participant per Day. The currently agreed default value is 20,000.

**There can be 2 to 4 legs defined per TMC. Regardless of how Exchange Participants define the TMC, ordering of the legs will always be sorted according to *Instrument Class ID & Modifier & Last Trading Date & Strike Price (Strike Price is applicable should the Leg’s Instrument Type = Options*). The system only allows at most 1 TMC Combo Group to be configured. After legs sorting, the first leg Instrument is used to determine which Combo Type and Combo Class a TMC should be created under (i.e. Leg 1 Market & TMC Combo Group & Leg 1 Underlying).

Example below:

Example 1. 4-Leg TMC (All legs are Futures)

*Reference data for each Leg Instrument:***

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
| Instrument ID | Inst. Class ID | Last Trading Date | Modifier | Strike Price |
| *HSIZ6* | HSIFUT | 2026-12-31 | 0 | 0 (default value) |
| *HSIU6* | HSIFUT | 2026-09-30 | 0 | 0 (default value) |
| *HSIR6* | HSIFUT | 2026-06-30 | 0 | 0 (default value) |
| *HSIJ6* | HSIFUT | 2026-04-30 | 0 | 0 (default value) |

***EP input Security Definition Request:***

|  |  |  |  |
| --- | --- | --- | --- |
| Leg Ordering | Leg Security ID | Leg Operation | Leg Ratio |
| *#1* | *HSIZ6* | Buy | 1 |
| *#2* | *HSIU6* | Buy | 1 |
| *#3* | *HSIR6* | Sell | 1 |
| *#4* | *HSIJ6* | Sell | 1 |

***Sorted leg ordering:***

|  |  |
| --- | --- |
| Leg Ordering | Leg Security ID |
| *#1* | *HSIJ6* |
| *#2* | *HSIR6* |
| *#3* | *HSIU6* |
| *#4* | *HSIZ6* |

**Example 2. 4-Leg TMC (All Legs are either Call or Put** Options)

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
| Instrument ID | Inst. Class ID | Last Trading Date | Modifier | Strike Price |
| *HSI9800F6* | HSIPUT | 2026-06-30 | 0 | 9800 |
| *HSI-10000F6* | HSICALL | 2026-06-30 | 0 | -10000 |
| *HSI1050F6* | HSICALL | 2026-06-30 | 0 | 1050 |
| *HSI1020F6* | HSIPUT | 2026-06-30 | 0 | 1020 |

***EP input Security Definition Request:***

|  |  |  |  |
| --- | --- | --- | --- |
| Leg Ordering | Leg Security ID | Leg Operation | Leg Ratio |
| *#1* | *HSI9800F6* | Buy | 1 |
| *#2* | *HSI1050F6* | Buy | 1 |
| *#3* | *HSI-10000F6* | Buy | 1 |
| *#4* | *HSI1020F6* | Buy | 1 |

***Sorted leg ordering:***

|  |  |
| --- | --- |
| Leg Ordering | Leg Security ID |
| *#1* | *HSI-10000F6* |
| *#2* | *HSI1050F6* |
| *#3* | *HSI1020F6* |
| *#4* | *HSI9800F6* |

**Example 3**. 4-Leg TMC (Some Legs are Futures and some Legs are Options)

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
| Instrument ID | Inst. Class ID | Last Trading Date | Modifier | Strike Price |
| *HSIZ6* | HSIFUT | 2026-12-31 | 0 | 0 (default value) |
| *HSI-10000F6* | HSICALL | 2026-06-30 | 0 | -10000 |
| *HSI1050F6* | HSICALL | 2026-06-30 | 0 | 1050 |
| *HSI10200X6* | HSIPUT | 2026-12-31 | 0 | 10200 |

***EP input Security Definition Request:***

|  |  |  |  |
| --- | --- | --- | --- |
| Leg Ordering | Leg Security ID | Leg Operation | Leg Ratio |
| *#1* | *HSIZ6* | Buy | 1 |
| *#2* | *HSI1050F6* | Sell | 1 |
| *#3* | *HSI-10000F6* | Sell | 1 |
| *#4* | *HSI10200X6* | Buy | 1 |

***Sorted leg ordering:***

|  |  |
| --- | --- |
| Leg Ordering | Leg Security ID |
| *#1* | *HSI-10000F6* |
| *#2* | *HSI1050F6* |
| *#3* | *HSIZ6* |
| *#4* | *HSI10200X6* |

#FS10003\_S0070\_01020

A Combo Type and Combo Class level configurations of ***TMC*** ***Expiration Period*** are allowed:

* One Day – TMC and outstanding orders are to be removed at DAYEND.
* One Week – TMC and outstanding orders are to be removed at DAYEND on the last trading day of the week of creation.
* Two Weeks – TMC and outstanding orders are to be removed at DAYEND on the last trading day of the second week of creation.
* Four Weeks – TMC and outstanding orders are to be removed at DAYEND on the last trading day of the fourth week of creation.

The ***Last Trading Date*** is defined according to the TMC expiration and Product’s Holiday Calendar and leg’s Last Trading Date, whichever the earliest at time of TMC creation. ***First Trading Date, First Trading Time*** and ***Last Trading Time*** would be left as empty at time of TMC creation.[[1]](#footnote-2)

#FS10003\_S0070\_01030
If ***TMC Expiration Period*** in Combo Type or Combo Class level is amended (whether shortening or lengthening), the system will delist all TMCs under the Combo Type or Combo Class (whichever the changes took place) from the next Trading Day. Outstanding GTC/GTD orders will be removed by the system and not be reloaded on the next Trading Day if TMC has been delisted.

If a TMC is delisted by Business Operations intra-day, the system will check first whether there are resting orders inside the order book of TMC. If there are indeed resting orders, the delist operation will be rejected. Otherwise, the system will proceed to delist the TMC.

#FS10003\_S0070\_01050

TMC orders are not candidates for generating implied orders, thus TMC orders will not match with outright Instrument orders.

## Restrictions

### Creation Restrictions

#FS10003\_S0070\_01071

TMC must meet the following requirements to be created –

* Number of TMC cannot exceed the configured limit in Global Parameters setting and cannot exceed the Maxima Technical Limit defined in System configuration.
* The TMC creation cannot exceed the Participant daily creation limit.
* Whether the Direct Order Flow Session or the Trading GUI User has the Trading Right in the Instrument Type of all the leg Instruments defined in the Security Definition Request.
* Legs belong to the same Underlying and are in the same Matching Engine partition.[[2]](#footnote-3)
* Leg Instrument cannot be a Combo.
* Legs are valid for trading (i.e. passed ***First Trading Date/Time***, and have not reached ***Effective Last Trading Date/Last Trading Time***)
* Leg ratios are coprime[[3]](#footnote-4) (i.e. the Security Definition Request for leg ratios 2:4 will be Rejected, as the System expects the request to be inputted as 1:2.)
* All the Price Tick details (i.e. ***Price To***, ***Tick Size***) between all Leg Instruments must match exactly, including the Combo Class TMC belongs to.
* The leg ratio must be within the ***Order Size Limit*** for the product of the TMC creating Participant or User. The lower value (defined in Trading Right entities, namely Participant Trading Right and Trading Right – Item) between Participant level and User (CompID) level is used.
  + For example, when a Leg Instrument is having ***Order Size Limit*** = 3, TMC with the leg Instrument Ratio = 4 will be rejected.
* Based on configuration in Combo Type, the following are validated:
  + Whether Legs are allowed to spread across different Markets.
  + Maximum Ratio value of Legs.
  + Maximum Ratio difference between Legs.

### Start of Day Check Restrictions

#FS10003\_S0070\_01080

If the ***TMC Expiration Period*** is configured to last longer than one day, upon next SOD, the system will check whether the TMC is still compliant with the effective configurations:

* Legs are in the same Matching Engine partition.
* Legs belong to the same Underlying.
* Legs are valid for trading (i.e. passed ***First Trading Date/Time***, and have not reached ***Effective Last Trading Date/Last Trading Time***)
* When Pre-defined Strategy List is set in Combo Type, the TMC must match one of the strategies in the list. More details are in the following “Pre-defined Strategies in Strategy List” and “No Restriction Strategy in Strategy List” section.
* All the Price Tick details (i.e. ***Price To***, ***Tick Size***) between all Leg Instruments must match exactly, including the Combo Class TMC belongs to.

If TMC is no longer compliant with the above list of restrictions, the TMC will be delisted. An exception report will be created. All TMC orders will not be reloaded from the next Trading Day without informing the Exchange Participants.

Standard Combo takes priority over TMC. Hence, should the definition of the next trading day effective Standard Combo collide with an existent TMC, the existent TMC will be delisted by the system, regardless of whether there are any resting orders inside the TMC order book.

Such system-induced delist behaviour will be recorded in the audit report for Business Operations to refer to.

### Operational Restrictions

#FS10003\_S0070\_01090

Once TMC is successfully delisted, it will not be able to be re-activated. The TMC will remain inside the Trading System from the day of being delisted (or from the expiry date, if TMC is not delisted during its life cycle) till it has exceeded the ***TMC Number Retention Days*** attribute configured at Combo Type.

## Reference Data Setup

### Pre-defined Strategies in Strategy List

#FS10003\_S0070\_01101

Please note that though the leg Instruments are sorted at time of TMC creation, the ordering of the legs do not affect the result of pre-defined strategy validation.

A pre-defined strategy restricts the type of strategy that can be created as TMC for trading. A maximum of 200 strategies is allowed, each with the following attributes:

* Strategy Name – A unique name in the strategy list.
* Description – Description of the strategy.
* Short Name – A short name to be used optionally for TMC instrument name.
* Allow Reversed – A Yes / No option, to allow reverse of existing combination.

Aside from the basic attributes above, a minimum of 2 legs must be defined with the following attributes:

* Leg Number – A sequential number which acts as an identifier of the leg entry. Maximum supports 4 legs.
* Operation – Specify the leg that should be bought or sold when buying the combo.
* Ratio Parameter:

|  |  |  |
| --- | --- | --- |
| **Parameter** | **Description** | **Values** |
| Condition | Define the parameter definition. | Exact, Relative |
| Reference Leg | The Leg which this parameter referred to when the condition is set to relative.  The reference leg is ignored when condition is set to Exact. | e.g. 1,2,3,4 |
| Parameter | When condition is Exact, the parameter defines the exact ratio of the leg.  When condition is Relative, the parameter defines the relationship to the reference leg. | For Exact Condition: 1,2,3,4.  For Relative Condition: =, >, <, ≠,2x |

* Strike Parameter (Optional):

|  |  |  |
| --- | --- | --- |
| **Parameter** | **Description** | **Values** |
| Reference Leg | The Leg which this parameter refers to. | e.g. 1,2,3,4 |
| Condition | The strike price condition relative to reference leg. | =, >, <, ≠ |

* Last Trading Date Parameter[[4]](#footnote-5) (Optional):

|  |  |  |
| --- | --- | --- |
| **Parameter** | **Description** | **Values** |
| Reference Leg | The Leg which this parameter refers to. | e.g. 1,2,3,4 |
| Condition | The last trading date condition relative to reference leg. | =, >, <, ≠ |

* Instrument Groups:

|  |  |  |
| --- | --- | --- |
| **Parameter** | **Description** | **Values** |
| Group 1 | Specify the instrument group allowed for the TMC.  When all the TMC legs match Group 1 definition, the TMC matches the Instrument Groups attribute. | Instrument group |
| Group 2 | Specify the instrument group allowed for the TMC.  When all the TMC legs match Group 2 definition, the TMC matches the Instrument Groups attribute. | Instrument group |
| Group 3 | Specify the instrument group allowed for the TMC.  When all the TMC legs match with Group 3 definition, the TMC matches the Instrument Groups attribute. | Instrument group |

**Example 1. Strategy = Calendar Spread Futures**(Short description: Calendar Spread Futures refers to a TMC Strategy which puts together Futures Instrument having different maturity dates.)

***Reference data for Strategy:***

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
| Strategy ID | Name | Description | Short Name | Allow Reversed? | Number of Legs? |
| *4* | CALENDAR\_SPREAD\_FUTURES | Calendar Spread Futures | TSFU | N – No | 2 |

***Reference data for Strategy Leg:***

|  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Leg number | Operation | Ratio | Strike Price | Last Trading Date | Instrument Group 1 | Instrument Group 2 | Instrument Group 3 |
| *#1* | S – Sell | Exact 1 | Any1 | Any | FU42 | (Blank) | (Blank) |
| *#2* | B – Buy | Exact 1 | Any | > Leg 1 | FU4 | (Blank) | (Blank) |

*1 Strike Price is not applicable for Futures Instruments, therefore it can be defined as Any or leave as Blank.
2 FU4 is the Instrument Group ID for Futures.* **Example 2. Strategy = Calendar Spread Call (Options)**(Short description: Calendar Spread Call Options refers to a TMC Strategy which puts together Call Options Instrument having different maturity dates but of the same Strike Price.)

***Reference data for Strategy:***

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
| Strategy ID | Name | Description | Short Name | Allow Reversed? | Number of Legs? |
| *5* | CALENDAR\_SPREAD\_CALL | Calendar Spread Call | TSC | N – No | 2 |

***Reference data for Strategy Leg:***

|  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Leg number | Operation | Ratio | Strike Price | Last Trading Date | Instrument Group 1 | Instrument Group 2 | Instrument Group 3 |
| *#1* | S – Sell | Exact 1 | Any | Any | ACA1 | FSC2 | (Blank) |
| *#2* | B – Buy | Exact 1 | = Leg 1 | > Leg 1 | ACA | FSC | (Blank) |

*1 ACA is the Instrument Group ID for American Call Options.*

*2 FSC is the Instrument Group ID for Futures Style Call Options.*

**Example 3. Strategy = Delta Neutral Risk Reversal**(Short description: Delta Neutral Risk Reversal refers to a TMC Strategy which puts together Options and Futures Instrument, where the Options and Futures Instruments can have different maturity dates, but the Options Instruments must have the same maturity date and the Call Options Instrument should have a higher Strike Price than the Put Options Instrument.)

***Reference data for Strategy:***

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
| Strategy ID | Name | Description | Short Name | Allow Reversed? | Number of Legs? |
| *38* | DELTA\_NEUTRAL\_RISK\_REVERSAL | Delta Neutral Risk Reversal | DNRRV | N – No | 3 |

***Reference data for Strategy Leg:***

|  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Leg number | Operation | Ratio | Strike Price | Last Trading Date | Instrument Group 1 | Instrument Group 2 | Instrument Group 3 |
| *#1* | S – Sell | Exact 1 | Any | Any | APU1 | FSP2 | (Blank) |
| *#2* | B – Buy | = Leg 1 | > Leg 1 | = Leg 1 | ACA | FSC | (Blank) |
| *#3* | S – Sell | > Leg 1 | Any | Any | FU4 | (Blank) | (Blank) |

*1 APU is the Instrument Group ID for American Put Options.*

*2 FSP is the Instrument Group ID for Futures Style Put Options.*

#### Allow Reversed Attribute

#FS10003\_S0070\_01201

When a Security Definition Request is received, after passing through all validation checks, the system will attempt to search for whether any existing Combo (including Standard Combo and TMC) has the same definition as the raised request. If found, the system always returns an existing Combo to the originating session. If no same definition Combo can be found, the system will proceed to create a TMC based on the pre-defined strategies inside the Strategy List.

An Allow Reversed indicator in the pre-defined strategy governs creation of TMC with leg operation (Buy/Sell side) exactly reversed against strategy. When the indicator is not allowed, the TMC must match exactly as the pre-defined strategy.

All amendments to the existing TMC Strategy or adding a new TMC Strategy inside the TMC Strategy List are next-day effective only. There will be no duplication checks on whether a new TMC Strategy is a composition of Strategy Legs with direct opposite operation direction with what an existing TMC Strategy is composed of[[5]](#footnote-6) (i.e. Existing **Strategy A** – 2 Leg Instruments with Buy operation at Exact ratio =1 *versus* New **Strategy B** – 2 Leg Instruments with Sell operation at Exact ratio = 1, these two are valid TMC Strategies which can co-exist inside the same TMC Strategy List).

Under the above mentioned scenario, it is possible that an existing TMC can continue to be compliant with one of the Strategies inside the Strategy List after rollover (i.e. An exact match to a pre-defined **Strategy A** was found at time of TMC creation, whereas at the next SOD after definition amendments were made, **Strategy B** was found and its ***Allowed Reversed*** attribute is defined as Yes. Thus, TMC continues to be compliant.).

A rejection response will be returned to the originating Session/User under the following scenario:
- At T1: **Strategy A** exists inside the Strategy List, with ***Allowed Reversed*** defined as No.
- At T2: Order Flow Session/User ***ABC*** requests for a TMC to be created, which is an exact match with Strategy A.
- At T3: Order Flow Session/User ***ABC*** receives an accepted successful response, with the TMC ID being returned and broadcasted to the Market.
- At T4: Order Flow Session/User ***DEF*** requests for a TMC to be created, which is a reverse of Strategy A.
- At T5: Order Flow Session/User ***DEF*** receives a rejection response.

A Combo and its reverse cannot co-exist in the system, i.e. If a Combo (Buy 1 x Leg A + Buy 1 x Leg B) exists, a Combo (Sell 1 x Leg A + Sell 1 x Leg B) cannot be created.

Behavior summary for disallowing or allowing reverse in a TMC Strategy:

***Reference data set up***: **Pre-defined Strategy (Buy - Buy)**, ***Allow Reversed*** = No, and

|  |  |  |  |
| --- | --- | --- | --- |
|  | ***Response to EP*** | | |
| ***EP Security Definition Request*** | **Not Exist** | **Buy 1 x Leg A + Buy 1 x Leg B Already Exist** | **Sell 1 x Leg A + Sell 1 x Leg B Already Exist** |
| ***Buy 1 x Leg A + Buy 1 x Leg B*** | • Response: **Accept**  • Security ID: Present, with a newly created TMC ID (Buy-Buy)  • Reversed Flag: No | • Response: **Accept**  • Security ID: Present, with the existent TMC ID (Buy-Buy)  • Reversed Flag: No | • Response: **Accept**  • Security ID: Present, with the existent TMC ID (Sell-Sell)  • Reversed Flag: Yes |
| ***Sell 1 x Leg A + Sell 1 x Leg B*** | • Response: **Reject**  • Security ID: (Blank)  • Reversed Flag: (Blank) | • Response: **Accept**  • Security ID: Present, with the existent TMC ID (Buy-Buy)  • Reversed Flag: Yes | • Response: **Accept**  • Security ID: Present, with the existent TMC ID (Sell-Sell)  • Reversed Flag: No |

***Reference data set up***: **Pre-defined Strategy (Buy - Buy)**, ***Allow Reversed*** = Yes, and

|  |  |  |  |
| --- | --- | --- | --- |
|  | ***Response to EP*** | | |
| ***EP Security Definition Request*** | **Not Exist** | **Buy 1 x Leg A + Buy 1 x Leg B Already Exist** | **Sell 1 x Leg A + Sell 1 x Leg B Already Exist** |
| ***Buy 1 x Leg A + Buy 1 x Leg B*** | • Response: **Accept**  • Security ID: Present, with a newly created TMC ID (Buy-Buy)  • Reversed Flag: No | • Response: **Accept**  • Security ID: Present, with the existent TMC ID (Buy-Buy)  • Reversed Flag: No | • Response: **Accept**  • Security ID: Present, with the existent TMC ID (Sell-Sell)  • Reversed Flag: Yes |
| ***Sell 1 x Leg A + Sell 1 x Leg B*** | • Response: **Accept**  • Security ID: Present, with a newly created TMC ID (Sell-Sell)  • Reversed Flag: No | • Response: **Accept**  • Security ID: Present, with the existent TMC ID (Buy-Buy)  • Reversed Flag: Yes | • Response: **Accept**  • Security ID: Present, with the existent TMC ID (Sell-Sell)  • Reversed Flag: No |

When the indicator is allowed, both the exact match and the reverse strategy TMC can be created when neither one already exists. If either one of them already exists, a successful response will be returned with the existing TMC ID, the requested TMC will not be created.

#### Sequence Attribute

#FS10003\_S0070\_01250

The TMC will be validated against the pre-defined Strategies by the sequence of how it is placed inside the Strategy List by Business Operations. There will be an Admin GUI screen which allows Business Operations to define and change the sequence of Strategy definition inside a Strategy List, which is next-day effective only, though this does not change the validation results.

### No Restriction Strategy in Strategy List

#FS10003\_S0070\_01300

When No restriction strategy is assigned to the Combo Type which the TMC belongs to, there will be no validation check basis, and the TMC creation would be successful under most cases. The max number of legs allowed in a strategy is same as the pre-defined strategy limit (4 Legs). The behavior of creating TMC when an exactly reversed one already exists is same as “allow reversed” in pre-defined strategy.

## TMC Definition Request, Leg Definitions and Last Trading Time

#FS10003\_S0070\_01400

TMC function allows Exchange Participants to define Combination for trading through Order Flow Session or Trading GUI. TMC can only be requested to be created by Exchange Participants and neither by Business Operations nor any parties within HKEX.

Once the TMC creation request is acknowledged and passed the validations by the system, the TMC is readily available for trade. Whether the TMC can be traded is subject to the trading status and Trading Timetable of leg Instruments[[6]](#footnote-7). The trading status and the Trading Timetable of leg Instruments do not affect the creation results of a TMC.

There will be a response following the TMC creation request regardless of whether the request is accepted or rejected. Response to an accepted request will return the Security ID of the created TMC to the requesting session and be announced to the market.

### Definition Request

The definition request includes the following attributes:

|  |  |
| --- | --- |
| **Attributes** | **Description** |
| Request ID | The ID of the request where response transaction will contain the same ID. Details refer to protocol spec. |
| Leg Definitions | 2 – 4 Leg Definitions. Each of them defines the leg instrument and attribute for the TMC. |

### Leg Definitions

#FS10003\_S0070\_01501

Each Leg Definition includes the following attributes:

|  |  |
| --- | --- |
| **Attributes** | **Description** |
| Leg Security ID | The instrument ID of the TMC leg. |
| Leg Operation | The operation of the TMC leg, the value is either Buy or Sell. |
| Leg Ratio | The ratio of the TMC leg. Must be an exact number and should be of a value (x) which complies to 1 ≤ x ≤ 4. |

### Last Trading Time

#FS10003\_S0070\_01601

By default, the ***Last Trading Time*** of TMC is empty. It means the TMC ends trading according to the time of the last Trading State inside the Trading Timetable.

In case the TMC ***Last Trading Date*** is same as leg’s ***Last Trading Date***, the ***Last Trading Time*** is as same as leg’s value.

# Appendix I. CA Type Formula

#FS10003\_S0100\_01000

Amongst Specific Parameters, all but the one listed below are from manual input. The listed are from Instrument data in the system.

* Old contracted price
* Old contract multiplier
* Old exercise price
* Old contract size

Futures contracts:

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
| **CA Event** | **Specific Parameters** | **Adjustment Ratio (AR)**  **Round to 4dp** | **Adjusted Contracted Price (ACP)**  **Round to 2dp** | **Adjusted Contract Multiplier (ACM)**  **Round to 4dp** |
| Right Issue | 1. Num of old shares (X) 2. Num of new shares (Y) 3. Subscription price per share (Z) 4. Underlying stock closing price on E-1 Day (S) 5. Old contracted price (OCP) 6. Old contract multiplier (OCM) | (X + (Y \* Z / S)  --------------------  X + Y | OCP \* AR | OCP \* OCM  ----------------------  ACP |
| Bonus Issue of Shares | 1. Num of old shares (X) 2. Num of new shares (Y) 3. Old contracted price (OCP) 4. Old contract multiplier (OCM) | X  -------------  X + Y | OCP \* AR | OCP \* OCM  ----------------------  ACP |
| Bonus Issue of Warrants | 1. Theoretical value of the warrant entitlement per share on E-1 Day (W) 2. Ordinary dividend (OD) 3. Underlying stock closing price on E-1 Day (S) 4. Old contracted price (OCP) 5. Old contract multiplier (OCM) | S – OD – W  --------------------  S – OD | OCP \* AR | OCP \* OCM  ----------------------  ACP |
| Share Consolidation | 1. Num of old shares (X) 2. Num of consolidated shares (Y) 3. Old contracted price (OCP) 4. Old contract multiplier (OCM) | X  ------  Y | OCP \* AR | OCP \* OCM  ----------------------  ACP |
| Share Sub-division | 1. Num of old shares (X) 2. Num of sub-divided shares (Y) 3. Old contracted price (OCP) 4. Old contract multiplier (OCM) | X  ------  Y | OCP \* AR | OCP \* OCM  ----------------------  ACP |
| Merger (Shares + Cash) | 1. Num of old shares (X) 2. Num of new company shares (Y) 3. Amount of cash (Z) 4. Underlying stock closing price on E-1 Day (S) 5. Old contracted price (OCP) 6. Old contract multiplier (OCM) | X – Z / S  ------  Y | OCP \* AR | OCP \* OCM  ----------------------  ACP |
| Merger (Shares Only) | 1. Num of old shares (X) 2. Num of consolidated shares (Y) 3. Old contracted price (OCP) 4. Old contract multiplier (OCM) | X  ------  Y | OCP \* AR | OCP \* OCM  ----------------------  ACP |
| Spin-Off (E Day) | 1. Old contracted price (OCP) 2. Old contract multiplier (OCM) | 1 | OCP | OCM |
| Spin-Off (F Day; with Entitlement) | 1. VWAP of the entitlement on F Day (E) 2. VWAP of the old share on F Day (S) 3. Old contracted price (OCP) 4. Old contract multiplier (OCM) | S  ------  S + E | OCP \* AR | OCP \* OCM  ----------------------  ACP  If the AR is below a configurable value (L), the formula should become:  OCM  ----------------------  L |
| Other Cash Distribution, e.g. Special Dividend | 1. Cash distribution (CD) 2. Ordinary dividend (OD) 3. Underlying stock closing price on E-1 Day (S) 4. Old contracted price (OCP) 5. Old contract multiplier (OCM) | S – OD – CD  --------------------  S – OD | OCP \* AR | OCP \* OCM  ----------------------  ACP |
| CA by Package Method | 1. Old contracted price (OCP) 2. Old contract multiplier (OCM) | 1 | OCP | OCM |
| Other CA Events | 1. Old contracted price (OCP) 2. Old contract multiplier (OCM) | Manual Input | OCP \* AR | OCP \* OCM  ----------------------  ACP |

Options Contracts:

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
| **CA Event** | **Specific Parameters** | **Adjustment Ratio (AR)**  **Round to 4dp** | **Adjusted Exercise Price (AEP)**  **Round to 2dp** | **Adjusted Contract Size (ACS)**  **Round to 4dp** |
| Right Issue | 1. Num of old shares (X) 2. Num of new shares (Y) 3. Subscription price per share (Z) 4. Underlying stock closing price on E-1 Day (S) 5. Old exercise price (OEP) 6. Old contract size (OCS) | (X + (Y \* Z / S)  --------------------  X + Y | OEP \* AR | OEP \* OCS  ----------------------  AEP |
| Bonus Issue of Shares | 1. Num of old shares (X) 2. Num of new shares (Y) 3. Old exercise price (OEP) 4. Old contract size (OCS) | X  -------------  X + Y | OEP \* AR | OEP \* OCS  ----------------------  AEP |
| Bonus Issue of Warrants | 1. Theoretical value of the warrant entitlement per share on E-1 Day (W) 2. Ordinary dividend (OD) 3. Underlying stock closing price on E-1 Day (S) 4. Old exercise price (OEP) 5. Old contract size (OCS) | S – OD – W  --------------------  S – OD | OEP \* AR | OEP \* OCS  ----------------------  AEP |
| Share Consolidation | 1. Num of old shares (X) 2. Num of consolidated shares (Y) 3. Old exercise price (OEP) 4. Old contract size (OCS) | X  ------  Y | OEP \* AR | OEP \* OCS  ----------------------  AEP |
| Share Sub-division | 1. Num of old shares (X) 2. Num of sub-divided shares (Y) 3. Old exercise price (OEP) 4. Old contract size (OCS) | X  ------  Y | OEP \* AR | OEP \* OCS  ----------------------  AEP |
| Merger (Shares + Cash) | 1. Num of old shares (X) 2. Num of new company shares (Y) 3. Amount of cash (Z) 4. Underlying stock closing price on E-1 Day (S) 5. Old exercise price (OEP) 6. Old contract size (OCS) | X – Z / S  ------  Y | OEP \* AR | OEP \* OCS  ----------------------  AEP |
| Merger (Shares Only) | 1. Num of old shares (X) 2. Num of consolidated shares (Y) 3. Old exercise price (OEP) 4. Old contract size (OCS) | X  ------  Y | OEP \* AR | OEP \* OCS  ----------------------  AEP |
| Spin-Off (E Day) | 1. Old exercise price (OEP) 2. Old contract size (OCS) | 1 | OEP | OCS |
| Spin-Off (F Day; with Entitlement) | 1. VWAP of the entitlement on F Day (E) 2. VWAP of the old share on F Day (S) 3. Old exercise price (OEP) 4. Old contract size (OCS) | S  ------  S + E | OEP \* AR | OEP \* OCS  ----------------------  AEP  If the AR is below a configurable value (L), the formula should become:  OCS  ----------------------  L |
| Other Cash Distribution, e.g. Special Dividend | 1. Cash distribution (CD) 2. Ordinary dividend (OD) 3. Underlying stock closing price on E-1 Day (S) 4. Old exercise price (OEP) 5. Old contract size (OCS) | S – OD – CD  --------------------  S – OD | OEP \* AR | OEP \* OCS  ----------------------  AEP |
| CA by Package Method | 1. Old exercise price (OEP) 2. Old contract size (OCS) | 1 | OEP | OCS |
| Other CA Events | 1. Old exercise price (OEP) 2. Old contract size (OCS) | Manual Input | OEP \* AR | OEP \* OCS  ----------------------  AEP |

1. ***Effective Last Trading Date*** will be filled with the value same as ***Last Trading Date*** at time of TMC creation. [↑](#footnote-ref-2)
2. TMC creation will be rejected as it does not allow Leg Instruments not belonging to the same Underlying being formulated as a TMC. Given all Leg Instruments under the same Underlying are physically located in the same Matching Engine partition, [↑](#footnote-ref-3)
3. Ratio values are coprime if their Greatest Common Factor is 1. [↑](#footnote-ref-4)
4. The validation is based on ***Last Trading Date*** field and not based on ***Effective Last Trading Date*** of the leg Instrument. [↑](#footnote-ref-5)
5. Assuming all other definitions, such as ***Strike Price***, ***Last Trading Date*** and ***Instrument Group(s)*** are the same. Also, the existing and the new TMC Strategy must have their ***Allowed Reversed*** attribute defined as No. [↑](#footnote-ref-6)
6. A TMC is tradable when all the conditions are met (1) All leg Instruments are not Suspended, and (2) All leg Instruments are tradeable following the Trading Timetable configurations (i.e. not holiday, currently tradeable according to the Trading State configurations). [↑](#footnote-ref-7)
