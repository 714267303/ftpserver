# ODP UAT Skills and Tooling

Conversion skills and maintained tools for generating, running, diagnosing,
and repairing ODP UAT Features.

Website exploration knowledge is isolated under [`pageExplore/`](pageExplore/).
The skills consume that knowledge base, but PageExplore does not depend on a
user Skill.

ODP business requirements are isolated under [`odp-docs/`](odp-docs/). Use its
generated index to select the relevant Functional Specification before creating
or repairing a Feature; it is a business reference, not an executable step
library.

## Quick Start

See [`USER_GUIDE.md`](USER_GUIDE.md) for the complete English generation,
execution, diagnosis, repair, and index-usage guide. The historical
`UAT_SKILL使用手册.md` is retained only in the maintainer source checkout as a
localized compatibility document and is not included in the tester archive.

For a tester checkout, copy the `PageExplore/` delivery bundle beside the
runtime `features/` and `resource/` directories:

```
ProjectA/
  features/
  resource/
  PageExplore/
```

Run the commands from `ProjectA`; bundled tools and skills resolve from that
copied `PageExplore/` tree rather than a fixed internal checkout path. The
delivery bundle does not replace the runtime checkout or its credentials.

1. From `ProjectA`, run `cp PageExplore/.env.example .env` so the result is
   `ProjectA/.env` (beside `features/`, `resource/`, and `PageExplore/`), then
   set `ODP_URL`, maker `ODP_USERNAME`/`ODP_PASSWORD`, and, for a
   maker/checker case, `ODP_CHECKER_USERNAME`/`ODP_CHECKER_PASSWORD`.
   In this source checkout, that same location is the repository-root `.env`.
   `ODP_URL` may be a full `https://host/` URL or the legacy host/IP form
   `host[:port]`; the runner normalizes the latter to HTTPS.
   For an Admin MCP run, `--odp-url URL` may be used as a non-secret override;
   the MCP process receives `.env` via `--secrets` so matching values are
   redacted from browser-tool responses. During Admin exploration, the model
   reads that exact `.env` before navigation and uses `ODP_USERNAME` and
   `ODP_PASSWORD` for the maker plus `ODP_CHECKER_USERNAME` and
   `ODP_CHECKER_PASSWORD` for Reject cleanup (the corresponding
   `SECRET_ODP_*` aliases are also accepted) only as Playwright login-field
   inputs. It must never pass dotenv key names as field
   values: standard Playwright MCP `--secrets` redacts values but does not
   substitute key names in tool inputs. Excel/YAML conversion models retain the
   restricted credential-blind policy. Exact credential values are scrubbed
   from the terminal and OpenCode transcript and must never be stored in an
   exploration report or flow manifest.
   These dotenv accounts are used by MCP rollback validation only. Generated
   Features continue to resolve `admin_gui_user1`/`admin_gui_user2` and their
   password aliases from the runtime `resource/admin_gui_value.csv`.
   Snapshot refs are observation-only handles in Admin exploration. Ref-based
   click/type/fill/select/hover/drag tools are denied, and UI actions use stable
   role/name/label/id locators through raw Playwright code. Raw locator code is
   also allowed for reviewed PageExplore Grid snippets, while direct backend
   access and fetch/XHR overrides remain banned.
   If the agent exits without its report, the batch runner writes a deterministic
   failed `exploration-report.json` from the redacted transcript diagnostics.
   If automatic discovery is ever ambiguous, pass both locations explicitly:
   `--odp-url 'https://odp-host/' --playwright-mcp-secrets "$PWD/.env"`.
2. Read [`pageExplore/sitemap.md`](pageExplore/sitemap.md) for the login procedure, SPA navigation, and all 96 page routes.
3. Refer to [`pageExplore/GRID_OPERATION_GUIDE.md`](pageExplore/GRID_OPERATION_GUIDE.md) for filtering, pagination, and row-detail templates.
4. For each page's schema, see [`pageExplore/pages/`](pageExplore/pages/).
5. Use [`pageExplore/pages/INDEX.md`](pageExplore/pages/INDEX.md) to resolve a route/profile.
6. Use [`odp-docs/INDEX.md`](odp-docs/INDEX.md) to resolve the relevant ODP business specification.

For an internal ODP site with a self-signed HTTPS certificate, the maintained
Playwright MCP installer ignores browser certificate errors by default. Set
`PLAYWRIGHT_MCP_IGNORE_HTTPS_ERRORS=0` to restore browser verification. The
OpenCode command and security boundary are documented in
[`USER_GUIDE.md`](USER_GUIDE.md#playwright-mcp-https-certificates).
The standalone Python `web-playwright` runner uses the corresponding
`PW_IGNORE_HTTPS_ERRORS=true` default and accepts `false` to restore
verification.

## Key Concepts

| Concept | Detail |
|---|---|
| **Grid Type** | Canvas-based qaGrid — no DOM `<table>` elements |
| **Data Access** | `window.qaGridApi[gridKey]` (never fetch backend APIs directly) |
| **Filter Injection** | `page.route('**/api/private/subscribeView')` + click "Apply" |
| **Open Row Detail** | Double-click on `#canvasTableWrapperRef` at computed Y position |
| **Booleans** | `"Y"` / `"N"` strings |
| **Navigation** | `window.history.pushState` + `PopStateEvent` (no `page.goto`) |

## File Reference

| File | Purpose |
|---|---|
| [`pageExplore/`](pageExplore/) | Independent ODP website exploration knowledge base |
| [`pageExplore/sitemap.md`](pageExplore/sitemap.md) | Login, SPA navigation, all 96 routes, qaGrid API reference |
| [`pageExplore/GRID_OPERATION_GUIDE.md`](pageExplore/GRID_OPERATION_GUIDE.md) | Copy-paste templates for filtering, pagination, detail pages |
| [`pageExplore/selenium_solution.md`](pageExplore/selenium_solution.md) | Selenium exploration reference |
| [`pageExplore/pages/`](pageExplore/pages/) | Per-page schema and generated route/profile index |
| [`odpt-automation-skill/Admin_GUI/flow_catalog/INDEX.md`](odpt-automation-skill/Admin_GUI/flow_catalog/INDEX.md) | Persisted semantic Playwright Admin flows and replay/reuse status |
| [`odpt-automation-skill/repair_experience/INDEX.md`](odpt-automation-skill/repair_experience/INDEX.md) | Review-gated repair findings and reusable anti-pattern lessons |
| [`pageExplore/qaGrid/Grid_API_Core_Index.md`](pageExplore/qaGrid/Grid_API_Core_Index.md) | Shared Admin/Trading `qaGridApi` contract and safety policy |
| [`odpt-automation-skill/Step_Index.md`](odpt-automation-skill/Step_Index.md) | UAT step vocabulary, source authority, and runtime resolution |
| [`odpt-automation-skill/Admin_GUI/Feature_Converter.md`](odpt-automation-skill/Admin_GUI/Feature_Converter.md) | Playwright evidence manifest → Ruby/Cucumber Admin or Hybrid Feature |
| [`odpt-automation-skill/Feature_Run_and_Debug.md`](odpt-automation-skill/Feature_Run_and_Debug.md) | Run generated or manually edited Features and diagnose failures with opencode |
| [`odp-docs/INDEX.md`](odp-docs/INDEX.md) | Restored ODP Functional Specifications and source line/hash provenance |
| [`tools/restore_odp_docs.py`](tools/restore_odp_docs.py) | Maintainer-only rebuild of `odp-docs/` from the source snapshot; tester bundles use the shipped index |

## Feature Generation Handoff

Use Playwright MCP to validate the Admin path and capture evidence, then
normalize the result into a reviewed Admin flow manifest. For a maker/checker
path, MCP submits the maker request and has the checker Reject it after
validation so no requested change becomes active. For a path without a
countersign request, it cancels before persistent save. MCP never clicks
Approve. Required approval remains a semantic Step_Index operation in the
manifest and is deferred to the generated Feature. Run
`tools/admin_feature_converter.py` for a deterministic standalone Admin draft;
raw locators and `qaGridApi.setRowData()` are never emitted as business
steps.  Existing Binary-only cases continue to use
`tools/batch_transform_tc.rb` unchanged.

The batch treats browser evidence and its JSON handoff as separate stages. It
normalizes mechanically recoverable manifest fields with before/after hashes,
then validates every semantic step and required DataTable against
`Step_Index.json`. If only that semantic handoff is invalid, one browser-free
model repair is allowed with MCP, credentials, shell, network, and business
actions disabled; the completed Playwright rollback is never rerun just to fix
`admin-flow.json`.

After a clean, rollback-validation Playwright pass, keep the raw trace/screenshots under an
isolated `outputs/admin/<case>/run-###/` directory and persist the reviewed
semantic manifest under `odpt-automation-skill/Admin_GUI/flow_catalog/flows/`.
Refresh the catalog with `python3 tools/build_admin_flow_catalog.py`; only
flows marked `verified` and `safe_to_reuse` are reused automatically. Observed
or inferred flows require the explicit `--allow-unverified-admin-flow` override.

For batch cases, the legacy three positional arguments remain compatible.
The bundled `Admin_GUI/flow_catalog/flows/` directory is searched by default;
set `ADMIN_FLOW_DIR` (or pass `--admin-flow-dir`) for case-local manifests.
When YAML contains `Execution Channel: admin_gui`, Admin work cannot silently
fall through to the generic/Binary conversion path. In a
`--repair-generated` run, a missing flow is validated automatically through
OpenCode's local Playwright MCP server. `--admin-explore` enables the same
stage in another generation mode; `--no-admin-explore` keeps the strict
conversion-only failure. Hybrid cases first generate and validate
`<case>.admin.feature`. Only after that succeeds does the batch generate an
independent non-Admin continuation. A single-day case uses `<case>.feature`;
a case with a next-trading-day batch boundary uses `<case>-Day1.feature` and
`<case>-Day2.feature`. The batch also writes `<case>.execution-flow.json` so
the ordered lifecycle is machine-readable. Admin and non-Admin artifacts are
not merged for diagnosis or repair.

The Admin/Hybrid repair pipeline is deliberately ordered as: Excel to YAML,
channel inspection, missing Admin path validation and cleanup through
Playwright MCP, standalone Admin Feature generation, exact flow/step/table
comparison, Admin execution and repair, and Admin flow promotion. A Hybrid
case's non-Admin continuation is generated and tested afterward as a separate
artifact. A new flow remains unsafe to reuse until cleanup is proven and the
standalone Admin Feature passes; failure quarantines it as
`observed`. Playwright MCP is headed by default for VNC inspection. Set
`DISPLAY=:99` (or the active display), or pass `--playwright-mcp-headless` for
an environment without a display. MCP's Reject is cleanup evidence only and is
not emitted into the semantic flow. The generated Feature repeats the maker
operation and performs the required checker Approve.

For a cross-day Hybrid case, the declared order is `admin -> day1 ->
night_batch -> day2`. `night_batch` is an external gate, not a generated
Gherkin `Wait`. A real run stops after Day1 with exit code 3. Once night batch
has actually completed and the market is OPEN, resume the stateful flow with:

```bash
ruby PageExplore/tools/batch_transform_tc.rb \
  --run-execution-flow path/to/<case>.execution-flow.json \
  --complete-gate night_batch \
  --repair-generated --run-workdir . \
  --cucumber-command 'bundle exec cucumber'
```

The acknowledgement is rejected unless the same flow is already in its
`waiting_for_gate` state. Day1 saves `<case>-Day1` through `Save FIX dumpfile`;
Day2 loads it before executing. Dry-run and preflight validation may inspect
all Features without satisfying the business gate.

The batch compares the complete Admin Background, ordered Scenario steps, and
DataTables with the MCP flow both before and after repair. If a repair drifts,
only the standalone Admin Feature is rebuilt and retested; the Binary/Batch
continuation is never used as an Admin repair target.

Feature execution is opt-in. Use `--run-generated` to run newly created
Features, `--debug-generated` to run and diagnose failures, or
`--repair-generated` (equivalently a trailing no-value `--repair`) to repair
each generated Feature and rerun it until Cucumber passes. Add
`--binary-debug` to either mode when low-level WABI/FIX diagnostics are
needed. After manually editing a Feature, use
`ruby tools/run_feature_debug.rb FEATURE --diagnose` (or the batch
`--debug-feature FEATURE` mode). Use `--error-category CATEGORY_ID` when a
generic runtime log prints a reason code without naming its FIX field. The
run report also resolves explicit FIX pairs such as `Side=1` through the
generated application/transport enum index. See
[`Feature_Run_and_Debug.md`](odpt-automation-skill/Feature_Run_and_Debug.md)
for report paths, review gates, and runtime prerequisites.

Generated drafts with unresolved account/session aliases or environment
records should remain in conversion-only mode. Use `--dry-run` for Gherkin and
step matching, or `--preflight-only` for a runtime-data readiness report.
Repair mode will not ask a model to edit around known missing data. Cucumber
steps after the first failure are skipped and are never reported as observed
page or SMP lookup failures.
Code exceptions originating in user-defined Ruby steps under
`features/customized_steps/` or `features/step_definitions/` are likewise a
hard boundary: they are reported as `custom_step_implementation`, automatic
repair is withheld, and no user `.rb` file is edited. Repair authorization is
always limited to the generated `.feature` file.

To let opencode repair one existing Feature after a failed run, use
`--repair FEATURE`. The repair prompt is limited to that Feature, verifies
the file hash and changed paths, and reruns the Feature until it passes (or
until `--repair-attempts N` is reached; `0` means no attempt limit). Use
`--repair-opencode-command` or `OPENCODE_REPAIR_CMD` for a reviewed repair
agent command. `--debug-feature` remains a read-only diagnosis mode. The
repair runner invokes the configured Cucumber prefix as
`<command> <absolute-feature-path>` (or substitutes `{feature}` when present).
In batch repair-only mode, `--opencode-command` is also used as the repair
command unless `--repair-opencode-command`/`OPENCODE_REPAIR_CMD` is set.
Repair runs write redacted candidates to `repair_experience/inbox/`; only
lessons promoted to `status=verified` and `reuse.safe_to_reuse=true` are
eligible for automatic guidance. See
[`repair_experience/README.md`](odpt-automation-skill/repair_experience/README.md).
The Playwright `Admin_GUI/flow_catalog/` remains a positive-flow catalog; failed
or unsafe shapes such as a multi-user login table are recorded only in the
review-gated repair catalog.

For an Admin/Hybrid repair, pass `--playwright-flow PATH` to compare the
Feature with a reviewed positive flow. Add a project-owned
`--playwright-replay-command` adapter and select
`--playwright-replay-mode each_attempt` to collect fresh Playwright/MCP browser
evidence before every repair cycle. The runner serializes Playwright and
Cucumber so they cannot mutate the same ODP state concurrently. The combined
JSON report records the flow hash, static step-order divergence, replay step
results, and Cucumber failure; raw browser locators are not executable Feature
input. To prove that a manually replaced SMP ID was used, forward the current
Feature as `{feature}` and optional private values as `{bindings}`; the adapter
must acknowledge their SHA256 values before replay evidence is authoritative.

For Binary/Hybrid state hand-off, generated Features must use
`Save FIX dumpfile <name>` and `Load FIX dumpfile <name>`. The legacy GUI
`Save/Load bigmap file` names are not emitted by the converter.

Batch conversion uses a permissioned `opencode run --pure --thinking` command
by default and does not inherit ODP credentials. Configure a reviewed custom
conversion command with `OPENCODE_CONVERSION_COMMAND`/`--opencode-command` and
explicit provider variables with `OPENCODE_ENV_ALLOWLIST`; automatic permission
flags are rejected. Configure a batch failure-diagnosis command separately with
`OPENCODE_DEBUG_CMD`/`--diagnose-opencode-command`. Assisted transforms execute
only newly created Features, while the standalone runner handles an exact
manually edited path.

## License

Internal tooling — HKEX ODP Trading Admin exploration.
