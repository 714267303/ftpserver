---
label: "Maintain Combo Class"
route: "/UI/uiComboClassSearchTable"
cacheName: "comboClassPermCache"
pkField: "comboClassId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "comboClassId"
    headerName: "Combo Class ID"
  - field: "$D_comboTypeId"
    headerName: "Combo Type ID"
  - field: "$D_underlyingId"
    headerName: "Underlying ID"
  - field: "description"
    headerName: "Description"
  - field: "isTraded"
    headerName: "Traded?"
  - field: "isImplied"
    headerName: "Implied?"
  - field: "currencyCode"
    headerName: "Currency"
  - field: "$D_priceTickId"
    headerName: "Price Tick ID"
  - field: "$D_priceTickLimitId"
    headerName: "Price Tick Limit ID"
  - field: "isAutoUpdatePriceTickLimit"
    headerName: "Auto Price Tick Limit Update?"
  - field: "$D_specialTradingDaysId"
    headerName: "Special Trading Days ID"
  - field: "$D_timetableId"
    headerName: "Normal Day Timetable ID"
  - field: "isBlockTradeEligible"
    headerName: "Block Trade Eligible?"
  - field: "blockTradeMinVolume"
    headerName: "Block Trade Minimum Volume Thresholds"
  - field: "lotSize"
    headerName: "Lot Size"
  - field: "tmcExpirationPeriod"
    headerName: "TMC Expiration Period"
  - field: "$D_nameStdId"
    headerName: "Name Standard ID"
  - field: "isAutoGeneration"
    headerName: "Auto Generation?"
booleanFields: ["isTraded", "isImplied", "isAutoUpdatePriceTickLimit", "isBlockTradeEligible", "isAutoGeneration"]
codeFields: ["recordStatus"]
sampleFields: ["comboClassId", "description", "$D_comboTypeId", "$D_underlyingId", "isTraded", "recordStatus"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Combo Class ID"
        type: combobox
      - label: "Combo Type ID"
        type: combobox
      - label: "Underlying ID"
        type: combobox
      - label: "Description"
        type: textbox
  - heading: "General"
    fields:
      - label: "Implied?"
        type: combobox
  - heading: "Calendar"
    fields:
      - label: "Special Trading Days ID"
        type: combobox
      - label: "Normal Day Timetable ID"
        type: combobox
  - heading: "Price"
    fields:
      - label: "Currency"
        type: textbox
      - label: "Auto Price Tick Limit Update?"
        type: combobox
      - label: "Price Tick Limit ID"
        type: combobox
      - label: "Price Tick ID"
        type: combobox
  - heading: "Auto Generation"
    fields:
      - label: "Auto Generation?"
        type: combobox
  - heading: "Trading Parameters"
    fields:
      - label: "Traded?"
        type: combobox
      - label: "Block Trade Eligible?"
        type: combobox
      - label: "Block Trade Minimum Volume Thresholds"
        type: textbox
      - label: "Name Standard ID"
        type: combobox
      - label: "Lot Size"
        type: textbox
  - heading: "TMC"
    fields:
      - label: "TMC Expiration Period"
        type: textbox

---

