---
label: "Maintain Inst. Group"
route: "/UI/uiInstGroupSearchTable"
cacheName: "instGroupPermCache"
pkField: "instGroupId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "instGroupId"
    headerName: "Inst. Group ID"
  - field: "instGroupCode"
    headerName: "Inst. Group Code"
  - field: "shortName"
    headerName: "Short Name"
  - field: "description"
    headerName: "Description"
  - field: "groupType"
    headerName: "Group Type"
  - field: "isPhysicalDelivery"
    headerName: "Physical Delivery?"
  - field: "isMaturity"
    headerName: "Maturity?"
  - field: "optionsType"
    headerName: "Options Type"
  - field: "optionsStyle"
    headerName: "Options Style"
  - field: "optionsVariant"
    headerName: "Options Variant"
  - field: "isFuturesStyledOptions"
    headerName: "Futures Styled Options?"
booleanFields:
  - field: "isPhysicalDelivery"
    headerName: "Physical Delivery?"
  - field: "isMaturity"
    headerName: "Maturity?"
  - field: "isFuturesStyledOptions"
    headerName: "Futures Styled Options?"
codeFields: ["recordStatus", "groupType", "optionsType", "optionsStyle", "optionsVariant"]
sampleFields: ["instGroupId", "instGroupCode", "shortName", "description", "isPhysicalDelivery", "recordStatus"]
notes: "isPhysicalDelivery is server-filterable (verified); no isIndex field on this page"
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Inst. Group ID"
        type: combobox
      - label: "Description"
        type: textbox
      - label: "Inst. Group Code"
        type: combobox
      - label: "Short Name"
        type: textbox
  - heading: "General"
    fields:
      - label: "Group Type"
        type: combobox
      - label: "Physical Delivery?"
        type: combobox
      - label: "Maturity?"
        type: combobox
  - heading: "Options Attributes"
    fields:
      - label: "Options Type"
        type: combobox
      - label: "Options Style"
        type: textbox
      - label: "Options Variant"
        type: textbox
      - label: "Futures Styled Options?"
        type: combobox

---
