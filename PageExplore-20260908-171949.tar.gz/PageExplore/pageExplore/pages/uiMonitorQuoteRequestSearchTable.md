---
label: "Monitor Quote Request"
route: "/UI/uiMonitorQuoteRequestSearchTable"
cacheName: "monitorQuoteRequestPermCache"
pkField: ""
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "time"
    headerName: "Time"
  - field: "instId"
    headerName: "Inst. ID"
  - field: "partId"
    headerName: "Part. ID"
  - field: "userId"
    headerName: "User ID"
  - field: "ba"
    headerName: "B/A"
  - field: "status"
    headerName: "Status"
booleanFields: []
codeFields: ["ba", "status"]
sampleFields: ["time", "instId", "partId", "userId", "ba", "status"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Inst. ID"
        type: combobox
      - label: "Part. ID"
        type: combobox
      - label: "User ID"
        type: combobox
  - heading: "General"
    fields:
      - label: "Time"
        type: textbox
      - label: "B/A"
        type: combobox
      - label: "Status"
        type: combobox
---
