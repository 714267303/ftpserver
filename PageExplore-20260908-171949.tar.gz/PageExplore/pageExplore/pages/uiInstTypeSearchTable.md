---
label: "Maintain Inst. Type"
route: "/UI/uiInstTypeSearchTable"
cacheName: "instTypePermCache"
pkField: "instTypeId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "instTypeId"
    headerName: "Inst. Type ID"
  - field: "$D_marketId"
    headerName: "Market ID"
  - field: "$D_instGroupId"
    headerName: "Inst. Group ID"
  - field: "description"
    headerName: "Description"
  - field: "isTraded"
    headerName: "Traded?"
  - field: "$D_specialTradingDaysId"
    headerName: "Special Trading Days ID"
  - field: "$D_timetableId"
    headerName: "Normal Day Timetable ID"
  - field: "isBlockTradeEligible"
    headerName: "Block Trade Eligible?"
  - field: "identifyInQuoteRequest"
    headerName: "Identify In Quote Request?"
  - field: "defaultOrderSizeLimit"
    headerName: "Default Order Size Limit"
  - field: "defaultBlockTradeSizeLimit"
    headerName: "Default Block Trade Size Limit"
  - field: "orderSizeLimitByEp"
    headerName: "Maximum Order Size Limit by EP"
  - field: "blockTradeSizeLimitByEp"
    headerName: "Maximum Block Trade Size Limit by EP"
booleanFields:
  - field: "isTraded"
    headerName: "Traded?"
  - field: "isBlockTradeEligible"
    headerName: "Block Trade Eligible?"
  - field: "identifyInQuoteRequest"
    headerName: "Identify In Quote Request?"
codeFields: ["recordStatus"]
sampleFields: ["instTypeId", "description", "isTraded", "recordStatus", "isBlockTradeEligible", "defaultOrderSizeLimit"]
notes: "isTraded server-filterable"
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Inst. Type ID"
        type: combobox
      - label: "Market ID"
        type: combobox
      - label: "Inst. Group ID"
        type: combobox
      - label: "Description"
        type: textbox
  - heading: "Calendar"
    fields:
      - label: "Special Trading Days ID"
        type: combobox
      - label: "Normal Day Timetable ID"
        type: combobox
  - heading: "Trading Parameters"
    fields:
      - label: "Traded?"
        type: combobox
      - label: "Block Trade Eligible?"
        type: combobox
      - label: "Identify In Quote Request?"
        type: combobox
      - label: "Default Order Size Limit"
        type: textbox
      - label: "Default Block Trade Size Limit"
        type: textbox
      - label: "Maximum Order Size Limit by EP"
        type: textbox
      - label: "Maximum Block Trade Size Limit by EP"
        type: textbox

---
