---
label: "Maintain Report"
route: "/UI/uiReportSearchTable"
cacheName: "reportPermCache"
pkField: "rptId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "rptId"
    headerName: "Report ID"
  - field: "name"
    headerName: "Name"
  - field: "description"
    headerName: "Description"
  - field: "$D_rptTypeId"
    headerName: "Report Type ID"
  - field: "rptHeader"
    headerName: "Header"
  - field: "rptHeaderCh"
    headerName: "Chinese Header Name"
  - field: "keepDay"
    headerName: "Keep Day for Spot Month"
  - field: "expirationFreq"
    headerName: "Expiration Frequency"
  - field: "$D_rptGrpListId"
    headerName: "Report Group List ID"
  - field: "rptGrpId"
    headerName: "Report Group ID"
  - field: "$D_tradingStateId"
    headerName: "Trading State ID"
booleanFields: []
codeFields: []
sampleFields: ["requestStatus", "requestAction", "recordStatus", "rptId", "name"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Report ID"
        type: combobox
      - label: "Name"
        type: textbox
      - label: "Description"
        type: textbox
      - label: "Report Type ID"
        type: combobox
      - label: "Report Group List ID"
        type: combobox
      - label: "Report Group ID"
        type: combobox
  - heading: "General"
    fields:
      - label: "Header"
        type: textbox
      - label: "Chinese Header Name"
        type: textbox
      - label: "Keep Day for Spot Month"
        type: textbox
      - label: "Expiration Frequency"
        type: textbox
      - label: "Trading State ID"
        type: combobox
---
