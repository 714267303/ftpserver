---
label: "Control Contingency Trigger of Inst. Class Price Tick Limit"
route: "/UI/uiControlContingencyTriggerOfPriceTickLimitCalculationSearchTable"
cacheName: "controlContingencyTriggerOfPriceTickLimitCalculationPermCache"
pkField: "instClassId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "instClassId"
    headerName: "Inst. Class ID"
booleanFields: []
codeFields: []
sampleFields: ["instClassId"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Inst. Class ID"
        type: combobox
---
