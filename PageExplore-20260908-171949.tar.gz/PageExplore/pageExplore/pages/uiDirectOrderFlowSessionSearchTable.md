---
label: "Maintain Direct Order Flow Session"
route: "/UI/uiDirectOrderFlowSessionSearchTable"
cacheName: "directOrderFlowSessionPermCache"
pkField: "compId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "compId"
    headerName: "Comp ID"
  - field: "$COT_traderId"
    headerName: "Trader ID"
  - field: "$D_exchangeParticipantId"
    headerName: "Exchange Part. ID"
  - field: "isBlocked"
    headerName: "Blocked?"
  - field: "blockedReason"
    headerName: "Blocked Reason"
  - field: "gwServiceType"
    headerName: "Service Type"
  - field: "gwSessionUsage"
    headerName: "Session Usage"
  - field: "partitionId"
    headerName: "Partition ID"
  - field: "subPartitionId"
    headerName: "Sub Partition ID"
  - field: "interfaceProtocol"
    headerName: "Interface Protocol"
  - field: "$D_ipAddrListId"
    headerName: "Legal IP Address List ID"
  - field: "lastPasswordSetTimestamp"
    headerName: "Last Password Set Timestamp"
  - field: "$CSE_lastSignonTime"
    headerName: "Last Successful Logon Time"
  - field: "$D_passwordPolicyId"
    headerName: "Password Policy ID"
  - field: "$CSE_isLocked"
    headerName: "Locked?"
  - field: "$CSE_passwordExpiryDate"
    headerName: "Password Expiration Date"
  - field: "numMissingHeartbeat"
    headerName: "Number Of Missing Heartbeat"
  - field: "$CIO_timeoutBeforeCod"
    headerName: "Timeout Before COD"
  - field: "$CIO_orderThrottle"
    headerName: "Order Throttle"
  - field: "$D_$TR_participantUserRoleId"
    headerName: "Participant User Role ID"
  - field: "$D_$TR_tradingRightId"
    headerName: "Trading Right ID"
  - field: "$CIO_isReceiveNonCriticalMktMsg"
    headerName: "Receive Non-Critical Market Messages?"
booleanFields: []
codeFields: []
sampleFields: ["requestStatus", "requestAction", "recordStatus", "compId", "$COT_traderId"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Comp ID"
        type: combobox
      - label: "Trader ID"
        type: combobox
      - label: "Exchange Part. ID"
        type: combobox
  - heading: "Session Configuration"
    fields:
      - label: "Service Type"
        type: combobox
      - label: "Session Usage"
        type: combobox
      - label: "Partition ID"
        type: combobox
      - label: "Sub Partition ID"
        type: combobox
      - label: "Interface Protocol"
        type: combobox
      - label: "Legal IP Address List ID"
        type: combobox
      - label: "Password Policy ID"
        type: combobox
  - heading: "Trading Configuration"
    fields:
      - label: "Participant User Role ID"
        type: combobox
      - label: "Trading Right ID"
        type: combobox
      - label: "Timeout Before COD"
        type: textbox
      - label: "Order Throttle"
        type: textbox
      - label: "Receive Non-Critical Market Messages?"
        type: combobox
  - heading: "Security"
    fields:
      - label: "Blocked?"
        type: combobox
      - label: "Blocked Reason"
        type: textbox
      - label: "Locked?"
        type: combobox
      - label: "Password Expiration Date"
        type: textbox
      - label: "Last Password Set Timestamp"
        type: textbox
      - label: "Last Successful Logon Time"
        type: textbox
      - label: "Number Of Missing Heartbeat"
        type: textbox
---
