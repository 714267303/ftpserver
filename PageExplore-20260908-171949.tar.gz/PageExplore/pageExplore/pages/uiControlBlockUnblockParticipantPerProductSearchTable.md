---
label: "Control Block/Unblock Participant Per Product"
route: "/UI/uiControlBlockUnblockParticipantPerProductSearchTable"
cacheName: "controlBlockUnblockParticipantPerProductPermCache"
pkField: "participantId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: ""
    headerName: ""
  - field: "participantId"
    headerName: "ID"
  - field: "productHierarchyLevel"
    headerName: "Level"
  - field: "entity"
    headerName: "Entity"
  - field: "description"
    headerName: "Description"
  - field: "currencyCode"
    headerName: "Currency"
  - field: "isBlocked"
    headerName: "Blocked?"
  - field: "action"
    headerName: "Action"
  - field: "when"
    headerName: "When"
  - field: "modifiedBy"
    headerName: "Modified By"
booleanFields: []
codeFields: []
sampleFields: ["participantId", "productHierarchyLevel", "entity", "description", "currencyCode"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "ID"
        type: combobox
      - label: "Entity"
        type: textbox
      - label: "Description"
        type: textbox
  - heading: "General"
    fields:
      - label: "Level"
        type: combobox
      - label: "Currency"
        type: textbox
      - label: "Blocked?"
        type: combobox
      - label: "Action"
        type: combobox
      - label: "When"
        type: textbox
      - label: "Modified By"
        type: textbox
---
