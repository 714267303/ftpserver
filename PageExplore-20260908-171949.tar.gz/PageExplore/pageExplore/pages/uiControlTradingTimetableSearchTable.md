---
label: "Control Trading Timetable"
route: "/UI/uiControlTradingTimetableSearchTable"
cacheName: "controlTradingTimetablePermCache"
pkField: "combinedId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "checkbox"
    headerName: ""
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "combinedId"
    headerName: "combinedId"
  - field: "productId"
    headerName: "Market ID / Type ID / Class ID"
  - field: "levelType"
    headerName: "Level"
  - field: "productType"
    headerName: "Product Type"
  - field: "currentTradingState"
    headerName: "Current Trading State"
  - field: "nextTradingState"
    headerName: "Next Trading State"
booleanFields: []
codeFields: []
sampleFields: ["requestStatus", "combinedId", "productId", "levelType", "productType"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "combinedId"
        type: combobox
      - label: "Market ID / Type ID / Class ID"
        type: combobox
  - heading: "General"
    fields:
      - label: "Level"
        type: combobox
      - label: "Product Type"
        type: combobox
      - label: "Current Trading State"
        type: combobox
      - label: "Next Trading State"
        type: combobox
---
