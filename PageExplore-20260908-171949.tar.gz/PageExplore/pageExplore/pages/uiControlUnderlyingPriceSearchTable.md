---
label: "Control Underlying Price"
route: "/UI/uiControlUnderlyingPriceSearchTable"
cacheName: "controlUnderlyingPricePermCache"
pkField: "underlyingId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: ""
    headerName: ""
  - field: "underlyingId"
    headerName: "Underlying ID"
  - field: "status"
    headerName: "Status"
  - field: "lastTradedPrice"
    headerName: "Last Traded Price"
  - field: "recvLastTradedPrice"
    headerName: "Received Last Traded Price"
  - field: "decimalsInRecvLastTradedPrice"
    headerName: "Decimals In Received Last Traded Price"
  - field: "lastTradedPriceUpdateType"
    headerName: "Last Traded Price Update Type"
  - field: "lastTradedPriceUpdateTime"
    headerName: "Last Traded Price Update Time"
  - field: "settlementPrice"
    headerName: "Settlement Price"
  - field: "recvSettlementPrice"
    headerName: "Received Settlement Price"
  - field: "decimalsInRecvSettlementPrice"
    headerName: "Decimals In Received Settlement Price"
  - field: "settlementPriceUpdateType"
    headerName: "Settlement Price Update Type"
  - field: "settlementPriceUpdateTime"
    headerName: "Settlement Price Update Time"
booleanFields: []
codeFields: ["status", "lastTradedPriceUpdateType", "settlementPriceUpdateType"]
sampleFields: ["underlyingId", "lastTradedPrice", "settlementPrice", "status", "lastTradedPriceUpdateType"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Underlying ID"
        type: combobox
  - heading: "General"
    fields:
      - label: "Status"
        type: combobox
  - heading: "Last Traded Price"
    fields:
      - label: "Last Traded Price"
        type: textbox
      - label: "Received Last Traded Price"
        type: textbox
      - label: "Decimals In Received Last Traded Price"
        type: textbox
      - label: "Last Traded Price Update Type"
        type: combobox
      - label: "Last Traded Price Update Time"
        type: textbox
  - heading: "Settlement Price"
    fields:
      - label: "Settlement Price"
        type: textbox
      - label: "Received Settlement Price"
        type: textbox
      - label: "Decimals In Received Settlement Price"
        type: textbox
      - label: "Settlement Price Update Type"
        type: combobox
      - label: "Settlement Price Update Time"
        type: textbox
---
