---
label: "Maintain Strike Price Range"
route: "/UI/uiStrikePriceRangeSearchTable"
cacheName: "strikePriceRangePermCache"
pkField: "strikePriceRangeId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "strikePriceRangeId"
    headerName: "Strike Price Range ID"
  - field: "name"
    headerName: "Name"
  - field: "description"
    headerName: "Description"
  - field: "method"
    headerName: "Method"
  - field: "upRange"
    headerName: "Up Range Percentage"
  - field: "upRangeStep"
    headerName: "Up Range Step"
  - field: "downRange"
    headerName: "Down Range Percentage"
  - field: "downRangeStep"
    headerName: "Down Range Step"
  - field: "$D_strikePriceTableId"
    headerName: "Strike Price Table ID"
booleanFields: []
codeFields: ["recordStatus", "method"]
sampleFields: ["strikePriceRangeId", "name", "description", "method", "recordStatus"]
notes: "Small dataset (11 rows); $D prefix indicates display-only field"
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Strike Price Range ID"
        type: combobox
      - label: "Name"
        type: textbox
      - label: "Description"
        type: textbox
      - label: "Strike Price Table ID"
        type: combobox
  - heading: "General"
    fields:
      - label: "Method"
        type: combobox
      - label: "Up Range Percentage"
        type: textbox
      - label: "Up Range Step"
        type: textbox
      - label: "Down Range Percentage"
        type: textbox
      - label: "Down Range Step"
        type: textbox
---
