---
label: "Monitor Historical Order Book"
route: "/UI/uiMonitorHistoricalOrderBookSearchTable"
cacheName: "monitorHistoricalOrderBookPermCache"
pkField: ""
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "bTrd"
    headerName: "B TRD"
  - field: "bPart"
    headerName: "B PART"
  - field: "bType"
    headerName: "TYPE"
  - field: "bQty"
    headerName: "B QTY"
  - field: "bid"
    headerName: "BID"
  - field: "ask"
    headerName: "ASK"
  - field: "aQty"
    headerName: "A QTY"
  - field: "aType"
    headerName: "TYPE"
  - field: "aPart"
    headerName: "A PART"
  - field: "aTrd"
    headerName: "A TRD"
booleanFields: []
codeFields: ["bType", "aType"]
sampleFields: ["bTrd", "bPart", "bid", "ask", "aPart"]
notes: "Order book depth view; no data currently (rowCount=0)"
profiled: true
details:
  - heading: "Bid Side"
    fields:
      - label: "B TRD"
        type: textbox
      - label: "B PART"
        type: textbox
      - label: "TYPE"
        type: combobox
      - label: "B QTY"
        type: textbox
      - label: "BID"
        type: textbox
  - heading: "Ask Side"
    fields:
      - label: "ASK"
        type: textbox
      - label: "A QTY"
        type: textbox
      - label: "TYPE"
        type: combobox
      - label: "A PART"
        type: textbox
      - label: "A TRD"
        type: textbox
---
