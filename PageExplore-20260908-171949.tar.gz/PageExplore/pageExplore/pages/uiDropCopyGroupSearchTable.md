---
label: "Maintain Drop Copy Group"
route: "/UI/uiDropCopyGroupSearchTable"
cacheName: "dropCopyGroupPermCache"
pkField: "dropCopyGroupId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "dropCopyGroupId"
    headerName: "Drop Copy Group ID"
  - field: "name"
    headerName: "Name"
  - field: "participantId"
    headerName: "Exchange Part. ID"
  - field: "description"
    headerName: "Description"
booleanFields: []
codeFields: []
sampleFields: ["requestStatus", "requestAction", "recordStatus", "dropCopyGroupId", "name"]
notes: "No data currently; grid structure may still be empty."
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Drop Copy Group ID"
        type: combobox
      - label: "Name"
        type: textbox
      - label: "Exchange Part. ID"
        type: combobox
      - label: "Description"
        type: textbox
---
