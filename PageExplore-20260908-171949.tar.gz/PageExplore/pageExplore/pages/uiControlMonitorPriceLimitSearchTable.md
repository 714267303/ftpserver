---
label: "Control & Monitor Price Limit"
route: "/UI/uiControlMonitorPriceLimitSearchTable"
cacheName: "controlMonitorPriceLimitPermCache"
pkField: "instId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: ""
    headerName: ""
  - field: "instId"
    headerName: "Inst. ID"
  - field: "effectiveUpperPrice"
    headerName: "Upper Price"
  - field: "effectiveLowerPrice"
    headerName: "Lower Price"
  - field: "manualUpdatedSplRefPrice"
    headerName: "Manually Updated Ref Price"
  - field: "splRefPrice"
    headerName: "Effective Ref Price"
  - field: "calculatedSplRefPrice"
    headerName: "Calculated Ref Price"
  - field: "splUpperPrice"
    headerName: "Upper Price"
  - field: "splLowerPrice"
    headerName: "Lower Price"
  - field: "splUpperLimit"
    headerName: "Upper Limit"
  - field: "splLowerLimit"
    headerName: "Lower Limit"
  - field: "splDeviationUnit"
    headerName: "Unit"
  - field: "manualUpdatedDplRefPrice"
    headerName: "Manually Updated Ref Price"
  - field: "dplRefPrice"
    headerName: "Effective Ref Price"
  - field: "dplUpperPrice"
    headerName: "Upper Price"
  - field: "dplLowerPrice"
    headerName: "Lower Price"
  - field: "dplUpperLimit"
    headerName: "Upper Limit"
  - field: "dplLowerLimit"
    headerName: "Lower Limit"
  - field: "dplDeviationUnit"
    headerName: "Unit"
booleanFields: []
codeFields: []
sampleFields: ["instId", "effectiveUpperPrice", "effectiveLowerPrice", "manualUpdatedSplRefPrice", "splRefPrice"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Inst. ID"
        type: combobox
  - heading: "Static Price Limit"
    fields:
      - label: "Effective Upper Price"
        type: textbox
      - label: "Effective Lower Price"
        type: textbox
      - label: "Manually Updated Ref Price"
        type: textbox
      - label: "Effective Ref Price"
        type: textbox
      - label: "Calculated Ref Price"
        type: textbox
      - label: "Upper Price"
        type: textbox
      - label: "Lower Price"
        type: textbox
      - label: "Upper Limit"
        type: textbox
      - label: "Lower Limit"
        type: textbox
      - label: "Unit"
        type: textbox
  - heading: "Dynamic Price Limit"
    fields:
      - label: "Manually Updated Ref Price"
        type: textbox
      - label: "Effective Ref Price"
        type: textbox
      - label: "Upper Price"
        type: textbox
      - label: "Lower Price"
        type: textbox
      - label: "Upper Limit"
        type: textbox
      - label: "Lower Limit"
        type: textbox
      - label: "Unit"
        type: textbox
---
