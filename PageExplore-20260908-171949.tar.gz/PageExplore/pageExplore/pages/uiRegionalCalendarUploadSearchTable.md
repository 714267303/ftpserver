---
label: "Regional Calendar Upload"
route: "/UI/uiRegionalCalendarUploadSearchTable"
cacheName: "regionalCalendarUploadPermCache"
pkField: "isoCode"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "isoCode"
    headerName: "ISO Code"
  - field: "regCalName"
    headerName: "Regional Calendar Name"
  - field: "eventDate"
    headerName: "Event Date"
  - field: "eventName"
    headerName: "Event Name"
booleanFields: []
codeFields: ["recordStatus"]
sampleFields: ["isoCode", "regCalName", "eventDate", "eventName", "recordStatus"]
notes: "Upload page with grid for uploaded calendar entries; 0 rows currently"
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "ISO Code"
        type: combobox
      - label: "Regional Calendar Name"
        type: textbox
  - heading: "General"
    fields:
      - label: "Event Date"
        type: textbox
      - label: "Event Name"
        type: textbox
---
