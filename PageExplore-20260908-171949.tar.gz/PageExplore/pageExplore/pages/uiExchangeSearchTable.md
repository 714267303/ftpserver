---
label: "Maintain Exchange"
route: "/UI/uiExchangeSearchTable"
cacheName: "exchangePermCache"
pkField: "exchangeId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "exchangeId"
    headerName: "Exchange ID"
  - field: "exchangeCode"
    headerName: "Exchange Code"
  - field: "description"
    headerName: "Description"
  - field: "shortName"
    headerName: "Short Name"
booleanFields: []
codeFields: ["recordStatus"]
sampleFields: ["exchangeId", "exchangeCode", "description", "shortName", "recordStatus"]
notes: "Only 2 rows (00=SYSTEM, HK=HKFE); exchangeId is NOT server-filterable (silently ignored)"
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Exchange ID"
        type: combobox
      - label: "Exchange Code"
        type: combobox
      - label: "Description"
        type: textbox
      - label: "Short Name"
        type: textbox

---
