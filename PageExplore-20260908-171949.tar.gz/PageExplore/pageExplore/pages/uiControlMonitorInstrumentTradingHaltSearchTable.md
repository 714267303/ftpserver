---
label: "Control & Monitor Instrument Trading Halt"
route: "/UI/uiControlMonitorInstrumentTradingHaltSearchTable"
cacheName: "controlMonitorInstrumentTradingHaltPermCache"
pkField: "instId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: ""
    headerName: ""
  - field: "instId"
    headerName: "Inst. ID"
  - field: "isHalt"
    headerName: "Halt?"
  - field: "lastUpdateTime"
    headerName: "Last Update Time"
booleanFields: []
codeFields: []
sampleFields: ["instId", "isHalt", "lastUpdateTime"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Inst. ID"
        type: combobox
  - heading: "General"
    fields:
      - label: "Halt?"
        type: combobox
      - label: "Last Update Time"
        type: textbox
---
