---
label: "Maintain TMC Strategy"
route: "/UI/uiTmcStrategySearchTable"
cacheName: "tmcStrategyPermCache"
pkField: "tmcStrategyId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "tmcStrategyId"
    headerName: "Strategy ID"
  - field: "tmcStrategyName"
    headerName: "Name"
  - field: "description"
    headerName: "Description"
  - field: "shortName"
    headerName: "Short Name"
  - field: "isAllowedReversed"
    headerName: "Allow Reversed?"
  - field: "numLegs"
    headerName: "Number of Legs"
booleanFields: []
codeFields: []
sampleFields: ["requestStatus", "requestAction", "recordStatus", "tmcStrategyId", "tmcStrategyName"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Strategy ID"
        type: combobox
      - label: "Name"
        type: textbox
      - label: "Description"
        type: textbox
      - label: "Short Name"
        type: textbox
  - heading: "General"
    fields:
      - label: "Allow Reversed?"
        type: combobox
      - label: "Number of Legs"
        type: textbox
---
