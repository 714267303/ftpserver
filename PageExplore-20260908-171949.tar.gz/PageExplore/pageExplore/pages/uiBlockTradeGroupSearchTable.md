---
label: "Maintain Block Trade Group"
route: "/UI/uiBlockTradeGroupSearchTable"
cacheName: "blockTradeGroupPermCache"
pkField: "blockTradeGroupId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "blockTradeGroupId"
    headerName: "Block Trade Group ID"
  - field: "name"
    headerName: "Name"
  - field: "description"
    headerName: "Description"
  - field: "isInternalAllowed"
    headerName: "Internal Allowed?"
  - field: "isInterbankAllowed"
    headerName: "Interbank Allowed?"
  - field: "isOnBehalfAllowed"
    headerName: "On-behalf Allowed?"
booleanFields: []
codeFields: []
sampleFields: ["requestStatus", "requestAction", "recordStatus", "blockTradeGroupId", "name"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Block Trade Group ID"
        type: combobox
      - label: "Name"
        type: textbox
      - label: "Description"
        type: textbox
  - heading: "General"
    fields:
      - label: "Internal Allowed?"
        type: combobox
      - label: "Interbank Allowed?"
        type: combobox
      - label: "On-behalf Allowed?"
        type: combobox
---
