---
label: "Control Contingency Trigger of Combo Class Price Tick Limit"
route: "/UI/uiControlContingencyTriggerOfComboClassPriceTickLimitCalculationSearchTable"
cacheName: "controlContingencyTriggerOfComboClassPriceTickLimitCalculationPermCache"
pkField: "comboClassId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "comboClassId"
    headerName: "Combo Class ID"
booleanFields: []
codeFields: []
sampleFields: ["comboClassId"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Combo Class ID"
        type: combobox
---
