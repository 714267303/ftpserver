---
label: "Maintain Inst. Class"
route: "/UI/uiInstClassSearchTable"
cacheName: "instClassPermCache"
pkField: "instClassId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "instClassId"
    headerName: "Inst. Class ID"
  - field: "$D_instTypeId"
    headerName: "Inst. Type ID"
  - field: "$D_underlyingId"
    headerName: "Underlying ID"
  - field: "description"
    headerName: "Description"
  - field: "isTraded"
    headerName: "Traded?"
  - field: "currencyCode"
    headerName: "Currency"
  - field: "settlementCurrencyCode"
    headerName: "Settlement Currency"
  - field: "$D_priceTickId"
    headerName: "Price Tick ID"
  - field: "$D_priceTickLimitId"
    headerName: "Price Tick Limit ID"
  - field: "isAutoUpdatePriceTickLimit"
    headerName: "Auto Price Tick Limit Update?"
  - field: "priceTickRefInstClassId"
    headerName: "Corresponding Inst. Class For Price Tick"
  - field: "$D_priceLimitId"
    headerName: "Price Limit ID"
  - field: "$D_vcmId"
    headerName: "VCM ID"
  - field: "futuresGroupId"
    headerName: "AHT Reference Price Futures Group ID"
  - field: "priceLimitRefInstClassId"
    headerName: "Corresponding Inst. Class For AHT Reference Price"
  - field: "priceQuotationFactor"
    headerName: "Price Quotation Factor"
  - field: "contractSize"
    headerName: "Contract Size"
  - field: "decimalsContractSize"
    headerName: "Decimals For Contract Size & PQF"
  - field: "decimalsStrikePrice"
    headerName: "Decimals For Strike Price"
  - field: "$D_specialTradingDaysId"
    headerName: "Special Trading Days ID"
  - field: "$D_timetableId"
    headerName: "Normal Day Timetable ID"
  - field: "isBlockTradeEligible"
    headerName: "Block Trade Eligible?"
  - field: "blockTradeMvtId"
    headerName: "Block Trade MVT ID"
  - field: "blockTradeStaticPriceLimitCheck"
    headerName: "Block Trade Static Price Limit?"
  - field: "lotSize"
    headerName: "Lot Size"
  - field: "$D_nameStdId"
    headerName: "Name Standard ID"
  - field: "isAutoGeneration"
    headerName: "Auto Generation?"
  - field: "autoInstGenRuleId"
    headerName: "Auto Instrument Generation Rule ID"
  - field: "lastCaEffectiveDate"
    headerName: "Last CA Effective Date"
  - field: "cycleBlockFrozenDate"
    headerName: "Cycle Block Frozen Date"
  - field: "furthestExpiryDate"
    headerName: "Furthest Expiry Date"
booleanFields: ["isTraded", "isBlockTradeEligible", "blockTradeStaticPriceLimitCheck", "isAutoGeneration", "isAutoUpdatePriceTickLimit"]
codeFields: ["recordStatus"]
sampleFields: ["instClassId", "description", "$D_instTypeId", "$D_underlyingId", "isTraded", "currencyCode", "recordStatus"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Inst. Class ID"
        type: combobox
      - label: "Inst. Type ID"
        type: combobox
      - label: "Underlying ID"
        type: combobox
      - label: "Description"
        type: textbox
  - heading: "Calendar"
    fields:
      - label: "Special Trading Days ID"
        type: combobox
      - label: "Normal Day Timetable ID"
        type: combobox
      - label: "Last CA Effective Date"
        type: textbox
      - label: "Cycle Block Frozen Date"
        type: textbox
      - label: "Furthest Expiry Date"
        type: textbox
  - heading: "Price"
    fields:
      - label: "Currency"
        type: textbox
      - label: "Settlement Currency"
        type: textbox
      - label: "Price Tick ID"
        type: combobox
      - label: "Price Tick Limit ID"
        type: combobox
      - label: "Auto Price Tick Limit Update?"
        type: combobox
      - label: "Corresponding Inst. Class For Price Tick"
        type: textbox
      - label: "Price Limit ID"
        type: combobox
      - label: "VCM ID"
        type: combobox
      - label: "AHT Reference Price Futures Group ID"
        type: combobox
      - label: "Corresponding Inst. Class For AHT Reference Price"
        type: textbox
      - label: "Price Quotation Factor"
        type: textbox
      - label: "Contract Size"
        type: textbox
      - label: "Decimals For Contract Size & PQF"
        type: textbox
      - label: "Decimals For Strike Price"
        type: textbox
  - heading: "Auto Generation"
    fields:
      - label: "Auto Generation?"
        type: combobox
      - label: "Auto Instrument Generation Rule ID"
        type: combobox
  - heading: "Trading Parameters"
    fields:
      - label: "Traded?"
        type: combobox
      - label: "Block Trade Eligible?"
        type: combobox
      - label: "Block Trade Static Price Limit?"
        type: combobox
      - label: "Block Trade MVT ID"
        type: combobox
      - label: "Lot Size"
        type: textbox
      - label: "Name Standard ID"
        type: combobox

---

