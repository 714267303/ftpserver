---
label: "Maintain SMP ID"
route: "/UI/uiSmpIdSearchTable"
cacheName: "smpIdPermCache"
pkField: "smpId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: ""
    headerName: ""
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "smpId"
    headerName: "SMP ID"
  - field: "description"
    headerName: "Description"
  - field: "creationRefNo"
    headerName: "Creation Reference Number"
  - field: "$D_participantId"
    headerName: "Owner ID"
  - field: "smpInstruction"
    headerName: "Cancellation Method"
  - field: "smpIdStatus"
    headerName: "Status"
  - field: "statusLastUpdateDate"
    headerName: "Status Last Update Date"
booleanFields: []
codeFields: ["recordStatus", "smpInstruction", "smpIdStatus"]
sampleFields: ["smpId", "description", "smpIdStatus", "smpInstruction"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "SMP ID"
        type: combobox
      - label: "Description"
        type: textbox
      - label: "Creation Reference Number"
        type: textbox
      - label: "Owner ID"
        type: combobox
  - heading: "General"
    fields:
      - label: "Cancellation Method"
        type: combobox
      - label: "Status"
        type: combobox
      - label: "Status Last Update Date"
        type: textbox
---
