---
label: "Control & Monitor VCM"
route: "/UI/uiControlMonitorVCMSearchTable"
cacheName: "controlMonitorVCMPermCache"
pkField: "instId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: ""
    headerName: ""
  - field: "instId"
    headerName: "Inst.ID"
  - field: "inVcmCoolingOffPeriod"
    headerName: "In VCM cooling-off period?"
  - field: "startTime"
    headerName: "Start Time"
  - field: "endTime"
    headerName: "End Time"
  - field: "manuallyUpdatedRefPrice"
    headerName: "Manually Updated Ref Price"
  - field: "referencePriceDisplay"
    headerName: "Effective Ref Price"
  - field: "upperPrice"
    headerName: "Upper Price"
  - field: "lowerPrice"
    headerName: "Lower Price"
  - field: "upperLimitEdit"
    headerName: "Upper Limit"
  - field: "lowerLimitEdit"
    headerName: "Lower Limit"
  - field: "limitDeviationUnitEdit"
    headerName: "Unit"
booleanFields: []
codeFields: []
sampleFields: ["instId", "inVcmCoolingOffPeriod", "startTime", "endTime", "manuallyUpdatedRefPrice"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Inst.ID"
        type: combobox
  - heading: "General"
    fields:
      - label: "In VCM cooling-off period?"
        type: combobox
      - label: "Start Time"
        type: textbox
      - label: "End Time"
        type: textbox
  - heading: "Price"
    fields:
      - label: "Manually Updated Ref Price"
        type: textbox
      - label: "Effective Ref Price"
        type: textbox
      - label: "Upper Price"
        type: textbox
      - label: "Lower Price"
        type: textbox
      - label: "Upper Limit"
        type: textbox
      - label: "Lower Limit"
        type: textbox
      - label: "Unit"
        type: textbox
---
