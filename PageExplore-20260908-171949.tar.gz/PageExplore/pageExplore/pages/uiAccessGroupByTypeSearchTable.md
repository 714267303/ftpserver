---
label: "Maintain Access Group By Type"
route: "/UI/uiAccessGroupByTypeSearchTable"
cacheName: "accessGroupByTypePermCache"
pkField: "accessGrpByTypeId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "accessGrpByTypeId"
    headerName: "Access Group By Type ID"
  - field: "name"
    headerName: "Name"
  - field: "description"
    headerName: "Description"
booleanFields: []
codeFields: ["recordStatus"]
sampleFields: ["accessGrpByTypeId", "name", "description", "recordStatus"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Access Group By Type ID"
        type: combobox
      - label: "Name"
        type: textbox
      - label: "Description"
        type: textbox

---

