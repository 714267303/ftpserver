---
label: "Maintain Price Limit Parameters"
route: "/UI/uiPriceLimitParametersSearchTable"
cacheName: "priceLimitParametersPermCache"
pkField: "priceLimitParamId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "priceLimitParamId"
    headerName: "Price Limit Param ID"
  - field: "name"
    headerName: "Name"
  - field: "description"
    headerName: "Description"
  - field: "$PLR_limitDeviationUnit"
    headerName: "Limit Deviation Unit"
  - field: "staticRefPriceSourceId"
    headerName: "Static Reference Price Source ID"
  - field: "isRemoveOrdersOutsideStaticLimit"
    headerName: "Remove Orders Outside Static Price Limit?"
  - field: "dynamicLastTradedPriceDeviationUnit"
    headerName: "Dynamic Last Traded Price Deviation Unit"
  - field: "dynamicLastTradedPriceDeviationPercentage"
    headerName: "Dynamic Last Traded Price Deviation Percentage"
  - field: "dynamicLastTradedPriceDeviationAbsValue"
    headerName: "Dynamic Last Traded Price Deviation Abs Value"
  - field: "resumptionCoolingOffInterval"
    headerName: "Resumption Cooling-Off Interval"
  - field: "noResumptionPeriod"
    headerName: "No Resumption Period"
  - field: "upperResumptionLevel"
    headerName: "Upper Resumption Level Percentage"
  - field: "lowerResumptionLevel"
    headerName: "Lower Resumption Level Percentage"
booleanFields: []
codeFields: []
sampleFields: ["requestStatus", "requestAction", "recordStatus", "priceLimitParamId", "name"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Price Limit Param ID"
        type: combobox
      - label: "Name"
        type: textbox
      - label: "Description"
        type: textbox
  - heading: "Static Price Limit"
    fields:
      - label: "Limit Deviation Unit"
        type: textbox
      - label: "Static Reference Price Source ID"
        type: combobox
      - label: "Remove Orders Outside Static Price Limit?"
        type: combobox
  - heading: "Dynamic Price Limit"
    fields:
      - label: "Dynamic Last Traded Price Deviation Unit"
        type: textbox
      - label: "Dynamic Last Traded Price Deviation Percentage"
        type: textbox
      - label: "Dynamic Last Traded Price Deviation Abs Value"
        type: textbox
  - heading: "Resumption"
    fields:
      - label: "Resumption Cooling-Off Interval"
        type: textbox
      - label: "No Resumption Period"
        type: textbox
      - label: "Upper Resumption Level Percentage"
        type: textbox
      - label: "Lower Resumption Level Percentage"
        type: textbox
---
