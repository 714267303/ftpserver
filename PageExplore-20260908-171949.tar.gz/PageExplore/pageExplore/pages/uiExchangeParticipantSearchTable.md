---
label: "Maintain Exchange Participant"
route: "/UI/uiExchangeParticipantSearchTable"
cacheName: "exchangeParticipantPermCache"
pkField: "participantId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "participantId"
    headerName: "Exchange Part. ID"
  - field: "$D_exchangeId"
    headerName: "Exchange ID"
  - field: "$D_companyId"
    headerName: "Company ID"
  - field: "description"
    headerName: "Description"
  - field: "isSuspended"
    headerName: "Suspended?"
  - field: "numMissingHeartbeat"
    headerName: "Number Of Missing Heartbeat"
  - field: "timeoutBeforeCod"
    headerName: "Timeout Before COD"
  - field: "blockTradeGroupId"
    headerName: "Allowed Block Trade Group ID"
  - field: "$D_smpIdListId"
    headerName: "SMP ID List ID"
  - field: "nominatedErrorTradeSessionUsage"
    headerName: "Nominated Error Trade Session Usage"
  - field: "nominatedErrorTradeCompId"
    headerName: "Nominated Error Trade Session ID"
booleanFields: ["isSuspended"]
codeFields: ["recordStatus"]
sampleFields: ["participantId", "description", "isSuspended", "recordStatus", "$D_exchangeId"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Exchange Part. ID"
        type: combobox
      - label: "Exchange ID"
        type: combobox
      - label: "Company ID"
        type: combobox
      - label: "Description"
        type: textbox
  - heading: "General"
    fields:
      - label: "Suspended?"
        type: combobox
      - label: "Number Of Missing Heartbeat"
        type: textbox
      - label: "Timeout Before COD"
        type: textbox
  - heading: "Trading Parameters"
    fields:
      - label: "Allowed Block Trade Group ID"
        type: combobox
      - label: "SMP ID List ID"
        type: combobox
  - heading: "Error Trade"
    fields:
      - label: "Nominated Error Trade Session Usage"
        type: combobox
      - label: "Nominated Error Trade Session ID"
        type: combobox
---
