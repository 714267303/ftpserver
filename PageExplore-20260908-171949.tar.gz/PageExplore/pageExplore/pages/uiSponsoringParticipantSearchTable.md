---
label: "Maintain Sponsoring Participant"
route: "/UI/uiSponsoringParticipantSearchTable"
cacheName: "sponsoringParticipantPermCache"
pkField: "participantId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "participantId"
    headerName: "Sponsoring Part. ID"
  - field: "$D_exchangeId"
    headerName: "Exchange ID"
  - field: "$D_companyId"
    headerName: "Company ID"
  - field: "description"
    headerName: "Description"
  - field: "isSuspended"
    headerName: "Suspended?"
booleanFields: []
codeFields: []
sampleFields: ["requestStatus", "requestAction", "recordStatus", "participantId", "$D_exchangeId"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Sponsoring Part. ID"
        type: combobox
      - label: "Exchange ID"
        type: combobox
      - label: "Company ID"
        type: combobox
      - label: "Description"
        type: textbox
  - heading: "General"
    fields:
      - label: "Suspended?"
        type: combobox
---
