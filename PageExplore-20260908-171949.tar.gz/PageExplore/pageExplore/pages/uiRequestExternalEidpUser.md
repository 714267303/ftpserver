---
label: "Request External IDP User"
route: "/UI/uiRequestExternalEidpUser"
cacheName: "requestExternalEidpUserPermCache"
pkField: ""
hasGrid: false
booleanFields: []
codeFields: []
sampleFields: []
profiled: true
---

