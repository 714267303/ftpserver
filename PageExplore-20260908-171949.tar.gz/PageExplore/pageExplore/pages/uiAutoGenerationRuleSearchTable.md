---
label: "Maintain Auto Generation Rule"
route: "/UI/uiAutoGenerationRuleSearchTable"
cacheName: "autoGenerationRulePermCache"
pkField: "autoInstGenRuleId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "autoInstGenRuleId"
    headerName: "Auto Instrument Generation Rule ID"
  - field: "description"
    headerName: "Description"
  - field: "unit"
    headerName: "Unit"
  - field: "type"
    headerName: "Type"
  - field: "untilDaysToLtd"
    headerName: "Until Days to Last Trading"
  - field: "preLaunchDays"
    headerName: "Pre-launch Days"
  - field: "oneOffPreLaunchFtd"
    headerName: "One-off Pre-Launch FTD"
  - field: "ltdGroup"
    headerName: "Last Trading Date Group"
  - field: "ltdGroupPriority"
    headerName: "Last Trading Date Group Priority"
  - field: "strikePriceGroup"
    headerName: "Strike Price Group"
  - field: "$D_cycleBlocksId"
    headerName: "Cycle Blocks ID"
  - field: "$D_ltdFormulaId"
    headerName: "Last Trading Date Formula ID"
  - field: "$D_ltdCalId"
    headerName: "Last Trading Date Calendar ID"
  - field: "$D_lifecycleTimeRuleId"
    headerName: "Lifecycle Time Rule ID"
booleanFields: []
codeFields: ["unit", "type", "recordStatus"]
sampleFields: ["autoInstGenRuleId", "description", "unit", "type", "recordStatus"]
notes: "unit codes: D(aily)/W(eekly)/M(onthly); type codes: O(ption)/U(uture); both server-filterable"
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Auto Instrument Generation Rule ID"
        type: combobox
      - label: "Description"
        type: textbox
  - heading: "General"
    fields:
      - label: "Unit"
        type: textbox
      - label: "Type"
        type: textbox
      - label: "Until Days to Last Trading"
        type: textbox
      - label: "Pre-launch Days"
        type: textbox
      - label: "One-off Pre-Launch FTD"
        type: textbox
      - label: "Last Trading Date Group"
        type: textbox
      - label: "Last Trading Date Group Priority"
        type: textbox
      - label: "Strike Price Group"
        type: textbox
      - label: "Cycle Blocks ID"
        type: combobox
      - label: "Last Trading Date Formula ID"
        type: combobox
      - label: "Last Trading Date Calendar ID"
        type: combobox
      - label: "Lifecycle Time Rule ID"
        type: combobox

---
