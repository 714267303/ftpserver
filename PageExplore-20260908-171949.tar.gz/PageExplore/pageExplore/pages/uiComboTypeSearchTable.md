---
label: "Maintain Combo Type"
route: "/UI/uiComboTypeSearchTable"
cacheName: "comboTypePermCache"
pkField: "comboTypeId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "comboTypeId"
    headerName: "Combo Type ID"
  - field: "$D_marketId"
    headerName: "Market ID"
  - field: "$D_comboGroupId"
    headerName: "Combo Group ID"
  - field: "description"
    headerName: "Description"
  - field: "isDifferentPriceQuotationFactorAllowed"
    headerName: "Allow Different Price Quotation Factor?"
  - field: "allowGtcAndGtdOrder"
    headerName: "Allow GTC And GTD Order?"
  - field: "$D_specialTradingDaysId"
    headerName: "Special Trading Days ID"
  - field: "$D_timetableId"
    headerName: "Normal Day Timetable ID"
  - field: "isBlockTradeEligible"
    headerName: "Block Trade Eligible?"
  - field: "tmcStrategyListId"
    headerName: "TMC Strategy List ID"
  - field: "isCrossMarketAllowed"
    headerName: "TMC Allow Cross Market?"
  - field: "tmcMaxRatio"
    headerName: "TMC Max Ratio"
  - field: "tmcMaxRatioDifference"
    headerName: "TMC Max Ratio Difference"
  - field: "tmcNumberRetentionDays"
    headerName: "TMC Number Retention Days"
  - field: "tmcExpirationPeriod"
    headerName: "TMC Expiration Period"
  - field: "$D_nameStdId"
    headerName: "Name Standard ID"
  - field: "identifyInQuoteRequest"
    headerName: "Identify In Quote Request?"
booleanFields: ["isDifferentPriceQuotationFactorAllowed", "allowGtcAndGtdOrder", "isBlockTradeEligible", "isCrossMarketAllowed", "identifyInQuoteRequest"]
codeFields: ["recordStatus"]
sampleFields: ["comboTypeId", "description", "$D_marketId", "$D_comboGroupId", "isBlockTradeEligible", "recordStatus"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Combo Type ID"
        type: combobox
      - label: "Market ID"
        type: combobox
      - label: "Combo Group ID"
        type: combobox
      - label: "Description"
        type: textbox
  - heading: "General"
    fields:
      - label: "Allow Different Price Quotation Factor?"
        type: combobox
      - label: "Allow GTC And GTD Order?"
        type: combobox
  - heading: "Calendar"
    fields:
      - label: "Special Trading Days ID"
        type: combobox
      - label: "Normal Day Timetable ID"
        type: combobox
  - heading: "TMC"
    fields:
      - label: "TMC Strategy List ID"
        type: combobox
      - label: "TMC Allow Cross Market?"
        type: combobox
      - label: "TMC Max Ratio"
        type: textbox
      - label: "TMC Max Ratio Difference"
        type: textbox
      - label: "TMC Number Retention Days"
        type: textbox
      - label: "TMC Expiration Period"
        type: textbox
  - heading: "Trading Parameters"
    fields:
      - label: "Block Trade Eligible?"
        type: combobox
      - label: "Name Standard ID"
        type: combobox
      - label: "Identify In Quote Request?"
        type: combobox

---

