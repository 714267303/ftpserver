---
label: "Maintain Last Trading Date Calendar"
route: "/UI/uiLastTradingDateCalendarSearchTable"
cacheName: "lastTradingDateCalendarPermCache"
pkField: "ltdCalId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "ltdCalId"
    headerName: "Last Trading Date Calendar ID"
  - field: "name"
    headerName: "Name"
  - field: "description"
    headerName: "Description"
  - field: "unit"
    headerName: "Unit"
booleanFields: []
codeFields: ["recordStatus", "unit"]
sampleFields: ["ltdCalId", "name", "description", "unit", "recordStatus"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Last Trading Date Calendar ID"
        type: combobox
      - label: "Name"
        type: textbox
      - label: "Description"
        type: textbox
  - heading: "General"
    fields:
      - label: "Unit"
        type: textbox
---
