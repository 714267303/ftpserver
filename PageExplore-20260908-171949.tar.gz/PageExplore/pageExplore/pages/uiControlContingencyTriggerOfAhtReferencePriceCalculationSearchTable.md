---
label: "Control Contingency Trigger of AHT Reference Price"
route: "/UI/uiControlContingencyTriggerOfAhtReferencePriceCalculationSearchTable"
cacheName: "controlContingencyTriggerOfAhtReferencePriceCalculationPermCache"
pkField: "productHierarchyLevel"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: ""
    headerName: ""
  - field: "productHierarchyLevel"
    headerName: "Hierarchy Level"
  - field: "entity"
    headerName: "Entity"
  - field: "description"
    headerName: "Description"
booleanFields: []
codeFields: []
sampleFields: ["productHierarchyLevel", "entity", "description"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Hierarchy Level"
        type: combobox
      - label: "Entity"
        type: textbox
      - label: "Description"
        type: textbox
---
