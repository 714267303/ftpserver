---
label: "Maintain Company"
route: "/UI/uiCompanySearchTable"
cacheName: "companyPermCache"
pkField: "companyId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "companyId"
    headerName: "Company ID"
  - field: "idpCompanyId"
    headerName: "IDP Company ID"
  - field: "companyUuid"
    headerName: "Company UUID"
  - field: "companyName"
    headerName: "Company Name"
  - field: "companyDescription"
    headerName: "Description"
booleanFields: []
codeFields: []
sampleFields: ["requestStatus", "requestAction", "recordStatus", "companyId", "idpCompanyId"]
notes: "recordStatus is server-filterable (verified); all rows active (recordStatus=E)"
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Company ID"
        type: combobox
      - label: "IDP Company ID"
        type: combobox
      - label: "Company UUID"
        type: textbox
      - label: "Company Name"
        type: textbox
      - label: "Description"
        type: textbox
---
