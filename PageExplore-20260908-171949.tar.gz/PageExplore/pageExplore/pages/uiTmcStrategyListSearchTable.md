---
label: "Maintain TMC Strategy List"
route: "/UI/uiTmcStrategyListSearchTable"
cacheName: "tmcStrategyListPermCache"
pkField: "tmcStrategyListId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "tmcStrategyListId"
    headerName: "Strategy List ID"
  - field: "name"
    headerName: "Name"
  - field: "description"
    headerName: "Description"
booleanFields: []
codeFields: []
sampleFields: ["requestStatus", "requestAction", "recordStatus", "tmcStrategyListId", "name"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Strategy List ID"
        type: combobox
      - label: "Name"
        type: textbox
      - label: "Description"
        type: textbox
---
