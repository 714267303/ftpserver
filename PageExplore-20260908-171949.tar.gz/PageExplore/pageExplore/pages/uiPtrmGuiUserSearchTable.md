---
label: "Maintain PTRM GUI User"
route: "/UI/uiPtrmGuiUserSearchTable"
cacheName: "ptrmGuiUserPermCache"
pkField: "userId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "userId"
    headerName: "User ID"
  - field: "idpUserId"
    headerName: "IDP User ID"
  - field: "$D_exchangeParticipantId"
    headerName: "Exchange Participant ID"
  - field: "$D_sponsoringParticipantId"
    headerName: "Sponsoring Participant ID"
  - field: "isSponsoringParticipant"
    headerName: "Is Sponsoring Participant?"
  - field: "isSuspended"
    headerName: "Suspended?"
  - field: "$CUP_compId"
    headerName: "Comp ID"
  - field: "$CI_isBlocked"
    headerName: "Blocked?"
  - field: "$CI_blockedReason"
    headerName: "Blocked Reason"
  - field: "$CI_gwServiceType"
    headerName: "Service Type"
  - field: "$CI_gwSessionUsage"
    headerName: "Session Usage"
  - field: "$CI_partitionId"
    headerName: "Partition ID"
  - field: "$CI_subPartitionId"
    headerName: "Sub Partition ID"
  - field: "$CI_interfaceProtocol"
    headerName: "Interface Protocol"
  - field: "$D_$CI_ipAddrListId"
    headerName: "Legal IP Address List ID"
  - field: "$CSE_lastSignonDateTime"
    headerName: "Last Successful Logon Time"
  - field: "$CSE_passwordExpiryDate"
    headerName: "Password Expiration Date"
  - field: "$D_$CI_passwordPolicyId"
    headerName: "Password Policy ID"
  - field: "$CSE_isLocked"
    headerName: "Locked?"
  - field: "$CI_numMissingHeartbeat"
    headerName: "Number Of Missing Heartbeat"
  - field: "$PS_ptrmThrottle"
    headerName: "PTRM Throttle"
  - field: "$D_participantUserRoleId"
    headerName: "Part. User Role ID"
  - field: "$D_browserIpAddrListId"
    headerName: "Legal Browser IP Address List ID"
booleanFields: []
codeFields: []
sampleFields: ["requestStatus", "requestAction", "recordStatus", "userId", "idpUserId"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "User ID"
        type: combobox
      - label: "IDP User ID"
        type: combobox
      - label: "Exchange Participant ID"
        type: combobox
      - label: "Sponsoring Participant ID"
        type: combobox
      - label: "Part. User Role ID"
        type: combobox
  - heading: "General"
    fields:
      - label: "Is Sponsoring Participant?"
        type: combobox
      - label: "Suspended?"
        type: combobox
  - heading: "Session Configuration"
    fields:
      - label: "Comp ID"
        type: combobox
      - label: "Service Type"
        type: combobox
      - label: "Session Usage"
        type: combobox
      - label: "Partition ID"
        type: combobox
      - label: "Sub Partition ID"
        type: combobox
      - label: "Interface Protocol"
        type: combobox
      - label: "Legal IP Address List ID"
        type: combobox
      - label: "Legal Browser IP Address List ID"
        type: combobox
      - label: "Password Policy ID"
        type: combobox
      - label: "Number Of Missing Heartbeat"
        type: textbox
  - heading: "PTRM"
    fields:
      - label: "PTRM Throttle"
        type: textbox
  - heading: "Security"
    fields:
      - label: "Blocked?"
        type: combobox
      - label: "Blocked Reason"
        type: textbox
      - label: "Locked?"
        type: combobox
      - label: "Last Successful Logon Time"
        type: textbox
      - label: "Password Expiration Date"
        type: textbox
---
