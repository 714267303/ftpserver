---
label: "Instrument Generation"
route: "/UI/uiInstrumentGeneration"
cacheName: "instrumentGenerationPermCache"
pkField: "instId"
hasGrid: false
booleanFields: ["isIndex", "isTraded", "isDummy", "isAutoGeneration", "isPhysicalDelivery", "isMaturity"]
codeFields: ["recordStatus"]
sampleFields: ["instId", "instCode", "description", "recordStatus", "shortName"]
profiled: false
---

