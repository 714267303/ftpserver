---
label: "Maintain Lifecycle Time Rule"
route: "/UI/uiLifecycleTimeRuleSearchTable"
cacheName: "lifecycleTimeRulePermCache"
pkField: "lifecycleTimeRuleId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "lifecycleTimeRuleId"
    headerName: "Lifecycle Time Rule ID"
  - field: "name"
    headerName: "Name"
  - field: "description"
    headerName: "Description"
  - field: "ftt"
    headerName: "First Trading Time"
  - field: "normalDayLtt"
    headerName: "Normal Day Last Trading Time"
  - field: "halfDayLtt"
    headerName: "Half Day Last Trading Time"
  - field: "isNormalDayDstAdjustment"
    headerName: "Normal Day DST Adjustment?"
  - field: "isHalfDayDstAdjustment"
    headerName: "Half Day DST Adjustment?"
  - field: "$D_ltdDstAdjustmentId"
    headerName: "DST Adjustment ID"
booleanFields: ["isNormalDayDstAdjustment", "isHalfDayDstAdjustment"]
codeFields: ["recordStatus"]
sampleFields: ["lifecycleTimeRuleId", "name", "description", "ftt", "normalDayLtt", "recordStatus"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Lifecycle Time Rule ID"
        type: combobox
      - label: "Name"
        type: textbox
      - label: "Description"
        type: textbox
  - heading: "Trading Times"
    fields:
      - label: "First Trading Time"
        type: textbox
      - label: "Normal Day Last Trading Time"
        type: textbox
      - label: "Half Day Last Trading Time"
        type: textbox
      - label: "Normal Day DST Adjustment?"
        type: combobox
      - label: "Half Day DST Adjustment?"
        type: combobox
      - label: "DST Adjustment ID"
        type: combobox
---
