---
label: "Maintain Participant User Role"
route: "/UI/uiParticipantUserRoleSearchTable"
cacheName: "participantUserRolePermCache"
pkField: "participantUserRoleId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "participantUserRoleId"
    headerName: "Part. User Role ID"
  - field: "name"
    headerName: "Name"
  - field: "description"
    headerName: "Description"
  - field: "typeOfParticipantUser"
    headerName: "Part. User Type"
  - field: "$D_uiUserRoleId"
    headerName: "UI User Role ID"
  - field: "isOrderEntryAllowed"
    headerName: "Order Entry Allowed?"
  - field: "isOrderAmendAllowed"
    headerName: "Order Amend Allowed?"
  - field: "isOrderCancelAllowed"
    headerName: "Order Cancel Allowed?"
  - field: "isOrderMassCancelAllowed"
    headerName: "Order Mass Cancel Allowed?"
  - field: "isOboOrderCancelAllowed"
    headerName: "OBO Order Cancel Allowed?"
  - field: "isOboMassCancelAllowed"
    headerName: "OBO Mass Cancel Allowed?"
  - field: "isQuoteRequestAllowed"
    headerName: "Quote Request Allowed?"
  - field: "isSingleQuoteAllowed"
    headerName: "Single Quote Allowed?"
  - field: "isMassQuoteAllowed"
    headerName: "Mass Quote Allowed?"
  - field: "isBlockTradeAllowed"
    headerName: "Block Trade Allowed?"
  - field: "isErrorTradeClaimAllowed"
    headerName: "Error Trade Claim Allowed?"
  - field: "isTmcCreationAllowed"
    headerName: "TMC Creation Allowed?"
  - field: "isMmpParamUpdateAllowed"
    headerName: "MMP Parameter Update Allowed?"
  - field: "isStopRgAllowed"
    headerName: "Stop Risk Group Allowed?"
  - field: "isUnstopRgAllowed"
    headerName: "Unstop Risk Group Allowed?"
  - field: "isPtrmMassCancelAllowed"
    headerName: "PTRM Mass Cancel Allowed?"
  - field: "isTradingKillSwitchAllowed"
    headerName: "Kill Switch Allowed?"
  - field: "isPtrmKillSwitchAllowed"
    headerName: "PTRM Kill Switch Allowed?"
  - field: "isUnblockBreachedRiskCheckAllowed"
    headerName: "Unblock Breached Risk Check Allowed?"
  - field: "isPtrmParamUpdateAllowed"
    headerName: "PTRM Parameter Update Allowed?"
  - field: "blockTradeGroupId"
    headerName: "Allowed Block Trade Group ID"
booleanFields: []
codeFields: []
sampleFields: ["requestStatus", "requestAction", "recordStatus", "participantUserRoleId", "name"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Part. User Role ID"
        type: combobox
      - label: "Name"
        type: textbox
      - label: "Description"
        type: textbox
      - label: "Part. User Type"
        type: combobox
      - label: "UI User Role ID"
        type: combobox
  - heading: "Order Permissions"
    fields:
      - label: "Order Entry Allowed?"
        type: combobox
      - label: "Order Amend Allowed?"
        type: combobox
      - label: "Order Cancel Allowed?"
        type: combobox
      - label: "Order Mass Cancel Allowed?"
        type: combobox
      - label: "OBO Order Cancel Allowed?"
        type: combobox
      - label: "OBO Mass Cancel Allowed?"
        type: combobox
      - label: "Kill Switch Allowed?"
        type: combobox
  - heading: "Quote Permissions"
    fields:
      - label: "Quote Request Allowed?"
        type: combobox
      - label: "Single Quote Allowed?"
        type: combobox
      - label: "Mass Quote Allowed?"
        type: combobox
  - heading: "Trading Permissions"
    fields:
      - label: "Block Trade Allowed?"
        type: combobox
      - label: "Error Trade Claim Allowed?"
        type: combobox
      - label: "TMC Creation Allowed?"
        type: combobox
      - label: "Allowed Block Trade Group ID"
        type: combobox
  - heading: "Risk Management"
    fields:
      - label: "MMP Parameter Update Allowed?"
        type: combobox
      - label: "Stop Risk Group Allowed?"
        type: combobox
      - label: "Unstop Risk Group Allowed?"
        type: combobox
      - label: "Unblock Breached Risk Check Allowed?"
        type: combobox
  - heading: "PTRM"
    fields:
      - label: "PTRM Mass Cancel Allowed?"
        type: combobox
      - label: "PTRM Kill Switch Allowed?"
        type: combobox
      - label: "PTRM Parameter Update Allowed?"
        type: combobox
---
