---
label: "Maintain Trading GUI User"
route: "/UI/uiTradingGuiUserSearchTable"
cacheName: "tradingGuiUserPermCache"
pkField: "userId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "userId"
    headerName: "User ID"
  - field: "idpUserId"
    headerName: "IDP User ID"
  - field: "$D_participantId"
    headerName: "Exchange Part. ID"
  - field: "isSuspended"
    headerName: "Suspended?"
  - field: "$COT_compId"
    headerName: "Comp ID"
  - field: "$CI_isBlocked"
    headerName: "Blocked?"
  - field: "$CI_blockedReason"
    headerName: "Blocked Reason"
  - field: "$CI_gwServiceType"
    headerName: "Service Type"
  - field: "$CI_gwSessionUsage"
    headerName: "Session Usage"
  - field: "$CI_partitionId"
    headerName: "Partition ID"
  - field: "$CI_subPartitionId"
    headerName: "Sub Partition ID"
  - field: "$CI_interfaceProtocol"
    headerName: "Interface Protocol"
  - field: "$D_$CI_ipAddrListId"
    headerName: "Legal IP Address List ID"
  - field: "$CSE_lastSignonDateTime"
    headerName: "Last Successful Logon Time"
  - field: "$CSE_passwordExpiryDate"
    headerName: "Password Expiration Date"
  - field: "$CSE_isLocked"
    headerName: "Locked?"
  - field: "$D_$CI_passwordPolicyId"
    headerName: "Password Policy ID"
  - field: "$CI_numMissingHeartbeat"
    headerName: "Number Of Missing Heartbeat"
  - field: "$CIO_timeoutBeforeCod"
    headerName: "Timeout Before COD"
  - field: "$CIO_orderThrottle"
    headerName: "Order Throttle"
  - field: "$CIO_isReceiveNonCriticalMktMsg"
    headerName: "Receive Non-Critical Market Messages?"
  - field: "$D_$TR_participantUserRoleId"
    headerName: "Part. User Role ID"
  - field: "$D_$TR_tradingRightId"
    headerName: "Trading Right ID"
  - field: "$D_browserIpAddrListId"
    headerName: "Legal Browser IP Address List ID"
booleanFields: []
codeFields: []
sampleFields: ["requestStatus", "requestAction", "recordStatus", "userId", "idpUserId"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "User ID"
        type: combobox
      - label: "IDP User ID"
        type: combobox
      - label: "Exchange Part. ID"
        type: combobox
      - label: "Comp ID"
        type: combobox
      - label: "Part. User Role ID"
        type: combobox
      - label: "Trading Right ID"
        type: combobox
  - heading: "General"
    fields:
      - label: "Suspended?"
        type: combobox
  - heading: "Session Configuration"
    fields:
      - label: "Service Type"
        type: combobox
      - label: "Session Usage"
        type: combobox
      - label: "Partition ID"
        type: combobox
      - label: "Sub Partition ID"
        type: combobox
      - label: "Interface Protocol"
        type: combobox
      - label: "Legal IP Address List ID"
        type: combobox
      - label: "Legal Browser IP Address List ID"
        type: combobox
      - label: "Password Policy ID"
        type: combobox
      - label: "Timeout Before COD"
        type: textbox
      - label: "Order Throttle"
        type: textbox
      - label: "Receive Non-Critical Market Messages?"
        type: combobox
      - label: "Number Of Missing Heartbeat"
        type: textbox
  - heading: "Security"
    fields:
      - label: "Blocked?"
        type: combobox
      - label: "Blocked Reason"
        type: textbox
      - label: "Locked?"
        type: combobox
      - label: "Last Successful Logon Time"
        type: textbox
      - label: "Password Expiration Date"
        type: textbox
---
