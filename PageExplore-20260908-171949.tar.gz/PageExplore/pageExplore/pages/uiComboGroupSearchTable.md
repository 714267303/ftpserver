---
label: "Maintain Combo Group"
route: "/UI/uiComboGroupSearchTable"
cacheName: "comboGroupPermCache"
pkField: "comboGroupId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "comboGroupId"
    headerName: "Combo Group ID"
  - field: "comboGroupCode"
    headerName: "Combo Group Code"
  - field: "shortName"
    headerName: "Short Name"
  - field: "description"
    headerName: "Description"
  - field: "isTailorMadeOnly"
    headerName: "Tailor Made Only?"
  - field: "timeSpreadLevel"
    headerName: "Time Spread Level"
booleanFields:
  - field: "isTailorMadeOnly"
    headerName: "Tailor Made Only?"
codeFields: ["recordStatus"]
sampleFields: ["comboGroupId", "comboGroupCode", "shortName", "description", "recordStatus"]
notes: "recordStatus is server-filterable (verified); moderate dataset (27 rows)"
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Combo Group ID"
        type: combobox
      - label: "Combo Group Code"
        type: combobox
      - label: "Short Name"
        type: textbox
      - label: "Description"
        type: textbox
  - heading: "General"
    fields:
      - label: "Tailor Made Only?"
        type: combobox
      - label: "Time Spread Level"
        type: textbox

---
