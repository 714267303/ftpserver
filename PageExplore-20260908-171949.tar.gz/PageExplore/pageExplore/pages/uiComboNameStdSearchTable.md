---
label: "Maintain Combo Name Standard"
route: "/UI/uiComboNameStdSearchTable"
cacheName: "comboNameStdPermCache"
pkField: "nameStdId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "nameStdId"
    headerName: "Combo Name Standard ID"
  - field: "name"
    headerName: "Name"
  - field: "description"
    headerName: "Description"
  - field: "type"
    headerName: "Type"
booleanFields: []
codeFields: ["recordStatus", "type"]
sampleFields: ["nameStdId", "name", "description", "type", "recordStatus"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Combo Name Standard ID"
        type: combobox
      - label: "Name"
        type: textbox
      - label: "Description"
        type: textbox
  - heading: "General"
    fields:
      - label: "Type"
        type: textbox

---

