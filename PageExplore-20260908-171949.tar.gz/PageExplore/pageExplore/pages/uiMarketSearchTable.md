---
label: "Maintain Market"
route: "/UI/uiMarketSearchTable"
cacheName: "marketPermCache"
pkField: "marketId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "marketId"
    headerName: "Market ID"
  - field: "marketCode"
    headerName: "Market Code"
  - field: "description"
    headerName: "Description"
  - field: "$D_exchangeId"
    headerName: "Exchange ID"
  - field: "mic"
    headerName: "MIC"
  - field: "marketType"
    headerName: "Market Type"
  - field: "isIndex"
    headerName: "Index?"
  - field: "isDummy"
    headerName: "Dummy?"
  - field: "isTraded"
    headerName: "Traded?"
  - field: "blockTradeMvtId"
    headerName: "Block Trade MVT ID"
  - field: "tradingDays"
    headerName: "Normal Trading Days"
  - field: "$D_nonTradingDaysId"
    headerName: "Non-Trading Days ID"
  - field: "$D_specialTradingDaysId"
    headerName: "Special Trading Days ID"
  - field: "$D_timetableId"
    headerName: "Normal Day Timetable ID"
  - field: "marketPriorityNum"
    headerName: "Priority Number"
booleanFields:
  - field: "isIndex"
    headerName: "Index?"
  - field: "isDummy"
    headerName: "Dummy?"
  - field: "isTraded"
    headerName: "Traded?"
codeFields: ["recordStatus", "marketType"]
sampleFields: ["marketId", "marketCode", "description", "mic", "isTraded", "recordStatus"]
notes: "Exchange ID is a display-only field ($D prefix); filtering by exchangeId is not supported"
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Market ID"
        type: combobox
      - label: "Market Code"
        type: combobox
      - label: "Description"
        type: textbox
      - label: "Exchange ID"
        type: combobox
      - label: "MIC"
        type: textbox
  - heading: "General"
    fields:
      - label: "Market Type"
        type: combobox
      - label: "Index?"
        type: combobox
      - label: "Dummy?"
        type: combobox
      - label: "Priority Number"
        type: textbox
  - heading: "Calendar"
    fields:
      - label: "Non-Trading Days ID"
        type: combobox
      - label: "Special Trading Days ID"
        type: combobox
      - label: "Normal Day Timetable ID"
        type: combobox
  - heading: "Trading Parameters"
    fields:
      - label: "Traded?"
        type: combobox
      - label: "Block Trade MVT ID"
        type: combobox

---
