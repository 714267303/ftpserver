---
label: "Countersign Request"
route: "/UI/uiAuthorizationRequestSearchTable"
cacheName: "authorizationRequestPermCache"
pkField: "txRequestId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "txStatus"
    headerName: "Req Status"
  - field: "txAction"
    headerName: "Req Action"
  - field: "executionStatus"
    headerName: "Exec Status"
  - field: "txRequestId"
    headerName: "Req ID"
  - field: "txIdentifier"
    headerName: "Identifier"
  - field: "creDateTime"
    headerName: "Received At"
  - field: "authDateTime"
    headerName: "Approved At"
  - field: "$F_functionName"
    headerName: "Function Name"
  - field: "creUserId"
    headerName: "Requester"
  - field: "effectiveDate"
    headerName: "Effective Date"
  - field: "scheduledTime"
    headerName: "Scheduled Time"
  - field: "authUserId"
    headerName: "Approver"
  - field: "modUserId"
    headerName: "Rejecter"
  - field: "modDateTime"
    headerName: "Rejected At"
  - field: "lastUpdateTime"
    headerName: "Update At"
  - field: "errorDesc"
    headerName: "Failed Reason"
booleanFields: []
codeFields: ["executionStatus", "txStatus"]
sampleFields: ["txRequestId", "txIdentifier", "creUserId", "authUserId", "executionStatus"]
notes:  "Authorization/Countersign page; no data currently (rowCount=0)"
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Req ID"
        type: combobox
      - label: "Identifier"
        type: textbox
      - label: "Function Name"
        type: textbox
  - heading: "General"
    fields:
      - label: "Req Status"
        type: combobox
      - label: "Req Action"
        type: combobox
      - label: "Exec Status"
        type: combobox
      - label: "Failed Reason"
        type: textbox
  - heading: "Participant/User"
    fields:
      - label: "Requester"
        type: combobox
      - label: "Approver"
        type: combobox
      - label: "Rejecter"
        type: combobox
  - heading: "Dates"
    fields:
      - label: "Received At"
        type: textbox
      - label: "Approved At"
        type: textbox
      - label: "Rejected At"
        type: textbox
      - label: "Effective Date"
        type: textbox
      - label: "Scheduled Time"
        type: textbox
      - label: "Update At"
        type: textbox
---
