---
label: "Maintain Auto Combo Generation Rule Group"
route: "/UI/uiAutoComboGenerationRuleGroupSearchTable"
cacheName: "autoComboGenerationRuleGroupPermCache"
pkField: "autoComboGenRuleGroupId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "autoComboGenRuleGroupId"
    headerName: "Auto Combo Generation Rule Group ID"
  - field: "name"
    headerName: "Name"
  - field: "description"
    headerName: "Description"
  - field: "unit"
    headerName: "Unit"
  - field: "untilDaysToLtd"
    headerName: "Until Days to Last Trading"
  - field: "preLaunchDays"
    headerName: "Pre-Launch Days"
  - field: "isOneOffPreLaunch"
    headerName: "One-off Pre-launch?"
  - field: "isEnabled"
    headerName: "Enabled?"
booleanFields: ["isOneOffPreLaunch", "isEnabled"]
codeFields: ["recordStatus", "unit"]
sampleFields: ["autoComboGenRuleGroupId", "name", "description", "unit", "isEnabled", "recordStatus"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Auto Combo Generation Rule Group ID"
        type: combobox
      - label: "Name"
        type: textbox
      - label: "Description"
        type: textbox
  - heading: "General"
    fields:
      - label: "Unit"
        type: textbox
      - label: "Until Days to Last Trading"
        type: textbox
      - label: "Pre-Launch Days"
        type: textbox
      - label: "One-off Pre-launch?"
        type: combobox
      - label: "Enabled?"
        type: combobox
---
