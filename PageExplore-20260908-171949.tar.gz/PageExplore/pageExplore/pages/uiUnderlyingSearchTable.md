---
label: "Maintain Underlying"
route: "/UI/uiUnderlyingSearchTable"
cacheName: "underlyingPermCache"
pkField: "underlyingId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "underlyingId"
    headerName: "Underlying ID"
  - field: "underlyingCode"
    headerName: "Underlying Code"
  - field: "description"
    headerName: "Description"
  - field: "partitionId"
    headerName: "ME Partition ID"
  - field: "status"
    headerName: "Status"
  - field: "underlyingType"
    headerName: "Underlying Type"
  - field: "isIndex"
    headerName: "Index?"
  - field: "underlyingIssuer"
    headerName: "Underlying Issuer"
  - field: "isMmpEnabled"
    headerName: "MMP Enabled?"
  - field: "minMmpQuantity"
    headerName: "Minimum MMP Quantity"
  - field: "decimalsInPrice"
    headerName: "Price Decimals"
  - field: "currencyCode"
    headerName: "Currency"
  - field: "isCaCreated"
    headerName: "CA Created?"
  - field: "isCaSpinOffInProgress"
    headerName: "CA Spin-off In Progress?"
  - field: "caReuseCoolOffDate"
    headerName: "CA Reuse Cool-off Date"
  - field: "caPriority"
    headerName: "CA Priority"
  - field: "dataSource"
    headerName: "Data Source"
  - field: "dataSourceSymbolCode"
    headerName: "Data Source Symbol Code"
booleanFields:
  - field: "isIndex"
    headerName: "Index?"
  - field: "isMmpEnabled"
    headerName: "MMP Enabled?"
  - field: "isCaCreated"
    headerName: "CA Created?"
  - field: "isCaSpinOffInProgress"
    headerName: "CA Spin-off In Progress?"
codeFields: ["recordStatus", "underlyingType", "dataSource"]
sampleFields: ["underlyingId", "underlyingCode", "description", "currencyCode", "isIndex", "recordStatus"]
notes:  "recordStatus is server-filterable (verified)"
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Underlying ID"
        type: combobox
      - label: "Underlying Code"
        type: combobox
      - label: "Description"
        type: textbox
  - heading: "General"
    fields:
      - label: "ME Partition ID"
        type: combobox
      - label: "Status"
        type: textbox
      - label: "Underlying Type"
        type: combobox
      - label: "Index?"
        type: combobox
      - label: "Underlying Issuer"
        type: textbox
      - label: "MMP Enabled?"
        type: combobox
      - label: "Minimum MMP Quantity"
        type: textbox
  - heading: "Price"
    fields:
      - label: "Price Decimals"
        type: textbox
      - label: "Currency"
        type: textbox
  - heading: "CA"
    fields:
      - label: "CA Created?"
        type: combobox
      - label: "CA Spin-off In Progress?"
        type: combobox
      - label: "CA Reuse Cool-off Date"
        type: textbox
      - label: "CA Priority"
        type: textbox
  - heading: "Data Source"
    fields:
      - label: "Data Source Symbol Code"
        type: combobox

---
