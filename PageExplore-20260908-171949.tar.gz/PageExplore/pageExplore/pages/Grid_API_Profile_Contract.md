# Page Profile qaGridApi Contract

Every page profile with `hasGrid: true` inherits the shared contract in
[`../qaGrid/Grid_API_Core_Index.md`](../qaGrid/Grid_API_Core_Index.md).
The profile itself should contain only page-specific facts.

Recommended metadata:

```yaml
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred|observed|verified"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
```

`keyPattern` may be a canonical pattern such as
`smpIdListDetailDialog_<uuid>_subDetailTable1`.  It must not contain a UUID
captured from a single run.  `observationStatus` is evidence metadata and does
not mean that every row or business action is verified.

## Update Policy

- Add a page-specific `gridApi` block after `hasGrid` when a page has a
  confirmed key pattern or an important Grid observation.
- Keep columns in the existing `columns` list; do not duplicate them in the
  shared index.
- Add `subTables` only for detail-page Grids, with their own key pattern and
  status.
- Use `inferred` for profiles that have only the generic SearchTable pattern.
- Promote to `verified` only after a clean Playwright replay and a visible
  assertion are both available.
- Keep Admin and Trading observation indexes separate even though the API is
  shared.

## Current Profile Coverage

| Profile group | Shared contract | Page-specific observation |
|---|---|---|
| 91 Admin Grid profiles | inherited | mostly `inferred` until a page is replayed |
| `uiSmpIdListSearchTable` | inherited | Admin SMP ID detail sub-table is `observed` |
| Trading UI profiles | not represented in this Admin `pages/` directory | see `../qaGrid/Trading_GUI/Grid_API_Observation_Index.md` |

The absence of an observed key in a page profile is intentional: the key is
runtime-generated and should be captured on the target page.
