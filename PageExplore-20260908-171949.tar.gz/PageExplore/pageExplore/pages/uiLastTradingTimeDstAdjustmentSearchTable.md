---
label: "Maintain Last Trading Time DST Adjustment"
route: "/UI/uiLastTradingTimeDstAdjustmentSearchTable"
cacheName: "lastTradingTimeDstAdjustmentPermCache"
pkField: "ltdDstAdjustmentId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "ltdDstAdjustmentId"
    headerName: "DST Adjustment ID"
  - field: "name"
    headerName: "Name"
  - field: "description"
    headerName: "Description"
  - field: "adjMins"
    headerName: "Adjustment In Minutes"
booleanFields: []
codeFields: ["recordStatus"]
sampleFields: ["ltdDstAdjustmentId", "name", "description", "adjMins", "recordStatus"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "DST Adjustment ID"
        type: combobox
      - label: "Name"
        type: textbox
      - label: "Description"
        type: textbox
  - heading: "General"
    fields:
      - label: "Adjustment In Minutes"
        type: textbox
---
