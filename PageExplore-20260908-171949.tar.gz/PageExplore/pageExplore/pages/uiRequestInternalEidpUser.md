---
label: "Request Internal IDP User"
route: "/UI/uiRequestInternalEidpUser"
cacheName: "requestInternalEidpUserPermCache"
pkField: ""
hasGrid: false
booleanFields: []
codeFields: []
sampleFields: []
profiled: true
---

