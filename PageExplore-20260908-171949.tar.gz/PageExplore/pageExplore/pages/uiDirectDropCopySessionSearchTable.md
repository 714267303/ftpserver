---
label: "Maintain Direct Drop Copy Session"
route: "/UI/uiDirectDropCopySessionSearchTable"
cacheName: "directDropCopySessionPermCache"
pkField: "compId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "compId"
    headerName: "Comp ID"
  - field: "$D_$CI_exchangeParticipantId"
    headerName: "Exchange Part. ID"
  - field: "$CI_isBlocked"
    headerName: "Blocked?"
  - field: "$CI_blockedReason"
    headerName: "Blocked Reason"
  - field: "$CI_gwServiceType"
    headerName: "Service Type"
  - field: "$CI_gwSessionUsage"
    headerName: "Session Usage"
  - field: "$CI_partitionId"
    headerName: "Partition ID"
  - field: "$CI_subPartitionId"
    headerName: "Sub Partition ID"
  - field: "$CI_interfaceProtocol"
    headerName: "Interface Protocol"
  - field: "$D_$CI_ipAddrListId"
    headerName: "Legal IP Address List ID"
  - field: "$CIE_passwordExpiryDate"
    headerName: "Password Expiration Date"
  - field: "$D_$CI_passwordPolicyId"
    headerName: "Password Policy ID"
  - field: "$CI_lastPasswordSetTimestamp"
    headerName: "Last Password Set Timestamp"
  - field: "$CIE_lastSignonTime"
    headerName: "Last Successful Logon Time"
  - field: "$CIE_isLocked"
    headerName: "Locked?"
  - field: "$CI_numMissingHeartbeat"
    headerName: "Number Of Missing Heartbeat"
  - field: "isIncludeOrders"
    headerName: "Include Orders?"
  - field: "isIncludeTrades"
    headerName: "Include Trades?"
  - field: "$D_accessGrpByTypeId"
    headerName: "Access Group By Type ID"
booleanFields: []
codeFields: []
sampleFields: ["requestStatus", "requestAction", "recordStatus", "compId", "$D_$CI_exchangeParticipantId"]
notes: "No data currently; grid structure may still be empty."
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Comp ID"
        type: combobox
      - label: "Exchange Part. ID"
        type: combobox
  - heading: "Session Configuration"
    fields:
      - label: "Service Type"
        type: combobox
      - label: "Session Usage"
        type: combobox
      - label: "Partition ID"
        type: combobox
      - label: "Sub Partition ID"
        type: combobox
      - label: "Interface Protocol"
        type: combobox
      - label: "Legal IP Address List ID"
        type: combobox
      - label: "Password Policy ID"
        type: combobox
      - label: "Access Group By Type ID"
        type: combobox
  - heading: "Drop Copy"
    fields:
      - label: "Include Orders?"
        type: combobox
      - label: "Include Trades?"
        type: combobox
  - heading: "Security"
    fields:
      - label: "Blocked?"
        type: combobox
      - label: "Blocked Reason"
        type: textbox
      - label: "Locked?"
        type: combobox
      - label: "Password Expiration Date"
        type: textbox
      - label: "Last Password Set Timestamp"
        type: textbox
      - label: "Last Successful Logon Time"
        type: textbox
      - label: "Number Of Missing Heartbeat"
        type: textbox
---
