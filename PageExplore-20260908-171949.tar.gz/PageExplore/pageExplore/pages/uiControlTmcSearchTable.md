---
label: "Control TMC"
route: "/UI/uiControlTmcSearchTable"
cacheName: "controlTmcPermCache"
pkField: "comboId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: ""
    headerName: ""
  - field: "comboId"
    headerName: "TMC ID"
  - field: "comboClassId"
    headerName: "Combo Class ID"
  - field: "status"
    headerName: "Status"
  - field: "comboEffectiveDate"
    headerName: "Effective Date"
  - field: "lastTradingDate"
    headerName: "Last Trading Date"
  - field: "effectiveLastTradingDate"
    headerName: "Effective Last Trading Date"
  - field: "lastTradingTime"
    headerName: "Last Trading Time"
  - field: "firstTradingDate"
    headerName: "First Trading Date"
  - field: "firstTradingTime"
    headerName: "First Trading Time"
  - field: "operation1"
    headerName: "Operation"
  - field: "ratio1"
    headerName: "Ratio"
  - field: "legInstId1"
    headerName: "Inst. ID"
  - field: "operation2"
    headerName: "Operation"
  - field: "ratio2"
    headerName: "Ratio"
  - field: "legInstId2"
    headerName: "Inst. ID"
  - field: "operation3"
    headerName: "Operation"
  - field: "ratio3"
    headerName: "Ratio"
  - field: "legInstId3"
    headerName: "Inst. ID"
  - field: "operation4"
    headerName: "Operation"
  - field: "ratio4"
    headerName: "Ratio"
  - field: "legInstId4"
    headerName: "Inst. ID"
booleanFields: []
codeFields: []
sampleFields: ["comboId", "comboClassId", "status", "comboEffectiveDate", "lastTradingDate"]
notes: "No data currently; grid structure may still be empty."
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "TMC ID"
        type: combobox
      - label: "Combo Class ID"
        type: combobox
  - heading: "General"
    fields:
      - label: "Status"
        type: combobox
  - heading: "Dates"
    fields:
      - label: "Effective Date"
        type: textbox
      - label: "First Trading Date"
        type: textbox
      - label: "First Trading Time"
        type: textbox
      - label: "Last Trading Date"
        type: textbox
      - label: "Effective Last Trading Date"
        type: textbox
      - label: "Last Trading Time"
        type: textbox
  - heading: "Leg 1"
    fields:
      - label: "Operation"
        type: combobox
      - label: "Ratio"
        type: textbox
      - label: "Inst. ID"
        type: combobox
  - heading: "Leg 2"
    fields:
      - label: "Operation"
        type: combobox
      - label: "Ratio"
        type: textbox
      - label: "Inst. ID"
        type: combobox
  - heading: "Leg 3"
    fields:
      - label: "Operation"
        type: combobox
      - label: "Ratio"
        type: textbox
      - label: "Inst. ID"
        type: combobox
  - heading: "Leg 4"
    fields:
      - label: "Operation"
        type: combobox
      - label: "Ratio"
        type: textbox
      - label: "Inst. ID"
        type: combobox
---
