---
label: "Maintain Instrument"
route: "/UI/uiInstrumentSearchTable"
cacheName: "instrumentPermCache"
pkField: "instId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "instId"
    headerName: "Inst. ID"
  - field: "$D_instClassId"
    headerName: "Inst. Class ID"
  - field: "strikePrice"
    headerName: "Strike Price"
  - field: "isTraded"
    headerName: "Traded?"
  - field: "instEffectiveDate"
    headerName: "Effective Date"
  - field: "status"
    headerName: "Status"
  - field: "firstTradingDate"
    headerName: "First Trading Date"
  - field: "firstTradingTime"
    headerName: "First Trading Time"
  - field: "lastTradingDate"
    headerName: "Last Trading Date"
  - field: "effectiveLastTradingDate"
    headerName: "Effective Last Trading Date"
  - field: "lastTradingTime"
    headerName: "Last Trading Time"
  - field: "modifier"
    headerName: "Modifier"
  - field: "priceQuotationFactor"
    headerName: "Price Quotation Factor"
  - field: "contractSize"
    headerName: "Contract Size"
  - field: "isin"
    headerName: "ISIN"
  - field: "sedol"
    headerName: "SEDOL"
booleanFields: ["isTraded"]
codeFields: ["recordStatus", "status"]
sampleFields: ["instId", "$D_instClassId", "strikePrice", "isTraded", "status", "lastTradingDate", "recordStatus"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Inst. ID"
        type: combobox
      - label: "Inst. Class ID"
        type: combobox
  - heading: "General"
    fields:
      - label: "Status"
        type: textbox
      - label: "Effective Status"
        type: textbox
      - label: "Strike Price"
        type: textbox
      - label: "Effective Date"
        type: textbox
      - label: "ISIN"
        type: textbox
      - label: "SEDOL"
        type: textbox
  - heading: "First Trading"
    fields:
      - label: "First Trading Date"
        type: textbox
      - label: "First Trading Time"
        type: textbox
  - heading: "Last Trading"
    fields:
      - label: "Last Trading Date"
        type: textbox
      - label: "Effective Last Trading Date"
        type: textbox
      - label: "Last Trading Time"
        type: textbox
  - heading: "Price"
    fields:
      - label: "Price Quotation Factor"
        type: textbox
      - label: "Contract Size"
        type: textbox
  - heading: "Modified Values"
    fields:
      - label: "Modifier"
        type: textbox
  - heading: "Trading Parameters"
    fields:
      - label: "Traded?"
        type: combobox

---

