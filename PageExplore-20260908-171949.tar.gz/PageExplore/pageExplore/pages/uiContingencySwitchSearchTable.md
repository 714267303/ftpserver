---
label: "Maintain Contingency Switch"
route: "/UI/uiContingencySwitchSearchTable"
cacheName: "contingencySwitchPermCache"
pkField: "contingencySwitchId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "contingencySwitchId"
    headerName: "Contingency Switch ID"
  - field: "isStaticPriceLimitEnabled"
    headerName: "Static Price Limit Enabled?"
  - field: "isDynamicPriceLimitEnabled"
    headerName: "Dynamic Price Limit Enabled?"
  - field: "isVcmEnabled"
    headerName: "VCM Enabled?"
  - field: "isSmpEnabled"
    headerName: "SMP Enabled?"
  - field: "isImpliedEnabled"
    headerName: "Implied Enabled?"
  - field: "isPtrmEnabled"
    headerName: "PTRM Enabled?"
booleanFields: []
codeFields: []
sampleFields: ["requestStatus", "requestAction", "recordStatus", "contingencySwitchId", "isStaticPriceLimitEnabled"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Contingency Switch ID"
        type: combobox
  - heading: "General"
    fields:
      - label: "Static Price Limit Enabled?"
        type: combobox
      - label: "Dynamic Price Limit Enabled?"
        type: combobox
      - label: "VCM Enabled?"
        type: combobox
      - label: "SMP Enabled?"
        type: combobox
      - label: "Implied Enabled?"
        type: combobox
      - label: "PTRM Enabled?"
        type: combobox
---
