---
label: "Maintain MMP Parameter"
route: "/UI/uiMmpParameterSearchTable"
cacheName: "mmpParameterPermCache"
pkField: "$D_participantId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "$D_participantId"
    headerName: "Exchange Part. ID"
  - field: "$D_underlyingId"
    headerName: "Underlying ID"
  - field: "isIncludeFutures"
    headerName: "Include Futures?"
  - field: "quantityProtection"
    headerName: "Quantity Protection"
  - field: "deltaProtection"
    headerName: "Delta Protection"
  - field: "exposureTimeLimitInterval"
    headerName: "Exposure Time Limit Interval"
  - field: "frozenTime"
    headerName: "Frozen Time"
booleanFields: []
codeFields: []
sampleFields: ["requestStatus", "requestAction", "recordStatus", "$D_participantId", "$D_underlyingId"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Exchange Part. ID"
        type: combobox
      - label: "Underlying ID"
        type: combobox
  - heading: "MMP"
    fields:
      - label: "Include Futures?"
        type: combobox
      - label: "Quantity Protection"
        type: textbox
      - label: "Delta Protection"
        type: textbox
      - label: "Exposure Time Limit Interval"
        type: textbox
      - label: "Frozen Time"
        type: textbox
---
