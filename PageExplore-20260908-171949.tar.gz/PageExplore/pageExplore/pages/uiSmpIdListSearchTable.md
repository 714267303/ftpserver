---
label: "Maintain SMP ID List"
route: "/UI/uiSmpIdListSearchTable"
cacheName: "smpIdListPermCache"
pkField: "smpIdListId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; parent grid key is page-specific"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "observed"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
  subTables:
    - name: "SMP ID List detail sub-table"
      keyPattern: "smpIdListDetailDialog_<uuid>_subDetailTable1"
      observationStatus: "observed"
      fields: ["smpId", "smpIdStatus"]
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "smpIdListId"
    headerName: "SMP ID List ID"
  - field: "name"
    headerName: "Name"
  - field: "description"
    headerName: "Description"
  - field: "$D_participantId"
    headerName: "Owner ID"
booleanFields: []
codeFields: []
sampleFields: ["requestStatus", "requestAction", "recordStatus", "smpIdListId", "name"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "SMP ID List ID"
        type: combobox
      - label: "Name"
        type: textbox
      - label: "Description"
        type: textbox
      - label: "Owner ID"
        type: combobox
---
