---
label: "Maintain System Preference"
route: "/UI/uiSystemPreferenceSearchTable"
cacheName: "systemPreferencePermCache"
pkField: "uiSysPrefGrpId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "uiSysPrefGrpId"
    headerName: "Group ID"
  - field: "$D_appId"
    headerName: "App ID"
  - field: "name"
    headerName: "Name"
  - field: "description"
    headerName: "Description"
booleanFields: []
codeFields: []
sampleFields: ["requestStatus", "requestAction", "recordStatus", "uiSysPrefGrpId", "$D_appId"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Group ID"
        type: combobox
      - label: "App ID"
        type: combobox
      - label: "Name"
        type: textbox
      - label: "Description"
        type: textbox
---
