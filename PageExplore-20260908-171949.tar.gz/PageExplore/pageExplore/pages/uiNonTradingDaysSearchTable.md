---
label: "Maintain Non-Trading Days"
route: "/UI/uiNonTradingDaysSearchTable"
cacheName: "nonTradingDaysPermCache"
pkField: "nonTradingDaysId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "nonTradingDaysId"
    headerName: "Non-Trading Days ID"
  - field: "name"
    headerName: "Non-Trading Days Name"
  - field: "description"
    headerName: "Description"
booleanFields: []
codeFields: []
sampleFields: ["requestStatus", "requestAction", "recordStatus", "nonTradingDaysId", "name"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Non-Trading Days ID"
        type: combobox
      - label: "Non-Trading Days Name"
        type: textbox
      - label: "Description"
        type: textbox
---
