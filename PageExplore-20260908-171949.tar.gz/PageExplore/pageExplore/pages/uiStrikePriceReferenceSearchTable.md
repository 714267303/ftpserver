---
label: "Maintain Strike Price Reference"
route: "/UI/uiStrikePriceReferenceSearchTable"
cacheName: "strikePriceReferencePermCache"
pkField: "strikePriceRefId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "strikePriceRefId"
    headerName: "Strike Price Ref ID"
  - field: "name"
    headerName: "Name"
  - field: "description"
    headerName: "Description"
  - field: "sourceType"
    headerName: "Source Type"
  - field: "$D_instClassId"
    headerName: "Instrument Class ID"
  - field: "$D_underlyingId"
    headerName: "Underlying ID"
  - field: "priceType"
    headerName: "Price Type"
  - field: "deltaDays"
    headerName: "Delta Days"
booleanFields: []
codeFields: ["recordStatus", "sourceType", "priceType"]
sampleFields: ["strikePriceRefId", "name", "description", "sourceType", "priceType", "recordStatus"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Strike Price Ref ID"
        type: combobox
      - label: "Name"
        type: textbox
      - label: "Description"
        type: textbox
      - label: "Instrument Class ID"
        type: combobox
      - label: "Underlying ID"
        type: combobox
  - heading: "General"
    fields:
      - label: "Source Type"
        type: combobox
      - label: "Price Type"
        type: combobox
      - label: "Delta Days"
        type: textbox
---
