---
label: "Maintain Inst. Class Price Tick Limit"
route: "/UI/uiInstClassPriceTickLimitSearchTable"
cacheName: "instClassPriceTickLimitPermCache"
pkField: "instClassId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "instClassId"
    headerName: "Inst. Class ID"
  - field: "referencePrice"
    headerName: "Price Tick Reference Price"
  - field: "priceTickLowerLimit"
    headerName: "Price Tick Lower Limit"
  - field: "priceTickUpperLimit"
    headerName: "Price Tick Upper Limit"
  - field: "nextDayPriceTickRefPrice"
    headerName: "Next Day Price Tick Reference Price"
  - field: "nextDayPriceTickLowerLimit"
    headerName: "Next Day Price Tick Lower Limit"
  - field: "nextDayPriceTickUpperLimit"
    headerName: "Next Day Price Tick Upper Limit"
booleanFields: []
codeFields: []
sampleFields: ["requestStatus", "requestAction", "recordStatus", "instClassId", "referencePrice"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Inst. Class ID"
        type: combobox
  - heading: "Price"
    fields:
      - label: "Price Tick Reference Price"
        type: textbox
      - label: "Price Tick Lower Limit"
        type: textbox
      - label: "Price Tick Upper Limit"
        type: textbox
      - label: "Next Day Price Tick Reference Price"
        type: textbox
      - label: "Next Day Price Tick Lower Limit"
        type: textbox
      - label: "Next Day Price Tick Upper Limit"
        type: textbox
---
