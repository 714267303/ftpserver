---
label: "Control Capital Adjustment"
route: "/UI/uiCapitalAdjustmentSearchTable"
cacheName: "capitalAdjustmentPermCache"
pkField: "caEventId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "caEventId"
    headerName: "CA Event ID"
  - field: "caEventType"
    headerName: "CA Event Type"
  - field: "underlyingIssuer"
    headerName: "Underlying Issuer"
  - field: "effectiveAdjDate"
    headerName: "Effective Adjustment Date"
  - field: "adjRatio"
    headerName: "Adjustment Ratio"
  - field: "newDecimalsContractSize"
    headerName: "New Decimals For Contract Size & PQF"
booleanFields: []
codeFields: []
sampleFields: ["requestStatus", "requestAction", "caEventId", "caEventType", "underlyingIssuer"]
notes: "No data currently; grid structure may still be empty."
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "CA Event ID"
        type: combobox
      - label: "CA Event Type"
        type: combobox
      - label: "Underlying Issuer"
        type: textbox
  - heading: "General"
    fields:
      - label: "Effective Adjustment Date"
        type: textbox
      - label: "Adjustment Ratio"
        type: textbox
      - label: "New Decimals For Contract Size & PQF"
        type: textbox
---
