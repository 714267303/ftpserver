---
label: "Maintain Strike Price Table"
route: "/UI/uiStrikePriceTableSearchTable"
cacheName: "strikePriceTablePermCache"
pkField: "strikePriceTableId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "strikePriceTableId"
    headerName: "Strike Price Table ID"
  - field: "name"
    headerName: "Name"
  - field: "description"
    headerName: "Description"
  - field: "decimalsInPrice"
    headerName: "Decimals"
booleanFields: []
codeFields: ["recordStatus"]
sampleFields: ["strikePriceTableId", "name", "description", "decimalsInPrice", "recordStatus"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Strike Price Table ID"
        type: combobox
      - label: "Name"
        type: textbox
      - label: "Description"
        type: textbox
  - heading: "General"
    fields:
      - label: "Decimals"
        type: textbox
---
