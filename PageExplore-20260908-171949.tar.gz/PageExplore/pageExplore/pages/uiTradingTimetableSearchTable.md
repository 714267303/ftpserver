---
label: "Maintain Trading Timetable"
route: "/UI/uiTradingTimetableSearchTable"
cacheName: "tradingTimetablePermCache"
pkField: "timetableId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "$D_exchangeId"
    headerName: "Exchange ID"
  - field: "timetableId"
    headerName: "Trading Timetable ID"
  - field: "name"
    headerName: "Trading Timetable Name"
  - field: "description"
    headerName: "Description"
  - field: "timetableType"
    headerName: "Timetable Type"
booleanFields: []
codeFields: []
sampleFields: ["requestStatus", "requestAction", "recordStatus", "$D_exchangeId", "timetableId"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Exchange ID"
        type: combobox
      - label: "Trading Timetable ID"
        type: combobox
      - label: "Trading Timetable Name"
        type: textbox
      - label: "Description"
        type: textbox
  - heading: "General"
    fields:
      - label: "Timetable Type"
        type: combobox
---
