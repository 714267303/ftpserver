---
label: "Maintain Global Parameters"
route: "/UI/uiGlobalParametersSearchTable"
cacheName: "globalParametersPermCache"
pkField: "globalParamId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "globalParamId"
    headerName: "Global Parameters ID"
  - field: "instrumentRetentionPeriod"
    headerName: "Instrument Retention Period"
  - field: "maxOrderFlowSession"
    headerName: "Maximum Order Flow Session"
  - field: "maxTradingGuiUser"
    headerName: "Maximum Trading GUI User"
  - field: "maxDropCopySession"
    headerName: "Maximum Drop Copy Session"
  - field: "maxTpsPerOrderFlowSession"
    headerName: "Maximum TPS Per Order Flow Session"
  - field: "maxTraderIdPerRg"
    headerName: "Maximum Trader ID Per Risk Group"
  - field: "maxTradablePerRg"
    headerName: "Maximum Tradable Per Risk Group"
  - field: "maxRgPerParticipant"
    headerName: "Maximum Risk Group Per Sponsored Participant"
  - field: "maxNotificationIdPerRg"
    headerName: "Maximum Notification ID Per Risk Group"
  - field: "caCoolOffPeriod"
    headerName: "CA Cool-off Period"
  - field: "defaultOrderSizeLimit"
    headerName: "Default Order Size Limit"
  - field: "orderSizeLimitByEp"
    headerName: "Maximum Order Size Limit By EP"
  - field: "isRemoveOrdersViolatingSmp"
    headerName: "Remove Orders Violating Internal Crossing Rule?"
  - field: "massQuoteAllowedDifferentUnderlyingIssuer"
    headerName: "Mass Quote Allowed Different Underlying Issuer?"
  - field: "maxQuoteEntriesPerCompIdPerInst"
    headerName: "Maximum Quote Entries Per Comp ID Per Instrument"
  - field: "maxOrderQuantity"
    headerName: "Maximum Order Quantity"
  - field: "maxOrdersPerPriceQPreopen"
    headerName: "Maximum Orders Per Price Q In PREOPEN"
  - field: "maxOrdersPerPriceQOpen"
    headerName: "Maximum Orders Per Price Q In OPEN"
  - field: "maxTmc"
    headerName: "Maximum TMC"
  - field: "maxTmcPerEp"
    headerName: "Maximum TMC Per EP"
  - field: "disseminateImpliedInOrdersViaMktData"
    headerName: "Disseminate Implied In Orders Via Market Data?"
  - field: "maxPrice"
    headerName: "Maximum Price"
  - field: "maxDecimalsInPrice"
    headerName: "Maximum Price Decimals"
  - field: "minPrice"
    headerName: "Minimum Price"
  - field: "minDecimalsInPrice"
    headerName: "Minimum Price Decimals"
  - field: "maxTradingHours"
    headerName: "Maximum Trading Hours"
  - field: "tradingPauseTradingStateId"
    headerName: "Trading Pause Trading State"
  - field: "earliestTradingStartLogicalDayInd"
    headerName: "Earliest Trading Start Logical Day Ind"
  - field: "earliestTradingStartTime"
    headerName: "Earliest Trading Start Time"
  - field: "latestTradingEndLogicalDayInd"
    headerName: "Latest Trading End Logical Day Ind"
  - field: "latestTradingEndTime"
    headerName: "Latest Trading End Time"
  - field: "blockTradeAllowedConclusionTime"
    headerName: "Block Trade Allowed Conclusion Time"
  - field: "maxBlockTradeQuantity"
    headerName: "Maximum Block Trade Quantity"
  - field: "blockTradeSizeLimitByEp"
    headerName: "Maximum Block Trade Size Limit By EP"
  - field: "maxLegInBlockTrade"
    headerName: "Num Of Leg In Block Trade"
  - field: "isDuplicatedLegInBlockTradeAllowed"
    headerName: "Duplicated Leg In Block Trade Allowed?"
  - field: "defaultBlockTradeSizeLimit"
    headerName: "Default Block Trade Size Limit"
  - field: "isAbruptDisconnTriggerCod"
    headerName: "Abrupt Disconnection Trigger COD?"
  - field: "numMissingHeartbeat"
    headerName: "Number Of Missing Heartbeat"
  - field: "timeoutBeforeCod"
    headerName: "Timeout Before COD"
  - field: "maxPtrmGuiUser"
    headerName: "Maximum PTRM GUI User"
  - field: "maxTpsPerPtrmSession"
    headerName: "Maximum TPS Per PTRM Session"
  - field: "defaultPtrmMaxSizeLimit"
    headerName: "Default PTRM Max Size Limit"
  - field: "defaultPtrmExposureLimit"
    headerName: "Default PTRM Exposure Limit"
  - field: "defaultPtrmQuantityLimit"
    headerName: "Default PTRM Quantity Limit"
  - field: "defaultPtrmOrderRateLimit"
    headerName: "Default PTRM Order Rate Limit"
  - field: "defaultPtrmOrderRatePeriod"
    headerName: "Default PTRM Order Rate Period"
  - field: "defaultPtrmOrderCoefficient"
    headerName: "Default PTRM Order Coefficient (%)"
  - field: "defaultPtrmExecThrottlePeriod"
    headerName: "Default PTRM Execution Throttle Period"
  - field: "defaultPtrmNoticeThres"
    headerName: "Default PTRM Notice Threshold (%)"
  - field: "defaultPtrmWarningThres"
    headerName: "Default PTRM Warning Threshold (%)"
  - field: "defaultMmpIsIncludeFutures"
    headerName: "Default MMP Include Futures?"
  - field: "defaultMmpQuantityProtection"
    headerName: "Default MMP Quantity Protection"
  - field: "defaultMmpDeltaProtection"
    headerName: "Default MMP Delta Protection"
  - field: "defaultMmpExposureTimeLimitInterval"
    headerName: "Default MMP Exposure Time Limit Interval"
  - field: "defaultMmpFrozenTime"
    headerName: "Default MMP Frozen Time"
  - field: "smpIdMaintenanceReqApprovalPeriod"
    headerName: "SMP ID Maintenance Request Approval Period"
  - field: "smpIdCounterpartyReqPeriod"
    headerName: "SMP ID Counterparty Request Period"
  - field: "smpIdRetentionPeriod"
    headerName: "SMP ID Retention Period"
booleanFields: []
codeFields: []
sampleFields: ["requestStatus", "requestAction", "recordStatus", "globalParamId", "instrumentRetentionPeriod"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Global Parameters ID"
        type: combobox
  - heading: "General"
    fields:
      - label: "Instrument Retention Period"
        type: textbox
      - label: "CA Cool-off Period"
        type: textbox
      - label: "Trading Pause Trading State"
        type: combobox
      - label: "Maximum Trading Hours"
        type: textbox
      - label: "Earliest Trading Start Logical Day Ind"
        type: textbox
      - label: "Earliest Trading Start Time"
        type: textbox
      - label: "Latest Trading End Logical Day Ind"
        type: textbox
      - label: "Latest Trading End Time"
        type: textbox
  - heading: "Order and Session"
    fields:
      - label: "Maximum Order Flow Session"
        type: textbox
      - label: "Maximum Trading GUI User"
        type: textbox
      - label: "Maximum Drop Copy Session"
        type: textbox
      - label: "Maximum TPS Per Order Flow Session"
        type: textbox
      - label: "Maximum Trader ID Per Risk Group"
        type: textbox
      - label: "Maximum Tradable Per Risk Group"
        type: textbox
      - label: "Maximum Risk Group Per Sponsored Participant"
        type: textbox
      - label: "Maximum Notification ID Per Risk Group"
        type: textbox
      - label: "Default Order Size Limit"
        type: textbox
      - label: "Maximum Order Size Limit By EP"
        type: textbox
      - label: "Maximum Order Quantity"
        type: textbox
      - label: "Maximum Orders Per Price Q In PREOPEN"
        type: textbox
      - label: "Maximum Orders Per Price Q In OPEN"
        type: textbox
      - label: "Maximum Quote Entries Per Comp ID Per Instrument"
        type: textbox
      - label: "Remove Orders Violating Internal Crossing Rule?"
        type: combobox
      - label: "Mass Quote Allowed Different Underlying Issuer?"
        type: combobox
      - label: "Disseminate Implied In Orders Via Market Data?"
        type: combobox
  - heading: "Block Trade"
    fields:
      - label: "Num Of Leg In Block Trade"
        type: textbox
      - label: "Maximum Block Trade Quantity"
        type: textbox
      - label: "Maximum Block Trade Size Limit By EP"
        type: textbox
      - label: "Default Block Trade Size Limit"
        type: textbox
      - label: "Block Trade Allowed Conclusion Time"
        type: textbox
      - label: "Duplicated Leg In Block Trade Allowed?"
        type: combobox
  - heading: "Price"
    fields:
      - label: "Maximum Price"
        type: textbox
      - label: "Maximum Price Decimals"
        type: textbox
      - label: "Minimum Price"
        type: textbox
      - label: "Minimum Price Decimals"
        type: textbox
  - heading: "TMC"
    fields:
      - label: "Maximum TMC"
        type: textbox
      - label: "Maximum TMC Per EP"
        type: textbox
  - heading: "PTRM"
    fields:
      - label: "Maximum PTRM GUI User"
        type: textbox
      - label: "Maximum TPS Per PTRM Session"
        type: textbox
      - label: "Default PTRM Max Size Limit"
        type: textbox
      - label: "Default PTRM Exposure Limit"
        type: textbox
      - label: "Default PTRM Quantity Limit"
        type: textbox
      - label: "Default PTRM Order Rate Limit"
        type: textbox
      - label: "Default PTRM Order Rate Period"
        type: textbox
      - label: "Default PTRM Order Coefficient (%)"
        type: textbox
      - label: "Default PTRM Execution Throttle Period"
        type: textbox
      - label: "Default PTRM Notice Threshold (%)"
        type: textbox
      - label: "Default PTRM Warning Threshold (%)"
        type: textbox
  - heading: "MMP"
    fields:
      - label: "Default MMP Include Futures?"
        type: combobox
      - label: "Default MMP Quantity Protection"
        type: textbox
      - label: "Default MMP Delta Protection"
        type: textbox
      - label: "Default MMP Exposure Time Limit Interval"
        type: textbox
      - label: "Default MMP Frozen Time"
        type: textbox
  - heading: "SMP"
    fields:
      - label: "SMP ID Maintenance Request Approval Period"
        type: textbox
      - label: "SMP ID Counterparty Request Period"
        type: textbox
      - label: "SMP ID Retention Period"
        type: textbox
  - heading: "Session"
    fields:
      - label: "Abrupt Disconnection Trigger COD?"
        type: combobox
      - label: "Number Of Missing Heartbeat"
        type: textbox
      - label: "Timeout Before COD"
        type: textbox
---
