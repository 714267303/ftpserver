---
label: "Review SMP Request"
route: "/UI/uiReviewSmpRequestSearchTable"
cacheName: "reviewSmpRequestPermCache"
pkField: "smpRequestId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "lastUpdateDateTime"
    headerName: "Last Update Date Time"
  - field: "smpRequestId"
    headerName: "SMP Request ID"
  - field: "submitDateTime"
    headerName: "Submit Date Time"
  - field: "smpRequestType"
    headerName: "Type"
  - field: "smpRequestAction"
    headerName: "Action"
  - field: "$D_uploader"
    headerName: "Uploader"
  - field: "$D_participantId"
    headerName: "Participant ID"
  - field: "smpId"
    headerName: "SMP ID"
  - field: "$D_primaryParticipantId"
    headerName: "Primary Participant ID"
  - field: "$D_relatedParticipantId"
    headerName: "Related Participant ID"
  - field: "smpInstruction"
    headerName: "SMP Instruction"
  - field: "creationRefNo"
    headerName: "Creation Reference Number"
  - field: "smpConsentStatus"
    headerName: "Consent Status"
  - field: "smpConsentId"
    headerName: "SMP Consent ID"
  - field: "pdfFileName"
    headerName: "PDF File Name"
  - field: "smpRequestCode"
    headerName: "Rejection Code"
  - field: "smpRequestStatus"
    headerName: "Request Status"
booleanFields: []
codeFields: []
sampleFields: ["requestStatus", "requestAction", "recordStatus", "lastUpdateDateTime", "smpRequestId"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "SMP Request ID"
        type: combobox
      - label: "SMP ID"
        type: combobox
      - label: "Creation Reference Number"
        type: textbox
      - label: "Type"
        type: combobox
      - label: "Action"
        type: combobox
  - heading: "Participant Details"
    fields:
      - label: "Uploader"
        type: combobox
      - label: "Participant ID"
        type: combobox
      - label: "Primary Participant ID"
        type: combobox
      - label: "Related Participant ID"
        type: combobox
  - heading: "General"
    fields:
      - label: "Last Update Date Time"
        type: textbox
      - label: "Submit Date Time"
        type: textbox
      - label: "SMP Instruction"
        type: combobox
      - label: "Request Status"
        type: combobox
      - label: "Consent Status"
        type: combobox
      - label: "SMP Consent ID"
        type: combobox
      - label: "Rejection Code"
        type: textbox
      - label: "PDF File Name"
        type: textbox
---
