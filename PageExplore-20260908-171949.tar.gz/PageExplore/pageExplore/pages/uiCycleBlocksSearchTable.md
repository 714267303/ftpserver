---
label: "Maintain Cycle Blocks"
route: "/UI/uiCycleBlocksSearchTable"
cacheName: "cycleBlocksPermCache"
pkField: "cycleBlocksId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "cycleBlocksId"
    headerName: "Cycle Blocks ID"
  - field: "name"
    headerName: "Name"
  - field: "description"
    headerName: "Description"
  - field: "unit"
    headerName: "Unit"
  - field: "cycleType"
    headerName: "Type"
booleanFields: []
codeFields: ["unit", "cycleType", "recordStatus"]
sampleFields: ["cycleBlocksId", "name", "description", "unit", "cycleType", "recordStatus"]
notes: "unit uses codes D(aily)/W(eekly)/M(onthly); cycleType uses codes O(ption)/U(uture)"
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Cycle Blocks ID"
        type: combobox
      - label: "Name"
        type: textbox
      - label: "Description"
        type: textbox
  - heading: "General"
    fields:
      - label: "Unit"
        type: textbox
      - label: "Type"
        type: textbox

---
