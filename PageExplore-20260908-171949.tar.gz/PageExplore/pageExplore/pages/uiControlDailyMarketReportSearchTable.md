---
label: "Control Daily Market Report (DMR)"
route: "/UI/uiControlDailyMarketReportSearchTable"
cacheName: "controlDailyMarketReportPermCache"
pkField: "rptId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: ""
    headerName: ""
  - field: "rptId"
    headerName: "Report ID"
  - field: "name"
    headerName: "Name"
booleanFields: []
codeFields: []
sampleFields: ["rptId", "name"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Report ID"
        type: combobox
      - label: "Name"
        type: textbox
---
