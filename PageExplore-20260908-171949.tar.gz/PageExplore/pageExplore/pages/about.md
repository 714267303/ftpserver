---
label: "About"
route: "/UI/about"
cacheName: "aboutPermCache"
pkField: ""
hasGrid: false
booleanFields: []
codeFields: []
sampleFields: []
profiled: true
---

