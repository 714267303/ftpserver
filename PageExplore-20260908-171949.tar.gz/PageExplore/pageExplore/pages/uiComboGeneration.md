---
label: "Combo Generation"
route: "/UI/uiComboGeneration"
cacheName: "comboGenerationPermCache"
pkField: "comboId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "action"
    headerName: "Action"
  - field: "submission"
    headerName: "Submission"
  - field: "comboId"
    headerName: "Combo ID"
  - field: "comboClassId"
    headerName: "Combo Class ID"
  - field: "comboEffectiveDate"
    headerName: "Effective Date"
  - field: "firstTradingDate"
    headerName: "First Trading Date"
  - field: "firstTradingTime"
    headerName: "First Trading Time"
  - field: "lastTradingDate"
    headerName: "Last Trading Date"
  - field: "lastTradingTime"
    headerName: "Last Trading Time"
  - field: "operation1"
    headerName: "Operation"
  - field: "ratio1"
    headerName: "Ratio"
  - field: "legInstId1"
    headerName: "Inst. ID"
  - field: "operation2"
    headerName: "Operation"
  - field: "ratio2"
    headerName: "Ratio"
  - field: "legInstId2"
    headerName: "Inst. ID"
  - field: "existingComboId"
    headerName: "Combo ID"
  - field: "remark"
    headerName: "Remark"
booleanFields: []
codeFields: ["action", "submission"]
sampleFields: ["comboId", "comboClassId", "comboEffectiveDate", "lastTradingDate", "legInstId1", "legInstId2"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Combo ID"
        type: combobox
      - label: "Combo Class ID"
        type: combobox
      - label: "Existing Combo ID"
        type: combobox
  - heading: "General"
    fields:
      - label: "Action"
        type: combobox
      - label: "Submission"
        type: combobox
      - label: "Remark"
        type: textbox
  - heading: "Dates"
    fields:
      - label: "Effective Date"
        type: textbox
      - label: "First Trading Date"
        type: textbox
      - label: "First Trading Time"
        type: textbox
      - label: "Last Trading Date"
        type: textbox
      - label: "Last Trading Time"
        type: textbox
  - heading: "Combo Leg 1"
    fields:
      - label: "Operation"
        type: combobox
      - label: "Ratio"
        type: textbox
      - label: "Inst. ID"
        type: combobox
  - heading: "Combo Leg 2"
    fields:
      - label: "Operation"
        type: combobox
      - label: "Ratio"
        type: textbox
      - label: "Inst. ID"
        type: combobox
---
