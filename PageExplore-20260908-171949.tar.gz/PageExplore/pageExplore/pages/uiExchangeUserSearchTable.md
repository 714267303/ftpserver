---
label: "Maintain Exchange User"
route: "/UI/uiExchangeUserSearchTable"
cacheName: "exchangeUserPermCache"
pkField: "userId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "userId"
    headerName: "User ID"
  - field: "idpUserId"
    headerName: "IDP User ID"
  - field: "userType"
    headerName: "User Type"
  - field: "functionType"
    headerName: "Function Type"
  - field: "isSuspended"
    headerName: "Suspended?"
  - field: "$EXT_isLocked"
    headerName: "Locked?"
  - field: "$EXT_lockedReason"
    headerName: "Locked Reason"
  - field: "$EXT_lastLogonDate"
    headerName: "Last Logon Date"
  - field: "$EXT_lastLogonIp"
    headerName: "Last Logon Source IP"
booleanFields: []
codeFields: []
sampleFields: ["requestStatus", "requestAction", "recordStatus", "userId", "idpUserId"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "User ID"
        type: combobox
      - label: "IDP User ID"
        type: combobox
      - label: "User Type"
        type: combobox
      - label: "Function Type"
        type: combobox
  - heading: "General"
    fields:
      - label: "Suspended?"
        type: combobox
      - label: "Locked?"
        type: combobox
      - label: "Locked Reason"
        type: textbox
      - label: "Last Logon Date"
        type: textbox
      - label: "Last Logon Source IP"
        type: textbox
---
