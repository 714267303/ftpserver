---
label: "Maintain Combo Type Error Trade Parameters"
route: "/UI/uiComboTypeErrTradeParamSearchTable"
cacheName: "comboTypeErrTradeParamPermCache"
pkField: "comboTypeId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "comboTypeId"
    headerName: "Combo Type ID"
  - field: "prescribedTimeLimit"
    headerName: "Prescribed Time Limit (minutes)"
  - field: "contraEpResponseLimit"
    headerName: "Contra EP Response Limit (minutes)"
  - field: "acceptMsgTemplateId"
    headerName: "Accept Msg Template ID"
  - field: "rejectMsgTemplateId"
    headerName: "Reject Msg Template ID"
  - field: "cancelByEpMsgTemplateId"
    headerName: "Cancel Msg Template ID (By Participant)"
  - field: "cancelByPanelMsgTemplateId"
    headerName: "Cancel Msg Template ID (By Committee)"
booleanFields: []
codeFields: []
sampleFields: ["requestStatus", "requestAction", "recordStatus", "comboTypeId", "prescribedTimeLimit"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Combo Type ID"
        type: combobox
  - heading: "General"
    fields:
      - label: "Prescribed Time Limit (minutes)"
        type: textbox
      - label: "Contra EP Response Limit (minutes)"
        type: textbox
  - heading: "Message Template"
    fields:
      - label: "Accept Msg Template ID"
        type: combobox
      - label: "Reject Msg Template ID"
        type: combobox
      - label: "Cancel Msg Template ID (By Participant)"
        type: combobox
      - label: "Cancel Msg Template ID (By Committee)"
        type: combobox
---
