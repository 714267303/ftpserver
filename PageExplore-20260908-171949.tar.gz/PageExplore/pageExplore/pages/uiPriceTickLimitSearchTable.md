---
label: "Maintain Price Tick Limit Rule"
route: "/UI/uiPriceTickLimitSearchTable"
cacheName: "priceTickLimitPermCache"
pkField: "priceTickLimitId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "priceTickLimitId"
    headerName: "Price Tick Limit ID"
  - field: "name"
    headerName: "Name"
  - field: "description"
    headerName: "Description"
  - field: "deviationUnit"
    headerName: "Limit Deviation Unit"
  - field: "deviationTick"
    headerName: "Deviation Tick"
  - field: "exceptionDeviationTick"
    headerName: "Exception Deviation Tick"
  - field: "deviationPercentage"
    headerName: "Deviation Percentage"
  - field: "exceptionDeviationPercentage"
    headerName: "Exception Deviation Percentage"
booleanFields: []
codeFields: []
sampleFields: ["requestStatus", "requestAction", "recordStatus", "priceTickLimitId", "name"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Price Tick Limit ID"
        type: combobox
      - label: "Name"
        type: textbox
      - label: "Description"
        type: textbox
  - heading: "Price"
    fields:
      - label: "Limit Deviation Unit"
        type: textbox
      - label: "Deviation Tick"
        type: textbox
      - label: "Exception Deviation Tick"
        type: textbox
      - label: "Deviation Percentage"
        type: textbox
      - label: "Exception Deviation Percentage"
        type: textbox
---
