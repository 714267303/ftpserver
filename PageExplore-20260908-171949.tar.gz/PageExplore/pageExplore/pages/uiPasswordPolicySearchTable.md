---
label: "View Password Policy"
route: "/UI/uiPasswordPolicySearchTable"
cacheName: "passwordPolicyPermCache"
pkField: "passwordPolicyId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: ""
    headerName: ""
  - field: "passwordPolicyId"
    headerName: "Password Policy ID"
  - field: "passwordPolicyName"
    headerName: "Password Policy Name"
  - field: "policyType"
    headerName: "Policy Type"
  - field: "passwordMinLength"
    headerName: "Minimum Password Length"
  - field: "passwordMaxLength"
    headerName: "Maximum Password Length"
  - field: "passwordMinUpperCaseLetter"
    headerName: "Minimum Upper Case Letters"
  - field: "passwordMinLowerCaseLetter"
    headerName: "Minimum Lower Case Letters"
  - field: "passwordMinDigits"
    headerName: "Minimum Digits"
  - field: "passwordMinSpecialChars"
    headerName: "Minimum Special Characters"
  - field: "passwordValidityPeriod"
    headerName: "Password Validity Period"
  - field: "passwordExpiryAlert"
    headerName: "Password Expiry Advance Alert"
  - field: "enforcePasswordExpiryCheck"
    headerName: "Enforce Password Expiry Check?"
  - field: "passwordReuseCycle"
    headerName: "Password Reuse Cycle"
  - field: "numFailedAttempts"
    headerName: "Number of Failed Attempts"
  - field: "forcePasswordChange"
    headerName: "Change Password on 1st Logon?"
  - field: "maxPasswordChangesPerDay"
    headerName: "Maximum Password Changes Per Day"
  - field: "inactivityPeriod"
    headerName: "Inactivity Period"
  - field: "pwdExpiryInactivityHandling"
    headerName: "Password Expiry and Inactivity Handling"
booleanFields: []
codeFields: []
sampleFields: ["passwordPolicyId", "passwordPolicyName", "policyType", "passwordMinLength", "passwordMaxLength"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Password Policy ID"
        type: combobox
      - label: "Password Policy Name"
        type: textbox
      - label: "Policy Type"
        type: combobox
  - heading: "Password Rules"
    fields:
      - label: "Minimum Password Length"
        type: textbox
      - label: "Maximum Password Length"
        type: textbox
      - label: "Minimum Upper Case Letters"
        type: textbox
      - label: "Minimum Lower Case Letters"
        type: textbox
      - label: "Minimum Digits"
        type: textbox
      - label: "Minimum Special Characters"
        type: textbox
      - label: "Password Validity Period"
        type: textbox
      - label: "Password Expiry Advance Alert"
        type: textbox
      - label: "Enforce Password Expiry Check?"
        type: combobox
      - label: "Password Reuse Cycle"
        type: textbox
      - label: "Change Password on 1st Logon?"
        type: combobox
      - label: "Maximum Password Changes Per Day"
        type: textbox
      - label: "Number of Failed Attempts"
        type: textbox
      - label: "Inactivity Period"
        type: textbox
      - label: "Password Expiry and Inactivity Handling"
        type: combobox
---
