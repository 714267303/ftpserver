---
label: "Maintain Price Tick"
route: "/UI/uiPriceTickSearchTable"
cacheName: "priceTickPermCache"
pkField: "priceTickId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "priceTickId"
    headerName: "Price Tick ID"
  - field: "name"
    headerName: "Name"
  - field: "description"
    headerName: "Description"
  - field: "decimalsInPrice"
    headerName: "Decimals"
  - field: "lowerLimit"
    headerName: "Default Lower Limit"
  - field: "upperLimit"
    headerName: "Default Upper Limit"
  - field: "isBlockTradeFollowOrder"
    headerName: "Block Trade Follow Order?"
booleanFields: []
codeFields: []
sampleFields: ["requestStatus", "requestAction", "recordStatus", "priceTickId", "name"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Price Tick ID"
        type: combobox
      - label: "Name"
        type: textbox
      - label: "Description"
        type: textbox
  - heading: "Price"
    fields:
      - label: "Decimals"
        type: textbox
      - label: "Default Lower Limit"
        type: textbox
      - label: "Default Upper Limit"
        type: textbox
      - label: "Block Trade Follow Order?"
        type: combobox
---
