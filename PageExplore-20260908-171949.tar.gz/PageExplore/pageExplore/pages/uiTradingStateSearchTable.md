---
label: "Maintain Trading State"
route: "/UI/uiTradingStateSearchTable"
cacheName: "tradingStatePermCache"
pkField: "tradingStateId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "tradingStateId"
    headerName: "Trading State ID"
  - field: "tradingStateName"
    headerName: "Trading State Name"
  - field: "tradingStateType"
    headerName: "Trading State Type"
  - field: "description"
    headerName: "Description"
  - field: "isBusinessTradingState"
    headerName: "Business Trading State?"
  - field: "isLoAllowed"
    headerName: "LO Allowed?"
  - field: "isMoAllowed"
    headerName: "MO Allowed?"
  - field: "isM2lAllowed"
    headerName: "M2L Allowed?"
  - field: "isDayAllowed"
    headerName: "Day Allowed?"
  - field: "isFakAllowed"
    headerName: "FAK Allowed?"
  - field: "isFokAllowed"
    headerName: "FOK Allowed?"
  - field: "isGtcAllowed"
    headerName: "GTC Allowed?"
  - field: "isGtdAllowed"
    headerName: "GTD Allowed?"
  - field: "isAtCrossingAllowed"
    headerName: "At Crossing Allowed?"
  - field: "isOrderEntryAllowed"
    headerName: "Order Entry Allowed?"
  - field: "isOrderAmendKeepPriorityAllowed"
    headerName: "Order Amend Allowed (Preserve Time Priority)?"
  - field: "isOrderAmendLossPriorityAllowed"
    headerName: "Order Amend Allowed (Loss Of Time Priority)?"
  - field: "isOrderCancelAllowed"
    headerName: "Order Cancel Allowed?"
  - field: "isQuoteRequestAllowed"
    headerName: "Quote Request Allowed?"
  - field: "isSingleQuoteAllowed"
    headerName: "Single Quote Allowed?"
  - field: "isMassQuoteAllowed"
    headerName: "Mass Quote Allowed?"
  - field: "isBlockTradeAllowed"
    headerName: "Block Trade Allowed?"
  - field: "isErrorTradeClaimAllowed"
    headerName: "Error Trade Claim Allowed?"
  - field: "isTmcCreationAllowed"
    headerName: "TMC Creation Allowed?"
  - field: "isAdminOrderCancelAllowed"
    headerName: "Admin Order Cancel Allowed?"
  - field: "isAdminTradeCancelAllowed"
    headerName: "Admin Trade Cancel Allowed?"
  - field: "isAdminTradePriceAdjustment"
    headerName: "Admin Trade Price Adjustment?"
  - field: "isInternalOnBehalfEnterTrade"
    headerName: "Internal On-Behalf Enter Trade?"
  - field: "isCalculateAhtStaticPriceLimitRefPrice"
    headerName: "Calculate AHT Static Price Limit Ref Price?"
  - field: "isRemoveAllOrders"
    headerName: "Remove All Orders?"
  - field: "isInactivateNonAhtOrders"
    headerName: "Inactivate Non-AHT Orders?"
  - field: "isImpliedGenApplicable"
    headerName: "Implied Generation Applicable?"
  - field: "isStaticPriceLimitApplicable"
    headerName: "Static Price Limit Applicable?"
  - field: "isDynamicPriceLimitApplicable"
    headerName: "Dynamic Price Limit Applicable?"
  - field: "isVcmApplicable"
    headerName: "VCM Applicable?"
  - field: "vcmStartOffset"
    headerName: "VCM Start Offset"
  - field: "vcmEndOffset"
    headerName: "VCM End Offset"
  - field: "randomStartInterval"
    headerName: "Random Start Interval"
booleanFields: []
codeFields: []
sampleFields: ["requestStatus", "requestAction", "recordStatus", "tradingStateId", "tradingStateName"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Trading State ID"
        type: combobox
      - label: "Trading State Name"
        type: textbox
      - label: "Trading State Type"
        type: combobox
      - label: "Description"
        type: textbox
  - heading: "General"
    fields:
      - label: "Business Trading State?"
        type: combobox
      - label: "Random Start Interval"
        type: textbox
  - heading: "Order Types"
    fields:
      - label: "LO Allowed?"
        type: combobox
      - label: "MO Allowed?"
        type: combobox
      - label: "M2L Allowed?"
        type: combobox
      - label: "Day Allowed?"
        type: combobox
      - label: "FAK Allowed?"
        type: combobox
      - label: "FOK Allowed?"
        type: combobox
      - label: "GTC Allowed?"
        type: combobox
      - label: "GTD Allowed?"
        type: combobox
      - label: "At Crossing Allowed?"
        type: combobox
  - heading: "Order Permissions"
    fields:
      - label: "Order Entry Allowed?"
        type: combobox
      - label: "Order Amend Allowed (Preserve Time Priority)?"
        type: combobox
      - label: "Order Amend Allowed (Loss Of Time Priority)?"
        type: combobox
      - label: "Order Cancel Allowed?"
        type: combobox
  - heading: "Quote Permissions"
    fields:
      - label: "Quote Request Allowed?"
        type: combobox
      - label: "Single Quote Allowed?"
        type: combobox
      - label: "Mass Quote Allowed?"
        type: combobox
  - heading: "Trade Permissions"
    fields:
      - label: "Block Trade Allowed?"
        type: combobox
      - label: "Error Trade Claim Allowed?"
        type: combobox
      - label: "TMC Creation Allowed?"
        type: combobox
      - label: "Admin Order Cancel Allowed?"
        type: combobox
      - label: "Admin Trade Cancel Allowed?"
        type: combobox
      - label: "Admin Trade Price Adjustment?"
        type: combobox
      - label: "Internal On-Behalf Enter Trade?"
        type: combobox
  - heading: "Contingency"
    fields:
      - label: "Calculate AHT Static Price Limit Ref Price?"
        type: combobox
      - label: "Remove All Orders?"
        type: combobox
      - label: "Inactivate Non-AHT Orders?"
        type: combobox
      - label: "Implied Generation Applicable?"
        type: combobox
  - heading: "Price Supervision"
    fields:
      - label: "Static Price Limit Applicable?"
        type: combobox
      - label: "Dynamic Price Limit Applicable?"
        type: combobox
      - label: "VCM Applicable?"
        type: combobox
      - label: "VCM Start Offset"
        type: textbox
      - label: "VCM End Offset"
        type: textbox
---
