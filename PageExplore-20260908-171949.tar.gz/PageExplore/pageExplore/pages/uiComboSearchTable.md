---
label: "Maintain Combo"
route: "/UI/uiComboSearchTable"
cacheName: "comboPermCache"
pkField: "comboId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "comboId"
    headerName: "Combo ID"
  - field: "$D_comboClassId"
    headerName: "Combo Class ID"
  - field: "status"
    headerName: "Status"
  - field: "comboEffectiveDate"
    headerName: "Effective Date"
  - field: "$CG_isTailorMadeOnly"
    headerName: "Tailor Made Only?"
  - field: "firstTradingDate"
    headerName: "First Trading Date"
  - field: "firstTradingTime"
    headerName: "First Trading Time"
  - field: "lastTradingDate"
    headerName: "Last Trading Date"
  - field: "effectiveLastTradingDate"
    headerName: "Effective Last Trading Date"
  - field: "lastTradingTime"
    headerName: "Last Trading Time"
  - field: "numLegs"
    headerName: "Number of Legs"
  - field: "modifier"
    headerName: "Modifier"
booleanFields: []
codeFields: ["recordStatus", "status"]
sampleFields: ["comboId", "$D_comboClassId", "status", "lastTradingDate", "numLegs", "recordStatus"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Combo ID"
        type: combobox
      - label: "Combo Class ID"
        type: combobox
  - heading: "General"
    fields:
      - label: "Status"
        type: textbox
      - label: "Effective Status"
        type: textbox
      - label: "Effective Date"
        type: textbox
      - label: "Tailor Made Only?"
        type: combobox
  - heading: "First Date"
    fields:
      - label: "First Trading Date"
        type: textbox
      - label: "First Trading Time"
        type: textbox
  - heading: "Last Date"
    fields:
      - label: "Last Trading Date"
        type: textbox
      - label: "Effective Last Trading Date"
        type: textbox
      - label: "Last Trading Time"
        type: textbox
  - heading: "Modified Values"
    fields:
      - label: "Modifier"
        type: textbox
  - heading: "Combo Leg"
    fields:
      - label: "Number of Legs"
        type: textbox

---

