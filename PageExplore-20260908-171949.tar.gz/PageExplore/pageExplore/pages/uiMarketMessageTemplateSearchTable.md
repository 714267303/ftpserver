---
label: "Maintain Message Template"
route: "/UI/uiMarketMessageTemplateSearchTable"
cacheName: "marketMessageTemplatePermCache"
pkField: "msgTemplateId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "msgTemplateId"
    headerName: "Message Template ID"
  - field: "msgName"
    headerName: "Name"
  - field: "targetTriggeringEvent"
    headerName: "Target Triggering Event"
  - field: "msgPriority"
    headerName: "Message Priority"
  - field: "msgSubject"
    headerName: "Subject"
booleanFields: []
codeFields: []
sampleFields: ["requestStatus", "requestAction", "recordStatus", "msgTemplateId", "msgName"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Message Template ID"
        type: combobox
      - label: "Name"
        type: textbox
  - heading: "General"
    fields:
      - label: "Target Triggering Event"
        type: combobox
      - label: "Message Priority"
        type: textbox
      - label: "Subject"
        type: textbox
---
