---
label: "Maintain Automatic Event Message"
route: "/UI/uiAutomaticEventMessageSearchTable"
cacheName: "automaticEventMessagePermCache"
pkField: "autoEventMsgId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "autoEventMsgId"
    headerName: "Auto Event Message ID"
  - field: "msgName"
    headerName: "Name"
  - field: "triggeringEvent"
    headerName: "Triggering Event"
  - field: "templateMktData"
    headerName: "Template for Market Data Channel"
  - field: "templateGui"
    headerName: "Template for Trading GUI Channel"
  - field: "templateBinary"
    headerName: "Template for Binary Channel"
  - field: "templateEmail"
    headerName: "Template for Email Channel"
  - field: "email1"
    headerName: "Recipient for Email Channel 1"
  - field: "email2"
    headerName: "Recipient for Email Channel 2"
  - field: "email3"
    headerName: "Recipient for Email Channel 3"
  - field: "email4"
    headerName: "Recipient for Email Channel 4"
  - field: "email5"
    headerName: "Recipient for Email Channel 5"
booleanFields: []
codeFields: []
sampleFields: ["requestStatus", "requestAction", "recordStatus", "autoEventMsgId", "msgName"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Auto Event Message ID"
        type: combobox
      - label: "Name"
        type: textbox
  - heading: "General"
    fields:
      - label: "Triggering Event"
        type: combobox
  - heading: "Template"
    fields:
      - label: "Template for Market Data Channel"
        type: textbox
      - label: "Template for Trading GUI Channel"
        type: textbox
      - label: "Template for Binary Channel"
        type: textbox
      - label: "Template for Email Channel"
        type: textbox
  - heading: "Email Recipients"
    fields:
      - label: "Recipient for Email Channel 1"
        type: textbox
      - label: "Recipient for Email Channel 2"
        type: textbox
      - label: "Recipient for Email Channel 3"
        type: textbox
      - label: "Recipient for Email Channel 4"
        type: textbox
      - label: "Recipient for Email Channel 5"
        type: textbox
---
