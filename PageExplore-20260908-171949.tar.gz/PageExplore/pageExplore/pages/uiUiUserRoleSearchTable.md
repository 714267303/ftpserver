---
label: "Maintain UI User Role"
route: "/UI/uiUiUserRoleSearchTable"
cacheName: "uiUserRolePermCache"
pkField: "uiUserRoleId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "uiUserRoleId"
    headerName: "UI User Role ID"
  - field: "description"
    headerName: "Description"
  - field: "uiUserRoleType"
    headerName: "Role Type"
  - field: "$D_appId"
    headerName: "App ID"
  - field: "functionType"
    headerName: "Function Type"
  - field: "interfaceType"
    headerName: "Interface Type"
booleanFields: []
codeFields: []
sampleFields: ["requestStatus", "requestAction", "recordStatus", "uiUserRoleId", "description"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "UI User Role ID"
        type: combobox
      - label: "Description"
        type: textbox
      - label: "Role Type"
        type: combobox
      - label: "App ID"
        type: combobox
      - label: "Function Type"
        type: combobox
      - label: "Interface Type"
        type: combobox
---
