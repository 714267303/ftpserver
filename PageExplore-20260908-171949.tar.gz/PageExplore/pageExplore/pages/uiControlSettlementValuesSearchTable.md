---
label: "Control Settlement Values"
route: "/UI/uiControlSettlementValuesSearchTable"
cacheName: "controlSettlementValuesPermCache"
pkField: "instId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: ""
    headerName: ""
  - field: "instId"
    headerName: "Inst. ID"
  - field: "$IC_instClassId"
    headerName: "Inst. Class ID"
  - field: "dsp"
    headerName: "Daily Settlement Price"
  - field: "recvDsp"
    headerName: "Received DSP"
  - field: "decimalsInRecvDsp"
    headerName: "Decimal In Received DSP"
  - field: "dspUpdateType"
    headerName: "DSP Update Type"
  - field: "dspUpdateTime"
    headerName: "DSP Update Time"
  - field: "prevDsp"
    headerName: "Previous Daily Settlement Price"
  - field: "prevRecvDsp"
    headerName: "Previous Received DSP"
  - field: "decimalsInPrevRecvDsp"
    headerName: "Decimal In Previous Received DSP"
  - field: "prevDspUpdateType"
    headerName: "Previous DSP Update Type"
  - field: "prevDspUpdateTime"
    headerName: "Previous DSP Update Time"
  - field: "prevDspTradingDate"
    headerName: "Previous DSP Trading Date"
  booleanFields: []
codeFields: ["dspUpdateType", "prevDspUpdateType"]
sampleFields: ["instId", "dsp", "prevDsp", "dspUpdateType", "prevDspTradingDate"]
notes: "Very large dataset (50K+ rows); pageSize=9 (non-standard); avoid pagination, use Template 1 for filtering"
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Inst. ID"
        type: combobox
      - label: "Inst. Class ID"
        type: combobox
  - heading: "Current Settlement"
    fields:
      - label: "Daily Settlement Price"
        type: textbox
      - label: "Received DSP"
        type: textbox
      - label: "Decimal In Received DSP"
        type: textbox
      - label: "DSP Update Type"
        type: combobox
      - label: "DSP Update Time"
        type: textbox
  - heading: "Previous Settlement"
    fields:
      - label: "Previous Daily Settlement Price"
        type: textbox
      - label: "Previous Received DSP"
        type: textbox
      - label: "Decimal In Previous Received DSP"
        type: textbox
      - label: "Previous DSP Update Type"
        type: combobox
      - label: "Previous DSP Update Time"
        type: textbox
      - label: "Previous DSP Trading Date"
        type: textbox
---
