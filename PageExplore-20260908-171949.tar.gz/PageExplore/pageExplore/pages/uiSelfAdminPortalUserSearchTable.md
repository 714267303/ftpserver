---
label: "Maintain Self Admin Portal User"
route: "/UI/uiSelfAdminPortalUserSearchTable"
cacheName: "selfAdminPortalUserPermCache"
pkField: "userId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "userId"
    headerName: "User ID"
  - field: "idpUserId"
    headerName: "IDP User ID"
  - field: "$D_participantId"
    headerName: "Exchange Part. ID"
  - field: "isSuspended"
    headerName: "Suspended?"
  - field: "$D_browserIpAddrListId"
    headerName: "Legal Browser IP Address List ID"
  - field: "uiUserRoleId"
    headerName: "UI User Role ID"
booleanFields: []
codeFields: []
sampleFields: ["requestStatus", "requestAction", "recordStatus", "userId", "idpUserId"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "User ID"
        type: combobox
      - label: "IDP User ID"
        type: combobox
      - label: "Exchange Part. ID"
        type: combobox
      - label: "UI User Role ID"
        type: combobox
  - heading: "General"
    fields:
      - label: "Suspended?"
        type: combobox
      - label: "Legal Browser IP Address List ID"
        type: combobox
---
