---
label: "Maintain VCM Parameters"
route: "/UI/uiVcmParametersSearchTable"
cacheName: "vcmParametersPermCache"
pkField: "vcmParamId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "vcmParamId"
    headerName: "VCM Parameters ID"
  - field: "name"
    headerName: "Name"
  - field: "description"
    headerName: "Description"
  - field: "$PLR_limitDeviationUnit"
    headerName: "Limit Deviation Unit"
  - field: "delayTime"
    headerName: "Delay Time (second)"
  - field: "coolingOffInterval"
    headerName: "Cooling-Off Interval (second)"
  - field: "maxTriggers"
    headerName: "Max Triggers (Per Session)"
  - field: "isAutomaticVcmReenable"
    headerName: "Automatic VCM Re-enable?"
booleanFields: []
codeFields: []
sampleFields: ["requestStatus", "requestAction", "recordStatus", "vcmParamId", "name"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "VCM Parameters ID"
        type: combobox
      - label: "Name"
        type: textbox
      - label: "Description"
        type: textbox
  - heading: "Price"
    fields:
      - label: "Limit Deviation Unit"
        type: textbox
  - heading: "VCM"
    fields:
      - label: "Delay Time (second)"
        type: textbox
      - label: "Cooling-Off Interval (second)"
        type: textbox
      - label: "Max Triggers (Per Session)"
        type: textbox
      - label: "Automatic VCM Re-enable?"
        type: combobox
---
