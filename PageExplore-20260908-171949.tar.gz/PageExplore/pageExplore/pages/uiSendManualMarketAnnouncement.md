---
label: "Send Manual Market Announcement"
route: "/UI/uiSendManualMarketAnnouncement"
cacheName: "sendManualMarketAnnouncementPermCache"
pkField: ""
hasGrid: false
booleanFields: []
codeFields: []
sampleFields: []
profiled: true
---

