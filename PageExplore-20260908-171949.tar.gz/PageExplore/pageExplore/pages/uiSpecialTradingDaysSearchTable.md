---
label: "Maintain Special Trading Days"
route: "/UI/uiSpecialTradingDaysSearchTable"
cacheName: "specialTradingDaysPermCache"
pkField: "specialTradingDaysId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "specialTradingDaysId"
    headerName: "Special Trading Days ID"
  - field: "name"
    headerName: "Special Trading Days Name"
  - field: "description"
    headerName: "Description"
booleanFields: []
codeFields: []
sampleFields: ["requestStatus", "requestAction", "recordStatus", "specialTradingDaysId", "name"]
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Special Trading Days ID"
        type: combobox
      - label: "Special Trading Days Name"
        type: textbox
      - label: "Description"
        type: textbox
---
