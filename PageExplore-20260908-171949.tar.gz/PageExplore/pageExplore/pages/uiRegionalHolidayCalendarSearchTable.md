---
label: "Maintain Regional Holiday Calendar"
route: "/UI/uiRegionalHolidayCalendarSearchTable"
cacheName: "regionalHolidayCalendarPermCache"
pkField: "regCalId"
hasGrid: true
gridApi:
  apiName: "qaGridApi"
  keyPattern: "runtime-discovered; page-specific UUID key"
  discovery: "active page/container, never a hard-coded UUID"
  observationStatus: "inferred"
  sharedIndex: "../qaGrid/Grid_API_Core_Index.md"
  observationIndex: "../qaGrid/Admin_GUI/Grid_API_Observation_Index.md"
columns:
  - field: "requestStatus"
    headerName: "Req Status"
  - field: "requestAction"
    headerName: "Req Action"
  - field: "recordStatus"
    headerName: "Record Status"
  - field: "regCalId"
    headerName: "Regional Calendar ID"
  - field: "name"
    headerName: "Name"
  - field: "description"
    headerName: "Description"
booleanFields: []
codeFields: ["recordStatus"]
sampleFields: ["regCalId", "name", "description", "recordStatus"]
notes: "Small dataset (15 rows); simple schema with only basic fields"
profiled: true
details:
  - heading: "Identity"
    fields:
      - label: "Regional Calendar ID"
        type: combobox
      - label: "Name"
        type: textbox
      - label: "Description"
        type: textbox
---
