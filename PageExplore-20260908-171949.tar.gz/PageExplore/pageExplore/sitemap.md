# Orion Derivatives Platform (ODP) - Trading Admin Sitemap

**URL**: ${ODP_URL}  
**Platform**: ODP (Orion Derivatives Platform) by HKEX  
**Application**: Trading Admin  
**UI Framework**: React SPA with canvas-based qaGrid tables

---

## Login Procedure

1. Navigate to `${ODP_URL}ESUI/eventServerLanding.html` (redirects to `?login_mode=both`)
2. Click **"Login via WebAM"**
3. Fill in credentials:
   - **User ID**: `#loginid`
   - **Password**: `#loginpassword`
4. Click **Login** button (`button.login-Button`)
5. After success, you land at `${ODP_URL}UI`

### Credentials
| Field | Value |
|---|---|
| Username | ${ODP_USERNAME} |
| Password | ${ODP_PASSWORD} |

### SPA Navigation
Do NOT use `page.goto()` for protected pages — it triggers re-authentication. Instead use:
```js
window.history.pushState({}, '', '/UI/<routePath>');
window.dispatchEvent(new PopStateEvent('popstate'));
```

All `hasGrid: true` profiles inherit the shared [`qaGridApi` contract](qaGrid/Grid_API_Core_Index.md).
Observed page-specific keys and schemas are recorded in the Admin and Trading
observation indexes; a missing key pattern means runtime discovery is required.

---

## Sidebar Navigation Structure

The sidebar contains 18 main sections, each with sub-pages. All search pages have a qaGrid (canvas-based table accessible via `window.qaGridApi`).

---

### 1. Countersign

| # | Page Label | Route Path | Actions Available | Profile |
|---|---|---|---|---|
| 1 | Countersign Request | `/UI/uiAuthorizationRequestSearchTable` | Filter, Apply, More Actions, Reset Filters | [📄](pages/uiAuthorizationRequestSearchTable.md) |

### 2. Control & Monitoring

| # | Page Label | Route Path | Actions Available | Profile |
|---|---|---|---|---|
| 2 | Monitor Historical Order Book | `/UI/uiMonitorHistoricalOrderBookSearchTable` | Filter, Time range, Prev/Next Change/Tx | [📄](pages/uiMonitorHistoricalOrderBookSearchTable.md) |
| 3 | Monitor Quote Request | `/UI/uiMonitorQuoteRequestSearchTable` | Filter, Apply All, Reset All | [📄](pages/uiMonitorQuoteRequestSearchTable.md) |
| 4 | Control Settlement Values | `/UI/uiControlSettlementValuesSearchTable` | Filter, Cancel, Confirm | [📄](pages/uiControlSettlementValuesSearchTable.md) |
| 5 | Control Underlying Price | `/UI/uiControlUnderlyingPriceSearchTable` | Filter, Cancel, Confirm | [📄](pages/uiControlUnderlyingPriceSearchTable.md) |

### 3. Inst. Hierarchy (Instrument Hierarchy)

| # | Page Label | Route Path | Actions Available | Profile |
|---|---|---|---|---|
| 6 | Maintain Exchange | `/UI/uiExchangeSearchTable` | New/Clone Record, More Actions | [📄](pages/uiExchangeSearchTable.md) |
| 7 | Maintain Market | `/UI/uiMarketSearchTable` | New/Clone Record, More Actions | [📄](pages/uiMarketSearchTable.md) |
| 8 | Maintain Inst. Group | `/UI/uiInstGroupSearchTable` | New/Clone Record, More Actions | [📄](pages/uiInstGroupSearchTable.md) |
| 9 | Maintain Inst. Type | `/UI/uiInstTypeSearchTable` | New/Clone Record, More Actions | [📄](pages/uiInstTypeSearchTable.md) |
| 10 | Maintain Underlying | `/UI/uiUnderlyingSearchTable` | New/Clone Record, More Actions | [📄](pages/uiUnderlyingSearchTable.md) |
| 11 | Maintain Inst. Class | `/UI/uiInstClassSearchTable` | New/Clone Record, More Actions | [📄](pages/uiInstClassSearchTable.md) |
| 12 | Maintain Instrument | `/UI/uiInstrumentSearchTable` | New/Clone Record, More Actions | [📄](pages/uiInstrumentSearchTable.md) |
| 13 | Maintain Inst. Name Standard | `/UI/uiNameStdSearchTable` | New/Clone Record, More Actions | [📄](pages/uiNameStdSearchTable.md) |
| 14 | Maintain Access Group By Type | `/UI/uiAccessGroupByTypeSearchTable` | New/Clone Record, More Actions | [📄](pages/uiAccessGroupByTypeSearchTable.md) |

### 4. Combo Hierarchy

| # | Page Label | Route Path | Actions Available | Profile |
|---|---|---|---|---|
| 15 | Maintain Combo Group | `/UI/uiComboGroupSearchTable` | New/Clone Record, More Actions | [📄](pages/uiComboGroupSearchTable.md) |
| 16 | Maintain Combo Type | `/UI/uiComboTypeSearchTable` | New/Clone Record, More Actions | [📄](pages/uiComboTypeSearchTable.md) |
| 17 | Maintain Combo Class | `/UI/uiComboClassSearchTable` | New/Clone Record, More Actions | [📄](pages/uiComboClassSearchTable.md) |
| 18 | Maintain Combo | `/UI/uiComboSearchTable` | New/Clone Record, More Actions | [📄](pages/uiComboSearchTable.md) |
| 19 | Maintain Combo Name Standard | `/UI/uiComboNameStdSearchTable` | New/Clone Record, More Actions | [📄](pages/uiComboNameStdSearchTable.md) |

### 5. Auto Inst. Generation

| # | Page Label | Route Path | Actions Available | Profile |
|---|---|---|---|---|
| 20 | Maintain Auto Generation Rule | `/UI/uiAutoGenerationRuleSearchTable` | New/Clone Record, More Actions | [📄](pages/uiAutoGenerationRuleSearchTable.md) |
| 21 | Maintain Cycle Blocks | `/UI/uiCycleBlocksSearchTable` | New/Clone Record, More Actions | [📄](pages/uiCycleBlocksSearchTable.md) |
| 22 | Maintain Last Trading Date Formula | `/UI/uiLastTradingDateFormulaSearchTable` | New/Clone Record, More Actions | [📄](pages/uiLastTradingDateFormulaSearchTable.md) |
| 23 | Maintain Regional Holiday Calendar | `/UI/uiRegionalHolidayCalendarSearchTable` | New/Clone Record, More Actions | [📄](pages/uiRegionalHolidayCalendarSearchTable.md) |
| 24 | Maintain Last Trading Date Calendar | `/UI/uiLastTradingDateCalendarSearchTable` | New/Clone Record, More Actions | [📄](pages/uiLastTradingDateCalendarSearchTable.md) |
| 25 | Maintain Lifecycle Time Rule | `/UI/uiLifecycleTimeRuleSearchTable` | New/Clone Record, More Actions | [📄](pages/uiLifecycleTimeRuleSearchTable.md) |
| 26 | Maintain Last Trading Time DST Adjustment | `/UI/uiLastTradingTimeDstAdjustmentSearchTable` | New/Clone Record, More Actions | [📄](pages/uiLastTradingTimeDstAdjustmentSearchTable.md) |
| 27 | Maintain Strike Price Range | `/UI/uiStrikePriceRangeSearchTable` | New/Clone Record, More Actions | [📄](pages/uiStrikePriceRangeSearchTable.md) |
| 28 | Maintain Strike Price Table | `/UI/uiStrikePriceTableSearchTable` | New/Clone Record, More Actions | [📄](pages/uiStrikePriceTableSearchTable.md) |
| 29 | Maintain Strike Price Reference | `/UI/uiStrikePriceReferenceSearchTable` | New/Clone Record, More Actions | [📄](pages/uiStrikePriceReferenceSearchTable.md) |
| 30 | Regional Calendar Upload | `/UI/uiRegionalCalendarUploadSearchTable` | New/Clone Record, Upload form | [📄](pages/uiRegionalCalendarUploadSearchTable.md) |
| 31 | Instrument Generation | `/UI/uiInstrumentGeneration` | Action form (no grid) | [📄](pages/uiInstrumentGeneration.md) |

### 6. Auto Combo Generation

| # | Page Label | Route Path | Actions Available | Profile |
|---|---|---|---|---|
| 32 | Maintain Auto Combo Generation Rule Group | `/UI/uiAutoComboGenerationRuleGroupSearchTable` | New/Clone Record, More Actions | [📄](pages/uiAutoComboGenerationRuleGroupSearchTable.md) |
| 33 | Combo Generation | `/UI/uiComboGeneration` | Action form (no grid) | [📄](pages/uiComboGeneration.md) |

### 7. Timetable

| # | Page Label | Route Path | Actions Available | Profile |
|---|---|---|---|---|
| 34 | Maintain Trading Timetable | `/UI/uiTradingTimetableSearchTable` | New/Clone Record, More Actions | [📄](pages/uiTradingTimetableSearchTable.md) |
| 35 | Maintain Trading State | `/UI/uiTradingStateSearchTable` | New/Clone Record, More Actions | [📄](pages/uiTradingStateSearchTable.md) |
| 36 | Maintain Non-Trading Days | `/UI/uiNonTradingDaysSearchTable` | New/Clone Record, More Actions | [📄](pages/uiNonTradingDaysSearchTable.md) |
| 37 | Maintain Special Trading Days | `/UI/uiSpecialTradingDaysSearchTable` | New/Clone Record, More Actions | [📄](pages/uiSpecialTradingDaysSearchTable.md) |
| 38 | Control Trading Timetable | `/UI/uiControlTradingTimetableSearchTable` | Control actions | [📄](pages/uiControlTradingTimetableSearchTable.md) |

### 8. Participant

| # | Page Label | Route Path | Actions Available | Profile |
|---|---|---|---|---|
| 39 | Maintain Company | `/UI/uiCompanySearchTable` | New/Clone Record, More Actions | [📄](pages/uiCompanySearchTable.md) |
| 40 | Maintain Exchange Participant | `/UI/uiExchangeParticipantSearchTable` | New/Clone Record, More Actions | [📄](pages/uiExchangeParticipantSearchTable.md) |
| 41 | Maintain Drop Copy Group | `/UI/uiDropCopyGroupSearchTable` | New/Clone Record | [📄](pages/uiDropCopyGroupSearchTable.md) |
| 42 | Maintain Direct Drop Copy Session | `/UI/uiDirectDropCopySessionSearchTable` | New/Clone Record | [📄](pages/uiDirectDropCopySessionSearchTable.md) |
| 43 | Maintain Direct Order Flow Session | `/UI/uiDirectOrderFlowSessionSearchTable` | New/Clone Record | [📄](pages/uiDirectOrderFlowSessionSearchTable.md) |
| 44 | Maintain Legal IP Address | `/UI/uiLegalIPAddressSearchTable` | New/Clone Record | [📄](pages/uiLegalIPAddressSearchTable.md) |
| 45 | Maintain PTRM GUI User | `/UI/uiPtrmGuiUserSearchTable` | New/Clone Record | [📄](pages/uiPtrmGuiUserSearchTable.md) |
| 46 | Maintain Trading GUI User | `/UI/uiTradingGuiUserSearchTable` | New/Clone Record | [📄](pages/uiTradingGuiUserSearchTable.md) |
| 47 | Maintain Sponsoring Participant | `/UI/uiSponsoringParticipantSearchTable` | New/Clone Record | [📄](pages/uiSponsoringParticipantSearchTable.md) |
| 48 | Maintain Trading Rights | `/UI/uiTradingRightSearchTable` | New/Clone Record | [📄](pages/uiTradingRightSearchTable.md) |
| 49 | Maintain Participant User Role | `/UI/uiParticipantUserRoleSearchTable` | New/Clone Record | [📄](pages/uiParticipantUserRoleSearchTable.md) |
| 50 | Maintain SMP ID List | `/UI/uiSmpIdListSearchTable` | New/Clone Record | [📄](pages/uiSmpIdListSearchTable.md) |
| 51 | Maintain MMP Parameter | `/UI/uiMmpParameterSearchTable` | New/Clone Record | [📄](pages/uiMmpParameterSearchTable.md) |
| 52 | Control Block/Unblock Participant Per Product | `/UI/uiControlBlockUnblockParticipantPerProductSearchTable` | Control actions | [📄](pages/uiControlBlockUnblockParticipantPerProductSearchTable.md) |
| 53 | Maintain Self Admin Portal User | `/UI/uiSelfAdminPortalUserSearchTable` | New/Clone Record | [📄](pages/uiSelfAdminPortalUserSearchTable.md) |
| 54 | Request External IDP User | `/UI/uiRequestExternalEidpUser` | Action form (no grid) | [📄](pages/uiRequestExternalEidpUser.md) |

### 9. Price Supervision

| # | Page Label | Route Path | Actions Available | Profile |
|---|---|---|---|---|
| 55 | Maintain Price Tick | `/UI/uiPriceTickSearchTable` | New/Clone Record | [📄](pages/uiPriceTickSearchTable.md) |
| 56 | Maintain Price Tick Limit Rule | `/UI/uiPriceTickLimitSearchTable` | New/Clone Record | [📄](pages/uiPriceTickLimitSearchTable.md) |
| 57 | Maintain Inst. Class Price Tick Limit | `/UI/uiInstClassPriceTickLimitSearchTable` | New/Clone Record | [📄](pages/uiInstClassPriceTickLimitSearchTable.md) |
| 58 | Maintain Combo Class Price Tick Limit | `/UI/uiComboClassPriceTickLimitSearchTable` | New/Clone Record | [📄](pages/uiComboClassPriceTickLimitSearchTable.md) |
| 59 | Maintain Price Limit | `/UI/uiPriceLimitSearchTable` | New/Clone Record | [📄](pages/uiPriceLimitSearchTable.md) |
| 60 | Maintain Price Limit Parameters | `/UI/uiPriceLimitParametersSearchTable` | New/Clone Record | [📄](pages/uiPriceLimitParametersSearchTable.md) |
| 61 | Maintain Reference Price Source | `/UI/uiReferencePriceSourceSearchTable` | New/Clone Record | [📄](pages/uiReferencePriceSourceSearchTable.md) |
| 62 | Maintain Reference Price Calculation Rule | `/UI/uiReferencePriceCalculationRuleSearchTable` | New/Clone Record | [📄](pages/uiReferencePriceCalculationRuleSearchTable.md) |
| 63 | Maintain VCM | `/UI/uiVcmSearchTable` | New/Clone Record | [📄](pages/uiVcmSearchTable.md) |
| 64 | Maintain VCM Parameters | `/UI/uiVcmParametersSearchTable` | New/Clone Record | [📄](pages/uiVcmParametersSearchTable.md) |
| 65 | Maintain Futures Group | `/UI/uiFuturesGroupSearchTable` | New/Clone Record | [📄](pages/uiFuturesGroupSearchTable.md) |
| 66 | Control & Monitor Price Limit | `/UI/uiControlMonitorPriceLimitSearchTable` | Control actions | [📄](pages/uiControlMonitorPriceLimitSearchTable.md) |
| 67 | Control & Monitor VCM | `/UI/uiControlMonitorVCMSearchTable` | Control actions | [📄](pages/uiControlMonitorVCMSearchTable.md) |
| 68 | Control & Monitor Instrument Trading Halt | `/UI/uiControlMonitorInstrumentTradingHaltSearchTable` | Control actions | [📄](pages/uiControlMonitorInstrumentTradingHaltSearchTable.md) |
| 69 | Control Contingency Trigger of Inst. Class Price Tick Limit | `/UI/uiControlContingencyTriggerOfPriceTickLimitCalculationSearchTable` | Control actions | [📄](pages/uiControlContingencyTriggerOfPriceTickLimitCalculationSearchTable.md) |
| 70 | Control Contingency Trigger of Combo Class Price Tick Limit | `/UI/uiControlContingencyTriggerOfComboClassPriceTickLimitCalculationSearchTable` | Control actions | [📄](pages/uiControlContingencyTriggerOfComboClassPriceTickLimitCalculationSearchTable.md) |
| 71 | Control Contingency Trigger of AHT Reference Price | `/UI/uiControlContingencyTriggerOfAhtReferencePriceCalculationSearchTable` | Control actions | [📄](pages/uiControlContingencyTriggerOfAhtReferencePriceCalculationSearchTable.md) |

### 10. SMP (Special Market Participant)

| # | Page Label | Route Path | Actions Available | Profile |
|---|---|---|---|---|
| 72 | Maintain SMP ID | `/UI/uiSmpIdSearchTable` | New/Clone Record | [📄](pages/uiSmpIdSearchTable.md) |
| 73 | Review SMP Request | `/UI/uiReviewSmpRequestSearchTable` | Review actions | [📄](pages/uiReviewSmpRequestSearchTable.md) |

### 11. TMC (Trade Monitoring & Control)

| # | Page Label | Route Path | Actions Available | Profile |
|---|---|---|---|---|
| 74 | Maintain TMC Strategy List | `/UI/uiTmcStrategyListSearchTable` | New/Clone Record | [📄](pages/uiTmcStrategyListSearchTable.md) |
| 75 | Maintain TMC Strategy | `/UI/uiTmcStrategySearchTable` | New/Clone Record | [📄](pages/uiTmcStrategySearchTable.md) |
| 76 | Control TMC | `/UI/uiControlTmcSearchTable` | Control actions | [📄](pages/uiControlTmcSearchTable.md) |

### 12. System

| # | Page Label | Route Path | Actions Available | Profile |
|---|---|---|---|---|
| 77 | Maintain Global Parameters | `/UI/uiGlobalParametersSearchTable` | Edit | [📄](pages/uiGlobalParametersSearchTable.md) |
| 78 | Maintain Contingency Switch | `/UI/uiContingencySwitchSearchTable` | Edit | [📄](pages/uiContingencySwitchSearchTable.md) |
| 79 | View Password Policy | `/UI/uiPasswordPolicySearchTable` | View only | [📄](pages/uiPasswordPolicySearchTable.md) |
| 80 | Bulk Import | `/UI/uiBulkImport` | Upload form (no grid) | [📄](pages/uiBulkImport.md) |

### 13. User Maintenance

| # | Page Label | Route Path | Actions Available | Profile |
|---|---|---|---|---|
| 81 | Maintain Exchange User | `/UI/uiExchangeUserSearchTable` | New/Clone Record | [📄](pages/uiExchangeUserSearchTable.md) |
| 82 | Maintain UI User Role | `/UI/uiUiUserRoleSearchTable` | New/Clone Record | [📄](pages/uiUiUserRoleSearchTable.md) |
| 83 | Maintain System Preference | `/UI/uiSystemPreferenceSearchTable` | New/Clone Record | [📄](pages/uiSystemPreferenceSearchTable.md) |
| 84 | Request Internal IDP User | `/UI/uiRequestInternalEidpUser` | Action form (no grid) | [📄](pages/uiRequestInternalEidpUser.md) |

### 14. Block Trade

| # | Page Label | Route Path | Actions Available | Profile |
|---|---|---|---|---|
| 85 | Maintain Block Trade Group | `/UI/uiBlockTradeGroupSearchTable` | New/Clone Record | [📄](pages/uiBlockTradeGroupSearchTable.md) |
| 86 | Maintain Block Trade MVT | `/UI/uiBlockTradeMvtSearchTable` | New/Clone Record | [📄](pages/uiBlockTradeMvtSearchTable.md) |

### 15. Error Trade

| # | Page Label | Route Path | Actions Available | Profile |
|---|---|---|---|---|
| 87 | Maintain Combo Type Error Trade Parameters | `/UI/uiComboTypeErrTradeParamSearchTable` | New/Clone Record | [📄](pages/uiComboTypeErrTradeParamSearchTable.md) |
| 88 | Maintain Inst. Type Error Trade Parameters | `/UI/uiInstTypeErrTradeParamSearchTable` | New/Clone Record | [📄](pages/uiInstTypeErrTradeParamSearchTable.md) |

### 16. Report Generation And Processing

| # | Page Label | Route Path | Actions Available | Profile |
|---|---|---|---|---|
| 89 | Maintain Report | `/UI/uiReportSearchTable` | New/Clone Record | [📄](pages/uiReportSearchTable.md) |
| 90 | Maintain Report Group List | `/UI/uiReportGroupListSearchTable` | New/Clone Record | [📄](pages/uiReportGroupListSearchTable.md) |
| 91 | Control Daily Market Report (DMR) | `/UI/uiControlDailyMarketReportSearchTable` | Control actions | [📄](pages/uiControlDailyMarketReportSearchTable.md) |

### 17. Market Messages

| # | Page Label | Route Path | Actions Available | Profile |
|---|---|---|---|---|
| 92 | Maintain Message Template | `/UI/uiMarketMessageTemplateSearchTable` | New/Clone Record | [📄](pages/uiMarketMessageTemplateSearchTable.md) |
| 93 | Maintain Automatic Event Message | `/UI/uiAutomaticEventMessageSearchTable` | New/Clone Record | [📄](pages/uiAutomaticEventMessageSearchTable.md) |
| 94 | Send Manual Market Announcement | `/UI/uiSendManualMarketAnnouncement` | Action form (no grid) | [📄](pages/uiSendManualMarketAnnouncement.md) |

### 18. Capital Adjustment

| # | Page Label | Route Path | Actions Available | Profile |
|---|---|---|---|---|
| 95 | Control Capital Adjustment | `/UI/uiCapitalAdjustmentSearchTable` | Control actions | [📄](pages/uiCapitalAdjustmentSearchTable.md) |

### 19. More

| # | Page Label | Route Path | Actions Available | Profile |
|---|---|---|---|---|
| 96 | About | `/UI/about` | Version info page (no grid) | [📄](pages/about.md) |

---

## API Endpoints

| Method | URL | Purpose |
|---|---|---|
| POST | `${ODP_URL}vs02/api/private/loadData` | Load table data |
| POST | `${ODP_URL}es/api/private/getSessionUserProfile` | Get user profile |
| POST | `${ODP_URL}vs01/api/private/loadSystemPreference` | System preferences |
| POST | `${ODP_URL}vs01/api/private/loadUserPreference` | User preferences |
| POST | `${ODP_URL}AM/public/api/v1/login` | OAuth login with PKCE |

---

## qaGrid API Reference

The shared method and safety contract is maintained in
[`qaGrid/Grid_API_Core_Index.md`](qaGrid/Grid_API_Core_Index.md).
For Admin detail evidence see
[`qaGrid/Admin_GUI/Grid_API_Observation_Index.md`](qaGrid/Admin_GUI/Grid_API_Observation_Index.md);
for Trading captures see
[`qaGrid/Trading_GUI/Grid_API_Observation_Index.md`](qaGrid/Trading_GUI/Grid_API_Observation_Index.md).

Tables use a canvas-based qaGrid. Access via:

```js
// Set this from the selected page profile when the page has multiple Grids.
const gridKeyPattern = null; // e.g. /^smpIdListDetailDialog_[0-9a-f-]+_subDetailTable1$/i
const gridKeys = Object.getOwnPropertyNames(window.qaGridApi)
  .filter(key => !gridKeyPattern || gridKeyPattern.test(key));
if (gridKeys.length !== 1) {
  throw new Error(`Expected one active Grid, found ${gridKeys.length}`);
}
const gridKey = gridKeys[0];
const grid = window.qaGridApi[gridKey];
```

### Read Methods
| Method | Returns |
|---|---|
| `getRowData()` | Array of row objects (current page only) |
| `getRowCount()` | Total row count |
| `getColumnDefs()` | Column definitions |
| `getOriginalColumnDefs()` | Original column definitions |
| `getFilteredColumnDefs()` | Filtered column definitions |
| `getPageModel()` | `{ currentPage, maxPage, pageSize, previousPage }` |
| `getSelectedRows()` / `getRawSelectedRows()` | Selected row data |
| `getSortModel()` | Sort model |
| `getFilterModel()` / `getAppliedFilterModel()` | Filter state |
| `getVisibleRowData()` / `getVisibleRowNum()` | Visible rows |
| `getFormattedValue(rowIndex, colField)` | Cell value |
| `getVisibleFormattedValueByIndex(rowIndex)` | All formatted values for a visible row |

### Write Methods
| Method | Description |
|---|---|
| `setRowData(data)` | Set row data |
| `setColumnDefs(defs)` | Set column definitions |
| `setSelected(rowIndex, boolean)` | Select/deselect row |
| `setSelectedRows(rowIndices)` | Select multiple rows |
| `addRow(data)` | Add a new row |
| `updateRowByIndex(index, data)` | Update a row |
| `deleteRowsByIndex(indices)` | Delete rows |
| `setPageModel({ currentPage, pageSize })` | Change page |
| `setSortModel(model)` | Set sort model |
| `resetFilterModel()` / `resetFilterIcons()` | Reset filters |
| `scrollToRowIndex(index)` / `scrollToBottom()` | Scroll |
| `setReadOnly(boolean)` | Toggle read-only |
| `setFlashing(rows, color)` / `setRowFlashing(rowIndex, color)` / `setCellFlashing(rowIndex, colField, color)` | Visual feedback |
| `removeFlashing()` | Remove all flashing |
| `addCustomFormat(field, formatFn)` | Custom cell formatting |
| `redraw()` | Force redraw grid |

---

## Page Header Elements (All Pages)

- **Theme Toggle**: "Theme: Light" button
- **Font Size**: "Font Size: Large" button
- **User**: "Logged in as dt1"
- **Account Settings**: Button with gear icon (top-right)
- **Footer**: Privacy Notice | Disclaimer | Help | Copyright HKEX

---

## Page Types

1. **SearchTable pages** — Most pages (have qaGrid with filter/search, "Apply", "Reset Filters" buttons)
2. **Maintain pages** — SearchTable + "New Record", "Clone Record" buttons for CRUD operations
3. **Control pages** — SearchTable + action buttons like "Cancel", "Confirm", control-specific actions
4. **Monitor pages** — SearchTable with time range filters and event tracking
5. **Action forms** — No qaGrid (Instrument Generation, Combo Generation, Bulk Import, Request User, Send Announcement, About)
6. **Upload pages** — Regional Calendar Upload, Bulk Import (file upload forms)

---
