# Selenium Request Interception Solution

## Problem

Playwright's `page.route()` for request interception has **no equivalent in Selenium**. When you need to inject filters into the `subscribeView` API (e.g., filtering by a column not exposed in the UI), you must use an **in-browser JavaScript override** of `XMLHttpRequest` and `fetch`.

This approach works in **Selenium, Cypress, Puppeteer, and any tool** that supports `execute_script()` / `page.evaluate()`.

---

## How It Works

```
┌─────────────────────────────────────────────────────────────────┐
│                     Browser Context                             │
│                                                                 │
│  1. Override XMLHttpRequest & fetch (execute_script)            │
│     │                                                          │
│     ▼                                                          │
│  2. Page calls subscribeView via XHR/fetch                     │
│     │                                                          │
│     ┌──────────────────────────┐                               │
│     │   Our XHR Override       │                               │
│     │   - Catches URL          │                               │
│     │   - Parses JSON body     │                               │
│     │   - Checks cacheName     │                               │
│     │   - Injects filter       │                               │
│     │   - Forwards request     │                               │
│     └───────────┬──────────────┘                               │
│                 │                                              │
│                 ▼                                              │
│  3. Server receives modified request with filter               │
│     │                                                          │
│     ▼                                                          │
│  4. Server returns filtered data via WebSocket/SSE push        │
│     │                                                          │
│     ▼                                                          │
│  5. Read results from window.qaGridApi (execute_script)        │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## Complete Python Code

```python
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

driver = webdriver.Chrome()

# ============================================
# Login (adjust to your actual login flow)
# ============================================
driver.get("${ODP_URL}ESUI/eventServerLanding.html")
WebDriverWait(driver, 10).until(
    EC.element_to_be_clickable((By.LINK_TEXT, "Login via WebAM"))
).click()
time.sleep(1)

# Dismiss cookie banner if present
try:
    close_btn = driver.find_element(By.XPATH, '//button[contains(text(), "Close")]')
    close_btn.click()
except:
    pass

# Fill credentials
driver.find_element(By.ID, "loginid").send_keys("${ODP_USERNAME}")
driver.find_element(By.ID, "loginpassword").send_keys("${ODP_PASSWORD}")
driver.find_element(By.CSS_SELECTOR, "button.login-Button").click()
WebDriverWait(driver, 10).until(
    lambda d: "UI" in d.current_url
)

# ============================================
# Navigate to target page
# ============================================
driver.get("${ODP_URL}UI/uiInstClassSearchTable")
time.sleep(4)  # Wait for qaGrid to load

# ============================================
# Step 1: Inject XHR/fetch override
# ============================================
driver.execute_script("""
(function() {
    // --- Override XMLHttpRequest ---
    var OriginalXHR = window.XMLHttpRequest;
    window.XMLHttpRequest = function() {
        var xhr = new OriginalXHR();

        // Intercept open() to capture the URL
        var originalOpen = xhr.open;
        xhr.open = function(method, url) {
            this._url = url;
            return originalOpen.apply(this, arguments);
        };

        // Intercept send() to modify the request body
        var originalSend = xhr.send;
        xhr.send = function(body) {
            if (this._url && this._url.indexOf('subscribeView') !== -1) {
                try {
                    var data = JSON.parse(body);
                    // === CHANGE THIS cacheName per page ===
                    if (data.cacheName === 'instClassPermCache') {
                        if (!data.filterBy) data.filterBy = {};
                        data.filterBy.isAutoGeneration = 'Y';
                        body = JSON.stringify(data);
                    }
                } catch(e) {}
            }
            return originalSend.call(this, body);
        };

        return xhr;
    };

    // --- Also override fetch() as fallback ---
    var originalFetch = window.fetch;
    window.fetch = function(url, options) {
        if (url.indexOf('subscribeView') !== -1 && options && options.body) {
            try {
                var data = JSON.parse(options.body);
                if (data.cacheName === 'instClassPermCache') {
                    if (!data.filterBy) data.filterBy = {};
                    data.filterBy.isAutoGeneration = 'Y';
                    options.body = JSON.stringify(data);
                }
            } catch(e) {}
        }
        return originalFetch.apply(this, arguments);
    };
})();
""")

# ============================================
# Step 2: Trigger filtered data reload
# ============================================
apply_btn = driver.find_element(By.XPATH, '//button[contains(text(), "Apply")]')
apply_btn.click()
time.sleep(3)  # Wait for server response (WebSocket/SSE push)

# ============================================
# Step 3: Read results from qaGridApi
# ============================================
result = driver.execute_script("""
var gk = Object.getOwnPropertyNames(window.qaGridApi)[0];
var g = window.qaGridApi[gk];
var rows = g.getRowData().filter(function(r) {
    return r !== null && r !== undefined;
});
return {
    rowCount: g.getRowCount(),
    pageModel: g.getPageModel(),
    rows: rows.map(function(r) {
        return {
            instClassId: r.instClassId,
            description: r.description,
            isAutoGeneration: r.isAutoGeneration,
            autoInstGenRuleId: r.autoInstGenRuleId,
            instTypeId: r.$D_instTypeId,
            underlyingId: r.$D_underlyingId,
            isTraded: r.isTraded,
            recordStatus: r.recordStatus,
        };
    })
};
""")

# Print results
print(f"Total rows after filter: {result['rowCount']}")
for row in result['rows']:
    print(f"  {row['instClassId']} | {row['description']} | "
          f"Rule: {row['autoInstGenRuleId']} | "
          f"Type: {row['instTypeId']}")

driver.quit()
```

**Output:**
```
Total rows after filter: 3
  HSICALL | HSI - CALL OPTIONS | Rule: 13 | Type: HSIC
  HSIFUT  | HSI - FUTURES      | Rule: 12 | Type: HSIF
  HSIPUT  | HSI - PUT OPTIONS  | Rule: 14 | Type: HSIP
```

---

## Adapting for Other Pages

To use this on a **different page** with a **different filter**, change two things in the XHR override:

| To Change | Where | Example |
|---|---|---|
| `cacheName` | XHR override | `instrumentPermCache`, `autoGenerationRulePermCache`, etc. |
| `filterBy` field | XHR override | `data.filterBy.unit = 'M'` |
| `filterBy` value | XHR override | `"Y"` / `"N"` / `"E"` / `"D"` / string value |

### Cache Name Reference

| Page | Route Path | cacheName |
|---|---|---|
| Inst. Class | `/UI/uiInstClassSearchTable` | `instClassPermCache` |
| Instrument | `/UI/uiInstrumentSearchTable` | `instrumentPermCache` |
| Market | `/UI/uiMarketSearchTable` | `marketPermCache` |
| Exchange | `/UI/uiExchangeSearchTable` | `exchangePermCache` |
| Inst. Type | `/UI/uiInstTypeSearchTable` | `instTypePermCache` |
| Underlying | `/UI/uiUnderlyingSearchTable` | `underlyingPermCache` |
| Inst. Group | `/UI/uiInstGroupSearchTable` | `instGroupPermCache` |
| Company | `/UI/uiCompanySearchTable` | `companyPermCache` |
| Exchange Participant | `/UI/uiExchangeParticipantSearchTable` | `exchangeParticipantPermCache` |
| Combo Group | `/UI/uiComboGroupSearchTable` | `comboGroupPermCache` |
| Combo Type | `/UI/uiComboTypeSearchTable` | `comboTypePermCache` |
| Combo Class | `/UI/uiComboClassSearchTable` | `comboClassPermCache` |
| Combo | `/UI/uiComboSearchTable` | `comboPermCache` |
| Auto Generation Rule | `/UI/uiAutoGenerationRuleSearchTable` | `autoGenerationRulePermCache` |
| Cycle Blocks | `/UI/uiCycleBlocksSearchTable` | `cycleBlocksPermCache` |
| Last Trading Date Formula | `/UI/uiLastTradingDateFormulaSearchTable` | `lastTradingDateFormulaPermCache` |
| Regional Holiday Calendar | `/UI/uiRegionalHolidayCalendarSearchTable` | `regionalHolidayCalendarPermCache` |
| Strike Price Range | `/UI/uiStrikePriceRangeSearchTable` | `strikePriceRangePermCache` |
| Auto Combo Generation Rule Group | `/UI/uiAutoComboGenerationRuleGroupSearchTable` | `autoComboGenerationRuleGroupPermCache` |

**Pattern:** strip `ui` prefix and `SearchTable` suffix from route, lowercase first letter, append `PermCache`.

Example: `/UI/uiAutoGenerationRuleSearchTable` → `autoGenerationRulePermCache`

### Filter Value Reference

| Column Type | Use | Example |
|---|---|---|
| Boolean (ends with `?`) | `"Y"` or `"N"` | `isTraded: "Y"` |
| Record Status | `"E"` (Active) / `"D"` (Deleted) | `recordStatus: "E"` |
| Unit (frequency) | `"D"` (Daily), `"W"` (Weekly), `"M"` (Monthly) | `unit: "M"` |
| Type | `"O"` (Option), `"U"` (Future) | `type: "O"` |
| String (dropdown) | Display value | `currencyCode: "HKD"` |
| String (free text) | Exact match or `*` wildcard | `description: "HSI*"` |

### Multi-Filter Example

```javascript
data.filterBy.isAutoGeneration = 'Y';
data.filterBy.isTraded = 'Y';
data.filterBy.recordStatus = 'E';
```

---

## Example: List Monthly Auto Generation Rules (Selenium)

```python
driver.get("${ODP_URL}UI/uiAutoGenerationRuleSearchTable")
time.sleep(4)

# Inject override for autoGenerationRulePermCache
driver.execute_script("""
(function() {
    var OriginalXHR = window.XMLHttpRequest;
    window.XMLHttpRequest = function() {
        var xhr = new OriginalXHR();
        var originalOpen = xhr.open;
        xhr.open = function(method, url) {
            this._url = url;
            return originalOpen.apply(this, arguments);
        };
        var originalSend = xhr.send;
        xhr.send = function(body) {
            if (this._url && this._url.indexOf('subscribeView') !== -1) {
                try {
                    var data = JSON.parse(body);
                    if (data.cacheName === 'autoGenerationRulePermCache') {
                        if (!data.filterBy) data.filterBy = {};
                        data.filterBy.unit = 'M';
                        body = JSON.stringify(data);
                    }
                } catch(e) {}
            }
            return originalSend.call(this, body);
        };
        return xhr;
    };
})();
""")

apply_btn = driver.find_element(By.XPATH, '//button[contains(text(), "Apply")]')
apply_btn.click()
time.sleep(3)

result = driver.execute_script("""
var gk = Object.getOwnPropertyNames(window.qaGridApi)[0];
var g = window.qaGridApi[gk];
var rows = g.getRowData().filter(function(r) {
    return r !== null && r !== undefined;
});
return {
    rowCount: g.getRowCount(),
    rows: rows.map(function(r) {
        return {
            ruleId: r.autoInstGenRuleId,
            description: r.description,
            unit: r.unit,
            type: r.type,
            cycleBlocksId: r.$D_cycleBlocksId,
            ltdFormulaId: r.$D_ltdFormulaId,
            lifecycleTimeRuleId: r.$D_lifecycleTimeRuleId,
            strikePriceGroup: r.strikePriceGroup,
        };
    })
};
""")

print(f"Monthly rules count: {result['rowCount']}")
for row in result['rows']:
    print(f"  {row['ruleId']:>2} | {row['description']:>10} | "
          f"{row['type']} | {row['cycleBlocksId']}")
```

**Output:**
```
Monthly rules count: 16
    7 |     ZJAPUT | O | 205 - ZJA_OPT
    8 |    ZJACALL | O | 205 - ZJA_OPT
    9 |    ZAOCALL | O | 204 - ZAO_OPT
   10 |     ZAOPUT | O | 204 - ZAO_OPT
   11 |     ZAOFUT | U | 102 - STOCK_FUT
   12 |     HSIFUT | U | 101 - HSI/HHI/HBI
   13 |    HSICALL | O | 202 - HSI_OPT
   14 |     HSIPUT | O | 202 - HSI_OPT
   15 |    HKBCALL | O | 201 - HKB_OPT
   16 |     HKBPUT | O | 201 - HKB_OPT
   17 |     HKBFUT | U | 102 - STOCK_FUT
   18 |    TCHCALL | O | 203 - TCH_OPT
   19 |     TCHPUT | O | 203 - TCH_OPT
   20 |     TCHFUT | U | 102 - STOCK_FUT
   26 |    MHICALL | O | 209 - MINI_HSI
   27 |     MHIPUT | O | 209 - MINI_HSI
```

---

## Important Notes

1. **Override must be injected BEFORE clicking Apply.** The override only affects requests made after injection. If you inject after clicking, the original request already went out.

2. **Click Apply is mandatory.** The page doesn't re-send `subscribeView` on its own. Clicking "Apply" (or any action that triggers a data reload) is what fires the request through your override.

3. **Wait for server response.** After clicking Apply, wait at least 3 seconds for the WebSocket/SSE push to deliver data back to the grid.

4. **The override persists for the page session.** If you need to query without the filter, either:
   - Navigate to a different page and back
   - Re-inject the original `window.XMLHttpRequest`
   - Use a different browser tab

5. **Server-side filter support is not guaranteed.** The server may silently ignore unknown filter fields. If `rowCount` is unchanged and all rows violate the filter, that field isn't server-filterable — fall back to client-side filtering via `qaGridApi` pagination.

6. **`getRowData()` returns a sparse array.** Always filter out `null` and `undefined` entries:
   ```javascript
   g.getRowData().filter(function(r) { return r !== null && r !== undefined; });
   ```

---

## Comparison: Playwright vs Selenium

| Aspect | Playwright | Selenium |
|---|---|---|
| Request interception | `page.route()` (CDP-level) | `execute_script()` (XHR/fetch override) |
| Reliability | May miss WebSocket/SSE push | Same — both intercept the initial handshake |
| Cleanup | `page.unroute()` | Navigate away or restore original |
| SPA navigation | `page.evaluate(pushState)` | `execute_script(pushState)` |
| Read grid data | `page.evaluate(qaGridApi)` | `execute_script(qaGridApi)` |
| Click elements | `locator.click()` | `find_element().click()` |

The core logic (qaGridApi, cacheName, filter syntax) is **identical** in both. Only the interception mechanism differs.

