# qaGrid Operation Guide

All search/maintain pages on this SPA use a canvas-based grid (qaGrid) backed by the same `subscribeView` API.
This guide covers filtering, pagination, and opening row detail pages.

## Background: How Grid Filtering Works

The qaGrid uses `subscribeView` for data — an HTTP handshake that upgrades to a WebSocket/SSE push channel.
The grid has **no `setFilterModel` method** (only getters), and the UI only exposes 3 quick-search fields.
Key implications for filtering:

1. **`page.route()` works for filter injection** — the initial `subscribeView` HTTP request carries
   the `filterBy` payload that the server respects. Modifying `postData` via `route.continue({ postData })`
   is effective (verified on multiple pages and fields).

2. **Trigger via "Apply" button is critical** — `setPageModel()` page bumps do NOT trigger new
   `subscribeView` requests (data arrives via the push channel). Only the "Apply" button triggers
   `unsubscribeView` → `subscribeView` → `loadData` requests that interceptors can catch.

3. **XHR/fetch override** works for Selenium/non-Playwright tools by intercepting at the JS level.

4. **Read data only via `window.qaGridApi`** — see [sitemap.md](sitemap.md) for the full API reference.

> For per-page schema details (columns, cacheName, pkField, boolean/code fields), check the page's
> profile file in `pages/` (linked from [sitemap.md](sitemap.md)). Profiles with `profiled: true`
> contain real verified schemas.

## Copy-Paste Templates

These are ready-to-paste snippets for `playwright_browser_run_code_unsafe`.

Every snippet below asserts that the selected page has exactly one matching
Grid.  For a page with multiple Grids, replace the fallback key list with the
page profile's canonical `keyPattern` (or an active container anchor) before
running it; never choose the first key or copy a UUID from a log.

```js
function getActiveQaGrid(pattern) {
  const api = window.qaGridApi;
  if (!api) throw new Error('qaGridApi is not available');
  const re = pattern ? (pattern instanceof RegExp ? pattern : new RegExp(pattern)) : null;
  const keys = Object.getOwnPropertyNames(api).filter(key => !re || re.test(key));
  if (keys.length !== 1) {
    throw new Error(`Expected one active Grid, found ${keys.length}: ${keys.join(', ')}`);
  }
  return api[keys[0]];
}
```

## Quick Start: Discover columns, rowCount, and cacheName on a page

```js
async (page) => {
  const info = await page.evaluate(() => {
    const gridKeys = Object.getOwnPropertyNames(window.qaGridApi);
    if (gridKeys.length !== 1) throw new Error(`Expected one active Grid, found ${gridKeys.length}`);
    const gk = gridKeys[0];
    const g = window.qaGridApi[gk];
    const cols = g.getColumnDefs().filter(c => c.field).map(c => ({
      field: c.field,
      headerName: c.headerName,
    }));
    const rows = g.getRowData();
    const firstRow = rows.find(r => r !== null && r !== undefined);
    const sampleRow = firstRow ? Object.keys(firstRow).map(k => ({ field: k, value: firstRow[k] })) : 'No rows';
    return {
      rowCount: g.getRowCount(),
      pageModel: g.getPageModel(),
      loadedRows: rows.filter(r => r !== null && r !== undefined).length,
      columns: cols,
      sampleRow: sampleRow,
    };
  });

  const routePath = page.url().split('/UI/')[1] || '';
  const pageName = routePath.replace(/^ui/, '').replace(/SearchTable$/, '');
  const inferredCacheName = pageName.charAt(0).toLowerCase() + pageName.slice(1) + 'PermCache';

  return { ...info, inferredCacheName };
}
```

### Template 1: Server-side filter via `page.route()` (RECOMMENDED — try this FIRST)

**This is the simplest and most reliable method.** Intercept the `subscribeView` request
at the CDP level, inject the filter, and click "Apply" to trigger the reload.

**Confirmed working** via live testing (2026-08-29) on `isAutoGeneration` (931→3 rows),
`unit` (24→16 rows), `isTraded` (86→86 rows), `type` (24→18 rows), `recordStatus` (325→325 rows).

```js
async (page) => {
  // --- Step 0: Clean state ---
  await page.unroute('**/api/private/subscribeView');

  // --- Step 1: Intercept subscribeView and inject filter ---
  await page.route('**/api/private/subscribeView', async (route) => {
    const body = JSON.parse(route.request().postData());
    if (body.cacheName === '<cacheName>') {  // e.g. 'instClassPermCache'
      if (!body.filterBy) body.filterBy = {};
      body.filterBy['<fieldName>'] = '<value>';  // e.g. isAutoGeneration: 'Y'
      await route.continue({ postData: JSON.stringify(body) });
      return;
    }
    await route.continue();
  });

  // --- Step 2: Trigger filtered data reload via Apply button ---
  await page.locator('button:has-text("Apply")').click();
  await page.waitForTimeout(3000);

  // --- Step 3: Read results from qaGridApi ---
  const result = await page.evaluate(() => {
    const gridKeys = Object.getOwnPropertyNames(window.qaGridApi);
    if (gridKeys.length !== 1) throw new Error(`Expected one active Grid, found ${gridKeys.length}`);
    const gk = gridKeys[0];
    const g = window.qaGridApi[gk];
    const rows = g.getRowData().filter(r => r !== null && r !== undefined);
    return {
      rowCount: g.getRowCount(),
      loadedRows: rows.length,
      violations: rows.filter(r => r['<fieldName>'] !== '<value>').length,
      rows: rows,
    };
  });

  // --- Step 4: Clean up ---
  await page.unroute('**/api/private/subscribeView');

  if (result.violations > 0) {
    console.warn('Filter silently ignored — ' + result.violations + ' violations. Server does not support this field. Use Template 3a instead.');
  }
  return result;
}
```

### Template 2: Client-side filter with `setRowData()` — DEPRECATED / DANGEROUS

**DO NOT USE unless you know what you're doing.** `setRowData()` corrupts the grid's
internal state. After calling it, subsequent `getRowData()` calls may return unexpected
results. Requires navigating away and back to recover.

**Use Template 1 or Template 3a instead.**

```js
// DEPRECATED — setRowData() corrupts the grid
// See Common Pitfalls #14 for details
```

### Template 3: Paginate all pages via qaGridApi (fallback when server doesn't support filter)

**Use this when Template 1 returns violations > 0** (the field is not server-filterable).

**WARNING: NEVER change `pageSize` from its original value.** Changing `pageSize` (e.g. to 10000) changes what a given page number means and can cause the grid to return fewer defined rows than expected. Always use the original `pageSize` from `getPageModel().pageSize`.

**The `getRowData()` array grows as you paginate** — it is not pre-allocated to `rowCount`. On page 1 the array length is `pageSize + 1`; on page N the array length is `N * (pageSize + 1)`. Only the current page's rows are defined; the rest are `undefined`. Always use `.filter(r => r !== null && r !== undefined)` before accessing fields.

**Always paginate through each page using `setPageModel()` to collect all data.**

Pattern: Iterate pages collecting defined rows, filter in the Playwright (Node) layer.

```js
async (page) => {
  await page.unroute('**/api/private/subscribeView');

  const { pageSize, colFields, rowCount } = await page.evaluate(() => {
    const gridKeys = Object.getOwnPropertyNames(window.qaGridApi);
    if (gridKeys.length !== 1) throw new Error(`Expected one active Grid, found ${gridKeys.length}`);
    const gk = gridKeys[0];
    const g = window.qaGridApi[gk];
    return {
      pageSize: g.getPageModel().pageSize,
      rowCount: g.getRowCount(),
      colFields: g.getColumnDefs().filter(c => c.field).map(c => c.field),
    };
  });
  const maxPage = Math.ceil(rowCount / pageSize);

  const allRows = [];
  for (let p = 1; p <= maxPage; p++) {
    await page.evaluate(({ pageNum, sz }) => {
      const gridKeys = Object.getOwnPropertyNames(window.qaGridApi);
    if (gridKeys.length !== 1) throw new Error(`Expected one active Grid, found ${gridKeys.length}`);
    const gk = gridKeys[0];
      window.qaGridApi[gk].setPageModel({ currentPage: pageNum, pageSize: sz });
    }, { pageNum: p, sz: pageSize });
    await page.waitForTimeout(3000);

    const pageRows = await page.evaluate((cf) => {
      const gridKeys = Object.getOwnPropertyNames(window.qaGridApi);
    if (gridKeys.length !== 1) throw new Error(`Expected one active Grid, found ${gridKeys.length}`);
    const gk = gridKeys[0];
      const g = window.qaGridApi[gk];
      return g.getRowData()
        .filter(r => r !== null && r !== undefined)
        .map(r => {
          const obj = {};
          cf.forEach(f => obj[f] = r[f]);
          return obj;
        });
    }, colFields);
    allRows.push(...pageRows);
    console.log(`Page ${p}/${maxPage}: loaded ${pageRows.length} rows (total: ${allRows.length})`);
  }

  if (allRows.length < rowCount) {
    console.warn(`Loaded ${allRows.length} of ${rowCount} total rows — server may not return all records (e.g. deleted records excluded).`);
  }

  const filterField = '<fieldName>';
  const filterValue = '<value>';
  const filteredRows = allRows.filter(r => r[filterField] === filterValue);

  return {
    totalLoaded: allRows.length,
    rowCountFromGrid: rowCount,
    filteredCount: filteredRows.length,
    pagesIterated: maxPage,
    filteredRows: filteredRows,
    allRows: allRows,
  };
}
```

**Key behaviors of this grid:**
- `getRowData()` returns a growing array — length starts at `pageSize + 1` and increases as you visit more pages. Unvisited slots are `undefined`. The array is NOT pre-allocated to `rowCount`.
- `getRowData()` returns **`pageSize + 1`** defined rows on non-last pages (e.g. 10 rows when pageSize=9) — the extra row is the virtual scroll buffer that triggers next-page loading. The **last page** returns only the remaining rows (no extra buffer).
- When paginating, the last row of page N overlaps with the first row of page N+1 — **you MUST deduplicate by primary key** after collecting (use Template 3a).
- **Changing `pageSize` in `setPageModel()` re-paginates the dataset server-side** — it does not corrupt the grid for all pages, but it changes what a given page number means. For example, with 24 rows and original pageSize=9, page 2 covers rows 10-18. Change pageSize to 15 and page 2 now covers rows 16-30 (only 9 defined). **Always use the original `pageSize`** for consistent iteration.
- **Never** try to fetch data via `window.fetch` or `XMLHttpRequest` to backend — it breaks auth/session
- Use `setPageModel({ currentPage: N, pageSize: originalPageSize })` to flip pages one at a time
- Filter the collected data in the Playwright (Node) layer, not in `page.evaluate`
- After collecting, reset to page 1 to leave the grid in a clean state: `setPageModel({ currentPage: 1, pageSize: originalPageSize })`
- If `allRows.length < rowCount`, the server is excluding records (common: `recordStatus: 'D'` / Deleted rows are counted but not returned)

### Template 3a: Paginate with dedup (recommended variant of Template 3)

**Use this instead of Template 3 when row counts matter.** After collecting all rows, deduplicate by the grid's primary key.

**BEST FOR: when the field is not server-filterable** — no interception needed.

```js
async (page) => {
  const { pageSize, colFields, rowCount, pkField } = await page.evaluate(() => {
    const gridKeys = Object.getOwnPropertyNames(window.qaGridApi);
    if (gridKeys.length !== 1) throw new Error(`Expected one active Grid, found ${gridKeys.length}`);
    const gk = gridKeys[0];
    const g = window.qaGridApi[gk];
    const allCols = g.getColumnDefs().filter(c => c.field);
    const pkField = allCols.find(c => /[Ii]d$/.test(c.field) && !/Status$/i.test(c.field))?.field || allCols[0]?.field;
    return {
      pageSize: g.getPageModel().pageSize,
      rowCount: g.getRowCount(),
      colFields: allCols.map(c => c.field),
      pkField: pkField,
    };
  });
  const maxPage = Math.ceil(rowCount / pageSize);

  const allRows = [];
  for (let p = 1; p <= maxPage; p++) {
    await page.evaluate(({ pageNum, sz }) => {
      const gridKeys = Object.getOwnPropertyNames(window.qaGridApi);
    if (gridKeys.length !== 1) throw new Error(`Expected one active Grid, found ${gridKeys.length}`);
    const gk = gridKeys[0];
      window.qaGridApi[gk].setPageModel({ currentPage: pageNum, pageSize: sz });
    }, { pageNum: p, sz: pageSize });
    await page.waitForTimeout(3000);

    const pageRows = await page.evaluate((cf) => {
      const gridKeys = Object.getOwnPropertyNames(window.qaGridApi);
    if (gridKeys.length !== 1) throw new Error(`Expected one active Grid, found ${gridKeys.length}`);
    const gk = gridKeys[0];
      const g = window.qaGridApi[gk];
      return g.getRowData()
        .filter(r => r !== null && r !== undefined)
        .map(r => {
          const obj = {};
          cf.forEach(f => obj[f] = r[f]);
          return obj;
        });
    }, colFields);
    allRows.push(...pageRows);
    console.log(`Page ${p}/${maxPage}: loaded ${pageRows.length} rows (total collected: ${allRows.length})`);
  }

  const seen = new Set();
  const uniqueRows = allRows.filter(r => {
    const key = r[pkField];
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });

  return {
    totalCollected: allRows.length,
    uniqueCount: uniqueRows.length,
    rowCountFromGrid: rowCount,
    pkField: pkField,
    uniqueRows: uniqueRows,
  };
}
```

### Template 4: XHR/fetch override — Server-side filter (alternative when Template 1 doesn't work)

**Use this when using Selenium (or any non-Playwright tool)** that lacks `page.route()`.
**Use Template 1 (page.route) when using Playwright** — it's simpler.

The XHR/fetch override works inside the browser's JS context, intercepting the `subscribeView`
request before it reaches the server.

**⚠️ CRITICAL: Trigger via "Apply" button, NOT `setPageModel`.** The XHR/fetch override ONLY catches requests triggered by clicking the "Apply" button. Calling `setPageModel()` to bump the page does NOT trigger any XHR requests — data arrives via the WebSocket/SSE push channel which bypasses JavaScript-level interceptors.

```js
async (page) => {
  // --- Step 0: Clean state ---
  await page.unroute('**/api/private/subscribeView');

  // --- Step 1: Inject XHR/fetch override (MUST be done BEFORE clicking Apply) ---
  await page.evaluate(() => {
    window.__OriginalXHR = window.__OriginalXHR || window.XMLHttpRequest;
    window.__OriginalFetch = window.__OriginalFetch || window.fetch;
    const OriginalXHR = window.__OriginalXHR;
    window.XMLHttpRequest = function () {
      const xhr = new OriginalXHR();
      const originalOpen = xhr.open;
      const originalSend = xhr.send;
      xhr.open = function (method, url) {
        this._url = url;
        return originalOpen.apply(this, arguments);
      };
      xhr.send = function (body) {
        if (this._url && this._url.indexOf('subscribeView') !== -1) {
          try {
            const data = JSON.parse(body);
            if (data.cacheName === '<cacheName>') {
              if (!data.filterBy) data.filterBy = {};
              data.filterBy['<fieldName>'] = '<value>';
              body = JSON.stringify(data);
            }
          } catch (e) {}
        }
        return originalSend.call(this, body);
      };
      return xhr;
    };
    const originalFetch = window.__OriginalFetch;
    window.fetch = function (url, options) {
      if (url.indexOf('subscribeView') !== -1 && options && options.body) {
        try {
          const data = JSON.parse(options.body);
          if (data.cacheName === '<cacheName>') {
            if (!data.filterBy) data.filterBy = {};
            data.filterBy['<fieldName>'] = '<value>';
            options.body = JSON.stringify(data);
          }
        } catch (e) {}
      }
      return originalFetch.apply(this, url, options);
    };
  });

  // --- Step 2: Trigger filtered data reload ---
  await page.locator('button:has-text("Apply")').click();
  await page.waitForTimeout(3000);

  // --- Step 3: Read results from qaGridApi ---
  const result = await page.evaluate(() => {
    const gridKeys = Object.getOwnPropertyNames(window.qaGridApi);
    if (gridKeys.length !== 1) throw new Error(`Expected one active Grid, found ${gridKeys.length}`);
    const gk = gridKeys[0];
    const g = window.qaGridApi[gk];
    const rows = g.getRowData().filter(r => r !== null && r !== undefined);
    return {
      rowCount: g.getRowCount(),
      loadedRows: rows.length,
      violations: rows.filter(r => r['<fieldName>'] !== '<value>').length,
      rows: rows,
    };
  });

  // --- Step 4: Restore original XHR/fetch ---
  await page.evaluate(() => {
    if (window.__OriginalXHR) window.XMLHttpRequest = window.__OriginalXHR;
    if (window.__OriginalFetch) window.fetch = window.__OriginalFetch;
  });

  if (result.violations > 0) {
    console.warn('Filter silently ignored — ' + result.violations + ' violations. Server does not support this field. Use Template 3a instead.');
  }
  return result;
}
```

**Selenium equivalent (Python):** See `selenium_solution.md` for a complete working example with login, filter, and result reading.

## Opening Row Detail Page (All Grids)

All search/maintain grids share the same behavior to open a row's detail information: **double-click the row**. The detail opens as a **tooltip/modal overlay** on the current page — the URL does NOT change.

### Pattern: Open Any Row's Detail

```js
async (page) => {
  // --- Step 1: Filter the grid to target rows ---
  await page.unroute('**/api/private/subscribeView');
  await page.route('**/api/private/subscribeView', async (route) => {
    const body = JSON.parse(route.request().postData());
    if (body.cacheName === '<cacheName>') {
      if (!body.filterBy) body.filterBy = {};
      body.filterBy['<fieldName>'] = '<value>';
      await route.continue({ postData: JSON.stringify(body) });
      return;
    }
    await route.continue();
  });
  await page.locator('button:has-text("Apply")').click();
  await page.waitForTimeout(3000);
  await page.unroute('**/api/private/subscribeView');

  // --- Step 2: Select the target row (0-indexed) ---
  const rowIndex = 0;  // 0 = 1st row, 1 = 2nd row, 2 = 3rd row, etc.
  await page.evaluate((idx) => {
    const gridKeys = Object.getOwnPropertyNames(window.qaGridApi);
    if (gridKeys.length !== 1) throw new Error(`Expected one active Grid, found ${gridKeys.length}`);
    const gk = gridKeys[0];
    window.qaGridApi[gk].setSelected(idx, true);
  }, rowIndex);
  await page.waitForTimeout(500);

  // --- Step 3: Double-click the row ---
  // Y = 48 (header height) + rowIndex * 48 (row height) + 24 (row center offset)
  const y = 48 + rowIndex * 48 + 24;
  await page.locator('#canvasTableWrapperRef').dblclick({ force: true, position: { x: 100, y } });
  await page.waitForTimeout(3000);

  // --- Step 4: Read detail from tooltip overlay ---
  // Use playwright_browser_snapshot to read the detail panel content
  // Look for the tooltip element containing "Detail" heading
}
```

### Key Points

- **Target element**: `#canvasTableWrapperRef` — NOT `#canvasRef` or `#visibleScrollRef`
- **Must use `force: true`** — `#visibleScrollRef` overlays the canvas and intercepts pointer events
- **Y position formula**: `y = 48 + rowIndex * 48 + 24`
  - Row 1 (index 0): y = 72
  - Row 2 (index 1): y = 120
  - Row 3 (index 2): y = 168
- **X position**: 100 (within the grid area, away from edges)
- **Result**: Detail opens as a tooltip overlay with sections: Record Status, Identity, Calendar, Price, Auto Generation, Trading Parameters
- **Close detail**: Click the close button (icon: ) in the tooltip header

### Example: Open 2nd row of Auto Generation enabled Inst. Classes

```js
async (page) => {
  await page.unroute('**/api/private/subscribeView');
  await page.route('**/api/private/subscribeView', async (route) => {
    const body = JSON.parse(route.request().postData());
    if (body.cacheName === 'instClassPermCache') {
      if (!body.filterBy) body.filterBy = {};
      body.filterBy['isAutoGeneration'] = 'Y';
      await route.continue({ postData: JSON.stringify(body) });
      return;
    }
    await route.continue();
  });
  await page.locator('button:has-text("Apply")').click();
  await page.waitForTimeout(3000);
  await page.unroute('**/api/private/subscribeView');

  // Open 2nd row (index 1)
  await page.evaluate((idx) => {
    const gridKeys = Object.getOwnPropertyNames(window.qaGridApi);
    if (gridKeys.length !== 1) throw new Error(`Expected one active Grid, found ${gridKeys.length}`);
    const gk = gridKeys[0];
    window.qaGridApi[gk].setSelected(idx, true);
  }, 1);
  await page.waitForTimeout(500);
  await page.locator('#canvasTableWrapperRef').dblclick({ force: true, position: { x: 100, y: 120 } });
  await page.waitForTimeout(3000);
}
```

## Cache Names

The `cacheName` in the `subscribeView` request is page-specific.

**Pattern:** strip `ui` prefix and `SearchTable` suffix from route, lowercase first letter, append `PermCache`.

Example: `/UI/uiAutoGenerationRuleSearchTable` → `autoGenerationRulePermCache`

**For per-page cacheName, see the profile file** in `pages/` (linked from [sitemap.md](sitemap.md) — each page row links to its profile with the cacheName). The Quick Start snippet above also infers it automatically from the route path.

**Pattern:** `<pageName>PermCache` — **first letter is lowercase** (e.g. `instClassPermCache`, NOT `InstClassPermCache`).

## Filter Value Conventions

| Column Type | Filter Value | Example |
|-------------|-------------|---------|
| Boolean (ends with `?`) | `"Y"` or `"N"` | `isTraded: "Y"` |
| Record Status | `"E"` (Active) / `"D"` (Deleted) | `recordStatus: "E"` |
| String (dropdown) | Use the **display value**, not the code | `currencyCode: "HKD"` |
| String (free text) | Exact match or use `*` wildcard | `description: "HSI*"` |
| Code fields (type, unit) | Use the **raw code**, not the display label | `unit: "M"`, `type: "O"` |

**Common code fields and their meanings:**

| Field | Raw Codes | Display Meanings |
|-------|-----------|-----------------|
| `unit` | `D`, `W`, `M` | Daily, Weekly, Monthly |
| `type` | `O`, `U` | Option, Future |
| `recordStatus` | `E`, `D` | Active, Deleted |

## Cleanup

After you're done filtering a page, unroute and restore to avoid leaking the filter to other pages:

```js
await page.unroute('**/api/private/subscribeView');
await page.evaluate(() => {
  if (window.__OriginalXHR) window.XMLHttpRequest = window.__OriginalXHR;
  if (window.__OriginalFetch) window.fetch = window.__OriginalFetch;
});
```

**Important:** Always clean up before navigating to a different page, otherwise the filter will leak.

## Server-Side Filter Compatibility

**Not all columns support server-side filtering.** The server silently ignores unknown filter fields. If you inject `unit: 'M'` but the result still shows rows with `D` and `W`, that field isn't filterable.

### Decision Guide: Which Template to Use

1. **Try Template 1 first** (page.route) — simplest, works for all page sizes
2. **If violations > 0** → fall back to **Template 3a** (paginate + dedup in Playwright/Node layer)
3. **If using Selenium** → use **Template 4** (XHR/fetch override) instead of Template 1
4. **Do NOT use Template 2** (setRowData) — corrupts the grid

**When the server does NOT support the filter** (violations > 0), fall back to Template 3a regardless of page count — there is no alternative.

## Common Pitfalls

1. **NEVER fetch data from backend API directly** — don't use `window.fetch`, `XMLHttpRequest`, or `page.evaluate` with `fetch()` to call the backend. The auth/session context won't carry over and you'll get errors. **Always use `window.qaGridApi`** to read and navigate data.

2. **`getRowData()` returns an array that grows as you paginate** — it is NOT pre-allocated to `rowCount`. On page 1, the array length is `pageSize + 1`. On page N, the array grows to approximately `N * (pageSize + 1)`. Only the current page's rows are defined; the rest are `undefined`. Filter rows using `.filter(r => r !== null && r !== undefined)` before accessing fields. To get all data, you MUST paginate through all pages.

3. **NEVER change `pageSize` from its original value** — it changes what each page number means server-side roller. For example, with 24 rows and original pageSize=9, page 2 covers rows 10-18. Change pageSize to 15 and page 2 now covers rows 16-30 (potentially fewer defined rows). **Always use the original `pageSize`** from `getPageModel().pageSize`.

4. **Template 1 (page.route) is the simplest server-side filter method** — it works for Playwright. For Selenium/non-Playwright, use Template 4 (XHR/fetch override).

5. **Always restore/unroute before setting a new filter** — stale handlers stack and leak between pages.

6. **Always wait at least 3 seconds** after triggering a refresh for the server to respond.

7. **Trigger via "Apply" button** — `setPageModel()` does NOT trigger `subscribeView` XHR requests. Data arrives via WebSocket push that bypasses CDP/JS interceptors. Always click "Apply" to trigger the filtered reload.

8. **Boolean fields store "Y"/"N"** — not "Yes"/"No". The UI renders "Y" as "Yes" but the server filter expects "Y".

9. **Multiple filters** — use `Object.assign` to add multiple fields at once:
   ```js
   Object.assign(body.filterBy, { isTraded: 'Y', currencyCode: 'HKD', recordStatus: 'E' });
   ```

10. **Restore before navigating to a different page** — stale handlers will inject filters into other pages' requests.

11. **For Template 4, match on `subscribeView` string in URL** — the XHR override checks `this._url.indexOf('subscribeView') !== -1` which correctly matches `/vs02/api/private/subscribeView`.

12. **Some columns aren't server-filterable** — the server silently ignores unknown filter fields. Always verify by checking if rows violate your filter value. If they do, fall back to Template 3a.

13. **`allRows.length < rowCount` doesn't always mean pagination is incomplete** — after paginating all pages, you may still collect fewer rows than `rowCount`. The server may count deleted records (`recordStatus: 'D'`) in `rowCount` but not return them.

14. **`setRowData()` corrupts the grid** — avoid it. Prefer collecting data across pages and filtering in the Playwright (Node) layer.

15. **`page.evaluate()` only accepts 0 or 1 argument** — passing 2+ arguments will throw "Too many arguments". Always wrap multiple values in a single object: `page.evaluate(({ a, b }) => { ... }, { a: 1, b: 2 })`.

16. **Recovering from a corrupted grid** — if `setRowData()` or a bad operation corrupted the grid, the only recovery is to navigate away to a different page, wait 3 seconds, then navigate back.

17. **Compute `maxPage` manually** — `Math.ceil(rowCount / pageSize)` is safer than relying on `getPageModel().maxPage` as it may be missing or stale on some pages, though it matched on all 7 pages tested.

18. **Virtual scroll preloads 1 extra row per page (non-last pages only)** — On non-last pages, `getRowData()` returns `pageSize + 1` defined rows. On the **last page**, only the remaining rows are returned. When paginating, the last row of page N overlaps with the first row of page N+1. Deduplicate by primary key after collecting (see Template 3a).

19. **Detail page opens as overlay, not new URL** — double-clicking a grid row opens a tooltip/modal on the same page. The URL stays at the search table. Use snapshot to read the detail panel.

20. **Canvas dblclick target is `#canvasTableWrapperRef`** — NOT `#canvasRef` or `#visibleScrollRef`. Must use `{ force: true }` to bypass the overlay. Row Y position: `y = 48 + rowIndex * 48 + 24`.

## Preferred Workflow for Filtering Any Grid

1. **Navigate to the page** (use SPA navigation after login)
2. **Run Quick Start** to discover columns, rowCount, and infer cacheName
3. **Try Template 1** (page.route) with your filter field and value
4. **If violations > 0** → the field isn't server-filterable → use **Template 3a** (paginate + dedup)
5. **If violations === 0** → success — read your filtered data
6. **Clean up:** unroute and restore XHR/fetch before navigating away

## Opening Row Detail

1. **Filter** the grid to target rows (Template 1)
2. **Select row**: `setSelected(rowIndex, true)` (0-indexed)
3. **Double-click**: `locator('#canvasTableWrapperRef').dblclick({ force: true, position: { x: 100, y: 48 + rowIndex * 48 + 24 } })`
4. **Read** detail from tooltip overlay via `playwright_browser_snapshot`
5. **Close** detail by clicking the close icon ()

**Key insight:** Both Template 1 (page.route) and Template 4 (XHR/fetch override) produce identical results. Template 1 is preferred for Playwright (simpler code); Template 4 is for Selenium/non-Playwright tools.

For per-page filter testing results (which fields are server-filterable), see individual page profiles in `pages/` — profiled pages include `notes` about which filters have been verified.

## Editing Row Content (All Maintain Pages)

The detail tooltip opened by double-click is **read-only** by default (all fields are `disabled`). To edit a row, you must use the **settings button** on the Record Status card to trigger an update flow.

### Pattern: Edit a Row with Tomorrow Effective

```js
async (page) => {
  // --- Step 1: Open row detail (see Opening Row Detail above) ---
  await page.evaluate((idx) => {
    const gridKeys = Object.getOwnPropertyNames(window.qaGridApi);
    if (gridKeys.length !== 1) throw new Error(`Expected one active Grid, found ${gridKeys.length}`);
    const gk = gridKeys[0];
    window.qaGridApi[gk].setSelected(idx, true);
  }, 0);
  await page.waitForTimeout(500);
  await page.locator('#canvasTableWrapperRef').dblclick({ force: true, position: { x: 100, y: 72 } });
  await page.waitForTimeout(4000);

  // --- Step 2: Click the settings button on "Current Record" card ---
  // The settings button (gear icon) is inside the "Record Status" section,
  // right after the "Active" or "Inactive" label on the Current Record card.
  // Use playwright_browser_snapshot to find button labeled "settings" on the Current Record row.

  // --- Step 3: Select update timing from dropdown menu ---
  // The menu contains:
  //   - "Update for tomorrow" — effective date = next day
  //   - "Update for scheduled today" — effective today
  //   - "Update for as soon as possible" — immediate
  //   - "Delete for tomorrow" — soft delete effective tomorrow
  // Use playwright_browser_click on the desired menuitem.

  // --- Step 4: Edit fields in the form ---
  // After selecting the timing, the fields become editable (combobox/texbox/checkbox).
  // Modify the fields you need via playwright_browser_click, playwright_browser_type,
  // or playwright_browser_select_option.

  // --- Step 5: Confirm the changes ---
  // Click the "Confirm" button at the bottom of the tooltip to submit.
  // A "Confirmation" dialog will appear: "Proceed your action?"
  // Click "Confirm" on the dialog to finalize.
  // A successful submission will show "Success" and the "To" section with the
  // new effective date and "Effective until: Forever".
}
```

### Key Points

- **Fields are disabled initially** — the detail tooltip is read-only until you trigger an update via the settings button.
- **Settings button location** — In the "Record Status" section of the tooltip, on the "Current Record" card, to the right of the "Active" status label. It has `button` role with `name: "settings"`.
- **Menu options**: `playwright_browser_snapshot` after clicking will show a `menu` element with `menuitem` children.
- **Confirm button** — Located at the bottom of the tooltip, alongside a "Cancel" button. Both become enabled after selecting the update timing.
- **"To" section** — After confirmation, the "To" card shows the pending update with its effective date and modified values.
- **Confirm button triggers a dialog** — After clicking "Confirm" on the form, a **"Confirmation" dialog** appears with "Proceed your action?" — you must click its "Confirm" button to finalize.
- **No changes error** — If you submit without modifying any field, you get: `ErrorCode: 14005, ErrorMsg: No changes detected, please edit field before submitting`. You MUST change at least one field value before confirming.
- **Canceling mid-edit** — If you cancel while in edit mode, a "Please Confirm" dialog asks "You are editing fields, confirm to close?" — click "Confirm" to discard changes.
- **Close detail** — Click the close icon () in the tooltip header after completing edits.

### Example: Enable Auto Generation for HSIFUT with Tomorrow Effective

1. Filter grid to HSIFUT row, double-click to open detail
2. Click settings button on Current Record (next to "Active")
3. Select "Update for tomorrow" from dropdown
4. Verify Auto Generation? = "Y - Yes" (already set or change via combobox)
5. Click "Confirm" — detail shows "To: Update Record" with effective date 01-Sep-2026

## Rejecting a Countersign Request

When you submit a record edit (e.g., "Update for tomorrow"), it creates a **pending countersign request** that must be approved by an authorizer before taking effect. To reject (cancel) a request you submitted:

### Steps

1. **Navigate to Countersign Request page** — Use SPA navigation to `/UI/uiAuthorizationRequestSearchTable`. This page shows all countersign requests with `txStatus` values: `"P"` (Pending), `"A"` (Approved), `"R"` (Rejected).

2. **Select the target row** — Click the **checkbox column** (leftmost column, x=15) on `#canvasTableWrapperRef` at the row's Y position. This selects the row for bulk actions. Do NOT double-click (which opens the read-only detail).

3. **Click "More Actions"** — Opens a dropdown menu with action options.

4. **Click "Reject selected Countersign Request"** — Submits the rejection. A confirmation dialog may appear.

5. **Verify** — Navigate back to the original page (e.g., `/UI/uiInstClassSearchTable`), double-click the record, and confirm the "To" section shows **"No Plan"** instead of "Update Record".

### Pattern: Reject Selected Request

```js
async (page) => {
  // --- Step 1: Navigate to Countersign Request ---
  await page.evaluate(() => {
    window.history.pushState({}, '', '/UI/uiAuthorizationRequestSearchTable');
    window.dispatchEvent(new PopStateEvent('popstate'));
  });
  await page.waitForTimeout(3000);

  // --- Step 2: Select the target row via checkbox column ---
  // The checkbox column is at x=15 (leftmost area of canvas)
  // Y = 48 (header) + rowIndex * 48 (row height) + 24 (row center)
  const rowIndex = 1;  // 0-indexed, the row you want to reject
  const y = 48 + rowIndex * 48 + 24;
  await page.locator('#canvasTableWrapperRef').click({ force: true, position: { x: 15, y } });
  await page.waitForTimeout(500);

  // --- Step 3: Click "More Actions" ---
  await page.getByRole('button', { name: 'More Actions' }).click();
  await page.waitForTimeout(500);

  // --- Step 4: Click "Reject selected Countersign Request" ---
  await page.getByRole('button', { name: 'Reject selected Countersign' }).click();
  await page.waitForTimeout(3000);

  // --- Step 5: Verify rejection ---
  // Navigate back to original page and check "To" section shows "No Plan"
}
```

### Key Points

- **"Withdraw selected" is disabled** — Even the requestor cannot use "Withdraw" from the More Actions menu. The correct action is **"Reject selected"**.
- **"Approve selected"** — Available for approvers to approve pending requests.
- **"Reject all Pending" / "Approve all Pending"** — Bulk actions available in the menu.
- **Checkbox selection is required** — Single row click selects for detail; checkbox column click selects for bulk actions.
- **After rejection, the "To" section** reverts to **"No Plan"** on the original record's detail panel.
- **Rejecting doesn't undo the current record** — It only cancels the pending change. The current record remains unchanged.
