# ODP PageExplore Knowledge Base

This directory is the single source of truth for ODP website exploration.
It contains page routes and profiles, qaGrid contracts and observations, and
the evidence snapshots from which generated indexes are built.

## Reading order

1. Read [`sitemap.md`](sitemap.md) before navigating to an Admin page.
2. Read [`pages/INDEX.md`](pages/INDEX.md), then the selected page profile.
3. Read [`GRID_OPERATION_GUIDE.md`](GRID_OPERATION_GUIDE.md) before any Grid
   operation.
4. Read [`qaGrid/Grid_API_Core_Index.md`](qaGrid/Grid_API_Core_Index.md) and
   the relevant observation index when runtime Grid evidence is required.

## Layout

| Path | Role |
|---|---|
| `sitemap.md` | Login, SPA navigation, and route catalog |
| `GRID_OPERATION_GUIDE.md` | Playwright filtering, pagination, and detail workflows |
| `selenium_solution.md` | Selenium-specific exploration reference |
| `pages/` | Maintained page profiles and generated page indexes |
| `qaGrid/` | Shared Grid contract, observations, and generated aggregate index |
| `evidence/` | Source snapshots and redacted/raw observation logs |

The knowledge base must not depend on a user Skill. Consumer Skills and
runtime tools may read this directory through `PAGEEXPLORE_ROOT`, whose
bundled default is `<PageExplore>/pageExplore`.

Do not put consumer-specific conversion rules, executable test steps, repair
lessons, or user credentials here. Keep those in the consuming project or a
local secret store as appropriate.

## Refresh

Run from the `PageExplore` root:

```bash
python3 tools/build_pages_index.py
python3 tools/build_grid_api_index.py
```

Generated `INDEX.json` and `INDEX.md` files must be refreshed whenever their
maintained profiles or evidence inputs change. The maintenance scripts honor
`PAGEEXPLORE_ROOT` when this directory is mounted outside the bundled path.
