# qaGridApi Observation Index

Generated from redacted shape evidence.  Read the shared contract in
[`Grid_API_Core_Index.md`](Grid_API_Core_Index.md) before using this file.
Observed values are telemetry, not business expectations.

## Snapshot

- Records: `609`
- Exact keys: `139`
- Key patterns: `26`
- Page profiles with `hasGrid: true`: `91`
- Observed/verified page profiles: `1`

| Source | SHA-256 | Records |
|---|---|---:|
| `evidence/qaGrid/grid_log.txt` | `7dbbaf45e2b0a55f05e592abcd92d0671e6d019590155ab0323c49b7a2a8ab41` | 585 |
| `evidence/qaGrid/odp_admin_gui_grid_api.log` | `b1c8b76d3ed27b6e76915a4e99c20d5b7936558cd3e81931affacaf6180ebe00` | 3 |
| `evidence/qaGrid/odp_admin_gui_grid_api_additional.log` | `14afe683241efce2d88b5402eca300b28bce22475328280930b282c1bcbfcb9f` | 21 |

## Method Counts

| Method | Calls |
|---|---:|
| `getVisibleRowData` | 182 |
| `getColumnDefs` | 153 |
| `getVisibleOperationMenuPositionByIndex` | 141 |
| `getFilteredCount` | 73 |
| `getVisibleBoundaryByIndex` | 31 |
| `setSelectedRows` | 14 |
| `setRowData` | 13 |
| `getRowData` | 2 |

## Key Families

| Namespace | Key pattern | Observed exact keys | Methods | Fields |
|---|---|---:|---|---|
| `admin_gui` | `accessGroupByTypeDetailDialog_<uuid>_subDetailTable1` | 1 | `getVisibleBoundaryByIndex` (1), `setSelectedRows` (1) | - |
| `admin_gui` | `autoComboGenerationRuleGroupDetailDialog_<uuid>_subDetailTable1` | 2 | `setRowData` (2) | `$GUI_newRow`, `autoComboGenRuleType`, `bankerContractsFromSpot`, `bankerMonthSelection`, `bankerSelectionType`, `comboClassId`, `contractsFromSpot`, `description`, `instClassId`, `legContracts`, `legFromReference`, `legMonthSelection`, `legNumber`, `legs`, `manualLinkId`, `minTimeSpread`, `monthSelection`, `name`, `operation`, `ratio`, `rowId`, `ruleId`, `ruleNumber`, `unit` |
| `admin_gui` | `comboNameStdDetailDialog_<uuid>_subDetailTable1` | 2 | `getVisibleRowData` (1), `setRowData` (1) | `$GUI_newRow`, `category`, `freeText`, `legNumber`, `nameStdDateFormat`, `numCharacters`, `position`, `recordStatus`, `rowId` |
| `admin_gui` | `exchangeParticipantDetailDialog_<uuid>_subDetailTable1` | 2 | `getVisibleRowData` (1), `setRowData` (1) | `blockTradeSizeLimit`, `defaultAccount`, `effectiveDate`, `instTypeId`, `orderSizeLimit`, `participantId`, `recordStatus`, `requestAction`, `requestStatus`, `rowId` |
| `admin_gui` | `lastTradingDateCalendarDetailDialog_<uuid>_subDetailTable1` | 1 | `setRowData` (1) | `$GUI_newRow`, `Apr`, `Aug`, `Dec`, `Feb`, `Jan`, `Jul`, `Jun`, `Mar`, `May`, `Nov`, `Oct`, `Sep`, `Year`, `hasChildren`, `isAutoExpanded`, `key`, `rowId` |
| `admin_gui` | `lastTradingDateFormulaDetailDialog_<uuid>_subDetailTable1` | 1 | `setRowData` (1) | `anchoringDay`, `deltaDays`, `isFromMonthEnd`, `isIncludeProductCalendar`, `monthDelta`, `regCalId`, `rowId`, `ruleNumber`, `ruleType`, `weekInMonth`, `weekday` |
| `admin_gui` | `lastTradingTimeDstAdjustmentDetailDialog_<uuid>_subDetailTable1` | 1 | `getVisibleBoundaryByIndex` (3) | - |
| `admin_gui` | `reportGroupListDetailDialog_<uuid>_subDetailTable1` | 1 | `setRowData` (1) | `$GUI_newRow`, `contractDesc`, `contractDescCh`, `contractTerm`, `contractTermCh`, `instClassId`, `rowId`, `underlyingId` |
| `admin_gui` | `reportGroupListDetailDialog_<uuid>_subDetailTable2` | 1 | `setRowData` (1) | `comboClassId`, `rowId`, `underlyingId` |
| `admin_gui` | `smpIdListDetailDialog_<uuid>_subDetailTable1` | 4 | `getColumnDefs` (2), `getRowData` (2), `setRowData` (2) | `authDateTime`, `authUserId`, `creDateTime`, `creUserId`, `effectiveDate`, `modDateTime`, `modUserId`, `recordStatus`, `requestAction`, `requestStatus`, `rowId`, `scheduledTime`, `smpId`, `smpIdListId`, `smpIdStatus`, `txId`, `txUpdCnt`, `updCnt` |
| `admin_gui` | `tmcStrategyDetailDialog_<uuid>_subDetailTable1` | 1 | `setRowData` (1) | `instGroupId1`, `instGroupId2`, `instGroupId3`, `isRatioRelative`, `lastTradingDateCondition`, `lastTradingDateRefLeg`, `legNumber`, `operation`, `ratioCondition`, `ratioExact`, `ratioRefLeg`, `recordStatus`, `rowId`, `strikePriceCondition`, `strikePriceRefLeg`, `tmcStrategyId` |
| `admin_gui` | `tradingTimetableDetailDialog_<uuid>_subDetailTable1` | 1 | `setRowData` (1) | `$GUI_tradingStateName`, `alertInterval`, `numAlert`, `rowId`, `startLogicalDayInd`, `startTime`, `tradingSessionId`, `tradingStateId`, `transitionMode` |
| `trading_gui` | `uiAutomaticQuoteOrderBook_<uuid>_automaticQuoteOrderBookTableId` | 3 | `getFilteredCount` (1), `getVisibleRowData` (4) | `aRQty`, `ahtFlag`, `atId`, `bRQty`, `cancelHintValue`, `clearingAccount`, `clientOrderId`, `cnv`, `compId`, `compIdRef`, `creationTime`, `customerInfo`, `decimalInPrice`, `executionId`, `expireDate`, `giveUpInformation`, `giveUpParticipant`, `inactiveOrder`, `orderAttributeFlags`, `orderId`, `orderQty`, `orderType`, `participantId`, `participantIdRef`, `positionEffect`, `price`, `quoteAttributeFlags`, `quoteEntryId`, `securityId`, `securityIdRef`, `side`, `smpId`, `timeInForce`, `transactionTime` |
| `trading_gui` | `uiEnterTradeReportInterbank_<uuid>_enterTradeReportInterbankTableId` | 1 | `getVisibleRowData` (1) | `customerInfo`, `decimalsInPrice`, `giveUpInformation`, `giveUpParticipant`, `id`, `isValid`, `positionEffect`, `price`, `qty`, `side`, `tradingId`, `value` |
| `trading_gui` | `uiLocalInactiveOrders_<uuid>_localInactiveOrdersTableId` | 10 | `getFilteredCount` (15), `getVisibleBoundaryByIndex` (3), `getVisibleRowData` (15), `setSelectedRows` (5) | `aht`, `atid`, `changed`, `cod`, `compId`, `created`, `customer`, `customerInfo`, `decimalInPrice`, `expiryDate`, `giveUp`, `giveUpAcc`, `giveUpPart`, `groupId`, `idpUserId`, `positionEffect`, `price`, `qty`, `securityId`, `seqId`, `side`, `smpToken`, `timeValidity`, `type`, `userId` |
| `trading_gui` | `uiOrderBookExternal_<uuid>_orderBookTableId` | 21 | `getColumnDefs` (21), `getFilteredCount` (3), `getVisibleOperationMenuPositionByIndex` (21), `getVisibleRowData` (26), `setSelectedRows` (8) | `$UL_underlyingId`, `aRQty`, `ahtIndicator`, `atid`, `bRQty`, `cancelHintValue`, `changed`, `clearingAccount`, `clientOrderId`, `cnv`, `cod`, `compId`, `created`, `cumulativeQty`, `customerInformation`, `decimalInPrice`, `error`, `executionId`, `expireDate`, `giveUpInformation`, `giveUpParticipant`, `group`, `inactiveOrder`, `instId`, `leavesQty`, `orderAttributeFlags`, `orderId`, `orderPrice`, `orderQty`, `orderStatus`, `orderType`, `positionEffect`, `quoteEntryId`, `rQty`, `securityId`, `side`, `smpId`, `timeInForce`, `userId`, `version` |
| `trading_gui` | `uiOrderDepth_<uuid>_orderDepthTableId` | 3 | `getVisibleRowData` (3) | `aImplied`, `aPart`, `aQty`, `aTrd`, `aType`, `ask`, `bImplied`, `bPart`, `bQty`, `bTrd`, `bType`, `bid`, `decimalInPrice`, `tradingId` |
| `trading_gui` | `uiOrderHistory_<uuid>_orderHistoryTableId` | 22 | `getColumnDefs` (39), `getFilteredCount` (20), `getVisibleOperationMenuPositionByIndex` (39), `getVisibleRowData` (42) | `$MKT_description`, `$MKT_marketId`, `$UL_description`, `$UL_underlyingId`, `aROrExecQty`, `action`, `aggressorIndicator`, `ahtIndicator`, `atid`, `bROrExecQty`, `cPart`, `cancelHintValue`, `cc`, `clearingAccount`, `clientOrderId`, `cnv`, `cod`, `compId`, `cumulativeQty`, `customerInformation`, `decimalInPrice`, `executionId`, `executionPrice`, `executionQty`, `expireDate`, `giveUpInformation`, `giveUpParticipant`, `group`, `instId`, `leavesQty`, `matchType`, `orderAttributeFlags`, `orderCancelReason`, `orderId`, `orderPrice`, `orderQty`, `orderStatus`, `orderType`, `positionEffect`, `quoteEntryId`, `rOrExecQty`, `rQty`, `reply`, `securityId`, `side`, `smpId`, `subTradeType`, `timeInForce`, `tradeConfirmationIndicator`, `tradeDate`, `tradeId`, `tradeType`, `transactionTime`, `userId` |
| `trading_gui` | `uiPendingTradeReport_<uuid>_pendingTradeReportTableId` | 4 | `getColumnDefs` (8), `getFilteredCount` (4), `getVisibleOperationMenuPositionByIndex` (8), `getVisibleRowData` (5) | `aggregatedTrade`, `atid`, `blockTradeReportId`, `blockTradeStatus`, `compId`, `counterpartyEpId`, `customerInformation`, `decimalInPrice`, `direction`, `giveUpInformation`, `giveUpParticipant`, `group`, `key`, `legs`, `noBlockTradeLegs`, `positionEffect`, `price`, `qty`, `securityId`, `side`, `specialIndicator`, `tradeConclusionDateTime`, `tradeReportId`, `transactionTime`, `userId`, `version` |
| `trading_gui` | `uiPriceDepth_<uuid>_priceDepthTable` | 3 | `getVisibleRowData` (3) | `a1`, `a1HasQty`, `a2`, `a2HasQty`, `a3`, `a3HasQty`, `a4`, `a4HasQty`, `a5`, `a5HasQty`, `b1`, `b1HasQty`, `b2`, `b2HasQty`, `b3`, `b3HasQty`, `b4`, `b4HasQty`, `b5`, `b5HasQty`, `decimalInPrice`, `instId`, `key`, `lastUpdateTime`, `recType` |
| `trading_gui` | `uiPriceInformation_<uuid>_priceInformationTableId` | 18 | `getColumnDefs` (21), `getFilteredCount` (1), `getVisibleOperationMenuPositionByIndex` (11), `getVisibleRowData` (16) | `ahtHighestTraded`, `ahtLatestTraded`, `ahtLatestTradedQty`, `ahtLowestTraded`, `ahtOpenPrice`, `ahtTotalTradeReportQty`, `ahtTurn`, `bestAsk`, `bestAskQty`, `bestBid`, `bestBidQty`, `cop`, `currency`, `decimalInPrice`, `decimalInStrikePrice`, `displayStrike`, `highestTraded`, `instGroup`, `instId`, `instType`, `isEffective`, `lastTradingDate`, `lastUpdateTime`, `latestTraded`, `latestTradedQty`, `lowestTraded`, `market`, `openInterest`, `openPrice`, `recordStatus`, `refPrice`, `strike`, `totalTradeReportQty`, `tss`, `turn`, `underlying`, `underlyingId` |
| `trading_gui` | `uiQuote_<uuid>_priceQuotesTableId` | 4 | `getVisibleBoundaryByIndex` (24), `getVisibleRowData` (6) | `ahtHighestTraded`, `ahtLatestTraded`, `ahtLatestTradedQty`, `ahtLowestTraded`, `ahtOpenPrice`, `ahtTotalTradeReportQty`, `ahtTurn`, `bestAsk`, `bestAskQty`, `bestBid`, `bestBidQty`, `cop`, `currency`, `decimalInPrice`, `decimalInStrikePrice`, `displayStrike`, `highestTraded`, `instGroup`, `instId`, `instType`, `isEffective`, `lastTradingDate`, `lastUpdateTime`, `latestTraded`, `latestTradedQty`, `lowestTraded`, `market`, `openInterest`, `openPrice`, `recordStatus`, `refPrice`, `strike`, `totalTradeReportQty`, `tss`, `turn`, `underlying`, `underlyingId` |
| `admin_gui` | `uiRgNotificationDetailDialog_<uuid>_notificationListTableId` | 1 | `setRowData` (1) | `$GUI_newRow`, `emailAddr`, `rowId` |
| `trading_gui` | `uiTradeHistoryExternal_<uuid>_tradeHistoryTableId` | 16 | `getColumnDefs` (33), `getFilteredCount` (15), `getVisibleOperationMenuPositionByIndex` (33), `getVisibleRowData` (30) | `OriginalExecutionPrice`, `OriginalSecurityId`, `OriginalTradeId`, `action`, `aggressorIndicator`, `atid`, `bought`, `cPART`, `clearingAccount`, `clientOrderId`, `compId`, `cumulativeQty`, `customerInformation`, `dealSrc`, `dealSrcValue`, `decimalInPrice`, `ep`, `executionId`, `executionPrice`, `executionQty`, `giveUpInformation`, `giveUpParticipant`, `group`, `leavesQty`, `matchType`, `orderId`, `orderPrice`, `orderQty`, `orderStatus`, `orderType`, `positionEffect`, `securityId`, `side`, `smp`, `sold`, `state`, `subTradeType`, `timeInForce`, `trType`, `tradeDate`, `tradeHistoryKey`, `tradeId`, `tradeType`, `tradeViewKey`, `transactionTime`, `userId` |
| `trading_gui` | `uiTradeTicker_<uuid>_tickerTableId` | 2 | `getColumnDefs` (3), `getFilteredCount` (2), `getVisibleOperationMenuPositionByIndex` (3), `getVisibleRowData` (4) | `action`, `dealSrc`, `dealSrcValue`, `decimalInPrice`, `displayId`, `executionPrice`, `executionQty`, `securityId`, `tradeId`, `transactionTime` |
| `trading_gui` | `uiTradeViewExternal_<uuid>_tradeViewTableId` | 13 | `getColumnDefs` (26), `getFilteredCount` (12), `getVisibleOperationMenuPositionByIndex` (26), `getVisibleRowData` (25) | `OriginalExecutionPrice`, `OriginalSecurityId`, `OriginalTradeId`, `action`, `aggressorIndicator`, `atid`, `bought`, `cPART`, `clearingAccount`, `clientOrderId`, `compId`, `cumulativeQty`, `customerInformation`, `dealSrc`, `dealSrcValue`, `decimalInPrice`, `ep`, `executionId`, `executionPrice`, `executionQty`, `giveUpInformation`, `giveUpParticipant`, `group`, `leavesQty`, `matchType`, `orderId`, `orderPrice`, `orderQty`, `orderStatus`, `orderType`, `positionEffect`, `securityId`, `side`, `smp`, `sold`, `state`, `subTradeType`, `timeInForce`, `trType`, `tradeDate`, `tradeHistoryKey`, `tradeId`, `tradeType`, `tradeViewKey`, `transactionTime`, `userId` |

## Page Profile Coverage

Page profiles carry the page-specific label, columns, and Grid
observation status. The shared contract remains authoritative
for method safety and runtime key discovery.

| Profile | Route | Status | Columns | Key pattern |
|---|---|---|---:|---|
| `pages/uiAccessGroupByTypeSearchTable.md` | `/UI/uiAccessGroupByTypeSearchTable` | `inferred` | 6 | `runtime-discovered; page-specific UUID key` |
| `pages/uiAuthorizationRequestSearchTable.md` | `/UI/uiAuthorizationRequestSearchTable` | `inferred` | 16 | `runtime-discovered; page-specific UUID key` |
| `pages/uiAutoComboGenerationRuleGroupSearchTable.md` | `/UI/uiAutoComboGenerationRuleGroupSearchTable` | `inferred` | 11 | `runtime-discovered; page-specific UUID key` |
| `pages/uiAutoGenerationRuleSearchTable.md` | `/UI/uiAutoGenerationRuleSearchTable` | `inferred` | 17 | `runtime-discovered; page-specific UUID key` |
| `pages/uiAutomaticEventMessageSearchTable.md` | `/UI/uiAutomaticEventMessageSearchTable` | `inferred` | 15 | `runtime-discovered; page-specific UUID key` |
| `pages/uiBlockTradeGroupSearchTable.md` | `/UI/uiBlockTradeGroupSearchTable` | `inferred` | 9 | `runtime-discovered; page-specific UUID key` |
| `pages/uiBlockTradeMvtSearchTable.md` | `/UI/uiBlockTradeMvtSearchTable` | `inferred` | 6 | `runtime-discovered; page-specific UUID key` |
| `pages/uiBulkImport.md` | `/UI/uiBulkImport` | `inferred` | 54 | `runtime-discovered; page-specific UUID key` |
| `pages/uiCapitalAdjustmentSearchTable.md` | `/UI/uiCapitalAdjustmentSearchTable` | `inferred` | 8 | `runtime-discovered; page-specific UUID key` |
| `pages/uiComboClassPriceTickLimitSearchTable.md` | `/UI/uiComboClassPriceTickLimitSearchTable` | `inferred` | 10 | `runtime-discovered; page-specific UUID key` |
| `pages/uiComboClassSearchTable.md` | `/UI/uiComboClassSearchTable` | `inferred` | 21 | `runtime-discovered; page-specific UUID key` |
| `pages/uiComboGeneration.md` | `/UI/uiComboGeneration` | `inferred` | 17 | `runtime-discovered; page-specific UUID key` |
| `pages/uiComboGroupSearchTable.md` | `/UI/uiComboGroupSearchTable` | `inferred` | 10 | `runtime-discovered; page-specific UUID key` |
| `pages/uiComboNameStdSearchTable.md` | `/UI/uiComboNameStdSearchTable` | `inferred` | 7 | `runtime-discovered; page-specific UUID key` |
| `pages/uiComboSearchTable.md` | `/UI/uiComboSearchTable` | `inferred` | 15 | `runtime-discovered; page-specific UUID key` |
| `pages/uiComboTypeErrTradeParamSearchTable.md` | `/UI/uiComboTypeErrTradeParamSearchTable` | `inferred` | 10 | `runtime-discovered; page-specific UUID key` |
| `pages/uiComboTypeSearchTable.md` | `/UI/uiComboTypeSearchTable` | `inferred` | 20 | `runtime-discovered; page-specific UUID key` |
| `pages/uiCompanySearchTable.md` | `/UI/uiCompanySearchTable` | `inferred` | 8 | `runtime-discovered; page-specific UUID key` |
| `pages/uiContingencySwitchSearchTable.md` | `/UI/uiContingencySwitchSearchTable` | `inferred` | 10 | `runtime-discovered; page-specific UUID key` |
| `pages/uiControlBlockUnblockParticipantPerProductSearchTable.md` | `/UI/uiControlBlockUnblockParticipantPerProductSearchTable` | `inferred` | 9 | `runtime-discovered; page-specific UUID key` |
| `pages/uiControlContingencyTriggerOfAhtReferencePriceCalculationSearchTable.md` | `/UI/uiControlContingencyTriggerOfAhtReferencePriceCalculationSearchTable` | `inferred` | 3 | `runtime-discovered; page-specific UUID key` |
| `pages/uiControlContingencyTriggerOfComboClassPriceTickLimitCalculationSearchTable.md` | `/UI/uiControlContingencyTriggerOfComboClassPriceTickLimitCalculationSearchTable` | `inferred` | 1 | `runtime-discovered; page-specific UUID key` |
| `pages/uiControlContingencyTriggerOfPriceTickLimitCalculationSearchTable.md` | `/UI/uiControlContingencyTriggerOfPriceTickLimitCalculationSearchTable` | `inferred` | 1 | `runtime-discovered; page-specific UUID key` |
| `pages/uiControlDailyMarketReportSearchTable.md` | `/UI/uiControlDailyMarketReportSearchTable` | `inferred` | 2 | `runtime-discovered; page-specific UUID key` |
| `pages/uiControlMonitorInstrumentTradingHaltSearchTable.md` | `/UI/uiControlMonitorInstrumentTradingHaltSearchTable` | `inferred` | 3 | `runtime-discovered; page-specific UUID key` |
| `pages/uiControlMonitorPriceLimitSearchTable.md` | `/UI/uiControlMonitorPriceLimitSearchTable` | `inferred` | 18 | `runtime-discovered; page-specific UUID key` |
| `pages/uiControlMonitorVCMSearchTable.md` | `/UI/uiControlMonitorVCMSearchTable` | `inferred` | 11 | `runtime-discovered; page-specific UUID key` |
| `pages/uiControlSettlementValuesSearchTable.md` | `/UI/uiControlSettlementValuesSearchTable` | `inferred` | 13 | `runtime-discovered; page-specific UUID key` |
| `pages/uiControlTmcSearchTable.md` | `/UI/uiControlTmcSearchTable` | `inferred` | 21 | `runtime-discovered; page-specific UUID key` |
| `pages/uiControlTradingTimetableSearchTable.md` | `/UI/uiControlTradingTimetableSearchTable` | `inferred` | 8 | `runtime-discovered; page-specific UUID key` |
| `pages/uiControlUnderlyingPriceSearchTable.md` | `/UI/uiControlUnderlyingPriceSearchTable` | `inferred` | 12 | `runtime-discovered; page-specific UUID key` |
| `pages/uiCycleBlocksSearchTable.md` | `/UI/uiCycleBlocksSearchTable` | `inferred` | 8 | `runtime-discovered; page-specific UUID key` |
| `pages/uiDirectDropCopySessionSearchTable.md` | `/UI/uiDirectDropCopySessionSearchTable` | `inferred` | 22 | `runtime-discovered; page-specific UUID key` |
| `pages/uiDirectOrderFlowSessionSearchTable.md` | `/UI/uiDirectOrderFlowSessionSearchTable` | `inferred` | 25 | `runtime-discovered; page-specific UUID key` |
| `pages/uiDropCopyGroupSearchTable.md` | `/UI/uiDropCopyGroupSearchTable` | `inferred` | 7 | `runtime-discovered; page-specific UUID key` |
| `pages/uiExchangeParticipantSearchTable.md` | `/UI/uiExchangeParticipantSearchTable` | `inferred` | 14 | `runtime-discovered; page-specific UUID key` |
| `pages/uiExchangeSearchTable.md` | `/UI/uiExchangeSearchTable` | `inferred` | 7 | `runtime-discovered; page-specific UUID key` |
| `pages/uiExchangeUserSearchTable.md` | `/UI/uiExchangeUserSearchTable` | `inferred` | 12 | `runtime-discovered; page-specific UUID key` |
| `pages/uiFuturesGroupSearchTable.md` | `/UI/uiFuturesGroupSearchTable` | `inferred` | 6 | `runtime-discovered; page-specific UUID key` |
| `pages/uiGlobalParametersSearchTable.md` | `/UI/uiGlobalParametersSearchTable` | `inferred` | 63 | `runtime-discovered; page-specific UUID key` |
| `pages/uiInstClassPriceTickLimitSearchTable.md` | `/UI/uiInstClassPriceTickLimitSearchTable` | `inferred` | 10 | `runtime-discovered; page-specific UUID key` |
| `pages/uiInstClassSearchTable.md` | `/UI/uiInstClassSearchTable` | `inferred` | 34 | `runtime-discovered; page-specific UUID key` |
| `pages/uiInstGroupSearchTable.md` | `/UI/uiInstGroupSearchTable` | `inferred` | 17 | `runtime-discovered; page-specific UUID key` |
| `pages/uiInstTypeErrTradeParamSearchTable.md` | `/UI/uiInstTypeErrTradeParamSearchTable` | `inferred` | 10 | `runtime-discovered; page-specific UUID key` |
| `pages/uiInstTypeSearchTable.md` | `/UI/uiInstTypeSearchTable` | `inferred` | 19 | `runtime-discovered; page-specific UUID key` |
| `pages/uiInstrumentSearchTable.md` | `/UI/uiInstrumentSearchTable` | `inferred` | 19 | `runtime-discovered; page-specific UUID key` |
| `pages/uiLastTradingDateCalendarSearchTable.md` | `/UI/uiLastTradingDateCalendarSearchTable` | `inferred` | 7 | `runtime-discovered; page-specific UUID key` |
| `pages/uiLastTradingDateFormulaSearchTable.md` | `/UI/uiLastTradingDateFormulaSearchTable` | `inferred` | 7 | `runtime-discovered; page-specific UUID key` |
| `pages/uiLastTradingTimeDstAdjustmentSearchTable.md` | `/UI/uiLastTradingTimeDstAdjustmentSearchTable` | `inferred` | 7 | `runtime-discovered; page-specific UUID key` |
| `pages/uiLegalIPAddressSearchTable.md` | `/UI/uiLegalIPAddressSearchTable` | `inferred` | 7 | `runtime-discovered; page-specific UUID key` |
| `pages/uiLifecycleTimeRuleSearchTable.md` | `/UI/uiLifecycleTimeRuleSearchTable` | `inferred` | 12 | `runtime-discovered; page-specific UUID key` |
| `pages/uiMarketMessageTemplateSearchTable.md` | `/UI/uiMarketMessageTemplateSearchTable` | `inferred` | 8 | `runtime-discovered; page-specific UUID key` |
| `pages/uiMarketSearchTable.md` | `/UI/uiMarketSearchTable` | `inferred` | 21 | `runtime-discovered; page-specific UUID key` |
| `pages/uiMmpParameterSearchTable.md` | `/UI/uiMmpParameterSearchTable` | `inferred` | 10 | `runtime-discovered; page-specific UUID key` |
| `pages/uiMonitorHistoricalOrderBookSearchTable.md` | `/UI/uiMonitorHistoricalOrderBookSearchTable` | `inferred` | 10 | `runtime-discovered; page-specific UUID key` |
| `pages/uiMonitorQuoteRequestSearchTable.md` | `/UI/uiMonitorQuoteRequestSearchTable` | `inferred` | 6 | `runtime-discovered; page-specific UUID key` |
| `pages/uiNameStdSearchTable.md` | `/UI/uiNameStdSearchTable` | `inferred` | 7 | `runtime-discovered; page-specific UUID key` |
| `pages/uiNonTradingDaysSearchTable.md` | `/UI/uiNonTradingDaysSearchTable` | `inferred` | 6 | `runtime-discovered; page-specific UUID key` |
| `pages/uiParticipantUserRoleSearchTable.md` | `/UI/uiParticipantUserRoleSearchTable` | `inferred` | 29 | `runtime-discovered; page-specific UUID key` |
| `pages/uiPasswordPolicySearchTable.md` | `/UI/uiPasswordPolicySearchTable` | `inferred` | 18 | `runtime-discovered; page-specific UUID key` |
| `pages/uiPriceLimitParametersSearchTable.md` | `/UI/uiPriceLimitParametersSearchTable` | `inferred` | 16 | `runtime-discovered; page-specific UUID key` |
| `pages/uiPriceLimitSearchTable.md` | `/UI/uiPriceLimitSearchTable` | `inferred` | 6 | `runtime-discovered; page-specific UUID key` |
| `pages/uiPriceTickLimitSearchTable.md` | `/UI/uiPriceTickLimitSearchTable` | `inferred` | 11 | `runtime-discovered; page-specific UUID key` |
| `pages/uiPriceTickSearchTable.md` | `/UI/uiPriceTickSearchTable` | `inferred` | 10 | `runtime-discovered; page-specific UUID key` |
| `pages/uiPtrmGuiUserSearchTable.md` | `/UI/uiPtrmGuiUserSearchTable` | `inferred` | 26 | `runtime-discovered; page-specific UUID key` |
| `pages/uiReferencePriceCalculationRuleSearchTable.md` | `/UI/uiReferencePriceCalculationRuleSearchTable` | `inferred` | 6 | `runtime-discovered; page-specific UUID key` |
| `pages/uiReferencePriceSourceSearchTable.md` | `/UI/uiReferencePriceSourceSearchTable` | `inferred` | 6 | `runtime-discovered; page-specific UUID key` |
| `pages/uiRegionalCalendarUploadSearchTable.md` | `/UI/uiRegionalCalendarUploadSearchTable` | `inferred` | 7 | `runtime-discovered; page-specific UUID key` |
| `pages/uiRegionalHolidayCalendarSearchTable.md` | `/UI/uiRegionalHolidayCalendarSearchTable` | `inferred` | 6 | `runtime-discovered; page-specific UUID key` |
| `pages/uiReportGroupListSearchTable.md` | `/UI/uiReportGroupListSearchTable` | `inferred` | 6 | `runtime-discovered; page-specific UUID key` |
| `pages/uiReportSearchTable.md` | `/UI/uiReportSearchTable` | `inferred` | 14 | `runtime-discovered; page-specific UUID key` |
| `pages/uiReviewSmpRequestSearchTable.md` | `/UI/uiReviewSmpRequestSearchTable` | `inferred` | 20 | `runtime-discovered; page-specific UUID key` |
| `pages/uiSelfAdminPortalUserSearchTable.md` | `/UI/uiSelfAdminPortalUserSearchTable` | `inferred` | 9 | `runtime-discovered; page-specific UUID key` |
| `pages/uiSmpIdListSearchTable.md` | `/UI/uiSmpIdListSearchTable` | `observed` | 7 | `runtime-discovered; parent grid key is page-specific` |
| `pages/uiSmpIdSearchTable.md` | `/UI/uiSmpIdSearchTable` | `inferred` | 10 | `runtime-discovered; page-specific UUID key` |
| `pages/uiSpecialTradingDaysSearchTable.md` | `/UI/uiSpecialTradingDaysSearchTable` | `inferred` | 6 | `runtime-discovered; page-specific UUID key` |
| `pages/uiSponsoringParticipantSearchTable.md` | `/UI/uiSponsoringParticipantSearchTable` | `inferred` | 8 | `runtime-discovered; page-specific UUID key` |
| `pages/uiStrikePriceRangeSearchTable.md` | `/UI/uiStrikePriceRangeSearchTable` | `inferred` | 12 | `runtime-discovered; page-specific UUID key` |
| `pages/uiStrikePriceReferenceSearchTable.md` | `/UI/uiStrikePriceReferenceSearchTable` | `inferred` | 11 | `runtime-discovered; page-specific UUID key` |
| `pages/uiStrikePriceTableSearchTable.md` | `/UI/uiStrikePriceTableSearchTable` | `inferred` | 7 | `runtime-discovered; page-specific UUID key` |
| `pages/uiSystemPreferenceSearchTable.md` | `/UI/uiSystemPreferenceSearchTable` | `inferred` | 7 | `runtime-discovered; page-specific UUID key` |
| `pages/uiTmcStrategyListSearchTable.md` | `/UI/uiTmcStrategyListSearchTable` | `inferred` | 6 | `runtime-discovered; page-specific UUID key` |
| `pages/uiTmcStrategySearchTable.md` | `/UI/uiTmcStrategySearchTable` | `inferred` | 9 | `runtime-discovered; page-specific UUID key` |
| `pages/uiTradingGuiUserSearchTable.md` | `/UI/uiTradingGuiUserSearchTable` | `inferred` | 27 | `runtime-discovered; page-specific UUID key` |
| `pages/uiTradingRightSearchTable.md` | `/UI/uiTradingRightSearchTable` | `inferred` | 6 | `runtime-discovered; page-specific UUID key` |
| `pages/uiTradingStateSearchTable.md` | `/UI/uiTradingStateSearchTable` | `inferred` | 41 | `runtime-discovered; page-specific UUID key` |
| `pages/uiTradingTimetableSearchTable.md` | `/UI/uiTradingTimetableSearchTable` | `inferred` | 8 | `runtime-discovered; page-specific UUID key` |
| `pages/uiUiUserRoleSearchTable.md` | `/UI/uiUiUserRoleSearchTable` | `inferred` | 9 | `runtime-discovered; page-specific UUID key` |
| `pages/uiUnderlyingSearchTable.md` | `/UI/uiUnderlyingSearchTable` | `inferred` | 25 | `runtime-discovered; page-specific UUID key` |
| `pages/uiVcmParametersSearchTable.md` | `/UI/uiVcmParametersSearchTable` | `inferred` | 11 | `runtime-discovered; page-specific UUID key` |
| `pages/uiVcmSearchTable.md` | `/UI/uiVcmSearchTable` | `inferred` | 6 | `runtime-discovered; page-specific UUID key` |

## Use by Consumers

- Use key patterns to select a runtime Grid, never an exact UUID.
- Use column/row field names to maintain the matching page profile.
- Use method counts and call order as exploration hints only.
- Do not generate a status assertion or a mutation step from a log value alone.
- Promote an observation to `verified` only after a clean Playwright replay and a matching visible assertion pass.

The full machine-readable shape is in `qaGridApi_Index.json`.
