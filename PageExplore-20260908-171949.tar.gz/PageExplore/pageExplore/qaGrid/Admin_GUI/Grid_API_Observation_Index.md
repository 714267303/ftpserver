# Admin GUI qaGrid API Observation Index

## Scope

This index records real `qaGridApi` calls captured while editing Admin GUI
detail pages. The original three calls cover the SMP ID List detail sub-table;
the supplemental capture covers additional Admin dialogs. It supplements the generic API reference in
`sitemap.md` and `GRID_OPERATION_GUIDE.md` with an observed page-specific key,
column schema, validation rules, and row shape.

The regenerable cross-channel roll-up is
[`../qaGridApi_Index.md`](../qaGridApi_Index.md); this file remains the
human-maintained Admin interpretation of the 24 Admin records.

The records are observations from logs, not a runtime certification of every
environment. Dynamic UUIDs, timestamps, transaction IDs, and record values must
be treated as data, not constants.

## Provenance

| Field | Value |
|---|---|
| Raw log | `../../evidence/qaGrid/odp_admin_gui_grid_api.log` |
| Raw log SHA-256 | `b1c8b76d3ed27b6e76915a4e99c20d5b7936558cd3e81931affacaf6180ebe00` |
| Captured | 2026-09-01 11:11:55 to 11:12:51 +0800 |
| Records | 3 (`setRowData`, `getColumnDefs`, `getRowData`) |
| API | `qaGridApi` |
| Related page profile | `../../pages/uiSmpIdListSearchTable.md` |
| General API guidance | `../../sitemap.md`, `../../GRID_OPERATION_GUIDE.md` |
| Status | `observed`, not runtime-verified across environments |

The later capture is kept separately so the original evidence hash and
provenance remain stable. Sensitive row values (emails and free-text samples)
were redacted; dynamic UUIDs and timestamps remain raw evidence and are
normalized to placeholders by the generated indexes:

| Raw log | `../../evidence/qaGrid/odp_admin_gui_grid_api_additional.log` |
|---|---|
| Raw log SHA-256 | `14afe683241efce2d88b5402eca300b28bce22475328280930b282c1bcbfcb9f` |
| Captured | 2026-09-01 15:46:35 to 16:56:21 +0800 |
| Records | 21 (`setRowData`, reads, boundary and selection calls) |
| Key families | 13 Admin dialog/sub-table patterns |
| Status | `observed`; sensitive values redacted before indexing |

The cross-channel generated roll-up (`../qaGridApi_Index.md`) currently indexes
609 records from the Trading log plus both Admin logs. It is the authoritative
machine-readable source for counts; this document records the Admin meaning and
safety interpretation.

## Supplemental Admin Families

The additional capture expands page-specific hints for these dialogs:

| Dialog family | Observed methods | Redacted business fields/hints |
|---|---|---|
| `autoComboGenerationRuleGroupDetailDialog_<uuid>_subDetailTable1` | `setRowData` | auto-combo rule type, manual-link legs, banker selection |
| `lastTradingDateFormulaDetailDialog_<uuid>_subDetailTable1` | `setRowData` | rule type, anchoring/month delta, calendar reference |
| `lastTradingDateCalendarDetailDialog_<uuid>_subDetailTable1` | `setRowData` | year and Jan-Dec calendar values |
| `comboNameStdDetailDialog_<uuid>_subDetailTable1` | `setRowData`, `getVisibleRowData` | category, free text, date format, leg number |
| `tradingTimetableDetailDialog_<uuid>_subDetailTable1` | `setRowData` | session, start time, trading state |
| `exchangeParticipantDetailDialog_<uuid>_subDetailTable1` | `setRowData`, `getVisibleRowData` | instrument type and order/block limits |
| `reportGroupListDetailDialog_<uuid>_subDetailTable1/2` | `setRowData` | outright/combo class and underlying mappings |
| `tmcStrategyDetailDialog_<uuid>_subDetailTable1` | `setRowData` | strategy legs, ratios, instrument groups |
| `lastTradingTimeDstAdjustmentDetailDialog_<uuid>_subDetailTable1` | `getVisibleBoundaryByIndex` | column boundary coordinates only |
| `accessGroupByTypeDetailDialog_<uuid>_subDetailTable1` | `setSelectedRows`, `getVisibleBoundaryByIndex` | selection/boundary behavior only |
| `uiRgNotificationDetailDialog_<uuid>_notificationListTableId` | `setRowData` | notification email field (redacted) |

These records help select the page profile and the visible sub-table workflow;
they do not prove that a raw `setRowData` call is a valid mutation. Use the
normal Add/Modify Table Item flow and preserve field validation assertions.

## Observed Key Pattern

Both sub-table records use this dynamic key shape:

```text
smpIdListDetailDialog_<uuid>_subDetailTable1
```

The UUID changes between dialog instances. A Playwright exploration should
discover the key at runtime rather than hard-code either UUID from the log.

```js
const key = Object.getOwnPropertyNames(window.qaGridApi).find(
  k => /^smpIdListDetailDialog_[0-9a-f-]+_subDetailTable1$/.test(k)
);
if (!key) throw new Error("SMP ID List detail sub-table grid was not found");
const grid = window.qaGridApi[key];
```

## Captured Calls

| Time | Function | Meaning observed |
|---|---|---|
| 11:11:55 | `setRowData([...])` | Populates the sub-table with one SMP ID row; return value is `null` |
| 11:12:51 | `getColumnDefs()` | Returns the synthetic first column plus editable `smpId` and `smpIdStatus` columns |
| 11:12:51 | `getRowData()` | Returns one row with business fields and request/audit metadata |

## Column Definition Evidence

The `getColumnDefs()` record contains three columns:

| Order | Field | Header | Editor/type | Observed validation or enum |
|---:|---|---|---|---|
| 0 | empty | empty | no editor | Synthetic non-sortable column, width 50 |
| 1 | `smpId` | `SMP ID` | `contentAssistCellEditor`, `contentAssist` | Required; unique; error messages `is a mandatory field` and `Should be unique`; uppercase transform; `valueFormat=DESCRIPTION`; `sortable=false` |
| 2 | `smpIdStatus` | `Status` | `richSelectCellEditor` | Required; values `A - Active`, `D - Deleted`, `S - Suspended`; `sortable=false` |

Other observed UI metadata includes `leftHeaderIcon=pencil-filled` and
width 200 for both business columns. The content-assist
`values` array was empty in this capture, so lookup data must not be inferred
from this single record.

## Row Data Evidence

The observed `getRowData()` row has this shape:

| Field | Observed value | Use in exploration or feature mapping |
|---|---|---|
| `rowId` | `1` | Grid-local row identity |
| `smpIdListId` | `1323` | Parent SMP ID List identity |
| `smpId` | `210010008` | Editable SMP ID value |
| `smpIdStatus` | `S` | Editable status; map `A`, `D`, `S` from column enum |
| `recordStatus` | `A` | Parent/row record lifecycle status |
| `requestAction` | `A` | Pending request action |
| `requestStatus` | `A` | Request status |
| `creUserId`, `creDateTime` | `388_DT1`, `1788232316` | Creation audit metadata |
| `modUserId`, `modDateTime` | `388_DT1`, `1788232316` | Modification audit metadata |
| `authUserId`, `authDateTime` | `388_DT2`, `1788232359` | Approval/authorization audit metadata |
| `effectiveDate` | `1788192000` | Effective-date epoch value |
| `scheduledTime` | `1788233160` | Scheduled execution epoch value |
| `txId` | UUID | Transaction identity; do not hard-code |
| `txUpdCnt`, `updCnt` | `2`, `2` | Update counters |

Field meanings above are based on the names and the captured values. Confirm
status semantics against a second environment or the page behavior before using
them as an assertion oracle.

## Playwright Inspection Contract

For read-only exploration, inspect the discovered grid through the public
`qaGridApi` object:

```js
const key = Object.getOwnPropertyNames(window.qaGridApi).find(
  k => /^smpIdListDetailDialog_[0-9a-f-]+_subDetailTable1$/.test(k)
);
const grid = window.qaGridApi[key];
return {
  key,
  columns: grid.getColumnDefs(),
  rows: grid.getRowData().filter(r => r !== null && r !== undefined)
};
```

The existing grid guide marks `setRowData()` as deprecated/dangerous because it
can corrupt grid state. Its presence in this log proves only that the
application invoked it during this capture; it is not a recommendation for
exploration code. Prefer read methods and page/grid UI actions unless a
deliberate mutation test explicitly requires the method and includes recovery.

## Consumer Handoff

| Observed API fact | Semantic automation guidance |
|---|---|
| Dynamic detail sub-table key | Discover the active key at runtime |
| Editable `smpId` and status columns | Use the visible Add/Modify Table Item workflow |
| Required/unique validation | Assert the visible form or sub-table error message |
| Row/request/audit metadata | Assert only when the test objective requires it |
| `setRowData` mutation | Do not replay by default; use the normal visible UI action |

The log therefore makes SMP ID List sub-table flows easier to map, but it does
not replace page profiles or case-specific expected status assertions.

## Maintenance

When another `qaGridApi` log is captured, append the raw record to the evidence
log and add a short entry here with its page/key pattern, function, and observed
schema. Keep dynamic UUIDs and transaction values in the evidence only; the
canonical mapping should use placeholders and runtime discovery.
