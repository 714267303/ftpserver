# qaGridApi Core Index

## Purpose

This is the shared contract for the canvas Grid used by Trading UI and Admin
GUI. Both applications expose a `window.qaGridApi` object. The contract is
shared; page labels, Grid keys, columns, row schemas, and business actions
remain page-specific.

Use this file before either the Admin or Trading observation index.  Do not
copy a page's observed business fields into this shared file.

## Evidence Boundary

| Evidence | Source | Status | What it proves |
|---|---|---|---|
| Common API facade | `sitemap.md`, `GRID_OPERATION_GUIDE.md` | documented | Public API access through `window.qaGridApi` |
| Page profile contract | `../pages/Grid_API_Profile_Contract.md` | maintained | Shared metadata and promotion rules for page-specific observations |
| Admin calls | `../evidence/qaGrid/odp_admin_gui_grid_api.log` | observed | SMP ID List detail sub-table key and schema |
| Trading calls | `../evidence/qaGrid/grid_log.txt` | observed | Trading table key families, methods, and schemas |

Observed logs are not a guarantee that every method is available on every
page or in every deployment.  A page profile may promote an observation to
`verified` only after a fresh Playwright run (preferably repeated from a clean
page state).

## Shared Runtime Contract

### Discover a Grid

Grid keys contain page/widget identity and frequently include a UUID.  Never
hard-code a UUID from a log.  Resolve the active page's candidate key at
runtime, and fail when there is zero or more than one equally good candidate.

```js
function findQaGridKey(pattern, root = window) {
  const api = root.qaGridApi;
  if (!api) throw new Error("qaGridApi is not available");
  const re = pattern instanceof RegExp ? pattern : new RegExp(pattern);
  const keys = Object.getOwnPropertyNames(api).filter(k => re.test(k));
  if (keys.length !== 1) {
    throw new Error(`Expected one active Grid, found ${keys.length}: ${keys.join(", ")}`);
  }
  return keys[0];
}

const key = findQaGridKey(/^smpIdListDetailDialog_[0-9a-f-]+_subDetailTable1$/i);
const grid = window.qaGridApi[key];
```

The exact resolver may use an active page/container anchor when a page has
multiple Grid instances. A first-match substring search is insufficient
because a stale UUID can remain after a dialog or tab is reopened.

### Read Methods

| Method | Contract/use | Safety |
|---|---|---|
| `getColumnDefs()` | Raw visible/hidden column metadata, including `field`, `headerName`, editors, validation, ordering | Read-only |
| `getOriginalColumnDefs()` | Original column metadata before user changes | Read-only; page support varies |
| `getFilteredColumnDefs()` | Current filtered column metadata | Read-only; page support varies |
| `getRowData()` | Current page row objects; may contain `null` sparse slots | Read-only; filter nulls |
| `getRowCount()` | Total row count | Read-only |
| `getVisibleRowData()` | Rows currently rendered/visible; may be sparse | Read-only; filter nulls |
| `getVisibleRowNum()` | Visible row indexes | Read-only |
| `getSelectedRows()` / `getRawSelectedRows()` | Selected row objects | Read-only |
| `getPageModel()` | Current page, page size, and max page | Read-only |
| `getSortModel()` | Current sort state | Read-only |
| `getFilterModel()` / `getAppliedFilterModel()` | Current filter state | Read-only |
| `getFormattedValue(i, field)` | Rendered cell value | Read-only; formatting is page-specific |
| `getVisibleFormattedValueByIndex(i)` | Rendered values for one visible row | Read-only |

All returned rows must be normalized before comparison:

```js
const rows = (grid.getRowData() || []).filter(row => row != null);
```

Do not infer a business status from a field name alone.  Use the page profile,
functional specification, or an explicit test assertion.

### Write Methods and Safety Classes

| Method family | Examples | Default policy |
|---|---|---|
| Selection | `setSelected`, `setSelectedRows` | Allowed only when automation immediately performs the corresponding visible UI action |
| View state | `setPageModel`, `setSortModel`, `resetFilterModel` | Allowed for exploration; verify that the page reloads before asserting |
| Presentation | `setColumnDefs`, `setReadOnly`, `redraw`, flashing methods | Exploration only unless the case explicitly tests presentation |
| Data mutation | `setRowData`, `addRow`, `updateRowByIndex`, `deleteRowsByIndex` | Block by default; use the UI workflow and confirmation path |

`setRowData()` appearing in an Admin log is evidence of an application call,
not a recommendation to replay that call in automation. It can break the
Grid's subscription/state model. The same rule applies to Trading UI.

## Key and Schema Rules

1. Treat a key as a runtime locator, not a stable identifier.
2. Normalize UUIDs to `<uuid>` in indexes and recipes.
3. Keep `headerName -> field` mappings in the page profile or observation index.
4. Keep field value formatting and enum meaning in the page profile; the core
   index only describes the API shape.
5. Keep HTTP `subscribeView` filtering rules in `GRID_OPERATION_GUIDE.md`.
   A Grid API log alone does not prove server-side filterability.
6. Distinguish `getRowData()` (page data) from `getVisibleRowData()` (rendered
   viewport data); neither is necessarily the complete dataset.
7. When multiple keys match, bind the key to the visible page/container or
   require an explicit page mapping.  Do not silently choose the first match.

## Consumer Handoff

| Intent | Preferred source/step |
|---|---|
| Inspect columns | Playwright `page.evaluate` + `getColumnDefs()`; record in the observation index |
| Assert visible rows | Use the consumer's semantic visible-row assertion |
| Assert sub-table rows | Use the consumer's semantic sub-table assertion |
| Select rows before an action | Use the visible UI selection flow; `setSelectedRows` is an implementation detail |
| Open a row detail | Use the visible double-click/table flow and the page profile's key column |
| Filter/search | UI Apply flow and `GRID_OPERATION_GUIDE.md`; do not synthesize a Grid write call |
| Generate an executable test | Let the consumer map these facts to its own verified step catalog |

## Observation Promotion

Use these statuses consistently:

| Status | Meaning |
|---|---|
| `inferred` | Derived from naming conventions or generic documentation |
| `observed` | Captured in a log or one Playwright run |
| `verified` | Reproduced from a clean state and mapped to an executable step |
| `deprecated` | Previously observed but no longer valid; retain provenance |

A downstream consumer may use `verified` mappings for formal automation.
`inferred` and `observed` mappings remain review-only evidence until replayed.

## Related Indexes

- Generated aggregate evidence: [`qaGridApi_Index.md`](qaGridApi_Index.md) and
  [`qaGridApi_Index.json`](qaGridApi_Index.json)
- Admin observations: [`Admin_GUI/Grid_API_Observation_Index.md`](Admin_GUI/Grid_API_Observation_Index.md)
- Trading observations: [`Trading_GUI/Grid_API_Observation_Index.md`](Trading_GUI/Grid_API_Observation_Index.md)
- Page profile contract: [`../pages/Grid_API_Profile_Contract.md`](../pages/Grid_API_Profile_Contract.md)

## Revision History

| Date | Change |
|---|---|
| 2026-09-01 | Added shared qaGridApi contract, safety classes, runtime key-resolution rule, and evidence boundary |
