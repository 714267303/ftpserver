# Trading GUI qaGridApi Observation Index

## Scope and Provenance

This index summarizes the real Trading UI calls in
`../../evidence/qaGrid/grid_log.txt`. It is
an observation catalog layered on top of the shared
[`Grid_API_Core_Index.md`](../Grid_API_Core_Index.md), not a replacement for
Trading GUI page rules.

The regenerable cross-channel roll-up is
[`../qaGridApi_Index.md`](../qaGridApi_Index.md); this file preserves the
human-reviewed Trading interpretation of the PageExplore evidence log.

| Item | Value |
|---|---|
| Raw log | `../../evidence/qaGrid/grid_log.txt` |
| Captured records | 585 |
| Exact keys | 120 |
| Logical key families | 13 |
| File size | 2,146,532 bytes |
| API name | `qaGridApi` |
| Status | `observed`; promote per page only after replay |

All observed keys use a dynamic UUID.  Canonical patterns below replace the
UUID with `<uuid>` and must be discovered at runtime.

## Method Frequency

| Method | Calls |
|---|---:|
| `getVisibleRowData()` | 180 |
| `getColumnDefs()` | 151 |
| `getVisibleOperationMenuPositionByIndex(...)` | 141 |
| `getFilteredCount()` | 73 |
| `getVisibleBoundaryByIndex(...)` | 27 |
| `setSelectedRows(...)` | 13 |

The `setSelectedRows` calls select data returned by the same Grid. They do not
establish that direct JavaScript selection is the preferred business action;
use the normal visible Trading GUI selection flow in automation.

## Logical Key Families

| Calls | Canonical key pattern | Main observed use |
|---:|---|---|
| 140 | `uiOrderHistory_<uuid>_orderHistoryTableId` | Order/trade history |
| 111 | `uiTradeHistoryExternal_<uuid>_tradeHistoryTableId` | External trade history |
| 89 | `uiTradeViewExternal_<uuid>_tradeViewTableId` | External trade view |
| 79 | `uiOrderBookExternal_<uuid>_orderBookTableId` | Order book and row selection |
| 49 | `uiPriceInformation_<uuid>_priceInformationTableId` | Price/market information |
| 38 | `uiLocalInactiveOrders_<uuid>_localInactiveOrdersTableId` | Inactive orders |
| 30 | `uiQuote_<uuid>_priceQuotesTableId` | Quotes |
| 25 | `uiPendingTradeReport_<uuid>_pendingTradeReportTableId` | Pending trade reports |
| 12 | `uiTradeTicker_<uuid>_tickerTableId` | Trade ticker |
| 5 | `uiAutomaticQuoteOrderBook_<uuid>_automaticQuoteOrderBookTableId` | Automatic quote book |
| 3 | `uiOrderDepth_<uuid>_orderDepthTableId` | Order depth |
| 3 | `uiPriceDepth_<uuid>_priceDepthTable` | Price depth |
| 1 | `uiEnterTradeReportInterbank_<uuid>_enterTradeReportInterbankTableId` | Interbank trade-report entry |

## Observed Column Schemas

The following are field-name observations, not universal contracts.  Ordering
varies between captures; page profiles should preserve the order only when a
case checks display order.

### Order Book External

Key pattern: `uiOrderBookExternal_<uuid>_orderBookTableId`

```text
atid, securityId, bRQty, aRQty, orderPrice, orderType, timeInForce,
expireDate, giveUpParticipant, giveUpInformation, clearingAccount, compId,
inactiveOrder, ahtIndicator, cnv, customerInformation, clientOrderId, smpId,
cod, positionEffect, orderId, created, changed, error, $UL_underlyingId
```

This capture demonstrates that `smpId` is an order-book field in Trading UI;
it does not define SMP behavior or an expected value.

### Order History

Key pattern: `uiOrderHistory_<uuid>_orderHistoryTableId`

```text
customerInformation, action, cnv, transactionTime, securityId,
bROrExecQty, aROrExecQty, rQty, orderQty, orderPrice, orderType,
timeInForce, expireDate, giveUpParticipant, giveUpInformation,
clearingAccount, compId, ahtIndicator, clientOrderId, smpId, cPart, cc,
positionEffect, orderId, atid, cod, reply, orderCancelReason
```

### Trade History / Trade View

Key patterns:

```text
uiTradeHistoryExternal_<uuid>_tradeHistoryTableId
uiTradeViewExternal_<uuid>_tradeViewTableId
```

Common fields observed:

```text
orderId, action, ep, securityId, tradeId, bought, sold, leavesQty,
executionPrice, clearingAccount, giveUpParticipant, giveUpInformation,
customerInformation, positionEffect, trType, transactionTime, compId,
dealSrc, cPART, atid
```

### Pending Trade Report

Key pattern: `uiPendingTradeReport_<uuid>_pendingTradeReportTableId`

```text
blockTradeReportId, direction, noBlockTradeLegs, counterpartyEpId,
tradeConclusionDateTime, specialIndicator, atid, aggregatedTrade,
transactionTime
```

Nested `legs` objects appeared in row data.  Keep nested shape in a page
profile only when a test needs it; do not flatten it in the core index.

### Price Information

Key pattern: `uiPriceInformation_<uuid>_priceInformationTableId`

```text
underlyingId, instId, underlying, market, instGroup, instType, currency,
tss, lastTradingDate, displayStrike, bestBidQty, bestBid, bestAsk,
bestAskQty, cop, latestTraded, latestTradedQty, highestTraded,
lowestTraded, openPrice, turn, totalTradeReportQty, ahtLatestTraded,
ahtLatestTradedQty, ahtHighestTraded, ahtLowestTraded, ahtOpenPrice,
ahtTurn, ahtTotalTradeReportQty
```

### Trade Ticker

Key pattern: `uiTradeTicker_<uuid>_tickerTableId`

```text
tradeId, securityId, executionQty, executionPrice, transactionTime,
dealSrc, action
```

## Replay and Promotion Checklist

For a page-specific profile, capture at least:

1. The route and visible page/container that owns the Grid.
2. The runtime key pattern and number of matching keys.
3. `getColumnDefs()` and one redacted non-empty row.
4. The exact visible assertion or selection action that consumes the observation.
5. A second clean replay before marking the profile `verified`.

Do not infer `cacheName`, filter support, status-code meaning, or business
semantics from this log.  Those belong to the route profile and network/FS
evidence.

## Related Material

- Shared contract: [`../Grid_API_Core_Index.md`](../Grid_API_Core_Index.md)
- Raw capture: `../../evidence/qaGrid/grid_log.txt`
- Generic filtering/pagination guide: `../../GRID_OPERATION_GUIDE.md`

## Revision History

| Date | Change |
|---|---|
| 2026-09-01 | Added normalized Trading key families, method counts, and observed schemas from `grid_log.txt` |
